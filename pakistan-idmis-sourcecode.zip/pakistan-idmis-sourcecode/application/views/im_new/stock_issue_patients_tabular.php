<?php

  if(isset($tran_reference_number)){
    $refernce_number=$tran_reference_number;
    $temp_row = $temp_records->result_array();
    //print_r($temp_records->result_array());exit;
    $row_temp = $temp_row[0];
    $issue_to = $row_temp['issuance_to'];
    $warehouse_to = $row_temp['warehouse_to'];
    $center_name = $row_temp['warehouse_name'];
    $patient_name = $row_temp['full_name'] . "-" . $row_temp['nic_no'];
}
if (isset($_REQUEST['patient_id'])) {
    $patient_id = $_REQUEST['patient_id'];
}



$this_patient_info=array();
if(!empty($patient))
{
    foreach ($patient as $row) {  
        if(isset($warehouse_to) && !empty($warehouse_to)){
            if($warehouse_to == $row['pk_id'])
            $this_patient_info = $row;
        }
        
        if(isset($patient_id) && !empty($patient_id)){
            if ($row['pk_id'] == $patient_id) 
            $this_patient_info = $row;
            }
    }
}
//echo '<pre>';
//print_r($this_patient_info);
////print_r($prod_assoc_array);
//echo '</pre>';
//exit;
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row  ">

                <div class="col-sm-5">
                    <div class="heading-buttons">
                        <h3>Patients History (Latest On Top)</h3>

                    </div>
                    <table class="table table-condensed table-bordered table-striped">
                           
                            
                            <tr>
                                <td>#</td>
                                <td>Issued from /<br/>Issuance Date</td>
                                <td>Item/<br/>Batch/<br/>Expiry</td>
                                <td>Issuance /  <br/>Returned</td>
                                <td>Next <br/>Issuance</td>
                            </tr>
                            <?php
                            $c=1;
                            if(!empty($medicine_history)){
                            foreach($medicine_history as $k => $row){
                                $nxt_date = '';
                                if(!empty($row->next_issuance_date) && $row->next_issuance_date > '1970-01-01' )
                                {
                                $nxt_date = date('d-M-Y',strtotime($row->next_issuance_date));
                                }
                                echo '<tr>
                                        <td>'.$c++.'</td>
                                        <td><span class="badge badge-primary">From: '.$row->warehouse_name.'</span> 
                                        <br/><span class="badge badge-info">On: '.$row->transaction_date.'</span> </td>
                                        <td><span class="badge badge-success">'.$row->product_name.' </span> 
                                        <br/><span class="badge badge-primary">Batch:'.$row->batch_number.'</span> 
                                        <br/><span class="badge badge-warning">Exp: '.$row->batch_expiry.'</span></td>
                                        <td><span class="badge badge-primary">'.$row->quantity.'</span>
                                        <br/><span class="badge badge-info">'.$row->vials_returned.'</span></td>
                                        <td>'.$nxt_date.'</td>
                                    </tr>';
                            }
                            }
                            else{
                                echo 'No item issued before';
                            }
                            ?>
                        </table>
                </div>
                <div class="col-sm-7"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Medicine / Insulin Issuance to Patients</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="stock_issue" name="stock_issue" action="<?php echo base_url("im_new/stock_issue_patients_tabular"); ?>">
                            <input type="hidden" name="center_from" id="center_from" value="<?=($this->session->warehouse_id)?>"
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row"> 
                                                 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Issuance Date <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="date" max="<?=date('Y-m-d')?>" data-date="" data-date-format="YYYY-MM-DD"  class="form-controlz" name="receiving_time" id="receiving_time" required value="<?php echo date("m/d/Y"); ?>" <?php if (isset($master_id)) echo 'readonly="true"' ?>>

                                                        </div>
                                                    </div>
                                                </div> 

                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Patient<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <?php
//                                                        if ((empty($temp_records))) 
                                                        if (true) {
                                                            ?>
                                                            <select style="display:none" class="select2mex input-medium" name="center_patient" id="center_patient" required style="width:100%;padding:10%;">
                                                                <option value="">Select</option> 
                                                                <?php foreach ($patient as $row) {  
                                                                    $sel='';
                                                                        if(isset($patient_id)){
                                                                            if($row['pk_id'] != $patient_id) continue;
                                                                            if ($row['pk_id'] == $patient_id) {
                                                                                $sel= 'selected="selected"'; 
                                                                                $this_patient_info = $row;
                                                                            }
                                                                         } 
                                                                        ?>
                                                                    <option value="<?php echo $row['pk_id'] ?>" <?=$sel?>><?php echo $row['full_name'] . "-" . $row['nic_no'] ?></option>
                                                                <?php } ?>
                                                            </select> 
                                                        <?php }else {
                                                            ?>
                                                            <input type = "text" class = "form-control" name = "center_patient_readonly" id = "center_patient_readonly" required value = "<?php
                                                            if (isset($issue_to)) {
                                                                if ($issue_to == 'centers') {
                                                                    echo ($center_name);
                                                                } else {
                                                                    echo $patient_name;
                                                                }
                                                            }
                                                                ?>" <?php
                                                                   if (isset($master_id))
                                                                       echo 'readonly="true"'
                                                                       ?>>
                                                                   <?php
                                                               }
                                                               echo $this_patient_info['full_name']. "<br/>" . $this_patient_info['nic_no'];
                                                               ?>
                                                    </div>
                                                </div>
                                                  
                                         
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="vials" required >Empty Vials Returned <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="vials_returned" min="0" step="1" id="vials_returned" class="form-control"  required  >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Notes / Remarks / Observation</label>
                                                        <div class="controls">
                                                            <textarea name="remarks" id="remarks" class="form-control" ></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-12">
                                                    <div class="control-group">
                                                        <div class="controls">
                                                            
                                                            <span id="nxt"></span>
                                                            <input type="hidden" name="insulin_1"       id="insulin_1"      class="form-control" value="<?=@$this_patient_info['insulin_1']?>" >
                                                            <input type="hidden" name="daily_units_1"   id="daily_units_1"  class="form-control" value="<?=@$this_patient_info['daily_units_1']?>" >
<!--                                                            <input type="hidden" name="units_in_vial_1" id="units_in_vial_1" class="form-control" value="<?=@$prod_assoc_array[$this_patient_info['insulin_1']]['daily_units_in_single_item']?>" >-->
                                                            <input type="hidden" name="insulin_2"       id="insulin_2"      class="form-control" value="<?=@$this_patient_info['insulin_2']?>" >
                                                            <input type="hidden" name="daily_units_2"   id="daily_units_2"  class="form-control" value="<?=@$this_patient_info['daily_units_2']?>" >
<!--                                                            <input type="hidden" name="units_in_vial_2" id="units_in_vial_2" class="form-control" value="<?=@$prod_assoc_array[$this_patient_info['insulin_2']]['daily_units_in_single_item']?>" >-->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div> 
                                            <div class="form-group row">
                                                
                                                
                                                <span id="nxt"></span>
                                                <table class="table table-striped table-bordered table-condensed dt-responsive nowrap" id="datatable-buttonsxx">
                                                    <tr>
<!--                                                        <td>#</td>-->
                                                        <td>Item Name</td>
                                                        <td>Batch <br/>/ Expiry</td>
                                                        <td>Stock <br/>Available</td>
                                                        <td>Issuance <br/>Limit</td>
                                                        <td>Issuance <br/>Quantity</td>
                                                        <td>Next <br/>Issuance <br/>Date</td>
                                                    </tr>   
                                            <?php
                                            $c=1;
                                            
                                            foreach ($product as $row) {
                                                if(!empty($row['issuance_limit']) && $row['issuance_limit'] > 0 && $row['issuance_limit'] < $row['quantity']){
                                                    $max=$row['issuance_limit'];
                                                    
                                                }else{
                                                    $max=$row['quantity'];
                                                }
                                                
                                                $r_cls = '';
                                                $enable_issuance = false;
                                                if(in_array($row['item_id'], $oral_drugs) || $this_patient_info['insulin_1'] == $row['item_id'] || $this_patient_info['insulin_2'] ==$row['item_id'] )
                                                {
                                                  //if oral drug or insulin
                                                    $enable_issuance = true;
                                                    if( $this_patient_info['insulin_1'] == $row['item_id']){
                                                        @$row['daily_dose'] = $this_patient_info['daily_units_1'];
                                                    } 
                                                    if( $this_patient_info['insulin_2'] == $row['item_id']){
                                                        @$row['daily_dose'] = $this_patient_info['daily_units_2'];
                                                    }
                                                    
                                                    if(!empty($oral_drugs_dose[$row['item_id']]))
                                                    @$row['daily_dose'] = $oral_drugs_dose[$row['item_id']];
                                                }
                                                
                                                echo '<tr style="background-color:#'.$r_cls.'">';
//                                                echo '<td>'.$c++.'</td>';
                                                echo '<td>'.$row['product_name'].' ';
                                                    echo '<input type="hidden" name="product['.$row['batch_id'].']" value="'.$row['item_id'].'">';
                                                    echo '<input type="hidden" name="batch['.$row['batch_id'].']"   value="'.$row['batch_id'].'">';
                                                echo '</td>';
                                                echo '<td>'.$row['batch_number'].'<br/>Exp:'.$row['batch_expiry'].'</td>';
                                                echo '<td align="right">'.number_format($row['quantity']).'</td>';
                                                echo '<td align="right">'.((!empty($row['issuance_limit']) && $row['issuance_limit']>0)?number_format($row['issuance_limit']):'-').'</td>';
                                                echo '<td align="right">';
                                                if($enable_issuance){
                                                    echo '<input class="form-control patient_issuance_tabular" name="quantity['.$row['batch_id'].']" style="width:100%" type="number" min="0" step = "1" batch_id="'.$row['batch_id'].'" item_id="'.$row['item_id'].'" max="'.$max.'" issuance_limit="'.@$row['issuance_limit'].'" available_stock="'.@$row['quantity'].'"  daily_units_in_single_item="'.@$row['daily_units_in_single_item'].'" daily_dose="'.@$row['daily_dose'].'"><br/>';
                                                }
                                                echo '</td>';
                                                echo '<td class="nxt_date_cls_'.$row['item_id'].'">';
                                                ?>
                                                <input type="hidden"  class=" nxt_date_input" name="next_issuance_date[<?=$row['batch_id']?>]"  value="">
                                               
                                                <span class="msg h5 btn btn-secondary" style="display:none;" ></span>
                                                <br/>
                                                <button style="display:none;" type="button" class="reason btn btn-primary waves-effect waves-light mo-mb-2" 
                                                        data-toggle="popover" data-trigger="focus" title="Details" 
                                                        data-content="Calculations to be displayed here">
                                                    ?
                                                </button>
                                           
                                                <?php
                                                
                                                
                                                echo '</td>';
                                                echo '</tr>';
                                                
                                                
                                            }
                                            ?>
                                                </table>
                                                
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <input type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" value="Issue Items" > 

                                                </div>  
                                                <?php if (false && isset($temp_records)&&(!empty($temp_records))) {
                                                    ?>
<!--                                                    <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>"> -->
                                                <?php }
                                                ?>    
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                       
                        </form>
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>
