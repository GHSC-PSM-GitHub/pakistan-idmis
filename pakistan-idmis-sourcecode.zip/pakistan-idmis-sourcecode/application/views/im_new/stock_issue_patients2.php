<table class="table table-striped table-bordered table-condensed dt-responsive ">
    <thead>
        <tr>
            <th style="width: 1%;" class="center">No.</th>
            <th>Visit Code</th>
            <th>Product Name</th>
            <th>Prescribed Qty</th>
            <!--<th>Batch Number</th>-->
            <!--<th>Expiry Date</th>-->
            <th>Issued Quantity</th>
            <th>Remarks</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <!-- Table row -->
        <?php
        $count = 1;
        foreach ($temp_records->result_array() as $row) {
        ?>
            <tr>
                <td class="center"><?php echo $count; ?></td>
                <td><?php echo $row['transaction_reference']; ?></td>
                <td><?php echo $row['product_name']; ?></td>
                <td class="important"><?php echo $row['prescribed_quantity']; ?></td>
                <!--<td class="important"><?php //echo $row['batch_number']; ?></td>-->
                <!--<td class="important"><?php //echo $row['batch_expiry']; ?></td>-->
                <td class="important"><?php echo $row['quantity']; ?></td>
                <td class="important"><?php echo $row['remarks']; ?></td>
                <td><button class="btn btn-danger btn-sm" type="button" id="<?php echo $row['batch_id'] . "_" . $row['pk_id'] . "_" . $row['stock_master_id'] . "_" . $row['patient_id']; ?>-deletepp">
                    <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
                </button></td>
            </tr>
        <?php
            $count++;
        }
        ?>
        <!-- // Table row END -->
        <!-- Table row -->

        <!-- // Table row END -->
    </tbody>
</table>