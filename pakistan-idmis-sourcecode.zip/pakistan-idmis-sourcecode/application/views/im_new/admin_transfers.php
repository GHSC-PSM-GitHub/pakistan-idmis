<?php
//print_r($stock_master_records);exit;
if (isset($stock_master_records)) {


    $row = $stock_master_records[0];
    $refernce_number = $row['transaction_reference'];
    $temp_row = $temp_records->result_array();
    $row_temp = $temp_row[0];
    $issue_to = $row_temp['issuance_to'];
    $center_name = $row_temp['warehouse_name'];
    $center_from = $row_temp['wh_from'];
    $patient_name = $row_temp['full_name'] . "-" . $row_temp['nic_no'];
//    print_r($patient_name);exit;
} 
else if(isset($tran_reference_number)){
    $refernce_number=$tran_reference_number;
    $temp_row = $temp_records->result_array();
//    print_r($temp_records->result_array());exit;
    $row_temp = $temp_row[0];
    $issue_to = $row_temp['issuance_to'];
    $center_name = $row_temp['warehouse_name'];
    $center_from = $row_temp['wh_from'];
    $patient_name = $row_temp['full_name'] . "-" . $row_temp['nic_no'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Admin Control for Stock Transfers (Between Centers)</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="stock_issue" name="stock_issue" action="<?php echo base_url("im_new/admin_transfers"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row"> 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Letter No./Reference Number <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="refernce_number" id="reference_number" class="form-control" required="" <?php if (isset($master_id)) echo 'readonly="true"' ?> 
                                                            <?php
                                                            if (isset($refernce_number)) {
                                                                echo 'value="' . $refernce_number . '"';
                                                            }
                                                            ?>

                                                                   >

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Transfer Date <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="receiving_time" id="receiving_time" required value="<?php echo date("d/m/Y"); ?>" <?php if (isset($master_id)) echo 'readonly="true"' ?>>

                                                        </div>
                                                    </div>
                                                </div> 

                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Issue From <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <?php
                                                        if ((empty($temp_records))) {
                                                            ?>
                                                            <select class="select2me input-medium" name="center_from" id="center_from" required style="width:100%;padding:10%;">
                                                                <option value="">Select</option> 
                                                                <?php foreach ($warehouse as $row) {
                                                                    ?>
                                                                    <option value="<?php echo $row['wh_id'] ?>"><?php echo $row['warehouse_name'] ?></option>
                                                                <?php } ?>
                                                            </select> 
                                                        <?php } else {
                                                            ?>
                                                            <input type="hidden" name="center_from" id="center_from" value="<?=@$wh_from?>">
                                                            <input type = "text" class = "form-control" name = "center_from_readonly" id = "center_from_readonly" required value = "<?php
                                                            if (isset($issue_to)) { 
                                                                    echo ($center_from);
                                                                 
                                                            }
                                                            ?>" <?php
                                                                   if (isset($master_id))
                                                                       echo 'readonly="true"'
                                                                       ?>>
                                                                   <?php
                                                               }
                                                               ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Issue To<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <?php
                                                        if ((empty($temp_records))) {
                                                            ?>
                                                            <select class="select2me input-medium" name="center_patient" id="center_patient" required style="width:100%;padding:10%;">
                                                                <option value="">Select</option> 
                                                                <?php foreach ($warehouse as $row) {
                                                                    if($row['pk_id'] == $this->session->userdata('warehouse_id')) continue;
                                                                    ?>
                                                                    <option value="<?php echo $row['wh_id'] ?>"><?php echo $row['warehouse_name'] ?></option>
                                                                <?php } ?>
                                                            </select> 
                                                        <?php } else {
                                                            ?>
                                                            <input type = "text" class = "form-control" name = "center_patient_readonly" id = "center_patient_readonly" required value = "<?php
                                                            if (isset($issue_to)) {
                                                                if ($issue_to == 'centers') {
                                                                    echo ($center_name);
                                                                } else {
                                                                    echo $patient_name;
                                                                }
                                                            }
                                                            ?>" <?php
                                                                   if (isset($master_id))
                                                                       echo 'readonly="true"'
                                                                       ?>>
                                                                   <?php
                                                               }
                                                               ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Product<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select  class="select2me input-medium" name="product" id="product" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                           
                                                            <?php
                                                            foreach ($product as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['item_id'] ?>" <?php if (isset($product_id) && $product_id == $row['item_id']) echo "selected='selected'"; ?>><?php echo $row['product_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div> 

                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="batch" required >Batch<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <select disabled class="select2me input-medium" name="batch" id="batch" required style="width:100%;padding:10%;">
                                                                <option value="">Select</option>

                                                            </select>                                                        
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="quantity" required >Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="quantity" id="quantity" class="form-control" min="0"  pattern="\d+" required >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-1">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="available_quantity" required >Available </label>
                                                        <div class="controls">
                                                            <input name="available_quantity" id="available_quantity" class="form-control"   required readonly="true">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Expiry Date</label>
                                                        <div class="controls">
                                                            <input type="text" name="batch_expiry" id="batch_expiry" class="form-control"   required value="" readonly="true">
                                                        </div>
                                                    </div>
                                                </div> 


                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Remarks</label>
                                                        <div class="controls">
                                                            <textarea name="remarks" id="remarks" class="form-control" <?php
                                                                   if (isset($master_id))
                                                                       echo 'readonly="true"'
                                                                       ?>></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" > Add Issue</button>

                                                </div>  
                                                <?php if (isset($temp_records) && (!empty($temp_records))) {
                                                    ?>
                                                    <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>"> 
                                                <?php }
                                                ?>    
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <br>
                            <?php
                            if (isset($temp_records) && (!empty($temp_records))) {
                                ?>

                                <div id="divToPrint">
                                    <table class="table table-striped table-bordered table-condensed dt-responsive " >
                                        <thead>
                                            <tr>
                                                <th style="width: 1%;" class="center">No.</th>
                                                <th>Product Name</th>  
                                                <th>Manufacturer</th>
                                                <th>Batch Number</th>
                                                <th>Expiry Date</th> 
                                                <th>Quantity</th> 
                                                <!--<th>Action</th>-->  
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- Table row -->
                                            <?php
                                            $count = 1;
                                            foreach ($temp_records->result_array() as $row) {
                                                ?>
                                                <tr>
                                                    <td class="center"><?php echo $count; ?></td>
                                                    <td><?php echo $row['product_name']; ?></td> 
                                                    <td class="important"><?php echo $row['manufacturer']; ?></td>
                                                    <td class="important"><?php echo $row['batch_number']; ?></td>
                                                    <td class="important"><?php echo $row['batch_expiry']; ?></td> 
                                                    <td class="important"><?php echo $row['quantity']; ?></td> 

                <!--                                                <td>  
                                                                    <a onclick="return confirm('Are you sure you want to Delete?');" href="<?php echo base_url("product_management/deactivate?id=") . $row['pk_id']; ?>&status=1" class="btn btn-sm btn-light glyphicons bin" > Delete</a>
                                                                </td> -->
                                                </tr>
                                                <?php
                                                $count++;
                                            }
                                            ?>
                                            <!-- // Table row END -->
                                            <!-- Table row -->

                                            <!-- // Table row END -->
                                        </tbody>
                                    </table> 
                                </div>
                                <button type="button" id="save_temp_issue" name="save_temp_issue" class="btn btn-primary waves-effect waves-light" style="margin-left:90%;">Save</button>

                                <!-- // Table END -->
                                <?php
                            }
                            ?>
                        </form>    
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>
