<?php

if (isset($stock_master_records)) {


    $row = $stock_master_records[0];
    $refernce_number = $row['transaction_reference'];
    $vials_returned = $row['vials_returned'];
    $temp_row = $temp_records->result_array();
    $row_temp = $temp_row[0];
    $issue_to = $row_temp['issuance_to'];
    $warehouse_to = $row_temp['warehouse_to'];
    $center_name = $row_temp['warehouse_name'];
    $patient_name = $row_temp['full_name'] . "-" . $row_temp['nic_no'];

//    print_r($patient_name);exit;
}
else if(isset($tran_reference_number)){
    $refernce_number=$tran_reference_number;
    $temp_row = $temp_records->result_array();
//    print_r($temp_records->result_array());exit;
    $row_temp = $temp_row[0];
    $issue_to = $row_temp['issuance_to'];
    $warehouse_to = $row_temp['warehouse_to'];
    $center_name = $row_temp['warehouse_name'];
    $patient_name = $row_temp['full_name'] . "-" . $row_temp['nic_no'];
}
if (isset($_REQUEST['patient_id'])) {
    $patient_id = $_REQUEST['patient_id'];
}



$this_patient_info=array();
if(!empty($patient))
{
    foreach ($patient as $row) {  
        echo 'a';
        if(isset($warehouse_to) && !empty($warehouse_to)){
            if($warehouse_to == $row['pk_id'])
            $this_patient_info = $row;
        }
        
        if(isset($patient_id) && !empty($patient_id)){
            if ($row['pk_id'] == $patient_id) 
            $this_patient_info = $row;
            }
    }
}
//echo '<pre>';
//print_r($this_patient_info);
////print_r($prod_assoc_array);
//echo '</pre>';
//exit;
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Stock Issue</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="stock_issue" name="stock_issue" action="<?php echo base_url("im_new/stock_issue_patients"); ?>">
                            <input type="hidden" name="center_from" id="center_from" value="<?=($this->session->warehouse_id)?>"
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row"> 
                                                 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Issuance Date <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="receiving_time" id="receiving_time" required value="<?php echo date("d/m/Y"); ?>" <?php if (isset($master_id)) echo 'readonly="true"' ?>>

                                                        </div>
                                                    </div>
                                                </div> 

                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Patient<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <?php
                                                        if ((empty($temp_records))) {
                                                            ?>
                                                            <select class="select2me input-medium" name="center_patient" id="center_patient" required style="width:100%;padding:10%;">
                                                                <option value="">Select</option> 
                                                                <?php foreach ($patient as $row) {  
                                                                    $sel='';
                                                                        if(isset($patient_id)){
                                                                            if($row['pk_id'] != $patient_id) continue;
                                                                            if ($row['pk_id'] == $patient_id) {
                                                                                $sel= 'selected="selected"'; 
                                                                                $this_patient_info = $row;
                                                                            }
                                                                         } 
                                                                        ?>
                                                                    <option value="<?php echo $row['pk_id'] ?>" <?=$sel?>><?php echo $row['full_name'] . "-" . $row['nic_no'] ?></option>
                                                                <?php } ?>
                                                            </select> 
                                                        <?php }else {
                                                            ?>
                                                            <input type = "text" class = "form-control" name = "center_patient_readonly" id = "center_patient_readonly" required value = "<?php
                                                            if (isset($issue_to)) {
                                                                if ($issue_to == 'centers') {
                                                                    echo ($center_name);
                                                                } else {
                                                                    echo $patient_name;
                                                                }
                                                            }
                                                                ?>" <?php
                                                                   if (isset($master_id))
                                                                       echo 'readonly="true"'
                                                                       ?>>
                                                                   <?php
                                                               }
                                                               ?>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Item / Product Name<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="product" id="product" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            $prod_assoc_array = array();
                                                            foreach ($product as $row) {
                                                                $prod_assoc_array[$row['item_id']]=$row;
                                                                ?>
                                                                <option value="<?php echo $row['item_id'] ?>" <?php if (isset($product_id) && $product_id == $row['item_id']) echo "selected='selected'"; ?> issuance_limit="<?=@$row['issuance_limit']?>" daily_units_in_single_item="<?=@$row['daily_units_in_single_item']?>"><?php echo $row['product_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="batch" required >Batch Number<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="batch" id="batch" required style="width:100%;padding:10%;">
                                                                <option value="">Select</option>

                                                            </select>                                                        
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <?php
//            echo '<pre>';
//            print_r($product);
//            print_r($prod_assoc_array);
//            echo '</pre>';
//            exit;
                                            ?>
                                            <div class="form-group row"> 
                                                
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="available_quantity" required >Available Quantity</label>
                                                        <div class="controls">
                                                            <input name="available_quantity" tabindex="-1" id="available_quantity" class="form-control bg-white border-white"    readonly="true">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Expiry Date </label>
                                                        <div class="controls">
                                                            <input type="text" name="batch_expiry" tabindex="-1"  id="batch_expiry" class="form-control bg-white border-white"   value="" readonly="true">
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="quantity" required id="qty_label">Issuance Quantity<span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="quantity" id="quantity" class="form-control"   required >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Remarks</label>
                                                        <div class="controls">
                                                            <textarea name="remarks" id="remarks" class="form-control" ></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                
                                                
                                            </div> 
                                            <div class="form-group row">

                                                
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" > Add Issue</button>

                                                </div>  
                                                <?php if (isset($temp_records)&&(!empty($temp_records))) {
                                                    ?>
                                                    <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>"> 
                                                <?php }
                                                ?>    
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <br>
                            <?php
                            if (isset($temp_records)&&(!empty($temp_records))) {
                                ?>

                                <div id="divToPrint">
                                    <table class="table table-striped table-bordered table-condensed dt-responsive " >
                                        <thead>
                                            <tr>
                                                <th style="width: 1%;" class="center">No.</th>
<!--                                                <th>Funding Source</th>-->
                                                <th>Product Name</th>  
<!--                                                <th>Manufacturer</th>-->
                                                <th>Batch Number</th>
                                                <th>Expiry Date</th> 
                                                <th>Quantity</th> 
                                                <!--<th>Action</th>-->  
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- Table row -->
                                            <?php
                                            $count = 1;
                                            foreach ($temp_records->result_array() as $row) {
                                                ?>
                                                <tr>
                                                    <td class="center"><?php echo $count; ?></td>
<!--                                                    <td class="important"><?php //echo $row['funding_source_name']; ?></td>-->
                                                    <td><?php echo $row['product_name']; ?></td> 
<!--                                                    <td class="important"><?php //echo $row['manufacturer']; ?></td>-->
                                                    <td class="important"><?php echo $row['batch_number']; ?></td>
                                                    <td class="important"><?php echo $row['batch_expiry']; ?></td> 
                                                    <td class="important"><?php echo $row['quantity']; ?></td> 

                        <!--                                                <td>  
                                                                            <a onclick="return confirm('Are you sure you want to Delete?');" href="<?php echo base_url("product_management/deactivate?id=") . $row['pk_id']; ?>&status=1" class="btn btn-sm btn-light glyphicons bin" > Delete</a>
                                                                        </td> -->
                                                </tr>
                                                <?php
                                                $count++;
                                            }
                                            ?>
                                            <!-- // Table row END -->
                                            <!-- Table row -->

                                            <!-- // Table row END -->
                                        </tbody>
                                    </table> 
                                </div>

                                <!-- // Table END -->
                                <button type="button" id="save_temp_issue" name="save_temp_issue" class="btn btn-primary waves-effect waves-light" style="margin-left:90%;">Save</button>

                                <?php
                            }
                            ?>
                        </form>
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>
