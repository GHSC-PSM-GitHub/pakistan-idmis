<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Stock Adjustment Search</h3>
                         
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                     <div class="innerLR">
                        <br>
                        <?php
                        if (!empty($result)) {
                            ?>

                            <div id="divToPrint" style="overflow: auto">
                                <table class="table table-striped table-bordered table-condensed dt-responsive nowrap" id="datatable-buttons">
                                    <thead> 
                                        <tr>
                                            <th style="width: 1%;" class="center">No.</th>
                                            <th>Transaction Number</th>
                                            <th>Adjustment Number</th>
                                            <th>Reference Number</th>
                                            <th>Receiving Date</th>
                                            <th>Funding Source</th>
                                            <th>Product Name</th>   
                                            <th>Batch Number</th>
                                            <th>Expiry Date</th> 
                                            <th>Quantity</th> 
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Table row -->
                                        <?php
                                        $count = 1; 
                                        foreach ($result->result_array() as $row) {
                                            ?>
                                            <tr>
                                                <td class="center"><?php echo $count; ?></td>
                                                <td class="important"><?php echo "R-".sprintf('%04d', $row['fk_stock_id']); ?></td>
                                                 <td class="important"><?php echo $row['tran_no']; ?></td>
                                                <td class="important"><?php echo $row['tran_ref']; ?></td>
                                                 <td class="important"><?php echo $row['tran_date']; ?></td>
                                                 <td class="important"><?php echo $row['funding_source_name']; ?></td>
                                                <td><?php echo $row['product_name']; ?></td>  
                                                <td class="important"><?php echo $row['batch_no']; ?></td>
                                                <td class="important"><?php echo $row['batch_expiry']; ?></td> 
                                                <td class="important"><?php echo $row['quantity']; ?></td> 
                                                
                                            </tr>
                                            <?php
                                            $count++;
                                        }
                                        ?>
                                        <!-- // Table row END -->
                                        <!-- Table row -->

                                        <!-- // Table row END -->
                                    </tbody>
                                </table> 
                            </div>

                            <!-- // Table END -->
                            <?php
                        } else {
                            echo "<hr><h5>No data found!</h5>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
