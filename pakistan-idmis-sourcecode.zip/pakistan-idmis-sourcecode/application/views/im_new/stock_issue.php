<?php
if ((isset($message)) && ($message != '')) {
	echo '<script> alert("' . $message . '"); </script>';
}
?>
<style>
	.datepicker.dropdown-menu {
		z-index: 9999 !important;
	}
</style>
<?php
$from_id = '';
$pkdetailid = '';
$pkmasterid = '';
//echo 'Master ID'.$master_id;exit;
 
//print_r($form['driver_names']);exit;
if (isset($_REQUEST['pkdetailid']) && !empty($_REQUEST['pkdetailid'])) {
	$pkdetailid = $_REQUEST['pkdetailid'];
}
if (isset($_REQUEST['fkstockid']) && !empty($_REQUEST['fkstockid'])) {
	$pkmasterid = $_REQUEST['fkstockid'];
}
//print_r($stock_master_records);exit;
if (isset($stock_master_records)) {

	$row = $stock_master_records[0];
	$refernce_number = $row['tran_ref'];
	$transaction_date = $row['tran_date'];
	$temp_row = $temp_records->result_array();
	$row_temp = $temp_row[0];
	$issue_to = $row_temp['issuance_to'];
	$center_name = $row_temp['warehouse_name'];
	$patient_name = $row_temp['full_name'] . "-" . $row_temp['nic_no'];
	//    print_r($patient_name);exit;
} else if (isset($tran_reference_number)) {
	$refernce_number = $tran_reference_number;
	$temp_row = $temp_records->result_array();
	//    print_r($temp_records->result_array());exit;
	$row_temp = $temp_row[0];
	$issue_to = $row_temp['issuance_to'];
	$center_name = $row_temp['warehouse_name'];
	$patient_name = $row_temp['full_name'] . "-" . $row_temp['nic_no'];
}

$driver_names = $form['driver_names'];
 $driver_cnic = $form['driver_cnic'];
 $driver_contact = $form['driver_contact'];
 $driver_vehicle = $form['driver_vehicle'];
 $service_name = $form['service_name'];
 $consignment_no = $form['consignment_no'];
 $driver_reference = $form['driver_reference'];
 $agency_name = $form['agency_name'];

$siv_mode_of_transport = $form['siv_mode_of_transport'];

if (isset($issue_data)) {
	$row = $issue_data[0];
	//    print_r($row);exit;
	$date1 = str_replace('-', '/', $row['tran_date']);
	$TranDate = date('m/d/Y', strtotime($date1));
	$TranRef = $row['tran_ref'];
	//    $batch_expiry = $row['batch_expiry'];
	$WHIDTo = $row['wh_id_to'];
	$driver_names = $row['siv_driver_name'];
	$issue_to_info = $row['issue_to_info'];
	//    $production_date = $row['production_date'];
	$driver_contact = $row['siv_contatc_number'];
	$driver_cnic = $row['siv_cnic'];
	$driver_vehicle = $row['siv_vehicle_plate_no'];
	$siv_weight = $row['siv_weight'];
	$siv_transportation_po = $row['siv_transportation_po'];
	$siv_tracking_no = $row['siv_tracking_no'];
	$siv_no_of_cartons = $row['siv_no_of_cartons'];
	$source_type = $row['source_type'];
	$provinces_id = $row['province_id'];
	$editbatch_id = $row['batch_id'];
	$quantity = abs($row['quantity']);
	$ReceivedRemarks = $row['received_remarks'];
	$stk_id = $row['stk_id'];
	$siv_vehicle_type = $row['siv_vehicle_type'];
	$siv_mode_of_transport = $row['siv_mode_of_transport'];
	$service_name = $row['service_name'];
  $consignment_no = $row['consignment_no'];
  $driver_reference = $row['builty'];
  $agency_name = $row['agency_name'];

	$siv_name_of_transporters_edit = $row['siv_name_of_transporter'];
	$siv_vehicle_plate_no_edit = $row['siv_vehicle_plate_no'];
	if (isset($row['itm_id'])) {
		$item_id = $row['itm_id'];
	}
	if (isset($row['item_id'])) {
		$item_id = $row['item_id'];
	}
	//    $dc_date = $row['dc_date'];
	//    $invoice = $row['invoice'];
	//    $po_quantity = $row['po_quantity'];
	//    $actual_rec_qty = $row['actual_rec_qty'];
	//    $vehicle_reg = $row['vehicle_reg'];
	//    $driver_contract = $row['driver_contract'];
	//    $driver_name = $row['driver_names'];
	//    $wh_id_from_supplier = $row['wh_id_from_supplier'];
	//    $currency = $row['currency'];
	//    $conversion_rate = $row['conversion_rate'];
	//    $wh_id_from = $row['wh_id_from'];
	//    $tran_ref = $row['tran_ref'];
	//    $fkstockid = $row['fk_stock_id'];
	//    $pkdetailid = $row['pk_id'];
	//    $batchid = $row['batch_id'];
	//    $districts = $districts->result_object();
	//    $tehsils = $tehsils->result_object();
	//    $ucs = $ucs->result_object();
	//    $str_arr = str_replace("-",",",$string);
	//    $age = explode (",", $str_arr);
	//    $diff = abs(strtotime(date("Y-m-d"))-strtotime($string));
	//    $years = floor($diff / (365*60*60*24));
	//    print_r($years);
	//    $patient_month = $row['patient_month'];
	//    $email = $row['email'];
	//    $patient_id = $row['pk_id'];
	//    print_r($age);

}
?>

<div class="wrapper">
	<div class="container-fluid">
		<!-- Page-Title -->
		<div class="page-title-box">
			<div class="row align-items-center">

				<div class="col-sm-12">
					<div class="separator bottom"></div>

					<div class="heading-buttons">
						<h3>Stock Issuance</h3>

					</div>
					<div class="separator bottom"></div>

					<div class="innerLR">
						<form method="post" id="stock_issue" name="stock_issue" enctype="multipart/form-data" action="<?php echo base_url("im_new/stock_issue"); ?>">
							<input type="hidden" name="center_from" id="center_from" value="<?= ($this->session->warehouse_id) ?>" <div class="row">
							<div class="col-12">
								<div class="card m-b-30">
									<div class="card-body">
										<div class="form-group row">
											<div class="col-md-3">
												<div class="control-group">
													<label class="example-text-input" for="hf" required>Letter No./Requisition / DR# </label>
													<div class="controls">
														<input type="text" name="refernce_number" id="reference_number" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?> 
														<?php
															if (isset($refernce_number)) {
																echo 'value="' . $refernce_number . '"';
															} else if (isset($TranRef)) {
																echo 'value="' . $TranRef . '"';
															}
															?>>

													</div>
												</div>
											</div>
											<div class="col-md-3">
												<div class="control-group">
													<label class="example-text-input" for="hf" required>Transfer Date(MM/DD/YYYY) <span style="color: red">*</span> </label>
													<div class="controls">
														<input type="text" class="form-control" name="receiving_time" id="receiving_times" required <?php if (isset($master_id)) echo 'readonly="true"' ?> <?php
																																																			if (isset($TranDate)) {
																																																				echo 'value="' . $TranDate . '"';
																																																			} else {
																																																				echo 'value="' . date("m/d/Y") . '"';
																																																			}
																																																			?>>

													</div>
												</div>
											</div>

											<!-- <div class="col-md-3">
													<div class="control-group">
														<label class="example-text-input" for="issue_to_info" required>Issue To </label>
														<div class="controls">
															<input type="text" name="issue_to_info" id="issue_to_info" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?> <?php
																																																	if (isset($issue_to_info) && !empty($issue_to_info)) {
																																																		echo 'value="' . $issue_to_info . '"';
																																																	} else if (isset($form['issue_to_info'])) {
																																																		echo 'value="' . $form['issue_to_info'] . '"';
																																																	}
																																																	?>>

														</div>
													</div>
												</div> -->
											<!--	<div class="col-md-3">
												<div class="control-group">
													<label class="example-text-input" for="currency" required>Currency <span style="color: red">*</span> </label>
													<div class="controls">
														<select class="select2me input-medium" name="currency" id="currency" style="width:100%;padding:10%;" disabled 
													
															<?php

															foreach ($currency_type as $currencytype) {
															?>
																<option value="<?php echo $currencytype['pk_id']; ?>" ><?php echo $currencytype['name'] ?></option>
															<?php
															}
															?>
														</select>

													</div>
												</div>
											</div> -->

           <div class="col-md-3">
            <label class="example-text-input" required>Category <span style="color: red">*</span></label>
            <div class="controls">
             <select required class="select2me input-medium" name="stakeholder" id="stakeholder" style="width:100%;padding:10%;" <?php if (isset($master_id) && !empty($master_id)) echo 'disabled="true"' ?>>
              <option value="">Select</option>
              <?php
              foreach ($stakeholder as $row) {
              ?>
               <option value="<?php echo $row['stkid'] ?>" <?php if (isset($form['stakeholder']) && $form['stakeholder'] == $row['stkid']) echo "selected='selected'";
                          else if (isset($stk_id) && $stk_id == $row['stkid'])  echo "selected='selected'";  ?>><?php echo $row['stkname'] ?></option>
              <?php
              }
              ?>
             </select>
            </div>
           </div>
           <div class="col-md-3">
            <label class="example-text-input" required>Product<span style="color: red">*</span> </label>
            <div class="controls">
             <select class="select2me input-medium" name="product" id="issue_product" required style="width:100%;padding:10%;">
              <option value="">Select</option>
              <?php
              //                                                            foreach ($product as $row) {
              ?>
              <!--<option id="<?php // echo $row['itm_id'].'_'.$row['product_type']; 
                  ?>" value="<?php echo $row['itm_id'] ?>" <?php if (isset($item_id) && $item_id == $row['itm_id']) echo "selected='selected'";
                                          else if (isset($product_id) && $product_id == $row['itm_id']) echo "selected='selected'"; ?>><?php echo $row['itm_name'] ?></option>-->
              <?php
              //                                                            }
              ?>
             </select>
            </div>
           </div>
           	 <input type="hidden" name="stock_type" id="stock_type" value="stock_issue">
           <input type="hidden" name="issue_product_edit" id="issue_product_edit" value="<?php if (isset($item_id)) echo $item_id; ?>">
            <input type="hidden" name="issue_product_category" id="issue_product_category" value="<?php if (isset($form['stakeholder'])) echo $form['stakeholder']; ?>">
            <input type="hidden" name="stock_type" id="stock_type" value="stock_issue">
										</div>         
										<div class="form-group row">
											<div class="col-md-3" id="show_batch" style="display:none;">
													<div class="control-group">
														<label class="example-text-input" for="batch">Batch<span style="color: red">*</span> </label>
														<div class="controls">
															<select class="select2me input-medium issue_batch_stock" name="batch" id="issue_batch_stock" style="width:100%;padding:10%;">
																<option value="">Select</option>

															</select>
														</div>
													</div>
												</div>	

            <div class="col-md-3">
            <div class="control-group">
             <label class="example-text-input" for="available_quantity" required>Available Quantity <span style="color: red">*</span></label>
             <div class="controls">
              <input name="available_quantity" id="available_quantity" class="form-control" required readonly="true">
             </div>
            </div>
           </div>
												
												<div class="col-md-3">
												<div class="control-group">
													<label class="example-text-input" for="quantity" required>Quantity <span style="color: red">*</span></label>
													<div class="controls">
														<input type="number" name="quantity" id="quantity" class="form-control" min="0" pattern="\d+" required >
													</div>
												</div>
											</div>

            <div class="col-md-3">
            <div class="control-group">
             <label class="example-text-input" for="weight" required>Weight </label>
             <div class="controls">
              <input type="text" name="weight" id="weight" class="form-control" value="">

             </div>
            </div>
           </div>
										</div>
										<div class="form-group row">
											
										<!--	<div class="col-md-3">
												<div class="control-group">
													<label class="example-text-input" for="no_of_cartons" required>Number of Cartons </label>
													<div class="controls">
														<input type="text" name="no_of_cartons" id="no_of_cartons" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?> <?php
																																																if (isset($siv_no_of_cartons)) {
																																																	echo 'value="' . $siv_no_of_cartons . '"';
																																																} else if (isset($form['no_of_cartons'])) {
																																																	echo 'value="' . $form['no_of_cartons'] . '"';
																																																}
																																																?>>

													</div>
												</div>
											</div> -->
											<!--<div class="col-md-3">
												<div class="control-group">
													<label class="example-text-input" for="transportation_po" required>Transportation PO# </label>
													<div class="controls">
														<input type="text" name="transportation_po" id="transportation_po" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?> <?php
																																																		if (isset($siv_transportation_po)) {
																																																			echo 'value="' . $siv_transportation_po . '"';
																																																		} else if (isset($form['transportation_po'])) {
																																																			echo 'value="' . $form['transportation_po'] . '"';
																																																		}
																																																		?>>

													</div>
												</div>
											</div> -->
											<!--<div class="col-md-3">
												<div class="control-group">
													<label class="example-text-input" for="siv_tracking_no" required>TCS Tracking Number </label>
													<div class="controls">
														<input type="text" name="siv_tracking_no" id="siv_tracking_no" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?> <?php
																																																	if (isset($siv_tracking_no)) {
																																																		echo 'value="' . $siv_tracking_no . '"';
																																																	} else if (isset($form['siv_tracking_no'])) {
																																																		echo 'value="' . $form['siv_tracking_no'] . '"';
																																																	}
																																																	?>>

													</div>
												</div>
											</div>-->
										</div>

										<div class="form-group row">
											
											<!--<div class="col-md-3">
												<div class="control-group">
													<label class="example-text-input" for="siv_name_of_transporter">Name of Transporter </label>
													<div class="controls">
														<input type="text" name="siv_name_of_transporter" id="siv_name_of_transporter" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?> <?php
																																																					if (isset($siv_name_of_transporter)) {
																																																						echo 'value="' . $siv_name_of_transporter . '"';
																																																					} else if (isset($form['siv_name_of_transporter'])) {
																																																						echo 'value="' . $form['siv_name_of_transporter'] . '"';
																																																					} else if (isset($siv_name_of_transporters_edit)) {
																																																						echo 'value="' . $siv_name_of_transporters_edit . '"';
																																																					}
																																																					?>>

													</div>
												</div>
											</div> -->
											<!--<div class="col-md-3">
												<div class="control-group">
													<label class="example-text-input" for="siv_vehicle_type">Vehicle Type </label>
													<div class="controls">
														<?php
														if ((empty($temp_records))) {
														?>
															<select name="siv_vehicle_type" id="siv_vehicle_type" class="select2me input-medium" required="" style="width:100%;padding:10%;">
																<option value="">Select</option>
																<?php
																if ($vehicle_type) {
																	//fetch result
																	foreach ($vehicle_type as $row) {
                  if($row['name'] == 'n/a'){continue;}
																		
																?>
																		<option value="<?php echo $row['name']; ?>" <?php if (isset($form['siv_vehicle_type']) && $form['siv_vehicle_type'] == $row['name']) {
																														echo "selected='selected'";
																													} else if (isset($siv_vehicle_type) && $siv_vehicle_type == $row['name']) {
																														echo "selected='selected'";
																													} ?>> <?php echo $row['name']; ?> </option>
																<?php
																	}
																}
																?>
															</select>
														<?php } else { ?>
															<select name="siv_vehicle_type" id="siv_vehicle_type" class="select2me input-medium" required="" style="width:100%;padding:10%;">
																<option value="">Select</option>
																<?php
																if ($vehicle_type) {
																	foreach ($vehicle_type as $row) {
																		
																?>
																		<option value="<?php echo $row['name']; ?>" <?php if (isset($form['siv_vehicle_type']) && $form['siv_vehicle_type'] == $row['name']) {
																														echo "selected='selected'";
																													} else if (isset($siv_vehicle_type) && $siv_vehicle_type == $row['name']) {
																														echo "selected='selected'";
																													} ?>> <?php echo $row['name']; ?> </option>
																<?php
																	}
																}
																?>
															</select>
														<?php } ?>
													</div>
												</div>
											</div> -->
											<!--<div class="col-md-3">
												<div class="control-group">
													<label class="example-text-input" for="siv_vehicle_plate_no">Vehicle Plate # </label>
													<div class="controls">
														<input type="text" name="siv_vehicle_plate_no" id="siv_vehicle_plate_no" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?> <?php
																																																				if (isset($siv_vehicle_plate_no)) {
																																																					echo 'value="' . $siv_vehicle_plate_no . '"';
																																																				} else if (isset($form['siv_vehicle_plate_no'])) {
																																																					echo 'value="' . $form['siv_vehicle_plate_no'] . '"';
																																																				} else if (isset($siv_vehicle_plate_no_edit)) {
																																																					echo 'value="' . $siv_vehicle_plate_no_edit . '"';
																																																				}
																																																				?>>

													</div>
												</div>
											</div> -->
										</div>

										
										<div class="form-group row">
           <div class="col-md-3">
            <div class="control-group">
             <label class="example-text-input" for="total_price" required>Total Price <span style="color: red">*</span> </label>
             <div class="controls">
              <input type="text" name="total_price" id="total_price" class="form-control" required="" readonly <?php
                                       if (isset($total_price)) {
                                        echo 'value="' . $total_price . '"';
                                       } else {
                                        echo 'value=""';
                                       }
                                       ?>>

             </div>
            </div>
           </div>
            
											<!--<div class="col-md-3">
												<div class="control-group">
													<label class="example-text-input" for="storage_info">Storage </label>
													<div class="controls">
													
														<select name="storage_info" id="storage_info" class="select2me input-medium" style="width:100%;padding:10%;">
															<option value="">Select</option>
															<?php foreach ($storage as $rowstorage) { ?>
																<option value="<?php echo $rowstorage['pk_id'] ?>"><?php echo $rowstorage['name'] ?></option>
															<?php } ?>
														</select>
													</div>
												</div>
											</div> 
											<input type="hidden" name="storage_id" id="storage_id" value="">-->


											
											
											<div class="col-md-3" id="show_expiry_date" style="display:none;">
												<div class="control-group">
													<label class="example-text-input" for="hf" required>Expiry Date <span style="color: red">*</span></label>
													<div class="controls">
														<input type="text" name="batch_expiry" id="batch_expiry" class="form-control" value="" readonly="true">
													</div>
												</div>
											</div>

											<div class="col-md-3" id="show_reorder_date" style="display:none;">
												<div class="control-group">
													<label class="example-text-input" for="reorder_date" required>Reorder Date <span style="color: red">*</span></label>
													<div class="controls">
														<input type="text" name="reorder_date" id="reorder_date" class="form-control" value="" readonly="true">
													</div>
												</div>
											</div>
											<div class="col-md-3">
												<div class="control-group">
													<label class="example-text-input" for="unit_price" required>Unit Price<span style="color: red">*</span> </label>
													<div class="controls">
														<input type="text" name="unit_price" id="unit_price" class="form-control" required="" readonly <?php
																																						if (isset($unit_price)) {
																																							echo 'value="' . $unit_price . '"';
																																						} else {
																																							echo 'value=""';
																																						}
																																						?>>

													</div>
												</div>
											</div>
           <div class="col-md-3">
            <div class="control-group">
             <label class="example-text-input" for="conversion_rate" required>Conversion Rate <span style="color: red">*</span> </label>
             <div class="controls">
              <input type="text" name="conversion_rate" id="conversion_rate" class="form-control" required="" readonly <?php if (isset($master_id) && !empty($master_id)) echo 'readonly="true"' ?> <?php
                                                      if (isset($conversion_rate)) {
                                                       echo 'value="' . $conversion_rate . '"';
                                                      } else {
                                                       echo 'value=""';
                                                      }
                                                      ?>>

             </div>
            </div>
           </div>							
					</div>

				  


          <div class="form-group row ">
          	 <?php if (!isset($master_id) && empty($master_id)){?>	
              <div class="col-md-3" >
            <label class="example-text-input" for="office" required>Office <span style="color: red">*</span></label>
            <div class="controls">
            <select class="select2me input-medium" name="office" id="office_change" class="office_change" style="width:100%;padding:10%;" <?php if (isset($master_id) && !empty($master_id)) echo 'disabled="true"' ?>>
              <option value="">Select</option>
              <?php
           

              foreach ($arrProv as $key =>$row) {
                  $selected_text = '';
               if (isset($form['office']) && $form['office'] == $key) {$selected_text = "selected='selected'";} 
               ?>
               <option value="<?php echo $key; ?>" <?php echo $selected_text;?> ><?php echo $row; ?></option>
              <?php } ?>
             </select>
            </div>
           </div> 
      
           <div class="col-md-3" id="province_div" <?php if(!isset($form['province']) && empty($form['province'])){?>style="display:none;" <?php }?> >
            <label class="example-text-input" for="province" required>Province <span style="color: red">*</span></label>
            <div class="controls">
             <select class="select2me input-medium" name="province" id="province_change_office" style="width:100%;padding:10%;" <?php if (isset($master_id) && !empty($master_id)) echo 'disabled="true"' ?> >
              <option value="">Select</option>
              <?php
              // $provinces = array(3 => "Khyber Pakhtunkhwa");

              foreach ($province as $row) {
                  if($row['PkLocID']  != $_SESSION['province_id']){
                    continue;
                  }
              ?>
               <option value="<?php echo $row['PkLocID'] ?>" <?php if (isset($form['province']) && $form['province'] == $row['PkLocID']) {
                            echo "selected='selected'";
                           } ?>><?php echo $row['LocName'] ?></option>
              <?php
              }
              ?>
             </select>
            </div>
           </div>      
           <div class="col-md-3" id="district_div" <?php if(!isset($form['province']) && empty($form['province'])){?>style="display:none;" <?php }?>>
            <label class="example-text-input" for="district_village" required>District<span style="color: red">*</span> </label>
            <div class="controls">
             <select class="select2me input-medium" name="district" id="district_change_office" style="width:100%;padding:10%;" <?php if (isset($master_id) && !empty($master_id)) echo 'disabled="true"' ?>>
              <option value="">Select</option>
              <?php
              if (isset($districts)) {
               $dist_arr = $districts->result_array();
               foreach ($dist_arr as $row) {
              ?>
                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($district_id) && $district_id == $row['pk_id']) echo 'selected="selected"' ?>><?php echo $row['loc_name'] ?></option>
              <?php
               }
              }
              ?>
             </select>
            </div>
           </div>
              <?php } ?>
           <div class="col-md-3">
            <label class="example-text-input" required>Issue to Center<span style="color: red">*</span> </label>
            <div class="controls">
             <?php
             if ((empty($temp_records))) {?>
              <select class="select2me input-medium" name="center_patient" id="center_patient" required style="width:100%;padding:10%;" <?php if (isset($master_id) && !empty($master_id)) echo 'disabled="true"' ?> >
               <option value="">Select</option>
               <?php foreach ($warehouse as $row) {
                //                                                                    if($row['wh_id'] == $this->session->userdata('warehouse_id')) continue;
               ?>
                <option value="<?php echo $row['wh_id'] ?>" <?php if (isset($form['center_patient']) && $form['center_patient'] == $row['wh_id']) {
                 echo "selected='selected'";
                } else if (isset($WHIDTo) && $WHIDTo == $row['wh_id']) {
                 echo "selected='selected'";
                } ?>><?php if (isset($row['warehouse_name'])){echo $row['warehouse_name'];}elseif(isset($row['wh_name'])){echo $row['wh_name'];} ?></option>
               <?php } ?>
              </select>
             <?php } else {
             ?>

              <select  class="select2me input-medium" name="center_patient" id="center_patient" required style="width:100%;padding:10%;" <?php if (isset($master_id) && !empty($master_id)) echo 'disabled="true"' ?>>
               <!--<option value="">Select</option>-->
               <?php foreach ($warehouse as $row) {
                //                                                                    if($row['wh_id'] == $this->session->userdata('warehouse_id')) continue;
               ?>
                <option value="<?php echo $row['wh_id'] ?>" <?php if (isset($form['center_patient']) && $form['center_patient'] == $row['wh_id']) {
                            echo "selected='selected'";
                           } else if (isset($WHIDTo) && $WHIDTo == $row['wh_id']) {
                            echo "selected='selected'";
                           } ?>><?php if (isset($row['warehouse_name'])){echo $row['warehouse_name'];}elseif(isset($row['wh_name'])){echo $row['wh_name'];} ?></option>
               <?php } ?>
              </select>

             <?php
             }
             ?>
            </div>
           </div>
          </div>
          
										<div class="form-group row">
											<div class="col-md-3">
            <div class="control-group">
             <label class="example-text-input" for="siv_mode_of_transport">Mode of Transport </label>
             <div class="controls">
              <?php
              if ((empty($temp_records))) {
              ?>
               <select name="siv_mode_of_transport" id="siv_mode_of_transport" class="select2me input-medium" required="" style="width:100%;padding:10%;" <option value="">Select</option>
                <option value="Airways" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Airways') {
                       echo "selected='selected'";
                      } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Airways') {
                       echo "selected='selected'";
                      } ?>>Airways</option>
                <option value="Railways" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Railways') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Railways') {
                        echo "selected='selected'";
                       } ?>>Railways</option>
                <option value="Roadways" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Roadways') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Roadways') {
                        echo "selected='selected'";
                       } ?>>Roadways</option>
                <option value="Waterways" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Waterways') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Waterways') {
                        echo "selected='selected'";
                       } ?>>Waterways</option>
                <option value="Pipelines" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Pipelines') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Pipelines') {
                        echo "selected='selected'";
                       } ?>>Pipelines</option>
                <option value="Official Vehicle" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Official Vehicle') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Official Vehicle') {
                        echo "selected='selected'";
                       } ?>>Official Vehicle</option>
                <option value="Courier service" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Courier service') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Courier service') {
                        echo "selected='selected'";
                       } ?>>Courier service</option>
                <option value="Goods Forwarding Agency" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Goods Forwarding Agency') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Goods Forwarding Agency') {
                        echo "selected='selected'";
                       } ?>>Goods Forwarding Agency</option>       
                                     
                        <option value="Self" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Self') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Self') {
                        echo "selected='selected'";
                       } ?>>Self</option>
               </select>
              <?php } else { ?>
               <select name="siv_mode_of_transport" id="siv_mode_of_transport" disabled class="select2me input-medium" required="" style="width:100%;padding:10%;">
                <option value="">Select</option>
                <option value="Airways" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Airways') {
                       echo "selected='selected'";
                      } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Airways') {
                       echo "selected='selected'";
                      } ?>>Airways</option>
                <option value="Railways" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Railways') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Railways') {
                        echo "selected='selected'";
                       } ?>>Railways</option>
                <option value="Roadways" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Roadways') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Roadways') {
                        echo "selected='selected'";
                       } ?>>Roadways</option>
                <option value="Waterways" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Waterways') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Waterways') {
                        echo "selected='selected'";
                       } ?>>Waterways</option>
                <option value="Pipelines" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Pipelines') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Pipelines') {
                        echo "selected='selected'";
                       } ?>>Pipelines</option>
                       <option value="Official Vehicle" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Official Vehicle') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Official Vehicle') {
                        echo "selected='selected'";
                       } ?>>Official Vehicle</option>
                <option value="Courier service" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Courier service') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Courier service') {
                        echo "selected='selected'";
                       } ?>>Courier service</option>
                <option value="Goods Forwarding Agency" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Goods Forwarding Agency') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Goods Forwarding Agency') {
                        echo "selected='selected'";
                       } ?>>Goods Forwarding Agency</option>       
                                     
                        <option value="Self" <?php if (isset($form['siv_mode_of_transport']) && $form['siv_mode_of_transport'] == 'Self') {
                        echo "selected='selected'";
                       } else if (isset($siv_mode_of_transport) && $siv_mode_of_transport == 'Self') {
                        echo "selected='selected'";
                       } ?>>Self</option>
               </select>
              <?php } ?>
              <input type="hidden" name="transport_selected_mode" value="<?php if (isset($siv_mode_of_transport)) {echo $siv_mode_of_transport;} ?>" >
             </div>
            </div>
           </div>
											
											
											<div class="col-md-3">
												<div class="control-group">
													<label class="example-text-input" for="fileToUploads">Select File to upload:</label>
													<div class="controls">
														<input type="file" name="fileToUpload">
													</div>
												</div>
											</div>
											<div class="col-md-3">
												<div class="control-group">
													<label class="example-text-input" for="hf" required>Remarks</label>
													<div class="controls">
														<textarea name="remarks" id="remarks" class="form-control" <?php
																													if (isset($ReceivedRemarks)) {
																														echo 'value="' . $ReceivedRemarks . '"';
																													}
																													?>></textarea>
													</div>
												</div>
											</div>																													
										</div>
           <div class="form-group row transport_mode_div">
             <?php if(!empty($siv_mode_of_transport) && $siv_mode_of_transport=='Official Vehicle'){ ?>
                 <div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_name" required>Driver Name </label><div class="controls"> <input type="text" name="driver_names" id="driver_names" class="form-control" value="<?php echo $driver_names?>" ></div></div></div>
                 <div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_name" required>  CNIC </label><div class="controls"> <input type="text" name="driver_cnic" id="driver_cnic" maxlength="13" class="form-control" value="<?php echo $driver_cnic?>" ></div></div></div>
                 <div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_name" required> Contact</label><div class="controls"> <input type="text" name="driver_contact" id="driver_contact" class="form-control" value="<?php echo $driver_contact?>" ></div></div></div><div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_name" required> Vehicle # </label><div class="controls"> <input type="text" name="driver_vehicle" id="driver_vehicle" class="form-control" value="<?php echo $driver_vehicle?>" ></div></div></div>

             <?php }else if(!empty($siv_mode_of_transport) && $siv_mode_of_transport=='Goods Forwarding Agency'){?>
                 <div class="col-md-3"><div class="control-group"><label class="example-text-input" for="agency_name" required> Agency Name  </label><div class="controls"> <input type="text" name="agency_name" id="agency_name" class="form-control" value="<?php echo $agency_name?>" ></div></div></div>
                 
                 <div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_reference" required>  Reference</label><div class="controls"> <input type="text" name="driver_reference" id="driver_reference" class="form-control" value="<?php echo $driver_reference?>" ></div></div></div>
             <?php }if(!empty($siv_mode_of_transport) && $siv_mode_of_transport=='Self'){ ?>
                 <div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_name" required> Name </label><div class="controls"> <input type="text" name="driver_names" id="driver_names" class="form-control" value="<?php echo $driver_names?>" ></div></div></div>
                 <div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_designation" required>  Designations </label><div class="controls"> <input type="text" name="driver_designation" id="driver_designation" maxlength="13" class="form-control" value="<?php echo $driver_designation?>" ></div></div></div>
                 <div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_name" required>  CNIC </label><div class="controls"> <input type="text" name="driver_cnic" id="driver_cnic" maxlength="13" class="form-control" value="<?php echo $driver_cnic?>" ></div></div></div>
                 <div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_name" required> Contact</label><div class="controls"> <input type="text" name="driver_contact" id="driver_contact" class="form-control" value="<?php echo $driver_contact?>" ></div></div></div><div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_name" required> Vehicle # </label><div class="controls"> <input type="text" name="driver_vehicle" id="driver_vehicle" class="form-control" value="<?php echo $driver_vehicle?>" ></div></div></div>

              <?php }if(!empty($siv_mode_of_transport) && $siv_mode_of_transport=='Courier service'){ ?>
                  <div class="col-md-3"><div class="control-group"><label class="example-text-input" for="service_name" required>Service Name </label><div class="controls"> <input type="text" name="service_name" id="service_name" class="form-control" value="<?php echo $service_name?>" ></div></div></div>
                
                 <div class="col-md-3"><div class="control-group"><label class="example-text-input" for="consignment_no" required>   Consignment No </label><div class="controls"> <input type="text" name="consignment_no" id="consignment_no" class="form-control" value="<?php echo $consignment_no?>" ></div></div></div>

             <?php } ?>


           </div>

										<div class="form-group row">
										
											

											
												
											
										</div>

										<div id="issue_batch_details">

										</div>

										<div class="form-group row">
											<div class="col-md-10">
											</div>
											<div class="col-md-2">
												<input type="hidden" name="produstbatchid" id="produstbatchid" value="">
												<input type="hidden" name="pkdetailid" id="pkdetailid" value="<?php if (isset($pkdetailid)) echo $pkdetailid; ?>">
												<input type="hidden" name="pkmasterid" id="pkmasterid" value="<?php if (isset($pkmasterid)) echo $pkmasterid; ?>">
												<button type="submit" id="wh_btn" name="wh_btn" class="btn btn-success waves-effect waves-light"> Add Issue</button>
												<input type="hidden" name="actual_rec_qty" id="actual_rec_qty" value="">
												<?php if (isset($editbatch_id) && !empty($editbatch_id)) { ?>
													<input type="hidden" name="editbatchid" id="editbatchid" value="<?php if (isset($editbatch_id)) {
																														echo $editbatch_id;
																													} else {
																														echo '';
																													} ?>">
												<?php } ?>

												<input type="hidden" name="prod_field1" id="prod_field1" value="">
            <input type="hidden" name="selected_office" id="selected_office" value="<?php echo $form['office']?>">
            <input type="hidden" name="selected_province" id="selected_province" value="<?php echo $form['province']?>">
            <input type="hidden" name="selected_district" id="selected_district" value="<?php echo $form['district']?>">
            <input type="hidden" name="selected_issue_center" id="selected_issue_center" value="<?php echo $form['center_patient']?>">
												<input type="hidden" name="prod_field2" id="prod_field2" value="">
												<input type="hidden" name="prod_field3" id="prod_field3" value="">
												<input type="hidden" name="prod_field4" id="prod_field4" value="">
												<input type="hidden" name="prod_field5" id="prod_field5" value="">
												<input type="hidden" name="prod_field6" id="prod_field6" value="">
												<input type="hidden" name="prod_field7" id="prod_field7" value="">
												<input type="hidden" name="prod_field8" id="prod_field8" value="">
												<input type="hidden" name="prod_field9" id="prod_field9" value="">
												<input type="hidden" name="prod_field10" id="prod_field10" value="">

												<input type='hidden' name='p_wh_id_from_supplier' id='wh_id_from_supplier' value=''>
												<input type='hidden' name='p_wh_id_from' id='wh_id_from' value=''>

												<input type="hidden" name="p_dc_quantity" id="dc_quantity" value="">
												<input type="hidden" name="p_pi_quantity" id="pi_quantity" value="">
												<!--<input type="hidden" name="pi_comment" id="pi_comment" value="">-->
												<!--<input type="hidden" name="ti_comment" id="ti_comment" value="">-->
												<input type="hidden" name="p_ti_quantity" id="ti_quantity" value="">
												<input type="hidden" name="p_delivery_challan_type" id="delivery_challan_type" value="">
												<input type="hidden" name="p_challan_type_detail" id="challan_type_detail" value="">
												<input type="hidden" name="p_driver_name" id="driver_name" value="">
												<input type="hidden" name="p_driver_contract" id="driver_contract" value="">
												<input type="hidden" name="p_vehicle_reg" id="vehicle_reg" value="">
												<input type="hidden" name="p_dc_no" id="dc_no" value="">
												<input type="hidden" name="p_dc_date" id="dc_date" value="">
												<input type="hidden" name="p_invoice" id="invoice" value="">
												<input type="hidden" name="p_po_quantity" id="po_quantity" value="">
												<!--<input type="hidden" name="gwis_adj_status" id="gwis_adj_status" value="">-->
												<input type="hidden" name="p_grn_quantity" id="grn_quantity" value="">

												<input type="hidden" id="stk_id" name='p_stk_id' value="" />

												<input type="hidden" id="inspection_date" name='p_inspection_date' value="" />
												<input type="hidden" id="delivery_location" name='p_delivery_location' value="" />
												<input type="hidden" id="po_cmu_no" name='p_po_cmu_no' value="" />
												<input type="hidden" id="po_cmu_date" name='p_po_cmu_date' value="" />
												<input type="hidden" id="po_gf_no" name='p_po_gf_no' value="" />
												<input type="hidden" id="po_gf_date" name='p_po_gf_date' value="" />
												<input type="hidden" id="date_of_receiving" name='p_date_of_receiving' value="" />
												<input type="hidden" id="air_bill_no" name='p_air_bill_no' value="" />
												<input type="hidden" id="shipment_no" name='p_shipment_no' value="" />
												<input type="hidden" id="origin_of_country" name='p_origin_of_country' value="" />
												<input type="hidden" id="vehicle_type_and_plate" name='p_vehicle_type_and_plate' value="" />
												<input type="hidden" id="consignment_weight" name='p_consignment_weight' value="" />

												<!--                                                    <input type="hidden" name="giv_quantity" id="giv_quantity" value="">
                                                    <input type="hidden" name="temperature_requirement" id="temperature_requirement" value="">-->

											</div>

											<?php if ((isset($_REQUEST['pkmasteridedit']) && !empty($_REQUEST['pkmasteridedit'])) || (isset($pkmasteridedit) && !empty($pkmasteridedit))) { ?>

												<input type="hidden" name="vouchertno" id="vouchertno" value="<?php if (isset($_REQUEST['vouchertno']) && !empty($_REQUEST['vouchertno'])) {
																													echo $_REQUEST['vouchertno'];
																												} else {
																													echo $vouchertno;
																												} ?>">
												<input type="hidden" name="pkmasteridedit" id="pkmasteridedit" value="<?php if (isset($_REQUEST['pkmasteridedit']) && !empty($_REQUEST['pkmasteridedit'])) {
																															echo $_REQUEST['pkmasteridedit'];
																														} else {
																															echo $pkmasteridedit;
																														} ?>">
												<input type="hidden" name="edit" id="edit" value="<?php if (isset($_REQUEST['edit']) && !empty($_REQUEST['edit'])) {
																										echo $_REQUEST['edit'];
																									} else {
																										echo $edit;
																									} ?>">

											<?php } ?>

											<?php if (isset($temp_records) && (!empty($temp_records))) {
											?>
												<input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>">
											<?php }
											?>
											<input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

										</div>
									</div>
								</div>
							</div>


							<br>
							<div style="overflow-x:auto;width:100%;">
								<?php
								if (isset($temp_records) && (!empty($temp_records)) || (isset($_REQUEST['edit']) && !empty($_REQUEST['edit'])) || (isset($edit) && !empty($edit))) {
								?>

									<div id="divToPrint">
										<table class="table table-striped table-bordered table-condensed dt-responsive ">
											<thead>
												<tr>
													<th style="width: 1%;" class="center">No.</th>
													<th>Voucher Number</th>
													<th>Product Name</th>
													<!--<th>Manufacturer</th>-->
													<?php
													$sr = 0;
													//                                                foreach ($temp_records->result_array() as $row) {
													//                                                if($row['product_type'] == '36' && $sr == 0) {
													?>
													<th>Batch#</th>
													<th>Mfg Date</th>
													<th>Exp. Date</th>
													<th>Serial No</th>
													<!--<th>Warranty (years)</th>-->
													<th>Pack Size</th>
													<!--<th>Unit</th>-->
													<!--                                                <th>Temp From</th>
                                                <th>Temp to</th>-->
													<?php // $sr++; }
													//                                                }
													?>
													<!--<th>Funding Source</th>-->
													<th>Batch Quantity</th>
													<th>Issue Quantity</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody>
												<!-- Table row -->
												<?php
												//print_r($temp_records->result_array());exit;
												$count = 1;
												foreach ($temp_records->result_array() as $row) {
												?>
													<tr>
														<td class="center"><?php echo $count; ?></td>
														<td><?php echo $row['tran_no']; ?></td>
														<td><?php echo $row['product_name']; ?></td>
														<!--<td class="important"><?php echo $row['manufacturer']; ?></td>-->
														<?php // if($row['product_type'] == '36') { 
														?>
														<td><?php echo $row['batch_no']; ?></td>
														<td><?php echo $row['field2']; ?></td>
														<td class="important"><?php echo $row['batch_expiry']; ?></td>
														<td><?php echo $row['field4']; ?></td>
														<!--<td><?php echo $row['field5']; ?></td>-->
														<!--<td><?php echo $row['field6']; ?></td>-->
														<td><?php echo $row['pack_size']; ?></td>
														<!--<td><?php echo $row['field7']; ?></td>-->
														<!--                                                    <td><?php echo $row['field8']; ?></td> 
                                                    <td><?php echo $row['field9']; ?></td> -->
														<?php
														//                                                        }
														?>
														<!-- <td class="important"><?php echo $row['stkname']; ?></td>-->
														<td class="important"><?php echo $row['Qty']; ?></td>
														<td class="important"><?php echo $row['quantity']; ?></td>
														<td>
															<button class="btn btn-danger btn-sm" type="button" id="<?php echo $row['pk_id'] . "_" . $row['fk_stock_id'] . "_" . $row['batch_id'] . "_" . $row['quantity']; ?>-deletegsi">
																<span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Delete
															</button>
															<!--<a onclick="return confirm('Are you sure you want to Delete?');" href="<?php echo base_url("inventory_management/delete?id=") . $row['pk_id']; ?>&status=1" class="btn btn-sm btn-light glyphicons bin" > Delete</a>-->
														</td>
														<!--                                                <td>  
                                                                    <a onclick="return confirm('Are you sure you want to Delete?');" href="<?php echo base_url("product_management/deactivate?id=") . $row['pk_id']; ?>&status=1" class="btn btn-sm btn-light glyphicons bin" > Delete</a>
                                                                </td> -->
													</tr>
												<?php
													$count++;
												}
												?>
												<!-- // Table row END -->
												<!-- Table row -->

												<!-- // Table row END -->
											</tbody>
										</table>
									</div>
									<button type="button" id="save_temp_issue" name="save_temp_issue" class="btn btn-success waves-effect waves-light" style="margin-left:90%;">Save</button>

									<!-- // Table END -->
								<?php
								}
								?>
							</div>
						</form>
					</div>
				</div>
			</div>

		</div>
	</div>
	<!-- end row -->
</div>
</div>
