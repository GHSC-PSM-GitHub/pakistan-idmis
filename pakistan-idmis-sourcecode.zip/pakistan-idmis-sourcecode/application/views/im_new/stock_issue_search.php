<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Stock Issue Search</h3>
                         
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                     <div class="innerLR">
                           <form method="POST" name="dc_search" action="stock_issue_search" >
                            <!-- Row -->
                            <div class="col-md-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="form-group row ">
                                            <!--<div class="col-md-12">-->

                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="example-text-input" for="start_date"  >Date From(DD/MM/YYYY) <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="start_date" id="start_date" required="" value="<?php if (isset($_REQUEST['start_date']) && !empty($_REQUEST['start_date'])) {
    echo $_REQUEST['start_date'];
} else {
    echo date("d/m/Y");
} ?>" >

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="example-text-input" for="end_date"  >Date To(DD/MM/YYYY) <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="end_date" id="end_date" required=""  value="<?php if (isset($_REQUEST['end_date']) && !empty($_REQUEST['end_date'])) {
    echo $_REQUEST['end_date'];
} else {
    echo date("d/m/Y");
} ?>" >

                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3" id="show_receive_from_suppliers" >
                                                <label class="example-text-input" for="suppliers"  >Received From (Supplier) </label>
                                                <div class="controls">
                                                        <?php
//                                            if (empty($temp_records)) {
                                                        ?>
                                                    <select class="select2me input-medium"  name="receive_from_suppliers" id="receive_from_suppliers" style="width:100%;padding:10%;">
                                                        <option value="">Select</option>
                                                        <?php
                                                        foreach ($suppliers as $row) {
                                                            ?>
                                                            <option value="<?php echo $row['wh_id'] ?>" <?php if (isset($_REQUEST['receive_from_suppliers']) && $_REQUEST['receive_from_suppliers'] == $row['wh_id']) echo "selected='selected'"; ?>><?php echo $row['wh_name'] ?></option>
                                                        <?php
                                                    }
                                                    ?>

                                                    </select>  
                                                    <?php
//                                            }else
//                                            {
//                                                foreach ($suppliers as $row) {
////                                                                if(isset($warehouse_from) && $warehouse_from == $row['stkid']) echo  '<input class="form-control" disabled value="'.$row['stkname'].'">';
//                                                    if(isset($warehouse_from_supplier) && $warehouse_from_supplier == $row['wh_id']) { echo  '<input class="form-control" disabled value="'.$row['wh_name'].'">';   } 
//                                                    else if (isset($gwis_supplier) && $gwis_supplier == $row['wh_id']){ echo '<input class="form-control" disabled value="'.$row['wh_name'].'">'; } 
//
//                                                }
//                                            }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <label class="example-text-input" required >Stakeholder </label>
                                                <div class="controls">
                                                    <select class="select2me input-medium" name="stakeholder" id="stakeholder"  style="width:100%;padding:10%;">
                                                        <option value="">Select</option>
                                                        <?php
                                                        foreach ($stakeholder as $row) {
                                                            ?>
                                                            <option value="<?php echo $row['stkid'] ?>" <?php if (isset($form['stakeholder']) && $form['stakeholder'] == $row['stkid']) echo "selected='selected'"; ?>><?php echo $row['stkname'] ?></option>
    <?php
}
?>
                                                    </select>  
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-3">
                                                <label class="example-text-input" required >Issue To</label>
                                                <div class="controls">
                                                    <select class="select2me input-medium" name="warehouse" id="warehouse"  style="width:100%;padding:10%;">
                                                        <option value="">Select</option>
                                                        <?php
                                                        foreach ($warehouse as $row) {
                                                            ?>
                                                            <option value="<?php echo $row['wh_id'] ?>" <?php if (isset($form['warehouse']) && $form['warehouse'] == $row['wh_id']) echo "selected='selected'"; ?>><?php echo $row['warehouse_name'] ?></option>
    <?php
}
?>
                                                    </select>  
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <div class="input-group input-medium" style="margin-top: 21px;float: right;">
                                                        <div class="controls">
                                                            <button type="submit" class="btn btn-primary" name="submit" value="Search"> Search </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <br>
                        <?php
                        if ( !empty($result)) {
                            ?>

                            <div id="divToPrint">
                                <table class="table table-striped table-bordered table-condensed dt-responsive nowrap" id="datatable-buttons">
                                    <thead>
                                        <tr>
                                            <th style="width: 1%;" class="center">No.</th>
                                            <th>Transaction Number</th>
<!--                                            <th>Reference Number</th>-->
                                            <th>Issued To</th>
                                            <th>Issuance Date</th>
<!--                                            <th>Funding Source</th>-->
                                            <th>Product Name</th>   
                                            <th>Batch Number</th>
<!--                                            <th>Expiry Date</th> -->
                                            <th>Quantity</th> 
                                            <th>Action</th> 
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Table row -->
                                        <?php
                                        $count = 1; 
                                        foreach ($result->result_array() as $row) {
//                                            echo '<pre>';
//                                            print_r($row);
//                                            echo '</pre>';
//                                            exit;
                                            ?>
                                            <tr>
                                                <td class="center"><?php echo $count; ?></td>
                                                <td class="important"><?php echo "I-".sprintf('%04d', $row['pk_id']); ?></td>
<!--                                                <td class="important"><?php echo $row['transaction_reference']; ?></td>-->
                                                <td class="important"><?php if($row['issuance_to']=='centers') echo ($row['wh_name']); else echo $row['full_name']."-".$row['nic_no']; ?></td>
                                                <td class="important"><?php echo $row['tran_date']; ?></td> 
<!--                                                <td class="important"><?php echo $row['funding_source_name']; ?></td>-->
                                                <td><?php echo $row['product_name']; ?></td>  
                                                <td class="important"><?php echo $row['batch_no']; ?></td>
<!--                                                <td class="important"><?php echo $row['batch_expiry']; ?></td> -->
                                                <td class="important"><?php echo $row['quantity']; ?></td> 
                                                <td>
                                                <?php
                                                
                                                    if($this->session->userdata('id')==$row['created_by']){
                                                        echo '<a class="btn btn-secondary btn-sm" href="'.base_url('inventory_management/del_stock_detail/'.$row['pk_id']).'"  onclick="return confirm(\'This action will delete data of this transaction. Deletion is not reversible.\')"> Delete</a>';
                                                    }
                                                ?>
                                                </td>
                                              
                                            </tr>
                                            <?php
                                            $count++;
                                        }
                                        ?>
                                        <!-- // Table row END -->
                                        <!-- Table row -->

                                        <!-- // Table row END -->
                                    </tbody>
                                </table> 
                            </div>

                            <!-- // Table END -->
                            <?php
                        } else {
                            echo "<hr><h5>No data found!</h5>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
