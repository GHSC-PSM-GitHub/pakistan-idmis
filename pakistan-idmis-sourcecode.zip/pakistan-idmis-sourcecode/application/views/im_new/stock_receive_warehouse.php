<?php
//print_r($_SESSION);exit;
//echo '<pre>';
//print_r($stockReceive); exit;
?>

<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Stock Receive Warehouse</h3>

                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                    <div class="innerLR">

                        <form method="POST" name="dc_searchs" action="<?php echo base_url(); ?>Im_new/stock_receive_wh" >
                            <!-- Row -->
                            <div class="col-md-12">
                                <div class="card m-b-30">
                                    <div class="card-body">

                                        <div class="form-group row"> 

                                            <div class="col-md-3">
                                                <label class="example-text-input" required >Issue Number</label>
                                                <div class="controls">

                                                    <input type="text" class="form-control" name="search_voucher_no" id="search_voucher_no">
                                                  Pending Vouchers are :   <?php
                                                    if (!empty($voucher_no_wh)) {
                                                        
                                                        foreach ($voucher_no_wh as $k => $val) {
                                                            $url_1 = base_url('im_new/stock_receive_wh/' . $voucher_no_wh[$k]['tran_no']);
                                                            ?>

                                                           <a onclick="window.open('<?php echo $url_1; ?>', '_self')" style="text-decoration: underline; color:red;" class="alert-link" ><?php echo $voucher_no_wh[$k]['tran_no']; ?></a> ,
        <?php
    }
}
?>

                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="control-group">
                                                    <div class="input-group input-medium" style="margin-top: 21px;">
                                                        <div class="controls">
                                                            <input type="submit" name="search_wh" id="search_wh" class="form-control btn-primary btn-sm" value="Search">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div> 


                                        </div>
                                        

                                    </div>
                                </div>
                            </div>
                        </form>

                        <br>

                    </div>

                    <div class="innerLR">
<?php if (!empty($stockReceive)) { ?>
                            <form method="POST" action="<?php echo base_url(); ?>Im_new/stock_receive_wh">
                                <!-- Row -->
                                <div class="col-md-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">

                                            <div class="form-group row"> 
                                                <table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable" border="1">

                                                    <!-- Table heading -->
                                                    <thead>
                                                        <tr>
                                                            <th> Product </th>
                                                            <th> Batch </th>
                                                            <th> Quantity </th>
                                                            <th> Adjusted Qty </th>
                                                            <th> Adjustment Type</th>
                                                            <th style="width: 1%;"> <input type="checkbox" id="checkAll" /></th>
                                                        </tr>
                                                    </thead>
                                                    <!-- // Table heading END --> 

                                                    <!-- Table body -->
                                                    <tbody>
                                                        <!-- Table row -->
    <?php
    $i = 1;
    foreach ($stockReceive as $k => $value) {
        $stockID = $stockReceive[$k]['fk_stock_id'];
        $issuance_date = $stockReceive[$k]['tran_date'];
//                                                print_r($stockReceive);exit;
//                                                echo $stockReceive[$k]['PkDetailID']; exit;
        ?>
                                                            <tr>
                                                                <td><?php echo $stockReceive[$k]['itm_name']; ?></td>
                                                                  <input type="hidden" name="product[<?php echo $stockReceive[$k]['PkDetailID']; ?>]" id="<?php echo $i; ?>-product" value="<?php echo $stockReceive[$k]['itm_name']; ?>"  />
                                                        <input type="hidden" name="refernce_number" value="<?php echo $stockReceive[$k]['fk_stock_id']; ?>"/>
                                                        <td><?php echo $stockReceive[$k]['batch_no']; ?></td>
                                                        <input type="hidden" name="batch[<?php echo $stockReceive[$k]['PkDetailID']; ?>]" id="<?php echo $i; ?>-batch" value="<?php echo $stockReceive[$k]['batch_id']; ?>"  />
                                                          <input type="hidden" name="batchno[<?php echo $stockReceive[$k]['PkDetailID']; ?>]" id="<?php echo $i; ?>-batchno" value="<?php echo $stockReceive[$k]['batch_no']; ?>"  />
                                                        <td class="right"><?php echo abs($stockReceive[$k]['Qty']); ?>
                                                             <input type="hidden" name="quantity[<?php echo $stockReceive[$k]['PkDetailID']; ?>]" id="<?php echo $i; ?>-quantity" value="<?php echo abs($stockReceive[$k]['Qty']); ?>"  />
                                                            <input type="hidden" id="<?php echo $i; ?>-qty" value="<?php echo abs($stockReceive[$k]['Qty']); ?>" /></td>
                                                        <td class="col-md-3"><input type="number" name="missing[<?php echo $stockReceive[$k]['PkDetailID']; ?>]" id="<?php echo $i; ?>-missing" value="" min="0" class="form-control input-sm input-small" /></td>
                                                        <td class="col-md-3">
                                                            <select name="types[<?php echo $stockReceive[$k]['PkDetailID']; ?>]" id="<?php echo $i; ?>-types" class="form-control input-sm input-small types_select">
        <?php
        if (!empty($types)) {

            foreach ($types as $kk => $valll) {

                echo "<option value=" . $types[$kk]['trans_id'] . ">" . $types[$kk]['trans_type'] . "</option>";
            }
        }
        ?>
                                                            </select></td>
                                                        <td class="center"><input type="checkbox" name="stockid[<?php echo $stockReceive[$k]['PkDetailID']; ?>]" value="<?php echo $stockReceive[$k]['PkDetailID']; ?>" /></td>
                                                        </tr>
                                                                <?php
                                                                $i++;
                                                            }
                                                            ?>
                                                    <tr> <td>Remarks:<textarea class="form-control" id="remarks" name="remarks" rows="3" cols="10"></textarea></td>
                                                        <td>Receive Date:<input type="date" class="form-control" id="rcv_date" name="rcv_date" value="<?php echo date("Y-m-d"); ?>" required/></td>
                                                    <!--<td></td>-->
                                                    <td><input type="submit" name="rcv_save" class="form-control btn-success btn-sm" value="Save"/></td></tr>
                                                    <!-- // Table row END -->
                                                    </tbody>
                                                    <!-- // Table body END -->
                                                </table>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </form>
<?php } ?>
                        <br>

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>        
<script>
    $("#rcv_date").datepicker({
        minDate: "<?=date('Y-m-d',strtotime($issuance_date))?>",
        maxDate: 0,
        dateFormat: 'dd/mm/yy'
    });
</script>