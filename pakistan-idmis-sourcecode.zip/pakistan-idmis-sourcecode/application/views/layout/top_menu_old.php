<!-- MENU Start -->
<div class="navbar-custom">
    <div class="container-fluid">
        <div id="navigation">

            <?php
//            print_r($_SESSION);exit;
            $userid = $_SESSION['id'];
                
                $sql ="SELECT
                            GROUP_CONCAT( role_resources.permission ) AS permission,
                            GROUP_CONCAT( role_resources.role_id ) AS role_id,
                            GROUP_CONCAT( role_resources.resource_id ) AS resource_id,
                            GROUP_CONCAT( role_resources.is_default ) AS is_default,
                            GROUP_CONCAT( role_resources.rank ) AS rank,
                            GROUP_CONCAT( resources.resource_name ) AS resource_name,
                            GROUP_CONCAT( resources.page_title ) AS page_title,
                            GROUP_CONCAT( resources.description ) AS description,
                            GROUP_CONCAT( resources.parent_id ) AS parent_id,
                            GROUP_CONCAT( resources.resource_type_id ) AS resource_type_id,
                            GROUP_CONCAT( roles.role_name ) AS role_name,
                            GROUP_CONCAT( roles.role_level ) AS role_level_id 
                    FROM
                            roles
                            INNER JOIN role_resources ON roles.pk_id = role_resources.role_id
                            INNER JOIN resources ON role_resources.resource_id = resources.pk_id
                            INNER JOIN users ON roles.pk_id = users.role_id 
                    WHERE
                            users.pk_id = '".$userid."' 
                        ";
                $resources_code = $this->db->query($sql);
                if ($resources_code->num_rows() > 0) {
//                            if ($approval_code) {
                               //fetch results
                               foreach ($resources_code->result() AS $row)
                               {
                                   $permission = preg_split ("/\,/", $row->permission);  
                                   $role_id = preg_split ("/\,/", $row->role_id);  
                                   $resource_id = preg_split ("/\,/", $row->resource_id);  
                                   $is_default = preg_split ("/\,/", $row->is_default);  
                                   $rank = preg_split ("/\,/", $row->rank); 
                                   $resource_name = preg_split ("/\,/", $row->resource_name); 
                                   $page_title = preg_split ("/\,/", $row->page_title);
                                   $description = preg_split ("/\,/", $row->description);
                                   $parent_id = preg_split ("/\,/", $row->parent_id);
                                   $resource_type_id = preg_split ("/\,/", $row->resource_type_id); 
                                   $role_name = preg_split ("/\,/", $row->role_name);
                                   $role_level_id = preg_split ("/\,/", $row->role_level_id); 
//                                   $approvalcount = count($approval_codess);
//                                   print_r($role_id);exit;
                               }
//                            }
                }
                
                
                
                $qry1 = "SELECT
                                resources.*,
                                role_resources.rank AS role_resource_rank 
                        FROM
                                resources
                                INNER JOIN role_resources ON resources.pk_id = role_resources.resource_id
                                INNER JOIN roles ON roles.pk_id = role_resources.role_id
                                INNER JOIN users ON roles.pk_id = users.role_id 
                        WHERE
                                resources.parent_id = 0
                                AND users.pk_id = '".$userid."'
                        ORDER BY
                                role_resources.rank ASC";
//                echo $qry1;exit;
                $maininfo = $this->db->query($qry1);
                
                
//                echo '<pre>';
//                var_dump($maininfo->result());die;
                ?> 
                <ul class="navigation-menu">
                <?php 
                foreach ($maininfo->result() AS $row1)
                { 
                    $qry2 = "SELECT
                                    resources.pk_id,
                                    resources.resource_name,
                                    resources.description,
                                    resources.page_title,
                                    resources.`level`,
                                    resources.parent_id,
                                    resources.resource_type_id,
                                    resources.icon_class,
                                    resources.created_by,
                                    resources.created_date,
                                    resources.modified_by,
                                    resources.modified_date 
                            FROM
                                    resources
                                    INNER JOIN role_resources ON resources.pk_id = role_resources.resource_id 
                            WHERE
                                    resources.parent_id = '".$row1->pk_id."'
                                    AND role_resources.role_id = '".$_SESSION['role']."'
                            ORDER BY
                                    role_resources.rank ASC ";
//                echo $qry2;exit;
                $mainmenu = $this->db->query($qry2);
                    ?>
                    
                        <li class="has-submenu">
                             <a href="#"><i class="<?php echo $row1->icon_class; ?>"></i> <?php echo $row1->page_title; ?> <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                    <ul class="submenu megamenu">
                    <?php foreach ($mainmenu->result() AS $row2)
                    {    
                    $qry3 = "SELECT
                               * 
                        FROM
                                resources
                        WHERE
                                resources.parent_id = ".$row2->pk_id;
//                echo $qry3;exit;
                $submenu = $this->db->query($qry3);
                    ?>
                            <div class="col-md-12">
                                <div class="">
                                    <div><span style="display:inline-block; width: 180px;"><a href="<?php if($row2->resource_name == '#' || empty($row2->resource_name)) { echo $row2->resource_name;} else{ echo base_url($row2->resource_name);} ?>"><?php echo $row2->page_title; ?></a></span>
                                        <?php foreach ($submenu->result() AS $row3)
                                        {     //var_dump($row3);die;
                                        ?>
                                        <a href="<?php echo base_url($row3->resource_name); ?>">
                                        <i class="<?php echo $row3->icon_class; ?>"></i><?php echo $row3->page_title; ?> </a> |
                                        
                                        <?php 
                                        }  ?>
                                    </div>
                                </div>
                            </div>
                        
                <?php   
                    } ?>
                    </ul>
                        </li>
                    
                <?php 
                } ?>
                </ul>
            <!-- End navigation menu -->
        </div>
        <!-- end #navigation -->
    </div>
    <!-- end container -->
</div>
<!-- end navbar-custom -->