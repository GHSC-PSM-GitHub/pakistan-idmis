<script>
    $(function () {
        $("#addlocation").validate({
            rules: { 
                location_name: "required"
            }
        });

    });
    $("#location_level").on("change", function () {
        if ($(this).val() == 4) {
            province();
            $("#province_div").show();
             $("#district_div, #tehsil_div").hide();
        } else if ($(this).val() == 5) {
            province();
            district();
            $("#province_div , #district_div").show();
            $("#tehsil_div").hide();
        }
        else if (($(this)).val()==6){
            province();
            district();
            tehsil();
            $("#province_div , #district_div , #tehsil_div").show();
        }
    });
    function province() {
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('ajax/combo_locations'); ?>",
            data: {
                lvl: 2
            },
            dataType: 'html',
            success: function (data) {
                $('#province').html(data);
            }
        });
    }
    function district() {
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('ajax/combo_locations'); ?>",
            data: {
                lvl: 4
            },
            dataType: 'html',
            success: function (data) {
                $('#district').html(data);
            }
        });
    }
    function tehsil(){
     $.ajax({
            type: "POST",
            url: "<?php echo base_url('ajax/combo_locations'); ?>",
            data: { 
                lvl: 5 
            },
            dataType: 'html',
            success: function (data) {
                $('#tehsil').html(data);
            }
        });
    }
</script>
