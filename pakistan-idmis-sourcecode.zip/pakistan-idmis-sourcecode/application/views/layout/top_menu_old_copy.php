<!-- MENU Start -->
<div class="navbar-custom">
    <div class="container-fluid">
        <?php if(!empty($top_menus[0]['pk_id'])):?>
        <div id="navigation">
            <ul class="navigation-menu">
                <?php foreach($top_menus as $top_menu):?>
                    <?php if(!empty($top_menu['child']) && count($top_menu['child']) > 0):?>
                    <li class="has-submenu">
                        <a href="<?= $top_menu['resource_name'];?>">
                            <i class="<?= $top_menu['icon_class'];?>"></i> 
                            <?= $top_menu['page_title'];?>
                            <i class="mdi mdi-chevron-down mdi-drop"></i>
                        </a>
                        <?php foreach($top_menu['child'] as $top_menu_child):?>
                            <?php if(!empty($top_menu_child['grand_child']) && count($top_menu_child['grand_child']) > 0):?>
                            <ul class="submenu megamenu">
                                <div class="col-md-12 row">
                                    <div class="col-md-6">
                                        <div class="">
                                            <p style="font-size: 14px;color:#1F8564;"><b>ORGANIZATION</b></p>
                                        <div>
                                            <span style="display:inline-block; width: 180px;">
                                                <a href="<?= $top_menu_child['resource_name'];?>">
                                                    <?= $top_menu_child['page_title'];?>
                                                </a>
                                            </span>
                                            <?php foreach($top_menu_child['grand_child'] as $top_menu_grand):?>
                                            <a href="<?= base_url().$top_menu_grand['resource_name'];?>">
                                                <i class="<?= $top_menu_grand['icon_class'];?>"></i>
                                                <?= $top_menu_grand['page_title'];?> </a> |
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>
                            </ul>
                            <?php endif;?>
                        <?php endforeach;?>
                    </li>
                    <?php endif;?>
                <?php endforeach;?>
            </ul>
            <!-- End navigation menu -->
        </div>
        <?php endif;?>
        <!-- end #navigation -->
    </div>
    <!-- end container -->
</div>
<!-- end navbar-custom -->