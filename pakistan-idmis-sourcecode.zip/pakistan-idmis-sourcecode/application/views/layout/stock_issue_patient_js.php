<script>
    $(function () {
        $("#quantity").on('keyup keypress blur change', function () {
            var prod = $('#product').val();
            var qty = $('#quantity').val();
            var units_in_vial = 1000;
            
            var ins1 = $("#insulin_1").val();
            var ins2 = $("#insulin_2").val();
            var daily_units = 0;
            var nxt = '';
            var nxt_date = '';
            var lasting_days = 0;
            var next_date = 0;
            var cushion = 5;
            console.log(prod+','+ins1+','+ins2);
            if(prod == ins1 || prod == ins2){
                if(prod == ins1){
                    daily_units = $("#daily_units_1").val();
                    units_in_vial = $("#units_in_vial_1").val();
                }
                else if(prod == ins2){
                    daily_units = $("#daily_units_2").val();
                    units_in_vial = $("#units_in_vial_2").val();
                }

                 lasting_days = qty * units_in_vial / daily_units;
                 var lasting_days2 = lasting_days;
                 if(lasting_days > cushion){
                     lasting_days = lasting_days - cushion;
                 }
                 
                var next_date = new Date();
                next_date.setDate(next_date.getDate('YYYY-MM-DD') + lasting_days); 
                var dd = next_date.getDate();
                var mm = next_date.getMonth() + 1;
                var y = next_date.getFullYear();

                var next_date_f = dd + '/'+ mm + '/'+ y;
            
                 nxt = 'Details : '+qty+' vials , having '+units_in_vial+' units in each vial, when consumed at rate of '+daily_units;
                 nxt += ' units per day, can last for '+Math.round(lasting_days2)+' days. ';
                 if(lasting_days > cushion){
                    nxt += 'While keeping a cushion of '+cushion+'days,';
                 }
                 nxt += 'The next issuance date is calculated to be :'+next_date_f+'(dd/mm/yyyy)';
                 
                 $('#nxt').html('').html(nxt);
                 $('#nxt_date').html('').html(next_date_f+'');
            }
            else{
                $('#nxt_date').html('').html('None');
                 $('#nxt').html('').html('Next issuance date can only be calculated for items marked as insulin 1 OR insulin 2 in Patients profile. ');
            }
            
            var iss_limit = parseInt($('#quantity').attr('max'));
            if(parseInt(qty) > iss_limit){
                
                    alertify.error("This item can be issued at maximum quantity of "+iss_limit);
            }
        });
        
//        $("#stock_issue").validate({
//            rules: {
//                product: "required", 
//                quantity: {
//                    required:true,
//                    number:true,
//                    min: 1,
//                    step: 1
//                }
//            }
//        });

        $("#product").change(function () {
            $('#batch').attr('disabled',true);
            var product = $("#product").val();
            var wh_id = $("#center_from").val();
            var issuance_limit = $("#product [value="+product+"]").attr('issuance_limit');
            //console.log(product+'-'+wh_id+'-'+$(this).val()+'-'+issuance_limit);
            
            if(issuance_limit == 'undefined' || issuance_limit == 'NaN' || issuance_limit <= 0 ){
                $('#quantity').val(''); 
                $('#quantity').attr('max',99999); 
                //$('#quantity').attr('readonly',false); 
            }
            else{
                $('#quantity').val(issuance_limit); 
                $('#quantity').attr('max',issuance_limit); 
                //$('#quantity').attr('readonly',true); 
            }
            
            
            
            
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('inventory_management/get_batches_of_wh'); ?>",
                data: {
                    item_id: product,
                    wh_id: wh_id
                },
                dataType: 'html',
                success: function (data) {
                    alertify.success("Please select the Batch now.");
                    $('#batch').attr('disabled',false);
                    $('#batch').html(data);
                }
            });
        });
        
        $("#center_from").change(function () {
            $('#product').attr('disabled',true);
            var id = $(this).val();
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('inventory_management/get_available_prods_of_wh'); ?>",
                data: {
                    wh_id: id
                },
                dataType: 'html',
                success: function (data) {
                    if(!data){
                        alertify.error("No Stock available at this center");
                    }
                    else
                    {
                        //alertify.success("Please select the product now.");
                        $('#product').attr('disabled',false);
                        $('#product').html(data);
                    }
                }
            });
        });
        $("#batch").change(function () {
            var batch_id = $("#batch").val();
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('inventory_management/get_batch_info'); ?>",
                data: {
                    batch_id: batch_id
                },
                dataType: 'json',
                success: function (data) {
                    $("#available_quantity").val(data.available_qty);
                    $("#batch_expiry").val(data.expiry_date);
                }
            });
        });
        $("#issue_to").change(function () {
        $.ajax({
                type: "POST",
                url: "<?php echo base_url('inventory_management/get_center_patients'); ?>",
                data: {
                    issue_type: $(this).val()
                },
                dataType: 'html',
                success: function (data) {
                    $("#center_patient").html(data); 
                }
            });
        });
        $("#save_temp_issue").click(function () {
        $.ajax({
                type: "POST",
                url: "<?php echo base_url('inventory_management/save_temporary_records'); ?>",
                data: {
                    stock_master_id: $("#stock_master_id").val() 
                },
                dataType: 'html',
                success: function (data) { 
                    window.location.href =" <?php echo base_url('inventory_management/stock_issue_search'); ?>";
                }
            });
        });
        
    });
</script>