<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style>
    *,
    *:after,
    *:before 
    {
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
    }

    .clearfix:before,
    .clearfix:after
    {
        content: " ";
        display: table;
    }

    .clearfix:after 
    {
        clear: both;
    }

    body 
    {
        font-family: sans-serif;
        background: #f6f9fa;
    }

    h1 
    {
        color: #ccc;
        text-align: center;
    }

    a 
    {
        color: #ccc;
        text-decoration: none;
        outline: none;
    }

    /*Fun begins*/
    .tab_container 
    {
        width: 90%;
        margin: 0 auto;
        position: relative;
    }

    input, section 
    {
        clear: both;
        padding-top: 10px;
        display: none;
    }

    label 
    {
        font-weight: 700;
        font-size: 18px;
        display: block;
        float: left;
        width: 25%;
        padding: 1.5em;
        color: #757575;
        cursor: pointer;
        text-decoration: none;
        text-align: center;
        background: #f0f0f0;
    }

    #tab1:checked ~ #content1,
    #tab2:checked ~ #content2,
    #tab3:checked ~ #content3,
    #tab4:checked ~ #content4,
    #tab5:checked ~ #content5,
    #tab6:checked ~ #content6,
    #tab7:checked ~ #content7,
    #tab8:checked ~ #content8,
    #tab9:checked ~ #content9 
    {
        display: block;
        padding: 20px;
        background: #fff;
        color: #999;
        border-bottom: 2px solid #fff;
    }

    .tab_container .tab-content p,
    .tab_container .tab-content h3 
    {
        -webkit-animation: fadeInScale 0.7s ease-in-out;
        -moz-animation: fadeInScale 0.7s ease-in-out;
        animation: fadeInScale 0.7s ease-in-out;
    }
    .tab_container .tab-content h3  
    {
        text-align: center;
    }

    .tab_container [id^="tab"]:checked + label 
    {
        background: #fff;
        box-shadow: inset 0 3px #0CE;
    }

    .tab_container [id^="tab"]:checked + label .fa 
    {
        color: #0CE;
    }

    label .fa 
    {
        font-size: 1.3em;
        margin: 0 0.4em 0 0;
    }

    /*Media query*/
    @media only screen and (max-width: 930px) 
    {
        label span 
        {
            font-size: 14px;
        }
        label .fa 
        {
            font-size: 14px;
        }
    }

    @media only screen and (max-width: 768px) 
    {
        label span 
        {
            display: none;
        }
        label .fa 
        {
            font-size: 16px;
        }
        .tab_container 
        {
            width: 98%;
        }
    }

    /*Content Animation*/
    @keyframes fadeInScale 
    {
        0% 
        {
            transform: scale(0.9);
            opacity: 0;
        }

        100% 
        {
            transform: scale(1);
            opacity: 1;
        }
    }
    #navbar {
  background-color: #333; /* Black background color */
  position: fixed; /* Make it stick/fixed */
  top: -50px; /* Hide the navbar 50 px outside of the top view */
  width: 100%; /* Full width */
  transition: top 0.3s; /* Transition effect when sliding down (and up) */
}

/* Style the navbar links */
#navbar a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 15px;
  text-decoration: none;
}

#navbar a:hover {
  background-color: #ddd;
  color: black;
}
</style>
<body>
    <div class="tab_container">
       
   
        <div>
 
            <table class="table table-bordered table-condensed table-responsive text-center" style="margin-top: 2%; ">
        
                <tr id="lmis">    
                    <td>
                        <iframe width="400" height="250" src="https://www.youtube.com/embed/feq0nWevpNY" allowfullscreen>
                        </iframe>
                        <b><p class="text-center">IDs MIS - Opening Balances</p></b>
                    </td>

                    <td>
                        <iframe width="400" height="250" src="https://www.youtube.com/embed/QvpWxoJPX6I" allowfullscreen>
                        </iframe>
                        <b><p class="text-center">IDs MIS Stock Issue to Centers</p></b>
                    </td>

                    <td>
                        <iframe width="400" height="250" src="https://www.youtube.com/embed/RQ5WozQe2ZM" allowfullscreen>
                        </iframe>
                        <b><p class="text-center">IDs MIS Stock Receive Warehouse</p></b>
                    </td>
                </tr>
             
                <tr>
                    <td>
                        <iframe width="400" height="250" src="https://www.youtube.com/embed/39-gl9U6WQ4" allowfullscreen>
                        </iframe>
                        <b>  <p class="text-center">IDs MIS Stock Issue to Facility</p></b>
                    </td>
                    <td>
                        <iframe width="400" height="250" src="https://www.youtube.com/embed/PAZ7AA4WLgc" allowfullscreen>
                        </iframe>
                        <b>  <p class="text-center">IDs MIS Batch Management</p></b>
                    </td>

                    <td>
                        <iframe width="400" height="250" src="https://www.youtube.com/embed/3ROjDknDTkk" allowfullscreen>
                        </iframe>
                        <b>  <p class="text-center">IDs MIS Requisition</p></b>
                    </td>
                </tr>
               <tr>
                    <td>
                        <iframe width="400" height="250" src="https://www.youtube.com/embed/CvwmGAZi7SI" allowfullscreen>
                        </iframe>
                        <b>  <p class="text-center">IDs MIS Consumption Form</p></b>
                    </td>
                   
                </tr>
             
            </table>
        </div>
    
    </div>
</body>
<script>
    window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("navbar").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-50px";
  }
}
    </script>