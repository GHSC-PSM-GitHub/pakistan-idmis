<td style="border: 1px solid #B5E4CB;"><script>
    $(function () {
        
        
        
//        $('#second_skip').prop('disabled', true);
        var max = 11;
        $('#contact_number').keypress(function (e) {
            if (e.which < 0x20) {
                // e.which < 0x20, then it's not a printable character
                // e.which === 0 - Not a character
                return;     // Do nothing
            }
            if (this.value.length == max) {
                e.preventDefault();
            } else if (this.value.length > max) {
                // Maximum exceeded
                this.value = this.value.substring(0, max);
            }
        });
//          $('#checkidmr').on('change', function() {
//                $('#checkidmr').not(this).prop('checked', false);  
//            });
        $("#update_patient_reg").click(function(e){
//           $('#checkidmr').siblings('input:checkbox').prop('checked', false);
//            if($("#age").val() == '')
//            {
//                alert("Please go back and enter age");
//                return false;
//            }
//            if($("#email").val() == '')
//            {
//                alert("Please go back and enter email");
//                return false;
//            }
            var val = [];
//            var userinput = $("#email").val();
            var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
            if (!testEmail.test($("#p_email").val()) && $("#p_email").val() != '') 
            {
                alert('Please go back and enter valid email');
                return false;
            }
            var length;
            $(':checkbox:checked').each(function(i){
              val[i] = $(this).val();
            });
            length = val.length;
//            $('#checkArray:checkbox:checked').length > 0;
            if($('#nadra:checkbox:checked').length > 0)
            {
                length = (val.length)-1;
//                var v = val;
//                v.replace(/^[^,]+, */, '');
//              val = val.split(',')[1];
                val = val[1];
//                alert(val);
            }
            if(length <= 1)
            {
              if(val != '' && length != 0)
                {
//                    alert(val); 
                    $("#update_patient_id").val(val);
                    $("#patient_info").submit();
                }
                else{
                    alert('Please select any checkbox');
                }
            }
            else{
                alert('Please Select only one checkbox');
            }
        });
        $("#second_skip").click(function(e){
            $('#p_email').rules('remove');
//        $('#age').prop('required',false);
//        $('#email').prop('required',false);
        var val = [];
        $(':checkbox:checked').each(function(i){
//            $(this).siblings('input:checkbox').prop('checked', false);
          val[i] = $(this).val();
        });
        if(val.length <= 1)
        {
          if(val != '')
          {
//              alert(val); 
              $("#patient_id_old").val(val);
              $("#patient_info").submit();
          }
          else{
              alert('Please select any checkbox');
          }
        }
        else{
            alert('Please Select only one checkbox');
        }
//            alert(document.getElementById('checkidmr').value);
//                if(document.getElementById('checkidmr').checked)
//                {
////                     var arr = [];
////
////                    $('input[type="checkbox"]:checked').each(function () {
////                      arr.push($(this).val());
//                    });
//
//                    alert("saad"+$('#checkidmr').val());
//                }
//                else{
//                    alert("saadi");
//                }
//               $("#patient_info").submit();
//            if($('#checkidmr').is(":checked")){
//                alert("Checkbox is checked.");
//            }
//            else {
//                alert("Checkbox is unchecked.");
//            }
        });
        $("#second_submit1").click(function(e){
//            if($("#age").val() == '')
//            {
//                alert("Please go back and enter age");
//                return false;
//            }
//            if($("#email").val() == '')
//            {
//                alert("Please go back and enter email");
//                return false;
//            }
            $("#patient_ids").val("");
            var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
            if (!testEmail.test($("#p_email").val()) && $("#p_email").val() != '') 
            {
                alert('Please go back and enter valid email');
                return false;
            }
               $("#patient_info").submit();
        });
        $("#second_submit").click(function(e){
//            alert($("#p_mobileno").val().length);
        if($('#age').val() != '')
         {
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('patients/get_info'); ?>",
                data: {phone: $("#p_mobileno").val(),name: $("#full_name").val()},
                dataType: 'html',
                success: function (html) {
//                    alert(html);
                    if(html != '') {
                        $("#same_record").html(html);
                        $("#modal").click();
//                        return true;
                    }                    
                    else
                    {
                        $("#patient_info").submit();
                    }
                }
            });
          } 
          if($('#full_name').val() == '')
            {
                $("#patient_info").submit();
//                  $("#full_name").focus();
            }
          if($('#full_name').val() != '' && $('#p_mobileno').val() == '' || $('#p_mobileno').val().length != '11')
            {
                $("#patient_info").submit();
            }
          if($('#full_name').val() != '' && $('#cnic').val().length != '13' && $('#p_mobileno').val().length == '11')
            {
                $("#cnic").focus();
            }
           if($('#full_name').val() != '' && $('#p_mobileno').val() != '' && $('#age').val() != '' && $('#village').val() == '')
           {
               $("#village").focus();
//                $('#village').select2('open');
                
           }
           if($('#full_name').val() != '' && $('#p_mobileno').val() != '' && $('#age').val() < '0' && $('#p_mobileno').val().length == '11')
            {
                $("#age").focus();
            }
//           if($('#full_name').val() != '' && $('#contact_number').val() != '' && $('#age').val() != '' && $('#province').val() != '' && $('#district').val() == '')
//           {
//               $("#district").select2('open');
//           }
//           if($('#full_name').val() != '' && $('#contact_number').val() != '' && $('#age').val() != '' && $('#province').val() != '' && $('#district').val() != '' && $('#tehsil').val() == '')
//           {
//               $("#tehsil").select2('open');
//           }
//           if($('#full_name').val() != '' && $('#contact_number').val() != '' && $('#age').val() != '' && $('#province').val() != '' && $('#district').val() != '' && $('#tehsil').val() != '' && $('#uc').val() == '')
//           {
//               $("#uc").select2('open');
//           }
      });
        var max_cnic = 13;
        $('#cnic_number').keypress(function (e) {
            if (e.which < 0x20) {
                // e.which < 0x20, then it's not a printable character
                // e.which === 0 - Not a character
                return;     // Do nothing
            }
            if (this.value.length == max_cnic) {
                e.preventDefault();
            } else if (this.value.length > max_cnic) {
                // Maximum exceeded
                this.value = this.value.substring(0, max_cnic);
            }
        });
        $("#patient_info").validate({
            rules: {
                full_name: {
                    required:true,
                    lettersonly: true
                },
                age: {
                    required:true,
                    min: 0,
                    max: 120
                },
                p_mobileno: {
                    required:true,
                    number: true,
                    minlength: 11,
                    maxlength: 11
                },
                cnic: {
                    number: true,
                    minlength: 13,
                    maxlength: 13

                },
                p_email: {
                    emailfull: true
                },
                village: {
                    required:true
                }
//                province : {
//                    province: "required needsSelection"
//                }
            },
            ignore: [],
//            ignore: ':hidden:not("#province")', // Tells the validator to check the hidden select
//            ignore : ".ignore, :hidden",
//            errorClass: 'invalid'
        });
        $("#data").validate({
            rules: {
                full_name: {
                    required:true,
                    lettersonly: true
                },
                age: {
                    required:true,
                    min: 1,
                    max: 120
                },
                p_mobileno: {
                    required:true,
                    number: true,
                    minlength: 11,
                    maxlength: 11
                },
                cnic: {
                    number: true,
                    minlength: 13,
                    maxlength: 13

                },
                p_email: {
                    emailfull: true
                },
                village: {
                    required:true
                }
//                province : {
//                    province: "required needsSelection"
//                }
            },
            ignore: [],
//            ignore: ':hidden:not("#province")', // Tells the validator to check the hidden select
//            ignore : ".ignore, :hidden",
//            errorClass: 'invalid'
        });
        jQuery.validator.addMethod("emailfull", function(value, element) {
            return this.optional(element) || /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i.test(value);
           }, "Please enter valid email address!");
        $("#patient_readings").validate({
            rules: {
                temperature: {
                    min: 90,
                    max: 105
                },
                bp_systolic: {
                    min: 1,
                    max: 200
                },
                bp_diastolic: {
                    min: 1,
                    max: 200
                },
                heart_pulse: {
                    min: 40,
                    max: 220
                }
            }
        });
        $.validator.addMethod("needsSelection", function (value, element) {
            return $(element).multiselect("getChecked").length > 0;
        });
        jQuery.validator.addMethod("lettersonly", function (value, element) {
            return this.optional(element) || /^[a-zA-Z ]+$/i.test(value);
        }, "Alphabets only please");

        $.validator.messages.needsSelection = 'Please select a disease.';

        $("#patient_diagnosis").validate({
            rules: {
                disease: "required needsSelection"
            },
            ignore: ':hidden:not("#disease")', // Tells the validator to check the hidden select
            errorClass: 'invalid'
        });
//        $("#medicine_prescription").validate({
//            rules: {
//                medicine: "required needsSelection"
//            },
//            ignore: ':hidden:not("#medicine")', // Tells the validator to check the hidden select
//            errorClass: 'invalid'
//        });
        get_medicines();
        $(document).on("click", "#delete_btn", function () {
            var id = $(this).data("id");
            var visit_id = $(this).data("visit-id");
//            alert(visit_id);
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('patients/delete_prescribed_medicines'); ?>",
                data: {id: id},
                dataType: 'html',
                success: function (data) {
                    $("#days").val('');
                    $('#table_medicine').html('');
                    $("#medicine").select2();
                    get_medicines();
                }
            });
        });
        $("#diesease_name").change(function () {
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('patients/get_medicines'); ?>",
                data: {desease_id: $(this).val()},
                dataType: 'html',
                success: function (data) {
                    $("#medicine").html(data);
                    $('#medicine').trigger('change');
                }
            });
        });
        $("#medicine").change(function () {
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('patients/get_medicine_strength'); ?>",
                data: {medicine_id: $(this).val()},
                dataType: 'html',
                success: function (data) {
                    $("#strength").html(data);
                    $('#strength').trigger('change');
                }
            });
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('patients/get_medicine_dose'); ?>",
                data: {medicine_id: $(this).val()},
                dataType: 'html',
                success: function (data) {
                    $("#dose").html(data);
                    $('#dose').trigger('change');
                }
            });
//            $.ajax({
//                type: "POST",
//                url: "<?php echo base_url('patients/contradictory_products'); ?>",
//                data: {medicine_id: $("#medicine").val(), contrasting_medicine: $("#medicine_string").val()},
//                dataType: 'json',
//                success: function (data) {
////                    alert(data.message_array);
//                    if(data.message_array == 'empty')
//                    {
//                        $('#contradict_msg').val('');
////                        $('#toaster_info').html('');
//                        toastr.clear();
//                    }
//                    else
//                    {
//                        $.each(data.message_array, function (index, element) {
//    //                        alert(element.message);
//                            toastr.info(element.message, element.contradictory_product_name, {timeOut: 0,"extendedTimeOut": "0",tapToDismiss: false,"positionClass": "toast-bottom-left"});
////                            $('#toaster_info').html('<bold>'+element.contradictory_product_name+'<bold> : <br>'+element.message);
////                            $('#toaster_info').css({ 'color': '#2F96B4', 'font-size': '100%' });
//                            $('#contradict_msg').val('<bold>'+element.contradictory_product_name+'<bold> : <br>'+element.message);
//                                                       
//                        });
//                        
//                    }
//                }
//            });

        });
        $("#final_submit").click(function () {
            var form = $("#medicine_prescription").serialize();
            if ($("#days").val() != '' && ($("#medicine").val() != '') && ($("#strength").val() != '') && ($("#dose_form").val() != '')) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('patients/add_medicines'); ?>",
                    data: form,
                    dataType: 'json',
                    success: function (data) {
                        $('#table_medicine').html(data.body);
                        $("#medicine").select2();

                        if (data.body) {
                            $(".disable-click").css("pointer-events", 'auto');
                        } else {
                            $(".disable-click").css("pointer-events", 'none');
                        }
                        $("#medicine_string").val(data.medicine_string);
                    },
                    error: function (data)
                    {
                        $(".disable-click").css("pointer-events", 'none');
                    }
                });
                var medicine = $("#medicine").val();
                var medicine_string = $("#medicine_string").val();
                $("#medicine_string").val(medicine_string + ',' + medicine);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('patients/remove_already_selected'); ?>",
                    data: {medicine_id: $("#medicine_string").val()},
                    dataType: 'json',
                    success: function (data) {
                        var html = "<option value=''></option>";
                        for (var key in data.medicine_array) {
                            html += "<option value=" + key + ">" + data.medicine_array[key] + "</option>"
                        }

                        $('#medicine').html(html);
                        $("#days").val("");
                        $('#medicine').trigger('change'); 

                    }
                });
            }
        });
//        $("#province").change(function(){
//            var value = $(this).val();
//            $.ajax({
//                type: "POST",
//                url: '<?php // echo base_url("ajax/combo"); ?>',
//                data: {
//                    id: value,
//                    lvl: 4
//                },
//                dataType: 'html',
//                success: function (data) {
//                    $("#district").select2("val", "");
//                    $("#tehsil").select2("val", "");
//                    $("#uc").select2("val", "");
//                    $('#district').html(data);
//                }
//            });
//            $.ajax({
//                type: "POST",
//                url: '<?php // echo base_url("ajax/cities"); ?>',
//                data: {
//                    province_id: value
//                },
//                dataType: 'html',
//                success: function (data) {
//                    $('#city').html(data);
//                }
//            });
//        });
//        $("#district").change(function(){
//            var value = $(this).val();
//            $.ajax({
//                type: "POST",
//                url: '<?php // echo base_url("ajax/combo"); ?>',
//                data: {
//                    id: value,
//                    lvl: 5
//                },
//                dataType: 'html',
//                success: function (data) {
//                    $("#tehsil").select2("val", "");
//                    $("#uc").select2("val", "");
//                    $('#tehsil').html(data);
//                }
//            });
//        });
//
//        $("#tehsil").change(function(){
//            var value = $(this).val();
//            $.ajax({
//                type: "POST",
//                url: '<?php // echo base_url("ajax/combo"); ?>',
//                data: {
//                    id: value,
//                    lvl: 6
//                },
//                dataType: 'html',
//                success: function (data) {
//                    $("#uc").select2("val", "");
//                    $('#uc').html(data);
//                }
//            });
//        });
//        $('#search_table').DataTable({
//            dom: 'Bfrtip',
//            buttons: [
//                'copy', 'csv', 'excel', 'pdf', 'print'
//            ]
//        });
        $('#search_table').DataTable({
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'copy',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'csv',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'excel',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'pdf',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'print',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                }
            ]
        });
        $('div.dataTables_filter input').addClass('col-md-4 form-control');
        $('div.dataTables_filter input').css("width", "100%");
        $('div.dataTables_filter label').css("padding-right", "20%");
        $('div.dataTables_filter label').css("text-align", "center");
    });
     function calculate_age(dob, method) {
            if (method == 'age2dob') {
                var birthDate = moment().subtract(dob, 'years');
                $("#day").val(birthDate.format("D"));
                $("#month").val(birthDate.format("M"));
                $("#year").val(birthDate.format("YYYY"));
            } else {
                var dob = $("#year").val() + '-' + $("#month").val() + '-' + $("#day").val();
                var a = moment();
                var b = moment(dob, "YYYY-MM-DD");
                var age_dt = a.diff(b, 'years');

                $("#age").val(age_dt);
            }
        }
    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        var printButton = document.getElementById("printPageButton");
        var printButton1 = document.getElementById("gotoparentpage");
        printButton.style.visibility = 'hidden';
        printButton1.style.visibility = 'hidden';
        var curURL = window.location.href;
        history.replaceState(history.state, '', '/');
//        window.print();
        window.print();
        history.replaceState(history.state, '', curURL);
        document.body.innerHTML = originalContents;
        printButton.style.visibility = 'visible';
        printButton1.style.visibility = 'visible';
    }
    function get_medicines() {
        var form = $("#medicine_prescription").serialize();
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('patients/add_medicines'); ?>",
            data: form,
            dataType: 'json',
            success: function (data) {
                $('#table_medicine').html(data.body);
                if (data.body) {
                    $(".disable-click").css("pointer-events", 'auto');
                }
                $("#medicine_string").val(data.medicine_string);

                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('patients/contradictory_products'); ?>",
                    data: {medicine_id: $("#medicine_string").val()},
                    dataType: 'json',
                    success: function (data) {
                        var html = "<option value=''></option>";
                        for (var key in data.medicine_array) {
                            html += "<option value=" + key + ">" + data.medicine_array[key] + "</option>"
                        }
                        $('#medicine').html(html);
                        $("#days").val("");
                        $('#medicine').trigger('change');

                    }
                });
            },
            error: function (data) {
                $(".disable-click").css("pointer-events", 'none');
            }
        });
    }
    
    
    

$(function() {
    $("#btnrdt").click(function(){
        $.post("ajax_add_rdt",
        $("#rdt").serialize(),
        function(data, status){
            $("#rdt_result").html(data);
            delete_rdt();
        });   
    });
    $("#nadra").click(function(){
            
        var thisval=$(this).val();
        if ($(this).prop('checked')==true){ 
            console.log('below');
            $('#father_guardian_nic').attr('required','required');
            $('#cnic').attr('required',false);
            $('#cnic').attr('readonly',true);
        }
        else{
            console.log('above');
            $('#father_guardian_nic').attr('required',false);
            $('#cnic').attr('required','required');
            $('#cnic').attr('readonly',false);
        }
    });

    $("#cnic").change(function(){
        var thisval=$(this).val();
        console.log(thisval);
         $.ajax({
             url: "check_unique_cnic/"+thisval, 
             success: function(result)
             {
                console.log(result);
                if(result=='no'){
                    $("#cnic").css('background-color','#ffc9c9');
                    $("#cnic").val('');
                    alert('This CNIC number '+thisval+' is already in use. Go to Patient Search , and check for the patients information.');
                    $("#cnic").focus();
                }
                else{
                        
                    $("#cnic").css('background-color','#aff7ac');
                    }
            }
        });
    });
    $("#diabetic_type").change(function(){
        var thisval=$(this).val();
        if(thisval=='type_2' || thisval=='gestational'){
            $('#zakat_entitled').slideDown();
        }else
            {

            $('#zakat_entitled').slideUp();
            }
    });
    $("#insulin_1").change(function(){
        var thisval=$(this).val();
        console.log(thisval);
        if(parseInt(thisval) > 1){
            $('#daily_units_1').attr('readonly',false);
        }else
        {
            $('#daily_units_1').attr('readonly','readonly');
        }
    });
    $("#insulin_2").change(function(){
        var thisval=$(this).val();
        if(parseInt(thisval) > 1){
            $('#daily_units_2').attr('readonly',false);
        }else
        {
            $('#daily_units_2').attr('readonly','readonly');
        }
    });
});

function delete_rdt(){
    $("button[id$='-delete']").click(function () {
        if(confirm('Are you sure you want to delete?')){
            var value = $(this).attr("id");
            var params = value.replace("-delete", "");
            var arr = params.split('_');
            $.post("ajax_del_rdt",
            {
                'pk_id': arr[0],
                'p_id': arr[1]
            },
            function(data, status){
                $("#rdt_result").html(data);
                delete_rdt();
            });  
        }
    });
}

$("#btnpreexam").click(function() {
    $.post("ajax_add_preexam",
    $("#preexam").serialize(),
    function(data, status){
        $("#preexam_result").html(data);
        delete_preexam();
    });  
});

function delete_preexam(){
    $("button[id$='-deletepreexam']").click(function () {
        if(confirm('Are you sure you want to cancel?')){
            var value = $(this).attr("id");
            var params = value.replace("-deletepreexam", "");
            var arr = params.split('_');
            $.post("ajax_del_preexam",
            {
                'pk_id': arr[0],
                'p_id': arr[1]
            },
            function(data, status){
                $("#preexam_result").html(data);
                delete_preexam();
            });  
        }
    });
}

$("#btnlabtest").click(function(){
    $.post("ajax_add_labtest",
    $("#labtest").serialize(),
    function(data, status){
        $("#labtest_result").html(data);
        delete_labtest();
    });   
});

function delete_labtest(){
    $("button[id$='-deletelab']").click(function () {
        if(confirm('Are you sure you want to cancel?')){
            var value = $(this).attr("id");
            var params = value.replace("-deletelab", "");
            var arr = params.split('_');
            $.post("ajax_del_labtest",
            {
                'pk_id': arr[0],
                'p_id': arr[1]
            },
            function(data, status){
                $("#labtest_result").html(data);
                delete_labtest();
            });  
        }
    });
}

$("#btnadditionalinfo").click(function(){
//    var str = $('#father_guardian_name').val();
//    var matches = str.match(/(\d+)/);
//    if($('#father_guardian_nic').val() != '' && ($('#father_guardian_nic').val() >= '14' || $('#father_guardian_nic').val() <= '12'))
//    {
////                $("#additional_info").submit();
//        $("#father_guardian_nic").focus();
//    }
//    if(matches)
//    {
////        alert("saad");
////                $("#additional_info").submit();
//        $("#father_guardian_name").focus();
//    }
//    if($('#father_guardian_nic').val() == '' || $('#father_guardian_nic').val() == '13' && matches == '')
//    {
        $.post("ajax_add_additional_info",
        $("#additional_info").serialize(),
        function(data, status){
            $("#additional_info_result").html(data);
            delete_ainfo();
        });  
//    }
});

function delete_ainfo(){
    $("button[id$='-deleteainfo']").click(function () {
        if(confirm('Are you sure you want to cancel?')){
            var value = $(this).attr("id");
            var params = value.replace("-deleteainfo", "");
            var arr = params.split('_');
            $.post("ajax_del_ainfo",
            {
                'pk_id': arr[0],
                'p_id': arr[1]
            },
            function(data, status){
                $("#additional_info_result").html(data);
                delete_ainfo();
            });  
        }
    });
}

$("#btnnotes").click(function() {
    $.post("ajax_add_notes",
    $("#anotes").serialize(),
    function(data, status){
        $("#notes_result").html(data);
        delete_anotes();
    });
});


function delete_anotes(){
    $("button[id$='-deleteanotes']").click(function () {
        if(confirm('Are you sure you want to cancel?')){
            var value = $(this).attr("id");
            var params = value.replace("-deleteanotes", "");
            var arr = params.split('_');
            $.post("ajax_del_anotes",
            {
                'pk_id': arr[0],
                'p_id': arr[1]
            },
            function(data, status){
                $("#notes_result").html(data);
                delete_anotes();
            });  
        }
    });
}

$("#test_date").datepicker({
    'format': 'dd/mm/yyyy'
});

$("#btncnote").click(function() {
//    alert($("#medicine_names").val());
//    alert($("#quantity").val());
//    alert($("#total_quantity").val());
//    alert($("#cnotes").serialize());
    $.post("ajax_add_cnote",
    $("#cnotes").serialize(),
    function(data, status){
        $("#cnote_result").html(data);
        delete_cnote();
    });  
});

function delete_cnote(){
    $("button[id$='-deletecnote']").click(function () {
        if(confirm('Are you sure you want to cancel?')){
            var value = $(this).attr("id");
            var params = value.replace("-deletecnote", "");
            var arr = params.split('_');
            $.post("ajax_del_cnote",
            {
                'pk_id': arr[0],
                'p_id': arr[1]
            },
            function(data, status){
                $("#cnote_result").html(data);
                delete_cnote();
            });  
        }
    });
}

$("#btnprescription").click(function() {
    $.post("ajax_add_prescription",
    $("#prescriptions").serialize(),
    function(data, status){
        $("#prescription_result").html(data);
        delete_prescription();
    });  
});

function delete_prescription(){
    $("button[id$='-deleteprescription']").click(function () {
        if(confirm('Are you sure you want to cancel?')){
            var value = $(this).attr("id");
            var params = value.replace("-deleteprescription", "");
            var arr = params.split('_');
            $.post("ajax_del_prescription",
            {
                'pk_id': arr[0],
                'p_id': arr[1]
            },
            function(data, status){
                $("#prescription_result").html(data);
                delete_prescription();
            });  
        }
    });
}
    $("#medicine").change(function () {
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('patients/get_medicine_strength'); ?>",
                    data: {medicine_id: $(this).val()},
                    dataType: 'html',
                    success: function (data) {
                        $("#strength").html(data);
                        $('#strength').trigger('change');
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('patients/get_medicine_dose'); ?>",
                    data: {medicine_id: $(this).val()},
                    dataType: 'html',
                    success: function (data) {
                        $("#dose_form").html(data);
                        $('#dose_form').trigger('change');
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('patients/contradictory_products'); ?>",
                    data: {medicine_id: $("#medicine").val(), contrasting_medicine: $("#medicine_string").val()},
                    dataType: 'json',
                    success: function (data) {
    //                    alert(data.message_array);
                        if(data.message_array == 'empty')
                        {
                            $('#contradict_msg').val('');
    //                        $('#toaster_info').html('');
                            toastr.clear();
                        }
                        else
                        {
                            $.each(data.message_array, function (index, element) {
        //                        alert(element.message);
                                toastr.info(element.message, element.contradictory_product_name, {timeOut: 0,"extendedTimeOut": "0",tapToDismiss: false,"positionClass": "toast-bottom-left"});
    //                            $('#toaster_info').html('<bold>'+element.contradictory_product_name+'<bold> : <br>'+element.message);
    //                            $('#toaster_info').css({ 'color': '#2F96B4', 'font-size': '100%' });
                                $('#contradict_msg').val('<bold>'+element.contradictory_product_name+'<bold> : <br>'+element.message);

                            });

                        }
                    }
                });

            });
//        $("#diesease_name").change(function () {
//            if($(this).val() == '2')
//            {
//                $('#leishmania_info').show();
//                $('#malaria_result').hide();
//                $('#dengue_result').hide();
//                $('#malaria_species_pv').hide();
//                $('#malaria_species_pf').hide();
//                $('#malaria_species_mix').hide();
//                $('#malaria_species_normal').hide();
//                $('#malaria_species_complicated').hide();
//                $('#malaria_severe_result').hide();
//            }
//            else{
//                $('#malaria_result').hide();
//                $('#dengue_result').hide();
//                $('#malaria_species_pv').hide();
//                $('#malaria_species_pf').hide();
//                $('#malaria_species_mix').hide();
//                $('#malaria_species_normal').hide();
//                $('#malaria_species_complicated').hide();
//                $('#malaria_severe_result').hide();
//                $('#leishmania_info').hide();
//            }
//        });
        $("#diesease_name").change(function () {
            if($(this).val() == '2')
            {
                $('#leishmania_info').show();
                $('#dengue_result').hide();
                $('#dengu_info').hide();
                $('#malaria_info').hide();
                $('#malaria_result').hide();
                $('#malaria_severe_result').hide();
                $('#malaria_species_pv').hide();
                $('#malaria_species_pf').hide();
                $('#malaria_species_mix').hide();
                $('#malaria_species_normal').hide();
                $('#malaria_species_complicated').hide();
            }
            if($(this).val() == '3')
            {
                $('#dengue_result').show();
                $('#dengu_info').show();
                $('#malaria_info').hide();
                $('#malaria_result').hide();
                $('#malaria_severe_result').hide();
                $('#malaria_species_pv').hide();
                $('#malaria_species_pf').hide();
                $('#malaria_species_mix').hide();
                $('#malaria_species_normal').hide();
                $('#malaria_species_complicated').hide();
                $('#leishmania_info').hide();
            }
            if($(this).val() == '1')
            {
                $('#dengue_result').hide();
                $('#malaria_info').show();
                $('#dengu_info').hide();
                $('#malaria_result').hide();
                $('#malaria_severe_result').hide();
                $('#leishmania_info').hide();
            }
//            if($(this).val() != '1' && $(this).val() != '3')
//            {
//                $('#dengue_result').hide();
//                $('#dengu_info').hide();
//                $('#malaria_info').hide();
//                $('#malaria_result').hide();
//                $('#malaria_severe_result').hide();
//                
//                $('#malaria_species_pv').hide();
//                $('#malaria_species_pf').hide();
//                $('#malaria_species_mix').hide();
//                $('#malaria_species_normal').hide();
//                $('#malaria_species_complicated').hide();
//            }
            
            if($(this).val() == '4')
            {
                $('#leishmania_info').hide();
                $('#dengue_result').hide();
                $('#dengu_info').hide();
                $('#malaria_info').hide();
                $('#malaria_result').hide();
                $('#malaria_severe_result').hide();
                $('#malaria_species_pv').hide();
                $('#malaria_species_pf').hide();
                $('#malaria_species_mix').hide();
                $('#malaria_species_normal').hide();
                $('#malaria_species_complicated').hide();
            }
            
            if($(this).val() == '')
            {
                $('#leishmania_info').hide();
                $('#dengue_result').hide();
                $('#dengu_info').hide();
                $('#malaria_info').hide();
                $('#malaria_result').hide();
                $('#malaria_severe_result').hide();
                $('#malaria_species_pv').hide();
                $('#malaria_species_pf').hide();
                $('#malaria_species_mix').hide();
                $('#malaria_species_normal').hide();
                $('#malaria_species_complicated').hide();
            }
            
        });
        $("#age_tetanus").change(function () {
            if($(this).val() == '1')
            {
                $('#age_tetanus_msg').html('<3 doses   , TCV=Yes, Anti-tetanus immunoglobulins = Yes');
            }
            if($(this).val() == '2')
            {
                $('#age_tetanus_msg').html('<3 doses  , TCV=Yes, Anti-tetanus immunoglobulins = No');
            }
        });
        $("#next_follow_up").change(function () {
//            var num = $(this).val();
        let numWeeks = $(this).val();
        if(isNaN(numWeeks)){
            return false;
        }
        else{
            let now = new Date();
            now.setDate(now.getDate() + numWeeks * 7);
//            alert(now);
            $('#follow_up_date').val(now);
        }
        });
        $("#no_of_lesion").change(function () {
            if($(this).val() == '1')
            {
                document.getElementById("lesion_number").readOnly = true;
                $('#lesion_number').val('1');
            }
            else
            {
                document.getElementById("lesion_number").readOnly = false;
                $('#lesion_number').val('');
            }
        });
        $("#reffered_action").change(function () {
//            alert($('#p_action_taken').val());
            if($('#p_action_taken').val() == '3')
            {
                $('#reffered').show();
            }
            else{
                $('#reffered').hide();
            }
        });
        $("#patient_species").change(function () {
//            alert($('#p_action_taken').val());
            if($('#patient_species').val() == '1')
            {
                $('#malaria_severe_result').show();
                $('#malaria_result').hide();
                $('#dengue_result').hide();
            }
            if($('#patient_species').val() == '2')
            {
                $('#malaria_severe_result').hide();
                $('#malaria_result').hide();
//                $('#malaria_result').show();
                $('#dengue_result').hide();
            }
        });
        
        
//         $("#insert-more").click(function () {
//                $("#uncomplicated_id").each(function () {
//                    var tds = '<tr>';
//                    jQuery.each($('tr:last td', this), function () {
//                        tds += '<td>' + $(this).html() + '</td>';
//                    });
//                    tds += '</tr>';
//                    if ($('tbody', this).length > 0) {
//                        $('tbody', this).append(tds);
//                    } else {
//                        $(this).append(tds);
//                    }
//                });
//           });
           
           $("#insert-more").click(function() {
               var id = $('#uncomplicated_id tr:last').find('td:first').html()
               if(id == 'Sr.No')
               {
                   id = '0';
                   var new_id = ++id;
               }
               else{
                   new_id = ++id;
               }
//               alert($('#srnos').html());
               
//            $('#uncomplicated_id tbody>tr:last')
//                .clone(true)
//                .insertAfter('#uncomplicated_id tbody>tr:last').find('input').each(function(){
//                    $(this).val('');
//                });
                $("#uncomplicated_id").append("<tr id='uncomplicated_newrows'><td id='srno'>"+new_id+"</td>\n\
                <td><input name='medicine_names[]' id='medicine_names' value='' /></td>\n\
                <td><input name='medicine_days_to_use[]' id='medicine_days_to_use' value='' /></td>\n\
                <td><input name='medicine_strength[]' id='medicine_strength' value='' /></td>\n\
                <td><input name='medicine_unit[]' id='medicine_unit' value='' /></td>\n\
                <td><input name='medicine_use[]' id='medicine_use' value='' /></td>\n\
                <td style='border: 1px solid #B5E4CB;'><input name='total_quantity[]' id='total_quantity' value='' /></td>\n\
                <td style='border: 1px solid #B5E4CB;'><textarea style='width: 100%; height: 100%;border: 1px solid black;' name='comments[]' id='comments'></textarea></td></tr>");
            
//                $('#srno').html('7+1');
                $("#uncomplicated_id").focus(); 
            });
            
//            $("#delete-more").on('click'function(){
//                $(this).parent().parent().remove();
//            });
            
        $('#remove').on("click", function(){
            var id = $('#uncomplicated_id tr:last').find('td:first').html();
            if(id != 'Sr.No')
            {
                $('#uncomplicated_id tr:last').remove();
            }
            else{
                return false;
            }
        });
        
        
        $("#insert-moree").click(function() {
               var id = $('#medicine_ides tr:last').find('td:first').html()
               if(id == 'Sr.No')
               {
                   id = '0';
                   var new_id = ++id;
               }
               else{
                   new_id = ++id;
               }
//               alert($('#srnos').html());
               
//            $('#medicine_ides tbody>tr:last')
//                .clone(true)
//                .insertAfter('#medicine_ides tbody>tr:last').find('input').each(function(){
//                    $(this).val('');
//                });
                $("#medicine_ides").append("<tr id='uncomplicated_newrowss'><td id='srno'>"+new_id+"</td>\n\
                <td><input name='medicine_namess[]' id='medicine_namess' value='' /></td>\n\
                <td><input name='medicine_days_to_usee[]' id='medicine_days_to_usee' value='' /></td>\n\
                <td><input name='medicine_strengthh[]' id='medicine_strengthh' value='' /></td>\n\
                <td><input name='medicine_unitt[]' id='medicine_unitt' value='' /></td>\n\
                <td><input name='medicine_usee[]' id='medicine_usee' value='' /></td>\n\
                <td style='border: 1px solid #B5E4CB;'><input name='total_quantityy[]' id='total_quantityy' value='' /></td>\n\
                <td style='border: 1px solid #B5E4CB;'><textarea style='width: 100%; height: 100%;border: 1px solid black;' name='comments[]' id='comments'></textarea></td></tr>");
            
//                $('#srno').html('7+1');
                $("#medicine_ides").focus(); 
            });
            
//            $("#delete-more").on('click'function(){
//                $(this).parent().parent().remove();
//            });
            
        $('#removee').on("click", function(){
            var id = $('#medicine_ides tr:last').find('td:first').html();
            if(id != 'Sr.No')
            {
                $('#medicine_ides tr:last').remove();
            }
            else{
                return false;
            }
        });
        
        
        $("#insert-moreee").click(function() {
               var id = $('#dengue_ides tr:last').find('td:first').html();
//               alert(id);
               if(id == 'Sr.No')
               {
                   id = '0';
                   var new_id = ++id;
               }
               else{
                   new_id = ++id;
               }
               
//               alert($('#srnos').html());
               
//            $('#dengue_ides tbody>tr:last')
//                .clone(true)
//                .insertAfter('#dengue_ides tbody>tr:last').find('input').each(function(){
//                    $(this).val('');
//                });
                $("#dengue_ides").append("<tr id='uncomplicated_newrowsss'><td id='srno'>"+new_id+"</td>\n\
                <td><input name='medicine_namesss[]' id='medicine_namesss' value='' /></td>\n\
                <td><input name='medicine_days_to_useee[]' id='medicine_days_to_useee' value='' /></td>\n\
                <td><input name='medicine_strengthhh[]' id='medicine_strengthhh' value='' /></td>\n\
                <td><input name='medicine_unittt[]' id='medicine_unittt' value='' /></td>\n\
                <td><input name='medicine_useee[]' id='medicine_useee' value='' /></td>\n\
                <td style='border: 1px solid #B5E4CB;'><input name='total_quantityyy[]' id='total_quantityyy' value='' /></td></tr>");
            
//                $('#srno').html('7+1');
                $("#dengue_ides").focus(); 
            });
            
//            $("#delete-more").on('click'function(){
//                $(this).parent().parent().remove();
//            });
            
        $('#removeee').on("click", function(){
            var id = $('#dengue_ides tr:last').find('td:first').html();
            if(id != 'Sr.No')
            {
               $('#dengue_ides tr:last').remove();
            }
            else{
                return false;
            }
        });
        
        $("#gender").change(function () {
//            alert($('#p_action_taken').val());
            if($('#gender').val() == '2')
            {
                $('#show_pregnant').show();
            }
            else{
                $("#pregnant").val($("#pregnant option:first").val());
//                $("#pregnant").val('');
//                $("#pregnant").prop("checked", false);
                $('#show_pregnant').hide();
            }
        });
        
        
        
        $("#species_pv_insert").click(function() {
               if($('#pv').val() == '1')
               {
                    var id = $('#species_pv_medicine_id tr:last').find('td:first').html()
                    if(id == 'Sr.No')
                    {
                        id = '0';
                        var new_id = ++id;
                    }
                    else{
                        new_id = ++id;
                    }
     //               alert($('#srnos').html());

     //            $('#species_pv_medicine_id tbody>tr:last')
     //                .clone(true)
     //                .insertAfter('#species_pv_medicine_id tbody>tr:last').find('input').each(function(){
     //                    $(this).val('');
     //                });
                     $("#species_pv_medicine_id").append("<tr id='uncomplicated_newrows'><td id='srno'>"+new_id+"</td>\n\
                     <td><input name='species_pv_names[]' id='species_pv_names' value='' /></td>\n\
                     <td><input name='species_pv_unit[]' id='species_pv_unit' value='' /></td>\n\
                     <td><input name='species_pv_strength[]' id='species_pv_strength' value='' /></td>\n\
                     <td style='border: 1px solid #B5E4CB;'><input name='species_pv_quantity[]' id='species_pv_quantity' value='' /></td>\n\
                     <td style='border: 1px solid #B5E4CB;'><textarea style='width: 100%; height: 100%;border: 1px solid black;' name='species_pv_comments[]' id='species_pv_comments'></textarea></td></tr>");

     //                $('#srno').html('7+1');
                     $("#species_pv_medicine_id").focus(); 
                 }
                 else{
                     
                     var id = $('#species_pv_medicine_id tr:last').find('td:first').html()
                    if(id == 'Sr.No')
                    {
                        id = '0';
                        var new_id = ++id;
                    }
                    else{
                        new_id = ++id;
                    }
     //               alert($('#srnos').html());

     //            $('#species_pv_medicine_id tbody>tr:last')
     //                .clone(true)
     //                .insertAfter('#species_pv_medicine_id tbody>tr:last').find('input').each(function(){
     //                    $(this).val('');
     //                });
                     $("#species_pv_medicine_id").append("<tr id='uncomplicated_newrows'><td id='srno'>"+new_id+"</td>\n\
                     <td><input name='species_pv_weight_id[]' id='species_pv_weight_id' value='' /></td>\n\
                        <td><input name='species_pv_names[]' id='species_pv_names' value='' /></td>\n\
                        <td><input name='species_pv_dose_kg[]' id='species_pv_dose_kg' value='' /></td>\n\
                        <td><input name='species_pv_dose_per_weight[]' id='species_pv_dose_per_weight' value='' /></td>\n\
                        <td><input name='species_pv_unit[]' id='species_pv_unit' value='' /></td>\n\
                        <td><input name='species_pv_strength[]' id='species_pv_strength' value='' /></td>\n\
                        <td style='border: 1px solid #B5E4CB;'><input name='species_pv_quantity[]' id='species_pv_quantity' value='' /></td>\n\
                        <td style='border: 1px solid #B5E4CB;'><textarea style='width: 100%; height: 100%;border: 1px solid black;' name='species_pv_comments[]' id='species_pv_comments'></textarea></td></tr>");

     //                $('#srno').html('7+1');
                     $("#species_pv_medicine_id").focus(); 
                     
                 }
            });
            
//            $("#delete-more").on('click'function(){
//                $(this).parent().parent().remove();
//            });
            
        $('#species_pv_remove').on("click", function(){
            var id = $('#species_pv_medicine_id tr:last').find('td:first').html();
            if(id != 'Sr.No')
            {
                $('#species_pv_medicine_id tr:last').remove();
            }
            else{
                return false;
            }
        });
        
        
        
        $("#species_pf_insert").click(function() {
                if($('#pf').val() == '1')
                {
                    var id = $('#species_pf_medicine_id tr:last').find('td:first').html()
                    if(id == 'Sr.No')
                    {
                        id = '0';
                        var new_id = ++id;
                    }
                    else{
                        new_id = ++id;
                    }
     //               alert($('#srnos').html());

     //            $('#species_pf_medicine_id tbody>tr:last')
     //                .clone(true)
     //                .insertAfter('#species_pf_medicine_id tbody>tr:last').find('input').each(function(){
     //                    $(this).val('');
     //                });
                     $("#species_pf_medicine_id").append("<tr id='uncomplicated_newrows'><td id='srno'>"+new_id+"</td>\n\
                     <td><input name='species_pf_names[]' id='species_pf_names' value='' /></td>\n\
                     <td><input name='species_pf_unit[]' id='species_pf_unit' value='' /></td>\n\
                     <td><input name='species_pf_strength[]' id='species_pf_strength' value='' /></td>\n\
                     <td style='border: 1px solid #B5E4CB;'><input name='species_pf_quantity[]' id='species_pf_quantity' value='' /></td>\n\
                     <td style='border: 1px solid #B5E4CB;'><textarea style='width: 100%; height: 100%;border: 1px solid black;' name='species_pf_comments[]' id='species_pf_comments'></textarea></td></tr>");

     //                $('#srno').html('7+1');
                     $("#species_pf_medicine_id").focus(); 
                 }
                 else{
                     
                     var id = $('#species_pf_medicine_id tr:last').find('td:first').html()
                    if(id == 'Sr.No')
                    {
                        id = '0';
                        var new_id = ++id;
                    }
                    else{
                        new_id = ++id;
                    }
     //               alert($('#srnos').html());

     //            $('#species_pf_medicine_id tbody>tr:last')
     //                .clone(true)
     //                .insertAfter('#species_pf_medicine_id tbody>tr:last').find('input').each(function(){
     //                    $(this).val('');
     //                });
                     $("#species_pf_medicine_id").append("<tr id='uncomplicated_newrows'><td id='srno'>"+new_id+"</td>\n\
                     <td><input name='species_pf_weight_id[]' id='species_pf_weight_id' value='' /></td>\n\
                        <td><input name='species_pf_names[]' id='species_pf_names' value='' /></td>\n\
                        <td><input name='species_pf_dose_kg[]' id='species_pf_dose_kg' value='' /></td>\n\
                        <td><input name='species_pf_dose_per_weight[]' id='species_pf_dose_per_weight' value='' /></td>\n\
                        <td><input name='species_pf_unit[]' id='species_pf_unit' value='' /></td>\n\
                        <td><input name='species_pf_strength[]' id='species_pf_strength' value='' /></td>\n\
                        <td style='border: 1px solid #B5E4CB;'><input name='species_pf_quantity[]' id='species_pf_quantity' value='' /></td>\n\
                        <td style='border: 1px solid #B5E4CB;'><textarea style='width: 100%; height: 100%;border: 1px solid black;' name='species_pf_comments[]' id='species_pf_comments'></textarea></td></tr>");

     //                $('#srno').html('7+1');
                     $("#species_pf_medicine_id").focus(); 
                     
                 }
            });
            
//            $("#delete-more").on('click'function(){
//                $(this).parent().parent().remove();
//            });
            
        $('#species_pf_remove').on("click", function(){
            var id = $('#species_pf_medicine_id tr:last').find('td:first').html();
            if(id != 'Sr.No')
            {
                $('#species_pf_medicine_id tr:last').remove();
            }
            else{
                return false;
            }
        });
        
        
        
        
        $("#species_mix_insert").click(function() {
                if($('#mix').val() == '1')
                {
                    var id = $('#species_mix_medicine_id tr:last').find('td:first').html()
                    if(id == 'Sr.No')
                    {
                        id = '0';
                        var new_id = ++id;
                    }
                    else{
                        new_id = ++id;
                    }
     //               alert($('#srnos').html());

     //            $('#species_pv_medicine_id tbody>tr:last')
     //                .clone(true)
     //                .insertAfter('#species_pv_medicine_id tbody>tr:last').find('input').each(function(){
     //                    $(this).val('');
     //                });
                     $("#species_mix_medicine_id").append("<tr id='uncomplicated_newrows'><td id='srno'>"+new_id+"</td>\n\
                     <td><input name='species_mix_names[]' id='species_mix_names' value='' /></td>\n\
                     <td><input name='species_mix_unit[]' id='species_mix_unit' value='' /></td>\n\
                     <td><input name='species_mix_strength[]' id='species_mix_strength' value='' /></td>\n\
                     <td style='border: 1px solid #B5E4CB;'><input name='species_mix_quantity[]' id='species_mix_quantity' value='' /></td>\n\
                     <td style='border: 1px solid #B5E4CB;'><textarea style='width: 100%; height: 100%;border: 1px solid black;' name='species_mix_comments[]' id='species_mix_comments'></textarea></td></tr>");

     //                $('#srno').html('7+1');
                     $("#species_mix_medicine_id").focus(); 
                 }
                 else if($('#p_treatment').val() != '3'){
                     
                     var id = $('#species_mix_medicine_id tr:last').find('td:first').html()
                    if(id == 'Sr.No')
                    {
                        id = '0';
                        var new_id = ++id;
                    }
                    else{
                        new_id = ++id;
                    }
     //               alert($('#srnos').html());

     //            $('#species_pv_medicine_id tbody>tr:last')
     //                .clone(true)
     //                .insertAfter('#species_pv_medicine_id tbody>tr:last').find('input').each(function(){
     //                    $(this).val('');
     //                });
                     $("#species_mix_medicine_id").append("<tr id='uncomplicated_newrows'><td id='srno'>"+new_id+"</td>\n\
                     <td><input name='species_mix_weight_id[]' id='species_mix_weight_id' value='' /></td>\n\
                        <td><input name='species_mix_names[]' id='species_mix_names' value='' /></td>\n\
                        <td><input name='species_mix_dose_kg[]' id='species_mix_dose_kg' value='' /></td>\n\
                        <td><input name='species_mix_dose_per_weight[]' id='species_mix_dose_per_weight' value='' /></td>\n\
                        <td><input name='species_mix_unit[]' id='species_mix_unit' value='' /></td>\n\
                        <td><input name='species_mix_strength[]' id='species_mix_strength' value='' /></td>\n\
                        <td style='border: 1px solid #B5E4CB;'><input name='species_mix_quantity[]' id='species_mix_quantity' value='' /></td>\n\
                        <td style='border: 1px solid #B5E4CB;'><textarea style='width: 100%; height: 100%;border: 1px solid black;' name='species_mix_comments[]' id='species_mix_comments'></textarea></td></tr>");

     //                $('#srno').html('7+1');
                     $("#species_mix_medicine_id").focus(); 
                     
                 }
            });
            
//            $("#delete-more").on('click'function(){
//                $(this).parent().parent().remove();
//            });
            
        $('#species_mix_remove').on("click", function(){
            var id = $('#species_mix_medicine_id tr:last').find('td:first').html();
            if(id != 'Sr.No')
            {
                $('#species_mix_medicine_id tr:last').remove();
            }
            else{
                return false;
            }
        });
        
        
        $("#species_normal_insert").click(function() {
               var id = $('#species_normal_medicine_id tr:last').find('td:first').html()
               if(id == 'Sr.No')
               {
                   id = '0';
                   var new_id = ++id;
               }
               else{
                   new_id = ++id;
               }
//               alert($('#srnos').html());
               
//            $('#species_pv_medicine_id tbody>tr:last')
//                .clone(true)
//                .insertAfter('#species_pv_medicine_id tbody>tr:last').find('input').each(function(){
//                    $(this).val('');
//                });
                $("#species_normal_medicine_id").append("<tr id='uncomplicated_newrows'><td id='srno'>"+new_id+"</td>\n\
                <td><input name='species_normal_names[]' id='species_normal_names' value='' /></td>\n\
                <td><input name='species_normal_unit[]' id='species_normal_unit' value='' /></td>\n\
                <td><input name='species_normal_strength[]' id='species_normal_strength' value='' /></td>\n\
                <td style='border: 1px solid #B5E4CB;'><input name='species_normal_quantity[]' id='species_normal_quantity' value='' /></td>\n\
                <td style='border: 1px solid #B5E4CB;'><textarea style='width: 100%; height: 100%;border: 1px solid black;' name='species_normal_comments[]' id='species_normal_comments'></textarea></td></tr>");
            
//                $('#srno').html('7+1');
                $("#species_normal_medicine_id").focus(); 
            });
            
//            $("#delete-more").on('click'function(){
//                $(this).parent().parent().remove();
//            });
            
        $('#species_normal_remove').on("click", function(){
            var id = $('#species_normal_medicine_id tr:last').find('td:first').html();
            if(id != 'Sr.No')
            {
                $('#species_normal_medicine_id tr:last').remove();
            }
            else{
                return false;
            }
        });
        
        
        
        $("#species_complicated_insert").click(function() {
               var id = $('#species_complicated_medicine_id tr:last').find('td:first').html()
               if(id == 'Sr.No') 
               {
                   id = '0';
                   var new_id = ++id;
               }
               else{
                   new_id = ++id;
               }
//               alert($('#srnos').html());
               
//            $('#species_pv_medicine_id tbody>tr:last')
//                .clone(true)
//                .insertAfter('#species_pv_medicine_id tbody>tr:last').find('input').each(function(){
//                    $(this).val('');
//                });
                $("#species_complicated_medicine_id").append("<tr id='uncomplicated_newrows'><td id='srno'>"+new_id+"</td>\n\
                <td><input name='species_complicated_weight_id[]' id='species_complicated_weight_id' value='' /></td>\n\
                <td><input name='species_complicated_names[]' id='species_complicated_names' value='' /></td>\n\
                <td><input name='species_complicated_dose_kg[]' id='species_complicated_dose_kg' value='' /></td>\n\
                <td><input name='species_complicated_dose_per_weight[]' id='species_complicated_dose_per_weight' value='' /></td>\n\
                <td><input name='species_complicated_unit[]' id='species_complicated_unit' value='' /></td>\n\
                <td><input name='species_complicated_strength[]' id='species_complicated_strength' value='' /></td>\n\
                <td style='border: 1px solid #B5E4CB;'><input name='species_complicated_quantity[]' id='species_complicated_quantity' value='' /></td>\n\
                <td style='border: 1px solid #B5E4CB;'><textarea style='width: 100%; height: 100%;border: 1px solid black;' name='species_complicated_comments[]' id='species_complicated_comments'></textarea></td></tr>");
            
//                $('#srno').html('7+1');
                $("#species_complicated_medicine_id").focus(); 
            });
            
//            $("#delete-more").on('click'function(){
//                $(this).parent().parent().remove();
//            });
            
        $('#species_complicated_remove').on("click", function(){
            var id = $('#species_complicated_medicine_id tr:last').find('td:first').html();
            if(id != 'Sr.No')
            {
                $('#species_complicated_medicine_id tr:last').remove();
            }
            else{
                return false;
            }
        });
        
        
        
        $("#patient_species").click(function () {
                var a = $('#p_treatment').val();
                if(a == '')
                {
                    $("#patient_species").val($("#patient_species option:first").val());
                    alert('Please Select Treatment First');
                    return false;
                }
        });
        
        $("#patient_species").change(function () {
//            alert($('#p_action_taken').val());
            if($('#patient_species').val() == '1')
            {
                var pregnant_stage = $('#pregnant_stage').val();
                var species_ide = $(this).val();
//                alert($('#p_treatment').val());
                var type = $('#p_treatment').val();
                var age_id = $('#age_id').val();
                var gender_id = $('#gender_id').val();
                var pregnant_id = $('#pregnant_id').val();
                var weight_id = $('#weight').val();
                var patient_month_id = $('#patient_month_id').val();
//                alert(age_id);
//                alert(gender_id);
//                alert(pregnant_id);
//                alert(weight_id);
//                  alert(patient_month_id);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('ajax/get_species_pf'); ?>",
                    data: {species_id: species_ide,type_id: type,age_id : age_id,gender_id : gender_id,pregnant_id : pregnant_id,weight_id: weight_id,patient_month_id: patient_month_id,pregnant_stage:pregnant_stage},
                    dataType: 'html',
                    success: function (response) {
//                         var user = JSON.parse(JSON.stringify(response));
//                        alert($.parseJSON(response));
//                        alert(response);
//                        var user = JSON.parse(response);
//                          console.log(user);
//                          alert(user);
                        $('#malaria_species_pf1').html(response);
//                        alert($('#malaria_species_pv').text('malaria_species_pv : ' + user));

//                        if(html != '') {
//                            $("#same_record").html(html);
//                            $("#modal").click();
//    //                        return true;
//                        }                    
//                        else
//                        {
//                            $("#patient_info").submit();
//                        }
                    }
                });
                
                $('#malaria_species_pv').hide();
                $('#malaria_species_pf').show();
                $('#malaria_species_mix').hide();
                $('#malaria_species_normal').hide();
                $('#malaria_species_complicated').hide();
                $('#malaria_severe_result').hide();
                $('#malaria_result').hide();
                $('#dengue_result').hide();
                
                
//                $('#malaria_severe_result').show();
//                $('#malaria_result').hide();
//                $('#dengue_result').hide();
            }
            if($('#patient_species').val() == '2')
            {
                var species_ide = $(this).val();
//                alert($('#p_treatment').val());
                var type = $('#p_treatment').val();
                var age_id = $('#age_id').val();
                var gender_id = $('#gender_id').val();
                var pregnant_id = $('#pregnant_id').val();
                var weight_id = $('#weight').val();
                var patient_month_id = $('#patient_month_id').val();
                var dose_kg = $('#dose_kg').val();
//                alert(type);
//                alert(weight_id);
////                alert(type);
//                alert(pregnant_id);
//                alert(weight_id);
//                  alert(patient_month_id);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('ajax/get_species_pv'); ?>",
                    data: {species_id: species_ide,type_id: type,age_id : age_id,gender_id : gender_id,pregnant_id : pregnant_id,weight_id: weight_id,patient_month_id: patient_month_id,dose_kg:dose_kg},
                    dataType: 'html',
                    success: function (response) {
//                         var user = JSON.parse(JSON.stringify(response));
//                        alert($.parseJSON(response));
//                        alert(response);
//                        var user = JSON.parse(response);
//                          console.log(user);
//                          alert(user);
                        $('#malaria_species_pv1').html(response);
//                        alert($('#malaria_species_pv').text('malaria_species_pv : ' + user));

//                        if(html != '') {
//                            $("#same_record").html(html);
//                            $("#modal").click();
//    //                        return true;
//                        }                    
//                        else
//                        {
//                            $("#patient_info").submit();
//                        }
                    }
                });
                
                $('#malaria_species_pv').show();
                $('#malaria_species_pf').hide();
                $('#malaria_species_mix').hide();
                $('#malaria_species_normal').hide();
                $('#malaria_species_complicated').hide();
                $('#malaria_severe_result').hide();
                $('#malaria_result').hide();
                $('#dengue_result').hide();
            }
            if($('#patient_species').val() == '3')
            {
            
            
            
                var species_ide = $(this).val();
                var pregnant_stage = $('#pregnant_stage').val();
//                alert($('#p_treatment').val());
                var type = $('#p_treatment').val();
                var age_id = $('#age_id').val();
                var gender_id = $('#gender_id').val();
                var pregnant_id = $('#pregnant_id').val();
                var weight_id = $('#weight').val();
                var patient_month_id = $('#patient_month_id').val();
//                alert(age_id);
//                alert(gender_id);
//                alert(pregnant_id);
//                alert(weight_id);
//                  alert(patient_month_id);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('ajax/get_species_mix'); ?>",
                    data: {species_id: species_ide,type_id: type,age_id : age_id,gender_id : gender_id,pregnant_id : pregnant_id,weight_id: weight_id,patient_month_id: patient_month_id,pregnant_stage:pregnant_stage},
                    dataType: 'html',
                    success: function (response) {
//                         var user = JSON.parse(JSON.stringify(response));
//                        alert($.parseJSON(response));
//                        alert(response);
//                        var user = JSON.parse(response);
//                          console.log(user);
//                          alert(user);
                        $('#malaria_species_mix1').html(response);
//                        alert($('#malaria_species_pv').text('malaria_species_pv : ' + user));

//                        if(html != '') {
//                            $("#same_record").html(html);
//                            $("#modal").click();
//    //                        return true;
//                        }                    
//                        else
//                        {
//                            $("#patient_info").submit();
//                        }
                    }
                });
                
                $('#malaria_species_pv').hide();
                $('#malaria_species_pf').hide();
                $('#malaria_species_mix').show();
                $('#malaria_species_normal').hide();
                $('#malaria_species_complicated').hide();
                $('#malaria_severe_result').hide();
                $('#malaria_result').hide();
                $('#dengue_result').hide();
            
            
//                $('#malaria_severe_result').hide();
//                $('#malaria_result').show();
//                $('#dengue_result').hide();
            }
            
            if($('#patient_species').val() == '4')
            {
            
            
            
                var species_ide = $(this).val();
//                alert($('#weight').val());
                var type = $('#p_treatment').val();
                var age_id = $('#age_id').val();
                var gender_id = $('#gender_id').val();
                var pregnant_id = $('#pregnant_id').val();
                var weight_id = $('#weight').val();
                var patient_month_id = $('#patient_month_id').val();
//                alert(age_id);
//                alert(gender_id);
//                alert(pregnant_id);
//                alert(weight_id);
//                  alert(patient_month_id);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('ajax/get_species_normal'); ?>",
                    data: {species_id: species_ide,type_id: type,age_id : age_id,gender_id : gender_id,pregnant_id : pregnant_id,weight_id: weight_id,patient_month_id: patient_month_id},
                    dataType: 'html',
                    success: function (response) {
//                         var user = JSON.parse(JSON.stringify(response));
//                        alert($.parseJSON(response));
//                        alert(response);
//                        var user = JSON.parse(response);
//                          console.log(user);
//                          alert(user);
                        $('#malaria_species_normal1').html(response);
//                        alert($('#malaria_species_pv').text('malaria_species_pv : ' + user));

//                        if(html != '') {
//                            $("#same_record").html(html);
//                            $("#modal").click();
//    //                        return true;
//                        }                    
//                        else
//                        {
//                            $("#patient_info").submit();
//                        }
                    }
                    
                });
                
                $('#malaria_species_pv').hide();
                $('#malaria_species_pf').hide();
                $('#malaria_species_mix').hide();
                $('#malaria_species_normal').show();
                $('#malaria_species_complicated').hide();
                $('#malaria_severe_result').hide();
                $('#malaria_result').hide();
                $('#dengue_result').hide();
            
            
//                $('#malaria_severe_result').hide();
//                $('#malaria_result').show();
//                $('#dengue_result').hide();
            }
          
          if($('#patient_species').val() == '5')
            {
            
            
            
                var species_ide = $(this).val();
//                alert($('#weight').val());
                var type = $('#p_treatment').val();
                var age_id = $('#age_id').val();
                var gender_id = $('#gender_id').val();
                var pregnant_id = $('#pregnant_id').val();
                var weight_id = $('#weight').val();
                var patient_month_id = $('#patient_month_id').val();
//                alert(age_id);
//                alert(gender_id);
//                alert(pregnant_id);
//                alert(weight_id);
//                  alert(patient_month_id);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('ajax/get_species_complicated'); ?>",
                    data: {species_id: species_ide,type_id: type,age_id : age_id,gender_id : gender_id,pregnant_id : pregnant_id,weight_id: weight_id,patient_month_id: patient_month_id},
                    dataType: 'html',
                    success: function (response) {
//                         var user = JSON.parse(JSON.stringify(response));
//                        alert($.parseJSON(response));
//                        alert(response);
//                        var user = JSON.parse(response);
//                          console.log(user);
//                          alert(user);
                        $('#malaria_species_complicatede').html(response);
//                        alert($('#malaria_species_pv').text('malaria_species_pv : ' + user));

//                        if(html != '') {
//                            $("#same_record").html(html);
//                            $("#modal").click();
//    //                        return true;
//                        }                    
//                        else
//                        {
//                            $("#patient_info").submit();
//                        }
                    }
                    
                });
                
                $('#malaria_species_pv').hide();
                $('#malaria_species_pf').hide();
                $('#malaria_species_mix').hide();
                $('#malaria_species_normal').hide();
                $('#malaria_species_complicated').show();
                $('#malaria_severe_result').hide();
                $('#malaria_result').hide();
                $('#dengue_result').hide();
            
            
//                $('#malaria_severe_result').hide();
//                $('#malaria_result').show();
//                $('#dengue_result').hide();
            }
          
        });
        
        $('#age').on("keyup", function(){
            if($(this).val() <= '0')
            {
                $('#patient_months').show();
            }
            else{
                $('#patient_months').hide();
                $('#patient_month').val('');
            }
        });
        
        $('#age').on("keyup keydown", function(){
            if($(this).val() < 13)
            {
                $("#marital").prop("disabled", true);
                $('#marital option[value="2"]').prop('selected', true);
            }
            else{
                $("#marital").prop("disabled", false);
            }
        });
        
        $("#patient_month").on("keypress", function(e){
            var currentValue = String.fromCharCode(e.which);
            var finalValue = $(this).val() + currentValue;
//            if(finalValue < 35){
//                e.preventDefault();
//            }
            if(finalValue > 12){
                e.preventDefault();
            }
        });
        
        if($('#age').val() == '0')
        {
            $('#patient_months').show();
        }
        else{
            $('#patient_months').hide();
            $('#patient_month').val('');
        }
        
        if($('#gender_id').val() == '2')
        {
            $('#show_pregnant').show();
        }
        else{
            $('#show_pregnant').hide();
        }
        
        $("#additional_info").validate({
            rules: {
                father_guardian_name: {
                    lettersonly: true
                },
                father_guardian_nic: {
                    number: true,
                    maxlength: 13

                },
//                province : {
//                    province: "required needsSelection"
//                }
            },
            ignore: [],
//            ignore: ':hidden:not("#province")', // Tells the validator to check the hidden select
//            ignore : ".ignore, :hidden",
//            errorClass: 'invalid'
        });

        $("#weight").on("keypress", function(e){
            var currentValue = String.fromCharCode(e.which);
            var finalValue = $(this).val() + currentValue;
            if(finalValue > 200){
                e.preventDefault();
            }
        });
        
        $("#malaria_temp").on("keypress", function(e){
            var currentValue = String.fromCharCode(e.which);
            var finalValue = $(this).val() + currentValue;
//            if(finalValue < 35){
//                e.preventDefault();
//            }
            if(finalValue > 105.9){
                e.preventDefault();
            }
        });
        
        $("#dengue_temp").on("keypress", function(e){
            var currentValue = String.fromCharCode(e.which);
            var finalValue = $(this).val() + currentValue;
//            if(finalValue < 35){
//                e.preventDefault();
//            }
            if(finalValue > 105.9){
                e.preventDefault();
            }
        });
        
//        $(document).ready(function(){
//            $("#disease_date").datepicker({
//                format: 'dd/mm/yyyy',
//                autoclose: true,
//            });
//        });
        
        $(document).ready(function(){
            $("#dengue_sample_date").datepicker({
                startDate: new Date(),
                format: 'dd/mm/yyyy',
                autoclose: true,
            });
        });
        
        $(document).ready(function(){
            $("#time_since_onset").datetimepicker({
                minDate : 0,
                format: 'd/m/y H:i A',
                autoclose: true,
            });
        });
        
        $(document).ready(function(){
            $("#sample_date").datepicker({
                startDate: new Date(),
                format: 'dd/mm/yyyy',
                autoclose: true,
            });
        });
        
        
</script>
