<script>
    $(function () {
//        $('#myElem').hide();
        var max = 11;
        $('#patient_mobileno').keypress(function (e) {
            if (e.which < 0x20) {
                // e.which < 0x20, then it's not a printable character
                // e.which === 0 - Not a character
                return;     // Do nothing
            }
            if (this.value.length == max) {
                e.preventDefault();
            } else if (this.value.length > max) {
                // Maximum exceeded
                this.value = this.value.substring(0, max);
            }
        });
        $('#reporter_mobileno').keypress(function (e) {
            if (e.which < 0x20) {
                // e.which < 0x20, then it's not a printable character
                // e.which === 0 - Not a character
                return;     // Do nothing
            }
            if (this.value.length == max) {
                e.preventDefault();
            } else if (this.value.length > max) {
                // Maximum exceeded
                this.value = this.value.substring(0, max);
            }
        });
        $('#p_mobileno').keypress(function (e) {
            if (e.which < 0x20) {
                // e.which < 0x20, then it's not a printable character
                // e.which === 0 - Not a character
                return;     // Do nothing
            }
            if (this.value.length == max) {
                e.preventDefault();
            } else if (this.value.length > max) {
                // Maximum exceeded
                this.value = this.value.substring(0, max);
            }
        });
       $("#add_form").validate({
            rules: {
                patient_mobileno: {
                    number: true,
                    minlength: 11,
                    maxlength: 11
                },
                reporter_mobileno: {
                    number: true,
                    minlength: 11,
                    maxlength: 11
                },
                reporter_email: {
                    emailfull: true
                }
//                province : {
//                    province: "required needsSelection"
//                }
            },
            ignore: [],
//            ignore: ':hidden:not("#province")', // Tells the validator to check the hidden select
//            ignore : ".ignore, :hidden",
//            errorClass: 'invalid'
        });
        jQuery.validator.addMethod("emailfull", function(value, element) {
            return this.optional(element) || /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i.test(value);
           }, "Please enter valid email address!");
        jQuery.validator.addMethod("p_email", function(value, element) {
         return this.optional(element) || /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i.test(value);
        }, "Please enter valid email address!");
    });
    function calculate_age(dob, method) {
            if (method == 'age2dob') {
                var birthDate = moment().subtract(dob, 'years');
                $("#day").val(birthDate.format("D"));
                $("#month").val(birthDate.format("M"));
                $("#year").val(birthDate.format("YYYY"));
            } else {
                var dob = $("#year").val() + '-' + $("#month").val() + '-' + $("#day").val();
                var a = moment();
                var b = moment(dob, "YYYY-MM-DD");
                var age_dt = a.diff(b, 'years');

                $("#age").val(age_dt);
            }
        }
        
        $("#patient_disease").change(function () {
            if($(this).val() == '2')
            {
                $('#leishmania_info').show();
            }
            else{
                $('#leishmania_info').hide();
            }
        });
        $("#patient_disease").change(function () {
            if($(this).val() == '1' || $(this).val() == '3')
            {
                $('#malaria_info').show();
            }
            else{
                $('#malaria_info').hide();
            }
        });
        
        $("#trainee_name").change(function(){
            var value = $(this).val();
//            alert(value);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/training_combo"); ?>',
                data: {
                    id: value,
                    lvl: 4
                },
                dataType: 'json',
                success: function (data) {
                    var user = JSON.parse(JSON.stringify(data));
//                    alert(user.warehouse_name);
                    if(user.gender != '')
                    {
                        $("#gender").val(user.gender);
                    }
                    else{
                        $("#gender").val('');
                    }
                    if(user.staff_desg != '')
                    {
                        $("#designation").val(user.desg);
                    }
                    else{
                        $("#designation").val('');
                    }
                    if(user.staff_contact_no != '')
                    {
                        $("#contact_no").val(user.contact_no);
                    }
                    else{
                        $("#contact_no").val('');
                    }
                    if(user.staff_cnic != '')
                    {
                        $("#cnic_no").val(user.cnic);
                    }
                    else{
                        $("#cnic_no").val('');
                    }
                    if(user.warehouse_name != '')
                    {
                        $("#health_facility").val(user.warehouse_name);
                    }
                    else{
                        $("#health_facility").val('');
                    }
                    if(user.location_name != '')
                    {
                        $("#district").val(user.location_name);
                    }
                    else{
                        $("#district").val('');
                    }
//                    $("#public_private").val(user.gender);
//                    $("#district").select2("val", "");
//                    $("#tehsil").select2("val", "");
//                    $("#uc").select2("val", "");
//                    $('#district').html(data);
                }
            });
//            $.ajax({
//                type: "POST",
//                url: '<?php echo base_url("ajax/cities"); ?>',
//                data: {
//                    province_id: value
//                },
//                dataType: 'html',
//                success: function (data) {
//                    $('#city').html(data);
//                }
//            });
        }).change();
        
//        $("#start_date, #end_date").datepicker({
//            'format': 'dd/mm/yyyy'
//        });
//        $("#start_date").datepicker().on('changeDate', function(selected){
//        startDate = new Date(selected.date.valueOf());
//        $('#end_date').datepicker('setStartDate', startDate);
//    });  
//
//    $("#end_date").datepicker().on('changeDate', function(selected){
//        startDate = new Date(selected.date.valueOf());
//        $('#start_date').datepicker('setEndDate', startDate);
//    });

        $(document).ready(function(){
   $("#start_date").datepicker({
       format: 'dd/mm/yyyy',
       autoclose: true,
   }).on('changeDate', function (selected) {
       var minDate = new Date(selected.date.valueOf());
       $('#end_date').datepicker('setStartDate', minDate);
   });

   $("#end_date").datepicker({
       format: 'dd/mm/yyyy',
       autoclose: true,
   }).on('changeDate', function (selected) {
           var minDate = new Date(selected.date.valueOf());
           $('#start_date').datepicker('setEndDate', minDate);
   });
});


//    $('.table').on("input", ".subtotal", function() {
//      let sum = 0;
//      $(".subtotal").each(function(){
//        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
//      });
//      $(".total").val(sum);
//    });
//    
//    $('.table').on("input", ".subtotal1", function() {
//      let sum = 0;
//      $(".subtotal1").each(function(){
//        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
//      });
//      $(".total1").val(sum);
//    });
//    
//    $('.table').on("input", ".subtotal2", function() {
//      let sum = 0;
//      $(".subtotal2").each(function(){
//        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
//      });
//      $(".total2").val(sum);
//    });
//    
//    $('.table').on("input", ".subtotal3", function() {
//      let sum = 0;
//      $(".subtotal3").each(function(){
//        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
//      });
//      $(".total3").val(sum);
//    });
//    
//    $('.table').on("input", ".subtotal4", function() {
//      let sum = 0;
//      $(".subtotal4").each(function(){
//        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
//      });
//      $(".total4").val(sum);
//    });
//    
//    $('.table').on("input", ".subtotal5", function() {
//      let sum = 0;
//      $(".subtotal5").each(function(){
//        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
//      });
//      $(".total5").val(sum);
//    });
//    
//    $('.table').on("input", ".subtotal6", function() {
//      let sum = 0;
//      $(".subtotal6").each(function(){
//        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
//      });
//      $(".total6").val(sum);
//    });
    
    
//    $('.table').on("input", ".subtotal7", function() {
//      let sum = 0;
//      $(".subtotal7").each(function(){
//        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
//      });
//      $(".total7").val(sum);
//    });
//    
//    $('.table').on("input", ".subtotal8", function() {
//      let sum = 0;
//      $(".subtotal8").each(function(){
//        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
//      });
//      $(".total8").val(sum);
//    });
    
    
    
    
//    for (let i = 0; i < document.getElementById("consolidated_info").rows.length; i++) {
//        
//        $('.table').on("input", ".subtotal5"+[i], ".subtotal3"+[i], function() {
//          let sum = 0;
//          let sum1 = 0;
//          let sum2 = 0;
//          $(".subtotal5"+[i]).each(function(){
//            sum1 += $(this).is('input') ? +$(this).val() : +$(this).text();
//          });
//          $(".subtotal3"+[i]).each(function(){
//            sum2 += $(this).is('input') ? +$(this).val() : +$(this).text();
//          });
//          sum = sum1 - sum2;
//          $(".subtotal7"+[i]).val(sum);
//        });
//    
//    }
//    
//    
//    
//    
//    for (let i = 0; i < document.getElementById("consolidated_info").rows.length; i++) {
//        
//        $('.table').on("input", ".subtotal6"+[i], ".subtotal4"+[i], function() {
//          let sum = 0;
//          let sum1 = 0;
//          let sum2 = 0;
//          $(".subtotal6"+[i]).each(function(){
//            sum1 += $(this).is('input') ? +$(this).val() : +$(this).text();
//          });
//          $(".subtotal4"+[i]).each(function(){
//            sum2 += $(this).is('input') ? +$(this).val() : +$(this).text();
//          });
//          sum = sum1 - sum2;
//          $(".subtotal8"+[i]).val(sum);
//        });
//    
//    }
//    alert($(".subtotal7"+2).val());

        let count = 0;
//    $('.table').on("input" ,function() {
        for (let i = 1; i <= $('input[name="distname[]"]').length; i++) {
            if($(".hf_name"+[i]).val() != '')
            {
                $(".hf_name"+[i]).each(function(){
                  count += $(this).is('input') ? +$(this).val() : +$(this).text();
                });
                $(".total").val(count);
            }
//            alert($(".total").val(count));
        }
        
        let count1 = 0;
//    $('.table').on("input" ,function() {
        for (let i = 1; i <= $('input[name="distname[]"]').length; i++) {
            if($(".total_screened"+[i]).val() != '')
            {
                $(".total_screened"+[i]).each(function(){
                  count1 += $(this).is('input') ? +$(this).val() : +$(this).text();
                });
                $(".total1").val(count1);
            }
//            alert($(".total7").val(sume));
        }
        
        let count2 = 0;
//    $('.table').on("input" ,function() {
        for (let i = 1; i <= $('input[name="distname[]"]').length; i++) {
            if($(".total_positive"+[i]).val() != '')
            {
                $(".total_positive"+[i]).each(function(){
                  count2 += $(this).is('input') ? +$(this).val() : +$(this).text();
                });
                $(".total2").val(count2);
            }
//            alert($(".total7").val(sume));
        }
        
        let count3 = 0;
//    $('.table').on("input" ,function() {
        for (let i = 1; i <= $('input[name="distname[]"]').length; i++) {
            if($(".nagative_slides_sent"+[i]).val() != '')
            {
                $(".nagative_slides_sent"+[i]).each(function(){
                  count3 += $(this).is('input') ? +$(this).val() : +$(this).text();
                });
                $(".total3").val(count3);
            }
//            alert($(".total7").val(sume));
        }
        
        let count4 = 0;
//    $('.table').on("input" ,function() {
        for (let i = 1; i <= $('input[name="distname[]"]').length; i++) {
            if($(".positive_slides_sent"+[i]).val() != '')
            {
                $(".positive_slides_sent"+[i]).each(function(){
                  count4 += $(this).is('input') ? +$(this).val() : +$(this).text();
                });
                $(".total4").val(count4);
            }
//            alert($(".total7").val(sume));
        }
        
        let count5 = 0;
//    $('.table').on("input" ,function() {
        for (let i = 1; i <= $('input[name="distname[]"]').length; i++) {
            if($(".negative_slides_receive"+[i]).val() != '')
            {
                $(".negative_slides_receive"+[i]).each(function(){
                  count5 += $(this).is('input') ? +$(this).val() : +$(this).text();
                });
                $(".total5").val(count5);
            }
//            alert($(".total7").val(sume));
        }
        
        let count6 = 0;
//    $('.table').on("input" ,function() {
        for (let i = 1; i <= $('input[name="distname[]"]').length; i++) {
            if($(".positive_slides_receive"+[i]).val() != '')
            {
                $(".positive_slides_receive"+[i]).each(function(){
                  count6 += $(this).is('input') ? +$(this).val() : +$(this).text();
                });
                $(".total6").val(count6);
            }
//            alert($(".total7").val(sume));
        }
        
        let count7 = 0;
        for (let i = 1; i <= $('input[name="distname[]"]').length; i++) {
            if($(".negative_slides_variance"+[i]).val() != '')
            {
                $(".negative_slides_variance"+[i]).each(function(){
                  count7 += $(this).is('input') ? +$(this).val() : +$(this).text();
                });
                $(".total7").val(count7);
            }
        }
        
        let count8 = 0;
        for (let i = 1; i <= $('input[name="distname[]"]').length; i++) {
            if($(".positive_slides_variance"+[i]).val() != '')
            {
                $(".positive_slides_variance"+[i]).each(function(){
                  count8 += $(this).is('input') ? +$(this).val() : +$(this).text();
                });
                $(".total8").val(count8);
            }
        }
        
        if($(".total3").val() != '' || $(".total4").val() != '')
        {
            var a=parseInt($(".total3").val());
            var b=parseInt($(".total4").val());
            var final_total = a + b ;
    //        alert(final_total);
            $(".final_total1").val(final_total);
        }
        
        if($(".total5").val() != '' || $(".total6").val() != '')
        {
            var a=parseInt($(".total5").val());
            var b=parseInt($(".total6").val());
            var final_total = a + b ;
    //        alert(final_total);
            $(".final_total2").val(final_total);
        }
        
        if($(".total7").val() != '' || $(".total8").val() != '')
        {
            var a=parseInt($(".total7").val());
            var b=parseInt($(".total8").val());
            var final_total = a + b ;
    //        alert(final_total);
            $(".final_total3").val(final_total+'%');
        }

//    });
    
    $('.hftable').on("input", ".hfsubtotal", function() {
      let sum = 0;
      $(".hfsubtotal").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".hftotal").val(sum);
    });
    
     $('.hftable').on("input", ".hfsubtotal1", function() {
      let sum = 0;
      $(".hfsubtotal1").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".hftotal1").val(sum);
    });
    
    $('.hftable').on("input", ".hfsubtotal3", function() {
      let sum = 0;
      $(".hfsubtotal3").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".hftotal3").val(sum);
    });
    
    $('.hftable').on("input", ".hfsubtotal4", function() {
      let sum = 0;
      $(".hfsubtotal4").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".hftotal4").val(sum);
    });
    
    $('.hftable').on("input", ".hfsubtotal5", function() {
      let sum = 0;
      $(".hfsubtotal5").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".hftotal5").val(sum);
    });
    
    $('.hftable').on("input", ".hfsubtotal6", function() {
      let sum = 0;
      $(".hfsubtotal6").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".hftotal6").val(sum);
    });
    
    $('.hftable').on("input", ".hfsubtotal7", function() {
      let sum = 0;
      $(".hfsubtotal7").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".hftotal7").val(sum);
    });
    
    $('.hftable').on("input", ".hfsubtotal8", function() {
      let sum = 0;
      $(".hfsubtotal8").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".hftotal8").val(sum);
    });
    
    $('.hftable').on("input", ".hfsubtotal9", function() {
      let sum = 0;
      $(".hfsubtotal9").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".hftotal9").val(sum);
    });
    
    $('.hftable').on("input", ".hfsubtotal10", function() {
      let sum = 0;
      $(".hfsubtotal10").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".hftotal10").val(sum);
    });
    
    
    
    for (let i = 0; i < document.getElementById("consolidated_info").rows.length; i++) {
        
        $('.hftable').on("input", ".total_screened"+[i], ".total_positive"+[i], function() {
//            alert('saad');
          let sum = 0;
          let sum1 = 0;
          let sum2 = 0;
          $(".total_screened"+[i]).each(function(){
            sum1 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          $(".total_positive"+[i]).each(function(){
            sum2 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          sum = sum1 - sum2;
          $(".total_negative"+[i]).val(sum);
        });
    
    } 
   
    
    for (let i = 0; i < document.getElementById("consolidated_info").rows.length; i++) {
        
        $('.hftable').on("input", ".total_positive"+[i], ".total_screened"+[i], function() {
//            alert('saad');
          let sum = 0;
          let sum1 = 0;
          let sum2 = 0;
          $(".total_screened"+[i]).each(function(){
            sum1 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          $(".total_positive"+[i]).each(function(){
            sum2 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          sum = sum1 - sum2;
          $(".total_negative"+[i]).val(sum);
        });
    
    }
    
    
    for (let i = 0; i < document.getElementById("consolidated_info").rows.length; i++) {
        
        $('.hftable').on("input", ".negative_slides_receive"+[i], ".nagative_slides_sent"+[i], function() {
//            alert('saad');
          let sum = 0;
          let sum1 = 0;
          let sum2 = 0;
          $(".negative_slides_receive"+[i]).each(function(){
            sum1 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          $(".nagative_slides_sent"+[i]).each(function(){
            sum2 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          sum = sum1 - sum2;
          $(".negative_slides_variance"+[i]).val(sum);
        });
    
    }
    
    
    for (let i = 0; i < document.getElementById("consolidated_info").rows.length; i++) {
        
        $('.hftable').on("input", ".nagative_slides_sent"+[i], ".negative_slides_receive"+[i], function() {
//            alert('saad');
          let sum = 0;
          let sum1 = 0;
          let sum2 = 0;
          $(".negative_slides_receive"+[i]).each(function(){
            sum1 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          $(".nagative_slides_sent"+[i]).each(function(){
            sum2 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          sum = sum1 - sum2;
          $(".negative_slides_variance"+[i]).val(sum);
        });
    
    }
    
    
    for (let i = 0; i < document.getElementById("consolidated_info").rows.length; i++) {
        
        $('.hftable').on("input", ".positive_slides_receive"+[i], ".positive_slides_sent"+[i], function() {
//            alert('saad');
          let sum = 0;
          let sum1 = 0;
          let sum2 = 0;
          $(".positive_slides_receive"+[i]).each(function(){
            sum1 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          $(".positive_slides_sent"+[i]).each(function(){
            sum2 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          sum = sum1 - sum2;
          $(".positive_slides_variance"+[i]).val(sum);
        });
    
    }
    
    
    for (let i = 0; i < document.getElementById("consolidated_info").rows.length; i++) {
        
        $('.hftable').on("input", ".positive_slides_sent"+[i], ".positive_slides_receive"+[i], function() {
//            alert('saad');
          let sum = 0;
          let sum1 = 0;
          let sum2 = 0;
          $(".positive_slides_receive"+[i]).each(function(){
            sum1 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          $(".positive_slides_sent"+[i]).each(function(){
            sum2 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          sum = sum1 - sum2;
          $(".positive_slides_variance"+[i]).val(sum);
        });
    
    }
    
    
    $('.table').on("input" ,function() {
        
        if($(".hfsubtotal2").val() != '')
        {
            let sum = 0;
            $(".hfsubtotal2").each(function(){
              sum += $(this).is('input') ? +$(this).val() : +$(this).text();
            });
            $(".hftotal2").val(sum);
        }
        
        if($(".hfsubtotal11").val() != '')
        {
            let sum = 0;
            $(".hfsubtotal11").each(function(){
              sum += $(this).is('input') ? +$(this).val() : +$(this).text();
            });
            $(".hftotal11").val(sum);
        }
        
        if($(".hfsubtotal12").val() != '')
        {
            let sum = 0;
            $(".hfsubtotal12").each(function(){
              sum += $(this).is('input') ? +$(this).val() : +$(this).text();
            });
            $(".hftotal12").val(sum);
        }
    });
    
    
//    function printDiv() 
//    {
//
//      var divToPrint=document.getElementById('divToPrint');
//
//      var newWin=window.open('','Print-Window');
//
//      newWin.document.open();
//
//      newWin.document.write('<html><body onload="window.print()">'+divToPrint.innerHTML+'</body></html>');
//
//      newWin.document.close();
//
//      setTimeout(function(){newWin.close();},10);
//
//    }
    
</script>