<!-- MENU Start -->
<div class="navbar-custom">
    <div class="container-fluid">

        <div id="navigation">

            <?php
            //                print_r($_SESSION['approval_code_id']);exit;
            //                $assigned_code_touser = implode(",", $_SESSION['approval_code_id']);
            $assigned_code_touser = $_SESSION['approval_code_id'];

            $sql = "SELECT
                        GROUP_CONCAT( assign_approval_to_user.approval_code_id ) AS approval_code_id,
                        GROUP_CONCAT( approval_code.approval_code ) AS approval_code,
                        GROUP_CONCAT( approval_code.process_status ) AS process_status,
                        GROUP_CONCAT( a.`name` ) AS document_name,
                        GROUP_CONCAT( b.`name` ) AS approver_designation,
                        GROUP_CONCAT( b.`pk_id` ) AS approver_desg_id,
                        GROUP_CONCAT( approver_configration.approve_from ) AS approve_from,
                        GROUP_CONCAT( approver_configration.approve_to ) AS approve_to,
                        GROUP_CONCAT( approval_code.final ) AS final_status,
                        GROUP_CONCAT( approval_code.processid ) AS processid
                FROM
                        assign_approval_to_user
                        INNER JOIN approval_code ON assign_approval_to_user.approval_code_id = approval_code.pk_id
                        INNER JOIN list_detail AS a ON approval_code.document_id = a.pk_id
                        INNER JOIN list_detail AS b ON approval_code.approver_designation = b.pk_id
                        INNER JOIN approver_configration ON approval_code.pk_id = approver_configration.pk_id 
                WHERE
                        assign_approval_to_user.user_id = '" . $_SESSION['id'] . "' 
                        ";
            $approval_code = $this->db->query($sql);
            if ($approval_code->num_rows() > 0) {
//                            if ($approval_code) {
                //fetch results
                foreach ($approval_code->result() AS $row) {
                    $approval_codess = preg_split("/\,/", $row->approval_code);
                    $approval_code_idd = preg_split("/\,/", $row->approval_code_id);
                    $approve_fromm = preg_split("/\,/", $row->approve_from);
                    $approve_too = preg_split("/\,/", $row->approve_to);
                    $process_statuss = preg_split("/\,/", $row->process_status);
                    $final_statuss = preg_split("/\,/", $row->final_status);
                    $approver_designation = preg_split("/\,/", $row->approver_designation);
                    $approver_desg_id = preg_split("/\,/", $row->approver_desg_id);
                    $processid = preg_split("/\,/", $row->processid);
                    $document_name = preg_split("/\,/", $row->document_name);
                    $approvalcount = count($approval_codess);
//                                   print_r($approval_codess);exit;
                }
//                            }
            }
            ?>
            <ul class="navigation-menu">

                <li><a href="<?php echo base_url('/dashboard/index'); ?>">Dashboard</a></li>
<?php if($_SESSION['id'] == '159')  {?>
                
                    <li class="has-submenu">
                        <a href="#"><i class="icon-setting-1"></i> Admin Configurations <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                        <ul class="submenu megamenu">

                            <li>
                                <ul>

                                </ul>
                            </li>   
                                                        

                            <li>
                                <ul>
                                    

                                </ul>
                            </li>
                            <li>
                                <ul>


                                </ul>
                            </li>
                            
                            
                            <div class="col-md-12 row">
                            <div class="col-md-6">
                                <div class="">
                                    <p style="font-size: 14px;color:#1F8564;"><b>ORGANIZATION</b></p>
                                    
                                    <!--<div><span style="display:inline-block; width: 180px;">Stakeholder Category </span>: <a  href="<?php echo base_url('/productcategory_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productcategory_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->   
                                    <div><span style="display:inline-block; width: 180px;">Stakeholder/Departments </span>: <a  href="<?php echo base_url('/stakeholder_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/stakeholder_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Funding Source </span>: <a  href="<?php echo base_url('/fundingsource_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/fundingsource_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <!--<div><span style="display:inline-block; width: 180px;">Warehouse / Store / HFs </span>: <a  href="<?php echo base_url('/warehouse_management/view_warehouse'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/warehouse_management/add_warehouse'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                    <div><span style="display:inline-block; width: 180px;">Issue To Center </span>: <a  href="<?php echo base_url('/warehouse_management/view_issue_to_center'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/warehouse_management/add_issue_to_center'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Storage </span>: <a  href="<?php echo base_url('/lists_management/index/16'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/lists_management/add/16'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
<!--                                    <div><span style="display:inline-block; width: 180px;">Cities  </span>: <a href="<?php echo base_url('/Cities_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/Cities_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>   
                                    <div><span style="display:inline-block; width: 180px;">Test Sample Types</span>: <a href="<?php echo base_url('/Test_sample_types/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/Test_sample_types/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>      
                                    <div><span style="display:inline-block; width: 180px;">Facilities Types  </span>: <a href="<?php echo base_url('/wh_types_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/wh_types_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>      
                                    <div><span style="display:inline-block; width: 180px;">Facilities Category  </span>: <a href="<?php echo base_url('/wh_categories_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/wh_categories_management/add_wh_category'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>   
                                    <div><span style="display:inline-block; width: 180px;">External Systems  </span>: <a  href="<?php echo base_url('/externalsystems_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/externalsystems_management/add_ext_system'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>   -->
                                    <br>
                                    <p style="font-size: 14px;color:#1F8564;"><b>PRODUCT</b></p>
                                    
                                    <div><span style="display:inline-block; width: 180px;">Product Data Elements </span>: <a  href="<?php echo base_url('/field_list/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/field_list/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Product Category </span>: <a  href="<?php echo base_url('/category_list/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/category_list/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>   
                                    <div><span style="display:inline-block; width: 180px;">Product Type </span>: <a  href="<?php echo base_url('/lists_management/index/6'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/lists_management/add/6'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Product Generic Names </span>: <a  href="<?php echo base_url('/productgeneric_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productgeneric_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>   
                                    <div><span style="display:inline-block; width: 180px;">Product Strength </span>: <a  href="<?php echo base_url('/productstrength_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productstrength_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>   
                                    <div><span style="display:inline-block; width: 180px;">Product Method </span>: <a  href="<?php echo base_url('/productmethodtype_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productmethodtype_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>   
                                    <div><span style="display:inline-block; width: 180px;">Product Unit </span>: <a  href="<?php echo base_url('/lists_management/index/7'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/lists_management/add/7'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Product </span>: <a  href="<?php echo base_url('/product_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/product_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>   
                                    <div><span style="display:inline-block; width: 180px;">Product Mapping </span>: <a  href="<?php echo base_url('/assign_resources/add'); ?>"><i class="fa fa-search"></i>View/<i class="fa fa-plus-circle"></i>ADD </a></div>   
                                    <div><span style="display:inline-block; width: 180px;">Manufacturer </span>: <a  href="<?php echo base_url('/productmanufacturer_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productmanufacturer_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Suppliers </span>: <a  href="<?php echo base_url('/warehouse_management/view_supplier'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/warehouse_management/add_supplier'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    
                                    
                                    
<!--                                    <div><span style="display:inline-block; width: 180px;">Patient Disease </span>: <a  href="<?php echo base_url('/patientdisease_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/patientdisease_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div> 
                                    <div><span style="display:inline-block; width: 180px;">Lab </span>: <a  href="<?php echo base_url('/medicine_lab_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/medicine_lab_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div> 
                                    <div><span style="display:inline-block; width: 180px;">Lab Test </span>: <a  href="<?php echo base_url('/patient_lab_test_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/patient_lab_test_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div> 
                                    <div><span style="display:inline-block; width: 180px;">Designation </span>: <a  href="<?php echo base_url('/designation_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/designation_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Hr Type </span>: <a  href="<?php echo base_url('/hr_type_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/hr_type_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Malaria Status </span>: <a  href="<?php echo base_url('/malaria_status_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/malaria_status_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Public/Private </span>: <a  href="<?php echo base_url('/public_private_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/public_private_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Training Status </span>: <a  href="<?php echo base_url('/training_status_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/training_status_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Status </span>: <a  href="<?php echo base_url('/center_status_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/center_status_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Gender </span>: <a  href="<?php echo base_url('/gender_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/gender_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Marital Status </span>: <a  href="<?php echo base_url('/marital_status_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/marital_status_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Follow Up </span>: <a  href="<?php echo base_url('/follow_up_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/follow_up_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                </div>
                            </div>
                                <div class="col-md-6">
                                    <div class="">
                                    <p style="font-size: 14px;color:#1F8564;"><b>ACCESS</b></p>
                                    
                                    <div><span style="display:inline-block; width: 180px;">Add User </span>: <a  href="<?php echo base_url('/users_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/users_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>    
                                    <div><span style="display:inline-block; width: 180px;">User Roles </span>: <a  href="<?php echo base_url('/role_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/role_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>   
                                    <div><span style="display:inline-block; width: 180px;">Assign Doc to User </span>: <a  href="<?php echo base_url('/assign_document_user/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/assign_document_user/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <!--<div><span style="display:inline-block; width: 180px;">Approver Designation List </span>: <a  href="<?php echo base_url('/lists_management/index/8'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/lists_management/add/8'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->
                                    <div><span style="display:inline-block; width: 180px;">Approver Level List </span>: <a  href="<?php echo base_url('/lists_management/index/9'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/lists_management/add/9'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Approver Final List </span>: <a  href="<?php echo base_url('/lists_management/index/10'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/lists_management/add/10'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Approver Code Config </span>: <a  href="<?php echo base_url('/approver_configuration/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/approver_configuration/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Assign Warehouse to User </span>: <a  href="<?php echo base_url('/assign_wh_to_user/add'); ?>"><i class="fa fa-search"></i>View/<i class="fa fa-plus-circle"></i>ADD </a></div>     
                                    
                                    <br>
                                    
                                    <p style="font-size: 14px;color:#1F8564;"><b>DOCUMENT / Approver</b></p>
                                    
                                    <!--<div><span style="display:inline-block; width: 180px;">Product Sub Category </span>: <a  href="<?php echo base_url('/productsubcategory_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/productsubcategory_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>-->   
                                    <div><span style="display:inline-block; width: 180px;">Document Type List </span>: <a  href="<?php echo base_url('/lists_management/index/9'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/lists_management/add/9'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Document Type </span>: <a  href="<?php echo base_url('/stock_document_type_mang/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/stock_document_type_mang/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>   
                                    <div><span style="display:inline-block; width: 180px;">Transaction Type </span>: <a  href="<?php echo base_url('/trans_type_mang/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/trans_type_mang/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Challan Type </span>: <a  href="<?php echo base_url('/challan_type_management/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/challan_type_management/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Currency Type </span>: <a  href="<?php echo base_url('/lists_management/index/5'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/lists_management/add/5'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Vehicle Type </span>: <a  href="<?php echo base_url('/lists_management/index/13'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/lists_management/add/13'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">Approver Code </span>: <a  href="<?php echo base_url('/approver_code/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/approver_code/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>   
                                    <div><span style="display:inline-block; width: 180px;">PO Type </span>: <a  href="<?php echo base_url('/lists_management/index/15'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/lists_management/add/15'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>
                                    <div><span style="display:inline-block; width: 180px;">PO Document Info </span>: <a  href="<?php echo base_url('/po_info/index'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/po_info/add'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>       
                                    <div><span style="display:inline-block; width: 180px;">PI Type </span>: <a  href="<?php echo base_url('/lists_management/index/14'); ?>"><i class="fa fa-search"></i>View </a> | <a href="<?php echo base_url('/lists_management/add/14'); ?>"><i class="fa fa-plus-circle"></i>Add</a></div>    
                                        
                                    </div>
                                </div>
                            </div>
                        </ul>

                   </li>
<?php } ?>
                   <?php if($_SESSION['id'] != '159')  {?>
                <li class="has-submenu">
                    <a href="#"><i class="icon-todolist"></i> Inventory Module <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                    <ul class="submenu megamenu">
                        <li>
                            <ul>
                                <li><a href="<?php echo base_url('/im_new/stock_receive'); ?>">Stock Receive (Supplier)</a></li>
                                <li><a href="<?php echo base_url('/im_new/stock_receive_wh'); ?>">Stock Receive (Warehouse)</a></li>
                                <li><a href="<?php echo base_url('/im_new/stock_receive_search'); ?>">Stock Receive Search</a></li>
                                <li><a href="<?php echo base_url('/im_new/stock_issue'); ?>">Stock Issue to Centers</a></li>
                                <!-- <li><a href="<?php //echo base_url('/im_new/stock_issue_patients');  ?>">Stock Issue to Patients</a></li> -->
                                <li><a href="<?php echo base_url('/im_new/stock_issue_search'); ?>">Stock Issue Search</a></li>
                                <li><a href="<?php echo base_url('/inventory_management/stock_adjustment'); ?>">Stock Adjustments</a></li>
<!--                                <li><a href="<?php echo base_url('/im_new/stock_adjustment_search'); ?>">Stock Adjustments Search</a></li>-->
                                <!--<li><a href="<?php //echo base_url('/inventory_management/admin_transfers');
            ?>">Stock Transfers</a></li>-->


                            </ul>
                        </li>
                    </ul>
                </li>

<!--                <li class="has-submenu">
                    <a href="#"><i class="icon-paper-sheet"></i> Documents Search<i class="mdi mdi-chevron-down mdi-drop"></i></a>
                    <ul class="submenu megamenu">
                        <li>
                            <ul>
                                <li><a href="<?php //echo base_url('/inventory_management/gwis_stock_receive_search'); ?>">GRN</a></li>
                                <li><a href="<?php //echo base_url('/inventory_management/stock_issue_search'); ?>">SIV</a></li>

                            </ul>
                        </li>
                    </ul>
                </li>-->

                <li class="has-submenu">
                    <a href="#"><i class="icon-life-buoy"></i>Reports <i class="mdi mdi-chevron-down mdi-drop"></i></a>
                    <ul class="submenu megamenu">

                        <li>
                            <ul>
                                <li><a href="<?php echo base_url('/reports/batch_management'); ?>">Batch Management</a></li>
                                <li><a href="<?php echo base_url('/reports/storage_report'); ?>">Storage Report</a></li>
                                <li><a href="<?php echo base_url('/reports/stock_ledger'); ?>">Stock Ledger</a></li>
                                <li><a href="<?php echo base_url('/reports/stock_summary'); ?>">Stock Summary</a></li>
                                <li><a href="<?php echo base_url('/reports/soh_product_wise'); ?>">SOH Product Wise </a></li>
                                <li><a href="<?php echo base_url('/reports/soh_batch_wise'); ?>">SOH Batch Wise</a></li>
<!--                                    <li><a href="<?php echo base_url('/reports/distribution_detail'); ?>">Distribution summary</a></li>
                                <li><a href="<?php echo base_url('/reports/detail_distribution'); ?>">Detailed distribution</a></li>-->
                                <li><a href="<?php echo base_url('/reports/adjustment_report'); ?>">Adjustment Report</a></li>
                                <li><a href="<?php echo base_url('/reports/consumption_report'); ?>">Consumption Report</a></li>
                                <li><a href="<?php echo base_url('/reports/stock_movement_report'); ?>">Stock Movement</a></li>
                                <li><a href="<?php echo base_url('/reports/shipment_rpt'); ?>">Shipment Report</a></li>
<!--                                    <li><a href="<?php echo base_url('/reports/patient_threshold'); ?>">Patient Threshold</a></li>
                                <li><a href="<?php echo base_url('/reports/trans_list'); ?>">Stock Transactions Report</a></li>
                                 <li class="has-submenu">
                                        <a href="<?php echo base_url('/community_form/community_report'); ?>"><i class=""></i> Community Report</a>
                                    </li>
                                <li><a href="<?php echo base_url('/quality_management/desk_review_report'); ?>">Desk Review Report</a></li>    
                                    
                                <li><a href="<?php echo base_url('/reports/issuance'); ?>">Stock Issuance Report</a></li>
                                <li><a href="<?php echo base_url('/reports/receive'); ?>">Stock Receive Report</a></li>
                                
                                <li><a href="<?php echo base_url('/reports/issuance_list'); ?>">Stock Issuance Report</a></li>
                                <li><a href="<?php echo base_url('/reports/receive_list'); ?>">Stock Receive Report</a></li>-->
                            </ul>
                        </li>
                    </ul>
                </li>
                 <li class="has-submenu">
                    <a href="#"><i class="icon-life-buoy"></i>Requisition<i class="mdi mdi-chevron-down mdi-drop"></i></a>
                    <ul class="submenu megamenu">

                        <li>
                            <ul>
                                <li><a href="<?php echo base_url('/requisition/add'); ?>">New Requisition</a></li>
<!--                                <li><a href="<?php echo base_url('/reports/storage_report'); ?>">Storage Report</a></li>
                                <li><a href="<?php echo base_url('/reports/stock_ledger'); ?>">Stock Ledger</a></li>
                                <li><a href="<?php echo base_url('/reports/stock_summary'); ?>">Stock Summary</a></li>
                                <li><a href="<?php echo base_url('/reports/soh_product_wise'); ?>">SOH Product Wise </a></li>
                                <li><a href="<?php echo base_url('/reports/soh_batch_wise'); ?>">SOH Batch Wise</a></li>
                                    <li><a href="<?php echo base_url('/reports/distribution_detail'); ?>">Distribution summary</a></li>
                                <li><a href="<?php echo base_url('/reports/detail_distribution'); ?>">Detailed distribution</a></li>
                                <li><a href="<?php echo base_url('/reports/adjustment_report'); ?>">Adjustment Report</a></li>
                                <li><a href="<?php echo base_url('/reports/consumption_report'); ?>">Consumption Report</a></li>
                                <li><a href="<?php echo base_url('/reports/stock_movement_report'); ?>">Stock Movement</a></li>-->
<!--                                    <li><a href="<?php echo base_url('/reports/patient_threshold'); ?>">Patient Threshold</a></li>
                                <li><a href="<?php echo base_url('/reports/trans_list'); ?>">Stock Transactions Report</a></li>
                                 <li class="has-submenu">
                                        <a href="<?php echo base_url('/community_form/community_report'); ?>"><i class=""></i> Community Report</a>
                                    </li>
                                <li><a href="<?php echo base_url('/quality_management/desk_review_report'); ?>">Desk Review Report</a></li>    
                                    
                                <li><a href="<?php echo base_url('/reports/issuance'); ?>">Stock Issuance Report</a></li>
                                <li><a href="<?php echo base_url('/reports/receive'); ?>">Stock Receive Report</a></li>
                                
                                <li><a href="<?php echo base_url('/reports/issuance_list'); ?>">Stock Issuance Report</a></li>
                                <li><a href="<?php echo base_url('/reports/receive_list'); ?>">Stock Receive Report</a></li>-->
                            </ul>
                        </li>
                    </ul>
                </li>
                
                   <li class="has-submenu">
                    <a href="#"><i class="icon-life-buoy"></i>Consumption<i class="mdi mdi-chevron-down mdi-drop"></i></a>
                    <ul class="submenu megamenu">

                        <li>
                            <ul>
                                <li><a href="<?php echo base_url('/dataentry2/warehouse'); ?>">Add Consumption</a></li>
<!--                                <li><a href="<?php echo base_url('/reports/storage_report'); ?>">Storage Report</a></li>
                                <li><a href="<?php echo base_url('/reports/stock_ledger'); ?>">Stock Ledger</a></li>
                                <li><a href="<?php echo base_url('/reports/stock_summary'); ?>">Stock Summary</a></li>
                                <li><a href="<?php echo base_url('/reports/soh_product_wise'); ?>">SOH Product Wise </a></li>
                                <li><a href="<?php echo base_url('/reports/soh_batch_wise'); ?>">SOH Batch Wise</a></li>
                                    <li><a href="<?php echo base_url('/reports/distribution_detail'); ?>">Distribution summary</a></li>
                                <li><a href="<?php echo base_url('/reports/detail_distribution'); ?>">Detailed distribution</a></li>
                                <li><a href="<?php echo base_url('/reports/adjustment_report'); ?>">Adjustment Report</a></li>
                                <li><a href="<?php echo base_url('/reports/consumption_report'); ?>">Consumption Report</a></li>
                                <li><a href="<?php echo base_url('/reports/stock_movement_report'); ?>">Stock Movement</a></li>-->
<!--                                    <li><a href="<?php echo base_url('/reports/patient_threshold'); ?>">Patient Threshold</a></li>
                                <li><a href="<?php echo base_url('/reports/trans_list'); ?>">Stock Transactions Report</a></li>
                                 <li class="has-submenu">
                                        <a href="<?php echo base_url('/community_form/community_report'); ?>"><i class=""></i> Community Report</a>
                                    </li>
                                <li><a href="<?php echo base_url('/quality_management/desk_review_report'); ?>">Desk Review Report</a></li>    
                                    
                                <li><a href="<?php echo base_url('/reports/issuance'); ?>">Stock Issuance Report</a></li>
                                <li><a href="<?php echo base_url('/reports/receive'); ?>">Stock Receive Report</a></li>
                                
                                <li><a href="<?php echo base_url('/reports/issuance_list'); ?>">Stock Issuance Report</a></li>
                                <li><a href="<?php echo base_url('/reports/receive_list'); ?>">Stock Receive Report</a></li>-->
                            </ul>
                        </li>
                    </ul>
                </li>
<?php } ?>

            </ul>
            <!--End navigation menu-->
        </div>
        <!--end #navigation-->
    </div>
    <!--end container-->
</div>

<!-- end navbar-custom -->
