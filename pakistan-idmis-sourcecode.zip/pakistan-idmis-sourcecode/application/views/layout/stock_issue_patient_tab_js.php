<script>
    $(function () {
        $(".patient_issuance_tabular").on('keyup keypress blur change', function () {
            var prod = $(this).attr('item_id');
            var qty = $(this).val();
            var units_in_vial = 1000;
            
            var ins1 = $("#insulin_1").val();
            var ins2 = $("#insulin_2").val();
            var daily_units = 0;
            var nxt = '';
            var nxt_date = '';
            var lasting_days = 0;
            var next_date = 0;
            var cushion = 5;
            console.log(prod+','+ins1+','+ins2);
            if(prod == ins1 || prod == ins2){
                if(prod == ins1){
                    daily_units = $("#daily_units_1").val();
                    units_in_vial = $(this).attr('daily_units_in_single_item');
                }
                else if(prod == ins2){
                    daily_units = $("#daily_units_2").val();
                    units_in_vial = $(this).attr('daily_units_in_single_item');
                }

                 lasting_days = qty * units_in_vial / daily_units;
                 var lasting_days2 = lasting_days;
                 if(lasting_days > cushion){
                     lasting_days = lasting_days - cushion;
                 }
                 
                var next_date = new Date();
                next_date.setDate(next_date.getDate('YYYY-MM-DD') + lasting_days); 
                var dd = next_date.getDate();
                var mm = next_date.getMonth() + 1;
                var y = next_date.getFullYear();

                var next_date_f = dd + '/'+ mm + '/'+ y;
            
                 nxt = '  Details : '+qty+' vials , having '+units_in_vial+' units in each vial, when consumed at rate of '+daily_units;
                 nxt += ' units per day, can last for '+Math.round(lasting_days2)+' days. ';
                 if(lasting_days > cushion){
                    nxt += 'While keeping a cushion of '+cushion+'days,';
                 }
                 nxt += 'The next issuance date is calculated to be :'+next_date_f+'(dd/mm/yyyy)';
                 
                 $('.nxt_date_cls_'+prod+' .reason').attr('data-content',nxt);
                 $('.nxt_date_cls_'+prod+' .reason').show();
                 
                 $('.nxt_date_cls_'+prod+' .nxt_date_input').val(next_date_f+'');
                 $('.nxt_date_cls_'+prod+' .msg').html('').html(next_date_f+'');
                $('.nxt_date_cls_'+prod+' .msg').show();
            }
            else{
                 $('.nxt_date_cls_'+prod+' .nxt_date_input').val('');
                $('.nxt_date_cls_'+prod+' .msg').html('').html('None');
                $('.nxt_date_cls_'+prod+' .msg').show();
                $('.nxt_date_cls_'+prod+' .reason').show();
                 $('.nxt_date_cls_'+prod+' .reason').attr('data-content','Next issuance date can only be calculated for items marked as insulin 1 OR insulin 2 in Patients profile. ');
            }
            
            var iss_limit = parseInt($(this).attr('max'));
            if(parseInt(qty) > iss_limit){
                
                    alertify.error("Maximum quantity allowed : "+iss_limit);
                    $(this).css('background-color', '#ff8e8e');
                    $(this).val('');
            }
            else{
                    $(this).css('background-color', '#e0ffea');
            }
        });
        
        
    });
</script>