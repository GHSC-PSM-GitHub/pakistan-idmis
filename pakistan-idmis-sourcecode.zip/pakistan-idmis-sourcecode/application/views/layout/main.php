<?php include 'header.php'; ?>
<?php echo $main_content; ?>
<?php
include 'footer.php';
//$params = helper_function( current_url() )
//?>
    <script>//
//        alert('<?php echo $this->router->fetch_class();?>');
//    </script>
    <?php
//print_r($this->router->fetch_class()); echo ', and seg:'.$this->uri->segment(2).' END ';exit;
if ($this->router->fetch_class() == "Users_management") {
    ?>
    <script src="<?php echo base_url('assets/js/users.js') ?>"></script>
    <?php
} else if ($this->router->fetch_class() == "warehouse_management") {
     include "warehouses_js.php";
} else if ($this->router->fetch_class() == "location_management") {

    include "locations_js.php";
} else if ($this->router->fetch_class() == "masterdata_management") {
    include "mdm_js.php";
} 
else if ($this->router->fetch_class() == "hr_profile_management") {
    include "hr_profile.php";
} 
else if ($this->router->fetch_class() == "inventory_management") {
    
    if($this->uri->segment(2) == 'stock_issue_patients')
    {
        include "stock_issue_patient_js.php";
    }
    elseif($this->uri->segment(2) == 'stock_issue_patients_tabular')
    {
        include "stock_issue_patient_tab_js.php";
    }
    else{
        include "stock_receive_js.php";
        include "stock_issue_js.php";
    }
}

else if ($this->router->fetch_class() == "community_form") {
    
//    if($this->uri->segment(2) == 'stock_issue_patients')
//    {
//        include "stock_issue_patient_js.php";
//    }
//    elseif($this->uri->segment(2) == 'stock_issue_patients_tabular')
//    {
//        include "stock_issue_patient_tab_js.php";
//    }
//    else{
        include "cummunity_js.php";
//        include "stock_issue_js.php";
//    }
}
else if ($this->router->fetch_class() == "patients") {
    
        include "patients_js.php";
}

else if ($this->router->fetch_class() == "user_trainings") {
    
        include "training_js.php";
}
else if ($this->router->fetch_class() == "reports") {
    
        include "training_js.php";
}

else if ($this->router->fetch_class() == "quality_management") {
    
        include "quality_js.php";
}
else if ($this->router->fetch_class() == "product_management") {
    
        include "product_js.php";
}
else if ($this->router->fetch_class() == "assign_resources") {
    
        include "resources_js.php";
}
else if ($this->router->fetch_class() == "Category_list") {
    
        include "resources_js.php";
}
else if ($this->router->fetch_class() == "Assign_document_user") {
    
        include "resources_js.php";
}
else if ($this->router->fetch_class() == "po_info") {
    
        include "stock_receive_js.php";
}
else if ($this->router->fetch_class() == "assign_wh_to_user") {
    
        include "resources_js.php";
}
else if ($this->router->fetch_class() == "assign_role_resources") {
    
        include "resources_js.php";
}

?>