<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>IDS MIS - <?php echo $page_title; ?></title>
    <meta content="Responsive admin theme build on top of Bootstrap 4" name="description" />
    <meta content="Themesdesign" name="author" />
    <!--<link rel="shortcut icon" href="<?php // echo base_url('assets/images/favicon.ico') ?>">-->
        <link rel="shortcut icon" href="<?= (!empty($this->session->userdata('report_logo'))?base_url().'uploads/'.$this->session->userdata('report_logo'):base_url('assets/images/lmis.jpg'));?>">


    <!--Morris Chart CSS -->
    <link rel="stylesheet" href="../plugins/morris/morris.css">

    <link href="<?php echo base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('assets/css/metismenu.min.css') ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('assets/css/icons.css') ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('assets/css/style.css') ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('plugins/select2/select2.css') ?>" rel="stylesheet" type="text/css">

    <link href="<?php echo base_url('plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css') ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('plugins/datatables/dataTables.bootstrap4.min.css') ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('plugins/datatables/buttons.bootstrap4.min.css') ?>" rel="stylesheet" type="text/css" />
     
    
    <!--for date-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" rel="stylesheet"/>
    <!--end-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.css" rel="stylesheet"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.min.css" rel="stylesheet"/>


        <?php echo add_page_css_file(); ?>
    <?php echo add_page_custom_css_file(@$css); ?>
    <?php include "css.php"; ?>
    
    <script src="<?php echo base_url('assets/js/jquery.min.js') ?>"></script>
</head>
<style>
    @media screen and (max-width: 600px) {
        
.logo-light {
/*visibility: hidden;*/
clear: both;
float: left;
margin: 10px auto 5px 20px;
width: 28%;
/*display: none;*/
/*overflow: hidden;*/
text-align: left;
font-size: 0px;
height: 50px;
/*clear: both;
display: inline-block;*/
/*overflow: hidden;
*/white-space: nowrap;
}
.logo-light:after { font-size: 20px; content: "KPIVMP" ; }
#pics{
    height: 100%;
    margin-bottom: 50%;
} 
}
    </style>
<body>

    <div class="header-bg">
        <!-- Navigation Bar-->
        <header id="topnav">
            <div class="topbar-main">
                <div class="container-fluid">

                    <!-- Logo-->
                    <div>
                        <a href="" class="logo">
                            <span class="logo-light">
                                <img id="pics" style="border-radius: 50%;" src="<?= (!empty($this->session->userdata('report_logo'))?base_url().'uploads/'.$this->session->userdata('report_logo'):base_url('assets/images/lmis.jpg'));?>" alt="" height="60">  Infectious Diseases MIS
                            </span>
                        </a>
                    </div>
                    <!-- End Logo-->

                    <div class="menu-extras topbar-custom navbar p-0"> 

                        <ul class="navbar-right ml-auto list-inline float-right mb-0">
                            <!-- language-->
                             
    <?php $document = base_url('uploads/user_manual.pdf'); ?>
                            <!-- full screen -->
                             <li class="dropdown notification-list list-inline-item d-none d-md-inline-block">
                               <a class="nav-link waves-effect" onclick="window.open('<?php echo $document;?>', 'Notification Letter', 'width:800,height=600')">
                                    <i class="mdi mdi-file-document ">User Manual</i>
                                </a>
                            </li>
                            <li class="dropdown notification-list list-inline-item d-none d-md-inline-block">
                                <a class="nav-link waves-effect" href="<?php echo base_url('dashboard/videos') ?>">
                                    <i class="mdi mdi-file-video-outline ">Training Videos</i>
                                </a>
                            </li>
                            
                             <li class="dropdown notification-list list-inline-item d-none d-md-inline-block">
                                <a class="nav-link waves-effect" href="#" id="btn-fullscreen">
                                    <i class="mdi mdi-arrow-expand-all noti-icon"></i>
                                </a>
                            </li>

                            <!-- notification -->
<!--                            <li class="dropdown notification-list list-inline-item ">
                                <a class="nav-link dropdown-toggle arrow-none waves-effect" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <i class="mdi mdi-bell-outline noti-icon "></i>
                                    <span class="badge badge-pill badge-danger noti-icon-badge">1</span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated dropdown-menu-lg px-1 ">
                                     item
                                    <h6 class="dropdown-item-text">
                                            Notifications
                                        </h6>
                                    <div class="slimscroll notification-item-list">
                                         item
                                        <a href="javascript:void(0);" class="dropdown-item notify-item active">
                                            <div class="notify-icon bg-success"><i class="mdi mdi-cart-outline"></i></div>
                                            <p class="notify-details">Expiry Alerts to be displayed here</p>
                                        </a>

                                         item
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon bg-danger"><i class="mdi mdi-message-text-outline"></i></div>
                                            <p class="notify-details">Notifications here</p>
                                        </a>

                                         item
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon bg-info"><i class="mdi mdi-filter-outline"></i></div>
                                            <p class="notify-details">Under stock facility here</p>
                                        </a>

                                         item
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon bg-success"><i class="mdi mdi-message-text-outline"></i></div>
                                            <p class="notify-details"><span class="text-muted">Defaulter Alert here</span></p>
                                        </a>

                                         item
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon bg-warning"><i class="mdi mdi-cart-outline"></i></div>
                                            <p class="notify-details">e</p>
                                        </a>

                                    </div>
                                     All
                                    <a href="javascript:void(0);" class="dropdown-item text-center notify-all text-primary">
                                            View all <i class="fi-arrow-right"></i>
                                        </a>
                                </div>
                            </li>-->

                            <li class="dropdown notification-list list-inline-item">
                                <div class="dropdown notification-list nav-pro-img">
                                    <a class="dropdown-toggle nav-link arrow-none nav-user" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                        <img src="<?php echo base_url('assets/images/users/user-4.jpg') ?>" alt="user" class="rounded-circle"> <?php if(isset($_SESSION['name'])){ echo $_SESSION['name'];}else{echo '';}?> <i class="mdi mdi-chevron-down mdi-drop"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                         <!--item-->
<!--                                        <a class="dropdown-item" href="#"><i class="mdi mdi-account-circle"></i> Profile</a>-->
                                        <a class="dropdown-item d-block" href="<?php echo base_url("Users_management/change_my_pass"); ?>"><i class="mdi mdi-settings"></i> Change Password</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item text-danger" href="<?php echo base_url('Auth/logout') ?>"><i class="mdi mdi-power text-danger"></i> Logout</a>
                                    </div>
                                </div>
                            </li>

                            <li class="menu-item dropdown notification-list list-inline-item">
                                <!-- Mobile menu toggle-->
                                <a class="navbar-toggle nav-link">
                                    <div class="lines">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                </a>
                                <!-- End mobile menu toggle-->
                            </li>

                        </ul>

                    </div>
                    <!-- end menu-extras -->

                    <div class="clearfix"></div>

                </div>
                <!-- end container -->
            </div>
            <!-- end topbar-main -->

            <?php
			//print_r($this->session->userdata());exit();
			if ($this->session->userdata('warehouse_id') == 97800) {
                            //// 97800 is the id of CMU warehouse
                            //// top-menu.php contains static menu for cmu
				include "top-menu.php";
			}
			else{
                            //// top-menu-im.php contains static menu for users other than cmu
				include "top-menu-im.php";
			}
			?>
        </header>
        <!-- End Navigation Bar-->

    </div>
    <!-- header-bg -->
