<script>
        $("#supplier_name_id").change(function(){
            var value = $(this).val();
//            alert(value);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/supplier_combo"); ?>',
                data: {
                    id: value,
                    lvl: 4
                },
                dataType: 'json',
                success: function (data) {
                    var user = JSON.parse(JSON.stringify(data));
//                    alert(user.warehouse_name);
                    if(user.gender != '')
                    {
                        $("#cpname").val(user.contact_person);
                    }
                    else{
                        $("#cpname").val('');
                    }
                    if(user.staff_desg != '')
                    {
                        $("#cnnumber").val(user.contact_numbers);
                    }
                    else{
                        $("#cnnumber").val('');
                    }
                    if(user.staff_contact_no != '')
                    {
                        $("#email").val(user.contact_emails);
                    }
                    else{
                        $("#email").val('');
                    }
                    if(user.staff_cnic != '')
                    {
                        $("#gstn").val(user.gstn);
                    }
                    else{
                        $("#gstn").val('');
                    }
                    if(user.warehouse_name != '')
                    {
                        $("#ntn").val(user.ntn);
                    }
                    else{
                        $("#ntn").val('');
                    }
                    if(user.warehouse_name != '')
                    {
                        $("#address").val(user.contact_address);
                    }
                    else{
                        $("#address").val('');
                    }
//                    $("#public_private").val(user.gender);
//                    $("#district").select2("val", "");
//                    $("#tehsil").select2("val", "");
//                    $("#uc").select2("val", "");
//                    $('#district').html(data);
                }
            });
//            $.ajax({
//                type: "POST",
//                url: '<?php echo base_url("ajax/cities"); ?>',
//                data: {
//                    province_id: value
//                },
//                dataType: 'html',
//                success: function (data) {
//                    $('#city').html(data);
//                }
//            });
        }).change();
        
        
        
        $("#product_type").change(function(){
            
            var value = $(this).val();
            if(value == '36')
            {
                $('#show_genericname').fadeIn();
                $('#show_strength').fadeIn();
                $('#show_method').fadeIn();
                $("#generic_name_id").prop('required',true);
                $("#strength_id").prop('required',true);
                $("#method_type_id").prop('required',true);
            }
            else{
                $('#show_genericname').fadeOut();
                $('#show_strength').fadeOut();
                $('#show_method').fadeOut();
                $("#generic_name_id").prop('required',false);
                $("#strength_id").prop('required',false);
                $("#method_type_id").prop('required',false);
            }
        }).change();
//        $("#start_date, #end_date").datepicker({
//            'format': 'dd/mm/yyyy'
//        });
//        $("#start_date").datepicker().on('changeDate', function(selected){
//        startDate = new Date(selected.date.valueOf());
//        $('#end_date').datepicker('setStartDate', startDate);
//    });  
//
//    $("#end_date").datepicker().on('changeDate', function(selected){
//        startDate = new Date(selected.date.valueOf());
//        $('#start_date').datepicker('setEndDate', startDate);
//    });

        
</script>