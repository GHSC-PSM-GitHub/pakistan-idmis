<script>
     $(function () {
   $("#province").change(function(){
//       alert("check");
       var value= $("#province option:selected" ).text(); 
        $("#province_name").val(value);
    });
    $("#city").change(function(){
       var value= $("#city option:selected" ).text(); 
        $("#city_name").val(value);
    });
    $("#district").change(function(){
       var value= $("#district option:selected" ).text(); 
        $("#district_name").val(value);
    });
    $("#tehsil").change(function(){
       var value= $("#tehsil option:selected" ).text(); 
        $("#tehsil_name").val(value);
    });
    $("#uc").change(function(){
       var value= $("#uc option:selected" ).text(); 
        $("#uc_name").val(value);
    });
    $("#stakeholder").change(function(){
       var value= $("#stakeholder option:selected" ).text(); 
        $("#stakeholder_name").val(value);
    });
    $("#type").change(function(){
       var value= $("#type option:selected" ).text(); 
        $("#facility_type_name").val(value);
    });
    $("#parent_hospital").change(function(){
       var value= $("#parent_hospital option:selected" ).text(); 
        $("#parent_hospital_name").val(value);
    });
    $("#category").change(function(){
       var value= $("#category option:selected" ).text();
       $("#category_name").val(value);
       if($(this).val()==1){
           $("#parent_div").css("display","block");
           $.ajax({
            type: "POST",
            url: "<?php echo base_url('ajax/facilities_by_category'); ?>",
            data: {
                category: $(this).val()
            },
            dataType: 'html',
            success: function (data) {
                $('#parent_hospital').html(data);
            }
        });
       }
        else{
        $("#parent_div").css("display","none");
        }
        
    });
    $("#fnf_status").change(function(){
//        alert($(this).val());
        if($(this).val() == 2)
        {
            $('#nf_reason').show();
        }
        else{
            $('#nf_reason').hide();
        }
    });
    
     $("#addwarehouse").validate({
            rules: {
                contact_no: {
                    number: true,
                    minlength: 11,
                    maxlength: 11
                },
                cnic_no: {
                    number: true,
                    minlength: 13,
                    maxlength: 13
                },
                email: {
                    emailfull: true
                },
//                province : {
//                    province: "required needsSelection"
//                }
            },
            ignore: [],
//            ignore: ':hidden:not("#province")', // Tells the validator to check the hidden select
//            ignore : ".ignore, :hidden",
//            errorClass: 'invalid'
        });
        jQuery.validator.addMethod("emailfull", function(value, element) {
            return this.optional(element) || /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i.test(value);
           }, "Please enter valid email address!");
//        jQuery.validator.addMethod("fullemail", function(value, element) {
//         return this.optional(element) || /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i.test(value);
//        }, "Please enter valid email address!");
    });

   
  
   
</script>
