<!-- Footer -->
<footer class="footer">
<!--For any comments and suggestions please write to <a href="mailto: "> Support Email</a>-->
For any comments and suggestions please write to <a href="mailto:support@lmis.gov.pk"><u>support@lmis.gov.pk</u></a>
    </footer>

    <!-- End Footer -->

    <!-- jQuery  -->
<!--    <script src="<?php echo base_url('assets/js/jquery.min.js') ?>"></script>-->
    <script src="<?php echo base_url('assets/js/bootstrap.bundle.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.slimscroll.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/waves.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.validate.min.js') ?>"></script>

    <script src="<?php echo base_url('plugins/sweet-alert2/sweetalert2.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/pages/sweet-alert.init.js') ?>"></script> 
    <script src="<?php echo base_url('plugins/alertify/js/alertify.js ')?>"></script>
    <!-- App js -->
    
    
    <!-- Required datatable js -->
    <script src="<?php echo base_url('plugins/datatables/jquery.dataTables.min.js');?>"></script>
    <script src="<?php echo base_url('plugins/datatables/dataTables.bootstrap4.min.js');?>"></script>
    <!-- Buttons examples -->
    <script src="<?php echo base_url('plugins/datatables/dataTables.buttons.min.js');?>"></script>
    <script src="<?php echo base_url('plugins/datatables/buttons.bootstrap4.min.js');?>"></script>
    <script src="<?php echo base_url('plugins/datatables/jszip.min.js');?>"></script>
    <script src="<?php echo base_url('plugins/datatables/pdfmake.min.js');?>"></script>
    <script src="<?php echo base_url('plugins/datatables/vfs_fonts.js');?>"></script>
    <script src="<?php echo base_url('plugins/datatables/buttons.html5.min.js');?>"></script>
    <script src="<?php echo base_url('plugins/datatables/buttons.print.min.js');?>"></script>
    <script src="<?php echo base_url('plugins/datatables/buttons.colVis.min.js');?>"></script>
    <!-- Responsive examples -->
    <script src="<?php echo base_url('plugins/datatables/dataTables.responsive.min.js');?>"></script>
    <script src="<?php echo base_url('plugins/datatables/responsive.bootstrap4.min.js');?>"></script>

    <!-- DatePicker -->
    <script src="<?php echo base_url('plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js');?>"></script>

    <!-- Datatable init js -->
    <script src="<?php echo base_url('assets/pages/datatables.init.js');?>"></script>  
    <!-- Searchable dropdowns -->
 <script src="<?php echo base_url('plugins/select2/select2.js');?>"></script>  
 <script src="<?php echo base_url('plugins/morris/morris.js');?>"></script>  
 <script src="<?php echo base_url('plugins/raphael/raphael.min.js');?>"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
 
 
<!--for Date-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.min.js"></script>

<!--end-->

	<script>var base_url_site='<?php echo base_url(); ?>' </script>
    <script src="<?php echo base_url('assets/js/app.js') ?>"></script>
    <?php echo add_page_js_file(); ?>
    <?php echo add_page_custom_js_file(@$js); ?>
    <?php include "js.php"; ?>

</body>

</html>
