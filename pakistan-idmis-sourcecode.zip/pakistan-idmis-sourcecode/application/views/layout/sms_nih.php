<?php
//$url = "http://cbs.zong.com.pk/reachcwsv2/corporatesms.svc?wsdl";
//$client = new SoapClient($url, array("trace" => 1, "exception" => 0));
//$username = '923181546029';
//$password = 'Tech@7788';
//$to = $_GET['to'];
//$var = $number*1;
//$phone = substr_replace("92","$var",2);
//$to = $phone;
//$n = '923309137104';
//$to = $phone.','.$n;
//echo $pmdc_no."            ";
//
//echo $number;
////print_r($number);
////exit;
//if(isset($reject) && !empty($reject))
//{
//    for($i=0;$i<count($number);++$i){
//        $message = "Your request to “Register” on Doctors Hub Application has been rejected due to the invalid credentials
//                in verification as per PMC record. For any queries, write us at support@nih.gov.pk.";
//        $var = $number[$i]->phone*1;
//        $phone = substr_replace("92","$var",2);
//        $to = $phone;
//                $resultQuick = $client->QuickSMS(
//                    array('obj_QuickSMS' =>
//                        array('loginId' => $username,
//                            'loginPassword' => $password,
//                            'Destination' => $to,
//                            'Mask' => 'NIH TECH',
//                            'Message' => $message,
//                            'UniCode' => 0,
//                            'ShortCodePrefered' => 'n'
//                        )
//                    )
//                );
//
//    $response = $resultQuick->QuickSMSResult;
//    echo($response);
//    }
////}
//if(isset($userinfo) && !empty($userinfo))
//{
////    echo $userinfo[0]->phone;
////    exit;
//    for($i=0;$i<count($nursepass);++$i){
//        $message = "Subject: Doctors Hub - Registration Approval\n\n";
//        $message .= "Dear ". $userinfo[$i]->full_name ."\n\n";
////        $message .= "Your request for registration has been Approved.Two Users are created First Username is: '" . $userinfo[$i]->pmdc_no .'_nurse' . "' & Password is:'".$nursepass[$i]."' AND Second Username is: '" . $userinfo[$i]->pmdc_no . '_fdesk' . "' & Password is:'".$fdeskpass[$i]."'";
//        $message .= "Your registration has been approved by PMC. Please login to Doctors Hub application using your Login and Password. Following users have been created for your team members:\n\n";
//        $message .= "Employee: Nurse \n";
//        $message .= "Login:  " . $userinfo[$i]->pmdc_no .'_nurse' . " \n";
//        $message .= "Password:  ".$nursepass[$i]."\n\n";
//        $message .= "Employee: Front Desk \n";
//        $message .= "Login:  " . $userinfo[$i]->pmdc_no . '_fdesk' . " \n";
//        $message .= "Password:  ".$fdeskpass[$i]."\n\n";
//        $message .= "For any further information , please contact support@nih.gov.pk";
//        $var = $userinfo[$i]->phone*1;
//        $phone = substr_replace("92","$var",2);
//        $to = $phone;
//                $resultQuick = $client->QuickSMS(
//                    array('obj_QuickSMS' =>
//                        array('loginId' => $username,
//                            'loginPassword' => $password,
//                            'Destination' => $to,
//                            'Mask' => 'NIH TECH',
//                            'Message' => $message,
//                            'UniCode' => 0,
//                            'ShortCodePrefered' => 'n'
//                        )
//                    )
//                );
//
//    $response = $resultQuick->QuickSMSResult;
//    echo($response);
//    }
//}
//if(empty($reject) && empty($userinfo)){
//    $var = $number*1;
//    $phone = substr_replace("92","$var",2);
//    $to = $phone;
//    $message = "Your request for registration has been submitted successfully, please wait till PMDC verification. You will be notified through provided *Mobile Number* & *Email* upon verification.";
//    $resultQuick = $client->QuickSMS(
//                    array('obj_QuickSMS' =>
//                        array('loginId' => $username,
//                            'loginPassword' => $password,
//                            'Destination' => $to,
//                            'Mask' => 'NIH TECH',
//                            'Message' => $message,
//                            'UniCode' => 0,
//                            'ShortCodePrefered' => 'n'
//                        )
//                    )
//                );
//
//    $response = $resultQuick->QuickSMSResult;
//    echo($response);
//}
//echo $message;
//print_r($userinfo);
//print_r($nursepass);
//print_r($fdeskpass);
//exit;
if(isset($p_number) && !empty($p_number))
{
//                $var = $number*1;
//                $phone = substr_replace("92","$var",2);
//                $to = $phone;
//                    echo $to;exit;
                $username = "03085325085";
                $password = "P6v@RRjUwE9";
                $from = "LMIS Alert";
                $to = "$p_number";
                $message = "Hello message";


                //==============    //WORKING CODE    //==============    

                $target_url = "https://connect.jazzcmt.com/sendsms_url.html";
                $post = array(
                    'Username' => $username,
                    'Password' => $password,
                    'From' => $from,
                    'To' => $to,
                    'Message' => $message
                );
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $target_url);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible;)");
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: multipart/form-data'));
                curl_setopt($ch, CURLOPT_FRESH_CONNECT, 1);
                curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
                curl_setopt($ch, CURLOPT_TIMEOUT, 100);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
                $result = curl_exec($ch);

                if ($result === FALSE) {
                    echo "Error sending" . $fname .  " " . curl_error($ch);
                    curl_close($ch);
                } else {
                    curl_close($ch);
                    echo  "Result: " . $result;
                }


    }
if(isset($r_number) && !empty($r_number))
{
//                $var = $number*1;
//                $phone = substr_replace("92","$var",2);
//                $to = $phone;
//                    echo $to;exit;
                $username = "03085325085";
                $password = "P6v@RRjUwE9";
                $from = "LMIS Alert";
                $to = "$r_number";
                $message = "Thank you for letting us know your query is forward to concerned department.";


                //==============    //WORKING CODE    //==============    

                $target_url = "https://connect.jazzcmt.com/sendsms_url.html";
                $post = array(
                    'Username' => $username,
                    'Password' => $password,
                    'From' => $from,
                    'To' => $to,
                    'Message' => $message
                );
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $target_url);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible;)");
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: multipart/form-data'));
                curl_setopt($ch, CURLOPT_FRESH_CONNECT, 1);
                curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
                curl_setopt($ch, CURLOPT_TIMEOUT, 100);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
                $result = curl_exec($ch);

                if ($result === FALSE) {
                    echo "Error sending" . $fname .  " " . curl_error($ch);
                    curl_close($ch);
                } else {
                    curl_close($ch);
                    echo  "Result: " . $result;
                }


    }
?>