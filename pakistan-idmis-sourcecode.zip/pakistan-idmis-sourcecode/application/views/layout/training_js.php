<script>
    $(function () {
        
        $('#batch_mang_product').change(function() {
//        alert('saad');
        if ($('#batch_mang_product').val() != '')
        {
            $('#mcc_generic_name_div').fadeIn();    
            $('#mcc_category_div').fadeIn(); 
            
//            $.ajax({
//                type: "POST",
//                url: "get_mcc_info.php",
//                cache: false,
//                data: {'pk_id': $('#product').val()}, // since, you need to delete post of particular id
//                dataType: 'json',
//                success: function(data) {
//    //                      alert(data.category_id);
//                    $("#mcc_generic_name").val(data.generic_updated);
//                    $("#mcc_category").val(data.mcc_category_name);
//                 }
//             });    
            
            $('#printSummary').css('display', 'none');
            $.ajax({
                type: "POST",
                url: "ajaxbatch",
                data: {id: $('#batch_mang_product').val()},
                dataType: 'html',
                success: function(data) {
                    $('#vaccine-detail').show();
                    $('#batch_detail_ajax').html(data).show();
                }
            });
        }
        else
        {
            $('#mcc_generic_name_div').fadeOut();
            $('#mcc_category_div').fadeOut();
            
            $('#batch_detail_ajax').html('').hide();
            $('#printSummary').css('display', 'block');
        }
    });
    
    
//        $('#myElem').hide();
        var max = 11;
        $('#patient_mobileno').keypress(function (e) {
            if (e.which < 0x20) {
                // e.which < 0x20, then it's not a printable character
                // e.which === 0 - Not a character
                return;     // Do nothing
            }
            if (this.value.length == max) {
                e.preventDefault();
            } else if (this.value.length > max) {
                // Maximum exceeded
                this.value = this.value.substring(0, max);
            }
        });
        $('#reporter_mobileno').keypress(function (e) {
            if (e.which < 0x20) {
                // e.which < 0x20, then it's not a printable character
                // e.which === 0 - Not a character
                return;     // Do nothing
            }
            if (this.value.length == max) {
                e.preventDefault();
            } else if (this.value.length > max) {
                // Maximum exceeded
                this.value = this.value.substring(0, max);
            }
        });
        $('#p_mobileno').keypress(function (e) {
            if (e.which < 0x20) {
                // e.which < 0x20, then it's not a printable character
                // e.which === 0 - Not a character
                return;     // Do nothing
            }
            if (this.value.length == max) {
                e.preventDefault();
            } else if (this.value.length > max) {
                // Maximum exceeded
                this.value = this.value.substring(0, max);
            }
        });
       $("#add_form").validate({
            rules: {
                patient_mobileno: {
                    number: true,
                    minlength: 11,
                    maxlength: 11
                },
                reporter_mobileno: {
                    number: true,
                    minlength: 11,
                    maxlength: 11
                },
                reporter_email: {
                    emailfull: true
                }
//                province : {
//                    province: "required needsSelection"
//                }
            },
            ignore: [],
//            ignore: ':hidden:not("#province")', // Tells the validator to check the hidden select
//            ignore : ".ignore, :hidden",
//            errorClass: 'invalid'
        });
        jQuery.validator.addMethod("emailfull", function(value, element) {
            return this.optional(element) || /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i.test(value);
           }, "Please enter valid email address!");
        jQuery.validator.addMethod("p_email", function(value, element) {
         return this.optional(element) || /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i.test(value);
        }, "Please enter valid email address!");
        
        
        $("#product").change(function () {
            $('#batch').attr('disabled',true);
            var product = $("#product").val();
            var wh_id = $("#center_from").val();
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('reports/get_batches_of_wh'); ?>",
                data: {
                    item_id: product,
                    wh_id: wh_id
                },
                dataType: 'html',
                success: function (data) {
                    alertify.success("Please select the Batch now.");
                    $('#batch').attr('disabled',false);
                    $('#batch').html(data);
                }
            });
        });
        
        $("#stakeholder").change(function(){
            
            if($(this).val() == '')
            {
                $('#ledger_product').html('');
                $('.select2-choice span').html('');
            }
            
            var value = $(this).val();
            if(value == '')
            {
                value = $('#sstakeholder').val();
            }
//            else{
//                $('#supplier_info').fadeOut();
//            }
//            alert(value);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/getproduct_bystkid"); ?>',
                data: {
                    id: value
                },
                dataType: 'json',
                success: function (data) {
                    var user = JSON.parse(JSON.stringify(data));
//                    alert(user);
                    if(user)
                    {
//                        $("#product").html(user);
                        $("#issue_product").html(user);
                        $("#adj_product").html(user);
//                        $("#ledger_product").html(user);
                    }
//                    $("#ledger_product").val(1); 
//                    $('#ledger_product').select2().trigger('change');
//                    $("#public_private").val(user.gender);
//                    $("#district").select2("val", "");
//                    $("#tehsil").select2("val", "");
//                    $("#uc").select2("val", "");
//                    $('#district').html(data);
                }
            });
            
//            var value = $(this).val();
//            if(value == '1')
//            {
//                $("#po_quantity").prop('required',true);
//                $("#wh_detail_info").prop('required',false);
//                $("#receive_from_warehouse").prop('required',false);
//                $("#receive_from_supplier").prop('required',true);
//                $("#po_detail_info").prop('required',true);
//                $('#show_receive_from_warehouse').fadeOut();
//                $('#show_receive_from_supplier').fadeIn();
//                $('#po_type_detail').fadeIn();
//                $('#fo_type_detail').fadeOut();
//                
//                $('#show_po_quantity').fadeIn();
//            }
        }).change();
        
        // if required then uncomment this line.
        
//        $("#ledger_product").change(function () {
        $("#ledger_product_notreq").change(function () {
            var value ="";
             value = $(this).children(":selected").attr("id");
//            alert(value.toString());
//           var params = value.replace("-deletesr", "");
            var arr = String(value).split('_');
//            alert(arr[0]);
//            alert(arr);
            var btn = this;
            var editbatchid = '';
            $('#issue_batch').attr('disabled',true);
            var product = $("#ledger_product").val();
            var wh_id = $("#center_from").val();
            if($("#editbatchid").val() != '')
            {
               editbatchid = $("#editbatchid").val();
//               alert(editbatchid);
            }
            if(arr[1] == '36')
            {
                        $('#show_batch').fadeIn();
                        $("#show_batch").prop('required',true);
                        $('#show_expiry_date').fadeIn();
                        $("#show_expiry_date").prop('required',true);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('inventory_management/get_batches_of_wh_ledger'); ?>",
                    data: {
                        item_id: product,
                        wh_id: wh_id,
                        editbatchid:editbatchid,
                        product_type : arr[1],
                        stk_id : arr[2]
                    },
                    dataType: 'html',
                    success: function (data) {
//                        alert(data);
                        alertify.success("Please select the Batch now.");
                        $('#issue_batch').attr('disabled',false);
                        $('#issue_batch').html(data);
                        $("#issue_batch").select2().select2('val',editbatchid);
                    }
                });
                
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('inventory_management/get_batches_of_wh_details'); ?>",
                    data: {
                        item_id: product,
                        wh_id: wh_id,
                        editbatchid:editbatchid,
                        product_type : arr[1],
                        stk_id : arr[2]
                    },
                    dataType: 'html',
                    success: function (data) {
                        $('#issue_batch_details').html(data);
                    }
                });
                
            }
            else
            {
                $('#show_batch').fadeOut();
                $("#show_batch").prop('required',false);
                $('#show_expiry_date').fadeOut();
                $("#show_expiry_date").prop('required',false);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('inventory_management/getprodinfo'); ?>",
                    data: {
                        item_id: product,
                        wh_id: wh_id,
                        editbatchid:editbatchid,
                        product_type : arr[1],
                        stk_id : arr[2]
                    },
                    dataType: 'json',
                    success: function (data) {
//                        var user = JSON.parse(JSON.stringify(data));

                        $("#available_quantity").val(data.available_qty);
                        $("#produstbatchid").val(data.batchid);
                        $("#unit_price").val(data.unit_price);
                        $("#conversion_rate").val(data.conversion_rate);
                        $("#currency").val(data.currency);
                        $("#actual_rec_qty").val(data.actual_rec_qty);
                    }
                });
            }
        }).change();
        
        $("#issue_product").change(function () {
            var value ="";
             value = $(this).children(":selected").attr("id");
//            alert(value.toString());
//           var params = value.replace("-deletesr", "");
            var arr = String(value).split('_');
//            alert(arr[0]);
//            alert(arr);
            var btn = this;
            var editbatchid = '';
            $('#issue_batch').attr('disabled',true);
            var product = $("#issue_product").val();
            var wh_id = $("#center_from").val();
            if($("#editbatchid").val() != '')
            {
               editbatchid = $("#editbatchid").val();
//               alert(editbatchid);
            }
            if(arr[1] == '36')
            {
                        $('#show_batch').fadeIn();
                        $("#show_batch").prop('required',true);
                        $('#show_expiry_date').fadeIn();
                        $("#show_expiry_date").prop('required',true);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('inventory_management/get_batches_of_wh'); ?>",
                    data: {
                        item_id: product,
                        wh_id: wh_id,
                        editbatchid:editbatchid,
                        product_type : arr[1]
                    },
                    dataType: 'html',
                    success: function (data) {
//                        alert(data);
                        alertify.success("Please select the Batch now.");
                        $('#issue_batch').attr('disabled',false);
                        $('#issue_batch').html(data);
                        $("#issue_batch").select2().select2('val',editbatchid);
                    }
                });
                
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('inventory_management/get_batches_of_wh_details'); ?>",
                    data: {
                        item_id: product,
                        wh_id: wh_id,
                        editbatchid:editbatchid,
                        product_type : arr[1]
                    },
                    dataType: 'html',
                    success: function (data) {
                        $('#issue_batch_details').html(data);
                    }
                });
                
            }
            else
            {
                $('#show_batch').fadeOut();
                $("#show_batch").prop('required',false);
                $('#show_expiry_date').fadeOut();
                $("#show_expiry_date").prop('required',false);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('inventory_management/getprodinfo'); ?>",
                    data: {
                        item_id: product,
                        wh_id: wh_id,
                        editbatchid:editbatchid,
                        product_type : arr[1]
                    },
                    dataType: 'json',
                    success: function (data) {
//                        var user = JSON.parse(JSON.stringify(data));

                        $("#available_quantity").val(data.available_qty);
                        $("#produstbatchid").val(data.batchid);
                        $("#unit_price").val(data.unit_price);
                        $("#conversion_rate").val(data.conversion_rate);
                        $("#currency").val(data.currency);
                        $("#actual_rec_qty").val(data.actual_rec_qty);
                    }
                });
            }
        }).change();
        
        
    });
    function calculate_age(dob, method) {
            if (method == 'age2dob') {
                var birthDate = moment().subtract(dob, 'years');
                $("#day").val(birthDate.format("D"));
                $("#month").val(birthDate.format("M"));
                $("#year").val(birthDate.format("YYYY"));
            } else {
                var dob = $("#year").val() + '-' + $("#month").val() + '-' + $("#day").val();
                var a = moment();
                var b = moment(dob, "YYYY-MM-DD");
                var age_dt = a.diff(b, 'years');

                $("#age").val(age_dt);
            }
        }
        
        $("#patient_disease").change(function () {
            if($(this).val() == '2')
            {
                $('#leishmania_info').show();
            }
            else{
                $('#leishmania_info').hide();
            }
        });
        $("#patient_disease").change(function () {
            if($(this).val() == '1' || $(this).val() == '3')
            {
                $('#malaria_info').show();
            }
            else{
                $('#malaria_info').hide();
            }
        });
        
        $("#trainee_name").change(function(){
            var value = $(this).val();
//            alert(value);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/training_combo"); ?>',
                data: {
                    id: value,
                    lvl: 4
                },
                dataType: 'json',
                success: function (data) {
                    var user = JSON.parse(JSON.stringify(data));
//                    alert(user.warehouse_name);
                    if(user.gender != '')
                    {
                        $("#gender").val(user.gender);
                    }
                    else{
                        $("#gender").val('');
                    }
                    if(user.staff_desg != '')
                    {
                        $("#designation").val(user.desg);
                    }
                    else{
                        $("#designation").val('');
                    }
                    if(user.staff_contact_no != '')
                    {
                        $("#contact_no").val(user.contact_no);
                    }
                    else{
                        $("#contact_no").val('');
                    }
                    if(user.staff_cnic != '')
                    {
                        $("#cnic_no").val(user.cnic);
                    }
                    else{
                        $("#cnic_no").val('');
                    }
                    if(user.warehouse_name != '')
                    {
                        $("#health_facility").val(user.warehouse_name);
                    }
                    else{
                        $("#health_facility").val('');
                    }
                    if(user.location_name != '')
                    {
                        $("#district").val(user.location_name);
                    }
                    else{
                        $("#district").val('');
                    }
//                    $("#public_private").val(user.gender);
//                    $("#district").select2("val", "");
//                    $("#tehsil").select2("val", "");
//                    $("#uc").select2("val", "");
//                    $('#district').html(data);
                }
            });
//            $.ajax({
//                type: "POST",
//                url: '<?php echo base_url("ajax/cities"); ?>',
//                data: {
//                    province_id: value
//                },
//                dataType: 'html',
//                success: function (data) {
//                    $('#city').html(data);
//                }
//            });
        }).change();
        
//        $("#start_date, #end_date").datepicker({
//            'format': 'dd/mm/yyyy'
//        });
//        $("#start_date").datepicker().on('changeDate', function(selected){
//        startDate = new Date(selected.date.valueOf());
//        $('#end_date').datepicker('setStartDate', startDate);
//    });  
//
//    $("#end_date").datepicker().on('changeDate', function(selected){
//        startDate = new Date(selected.date.valueOf());
//        $('#start_date').datepicker('setEndDate', startDate);
//    });

        $(document).ready(function(){
   $("#start_date").datepicker({
       format: 'dd/mm/yyyy',
       autoclose: true,
   }).on('changeDate', function (selected) {
       var minDate = new Date(selected.date.valueOf());
       $('#end_date').datepicker('setStartDate', minDate);
   });

   $("#end_date").datepicker({
       format: 'dd/mm/yyyy',
       autoclose: true,
   }).on('changeDate', function (selected) {
           var minDate = new Date(selected.date.valueOf());
           $('#start_date').datepicker('setEndDate', minDate);
   });
});


    $('.table').on("input", ".subtotal", function() {
      let sum = 0;
      $(".subtotal").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".total").val(sum);
    });
    
    $('.table').on("input", ".subtotal1", function() {
      let sum = 0;
      $(".subtotal1").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".total1").val(sum);
    });
    
    $('.table').on("input", ".subtotal2", function() {
      let sum = 0;
      $(".subtotal2").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".total2").val(sum);
    });
    
    $('.table').on("input", ".subtotal3", function() {
      let sum = 0;
      $(".subtotal3").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".total3").val(sum);
    });
    
    $('.table').on("input", ".subtotal4", function() {
      let sum = 0;
      $(".subtotal4").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".total4").val(sum);
    });
    
    $('.table').on("input", ".subtotal5", function() {
      let sum = 0;
      $(".subtotal5").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".total5").val(sum);
    });
    
    $('.table').on("input", ".subtotal6", function() {
      let sum = 0;
      $(".subtotal6").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".total6").val(sum);
    });
    
    
    $('.table').on("input", ".subtotal7", function() {
      let sum = 0;
      $(".subtotal7").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".total7").val(sum);
    });
    
    $('.table').on("input", ".subtotal8", function() {
      let sum = 0;
      $(".subtotal8").each(function(){
        sum += $(this).is('input') ? +$(this).val() : +$(this).text();
      });
      $(".total8").val(sum);
    });
    
    
    
    
    for (let i = 0; i < document.getElementById("consolidated_info").rows.length; i++) {
        
        $('.table').on("input", ".subtotal5"+[i], ".subtotal3"+[i], function() {
          let sum = 0;
          let sum1 = 0;
          let sum2 = 0;
          $(".subtotal5"+[i]).each(function(){
            sum1 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          $(".subtotal3"+[i]).each(function(){
            sum2 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          sum = sum1 - sum2;
          $(".subtotal7"+[i]).val(sum);
        });
    
    }
    
    
    
    
    for (let i = 0; i < document.getElementById("consolidated_info").rows.length; i++) {
        
        $('.table').on("input", ".subtotal6"+[i], ".subtotal4"+[i], function() {
          let sum = 0;
          let sum1 = 0;
          let sum2 = 0;
          $(".subtotal6"+[i]).each(function(){
            sum1 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          $(".subtotal4"+[i]).each(function(){
            sum2 += $(this).is('input') ? +$(this).val() : +$(this).text();
          });
          sum = sum1 - sum2;
          $(".subtotal8"+[i]).val(sum);
        });
    
    }
    
    $('.table').on("input" ,function() {
        
        if($(".subtotal7").val() != '')
        {
            let sum = 0;
            $(".subtotal7").each(function(){
              sum += $(this).is('input') ? +$(this).val() : +$(this).text();
            });
            $(".total7").val(sum);
        }
        
        if($(".subtotal8").val() != '')
        {
            let sum = 0;
            $(".subtotal8").each(function(){
              sum += $(this).is('input') ? +$(this).val() : +$(this).text();
            });
            $(".total8").val(sum);
        }
        
        if($(".total3").val() != '' || $(".total4").val() != '')
        {
            var a=parseInt($(".total3").val());
            var b=parseInt($(".total4").val());
            var final_total = a + b ;
    //        alert(final_total);
            $(".final_total1").val(final_total);
        }
        
        if($(".total5").val() != '' || $(".total6").val() != '')
        {
            var a=parseInt($(".total5").val());
            var b=parseInt($(".total6").val());
            var final_total = a + b ;
    //        alert(final_total);
            $(".final_total2").val(final_total);
        }
        
        if($(".total7").val() != '' || $(".total8").val() != '')
        {
            var a=parseInt($(".total7").val());
            var b=parseInt($(".total8").val());
            var final_total = a + b ;
    //        alert(final_total);
            $(".final_total3").val(final_total+'%');
        }

    });
    
    function makeIt(id)
    {
        var value = id;
        var action = value.replace("-makeit", "");
//        alert(action);
        $.ajax({
            type: "POST",
            url: "ajaxbatch",
            data: {batch_id: $('#' + action + '_id').val(), batch_status: $('#' + action + '_status').val()},
            dataType: 'json',
            success: function(data) {
                $('#' + action + '-status').html(data.status);
                $('#' + action + '-button').html(data.button);
                $('#' + action + '_status').val(data.status);   
            }
        });
    }

</script>