<script>
    $(function () {
        
$("#link_user").on("change", function () {
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('ajax/find_user_hf'); ?>",
            data: { 
                user_id:$(this).val()
            },
            dataType: 'html',
            success: function (data) {
                $('#hf').html(data);
            }
        });
    });
    });
</script>