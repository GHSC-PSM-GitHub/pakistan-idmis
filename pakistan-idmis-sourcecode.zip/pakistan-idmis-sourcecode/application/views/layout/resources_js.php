<script>
    $(function () {
        $(document).ready(function(){
            
        $('#checkAll').attr('checked', false);
            $('#checkAll').click(function(e) {
            if ($('#checkAll').is(':checked') )
                    {
                            $('input[type="checkbox"]').attr('checked', 'checked');
                    }
                    else
                    {
                            $('input[type="checkbox"]').attr('checked', false);
                    }
            });
        

        $('#stkid').click(function(e) {
            var value = $(this).val();
            $(':checkbox').prop('checked', false); // Unchecks it
//            if(value == '')
//            {
//                $('input[type="checkbox"]').attr('checked', false);
//            }
//            alert(value);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/stkresource_info"); ?>',
                data: {
                    id: value
                },
                dataType: 'json',
                success: function (data) {
                    var user = JSON.parse(JSON.stringify(data));
//                    alert(user);
                    
                    var i;
                    for (i = 0; i < user.length; ++i) {
                        // do something with `substr[i]`
//                        $('#products')[user[i]].checked = true;
                        $("input[value='" + user[i] + "']").prop('checked', true);
                    }
                    
//                    $("#products").val(user);
//                    if(user.contact_person != '')
//                    {
//                        $("#contact_person").val(user.contact_person);
//                    }
//                    else{
//                        $("#contact_person").val('');
//                    }
//                    if(user.contact_numbers != '')
//                    {
//                        $("#contact_number").val(user.contact_numbers);
//                    }
//                    else{
//                        $("#contact_number").val('');``
//                    }
//                    if(user.contact_emails != '')
//                    {
//                        $("#contact_email").val(user.contact_emails);
//                    }
//                    else{
//                        $("#contact_email").val('');
//                    }
//                    if(user.warehouse_name != '')
//                    {
//                        $("#address").val(user.contact_address);
//                    }
//                    else{
//                        $("#address").val('');
//                    }
//                    $("#public_private").val(user.gender);
//                    $("#district").select2("val", "");
//                    $("#tehsil").select2("val", "");
//                    $("#uc").select2("val", "");
//                    $('#district').html(data);
                }
                });
            });
        
        $('#user_id').click(function(e) {
            var value = $(this).val();
            $(':checkbox').prop('checked', false); // Unchecks it
//            if(value == '')
//            {
//                $('input[type="checkbox"]').attr('checked', false);
//            }
//            alert(value);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/assign_wh_info"); ?>',
                data: {
                    id: value
                },
                dataType: 'json',
                success: function (data) {
                    var user = JSON.parse(JSON.stringify(data));
//                    alert(user);
                    
                    var i;
                    for (i = 0; i < user.length; ++i) {
                        // do something with `substr[i]`
//                        $('#products')[user[i]].checked = true;
                        $("input[value='" + user[i] + "']").prop('checked', true);
                    }
                    
//                    $("#products").val(user);
//                    if(user.contact_person != '')
//                    {
//                        $("#contact_person").val(user.contact_person);
//                    }
//                    else{
//                        $("#contact_person").val('');
//                    }
//                    if(user.contact_numbers != '')
//                    {
//                        $("#contact_number").val(user.contact_numbers);
//                    }
//                    else{
//                        $("#contact_number").val('');``
//                    }
//                    if(user.contact_emails != '')
//                    {
//                        $("#contact_email").val(user.contact_emails);
//                    }
//                    else{
//                        $("#contact_email").val('');
//                    }
//                    if(user.warehouse_name != '')
//                    {
//                        $("#address").val(user.contact_address);
//                    }
//                    else{
//                        $("#address").val('');
//                    }
//                    $("#public_private").val(user.gender);
//                    $("#district").select2("val", "");
//                    $("#tehsil").select2("val", "");
//                    $("#uc").select2("val", "");
//                    $('#district').html(data);
                }
                });
            });
            
        $('#user').click(function(e) {
            var value = $(this).val();
            $(':checkbox').prop('checked', false); // Unchecks it
//            if(value == '')
//            {
//                $('input[type="checkbox"]').attr('checked', false);
//            }
//            alert(value);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/assign_approval_code_info"); ?>',
                data: {
                    id: value
                },
                dataType: 'json',
                success: function (data) {
                    var user = JSON.parse(JSON.stringify(data));
//                    alert(user);
                    
                    var i;
                    for (i = 0; i < user.length; ++i) {
                        // do something with `substr[i]`
//                        $('#products')[user[i]].checked = true;
                        $("input[value='" + user[i] + "']").prop('checked', true);
                    }
                    
//                    $("#products").val(user);
//                    if(user.contact_person != '')
//                    {
//                        $("#contact_person").val(user.contact_person);
//                    }
//                    else{
//                        $("#contact_person").val('');
//                    }
//                    if(user.contact_numbers != '')
//                    {
//                        $("#contact_number").val(user.contact_numbers);
//                    }
//                    else{
//                        $("#contact_number").val('');``
//                    }
//                    if(user.contact_emails != '')
//                    {
//                        $("#contact_email").val(user.contact_emails);
//                    }
//                    else{
//                        $("#contact_email").val('');
//                    }
//                    if(user.warehouse_name != '')
//                    {
//                        $("#address").val(user.contact_address);
//                    }
//                    else{
//                        $("#address").val('');
//                    }
//                    $("#public_private").val(user.gender);
//                    $("#district").select2("val", "");
//                    $("#tehsil").select2("val", "");
//                    $("#uc").select2("val", "");
//                    $('#district').html(data);
                }
                });
            });    
            
            
        $('#category').change(function(e) {
//            alert("saad");
            var value = $(this).val();
            $(':checkbox').prop('checked', false); // Unchecks it
                $.ajax({
                    type: "POST",
                    url: '<?php echo base_url("ajax/category_field_info"); ?>',
                    data: {
                        id: value
                    },
                    dataType: 'json',
                    success: function (data) {
//                        alert(data);
                        var user = JSON.parse(JSON.stringify(data));
//                        alert(user.field_id);
//                        var array = user[0].split(',');
                        var farray = user.field_id;
                        var marray = user.is_mandatory;
    //                    console.log(array);

    //                    alert(array);
                        var i;
                        for (i = 0; i < farray.length; ++i) {
                            // do something with `substr[i]`
    //                        $('#products')[user[i]].checked = true;
                            $("input[id='field_list'][value='" + farray[i] + "']").prop('checked', true);
                            $("input[id='is_mandatory'][value='" + marray[i] + "']").prop('checked', true);
                        }
                    }
                });
                
            });
            
            
            $('#user').change(function(e) {
//            alert($(this).val());
            var value = $(this).val();
            $(':checkbox').prop('checked', false); // Unchecks it
                $.ajax({
                    type: "POST",
                    url: '<?php echo base_url("ajax/assign_document_approver"); ?>',
                    data: {
                        id: value
                    },
                    dataType: 'json',
                    success: function (data) {
//                        alert(data);
                        var user = JSON.parse(JSON.stringify(data));
//                        alert(user.field_id);
//                        var array = user[0].split(',');
                        var aarray = user.approval_code_id;
    //                    console.log(array);

    //                    alert(array);
                        var i;
                        for (i = 0; i < aarray.length; ++i) {
                            // do something with `substr[i]`
    //                        $('#products')[user[i]].checked = true;
                            $("input[id='assign_code'][value='" + aarray[i] + "']").prop('checked', true);
                        }
                    }
                });
                
            });
            
            $('#role_id').click(function(e) {
            var value = $(this).val();
            $(':checkbox').prop('checked', false); // Unchecks it
//            if(value == '')
//            {
//                $('input[type="checkbox"]').attr('checked', false);
//            }
//            alert(value);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/resource_info"); ?>',
                data: {
                    id: value
                },
                dataType: 'json',
                success: function (data) {
                    var user = JSON.parse(JSON.stringify(data));
                    var resourceid = user.id;
                    var resourceArray = resourceid.split(',');
                    var roleid = user.role_id;
                    var view = user.id;
                    var add = user.id;
                    var rank = user.rank;
                    var rankArray = rank.split(',');
//                    alert(resourceArray.length);
                    
                    var i;
                    for (i = 0; i < resourceArray.length; ++i) {
//                        alert(resourceid[i]);
                        // do something with `substr[i]`
//                        $('#products')[user[i]].checked = true;
//                        $("input[value='" + resourceid[i] + "']").prop('checked', true);
//                        $('#resources').checked = true;
//                        $("input[id=resources][value='" + resourceid[i] + "']").prop('checked', true);
                        $("input[name='" + 'resources['+resourceArray[i] +']'+ "']").prop('checked', true);
                        $("input[name='" + 'rank['+resourceArray[i] +']'+ "']").val(rankArray[i]);
                    }
                    
//                    $("#products").val(user);
//                    if(user.contact_person != '')
//                    {
//                        $("#contact_person").val(user.contact_person);
//                    }
//                    else{
//                        $("#contact_person").val('');
//                    }
//                    if(user.contact_numbers != '')
//                    {
//                        $("#contact_number").val(user.contact_numbers);
//                    }
//                    else{
//                        $("#contact_number").val('');``
//                    }
//                    if(user.contact_emails != '')
//                    {
//                        $("#contact_email").val(user.contact_emails);
//                    }
//                    else{
//                        $("#contact_email").val('');
//                    }
//                    if(user.warehouse_name != '')
//                    {
//                        $("#address").val(user.contact_address);
//                    }
//                    else{
//                        $("#address").val('');
//                    }
//                    $("#public_private").val(user.gender);
//                    $("#district").select2("val", "");
//                    $("#tehsil").select2("val", "");
//                    $("#uc").select2("val", "");
//                    $('#district').html(data);
                }
                });
            });
            
            
    });
});
        
</script>