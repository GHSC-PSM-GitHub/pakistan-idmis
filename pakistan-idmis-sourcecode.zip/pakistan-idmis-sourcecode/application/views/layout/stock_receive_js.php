<script>
    $(function () {
        $("#stock_receive").validate({
            rules: {
                refernce_number: "required",
                receiving_time: "required",
                received_from: "required",
                product: "required",
                manufacturer: "required",
                batch_number: "required",
                expiry_date: "required",
                quantity: "required"
            }
        });
        
//        $("#field3").rules('add', { greaterThan: "#field2" });
        
        $("#delivery_challan").validate({
            rules: {
//                full_name: {
//                    required:true,
//                    lettersonly: true
//                },
//                age: {
//                    required:true,
//                    min: 0,
//                    max: 120
//                },
                driver_contract: {
                    required:true,
//                    number: true,
//                    minlength: 11,
//                    maxlength: 11
                }
//                cnic: {
//                    number: true,
//                    minlength: 13,
//                    maxlength: 13
//
//                },
//                p_email: {
//                    emailfull: true
//                },
//                village: {
//                    required:true
//                }
//                province : {
//                    province: "required needsSelection"
//                }
            },
//            ignore: [],
//            ignore: ':hidden:not("#province")', // Tells the validator to check the hidden select
//            ignore : ".ignore, :hidden",
//            errorClass: 'invalid'
        });
//        $('#receiving_time').datepicker({
//             minDate: 0,
//            maxDate: "+10Y",
//            dateFormat: 'dd/mm/yy',
//            changeMonth: true,
//            changeYear: true
//        });
//        $("#expiry_date").change(function () {
//            var exp = $("#expiry_date").val();
//            var man = $("#manufacturing_date").val();
//            var mdy = exp.split('/');
//            var exp2 = new Date(mdy[2], mdy[0]-1, mdy[1]);
//            var mdy2 = man.split('/');
//            var man2 = new Date(mdy2[2], mdy2[0]-1, mdy2[1]);
//            var today = new Date();
//            
//            var diff =  Math.round((exp2-man2)/(1000*60*60*24));
//            var diff2 =  Math.round((exp2-today)/(1000*60*60*24));
//            var shelf_life = 0;
//            if(diff != 'undefined' && diff != 'NaN' && diff > 0 ){
//                if(diff2 != 'undefined' && diff2 != 'NaN' && diff2 > 0 ){
//                    shelf_life  = Math.round(diff2*100/diff);
//                    var msgg = "This batch will expire in :"+diff2+" days. Shelf life is:"+shelf_life+"%";
//                    if(shelf_life != 'undefined' && shelf_life >= 85){
//                         alertify.success(msgg);
//                         $("#msg_shelf_text").html('').html(msgg);
//                        $('#msg_shelf').slideUp();
//                    }else{
//                        
//                         alertify.error(msgg);
//                         $("#msg_shelf_text").html('').html(msgg);
//                        $('#msg_shelf').slideDown();
//                    }  
//                }
//            }
//            //alertify.success("Exp "+exp+",exp2:"+exp2+",man:"+man+",diff:"+diff+", diff frm today"+diff2+" , shelf life:"+(diff2*100/diff));
////          
//        });
        
        
        $("#productfielddatefield3").change(function () {
            var exp = $("#productfielddatefield3").val();
            var man = $("#productfielddatefield2").val();
            var mdy = exp.split('/');
            var exp2 = new Date(mdy[2], mdy[0]-1, mdy[1]);
            var mdy2 = man.split('/');
            var man2 = new Date(mdy2[2], mdy2[0]-1, mdy2[1]);
            var today = new Date();
            
            var diff =  Math.round((exp2-man2)/(1000*60*60*24));
            var diff2 =  Math.round((exp2-today)/(1000*60*60*24));
            var shelf_life = 0;
            if(diff != 'undefined' && diff != 'NaN' && diff > 0 ){
                if(diff2 != 'undefined' && diff2 != 'NaN' && diff2 > 0 ){
                    shelf_life  = Math.round(diff2*100/diff);
                    var msgg = "This batch will expire in :"+diff2+" days. Shelf life is:"+shelf_life+"%";
                    if(shelf_life != 'undefined' && shelf_life >= 85){
                         alertify.success(msgg);
                         $("#msg_shelf_text").html('').html(msgg);
                        $('#msg_shelf').slideUp();
                    }else{
                        
                         alertify.error(msgg);
                         $("#msg_shelf_text").html('').html(msgg);
                        $('#msg_shelf').slideDown();
                    }  
                }
            }
            //alertify.success("Exp "+exp+",exp2:"+exp2+",man:"+man+",diff:"+diff+", diff frm today"+diff2+" , shelf life:"+(diff2*100/diff));
//          
        });
//        $("#manufacturing_date").change(function () {
//            //alertify.success("manufacturing_date changed.");
////          $('#msg_shelf').show();  
//        });
        
//        $("#expiry_date").datepicker({
//            minDate: 0,
//            maxDate: "+10Y",
//     defaultDate: new Date(),
//            dateFormat: 'dd/mm/yyyy',
//            changeMonth: true,
//            changeYear: true
//        });
//        $("#manufacturing_date").datepicker({
//            minDate: 0,
//            maxDate: "+10Y", 
//     defaultDate: new Date(),
//            dateFormat: 'dd/mm/yyyy',
//            changeMonth: true,
//            changeYear: true
//        });
        $("#save_temp_receive").click(function () {
        $.ajax({
                type: "POST",
                url: "<?php echo base_url('inventory_management/save_temporary_records'); ?>",
                data: {
                    stock_master_id: $("#stock_master_id").val() 
                },
                dataType: 'html',
                success: function (data) { 
                    window.location.href =" <?php echo base_url('inventory_management/stock_receive_search'); ?>";
                }
            });
        });
        
        
        $("#dc_save_temp_receive").click(function () {
        $.ajax({
                type: "POST",
                url: "<?php echo base_url('inventory_management/save_temporary_records'); ?>",
                data: {
                    stock_master_id: $("#stock_master_id").val() 
                },
                dataType: 'html',
                success: function (data) { 
                    window.location.href =" <?php echo base_url('inventory_management/delivery_challan_form_search'); ?>";
                }
            });
        });
        
        $("#stockreceive_btn").click(function () {
        $.ajax({
                type: "POST",
                url: "<?php echo base_url('inventory_management/save_temporary_records'); ?>",
                data: {
                    stock_master_id: $("#stock_master_id").val() 
                },
                dataType: 'html',
                success: function (data) { 
                    window.location.href =" <?php echo base_url('inventory_management/stock_receive_search'); ?>";
                }
            });
        });
        
        
    });
    

    $(document).ready(function(){
      $("#receiving_time").datepicker({
          format: 'mm/dd/yyyy',
          autoclose: true,
      });
   });
   
   $(document).ready(function(){
      $("#productfielddatefield10").datepicker({
          format: 'mm/dd/yyyy',
          autoclose: true,
      });
   });
   
   
//   $(document).ready(function(){
//        $("#stock_receiving_time").datepicker({
//            format: 'mm/dd/yyyy',
//            autoclose: true,
//        }).on('changeDate', function (selected) {
//            var maxDate = new Date(selected.date.valueOf());
//            $('#manufacturing_date').datepicker('setEndDate', maxDate);
//        });
//   });
   
   $(document).ready(function(){
        $("#stock_receiving_time").datepicker({
            format: 'mm/dd/yyyy',
            autoclose: true,
        }).on('changeDate', function (selected) {
            var maxDate = new Date(selected.date.valueOf());
            $('#productfielddatefield2').datepicker('setEndDate', maxDate);
        });
   });
   
   $(document).ready(function(){
      $("#receiving_times").datepicker({
//          startDate: '-1M',
          format: 'mm/dd/yyyy',
          autoclose: true,
      });
   });


//    $(document).ready(function(){
//   $("#manufacturing_date").datepicker({
//       format: 'mm/dd/yyyy',
//       autoclose: true,
//   }).on('changeDate', function (selected) {
//       var minDate = new Date(selected.date.valueOf());
//       $('#expiry_date').datepicker('setStartDate', minDate);
//   });
//
//   $("#expiry_date").datepicker({
//       format: 'mm/dd/yyyy',
//       autoclose: true,
//   }).on('changeDate', function (selected) {
//           var minDate = new Date(selected.date.valueOf());
//           $('#manufacturing_date').datepicker('setEndDate', minDate);
//   });
//});


$(document).ready(function(){
   $("#productfielddatefield2").datepicker({
       format: 'mm/dd/yyyy',
       autoclose: true,
   }).on('changeDate', function (selected) {
       var minDate = new Date(selected.date.valueOf());
       $('#productfielddatefield3').datepicker('setStartDate', minDate);
   });

   $("#productfielddatefield3").datepicker({
       format: 'mm/dd/yyyy',
       autoclose: true,
   }).on('changeDate', function (selected) {
           var minDate = new Date(selected.date.valueOf());
           $('#productfielddatefield2').datepicker('setEndDate', minDate);
   });
});

    $("#receive_from_supplier").change(function(){
            
            var value = $(this).val();
            if(value != '')
            {
                $('#supplier_info').fadeIn();
            }
            else{
                $('#supplier_info').fadeOut();
            }
//            alert(value);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/supplier_combo"); ?>',
                data: {
                    id: value,
                    lvl: 4
                },
                dataType: 'json',
                success: function (data) {
                    var user = JSON.parse(JSON.stringify(data));
//                    alert(data);
                    if(user.contact_person != '')
                    {
                        $("#contact_person").val(user.contact_person);
                    }
                    else{
                        $("#contact_person").val('');
                    }
                    if(user.contact_numbers != '')
                    {
                        $("#contact_number").val(user.contact_numbers);
                    }
                    else{
                        $("#contact_number").val('');``
                    }
                    if(user.contact_emails != '')
                    {
                        $("#contact_email").val(user.contact_emails);
                    }
                    else{
                        $("#contact_email").val('');
                    }
                    if(user.warehouse_name != '')
                    {
                        $("#address").val(user.contact_address);
                    }
                    else{
                        $("#address").val('');
                    }
//                    $("#public_private").val(user.gender);
//                    $("#district").select2("val", "");
//                    $("#tehsil").select2("val", "");
//                    $("#uc").select2("val", "");
//                    $('#district').html(data);
                }
            });
//            $.ajax({
//                type: "POST",
//                url: '<?php echo base_url("ajax/cities"); ?>',
//                data: {
//                    province_id: value
//                },
//                dataType: 'html',
//                success: function (data) {
//                    $('#city').html(data);
//                }
//            });
        }).change();
        
        $("#challan_type").change(function(){
            
            var value = $(this).val();
            if(value == '1')
            {
                $("#po_quantity").prop('required',true);
                $("#wh_detail_info").prop('required',false);
                $("#receive_from_warehouse").prop('required',false);
                $("#receive_from_supplier").prop('required',true);
                $("#po_detail_info").prop('required',false);
                $("#refernce_number").prop('required',false);
                $('#show_receive_from_warehouse').fadeOut();
                $('#show_receive_from_supplier').fadeIn();
                $('#po_type_detail').fadeIn();
                $('#nr_type_detail').fadeOut();
                $('#fo_type_detail').fadeOut();
                
                $('#show_po_quantity').fadeIn();
            }
            else if(value == '2'){
                $("#po_quantity").prop('required',false);
                $("#receive_from_supplier").prop('required',true);
                $("#wh_detail_info").prop('required',false);
                $("#po_detail_info").prop('required',false);
                $("#receive_from_warehouse").prop('required',false);
                $("#refernce_number").prop('required',true);
                $('#show_receive_from_supplier').fadeIn();
                $('#show_receive_from_warehouse').fadeOut();
                $('#nr_type_detail').fadeIn();
                $('#fo_type_detail').fadeOut();
                $('#po_type_detail').fadeOut();
                
                $('#show_po_quantity').fadeOut();
            }
            else if(value == '3'){
                $("#po_quantity").prop('required',false);
                $("#wh_detail_info").prop('required',false);
                $("#receive_from_warehouse").prop('required',true);
                $("#receive_from_supplier").prop('required',false);
                $("#po_detail_info").prop('required',false);
                $("#refernce_number").prop('required',false);
                $('#show_receive_from_warehouse').fadeIn();
                $('#show_receive_from_supplier').fadeOut();
                $('#fo_type_detail').fadeIn();
                $('#nr_type_detail').fadeOut();
                $('#po_type_detail').fadeOut();
                
                $('#show_po_quantity').fadeOut();
            }
            else{
                $('#show_receive_from_supplier').fadeOut();
                $('#show_receive_from_warehouse').fadeOut();
                $('#nr_type_detail').fadeOut();
                $('#fo_type_detail').fadeOut();
                $('#po_type_detail').fadeOut();
                $('#show_po_quantity').fadeOut();
            }
        }).change();
        
        
        $('.types_select').attr("disabled", true);
        $('.types_select').hide();
        
	$('#checkAll').attr('checked', false);
	$('#checkAll').click(function(e) {
        if ($('#checkAll').is(':checked') )
		{
			$('input[type="checkbox"]').attr('checked', 'checked');
		}
		else
		{
			$('input[type="checkbox"]').attr('checked', false);
		}
        });



        $("select[id$='-types']").attr("readonly", true);

//        $('#estimated_life').priceFormat({
//            prefix: '',
//            thousandsSeparator: '',
//            suffix: '',
//            centsLimit: 0,
//            limit: 2
//        });
        
//        function delete_labtest(){
//            $("button[id$='-deletedc']").click(function () {
//                if(confirm('Are you sure you want to Delete?')){
//                    var value = $(this).attr("id");
//                    var params = value.replace("-deletedc", "");
//                    var arr = params.split('_');
//                    $.post("ajax_deldc",
//                    {
//                        'pk_id': arr[0],
//                        'fk_stock_id': arr[1]
//                    },
//                    function(data, status){
////                        $("#dc_result").html(data);
////                        delete_labtest();
//                    });  
//                }
//            });
//        }

     $(document).ready(function(){
        $("button[id$='-deletedc']").click(function(e){
       //    e.preventDefault(); 
           var value = $(this).attr("id");
           var params = value.replace("-deletedc", "");
           var arr = params.split('_');
           var btn = this;

           $.ajax({
             type: "POST",
             url: "<?php echo base_url('inventory_management/ajax_deldc')?>",
             cache: false,
             data: {'pk_id': arr[0],'fk_stock_id': arr[1]}, // since, you need to delete post of particular id
             success: function(reaksi) {
                if (reaksi){
                   alert("Record Deleted Successfully.");
                   $(btn).closest('tr').fadeOut("slow");
//                   $("#dc_result").html(reaksi);
                } else {
                    alert("ERROR");
                }
              }
          });
       });
    });

    $(document).ready(function(){
        $("button[id$='-deletesr']").click(function(e){
       //    e.preventDefault(); 
           var value = $(this).attr("id");
           var params = value.replace("-deletesr", "");
           var arr = params.split('_');
           var btn = this;

           $.ajax({
             type: "POST",
             url: "<?php echo base_url('inventory_management/ajax_delsr')?>",
             cache: false,
             data: {'pk_id': arr[0],'fk_stock_id': arr[1]}, // since, you need to delete post of particular id
             success: function(reaksi) {
                if (reaksi){
                   alert("Record Deleted Successfully.");
                   $(btn).closest('tr').fadeOut("slow");
//                   $("#dc_result").html(reaksi);
                } else {
                    alert("ERROR");
                }
              }
          });
       });
    });
    
    $("#receivetype").change(function(){
            
            var value = $(this).val();
            if(value == '1')
            {
                $("#receiveno").prop('required',false);
                $('#show_receiveno').fadeOut();
                $("#dctypes").fadeOut();
                $("#reference_number").prop('readonly',false);
                $('#show_receive_from_supplier').fadeIn();
            }
            else if(value == '2'){
                $("#receiveno").prop('required',true);
                $('#show_receiveno').fadeIn();
                $("#dctypes").fadeIn();
                $("#reference_number").prop('readonly',true);
            }
            else{
                $("#receiveno").prop('required',false);
                $('#show_receiveno').fadeOut();
                $("#dctypes").fadeOut();
                $("#reference_number").prop('readonly',false);
                $('#show_receive_from_supplier').fadeIn();
            }
        }).change();

//        $(document).ready(function(){
//            $("#manufacturing_date").datepicker({
//                format: 'mm/dd/yyyy',
//                autoclose: true,
//            }).on('changeDate', function (selected) {
//                var minDate = new Date(selected.date.valueOf());
//                $('#expiry_date').datepicker('setStartDate', minDate);
//            });
//
//            $("#expiry_date").datepicker({
//                format: 'mm/dd/yyyy',
//                autoclose: true,
//            }).on('changeDate', function (selected) {
//                    var minDate = new Date(selected.date.valueOf());
//                    $('#manufacturing_date').datepicker('setEndDate', minDate);
//            });
//         });
         
         $(document).ready(function(){
            $("#productfielddatefield2").datepicker({
                format: 'mm/dd/yyyy',
                autoclose: true,
            }).on('changeDate', function (selected) {
                var minDate = new Date(selected.date.valueOf());
                $('#productfielddatefield3').datepicker('setStartDate', minDate);
            });

            $("#productfielddatefield3").datepicker({
                format: 'mm/dd/yyyy',
                autoclose: true,
            }).on('changeDate', function (selected) {
                    var minDate = new Date(selected.date.valueOf());
                    $('#productfielddatefield2').datepicker('setEndDate', minDate);
            });
         });
         
         
         $(document).ready(function(){
            $("#start_date").datepicker({
                format: 'dd/mm/yyyy',
                autoclose: true,
            }).on('changeDate', function (selected) {
                var minDate = new Date(selected.date.valueOf());
                $('#end_date').datepicker('setStartDate', minDate);
            });

            $("#end_date").datepicker({
                format: 'dd/mm/yyyy',
                autoclose: true,
            }).on('changeDate', function (selected) {
                    var minDate = new Date(selected.date.valueOf());
                    $('#start_date').datepicker('setEndDate', minDate);
            });
         });
         
         $("#dc_date").datepicker({
                format: 'mm/dd/yyyy',
                autoclose: true,
            });
            
//        $("#product").click(function(){
//            
//            var value = $('#stakeholder').val();
//            if(value == '')
//            {
////                $("#product").val($("#product option:first").val());
////                $('#product option[value=""]');
////                $('#product option[value=""]').attr('selected','selected');
////                    $("div#product select").val("");
////$("#product option").attr("selected", false); //Unselect each option
////$("#product").val('');
//                    alert('Please select stakeholder first');
//                    return false;
//            }
//        });
            
            $("#stakeholder").change(function(){
            
            var value = $(this).val();
            if(value == '')
            {
                value = $('#sstakeholder').val();
            }
            var issue_product_edits = $('#issue_product_edit').val();
            
//            else{
//                $('#supplier_info').fadeOut();
//            }
//            alert(value);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/getproduct_bystkid"); ?>',
                data: {
                    id: value
                },
                dataType: 'json',
                success: function (data) {
                    var user = JSON.parse(JSON.stringify(data));
//                    alert(user);
                    if(user)
                    {
                        $("#product").html(user);
                        $("#issue_product").html(user);
                        $("#adj_product").html(user);
                        $("#change_product_loc").html(user);
                    }
                    if(issue_product_edits)
                    {
                        $("#issue_product").select2().select2('val',issue_product_edits).change();
                    }
//                    $("#public_private").val(user.gender);
//                    $("#district").select2("val", "");
//                    $("#tehsil").select2("val", "");
//                    $("#uc").select2("val", "");
//                    $('#district').html(data);
                }
            });
            
//            var value = $(this).val();
//            if(value == '1')
//            {
//                $("#po_quantity").prop('required',true);
//                $("#wh_detail_info").prop('required',false);
//                $("#receive_from_warehouse").prop('required',false);
//                $("#receive_from_supplier").prop('required',true);
//                $("#po_detail_info").prop('required',true);
//                $('#show_receive_from_warehouse').fadeOut();
//                $('#show_receive_from_supplier').fadeIn();
//                $('#po_type_detail').fadeIn();
//                $('#fo_type_detail').fadeOut();
//                
//                $('#show_po_quantity').fadeIn();
//            }
        }).change();
    
    
    $(document).ready(function(){
//            $("input[type='number'][name='pi_quantity']").keyup(function() {
////                alert('saad');
//            if (parseInt($(this).val()) > $('#actual_rec_qty').val()) {
////                alert("To order quantity greater than 40 please use the contact form.");
////                this.value == '';
//                $(this).val('');
//                /* or with jQuery: $(this).val(''); */
//                $(this).focus();
//                return false;
//            }
//        });
        
        $("#currency").change(function() {
//                alert('saad');
            if ($('#currency').val() == '33') {
                $("#conversion_rate").prop('readonly',true);
                $("#conversion_rate").val('1');
            }
            else{
                $("#conversion_rate").prop('readonly',false);
                $("#conversion_rate").val('');
            }
        }).change();
        
         $(".missingqty").keyup(function() {
//             alert('saad');
//                alert();
            if (parseInt($(this).val()) > $(this).closest('td').prev('.piqty').text()) {
//                alert("To order quantity greater than 40 please use the contact form.");
//                this.value == '';
                $(this).val('');
                /* or with jQuery: $(this).val(''); */
                $(this).focus();
                return false;
            }
        });
        
        $(document).on('change keyup blur','#pi_quantity', function(e){
//        $("#pi_quantity").keyup(function() {
//             alert('saad');
//                alert();
            if (parseInt($(this).val()) > $('#actual_rec_qty').val()) {
//                alert("To order quantity greater than 40 please use the contact form.");
//                this.value == '';
//                $(this).val($('#actual_rec_qty').val());
                $(this). attr({
//                "max" : 10, // substitute your own.
                    "max" : $('#actual_rec_qty').val() // values (or variables) here.
                });
                /* or with jQuery: $(this).val(''); */
                $(this).focus();
                return false;
            }
        });
        
        $(document).on('change keyup blur','#actual_rec_qty', function(e){
//             alert('saad');
//                alert();
            if (parseInt($(this).val()) > $('#dc_quantity').val()) {
                //                alert("To order quantity greater than 40 please use the contact form.");
//                this.value == '';
//                $(this).val($('#dc_quantity').val());
                $(this). attr({
//                "max" : 10, // substitute your own.
                "max" : $('#dc_quantity').val() // values (or variables) here.
                });
                /* or with jQuery: $(this).val(''); */
                $(this).focus();
                return false;
            }
        });
        
        $(document).on('change keyup blur','#dcquantity', function(e){
//             alert('saad');
//                alert();
            if (parseInt($(this).val()) < $('#arquantity').val()) {
                //                alert("To order quantity greater than 40 please use the contact form.");
//                this.value == '';
//                $(this).val($('#dcquantity').val());
                $('#dcquantity'). attr({
//                "max" : 10, // substitute your own.
                "min" : $('#arquantity').val() // values (or variables) here.
                });
                /* or with jQuery: $(this).val(''); */
                $(this).focus();
                return false;
            }
        });
        
        $(document).on('change keyup blur','#arquantity', function(e){
//             alert('saad');
//                alert();
            if (parseInt($(this).val()) < $('#piquantity').val()) {
                //                alert("To order quantity greater than 40 please use the contact form.");
//                this.value == '';
//                $(this).val($('#dcquantity').val());
                $('#arquantity'). attr({
                "min" : $('#piquantity').val(), // substitute your own.
//                "max" : $('#dcquantity').val() // values (or variables) here.
                });
                /* or with jQuery: $(this).val(''); */
                $(this).focus();
                return false;
            }
            if (parseInt($(this).val()) > $('#dcquantity').val()) {
                //                alert("To order quantity greater than 40 please use the contact form.");
//                this.value == '';
//                $(this).val($('#dcquantity').val());
                $('#arquantity'). attr({
//                "min" : $('#piquantity').val(), // substitute your own.
                "max" : $('#dcquantity').val() // values (or variables) here.
                });
                /* or with jQuery: $(this).val(''); */
                $(this).focus();
                return false;
            }
        });
        
        $(document).on('change keyup blur','#piquantity', function(e){
//        $("#pi_quantity").keyup(function() {
//             alert('saad');
//                alert();
            if (parseInt($(this).val()) > $('#arquantity').val()) {
//                alert("To order quantity greater than 40 please use the contact form.");
//                this.value == '';
//                $(this).val($('#arquantity').val());
                $('#piquantity'). attr({
//                "max" : 10, // substitute your own.
                "max" : $('#arquantity').val() // values (or variables) here.
                });
                /* or with jQuery: $(this).val(''); */
                $(this).focus();
                return false;
            }
        });
        
        
        $("#actual_rec_qty,#unit_price,#conversion_rate").keyup(function() {
            var res = $('#actual_rec_qty').val()*$('#unit_price').val()*$('#conversion_rate').val();
            $('#amount_in_pkr').val(res);
        });
        
        $(".returnpiqty").keyup(function() {
//             alert('saad');
//                alert();
            if (parseInt($(this).val()) > $(this).closest('td').prev('.piqty').text()) {
//                alert("To order quantity greater than 40 please use the contact form.");
//                this.value == '';
                $(this).val('');
                /* or with jQuery: $(this).val(''); */
                $(this).focus();
                return false;
            }
        });
        
        $(".returntiqty").keyup(function() {
//             alert('saad');
//                alert($(this).closest('td').prev('.tiqty').text());
            if (parseInt($(this).val()) > $(this).closest('td').prev('.tiqty').text()) {
//                alert("To order quantity greater than 40 please use the contact form.");
//                this.value == '';
                $(this).val('');
                /* or with jQuery: $(this).val(''); */
                $(this).focus();
                return false;
            }
        });
        
        var total = 0;
        $(".srmissingqty").keyup(function() {
//                alert(parseInt($(this).val()));
            if (parseInt($(this).val()) > $(this).closest('td').prev('.tiqty').text()) {
//                alert("To order quantity greater than 40 please use the contact form.");
//                this.value == '';
                $(this).val('');
                /* or with jQuery: $(this).val(''); */
                $(this).focus();
                return false;
            }
            else{
                var value = ( $(this).val() ) * ( $(this).closest('tr').find("td:eq(6)").text() ) * ( $(this).closest('tr').find("td:eq(8)").text() ) ;
//                alert(value);
                $(this).closest('tr').find("td:eq(15) input[type='number']").val(value);
                total  += value;
                $("#batch_totalprice").text(total);
            }
           }); 
            
            
//            $("table").change(function(){
//                var values;
//                var theTotal = 0;
//                $(".batch_totalprice").each(function () {
//                    if($(this).val() != '')
//                    {
//                        values = $(this).val();
//                        values = values.substr(0, values.indexOf(','));
//                        values = values.replace(' ', '');
//                        theTotal += parseInt(values);
//                        $("#gtotal").text( + theTotal);
//                    }else{
//                        
//                    }
//        });
//        });
        $("#product").change(function () {
            var value = $(this).children(":selected").attr("id");
//           var params = value.replace("-deletesr", "");
            var arr = String(value).split('_');
//            alert(arr[0]);
//            alert(arr[1]);
            var btn = this;
//            var editbatchid = '';
//            $('#batch').attr('disabled',true);
            var product = $("#product").val();
//            var wh_id = $("#center_from").val();
//            if($("#editbatchid").val() != '')
//            {
//               editbatchid = $("#editbatchid").val();
////               alert(editbatchid);
//            }
            $.ajax({
                async: true,
                type: "POST",
                url: "<?php echo base_url('inventory_management/getproductfields'); ?>",
                data: {
                    item_id: product,
//                    wh_id: wh_id,
//                    editbatchid:editbatchid,
                    product_type : arr[1],
                    stk_id : arr[2]
                },
                dataType: 'html',
                success: function (data) {
                    
//                    var user = JSON.parse(JSON.stringify(data));
//                    alert(data);
                            $('#product_fields').html(data);
//                            $('.datepick').each(function(){
//                                $(this).datepicker({
//                                    format: 'mm/dd/yyyy',
//                                    autoclose: true,
////                                        min: ''
//                        }).change(function() {
//                                    $(this).valid();  // triggers the validation test
//                                
//                                
////                                 $("#field2").datepicker({
////                                        format: 'mm/dd/yyyy',
////                                        autoclose: true,
////                                    }).on('changeDate', function (selected) {
////                                        var minDate = new Date(selected.date.valueOf());
////                                        $('#field3').datepicker('setStartDate', minDate);
////                                    });
////
////                                    $("#field3").datepicker({
////                                        format: 'mm/dd/yyyy',
////                                        autoclose: true,
////                                    }).on('changeDate', function (selected) {
////                                            var minDate = new Date(selected.date.valueOf());
////                                            $('#field2').datepicker('setEndDate', minDate);
////                                    });
//                    });
//
//                            });
                            
                            $("#productfielddatefield2").datepicker({
                                format: 'mm/dd/yyyy',
                                autoclose: true,
                            }).on('changeDate', function (selected) {
                                var minDate = new Date(selected.date.valueOf());
                                $('#productfielddatefield3').datepicker('setStartDate', minDate);
                            });

                            $("#productfielddatefield3").datepicker({
                                format: 'mm/dd/yyyy',
                                autoclose: true,
                            }).on('changeDate', function (selected) {
                                    var minDate = new Date(selected.date.valueOf());
                                    $('#productfielddatefield2').datepicker('setEndDate', minDate);
                            });
                            
                            $(document).ready(function(){
                                $("#productfielddatefield10").datepicker({
                                    format: 'mm/dd/yyyy',
                                    autoclose: true,
                                });
                             });
                            
//                            $('#productfielddatefield2').datepicker();
//                            $('#productfielddatefield3').datepicker();
                            $('.dynamicselect2me').select2();
                            

                }
            });
            
            
            $.ajax({
                async: true,
                type: "POST",
                url: "<?php echo base_url('inventory_management/getmanufacturerfield'); ?>",
                data: {
                    item_id: product,
//                    wh_id: wh_id,
//                    editbatchid:editbatchid,
                    product_type : arr[1],
                    stk_id : arr[2]
                },
                dataType: 'html',
                success: function (data) {
//                    alert(data);
                    if(data != '')
                    {
                        var array = data.split('_');
                        $('#manufacturer_name').val(array[0]);
                        $('#manufacturer_id').val(array[1]);
                        $('#sh_manufacturer').fadeIn();
                        if(array[2] != '')
                        {
                            $('#dosage_form_sh').val(array[2]);
                            $('#sh_dosage_form').fadeIn();
                        }
                        else{
                            $('#sh_dosage_form').fadeOut();
                            $('#dosage_form_sh').val('');
                        }
                    }
                    else{
                        $('#manufacturer_name').val('');
                        $('#manufacturer_id').val('');
                        $('#dosage_form_sh').val('');
                        $('#sh_manufacturer').fadeOut();
                        $('#sh_dosage_form').fadeOut();
                    }
                }
            });
            
            
        }).change();
        
//        function addScript() {
//    var s = document.createElement('script');
//    s.type = 'text/javascript';
//    s.src = '<?php echo base_url('plugins/select2/select2.js'); ?>';
//    document.getElementsByTagName('head')[0].appendChild(s);
////    return s;  // to remove it later
//}
        });
        
        $(document).ready(function(){
      $("#productfielddate").datepicker({
          format: 'mm/dd/yyyy',
          autoclose: true,
      });

      $("#date_vehicle_req").datepicker({
          format: 'mm/dd/yyyy',
          autoclose: true,
          startDate : new Date()
      });
      
      $("#demand_req_date").datepicker({
          format: 'mm/dd/yyyy',
          autoclose: true,
          startDate : new Date()
      });
      
      $("#vehicle_req_date").datepicker({
          format: 'mm/dd/yyyy',
          autoclose: true,
          startDate : new Date()
      });
      
      $("#giws_date").datepicker({
          format: 'mm/dd/yyyy',
          autoclose: true
      });
      
      $("#po_info_date").datepicker({
          format: 'mm/dd/yyyy',
          autoclose: true
      });
      
      $("#inspection_date").datepicker({
          format: 'mm/dd/yyyy',
          autoclose: true
      });
      
      $("#date_of_receiving").datepicker({
          format: 'mm/dd/yyyy',
          autoclose: true
      });
//      $("#tabs").tabs();
   });
   
       $(document).ready(function(){
           
           
           $("#issue_batch").change(function(){
            
            var value = $(this).val();
            if(value == 'others')
            {
//                $("#po_quantity").prop('required',true);
//                $("#wh_detail_info").prop('required',false);
//                $("#receive_from_warehouse").prop('required',false);
//                $("#receive_from_supplier").prop('required',true);
//                $("#po_detail_info").prop('required',true);
//                $("#refernce_number").prop('required',false);
                $('#other_show_info').fadeIn();
                $('#show_batch').fadeIn();
                $('#show_main_info').fadeOut();
                
                $("#other_prod_date").datepicker({
                    format: 'mm/dd/yyyy',
                    autoclose: true,
                }).on('changeDate', function (selected) {
                    var minDate = new Date(selected.date.valueOf());
                    $('#other_expiry_date').datepicker('setStartDate', minDate);
                });

                $("#other_expiry_date").datepicker({
                    format: 'mm/dd/yyyy',
                    autoclose: true,
                }).on('changeDate', function (selected) {
                        var minDate = new Date(selected.date.valueOf());
                        $('#other_prod_date').datepicker('setEndDate', minDate);
                });
                
            }
            else{
                $('#show_batch').fadeIn();
                $('#other_show_info').fadeOut();
                $('#show_main_info').fadeIn();
            }
        });
           
           
//           $("#wh_btn").click(function() {
//                $("#field2").datepicker({
//                    format: 'mm/dd/yyyy',
//                    autoclose: true,
//                }).on('changeDate', function (selected) {
//                    var minDate = new Date(selected.date.valueOf());
//                    $('#field3').datepicker('setStartDate', minDate);
//                });
//
//                $("#field3").datepicker({
//                    format: 'mm/dd/yyyy',
//                    autoclose: true,
//                }).on('changeDate', function (selected) {
//                        var minDate = new Date(selected.date.valueOf());
//                        $('#field2').datepicker('setEndDate', minDate);
//                });
//        });

        
        $("#dc_quantity, #actual_rec_qty").on("keydown keyup", sum);
                function sum() {
//                $("#sum").val(Number($("#num1").val()) + Number($("#num2").val()));
                $("#dc_remove_rec").val(Number($("#dc_quantity").val()) - Number($("#actual_rec_qty").val()));
	}
        
        
        $("#po_cmu").change(function(){
            
            var value = $(this).val();
            if(value)
            {
                $('#show_po_cmu_date').fadeIn();
//                $("#po_detail_info").prop('required',true);
//                $("#refernce_number").prop('required',false);
                $.ajax({
                  type: "POST",
                  url: "<?php echo base_url('inventory_management/get_po_infos')?>",
                  cache: false,
                  data: {'pk_id': value}, // since, you need to delete post of particular id
                  dataType: 'json',
                  success: function(data) {
                      $("#po_cmu_date").val(data.date);
                   }
               });
            }
            else{
                $('#show_po_cmu_date').fadeOut();
            }
            
        }).change();
        
        $("#po_gf").change(function(){
            
            var value = $(this).val();
            if(value)
            {
                $('#show_po_gf_date').fadeIn();
//                $("#po_detail_info").prop('required',true);
//                $("#refernce_number").prop('required',false);
                $.ajax({
                  type: "POST",
                  url: "<?php echo base_url('inventory_management/get_po_infos')?>",
                  cache: false,
                  data: {'pk_id': value}, // since, you need to delete post of particular id
                  dataType: 'json',
                  success: function(data) {
                      $("#po_gf_date").val(data.date);
                   }
               });
            }
            else{
                $('#show_po_gf_date').fadeOut();
            }
        }).change();
    });
    
    
    $('#no_of_vehicle, #vehicle_rent').on('change keyup blur', function () {
//            if($("#quantity").val() != '')
//            {
//                alert('saad');
                var value = $("#no_of_vehicle").val() * $("#vehicle_rent").val();
                $("#vehicle_amount").val(value);
//            }
        }).keyup();
        
        
    $("#transport_req_product").change(function(){
        $.ajax({
                async: true,
                type: "POST",
                url: "<?php echo base_url('inventory_management/getmanufacturerld'); ?>",
                data: {
                    item_id: $("#transport_req_product").val(),
                },
                dataType: 'html',
                success: function (data) {
//                    alert(data);
                    if(data != '')
                    {
//                        $('#manufacturer').val(data);
                        $("#manufacturer").select2("val", data);
                    }
                    else{
//                        $('#manufacturer_name').val('');
                    }
                }
            });
        });
        
        
</script>