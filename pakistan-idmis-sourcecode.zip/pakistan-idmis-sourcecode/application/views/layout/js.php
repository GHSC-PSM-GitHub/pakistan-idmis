<script>
	/* $(function () {
        $('.select2me').select2();
        $("#nominee").multiselect({
            includeSelectAllOption: false,
            enableFiltering: true,
            enableCaseInsensitiveFiltering: true
        });
    }); */
	$(function() {
		$('.select2me').select2();
		var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
		var csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

		//        $("#province").change(function(){
		//            var value = $(this).val();
		//            $.ajax({
		//                type: "POST",
		//                url: '<?php echo base_url("ajax/combo"); ?>',
		//                data: {
		//                    id: value,
		//                    lvl: 4,
		//                    [csrfName]: csrfHash
		//                },
		//                dataType: 'html',
		//                success: function (data) {
		//                    $('#district').html(data);
		//                }
		//            });
		//            $.ajax({
		//                type: "POST",
		//                url: '<?php echo base_url("ajax/cities"); ?>',
		//                data: {
		//                    province_id: value, 
		//                    [csrfName]: csrfHash
		//                },
		//                dataType: 'html',
		//                success: function (data) {
		//                    $('#city').html(data);
		//                }
		//            });
		//        }).change();

		$("#province_village").change(function() {
			var value = $(this).val();
			$.ajax({
				type: "POST",
				url: '<?php echo base_url("ajax/combo_village"); ?>',
				data: {
					id: value,
					lvl: 4,
					[csrfName]: csrfHash
				},
				dataType: 'html',
				success: function(data) {
					$('#district_village').html(data);
				}
			});
		}).change();

		$("#village").click(function() {
			var value = $(this).val();
			$.ajax({
				type: "POST",
				url: '<?php echo base_url("ajax/village_uc"); ?>',
				data: {
					id: value,
					[csrfName]: csrfHash
				},
				dataType: 'html',
				success: function(data) {
					$('#uc').html(data);
				}
			});
			$.ajax({
				type: "POST",
				url: '<?php echo base_url("ajax/village_tehsil"); ?>',
				data: {
					id: value,
					[csrfName]: csrfHash
				},
				dataType: 'html',
				success: function(data) {
					$('#tehsil').html(data);
				}
			});
			$.ajax({
				type: "POST",
				url: '<?php echo base_url("ajax/village_district"); ?>',
				data: {
					id: value,
					[csrfName]: csrfHash
				},
				dataType: 'html',
				success: function(data) {
					$('#district').html(data);
				}
			});
			$.ajax({
				type: "POST",
				url: '<?php echo base_url("ajax/village_province"); ?>',
				data: {
					id: value,
					[csrfName]: csrfHash
				},
				dataType: 'html',
				success: function(data) {
					$('#province').html(data);
				}
			});
		}).click();

		$("#province_lab").change(function() {
			var value = $(this).val();
			$.ajax({
				type: "POST",
				url: '<?php echo base_url("ajax/facilities"); ?>',
				data: {
					id: value,
					[csrfName]: csrfHash
				},
				dataType: 'html',
				success: function(data) {
					$('#lab_list').html(data);
				}
			});
		});

		//        $("#district").change(function(){
		//            var value = $(this).val();
		//            $.ajax({
		//                type: "POST",
		//                url: '<?php echo base_url("ajax/combo"); ?>',
		//                data: {
		//                    id: value,
		//                    lvl: 5,
		//                    [csrfName]: csrfHash
		//                },
		//                dataType: 'html',
		//                success: function (data) {
		//                    $('#tehsil').html(data);
		//                }
		//            });
		//        }).change();

		$("#district_village").change(function() {
			var value = $(this).val();
			$.ajax({
				type: "POST",
				url: '<?php echo base_url("ajax/combo_village"); ?>',
				data: {
					id: value,
					lvl: 5,
					[csrfName]: csrfHash
				},
				dataType: 'html',
				success: function(data) {
					$('#tehsil_village').html(data);
				}
			});
		}).change();

		//        xxxxxxxxxxxxxxxxxxxxxx   Changes STart xxxxxxxxxxxxxxxxxxxxxxxxxxxxx

		$("#province_change").change(function() {
			//alert("Hello");
			var value = $(this).val();
			$.ajax({
				type: "POST",
				url: '<?php echo base_url("ajax/combo_village"); ?>',
				data: {
					id: value,
					lvl: 4,
					[csrfName]: csrfHash
				},
				dataType: 'html',
				success: function(data) {
					$('#district_change').html(data);
				}
			});
		});

		$("#district_change").change(function() {
			var value = $(this).val();
			$('#center_patient').html('');
			$.ajax({
				type: "POST",
				url: '<?php echo base_url("ajax/combo_village_facilities"); ?>',
				data: {
					id: value,
					lvl: 5,
					[csrfName]: csrfHash
				},
				dataType: 'html',
				success: function(data) {
					$('#center_patient').html(data);
				}
			});
		});

		$('#checkAll').attr('checked', false);
		$('#checkAll').click(function(e) {
			if ($('#checkAll').is(':checked')) {
				$('input[type="checkbox"]').attr('checked', 'checked');
			} else {
				$('input[type="checkbox"]').attr('checked', false);
			}
		});

		//          $('.types_select').attr("disabled", true);
		//        $('.types_select').hide();

  		$("#stakeholder").change(function(){
            var value = $(this).val();
            var stock_type = $('#stock_type').val();
            if(value == '')
            {
                value = $('#sstakeholder').val();
            }
            var issue_product_edits = $('#issue_product_edit').val();
            
//            else{
//                $('#supplier_info').fadeOut();
//            }
//            alert(value);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/getproduct_bystkid"); ?>',
                data: {
                    id: value,
                    stock_type:stock_type
                },
                dataType: 'json',
                success: function (data) {
                    var user = JSON.parse(JSON.stringify(data));
//                    alert(user);
                    if(user)
                    {
                        $("#product").html(user);
                        $("#issue_product").html(user);
                        $("#adj_product").html(user);
                        $("#change_product_loc").html(user);
                    }
                    if(issue_product_edits)
                    {
                        $("#issue_product").select2().select2('val',issue_product_edits).change();
                    }
//                    $("#public_private").val(user.gender);
//                    $("#district").select2("val", "");
//                    $("#tehsil").select2("val", "");
//                    $("#uc").select2("val", "");
//                    $('#district').html(data);
                }
            });
            
//            var value = $(this).val();
//            if(value == '1')
//            {
//                $("#po_quantity").prop('required',true);
//                $("#wh_detail_info").prop('required',false);
//                $("#receive_from_warehouse").prop('required',false);
//                $("#receive_from_supplier").prop('required',true);
//                $("#po_detail_info").prop('required',true);
//                $('#show_receive_from_warehouse').fadeOut();
//                $('#show_receive_from_supplier').fadeIn();
//                $('#po_type_detail').fadeIn();
//                $('#fo_type_detail').fadeOut();
//                
//                $('#show_po_quantity').fadeIn();
//            }
        }).change();
  			$("#issue_product").change(function () {
            var value ="";
             value = $(this).children(":selected").attr("id");
//            alert(value.toString());
//           var params = value.replace("-deletesr", "");
            var arr = String(value).split('_');
//            alert(arr[0]);
//            alert(arr[2]);
            var btn = this;
            var editbatchid = '';
            $('#issue_batch').attr('disabled',true);
            $('#issue_batch_stock').attr('disabled',true);
            var product = $("#issue_product").val();
            var stock_type = $("#stock_type").val();
            var wh_id = $("#center_from").val();
            if($("#editbatchid").val() != '')
            {
               editbatchid = $("#editbatchid").val();
//               alert(editbatchid);
            }
//            if(arr[1] == '36')
//            {
                        $('#show_batch').fadeIn();
                        $("#show_batch").prop('required',true);
                        $('#show_expiry_date').fadeIn();
                        $("#show_expiry_date").prop('required',true);
                $.ajax({
                    type: "POST",
                    url: '<?php echo base_url("inventory_management/get_batches_of_wh"); ?>',
                    data: {
                        item_id: product,
                        wh_id: wh_id,
                        editbatchid:editbatchid,
                        product_type : arr[1],
                        stk_id : arr[2],
                        stock_type: stock_type
                    },
                    dataType: 'html',
                    success: function (data) {
                        alertify.success("Please select the Batch now.");
                        $('#issue_batch_stock').attr('disabled',false);
                        $('#issue_batch_stock').html(data);
                        $("#issue_batch_stock").select2().select2('val',editbatchid);
                        
                        $('#issue_batch').attr('disabled',false);
                        $('#issue_batch').html(data);
                        $("#issue_batch").select2().select2('val',editbatchid);
                    }
                });
                
                $.ajax({
                    type: "POST",
                    url: '<?php echo base_url("inventory_management/get_batches_of_wh_details"); ?>',
                    data: {
                        item_id: product,
                        wh_id: wh_id,
                        editbatchid:editbatchid,
                        product_type : arr[1],
                        stk_id : arr[2]
                    },
                    dataType: 'html',
                    success: function (data) {
                        $('#issue_batch_details').html(data);
                    }
                });
                
//            }
//            else
//            {
//                $('#show_batch').fadeOut();
//                $("#show_batch").prop('required',false);
//                $('#show_expiry_date').fadeOut();
//                $("#show_expiry_date").prop('required',false);
//                $.ajax({
//                    type: "POST",
//                    url: "http://localhost/cmu_backup/inventory_management/getprodinfo",
//                    data: {
//                        item_id: product,
//                        wh_id: wh_id,
//                        editbatchid:editbatchid,
//                        product_type : arr[1],
//                        stk_id : arr[2]
//                    },
//                    dataType: 'json',
//                    success: function (data) {
////                        var user = JSON.parse(JSON.stringify(data));
////                        alert(data.currency);
//                        $("#available_quantity").val(data.available_qty);
//                        $("#produstbatchid").val(data.batchid);
//                        $("#unit_price").val(data.unit_price);
//                        $("#conversion_rate").val(data.conversion_rate);
//                        $("#currency").val(data.currency).change();
//                        $("#actual_rec_qty").val(data.actual_rec_qty);
//                        $("#batch_expiry").val(data.field3);
//                        $("#prod_field1").val(data.field1);
//                        $("#prod_field2").val(data.field2);
//                        $("#prod_field3").val(data.field3);
//                        $("#prod_field4").val(data.field4);
//                        $("#prod_field5").val(data.field5);
//                        $("#prod_field6").val(data.field6);
//                        $("#prod_field7").val(data.field7);
//                        $("#prod_field8").val(data.field8);
//                        $("#prod_field9").val(data.field9);
//                        $("#prod_field10").val(data.field10);
//                        $("#dc_quantity").val(data.dc_quantity);
//                        $("#pi_quantity").val(data.pi_quantity);
//                        $("#ti_quantity").val(data.ti_quantity);
//                        $("#delivery_challan_type").val(data.delivery_challan_type);
//                        $("#challan_type_detail").val(data.challan_type_detail);
//                        $("#driver_name").val(data.driver_name);
//                        $("#driver_contract").val(data.driver_contract);
//                        $("#vehicle_reg").val(data.vehicle_reg);
//                        $("#dc_no").val(data.dc_no);
//                        $("#dc_date").val(data.dc_date);
//                        $("#invoice").val(data.invoice);
//                        $("#po_quantity").val(data.po_quantity);
//                        $("#grn_quantity").val(data.grn_quantity);
//                        $("#wh_id_from_supplier").val(data.wh_id_from_supplier);
//                        $("#wh_id_from").val(data.wh_id_from);
//                        
//                        $("#stk_id").val(data.stk_id);
//                        
//                        $("#inspection_date").val(data.inspection_date);
//                        $("#delivery_location").val(data.delivery_location);
//                        $("#po_cmu_no").val(data.po_cmu_no);
//                        $("#po_cmu_date").val(data.po_cmu_date);
//                        $("#po_gf_no").val(data.po_gf_no);
//                        $("#po_gf_date").val(data.po_gf_date);
//                        $("#date_of_receiving").val(data.date_of_receiving);
//                        $("#air_bill_no").val(data.air_bill_no);
//                        $("#shipment_no").val(data.shipment_no);
//                        $("#origin_of_country").val(data.origin_of_country);
//                        $("#vehicle_type_and_plate").val(data.vehicle_type_and_plate);
//                        $("#consignment_weight").val(data.consignment_weight);
//                        
////                        $("#wh_location").val(data.wh_location);
////                        $("#storage_info").val(data.storage);
//                        $("#storage_id").val(data.storage_id);
//                        $("#storage_info").select2().select2('val',data.storage_id);
//                    }
//                });
//            }
        }).change();
        
          
            $("#issue_batch").change(function () {
//            var batch_id = '';
//            if($("#editbatchid").val() == "")
//            {
               var batch_id = $("#issue_batch").val();
               if(batch_id == '')
               {
                   batch_id = $("#editbatchid").val();
               }
//                
//            }
//            else{
//                batch_id = $("#editbatchid").val();
//               alert(batch_id);
//            }
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("inventory_management/get_batch_info_new"); ?>',
                data: {
                    batch_id: batch_id
                },
                dataType: 'json',
                success: function (data) {
                    $('#show_expiry_date').fadeIn();
                    $("#show_expiry_date").prop('required',true);
                    if(data.reorder_date)
                    {
                        $('#show_expiry_date').fadeOut();
                        $("#show_expiry_date").prop('required',false);
                        $('#show_reorder_date').fadeIn();
                        $("#show_reorder_date").prop('required',true);
                    }
                    else
                    {
                        $('#show_reorder_date').fadeOut();
                        $("#show_reorder_date").prop('required',false);
                    }
//                    alert(data.available_qty);
                    $("#available_quantity").val(Number(data.available_qty).toString());
                    $("#batch_expiry").val(data.expiry_date);
                    $("#reorder_date").val(data.reorder_date);
                    $("#unit_price").val(data.unit_price);
                    $("#conversion_rate").val(data.conversion_rate);
                    $("#currency").val(data.currency).change();
                    $("#actual_rec_qty").val(data.actual_rec_qty);
//                    $("#wh_location").val(data.wh_location);
//                    $("#storage_info").val(data.storage);
                    $("#storage_id").val(data.storage_id);
                    $("#storage_info").select2().select2('val',data.storage_id);
                }
            });
//            
        }).change();
		//        xxxxxxxxxxxxxxxxxxxxx CHanges END      xxxxxxxxxxxxxxxxxxxxxxxxx

		$("#tehsil_village").change(function() {
			var value = $(this).val();
			$.ajax({
				type: "POST",
				url: '<?php echo base_url("ajax/combo_village"); ?>',
				data: {
					id: value,
					lvl: 6,
					[csrfName]: csrfHash
				},
				dataType: 'html',
				success: function(data) {
					$('#uc_village').html(data);
				}
			});
		}).change();

		//        $("#tehsil").change(function(){
		//            var value = $(this).val();
		//            $.ajax({
		//                type: "POST",
		//                url: '<?php echo base_url("ajax/combo"); ?>',
		//                data: {
		//                    id: value,
		//                    lvl: 6,
		//                    [csrfName]: csrfHash
		//                },
		//                dataType: 'html',
		//                success: function (data) {
		//                    $('#uc').html(data);
		//                }
		//            });
		//        }).change();

		$("#uc").change(function() {
			var value = $(this).val();
			$.ajax({
				type: "POST",
				url: '<?php echo base_url("ajax/facilities"); ?>',
				data: {
					id: value,
					[csrfName]: csrfHash
				},
				dataType: 'html',
				success: function(data) {
					$('#facility').html(data);
				}
			});
		}).change();

		$("#facility").change(function() {
			var value = $(this).val();
			$.ajax({
				type: "POST",
				url: '<?php echo base_url("ajax/population"); ?>',
				data: {
					id: value,
					[csrfName]: csrfHash
				},
				dataType: 'html',
				success: function(data) {
					$('#wh_population').html(data);
				}
			});
		});
	});

	function PrintDiv() {

		var divToPrint = document.getElementById('divToPrint');
		var popupWin = window.open('', '_blank', 'width=1750,height=800');
		popupWin.document.open();
		popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
		popupWin.document.close();

	}

	function minmax(value, min, max) {
		if (parseInt(value) < min || isNaN(parseInt(value)))
			return min;
		else if (parseInt(value) > max)
			return max;
		else
			return value;
	}

	function emailIsValid(email) {
		return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
	}

	function cnicIsValid(cnic) {
		return /\d{5}-\d{7}-\d/.test(cnic)
	}

	$("input[id$='-tid']").keyup(function() {
		var value = $(this).attr("id");
		var id = value.replace("-tid", "");
		var id1 = $("#" + id + "-tid").val();
		var id2 = $("#" + id + "-eid").val();

		$("#" + id + "-sumid").val(parseInt(id1) + parseInt(id2));
	});

	$("input[id$='-eid']").keyup(function() {
		var value = $(this).attr("id");
		var id = value.replace("-eid", "");
		var id1 = $("#" + id + "-tid").val();
		var id2 = $("#" + id + "-eid").val();

		$("#" + id + "-sumid").val(parseInt(id1) + parseInt(id2));
	});

	$("#disease_id").click(function() {
		if ($(this).val() == '1') {
			$('#malaria_treatment_info').show();
		} else {
			$('#malaria_treatment_info').hide();
		}
	}).click();


	$("#pregnant_id").click(function() {
		if ($(this).val() == '1') {
			$('#pregnant_info').show();
		} else {
			$('#pregnant_info').hide();
		}
	});

	$('#method_type').click(function() {
		if ($(this).val() == '1') {
			$('#dose_info').show();
		} else {
			$('#dose_info').hide();
		}
		if ($(this).val() == '2') {
			$('#tablet_info').show();
		} else {
			$('#tablet_info').hide();
		}
	});
</script>
