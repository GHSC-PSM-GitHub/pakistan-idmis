<script src="<?php echo base_url('assets/js/jquery.min.js') ?>"></script>
<?php // include 'header.php'; ?>
<?php echo $main_content; ?>
