<script>
    $(function () {
        $("#stock_issue").validate({
            rules: {
//                refernce_number: "required",
                issuance_time: "required", 
                product: "required", 
                batch: "required",
                expiry_date: "required",
                quantity: {
                    required:true,
                    number:true,
                    min: 1,
                    step: 1
                },
//                driver_contact: {
//                    required:true,
//                    number: true,
//                    minlength: 11,
//                    maxlength: 11
//                },
                driver_cnic: {
                    number: true,
                    minlength: 13,
                    maxlength: 13

                },
            }
        });
        
        $("#issue_product").change(function () {
            var value ="";
             value = $(this).children(":selected").attr("id");
//            alert(value.toString());
//           var params = value.replace("-deletesr", "");
            var arr = String(value).split('_');
//            alert(arr[0]);
//            alert(arr[2]);
            var btn = this;
            var editbatchid = '';
            $('#issue_batch').attr('disabled',true);
            var product = $("#issue_product").val();
            var wh_id = $("#center_from").val();
            if($("#editbatchid").val() != '')
            {
               editbatchid = $("#editbatchid").val();
//               alert(editbatchid);
            }
//            if(arr[1] == '36')
//            {
                        $('#show_batch').fadeIn();
                        $("#show_batch").prop('required',true);
                        $('#show_expiry_date').fadeIn();
                        $("#show_expiry_date").prop('required',true);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('inventory_management/get_batches_of_wh'); ?>",
                    data: {
                        item_id: product,
                        wh_id: wh_id,
                        editbatchid:editbatchid,
                        product_type : arr[1],
                        stk_id : arr[2]
                    },
                    dataType: 'html',
                    success: function (data) {
                        alertify.success("Please select the Batch now.");
                        $('#issue_batch').attr('disabled',false);
                        $('#issue_batch').html(data);
                        $("#issue_batch").select2().select2('val',editbatchid);
                    }
                });
                
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('inventory_management/get_batches_of_wh_details'); ?>",
                    data: {
                        item_id: product,
                        wh_id: wh_id,
                        editbatchid:editbatchid,
                        product_type : arr[1],
                        stk_id : arr[2]
                    },
                    dataType: 'html',
                    success: function (data) {
                        $('#issue_batch_details').html(data);
                    }
                });
                
//            }
//            else
//            {
//                $('#show_batch').fadeOut();
//                $("#show_batch").prop('required',false);
//                $('#show_expiry_date').fadeOut();
//                $("#show_expiry_date").prop('required',false);
//                $.ajax({
//                    type: "POST",
//                    url: "<?php echo base_url('inventory_management/getprodinfo'); ?>",
//                    data: {
//                        item_id: product,
//                        wh_id: wh_id,
//                        editbatchid:editbatchid,
//                        product_type : arr[1],
//                        stk_id : arr[2]
//                    },
//                    dataType: 'json',
//                    success: function (data) {
////                        var user = JSON.parse(JSON.stringify(data));
////                        alert(data.currency);
//                        $("#available_quantity").val(data.available_qty);
//                        $("#produstbatchid").val(data.batchid);
//                        $("#unit_price").val(data.unit_price);
//                        $("#conversion_rate").val(data.conversion_rate);
//                        $("#currency").val(data.currency).change();
//                        $("#actual_rec_qty").val(data.actual_rec_qty);
//                        $("#batch_expiry").val(data.field3);
//                        $("#prod_field1").val(data.field1);
//                        $("#prod_field2").val(data.field2);
//                        $("#prod_field3").val(data.field3);
//                        $("#prod_field4").val(data.field4);
//                        $("#prod_field5").val(data.field5);
//                        $("#prod_field6").val(data.field6);
//                        $("#prod_field7").val(data.field7);
//                        $("#prod_field8").val(data.field8);
//                        $("#prod_field9").val(data.field9);
//                        $("#prod_field10").val(data.field10);
//                        $("#dc_quantity").val(data.dc_quantity);
//                        $("#pi_quantity").val(data.pi_quantity);
//                        $("#ti_quantity").val(data.ti_quantity);
//                        $("#delivery_challan_type").val(data.delivery_challan_type);
//                        $("#challan_type_detail").val(data.challan_type_detail);
//                        $("#driver_name").val(data.driver_name);
//                        $("#driver_contract").val(data.driver_contract);
//                        $("#vehicle_reg").val(data.vehicle_reg);
//                        $("#dc_no").val(data.dc_no);
//                        $("#dc_date").val(data.dc_date);
//                        $("#invoice").val(data.invoice);
//                        $("#po_quantity").val(data.po_quantity);
//                        $("#grn_quantity").val(data.grn_quantity);
//                        $("#wh_id_from_supplier").val(data.wh_id_from_supplier);
//                        $("#wh_id_from").val(data.wh_id_from);
//                        
//                        $("#stk_id").val(data.stk_id);
//                        
//                        $("#inspection_date").val(data.inspection_date);
//                        $("#delivery_location").val(data.delivery_location);
//                        $("#po_cmu_no").val(data.po_cmu_no);
//                        $("#po_cmu_date").val(data.po_cmu_date);
//                        $("#po_gf_no").val(data.po_gf_no);
//                        $("#po_gf_date").val(data.po_gf_date);
//                        $("#date_of_receiving").val(data.date_of_receiving);
//                        $("#air_bill_no").val(data.air_bill_no);
//                        $("#shipment_no").val(data.shipment_no);
//                        $("#origin_of_country").val(data.origin_of_country);
//                        $("#vehicle_type_and_plate").val(data.vehicle_type_and_plate);
//                        $("#consignment_weight").val(data.consignment_weight);
//                        
////                        $("#wh_location").val(data.wh_location);
////                        $("#storage_info").val(data.storage);
//                        $("#storage_id").val(data.storage_id);
//                        $("#storage_info").select2().select2('val',data.storage_id);
//                    }
//                });
//            }
        }).change();
        
        $("#adj_product").change(function () {
            var value ="";
             value = $(this).children(":selected").attr("id");
//            alert(value.toString());
//           var params = value.replace("-deletesr", "");
            var arr = String(value).split('_');
//            alert(arr[0]);
//            alert(arr[1]);
            var btn = this;
            var editbatchid = '';
            $('#issue_batch').attr('disabled',true);
            var product = $("#adj_product").val();
            var wh_id = $("#center_from").val();
            if($("#editbatchid").val() != '')
            {
               editbatchid = $("#editbatchid").val();
//               alert(editbatchid);
            }
//            if(arr[1] == '36')
//            {
                        $('#show_batch').fadeIn();
                        $("#show_batch").prop('required',true);
                        $('#show_expiry_date').fadeIn();
                        $("#show_expiry_date").prop('required',true);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('inventory_management/get_batches_of_wh_adj'); ?>",
                    data: {
                        item_id: product,
                        wh_id: wh_id,
                        editbatchid:editbatchid,
                        product_type : arr[1],
                        stk_id : arr[2]
                    },
                    dataType: 'html',
                    success: function (data) {
                        alertify.success("Please select the Batch now.");
                        $('#issue_batch').attr('disabled',false);
                        $('#issue_batch').html(data);
                        $("#issue_batch").select2().select2('val',editbatchid);
                        $("#otherproduct_batch").val('');
                    }
                });
                
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('inventory_management/get_batches_of_wh_details_adj'); ?>",
                    data: {
                        item_id: product,
                        wh_id: wh_id,
                        editbatchid:editbatchid,
                        product_type : arr[1],
                        stk_id : arr[2]
                    },
                    dataType: 'html',
                    success: function (data) {
                        $('#issue_batch_details').html(data);
                    }
                });
                
//            }
//            else
//            {
//                $('#show_main_info').fadeIn();
//                $('#other_show_info').fadeOut();
//                $('#show_batch').fadeOut();
//                $("#show_batch").prop('required',false);
//                $('#show_expiry_date').fadeOut();
//                $("#show_expiry_date").prop('required',false);
//                $.ajax({
//                    type: "POST",
//                    url: "<?php echo base_url('inventory_management/getprodinfo_adj'); ?>",
//                    data: {
//                        item_id: product,
//                        wh_id: wh_id,
//                        editbatchid:editbatchid,
//                        product_type : arr[1],
//                        stk_id : arr[2]
//                    },
//                    dataType: 'json',
//                    success: function (data) {
////                        var user = JSON.parse(JSON.stringify(data));
////                        alert(data.batchid);
//                        $("#otherproduct_batch").val(data.batchid);
//                        $("#produstbatchid").val(data.batchid);
//                        $("#available_quantity").val(data.available_qty);
//                        $("#unit_price").val(data.unit_price);
//                        $("#conversion_rate").val(data.conversion_rate);
//                        $("#currency").val(data.currency);
//                        $("#actual_rec_qty").val(data.actual_rec_qty);
//                        $("#batch_expiry").val(data.field3);
//                        $("#prod_field1").val(data.field1);
//                        $("#prod_field2").val(data.field2);
//                        $("#prod_field3").val(data.field3);
//                        $("#prod_field4").val(data.field4);
//                        $("#prod_field5").val(data.field5);
//                        $("#prod_field6").val(data.field6);
//                        $("#prod_field7").val(data.field7);
//                        $("#prod_field8").val(data.field8);
//                        $("#prod_field9").val(data.field9);
//                        $("#prod_field10").val(data.field10);
//                    }
//                });
//            }
        }).change();
        
        $("#change_product_loc").change(function () {
            var value ="";
             value = $(this).children(":selected").attr("id");
//            alert(value.toString());
//           var params = value.replace("-deletesr", "");
            var arr = String(value).split('_');
//            alert(arr[0]);
//            alert(arr[1]);
            var btn = this;
            var editbatchid = '';
            $('#change_product_batch').attr('disabled',true);
            var product = $("#change_product_loc").val();
            var wh_id = $("#center_from").val();
            if($("#editbatchid").val() != '')
            {
               editbatchid = $("#editbatchid").val();
//               alert(editbatchid);
            }
            if(arr[1] == '36')
            {
                        $('#show_batch').fadeIn();
                        $("#show_batch").prop('required',true);
                        $('#show_expiry_date').fadeIn();
                        $("#show_expiry_date").prop('required',true);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('inventory_management/get_batches_of_wh_chng_prod'); ?>",
                    data: {
                        item_id: product,
                        wh_id: wh_id,
                        editbatchid:editbatchid,
                        product_type : arr[1],
                        stk_id : arr[2]
                    },
                    dataType: 'html',
                    success: function (data) {
                        alertify.success("Please select the Batch now.");
                        $('#change_product_batch').attr('disabled',false);
                        $('#change_product_batch').html(data);
                        $("#change_product_batch").select2().select2('val',editbatchid);
                        $("#otherproduct_batch").val('');
                    }
                });
                
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('inventory_management/get_batches_of_wh_details_chng_prod'); ?>",
                    data: {
                        item_id: product,
                        wh_id: wh_id,
                        editbatchid:editbatchid,
                        product_type : arr[1],
                        stk_id : arr[2]
                    },
                    dataType: 'html',
                    success: function (data) {
                        $('#change_product_batch_details').html(data);
                    }
                });
                
            }
            else
            {
                $('#show_main_info').fadeIn();
                $('#other_show_info').fadeOut();
                $('#show_batch').fadeOut();
                $("#show_batch").prop('required',false);
                $('#show_expiry_date').fadeOut();
                $("#show_expiry_date").prop('required',false);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('inventory_management/getprodinfo_chng_prod'); ?>",
                    data: {
                        item_id: product,
                        wh_id: wh_id,
                        editbatchid:editbatchid,
                        product_type : arr[1],
                        stk_id : arr[2]
                    },
                    dataType: 'json',
                    success: function (data) {
//                        var user = JSON.parse(JSON.stringify(data));
//                        alert('saad');
                        $("#otherproduct_batch").val(data.batchid);
                        $("#produstbatchid").val(data.batchid);
                        $("#available_quantity").val(data.available_qty);
                        $("#unit_price").val(data.unit_price);
                        $("#conversion_rate").val(data.conversion_rate);
                        $("#currency").val(data.currency);
                        $("#actual_rec_qty").val(data.actual_rec_qty);
                        $("#batch_expiry").val(data.field3);
                        $("#prod_field1").val(data.field1);
                        $("#prod_field2").val(data.field2);
                        $("#prod_field3").val(data.field3);
                        $("#prod_field4").val(data.field4);
                        $("#prod_field5").val(data.field5);
                        $("#prod_field6").val(data.field6);
                        $("#prod_field7").val(data.field7);
                        $("#prod_field8").val(data.field8);
                        $("#prod_field9").val(data.field9);
                        $("#prod_field10").val(data.field10);
//                        $("#wh_location").val(data.wh_location);
                        $("#storage_info").val(data.storage);
                        $("#detailpk_id").val(data.detailpk_id);
                        $("#change_product_batch").val("");
                    }
                });
            }
        }).change();
        
        $("#center_from").change(function () {
            $('#product').attr('disabled',true);
            var id = $(this).val();
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('inventory_management/get_available_prods_of_wh'); ?>",
                data: {
                    wh_id: id
                },
                dataType: 'html',
                success: function (data) {
                    if(!data){
                        alertify.error("No Stock available at this center");
                    }
                    else
                    {
                        //alertify.success("Please select the product now.");
                        $('#product').attr('disabled',false);
                        $('#product').html(data);
                    }
                }
            });
        });
        
        $("#issue_batch").change(function () {
//            var batch_id = '';
//            if($("#editbatchid").val() == "")
//            {
               var batch_id = $("#issue_batch").val();
               if(batch_id == '')
               {
                   batch_id = $("#editbatchid").val();
               }
//                
//            }
//            else{
//                batch_id = $("#editbatchid").val();
//               alert(batch_id);
//            }
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('inventory_management/get_batch_info_new'); ?>",
                data: {
                    batch_id: batch_id
                },
                dataType: 'json',
                success: function (data) {
                    $('#show_expiry_date').fadeIn();
                    $("#show_expiry_date").prop('required',true);
                    if(data.reorder_date)
                    {
                        $('#show_expiry_date').fadeOut();
                        $("#show_expiry_date").prop('required',false);
                        $('#show_reorder_date').fadeIn();
                        $("#show_reorder_date").prop('required',true);
                    }
                    else
                    {
                        $('#show_reorder_date').fadeOut();
                        $("#show_reorder_date").prop('required',false);
                    }
//                    alert(data.available_qty);
                    $("#available_quantity").val(data.available_qty);
                    $("#batch_expiry").val(data.expiry_date);
                    $("#reorder_date").val(data.reorder_date);
                    $("#unit_price").val(data.unit_price);
                    $("#conversion_rate").val(data.conversion_rate);
                    $("#currency").val(data.currency).change();
                    $("#actual_rec_qty").val(data.actual_rec_qty);
//                    $("#wh_location").val(data.wh_location);
//                    $("#storage_info").val(data.storage);
                    $("#storage_id").val(data.storage_id);
                    $("#storage_info").select2().select2('val',data.storage_id);
                }
            });
//            
        }).change();
        
        $("#change_product_batch").change(function () {
//            var batch_id = '';
//            if($("#editbatchid").val() == "")
//            {
               var batch_id = $("#change_product_batch").val();
               if(batch_id == '')
               {
                   batch_id = $("#editbatchid").val();
               }
//                
//            }
//            else{
//                batch_id = $("#editbatchid").val();
//               alert(batch_id);
//            }
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('inventory_management/get_batch_info_chng_prod'); ?>",
                data: {
                    batch_id: batch_id
                },
                dataType: 'json',
                success: function (data) {
//                    alert(data.available_qty);
                    $("#available_quantity").val(data.available_qty);
                    $("#batch_expiry").val(data.expiry_date);
                    $("#unit_price").val(data.unit_price);
                    $("#conversion_rate").val(data.conversion_rate);
                    $("#currency").val(data.currency).change();
                    $("#actual_rec_qty").val(data.actual_rec_qty);
//                    $("#wh_location").val(data.wh_location);
                    $("#storage_info").val(data.storage);
                    $("#storage_id").val(data.storage_id);
                    $("#detailpk_id").val(""); 
                }
            });
//            
        }).change();
        
        $("#issue_to").change(function () {
        $.ajax({
                type: "POST",
                url: "<?php echo base_url('inventory_management/get_center_patients'); ?>",
                data: {
                    issue_type: $(this).val()
                },
                dataType: 'html',
                success: function (data) {
                    $("#center_patient").html(data); 
                }
            });
        });
        $("#save_temp_issue").click(function () {
        $.ajax({
                type: "POST",
                url: "<?php echo base_url('inventory_management/save_temporary_records'); ?>",
                data: {
                    stock_master_id: $("#stock_master_id").val() 
                },
                dataType: 'html',
                success: function (data) { 
                    window.location.href =" <?php echo base_url('inventory_management/stock_issue_search'); ?>";
                }
            });
        });
        
        $("#save_temp_transport_req").click(function () {
        $.ajax({
                type: "POST",
                url: "<?php echo base_url('inventory_management/save_temporary_records_transportreq'); ?>",
                data: {
                    stock_master_id: $("#stock_master_id").val() 
                },
                dataType: 'html',
                success: function (data) { 
                    window.location.href =" <?php echo base_url('inventory_management/transport_req_form_search_new'); ?>";
                }
            });
        });
        
//        $("#quantity").keyup(function () {
//        $("#quantity,#unit_price,#conversion_rate").keyup(function() {
//        $(document).on('change keyup blur','#quantity','#conversion_rate', function(e){
//            if($("#quantity").val() != '')
//            {
////                alert('saad');
//                var value = $("#unit_price").val() * $("#conversion_rate").val() * $("#quantity").val();
//                $("#total_price").val(value);
//            }
//        }).keyup();
        
        $('#quantity, #conversion_rate').on('change keyup blur', function () {
            if($("#quantity").val() != '')
            {
//                alert('saad');
                var value = $("#unit_price").val() * $("#conversion_rate").val() * $("#quantity").val();
                $("#total_price").val(value);
            }
        }).keyup();
        
        var total = 0;
        $(".givmissingqty").keyup(function() {
//                alert(parseInt($(this).val()));
            if (parseInt($(this).val()) > $(this).closest('td').prev('.grnqty').text()) {
//                alert("To order quantity greater than 40 please use the contact form.");
//                this.value == '';
                $(this).val('');
                /* or with jQuery: $(this).val(''); */
                $(this).focus();
                return false;
            }
            else{
                var value = ( $(this).val() ) * ( $(this).closest('tr').find("td:eq(6)").text() ) * ( $(this).closest('tr').find("td:eq(8)").text() ) ;
//                alert(value);
                $(this).closest('tr').find("td:eq(16) input[type='number']").val(value);
                total  += value;
                $("#batch_totalprice").text(total);
            }
           }); 
        
//        $("#receiving_times").datepicker({
//                format: 'mm/dd/yyyy',
//                mindate :  'today'
//            });
        
        
        $(document).ready(function(){
            $("button[id$='-deletetvreq']").click(function(e){
           //    e.preventDefault(); 
               var value = $(this).attr("id");
               var params = value.replace("-deletetvreq", "");
               var arr = params.split('_');
               var btn = this;

               $.ajax({
                 type: "POST",
                 url: "<?php echo base_url('inventory_management/ajax_deltvreq')?>",
                 cache: false,
                 data: {'pk_id': arr[0],'fk_stock_id': arr[1]}, // since, you need to delete post of particular id
                 success: function(reaksi) {
                    if (reaksi){
                       alert("Record Deleted Successfully.");
                       $(btn).closest('tr').fadeOut("slow");
    //                   $("#dc_result").html(reaksi);
                    } else {
                        alert("ERROR");
                    }
                  }
              });
           });
        });
        
        $(document).ready(function(){
            $("button[id$='-deletetpreq']").click(function(e){
           //    e.preventDefault(); 
               var value = $(this).attr("id");
               var params = value.replace("-deletetpreq", "");
               var arr = params.split('_');
               var btn = this;

               $.ajax({
                 type: "POST",
                 url: "<?php echo base_url('inventory_management/ajax_deltpreq')?>",
                 cache: false,
                 data: {'pk_id': arr[0],'fk_stock_id': arr[1]}, // since, you need to delete post of particular id
                 success: function(reaksi) {
                    if (reaksi){
                       alert("Record Deleted Successfully.");
                       $(btn).closest('tr').fadeOut("slow");
    //                   $("#dc_result").html(reaksi);
                    } else {
                        alert("ERROR");
                    }
                  }
              });
           });
        });
        
    });
    
//    $('#stock_issue').submit(function(e) {
//        $(':disabled').each(function(e) {
//            $(this).removeAttr('disabled');
//        });
//    });
    
    $(document).ready(function(){
        $("button[id$='-deletegsi']").click(function(e){
       //    e.preventDefault(); 
           var value = $(this).attr("id");
           var params = value.replace("-deletegsi", "");
           var arr = params.split('_');
           var btn = this;

           $.ajax({
             type: "POST",
             url: "<?php echo base_url('inventory_management/ajax_delgsi')?>",
             cache: false,
             data: {'pk_id': arr[0],'fk_stock_id': arr[1],'batch_id': arr[2],'quantity': arr[3]}, // since, you need to delete post of particular id
             success: function(reaksi) {
                if (reaksi){
                   alert("Record Deleted Successfully.");
                   $(btn).closest('tr').fadeOut("slow");
//                   $("#dc_result").html(reaksi);
                } else {
                    alert("ERROR");
                }
              }
          });
       });
    });

</script>