<?php
//print_r($result_edit);exit;
if (isset($result_edit)) {

//    $row = $result_edit->result_array();
//    $row = $row[0];
//    $role_name = $row['role_name'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Assign Role Resources</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="add_stk" name="add_stk" action="<?php echo base_url("assign_role_resources/add"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row">
                                             
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Role Name<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select name="role_id" class="select2me input-medium" id="role_id" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                                <?php
                                                                foreach ($roles as $row) {
                                                                    ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($role_id) && $role_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['role_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                            <table class="table" style="width:50%;">

                                                    <!-- Table heading -->
                                                    <thead>
                                                        <tr>
                                                            <th style="width: 1%;"> <input type="checkbox" id="checkAll" /></th>
                                                            <th> Resources </th>
                                                            <th> Rank </th>
                                                            <!--<th> Adjustment Type</th>-->

                                                        </tr>
                                                    </thead>
                                                    <!-- // Table heading END --> 

                                                    <!-- Table body -->
                                                    <tbody>
                                                        <!-- Table row -->
                                                        <?php
                                                            $i = 1;
                                                            foreach ($main_resources as $row) {

//$checked = (in_array($item['pk_id'], $assignedArr['resource'])) ? 'checked="checked"' : '';
                                                                ?>
                                                        <tr>
                                                            <td></td>
                                                            <td class="center" style="color:#3C445E;font-weight: bold;">
                                                                <input type="checkbox" id="resources" name="resources[<?php echo $row['pk_id']; ?>]" value="<?php echo $row['pk_id']; ?>" /><?php echo '  ' .$row['page_title']; ?>
                                                                
                                                            <!--<td class="center"><input type="text" id="rank" name="rank[<?php echo $row['pk_id']; ?>]" value="<?php echo $row['pk_id']; ?>" /><?php echo '  ' .$row['page_title']; ?></td>-->
                                                            </td>
                                                            <td>
                                                                <input type="text" style="width: 50px;" id="rank" name="rank[<?php echo $row['pk_id']; ?>]" value="" />
                                                            </td>
                                                        </tr>
                                                        
                                                        <?php foreach ($resources as $row1) { 
                                                            if($row['pk_id'] == $row1['parent_id'])
                                                                {?>
                                                            <tr style="">
                                                                <td></td>
                                                                <td class="center" style="width:150px;margin-left: 80px;display: inline-block;color:#6F6F6F;font-weight: bold;">
                                                                    <input type="checkbox" id="resources" name="resources[<?php echo $row1['pk_id']; ?>]" value="<?php echo $row1['pk_id']; ?>" /><?php echo '  ' .$row1['page_title']; ?>

                                                                <!--<td class="center"><input type="text" id="rank" name="rank[<?php echo $row1['pk_id']; ?>]" value="<?php echo $row1['pk_id']; ?>" /><?php echo '  ' .$row1['page_title']; ?></td>-->
                                                                </td>
                                                                <td>
                                                                    <input type="text" style="width: 50px;" id="rank" name="rank[<?php echo $row1['pk_id']; ?>]" value="" />
                                                                </td>
                                                            </tr>
                                                            <?php foreach ($resources as $row2) { 
                                                             if($row1['pk_id'] == $row2['parent_id']) { ?>
                                                                <tr style="">
                                                                    <td></td>
                                                                    <td class="center" style="width:200px;text-align: right;display: inline-block;">
                                                                        <input type="checkbox" id="resources" name="resources[<?php echo $row2['pk_id']; ?>]" value="<?php echo $row2['pk_id']; ?>" /><?php echo $row2['page_title']; ?>
                                                                    </td>
                                                                </tr>
<!--                                                                <tr style="">
                                                                    <td></td>
                                                                    <td class="center" style="width:200px;text-align: right;display: inline-block;">
                                                                        <input type="checkbox" id="resources" name="resources[<?php echo $row2['pk_id']; ?>]" value="<?php echo '1'; ?>" /><?php echo '  Add'; ?>
                                                                    </td>
                                                                </tr>-->
                                                            <?php   } 
                                                                  }
                                                                }
                                                            } ?>
                                                        
                                                        <?php $i++;
                                                            } ?>
                                                        <!-- // Table row END -->
                                                    </tbody>
                                                    <!-- // Table body END -->

                                            </table>
                                            
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                            if (isset($result))
                                                                echo 'value="edit"';
                                                            ?>>
                                                            <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div> 
                                                <?php if(isset($result_edit)){?>
                                                <input type="hidden" id="id" name="id" value="<?php echo $_REQUEST['id'] ?>">
                                                <?php
                                                }
                                                ?>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                    
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>
 