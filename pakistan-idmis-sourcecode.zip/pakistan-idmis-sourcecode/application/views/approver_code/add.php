<?php
//print_r($result_edit);exit;
if (isset($result_edit)) {

    $row = $result_edit->result_array();
    $row = $row[0];
    $approver_code = $row['approval_code'];
    $document_id = $row['document_id'];
    $approver_designation_id = $row['approver_designation'];
    $level_id = $row['level'];
    $final_id = $row['final'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Add Approver Code</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="add_ext_system" name="add_ext_system" action="<?php echo base_url("approver_code/add"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Document<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="document" id="document" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($document as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($document_id) && $document_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select> 
                                                    </div>
                                                </div>
                                                 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="approver_code" >Approver Code <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="approver_code" id="approver_code" required style="width:100%;" 
                                                               <?php
                                                               if(isset($approver_code))
                                                               {
                                                                   echo 'value="'.$approver_code.'"';
                                                               }
                                                               ?>
                                                               >
                                                    </div>
                                                </div> 
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Approver Designation<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="approver_designation" id="approver_designation" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($approver_designation as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($approver_designation_id) && $approver_designation_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select> 
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Level<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="level" id="level" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($level as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($level_id) && $level_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select> 
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group row">
                                            <div class="col-md-3">
                                                    <label class="example-text-input" required >Final<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="final" id="final" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($final as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($final_id) && $final_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select> 
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                            if (isset($result))
                                                                echo 'value="edit"';
                                                            ?>>
                                                            <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div> 
                                                <?php if(isset($result_edit)){?>
                                                <input type="hidden" id="id" name="id" value="<?php echo $_REQUEST['id'] ?>">
                                                <?php
                                                }
                                                ?>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                    
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>
 