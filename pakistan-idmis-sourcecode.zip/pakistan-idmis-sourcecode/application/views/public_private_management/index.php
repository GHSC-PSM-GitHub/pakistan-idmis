<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons"> 
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                    <!-- // Heading END -->
                    <h3>Public/Private Management</h3>
                    <div class="buttons pull-right">
                            <a href="<?php echo base_url("public_private_management/add"); ?>"   class="btn btn-primary btn-icon glyphicons circle_plus"><i class="fas fa-user-plus"></i> Add</a>
                        </div>
                     <div class="innerLR">
                        <br>
                        <?php
                        if (isset($result)) {
                            ?>

                            <div id="divToPrint">
                                <table  id="datatable-buttons"  class="table table-striped table-bordered table-condensed dt-responsive nowrap">
                                    <thead>
                                        <tr>
                                            <th  class="center">No.</th> 
                                            <th>Name</th> 
                                            <th>Action</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Table row -->
                                        <?php
                                        if($result)
                                        {
                                            $count = 1;
                                            foreach ($result->result_array() as $row) {
                                                ?>
                                                <tr>
                                                    <td class="center"><?php echo $count; ?></td> 
                                                    <td> <?php echo $row['name'] ?> </td> 
                                                    <td> <a href="<?php echo base_url("public_private_management/edit?id=") . $row['pk_id']; ?> " class="btn btn-danger" title="edit">Edit</a>
                                                    </td>
                                                    <td>    <?php  
                                                        if(@$row['is_active'] == 0){
                                                    ?>
                                                    <a onclick="return confirm('Are you sure you want to Activate?');" href="<?php echo base_url("public_private_management/deactivate?id=") . $row['pk_id']; ?>&status=1" class="btn btn-sm btn-light glyphicons bin" ><i class="fas fa-check success"></i> Activate</a>

                                                    <?php
                                                        }else{
                                                    ?>
                                                        <a onclick="return confirm('Are you sure you want to Deactivate?');" href="<?php echo base_url("public_private_management/deactivate?id=") . $row['pk_id']; ?>&status=0" class="btn btn-sm btn-light glyphicons bin" ><i class="fas fa-times red"></i> Disable</a>

                                                    <?php
                                                    }
                                                    ?>
                                                    </td>
                                                </tr>
                                                <?php
                                                $count++;
                                            }
                                        }
                                        ?>
                                        <!-- // Table row END -->
                                        <!-- Table row -->

                                        <!-- // Table row END -->
                                    </tbody>
                                </table>
                            </div>

                            <!-- // Table END -->
                            <?php
                        } else {
                            echo "<hr><h5>No data found!</h5>";
                        }
                        ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

