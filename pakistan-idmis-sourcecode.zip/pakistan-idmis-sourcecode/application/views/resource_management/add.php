<?php
//print_r($result_edit);exit;
if (isset($result_edit)) {

    $row = $result_edit->result_array();
    $row = $row[0];
    $resource_name = $row['resource_name'];
    $description = $row['description'];
    $page_title = $row['page_title'];
    $parent_id = $row['parent_id'];
    $resource_type_id = $row['resource_type_id'];
    $icon_class = $row['icon_class'];
    $rank = $row['rank'];
    $level = $row['level'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Resource Management</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="add_stk" name="add_stk" action="<?php echo base_url("resource_management/add"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row"> 
                                                 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="resource_name" >Resource Name <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="resource_name" id="resource_name" required style="width:100%;" 
                                                               <?php
                                                               if(isset($resource_name))
                                                               {
                                                                   echo 'value="'.$resource_name.'"';
                                                               }
                                                               ?>
                                                               >
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="description" >Description <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="description" id="description" required style="width:100%;" 
                                                               <?php
                                                               if(isset($description))
                                                               {
                                                                   echo 'value="'.$description.'"';
                                                               }
                                                               ?>
                                                               >
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="page_title" >Page Title <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="page_title" id="page_title" required style="width:100%;" 
                                                               <?php
                                                               if(isset($page_title))
                                                               {
                                                                   echo 'value="'.$page_title.'"';
                                                               }
                                                               ?>
                                                               >
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="parent_id" >Parent ID <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="parent_id" id="parent_id" style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <option value="0">0</option>
                                                            <?php
                                                            foreach ($parentids as $row) {
                                                            ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($parent_id) && $parent_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['page_title'] ?></option>
                                                            <?php
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                
                                            </div> 
                                            
                                            <div class="form-group row"> 
                                                 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="resource_type_id" >Resource Type <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="resource_type_id" id="resource_type_id" style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <option value="1" <?php if(isset($resource_type_id) && $resource_type_id==1) echo "Selected"; ?>>Main</option>
                                                            <option value="2" <?php if(isset($resource_type_id) && $resource_type_id==2) echo "Selected"; ?>>Main Module</option>
                                                            <option value="3" <?php if(isset($resource_type_id) && $resource_type_id==3) echo "Selected"; ?>>Sub Module</option>
                                                            <option value="4" <?php if(isset($resource_type_id) && $resource_type_id==4) echo "Selected"; ?>>Ajax File</option>
                                                            <option value="5" <?php if(isset($resource_type_id) && $resource_type_id==5) echo "Selected"; ?>>Other</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="icon_class" >Icon Class </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="icon_class" id="icon_class" style="width:100%;" 
                                                               <?php
                                                               if(isset($icon_class))
                                                               {
                                                                   echo 'value="'.$icon_class.'"';
                                                               }
                                                               ?>
                                                               >
                                                    </div>
                                                </div>
                                                
<!--                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="rank" >Rank <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="rank" id="rank" style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                            <option value="4">4</option>
                                                            <option value="5">5</option>
                                                            <option value="6">6</option>
                                                        </select>
                                                    </div>
                                                </div>-->
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="level" >Level <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="level" id="level" style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <option value="0" <?php if(isset($level) && $level==0) echo "Selected"; ?>>0</option>
                                                            <option value="1" <?php if(isset($level) && $level==1) echo "Selected"; ?>>1</option>
                                                            <option value="2" <?php if(isset($level) && $level==2) echo "Selected"; ?>>2</option>
                                                            <option value="3" <?php if(isset($level) && $level==3) echo "Selected"; ?>>3</option>
                                                            <option value="4" <?php if(isset($level) && $level==4) echo "Selected"; ?>>4</option>
                                                            <option value="5" <?php if(isset($level) && $level==5) echo "Selected"; ?>>5</option>
                                                            <option value="6" <?php if(isset($level) && $level==6) echo "Selected"; ?>>6</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                            if (isset($result))
                                                                echo 'value="edit"';
                                                            ?>>
                                                            <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div> 
                                                <?php if(isset($result_edit)){?>
                                                <input type="hidden" id="id" name="id" value="<?php echo $_REQUEST['id'] ?>">
                                                <?php
                                                }
                                                ?>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                    
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>
 