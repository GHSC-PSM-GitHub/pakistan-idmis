<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <!--<h3>Health Facilities</h3>-->
                        <div class="buttons pull-right">
                            <a href="<?php echo base_url("warehouse_management/add_wh"); ?>" class="btn btn-primary btn-icon glyphicons circle_plus"><i></i>Add</a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                    <!-- // Heading END -->

                    <div class="innerLR">
                        <br>
                        <?php
                        if (isset($result)) {
                            ?>

                            <div id="divToPrint">
                                <table class="table table-striped table-bordered table-condensed dt-responsive " id="datatable-buttons">
                                    <thead>
                                        <tr>
                                            <th style="width: 1%;" class="center">No.</th>
                                            <th>Facility / Center Name</th>
                                            <th>Province</th>
                                            <th>District</th>
<!--                                            <th>Tehsil</th>-->
<!--                                            <th>UC</th>-->
<!--                                            <th>Facility Category</th>-->
                                            <th>Facility Type</th>
<!--                                            <th>Stakeholder/Department</th>-->
                                            <th>Action</th>
                                            <th style="width:100px;"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Table row -->
                                        <?php
                                        $count = 1;
//        echo '<pre>';
//        print_r($result->result_array());
//        exit;
                                        foreach ($result->result_array() as $row) {
                                            ?>
                                            <tr>
                                                <td class="center"><?php echo $count; ?></td>
                                                <td><?php echo $row['warehouse_name']; ?></td>
                                                <td class="important"><?php echo $row['province_name']; ?></td>
                                                <td class="important"><?php echo $row['district_name']; ?></td>
<!--                                                <td class="important"><?php echo $row['tehsil_name']; ?></td>-->
<!--                                                <td class="important"><?php echo $row['uc_name']; ?></td>-->
<!--                                                <td class="important"><?php echo $row['category_name']; ?></td>-->
                                                <td class="important"><?php echo $row['facility_type_name']; ?></td>
<!--                                                <td class="important"><?php echo $row['stakeholder_name']; ?></td>-->
                                                <td> <a href="<?php echo base_url("warehouse_management/edit_wh?id=") . $row['pk_id']; ?> " class="btn btn-danger" title="edit">Edit</a>
                                                </td>
                                                <td>    <?php  
                                                    if($row['status'] == 0){
                                                ?>
                                                <a onclick="return confirm('Are you sure you want to Activate?');" href="<?php echo base_url("warehouse_management/deactivate_wh?id=") . $row['pk_id']; ?>&status=1" class="btn btn-sm btn-light glyphicons bin" ><i class="fas fa-check success"></i> Activate</a>

                                                <?php
                                                    }else{
                                                ?>
                                                    <a onclick="return confirm('Are you sure you want to Deactivate?');" href="<?php echo base_url("warehouse_management/deactivate_wh?id=") . $row['pk_id']; ?>&status=0" class="btn btn-sm btn-light glyphicons bin" ><i class="fas fa-times red"></i> Disable</a>

                                                <?php
                                                }
                                                ?>
                                                </td>
                                            </tr>
                                            <?php
                                            $count++;
                                        }
                                        ?>
                                        <!-- // Table row END -->
                                        <!-- Table row -->

                                        <!-- // Table row END -->
                                    </tbody>
                                </table> 
                            </div>

                            <!-- // Table END -->
                            <?php
                        } else {
                            echo "<hr><h5>No data found!</h5>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 

