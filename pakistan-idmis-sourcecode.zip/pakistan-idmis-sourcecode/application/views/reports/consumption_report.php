<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
}
    
</style>
<?php 
$status = '4';
if(isset($form['status']) && !empty($form['status']))
{
    $status = $form['status'];
}

$flag = false;
//check product
if (isset($_REQUEST['batch_mang_product']) && !empty($_REQUEST['batch_mang_product'])) {
    //get product
    $batch_mang_product = trim($_REQUEST['batch_mang_product']);
    //set product
//                $qryString .= '&product=' . $product;
    $flag = true;
}
//check status
if (isset($_REQUEST['tran_type']) && !empty($_REQUEST['tran_type'])) {
    //get funding_source
    $tran_type = trim($_REQUEST['tran_type']);
    //set funding_source
//                $objStockBatch->funding_source = $funding_source;
//                $qryString .= '&funding_source=' . $funding_source;
}
?>
<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Consumption Report</h3>
                         
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                     <div class="innerLR">
                         
                         <form method="POST" name="dc_searchs" action="consumption_report" >
                            <!-- Row -->
                  <div class="col-md-12">
                    <div class="card m-b-30">
                        <div class="card-body">
                            
                            <div class="form-group row"> 
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Month<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="month" id="month" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                                <?php
                                                                for ($i = 0; $i < 12; $i++) {
                                                                    $time = strtotime(sprintf('%d months', $i));   
                                                                    $label = date('F', $time);   
                                                                    $value = date('n', $time);
                                                                    if(isset($form['month']) && $form['month'] == $i)
                                                                    {
                                                                        $sel = 'selected';
                                                                    }
                                                                    echo "<option $sel value='$value'>$label</option>";
                                                                }
                                                                ?>
                                                        </select>  
                                                    </div>
                                                </div>
                                
                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Year<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <?php   
//                                                        echo "<select class='select2me input-medium' name='year' style='width:100%;padding:10%;'>";
//                                                        for($i=0;$i<=5;$i++){
//                                                            $year=date('Y',strtotime("last day of +$i year"));
//                                                            echo "<option name='$year'>$year</option>";
//                                                        }
//                                                        echo "</select>";
                                                        ?>
                                                        
                                                        <select class="select2me input-medium" name="year" id="year" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <option value="2022" <?php if(isset($form['year']) && $form['year'] == '2022') { echo 'selected';} ?>>2022</option>
                                                            <option value="2023" <?php if(isset($form['year']) && $form['year'] == '2023') { echo 'selected';} ?>>2023</option>
                                                            <option value="2024" <?php if(isset($form['year']) && $form['year'] == '2024') { echo 'selected';} ?>>2024</option>
                                                            <option value="2025" <?php if(isset($form['year']) && $form['year'] == '2025') { echo 'selected';} ?>>2025</option>
                                                        </select>
                                                        
                                                    </div>
                                                </div>
                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Stakeholder </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="stakeholder" id="stakeholder"  style="width:100%;padding:10%;" <?php if (isset($master_id)) echo 'disabled="true"' ?> >>
                                                            <option value="">Select</option>
                                                                <?php
                                                                foreach ($stakeholder as $row) {
                                                                    ?>
                                                                <option value="<?php echo $row['stkid'] ?>" <?php if (isset($form['stakeholder']) && $form['stakeholder'] == $row['stkid']) {echo "selected='selected'";}else if ((isset($editstkid)) && $editstkid == $row['stkid']) {echo "selected='selected'";} ?>><?php echo $row['stkname'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>
                                
                                                <div class="col-md-3" id="province_div">
                                                    <label class="example-text-input" for="province" required >Province </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="province" id="province_village" style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php 
//                                                            $provinces = array(3 => "Khyber Pakhtunkhwa");
                                                            foreach ($provinces as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['PkLocID'] ?>" <?php if (isset($form['province']) && $form['province'] == $row['PkLocID']){ echo "selected='selected'";} ?>><?php echo $row['LocName'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div> 
                                                
                                             
                                            </div>
                            
                                            <div class="form-group row"> 
                                                
                                                <div class="col-md-3" id="district_div">
                                                    <label class="example-text-input" for="district_village" required >District  </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="district" id="district_village" style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            if(isset($districts))
                                                            {
                                                                $dist_arr=$districts->result_array();
                                                                foreach ($dist_arr as $row) {
                                                                    ?>
                                                            <option value="<?php echo $row['pk_id']?>" <?php if(isset($district_id)&&$district_id==$row['pk_id']) echo 'selected="selected"'?>><?php echo $row['loc_name']?></option>
                                                                        <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>
                                
                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Warehouse</label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="warehouse" id="warehouse"  style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                                <?php
                                                                foreach ($warehouse as $row) {
                                                                    ?>
                                                                <option value="<?php echo $row['wh_id'] ?>" <?php if (isset($form['warehouse']) && $form['warehouse'] == $row['wh_id']) echo "selected='selected'"; ?>><?php echo $row['wh_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>
                                
                                                <div class="col-md-2">
                                                    <div class="control-group">
                                                    <div class="input-group input-medium" style="margin-top: 21px;">
                                                        <div class="controls">
                                                        <button type="submit" class="btn btn-primary" name="submit" value="Search"> Search </button>
                                                        </div>
                                                    </div>
                                                    </div>
                                                </div>
                                
                                            </div> 
                            
                                <!--<div class="col-md-12">-->
                                    <!--<div class="col-md-12" >-->
                                    
                                    
                                    
                                <!--</div>-->
                            <!--</div>-->
                        </div>
                    </div>
                  </div>
            </form>
                         
                        <br>
                        <?php
                        if (isset($batchsearch) && !empty($batchsearch)) {
                            ?>

                            <div id="divToPrint" style="overflow-x:auto;" >
                                <table class="table table-striped table-bordered " id="datatable-buttons">
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th rowspan="2" class="text-center">S.No.</th>
                                            <th rowspan="2" class="text-center">Article</th>
                                            <th rowspan="2" class="text-center">Strength</th>
                                            <th rowspan="2" class="text-center">Pack Size</th>
                                            <th rowspan="2" class="text-center">No. of Patients on this ARV (Mandatory)<br>(A)</th>
                                            <th rowspan="2" class="text-center">Stock On hand at center at begining of reporting period <br>(B)</th>
                                            <th rowspan="2" class="text-center">Stock Received during reporting period<br>(C)</th>
                                            <th rowspan="2" class="text-center">Total Stock during current Period<br>(D) = (B+C)</th>
                                            <th rowspan="2" class="text-center">Quantity consumed during period<br>(E)</th>
                                            <th colspan="2" class="text-center">Quantity Adjusted during during period (Expired, Damaged or any quantity transferred  etc.)<br>(F)</th>
                                            <th rowspan="2" class="text-center">Viable Stock on hand at the end of reporting period <br>G= (D-E-F)</th>
                                            <th rowspan="2" class="text-center">Monthly Demand</th>
                                            <th colspan="1" class="text-center">(J) Proposed required quantity (No. of Packs)</th>
                                        </tr>
                                        <tr>
                                            <th class="text-center">(+)</th>
                                            <th class="text-center">(-)</th><th rowspan="1" colspan="1" class="text-center">Quarterly Demand</th>
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 

                                    <!-- Table body -->
                                    <tbody>
                                        <?php
//                                        $i = 0;
                                        $len = count($batchsearch);
                                        //check if result rxists
                                        if ($batchsearch) {
                                            $i = 1;
                                            //fetch result
//                                            while ($row = mysql_fetch_object($batchsearch)) {
                                               foreach ($batchsearch as $row) { 
                                                ?>
                                                <!-- Table row -->
                                                <tr>
                                                    <td class="text-center"><?php echo $i; ?></td>
                                                    <td><?php echo $row['itm_name']; ?></td>
                                                    <td><?php echo $row['strength']; ?></td>
                                                    <td><?php echo $row['pack_size']; ?></td>
                                                    <td><?php echo $row['arv_patients']; ?></td>
                                                    <td><?php echo $row['opening_balance']; ?></td>
                                                    <td><?php echo $row['received_balance']; ?></td>
                                                    <td><?php echo $row['total_stock_dcurperiod']; ?></td>
                                                    <td><?php echo $row['issue_balance']; ?></td>
                                                    <td><?php echo $row['adjustment_positive']; ?></td>
                                                    <td><?php echo $row['adjustment_negative']; ?></td>
                                                    <td><?php echo $row['closing_balance']; ?></td>
                                                    <td><?php echo $row['demand']; ?></td>
                                                    <td><?php echo $row['quarterly_demand']; ?></td>
                                                </tr>
                                                <?php
                                                $i++;
                                            }
                                        }
                                        ?>
                                        <!-- // Table row END -->

                                    </tbody>
                                    
                                </table> 
                            </div>

                            <!-- // Table END -->
                            <?php
                        } else {
                            echo "<hr><h5>No data found!</h5>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>