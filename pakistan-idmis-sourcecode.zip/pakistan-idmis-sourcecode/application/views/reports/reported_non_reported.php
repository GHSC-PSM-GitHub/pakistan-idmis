<?php
//echo '<pre>';
//print_r($rpt);exit;
?>
<div class="wrapper">
    <div class="container-fluid">
        <h4>Reported/Non Reported</h4>
        <form method="POST" name="dc_searchs" action="reported_non_reported" >
            <div class="row">
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <div class="form-group row"> 
                                <div class="col-md-3">
                                    <label class="example-text-input" required >Month<span style="color: red">*</span> </label>
                                    <div class="controls">
                                        <select class="select2me input-medium" name="month" id="month" required style="width:100%;padding:10%;">
                                            <?php
                                            for ($i = 0; $i < 12; $i++) {
                                                $time = strtotime(sprintf('%d months', $i));
                                                $label = date('F', $time);
                                                $value = date('n', $time);
                                                if (isset($form['month']) && $form['month'] == $i) {
                                                    $sel = 'selected';
                                                }
                                                echo "<option $sel value='$value'>$label</option>";
                                            }
                                            ?>
                                        </select>  
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label class="example-text-input" required >Year<span style="color: red">*</span> </label>
                                    <div class="controls">
                                        <?php
//                                                        echo "<select class='select2me input-medium' name='year' style='width:100%;padding:10%;'>";
//                                                        for($i=0;$i<=5;$i++){
//                                                            $year=date('Y',strtotime("last day of +$i year"));
//                                                            echo "<option name='$year'>$year</option>";
//                                                        }
//                                                        echo "</select>";
                                        ?>

                                        <select class="select2me input-medium" name="year" id="year" required style="width:100%;padding:10%;">
                                            <option value="2022" <?php
                                            if (isset($form['year']) && $form['year'] == '2022') {
                                                echo 'selected';
                                            }
                                            ?>>2022</option>
                                            <option value="2023" <?php
                                            if (isset($form['year']) && $form['year'] == '2023') {
                                                echo 'selected';
                                            }
                                            ?>>2023</option>
                                            <option value="2024" <?php
                                            if (isset($form['year']) && $form['year'] == '2024') {
                                                echo 'selected';
                                            }
                                            ?>>2024</option>
                                            <option value="2025" <?php
                                            if (isset($form['year']) && $form['year'] == '2025') {
                                                echo 'selected';
                                            }
                                            ?>>2025</option>
                                        </select>

                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label class="example-text-input" required >Stakeholder </label>
                                    <div class="controls">
                                        <select class="select2me input-medium" name="stakeholder" id="stakeholder"  style="width:100%;padding:10%;" <?php if (isset($master_id)) echo 'disabled="true"' ?> >>

                                            <?php
                                            foreach ($stakeholder as $row) {
                                                ?>
                                                <option value="<?php echo $row['stkid'] ?>"><?php echo $row['stkname'] ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>  
                                    </div>
                                </div>
                                <div class="col-md-3" id="province_div">
                                    <label class="example-text-input" for="province" required >Province </label>
                                    <div class="controls">
                                        <select class="select2me input-medium" name="province" id="province_village" style="width:100%;padding:10%;">
                                            <?php
//                                                            $provinces = array(3 => "Khyber Pakhtunkhwa");
                                            foreach ($provinces as $row) {
                                                ?>
                                                <option value="<?php echo $row['PkLocID'] ?>" <?php
                                                if (isset($form['province']) == $row['PkLocID']) {
                                                    echo "selected='selected'";
                                                }
                                                ?>><?php echo $row['LocName'] ?></option>
                                                        <?php
                                                    }
                                                    ?>
                                        </select>  
                                    </div>
                                </div> 
                                <div class="col-md-3" id="district_div">
                                    <label class="example-text-input" for="district_village" required >District</label>
                                    <div class="controls">
                                        <select class="select2me input-medium" name="district" id="district_village" style="width:100%;padding:10%;">
                                            <?php
                                            if (isset($districts)) {
                                                $dist_arr = $districts->result_array();
                                                foreach ($dist_arr as $row) {
                                                    ?>
                                                    <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($district_id) && $district_id == $row['pk_id']) echo 'selected="selected"' ?>><?php echo $row['loc_name'] ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>  
                                    </div>
                                </div>
                                <div class="col-md-3" id="lvl_div">
                                    <label class="example-text-input" for="lvl" required >Type</label>
                                    <div class="controls">
                                        <select class="select2me input-medium" name="lvl" id="lvl" style="width:100%;padding:10%;">
                                            <option value="1">District Stores</option>
                                            <option value="2">Health Facilities</option>
                                        </select>  
                                    </div>
                                </div>
                                <div class="col-md-3" id="rpt_type_div">
                                    <label class="example-text-input" for="rpt_type" required >Type</label>
                                    <div class="controls">
                                        <select class="select2me input-medium" name="rpt_type" id="rpt_type" style="width:100%;padding:10%;">
                                            <option value="1">Reported</option>
                                            <option value="2">Non-Reported</option>
                                        </select>  
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="control-group">
                                        <div class="input-group input-medium" style="margin-top: 21px;">
                                            <div class="controls">
                                                <button type="submit" class="btn btn-primary" name="submit" value="Search"> Search </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>  
            </div>
        </form>

        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <?php
                        //count
                        $count = 1;
//data
                        $data = array();
//total warehouse
                        $totalWH = 0;
//on time
                        $ontime = 0;
//late
                        $late = 0;
//reported All 
                        $reportedAll = 0;
//non Reported 
                        $nonReported = 0;
//query result
                        foreach ($rpt as $row) {
//    echo '123';exit;
//total warehouse	
                            $totalWH++;
                            // Reported Count (Ontime and Late)
                            if (!empty($row['add_date'])) {
                                $data['reported'][] = $row;
                                $reportedAll++;
                            }
                            // Ontime Reported
                            if (!empty($row['add_date']) && $row['add_date'] < $newDate) {
                                $data['ontime'][] = $row;
                                $ontime++;
                            }
                            // Late Reported
                            else if (!empty($row['add_date']) && $row['add_date'] >= $newDate) {
                                $data['late'][] = $row;
                                $late++;
                            }

                            if (empty($row['add_date'])) { // Non-Reported Count
                                $data['non-reported'][] = $row;
                                $nonReported++;
                            }
                        }

// Create XML for the Grid
                        $xmlstore = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
                        $xmlstore .= "<rows>";
                        if ($sel_report_type == 'reported') {
                            $dataArr = $data['reported'];
                            //report title
                            $report_title = "All Reported Stores/Facilities Report for";
                            if ($row['add_date'] < $newDate) {
                                $color = 'color:#009900;';
                                $rpt_status = 'On-time';
                            } else {
                                $color = 'color:#FF0000;';
                                $rpt_status = 'Late';
                            }
                        } else if ($sel_report_type == 'ontime') {
                            $dataArr = $data['ontime'];
                            //report title
                            $report_title = "On-time Reported Stores/Facilities Report for";
                            //color 
                            $color = 'color:#009900;';
                            $rpt_status = 'Late';
                        } else if ($sel_report_type == 'late') {
                            $dataArr = $data['late'];
                            //report title
                            $report_title = "Late Reported Stores/Facilities Report for";
                            //color 
                            $color = 'color:#FF0000;';
                            $rpt_status = 'Late';
                        } else if ($sel_report_type == 'non-reported') {
                            $dataArr = $data['non-reported'];
                            //report title
                            $report_title = "Non-reported Stores/Facilities Report for";
                            //color 
                            $color = 'color:#FF0000;';
                            $rpt_status = 'Non-reported';
                        }

                        $num = count($dataArr);

                        foreach ($dataArr as $row) {
//stakeholder name	
                            $stakeholderName = $row['stkMain'];
                            //province Name 
                            $provinceName = $row['province'];

                            if ($sel_report_type == 'reported') {
                                if ($row['add_date'] < $newDate) {
                                    //color
                                    $color = 'color:#009900;';
                                    $rpt_status = 'On-time';
                                } else {
                                    //color	
                                    $color = 'color:#FF0000;';
                                    $rpt_status = 'Late';
                                }
                            } else if ($sel_report_type == 'ontime') {
                                //color	
                                $color = 'color:#009900;';
                                $rpt_status = 'On-time';
                            } else if ($sel_report_type == 'late') {
                                //color	
                                $color = 'color:#FF0000;';
                                $rpt_status = 'Late';
                            } else if ($sel_report_type == 'non-reported') {
                                //color	
                                $color = 'color:#FF0000;';
                                $rpt_status = 'Non-reported';
                            }

                            $xmlstore .= "<row>";
                            $xmlstore .= "<cell>" . $count++ . "</cell>";
                            //province
                            $xmlstore .= "<cell><![CDATA[" . $row['province'] . "]]></cell>";
                            //district
                            $xmlstore .= "<cell><![CDATA[" . $row['district'] . "]]></cell>";
                            //stakeholder Main
                            $xmlstore .= "<cell><![CDATA[" . $row['stkMain'] . "]]></cell>";
                            //stakeholder Office
                            $xmlstore .= "<cell><![CDATA[" . $row['stkOffice'] . "]]></cell>";
                            if ($sel_report_type != 'non-reported') {
                                $tempVar = "\"$row[wh_id]&month=$sel_month&year=$sel_year\"";
                                $xmlstore .= "<cell><![CDATA[<a href=javascript:showData($tempVar)>" . $row['wh_name'] . "</a>]]>^_self</cell>";
                            } else {
                                //warehouse name
                                $xmlstore .= "<cell><![CDATA[" . $row['wh_name'] . "]]></cell>";
                            }
                            //last_update
                            $xmlstore .= "<cell><![CDATA[" . $row['last_update'] . "]]></cell>";
                            //history
                            $xmlstore .= "<cell><![CDATA[<a href=javascript:showHistory($tempVar)>History</a>]]></cell>";
                            //ip_address
                            $xmlstore .= "<cell><![CDATA[" . $row['ip_address'] . "]]></cell>";
                            //status
                            $xmlstore .= "<cell style=\"$color\"><![CDATA[" . $rpt_status . "]]></cell>";


                            $xmlstore .= "</row>";
                        }
                        $xmlstore .= "</rows>";
//province Name
                        $provinceName = ($sel_prov == 'all') ? 'All' : $provinceName;
//stakeholder name
                        $stakeholderName = ($sel_stk1 == 'all') ? 'All' : $stakeholderName;
//check sel level type
                        if ($sel_lvl_type == 3) {
                            //set store type
                            $storeType = 'District Stores';
                        } elseif ($sel_lvl_type == 4) {
//set store type
                            $storeType = 'Field Stores';
                        } elseif ($sel_lvl_type == 7) {
//set store type
                            $storeType = 'Health Facilities';
                        } elseif ($sel_lvl_type == 'all') {
//set store type
                            $storeType = 'Stores/Facilities';
                        } elseif ($sel_lvl_type == 'df') {
//set store type
                            $storeType = 'District and Field Stores';
                        }
                        ?>
                        <!-- END HEAD -->
                        <table class="table table-bordered">
                            <tr>
                                <th>
                                    Sr.No.
                                </th>
                                <th>
                                    Province/Region
                                </th>
                                <th>
                                    District
                                </th>
                                <th>
                                    Stakeholder
                                </th>
                                <th>
                                    Warehouse/Store Name
                                </th>
                                <th>
                                    Status
                                </th>
                            </tr>
                            <?php
                            $total = 1;
                            foreach ($rpt as $row) {
                                ?>
                                <tr>
                                    <td>
    <?php echo $total++; ?>
                                    </td>
                                    <td>
    <?php echo $row->province; ?> 
                                    </td>
                                    <td>
    <?php echo $row->district; ?> 
                                    </td>
                                    <td>
    <?php echo 'NTP-KPK'; ?> 
                                    </td>
                                    <td>
    <?php echo $row->wh_name; ?> 
                                    </td>
                                    <td>
    <?php echo 'Reported'; ?> 
                                    </td>
                                </tr>
<?php } ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

