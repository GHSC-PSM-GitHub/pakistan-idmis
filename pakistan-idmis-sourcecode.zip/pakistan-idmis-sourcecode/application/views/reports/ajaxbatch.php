<?php
/**
 * ajaxbatch
 * @package im
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
//Including AllClasses file
//include("../includes/classes/AllClasses.php");
//Checking id
if (isset($_POST['id']) && !empty($_POST['id'])) {
//Getting id
    $id = $_POST['id'];
    //Setting id
//    $result = $objStockBatch->find_by_item($id);
    //Check result
    if (isset($result)) {
        $bres = $result[0];
        foreach ($result as $row) {
        (int) $RunningDoses = $row['RunningQty'];
        (int) $StackedDoses = $row['StackedQty'];
        (int) $FinishedDoses = $row['FinishedQty'];
        (int) $total = $RunningDoses + $StackedDoses + $FinishedDoses;
        }
    } else {
        $RunningDoses = 0;
        $StackedDoses = 0;
        $FinishedDoses = 0;
        $total = 0;
    }
    ?>
    <!-- Widget heading -->
    <div class="widget-head" style="background-color: #B5E4CB ">
        <h4 class="heading"> <?php echo $bres['itm_name']; ?></span></h4>
    </div>
    <!-- // Widget heading END -->

    <div class="form-group row " style="border:1px solid #B5E4CB">
        <div class="col-md-4">
            <p style="font-weight: bold;">Batch Status</p>
            <p>Running</p>
            <p>Stacked</p>
            <p>Finished</p>
            <p style="font-weight: bold;">Total</p>
        </div>
        <div class="col-md-4 center">
            <p style="text-align:right;font-weight: bold;">No of Batches</p>
            <p style="text-align:right" id="running"><?php echo!empty($bres['running']) ? $bres['running'] : 0; ?></p>
            <p style="text-align:right" id="stacked"><?php echo!empty($bres['stacked']) ? $bres['stacked'] : 0; ?></p>
            <p style="text-align:right" id="finished"><?php echo!empty($bres['finished']) ? $bres['finished'] : 0; ?></p>
            <p style="text-align:right;font-weight: bold;" id="total"><?php echo $bres['running'] + $bres['stacked'] + $bres['finished']; ?></p>
        </div>
        <div class="col-md-4 center">
            <p style="text-align:right;font-weight: bold;">Quantity (<?php echo $bres['itm_type']; ?>)</p>
            <p style="text-align:right"><?php echo number_format($RunningDoses); ?></p>
            <p style="text-align:right"><?php echo number_format($StackedDoses); ?></p>
            <p style="text-align:right"><?php echo number_format($FinishedDoses); ?></p>
            <p style="text-align:right;font-weight: bold;"><?php echo number_format($total); ?></p>
        </div>
    </div>
    <div style="clear:both;"></div>
    
    <?php
}
//Checking batch_id
if (isset($_POST['batch_id']) && !empty($_POST['batch_id'])) {
    //Getting batch_id
    $batch_id = $_POST['batch_id'];
    //Getting status
    $status = $_POST['batch_status'];
    //Check status
    if ($status == 'Running' || $status == 'Finished') {
        $button = 'Stacked';
    } else {
        $button = 'Running';
    }
//    change Status
//    $result = $objStockBatch->changeStatus($batch_id, $button);
    if ($sresult) {
        $array = array(
            'status' => $button,
            'button' => $status
        );
    } 
    else {
        $array = array(
            'status' => $status,
            'button' => $button
        );
    }
    //Encode in json
    echo json_encode($array);
}
?>