<style>

    .datepicker.dropdown-menu {
        z-index: 9999 !important;
    }

</style>
<?php
$status = '4';
if (isset($form['status']) && !empty($form['status'])) {
    $status = $form['status'];
}

$flag = false;
//check product
if (isset($_REQUEST['batch_mang_product']) && !empty($_REQUEST['batch_mang_product'])) {
    //get product
    $batch_mang_product = trim($_REQUEST['batch_mang_product']);
    //set product
//                $qryString .= '&product=' . $product;
    $flag = true;
}
//check status
if (isset($_REQUEST['tran_type']) && !empty($_REQUEST['tran_type'])) {
    //get funding_source
    $tran_type = trim($_REQUEST['tran_type']);
    //set funding_source
//                $objStockBatch->funding_source = $funding_source;
//                $qryString .= '&funding_source=' . $funding_source;
}
?>
<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Adjustment Report</h3>

                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                    <div class="innerLR">

                        <form method="POST" name="dc_searchs" action="adjustment_report" >
                            <!-- Row -->
                            <div class="col-md-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="form-group row ">
                                            <!--<div class="col-md-12">-->
                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="example-text-input" for="start_date"  >Start Date(MM/DD/YYYY)  </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="start_date" id="start_date"  value="<?php if (isset($form['start_date']) && !empty($form['start_date'])) {
    echo $form['start_date'];
} else {
    echo date("d/m/Y");
} ?>" >

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="example-text-input" for="end_date"  >End Date(MM/DD/YYYY)  </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="end_date" id="end_date" value="<?php if (isset($form['end_date']) && !empty($form['end_date'])) {
    echo $form['end_date'];
} else {
    echo date("d/m/Y");
} ?>" >

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3" id="show_receive_from_suppliers" >
                                                <label class="example-text-input" for="product_category"  >Product Category </label>
                                                <div class="controls">
                                                    <select class="select2me input-medium"  name="product_category" id="product_category" style="width:100%;padding:10%;">
                                                        <option value="">Select</option>
                                                        <?php
                                                        foreach ($product_cat as $row) {
                                                            ?>
                                                            <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($_REQUEST['product_category']) && $_REQUEST['product_category'] == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['name'] ?></option>
    <?php
}
?>

                                                    </select>  
                                                </div>
                                            </div>
                                            <div class="col-md-3" id="show_receive_from_suppliers" >
                                                <label class="example-text-input" for="batch_mang_product"  >Product </label>
                                                <div class="controls">
                                                    <select class="select2me input-medium"  name="batch_mang_product" id="batch_mang_product" style="width:100%;padding:10%;">
                                                        <option value="">Select</option>
                                                        <?php
                                                        foreach ($product as $row) {
                                                            ?>
                                                            <option value="<?php echo $row['itm_id'] ?>" <?php if (isset($_REQUEST['batch_mang_product']) && $_REQUEST['batch_mang_product'] == $row['itm_id']) echo "selected='selected'"; ?>><?php echo $row['itm_name'] ?></option>
    <?php
}
?>

                                                    </select>  
                                                </div>
                                            </div>

                                            <!--</div>-->
                                            <!--</div>-->
                                        </div>

                                        <div class="form-group row">
                                            <div class="col-md-3">
                                                <label class="example-text-input"  >Reason for Adjustment <span style="color: red">*</span> </label>
                                                <div class="controls" style="<?= ((isset($temp_records) && (!empty($temp_records))) ? 'display:none;' : '') ?>">

                                                    <select class="select2me input-medium " name="tran_type" id="tran_type" required style="width:100%;padding:10%;" >
                                                        <option value="">Select</option>
                                                        <?php
                                                        foreach ($trans as $row) {
                                                            ?>
                                                            <option value="<?php echo $row['trans_id'] ?>" <?php if (isset($tran_type) && $tran_type == $row['trans_id']) {
                                                                echo "selected='selected'";
                                                                $this_tran = $row['trans_type'];
                                                            } ?>><?php echo $row['trans_type'] . ' (' . $row['trans_nature'] . ')'; ?></option>
    <?php
}
?>

                                                    </select> 

                                                </div>
                                            </div>
                                            <!--<div class="col-md-12" >-->


                                            <div class="col-md-2">
                                                <div class="control-group">
                                                    <div class="input-group input-medium" style="margin-top: 21px;">
                                                        <div class="controls">
                                                            <button type="submit" class="btn btn-primary" name="submit" value="Search"> Search </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </form>

                        <br>
<?php
if (isset($batchsearch) && !empty($batchsearch)) {
    ?>

                            <div id="divToPrint" style="overflow-x:auto;" >

                                <table class="table table-striped table-bordered " id="datatable-buttons">
                                    <div id="report_type" style=" text-align:center; background: greenyellow;">
                                        <span style="line-height:20px"><b>STOCK LEDGER REPORT</b></span><br/>
                                        <span style="line-height:20px"><b>NTP</b></span><br/>
                                        <span style="line-height:20px"><b><?php foreach ($whName as $whname) {
        echo $whname['wh_name'];
    } ?></b></span><br/>
                                    </div>
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th width="60">Sr. No.</th>
                                            <th>Product</th>
                                            <th>Batch No.</th>
                                            <th>Expiry Date</th>
                                            <th>Strength</th>
                                            <th>Unit Cost</th>
                                            <th>Transfer Type</th>
                                            <th>Adjust Quantity</th>
                                            <!--<th>Remaining Quantity</th>-->
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 

                                    <!-- Table body -->
                                    <tbody>
    <?php
//                                        $i = 0;
    $len = count($batchsearch);
    //check if result rxists
    if ($batchsearch) {
        $i = 1;
        //fetch result
//                                            while ($row = mysql_fetch_object($batchsearch)) {
        foreach ($batchsearch as $row) {
            ?>
                                                <!-- Table row -->
                                                <tr class="gradeX">
                                                    <td class="center"><?php echo $i; ?></td>
                                                    <td><?php echo $row['itm_name']; ?></td>
                                                    <td><?php echo $row['batch_no']; ?></td>
                                                    <td><?php echo $row['batch_expiry']; ?></td>
                                                    <td><?php echo $row['strength']; ?></td>
                                                    <td><?php echo $row['unit_price']; ?></td>
                                                    <td><?php echo $row['trans_type']; ?></td>
                                                    <td><?php echo abs($row['issue_qty']); ?></td>
                                                    <!--<td>-->
                                                <?php
//                                                            $pop = 'onclick="window.open(\'print_ledger_history?id=' . $row['batch_id'] . '\',\'_blank\',\'scrollbars=1,width=840,height=595\')"';
//                                                            echo '<a style="text-decoration: underline;" class="alert-link" ' . $pop . ' >' . $row['batch_no'] . '</a>'
                                                ?>
                                                    <!--</td>-->
            <?php if ($i == $len) { ?>
                                                        <!--<td><?php echo abs($row['Qty']); ?></td>-->
            <?php } ?>
                                                </tr>
            <?php
            $i++;
        }
    }
    ?>
                                        <!-- // Table row END -->

                                    </tbody>

                                </table> 
                            </div>

                            <!-- // Table END -->
    <?php
} else {
    echo "<hr><h5>No data found!</h5>";
}
?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>