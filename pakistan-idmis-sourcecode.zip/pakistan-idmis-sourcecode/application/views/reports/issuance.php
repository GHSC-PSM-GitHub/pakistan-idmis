<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons"> 
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                    <!-- // Heading END -->
                    <h3>Issuance Report</h3>
                     <div class="innerLR">
                        <br>
                       

                            <div id="divToPrint">
                                <table  id="datatable-buttons"  class="table table-striped table-bordered table-condensed dt-responsive nowrap">
                                    <thead>
                                        <tr>
                                            <td>#</td>
                                            <td>Issuance Number</td>
                                            <td>From</td>
                                            <td>To</td>
                                            <td>Issuance Date</td>
                                            <td>Item Name</td>
                                            <td>Batch Number</td>
                                            <td>Quantity Issued</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                           
                                    <?php
                                    $c=1;
                                    if(!empty($list))
                                    foreach($list as $k=> $row){
                                        echo '<tr>';
                                        echo '<td>'.$c++.'</td>';
                                        echo '<td>I-'.sprintf('%04d', $row['pk_id']).'</td>';
                                        echo '<td>'.$row['wh_from'].'</td>';
                                        echo '<td>'.((!empty($row['issuance_to']) && $row['issuance_to']=='patients')?$row['full_name'].'-'.$row['nic_no']:$row['wh_to']).'</td>';
                                        echo '<td>'.$row['transaction_date'].'</td>';
                                        echo '<td>'.$row['product_name'].'</td>';
                                        echo '<td>'.$row['batch_number'].'</td>';
                                        echo '<td>'.abs($row['quantity']).'</td>';
                                        echo '</tr>';
                                    }
                                    ?>
                        
                                    </tbody>
                                </table>
                            </div>

                          
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

