<?php
$batch_data = array();
foreach($list as $k=> $row){
    $batch_data['batch_number'] = $row['batch_number'];
    $batch_data['batch_expiry'] = $row['batch_expiry'];
    $batch_data['product_name'] = $row['product_name'];
    $batch_data['quantity'] = $row['soh'];
    $batch_data['generic_name'] = $row['generic_name'];
    $batch_data['warehouse_name'] = $row['warehouse_name'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title">Batch  History : <?=$batch_data['batch_number']?></h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Reports</a></li>
                        <li class="breadcrumb-item active">Batch History</li>
                    </ol>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                        <div class="card-body">
            
            </div>
                    
                    <div class="card-body">
   
                        <table  id=""  class="table table-striped table-bordered table-condensed">
                            <thead>
                                <tr><td width="25%"><h6>Center Name</h6></td>    <td><?=$batch_data['warehouse_name']?></td></tr>
                                <tr><td><h6>Batch Number</h6></td>   <td><?=$batch_data['batch_number']?></td></tr>
                                <tr><td><h6>Expiry Date</h6></td>    <td><?=$batch_data['batch_expiry']?></td></tr>
                                <tr><td><h6>Product Name</h6></td>   <td><?=$batch_data['product_name']?></td></tr>
                                <tr><td><h6>Generic Name</h6></td>   <td><?=$batch_data['generic_name']?></td></tr>
                                <tr><td><h6>Stock On Hand</h6></td>  <td><?=$batch_data['quantity']?></td></tr>
                            </thead>
                        </table>
                        <table  id="datatable-buttonsx"  class="table table-striped table-bordered table-condensed">
                            <thead>
                            <tr>
                                <td>#</td>
                                <td>Transaction Date</td>
                                <td>Transaction No</td>
                                <td>From</td>
                                <td>To</td>
                                <td>Transaction Type</td>
                                <td>Quantity</td>
                                <td>Balance</td>
                            </tr>
                            </thead>
                            <tbody>
                        <?php
                        $c=1;
                        $balance = 0;
                        foreach($list as $k=> $row){
                            
                            if($row['transaction_type_id'] == 1) $tr_prefix='R';
                            elseif($row['transaction_type_id'] == 2) $tr_prefix='I';
                            else $tr_prefix='A';
                            echo '<tr>';
                            echo '<td>'.$c++.'</td>';
                            echo '<td>'.$row['transaction_date'].'</td>';
                            echo '<td>'.$tr_prefix.'-'.sprintf('%04d', $row['pk_id']).'</td>';
                            echo '<td>'.$row['wname_from'].'</td>';
                            echo '<td>'.((!empty($row['issuance_to']) && $row['issuance_to']== 'patients')?$row['patient_name'].'-'.$row['nic_no']:$row['wname_to']).'</td>';
                            echo '<td>'.$row['trans_type'].' ('.$row['trans_nature'].')</td>';
                            echo '<td align="right">'.number_format($row['quantity']).'</td>';
                            
                            $balance += $row['quantity'];
                            echo '<td align="right">'.number_format($balance).'</td>';
                            echo '</tr>';
                        }
                        ?>
                            </tbody>
                        </table>
                    </div>
        </div>
        </div>
        </div>
        </div>
        </div>