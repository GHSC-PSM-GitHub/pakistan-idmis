<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
}
    
</style>
<?php 
$status = '4';
if(isset($form['status']) && !empty($form['status']))
{
    $status = $form['status'];
}

$flag = false;
//check product
if (isset($_REQUEST['batch_mang_product']) && !empty($_REQUEST['batch_mang_product'])) {
    //get product
    $batch_mang_product = trim($_REQUEST['batch_mang_product']);
    //set product
//                $qryString .= '&product=' . $product;
    $flag = true;
}
//check status
if (isset($status) || (isset($_REQUEST['status']) && !empty($_REQUEST['status']))) {
    //get status
    $status = !empty($_REQUEST['status']) ? trim($_REQUEST['status']) : $status;
    //set status
//                $qryString .= '&status=' . $status;
}
//check batch number
if (isset($_REQUEST['batch_no']) && !empty($_REQUEST['batch_no'])) {
    //get batch number
    $batch_no = trim($_REQUEST['batch_no']);
    //set batch number
//                $qryString .= '&batch_no=' . $batch_no;
}
//check ref number
if (isset($_REQUEST['ref_no']) && !empty($_REQUEST['ref_no'])) {
    //get ref number
    $ref_no = trim($_REQUEST['ref_no']);
    //set ref number
//                $qryString .= '&ref_no=' . $ref_no;
}
//check funding_source
if (isset($_REQUEST['source_type']) && !empty($_REQUEST['source_type'])) {
    //get funding_source
    $source_type = trim($_REQUEST['source_type']);
    //set funding_source
//                $objStockBatch->funding_source = $funding_source;
//                $qryString .= '&funding_source=' . $funding_source;
}
?>
<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Batch Management</h3>
                         
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                     <div class="innerLR">
                         
                         <form method="POST" name="dc_searchs" action="batch_management" >
                            <!-- Row -->
                  <div class="col-md-12">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <div class="form-group row ">
                                <div class="col-md-6">
                                    <div class="form-group row ">
                                        <div class="col-md-8" id="show_receive_from_suppliers" >
                                            <label class="example-text-input" for="batch_mang_product"  >Product </label>
                                            <div class="controls">
                                                <select class="select2me input-medium"  name="batch_mang_product" id="batch_mang_product" style="width:100%;padding:10%;">
                                                    <option value="">Select</option>
                                                    <?php

                                                    foreach ($product as $row) {
                                                        ?>
                                                        <option value="<?php echo $row['itm_id'] ?>" <?php if (isset($_REQUEST['batch_mang_product']) && $_REQUEST['batch_mang_product'] == $row['itm_id']) echo "selected='selected'"; ?>><?php echo $row['itm_name'] ?></option>
                                                        <?php
                                                    }
                                                    ?>

                                                </select>  
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div style="margin-top:20px;float:right; <?php echo (!empty($batch_mang_product)) ? 'display:none' : 'display:block'; ?>" id="printSummary">
                                                <button type="button" class="btn btn-primary input-small" onClick="window.open('print_batch_management?type=1', '_blank', 'scrollbars=1,width=860,height=595');">Summary</button>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="col-md-12" style="border:1px solid #B5E4CB;">
                                            <div class="widget-head">
                                                <h4 class="heading" style="background-color:#B5E4CB;">Status</h4>
                                            </div>
                                            <!-- // Widget heading END -->

                                            <div class="widget-body" style="margin-left:20px;">
                                                <label class="radio">
                                                    <input type="radio" class="radio" name="status" value="1" <?php if ($status == 1) { ?>checked="" <?php } ?> />
                                                    Running </label>
                                                <br/>
                                                <label class="radio">
                                                    <input type="radio" class="radio" name="status" value="2" <?php if ($status == 2) { ?>checked="" <?php } ?> />
                                                    Stacked </label>
                                                <br/>
                                                <label class="radio">
                                                    <input type="radio" class="radio" name="status" value="3" <?php if ($status == 3) { ?>checked="" <?php } ?> />
                                                    Finished </label>
                                                <br/>
												<label class="radio">
                                                    <input type="radio" class="radio" name="status" value="5" <?php if ($status == 5) { ?>checked="" <?php } ?> />
                                                    Expired </label>
                                                <br/>
                                                <label class="radio">
                                                    <input type="radio" class="radio" name="status" value="4" <?php if ($status == '4') { ?>checked="" <?php } ?>/>
                                                    Total (Running + Stacked) </label>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="form-group row ">
                                    <!--<div class="col-md-12" >-->
                                    <div class="col-md-3">
                                        <label for="firstname">Batch No</label>
                                        <input class="form-control input-small" id="batch_no" name="batch_no" type="text" value="<?php if(isset($batch_no) && !empty($batch_no)) { echo $batch_no;} ?>" />
                                    </div>
                                    
                                    <div class="col-md-3">
                                        <label for="firstname">Ref No</label>
                                                        <input class="form-control input-small" id="ref_no" name="ref_no" type="text" value="<?php if(isset($ref_no) && !empty($ref_no)) { echo $ref_no;} ; ?>" />
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <label class="control-label" for="source_type"> Funding Source </label>
                                        <div class="controls">
                                            <select name="source_type" id="source_types" class="select2me input-medium"  style="width:100%;padding:10%;"  >
                                                <option value="">Select</option>
                                                <?php
                                                if ($funding_source) {
                                                    //fetch result
                                                    foreach ($funding_source as $row) {
                                                        //populate receive_from combo
//                                                                if($_SESSION['user_stakeholder']=='145'){
//                                                                    if($row->wh_id != '33677' && $row->wh_id != '33678' && $row->wh_id != '33680' && $row->wh_id != '20641'  && $row->wh_id != '9079') 
//                                                                        continue;
//                                                                }
                                                        ?>
                                                <option value="<?php echo $row['stkid']; ?>" <?php if (isset($source_type) && $source_type == $row['stkid']) { ?> selected="" <?php } else if(isset ($form['source_type']) &&  $form['source_type'] == $row['stkid']) { ?> selected="" <?php } ?>> <?php echo $row['stkname']; ?> </option>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-2">
                                        <div class="control-group">
                                        <div class="input-group input-medium" style="margin-top: 21px;">
                                            <div class="controls">
                                            <button type="submit" class="btn btn-primary" name="submit" value="Search"> Search </button>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                    </div>
                                    
                                    <div class="form-group row ">
                                        <div class="col-md-12">
                                            <div class="control-group">
                                            <div class="input-group input-medium" style="margin-top: 21px;">
                                                <div class="controls">
                                                    <button onclick=" window.open('distribution_detail','_blank')" style="float: Left;" class="btn btn-success" value="Distribution summary"> Distribution summary </button>
                                                    &nbsp;&nbsp;&nbsp;<button onclick=" window.open('detail_distribution','_blank')" style="float: right;" class="btn btn-success" value="Detailed distribution"> Detailed distribution  </button>
                                                </div>
                                            </div>
                                            </div>
                                        </div>
<!--                                        <div class="col-md-4">
                                            <div class="control-group">
                                            <div class="input-group input-medium" style="margin-top: 21px;">
                                                <div class="controls">
                                                <button onclick=" window.open('detail_distribution','_blank')" style="float: left;" class="btn btn-success" value="Detailed distribution"> Detailed distribution  </button>
                                                </div>
                                            </div>
                                            </div>
                                        </div>-->
                                    </div>
                                    
                                <!--</div>-->
                            </div>
                            <div class="col-md-6" id="vaccine-detail" <?php if ($flag == true) { ?> style="display:block;" <?php } else { ?>style="display:none;" <?php } ?>> 
                                <!-- Widget -->
                                <?php
//                                $result = '';
//                                if (isset($product) && !empty($product)) {
//                                    $result = $objStockBatch->find_by_item($product);
//                                    (int) $RunningVials = $result->RunningQty;
//                                    (int) $StackedVials = $result->StackedQty;
//                                    (int) $FinishedVials = $result->FinishedQty;
//                                    (int) $total = $RunningVials + $StackedVials + $FinishedVials;
//                                } else {
//                                    $RunningVials = 0;
//                                    $StackedVials = 0;
//                                    $FinishedVials = 0;
//                                    $total = 0;
//                                }
                                ?>
                                <div class="widget row-fluid" data-toggle="collapse-widget"  id="batch_detail_ajax">
                                    <?php
//                                    if ($result) {
                                        ?>
                                        <!-- Widget heading -->
<!--                                        <div class="widget-head">
                                            <h4 class="heading"><?php echo $result->itm_name; ?></h4>
                                        </div>
                                         // Widget heading END 

                                        <div class="widget-body">
                                            <div class="col-md-4">
                                                <p><b>Batch Status</b></p>
                                                <p>Running</p>
                                                <p>Stacked</p>
                                                <p>Finished</p>
                                                <p><b>Total</b></p>
                                            </div>
                                            <div class="col-md-4 center">
                                                <p style="text-align:right"><b>No of Batches</b></p>
                                                <p style="text-align:right" id="running"><?php echo!empty($result->running) ? $result->running : 0; ?></p>
                                                <p style="text-align:right" id="stacked"><?php echo!empty($result->stacked) ? $result->stacked : 0; ?></p>
                                                <p style="text-align:right" id="finished"><?php echo!empty($result->finished) ? $result->finished : 0; ?></p>
                                                <p style="text-align:right" id="total"><b><?php echo $result->running + $result->stacked + $result->finished; ?></b></p>
                                            </div>
                                            <div class="col-md-4 center" >
                                                <p style="text-align:right"><b>Quantity (<?php echo $result->itm_type; ?>)</b></p>
                                                <p style="text-align:right"><?php echo number_format($result->RunningQty); ?></p>
                                                <p style="text-align:right"><?php echo number_format($result->StackedQty); ?></p>
                                                <p style="text-align:right"><?php echo number_format($result->FinishedQty); ?></p>
                                                <p style="text-align:right" id="total"><b><?php echo number_format($result->RunningQty + $result->StackedQty + $result->FinishedQty); ?></b></p>
                                            </div>
                                        </div>
                                        <div style="clear:both;"></div>-->
                                        <?php
//                                    }
                                    ?>
                                </div>
                                <!-- Widget --> 
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
            </form>
                         
                        <br>
                        <?php
                        if (!empty($batchsearch)) {
                            ?>

                            <div id="divToPrint" style="overflow-x:auto;" >
                                <table class="table table-striped table-bordered " id="datatable-buttons">
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th width="60">Sr. No.</th>
                                            <th>Product</th>
                                                <th>Funding Source</th>
                                            <th>Batch No.</th>
                                            <!--<th>Manufacturer</th>-->
                                            <th>Stakeholder</th>
                                            <th>Expiry Date</th>
                                            <th>Quantity</th>
                                            <th>Unit Cost</th>
                                            <th>Cartons</th>
                                            <th>Price</th>
                                            <th>Status</th>
                                            <?php if ($_SESSION['role'] == 1) { ?>
                                                <th class="center" width="150">Action</th>
                                                <?php // if ($_SESSION['user_level'] < 3) { ?>
<!--                                                    <th class="center" width="100">DTL Status</th>
                                                    <th class="center" width="100">Physical Inspection</th>-->
                                                <?php // } ?>
                                            <?php } ?>
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 

                                    <!-- Table body -->
                                    <tbody>
                                        <?php
                                        //check if result rxists
                                        if ($batchsearch) {
                                            $i = 1;
                                            //fetch result
//                                            while ($row = mysql_fetch_object($batchsearch)) {
                                               foreach ($batchsearch as $row) { 
                                                $price = '';
                                                if(!empty($row['unit_price']) && $row['unit_price']>0 && $row['BatchQty'])
                                                {
                                                    $price = $row['BatchQty'] * $row['unit_price'];
                                                }   
                                                ?>
                                                <!-- Table row -->
                                                <tr class="gradeX">
                                                    <td class="center"><?php echo $i; ?></td>
                                                    <td><?php echo $row['itm_name']; ?></td>
                                                        <!--<td><?php echo $row['funding_source']; ?></td>-->
                                                        <td><?php echo $row['fs_name']; ?></td>
<!--                                                    <td>
                                                        <?php
//                                                            $pop = 'onclick="window.open(\'product-ledger-history.php?id=' .$row['batch_id'] . '\',\'_blank\',\'scrollbars=1,width=840,height=595\')"';
//                                                            echo "<a class='alert-link' " . $pop . " ></br>" .  $row['batch_no'] . "</a>";
                                                        ?>
                                                    </td>-->
                                                    
                                                    <td>
                                                        <?php 

                                                            //funding source
                        //                                                         '<b style="font-weight: 900;margin-left: 30px;">Funding Source : </b>' .$row['funding_source_name'] .

                                                            $pop = 'onclick="window.open(\'print_ledger_history?id=' . $row['batch_id'] . '\',\'_blank\',\'scrollbars=1,width=840,height=595\')"';
                                                            echo '<a style="text-decoration: underline;" class="alert-link" ' . $pop . ' >' . $row['batch_no'] . '</a>'?>
                                                    </td>
                                                    <td class="right"><?php echo $row['stakeholder_name'] ?></td>
                                                    <!--<td><?php echo $row['manufacturer']; ?></td>-->
                                                    <td class="editableSingle expiry id<?php echo $row['batch_id']; ?>"><?php echo date("d/m/Y", strtotime($row['batch_expiry'])); ?></td>
                                                    <td class="right"><?php echo number_format($row['BatchQty']); ?></td>
                                                    <!--<td class="right"><?php echo $row['UnitType'] ?></td>-->
                                                    <td class="right"><?php echo $row['unit_price'] ?></td>
                                                    <td class="right"><?php
                                                        //carton qty
                                                        if(!empty($row['qty_carton']))
                                                        {
                                                            $cartonQty = $row['BatchQty'] / $row['qty_carton'];
                                                        }
                                                        else{
                                                            $cartonQty = 0;
                                                        }
                                                        
                                                        echo (floor($cartonQty) != $cartonQty) ? number_format($cartonQty, 2) : number_format($cartonQty);
                                                        ?></td>
                                                    <td class="right"><?php echo (!empty($price)?number_format($price):'') ?></td>
                                                    <td id="batch<?php echo $row['batch_id']; ?>-status"class="badge badge-<?php echo ($row['status'] == 'Stacked') ? "danger" : "success"; ?>"> &nbsp; <?php echo $row['status']; ?></td>
                                                    <?php
//                                                        echo '<pre>';
//                                                        print_r($_SESSION);
//                                                        echo '</pre>';
//                                                        exit;
                                                    if ($_SESSION['role'] != 2) { ?>
                                                        <td class="span3"><input type="hidden" name="status" id="batch<?php echo $row['batch_id']; ?>_status" value="<?php echo $row['status']; ?>" />
                                                            <input type="hidden" name="batch_id" id="batch<?php echo $row['batch_id']; ?>_id" value="<?php echo $row['batch_id']; ?>" />
                                                            <?php
                                                            if ($row['status'] == 'Finished') {
                                                                echo '';
                                                            } else {
                                                                ?>
                                                            <button class="btn input-sm input-small <?php echo ($row['status'] == 'Stacked') ? "btn-success" : "btn-grey"; ?> btn-mini" onClick="makeIt(this.id)" id="batch<?php echo $row['batch_id']; ?>-makeit"> Make it <span id="batch<?php echo $row['batch_id']; ?>-button"> <?php echo ($row['status'] == 'Stacked') ? "Running" : "Stacked"; ?></span> </span> </button>
                                                                <?php
                                                                $var = base64_encode($row['itm_name'] . '|' . $row['batch_id'] . '|' . $row['batch_no'] . '|' . date("d/m/Y", strtotime($row['batch_expiry'])));
                                                                ?>
                                                                <!--<a class="btn btn-info input-sm" onClick="loadPlacementInfo('<?php echo $var; ?>');" data-target="#modal-ajax-placement-info" data-toggle="modal"> Placement Info</a>-->
                                                                <?php
                                                            }
                                                            ?></td>
                                                        
                                                        
                                                        <?php // if ($_SESSION['user_level'] < 3) { ?>
<!--                                                                <td class="text-center">
                                                                    <a data-v="0" data-batch-id="<?=$row['batch_id']?>"  class="dtl_<?=$row['batch_id']?> dtl_action dtl_<?=$row['batch_id']?>_0 btn btn-xs btn-default <?=($row['dtl']=='0')?" green ":"  "?>">Inprocess</a>
                                                                    <a data-v="1" data-batch-id="<?=$row['batch_id']?>"  class="dtl_<?=$row['batch_id']?> dtl_action dtl_<?=$row['batch_id']?>_1 btn btn-xs btn-default <?=($row['dtl']=='1')?" green ":"  "?>">Completed</a>
                                                                    <a data-v="2" data-batch-id="<?=$row['batch_id']?>"  class="dtl_<?=$row['batch_id']?> dtl_action dtl_<?=$row['batch_id']?>_2 btn btn-xs btn-default <?=($row['dtl']=='2')?" green ":"  "?>">NA</a>

                                                                </td>

                                                                <td class="text-center  ">

                                                                    <a data-v="0" data-batch-id="<?=$row['batch_id']?>"  class="phy_<?=$row['batch_id']?> phy_action phy_<?=$row['batch_id']?>_0 btn btn-xs btn-default <?=($row['phy_inspection']=='0')?" green ":"  "?>">Inprocess</a>
                                                                    <a data-v="1" data-batch-id="<?=$row['batch_id']?>"  class="phy_<?=$row['batch_id']?> phy_action phy_<?=$row['batch_id']?>_1 btn btn-xs btn-default <?=($row['phy_inspection']=='1')?" green ":"  "?>">Completed</a>
                                                                    <a data-v="2" data-batch-id="<?=$row['batch_id']?>"  class="phy_<?=$row['batch_id']?> phy_action phy_<?=$row['batch_id']?>_2 btn btn-xs btn-default <?=($row['phy_inspection']=='2')?" green ":"  "?>">NA</a>

                                                                </td>-->

                                                            <?php // } ?>
                                                    <?php } ?>
                                                </tr>
                                                <?php
                                                $i++;
                                            }
                                        }
                                        ?>
                                        <!-- // Table row END -->

                                    </tbody>
                                    
                                </table> 
                            </div>

                            <!-- // Table END -->
                            <?php
                        } else {
                            echo "<hr><h5>No data found!</h5>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
