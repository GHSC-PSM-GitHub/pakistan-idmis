<style>
    h2 {
        margin-top:18px !important;
    }
</style>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title">Stock On Hand Report</h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Reports</a></li>
                        <li class="breadcrumb-item active">SOH</li>
                    </ol>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                        <div class="card-body">
            
            </div>
                    
                    <div class="card-body">
                        <table  id="datatable-buttons"  class="table table-striped table-bordered dt-responsive nowrap">
                            <thead>
                            <tr>
                                <td>#</td>
                                <td>Center</td>
                                <td>Generic Name</td>
                                <td>Item Name</td>
                                <td>Batch Number</td>
                                <td>Batch Expiry</td>
                                <td>Quantity Available</td>
                            </tr>
                            </thead>
                            <tbody>
                        <?php
                        $c=1;
                        foreach($list as $k=> $row){
                            echo '<tr>';
                            echo '<td>'.$c++.'</td>';
                            echo '<td>'.$row['warehouse_name'].'</td>';
                            echo '<td>'.$row['generic_name'].'</td>';
                            echo '<td>'.$row['product_name'].'</td>';
                            echo '<td><a target="_blank" href="batch_history/'.$row['batch_id'].'">'.$row['batch_number'].'</a></td>';
                            echo '<td>'.$row['batch_expiry'].'</td>';
                            echo '<td>'.$row['quantity'].'</td>';
                            echo '</tr>';
                        }
                        ?>
                            </tbody>
                        </table>
                    </div>
        </div>
        </div>
        </div>
        </div>
        </div>