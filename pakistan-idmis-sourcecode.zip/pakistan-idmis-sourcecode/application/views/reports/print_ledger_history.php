<?php
$count = 1;
$balance = 0;
//default stakeholder
?>
<!-- END HEAD -->
<div class="wrapper">
    <div class="container-fluid">
    <div class="page-container">
        <div class="page-content-wrapper">
            <div class="page-content">

                <?php
                
                $batch_id = $_GET['id'];
                ?>
                <div class="widget" >
                    <div class="widget-head">
                        <h4 class="heading">Detailed Information of Batch</h4></div></div>
                <table class='table table-bordered table-condensed'>
                    <?php
                        $rowno = 0;
                        foreach ($fbatchinfo as $row) { 
                            if($rowno < 1 ) { 
                                $rowno++;
                                ?>
                        <tr>
                            <th>Batch Number</th><td><?php echo $row['batch_no'] ?></td> <br></tr>
                        <tr><th>Batch Expiry</th><td><?php echo $row['batch_expiry'] ?></td></tr>
                        <tr><th>Item Name</th><td><?php echo $row['itm_name'] ?></td></tr>

                        <tr><th>Quantity</th><td class="bold"><?php echo number_format($row['quantity']) ?></td></tr>
                        <tr><th>Current Status</th><td class="<?=(($row['status']=='Running')?'green bold':'bold')?>"><?php echo $row['status'] ?></td></tr>
                         <tr> <th>Funding Source</th><td><?php echo $row['funding_source_name'] ?></td></tr>
                        <!--<tr> <th>Manufacturer</th><td><?php echo $row['manuf_name'] ?></td></tr>-->

<!--                        <tr>
                            <th>Phy Inspection Status</th>
                            <td><?php
                                if ($row['phy_inspection'] == '2') {
                                    echo 'N/A';
                                } else if ($row['phy_inspection'] == '0') {
                                    echo 'In process';
                                } else if ($row['phy_inspection'] == '1') {
                                    echo 'Completed';
                                } else {
                                    echo '';
                                }
                                ?>
                            </td>
                        </tr>-->
                        <!--<tr>--> 
                            <!--<th>DTL Status (Drug Testing Lab)</th>-->
<!--                            <td><?php
                                if ($row['dtl'] == '1') {
                                    echo 'Not Done';
                                } else if ($row['dtl'] == '2') {
                                    echo 'Completed';
                                } else if ($row['dtl'] == '3') {
                                    echo 'In Progress';
                                } else  if ($row['dtl'] == '4') {
                                    echo 'Not Required';
                                }else {
                                    echo '';
                                }
                                ?>
                            </td> -->
                        <!--</tr>-->
<!--                        <tr> 
                            <th>District Plan [Received / Not Received]</th>
                            <td><?php
                                if ($row['dist_plan'] == '2') {
                                    echo 'N/A';
                                } else if ($row['dist_plan'] == '0') {
                                    echo 'Not Received';
                                } else if ($row['dist_plan'] == '1') {
                                    echo 'Received';
                                } else {
                                    echo '';
                                }
                                ?>
                            </td>
                        </tr>-->

                        </tr>
                        <?php } 
                        }
                    ?>
                </table><?php
                if ($sbatchinfo) {
                    ?>
                    <div class="widget" >
                        <div class="widget-head">
                            <h4 class="heading">Batch Trail</h4></div></div>
                    <div style="overflow-x:auto;">
                    <table width="100%" cellpadding="0" cellspacing="0" id="myTable" class="table table-bordered table-condensed">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Batch No</th>
                                <th>Voucher</th>
                                <th>Reference</th>
                                <th>Created On</th>
                                <th>Transaction Date</th>
                                <th>Quantity</th>
                                <th>Balance</th>
<!--                                <th>Status</th>-->
                                <th>From Warehouse</th>
                                <th>To Warehouse</th>
                                <th>Stakeholder</th>
                                <!--<th>Province</th>-->
                                <th>Transaction Type</th>

                            </tr>

                        </thead>
                        <?php
                        $numResults = count($sbatchinfo);
                        $counter = 0;
                        $c=1;
                        foreach ($sbatchinfo as $row) { 
                            ?>
                            <tbody>
                                <tr>
                                    <td><?php echo $c++?></td>
                                    <td><?php echo $row['batch_no'] ?></td>
                                    <?php
                                        $file_name = 'printAdjustment';
                                        if($row['status_id']==3)$file_name = 'print_receive';
                                        elseif($row['status_id']==4)$file_name = 'printIssue';
                                            
                                    ?>
                                    <!--<td><a  onclick="window.open('<?=$file_name?>?id=<?php echo $row['pk_id']; ?>&trantypeid=<?php echo $row['status_id']; ?>', '_blank', 'scrollbars=1,width=842,height=595');" href="javascript:void(0);"><?php echo $row['tran_no'] ?></a></td>-->
                                    <td><?php echo $row['tran_no'] ?></td>
                                    <td><?php echo $row['tran_ref'] ?></td>
                                    <td><?php echo date('Y-M-d',strtotime($row['created_on'])) ?></td>
                                    <td><?php echo date('Y-M-d',strtotime($row['tran_date']))  ?></td>
                                    <td align="right"><?php echo number_format($row['quantity']); ?></td>
                                    <td align="right" class="bold"><?php
                                        if ($count == 1) {
                                            echo number_format($row['quantity']);
                                            $balance = $row['quantity'];
                                        } else {
                                            $balance = $row['quantity'] + $balance;
                                            echo number_format($balance);
                                        }
                                        ?></td>
                                    <!--<td><?php
                                        if (++$counter == $numResults) {
                                            echo $row['status'];
                                        }
                                        ?></td>-->
                                    <!--<td><?php echo $row['From_warehouse'] ?></td>-->
                                    <td><?php echo $row['funding_source_name'] ?></td>
                                    <td><?php echo $row['to_warehouse'] ?></td>
                                    <td><?php echo $row['stkname'] ?></td>
                                    <!--<td><?php echo $row['province_name'] ?></td>-->
                                    <!--<td><?php echo ($row['adjustment_type']<=4)?'Issuance':'Adjustment' ?></td>-->
                                    
                                    <?php if($row['process_status'] == '9') { ?>
                                     <td bgcolor="#53e079">Receive</td>
                                    <?php } elseif($row['process_status'] == '99') { ?>
                                      <td bgcolor="#1f8eed">Adjustment</td>
                                    <?php } else {  ?>
                                      <td bgcolor="#f04d83">Issuance</td>
                                    <?php } ?>
                                    <!--<td><?php if($row['process_status'] == '9') {echo 'Receive';} else {echo 'Issuance';} ?></td>-->
                                </tr>
                                <?php $count++; ?>
                            </tbody>
                        <?php } ?>
                    </table>
                    </div>
                    <?php
                } else
                    echo 'No data found';
                ?>
            </div>
        </div>

    </div>
    </div>
</div>