<style>
    .sprintbuttonstyle{
      background-color: #4CAF50;  
      border: none;
      color: white;
      padding: 10px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 16px;
      margin: 4px 2px;
      cursor: pointer;
      border-radius: 4px;
    }
/*    h2 {
        margin-top:18px !important;
    }
        
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
    }
  
*{font-family:"Open Sans",sans-serif;}
b{font-size:12px;}
h3{font-size:13px;}
#report_type{
font-size:12px;
font-family: arial;}
#content_print
{
	width:90%;
	margin-left:50px;
        margin-right:50px;
}*/
table#myTable{
	border:1px solid #E5E5E5;
	font-size:9pt;
	width:100%;
}
table, table#myTable tr td{
	border-collapse: collapse;
	border:1px solid #E5E5E5;
	font-size:12px;
}
table, table#myTable tr th{
	border:1px solid #E5E5E5;
	border-collapse: collapse;
	font-size:12px;
}
/*
@media print
{    
    #noprint, #noprint *
    {
        display: none !important;
    }
}*/
</style>
<?php
/**
 * print_batch_management
 * @package im
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
//includ AllClasses
//include("../includes/classes/AllClasses.php");
////includ header
//include(PUBLIC_PATH . "html/header.php");
$title = "Batch Management";
$print = 1;
$print = true;
//echo '<pre>';print_r($_SESSION);exit;
//check type
if (isset($_REQUEST['type']) && $_REQUEST['type'] == 1) {
    
    ?>

    <div id="content_print">
        <style type="text/css" media="print">
            @media print
            {    
                #printButt
                {
                    display: none !important;
                }
            }
            .sprintbuttonstyle{
                background-color: #4CAF50; /* Green */
                border: none;
                color: white;
                padding: 10px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                margin: 4px 2px;
                cursor: pointer;
                border-radius: 4px;
              }
        </style>
        <?php
        $rptName = 'Batch Management Summary';
        //include header
//        include('report_header.php');
//        include('export_options.php');
        ?>
               <div style="line-height:1;">
    <div id="logoLeft" style="float:left; width:107px; text-align:right;">
    <!--<img src="<?php echo PUBLIC_URL;?>images/gop.png" />-->
        <img id="pics" style="border-radius: 50%;" src="<?php echo base_url('assets/images/lmis.jpg')?>" alt="" height="100">
    </div>
    <div id="report_type" style="float:left; width:100%; text-align:center;">
        <?php 
        $stkid = '';
        if ($stkid==1 && $provid==1 && $lvl==3) 
        {
            ?>
                <span style="line-height:20px"><b>POPULATION WELFARE DEPARTMENT</b></span><br/>
                <span style="line-height:20px"><b>GOVERNMENT OF PUNJAB</b></span><br/>
        <?php }
        elseif ($stkid==145) 
        {
            ?>
                <span style="line-height:20px"><b>PRIMARY & SECONDARY HEALTHCARE DEPARTMENT</b></span><br/>
                <span style="line-height:20px"><b>GOVERNMENT OF PUNJAB</b></span><br/>
                <span style="line-height:20px"><b>MEDICAL STORE DEPO LAHORE</b></span><br/>
        <?php 
        }elseif ($stkid==1) 
        {
            ?>
                <span style="line-height:20px"><b>GOVERNMENT OF PAKISTAN</b></span><br/>
                <span style="line-height:20px"><b>CMU</b></span><br/>
                <span style="line-height:20px"><b>REGULATIONS & COORDINATION</b></span><br/>
                <span style="line-height:20px">DIRECTORATE OF CENTRAL WAREHOUSE & SUPPLIES</span><br/>
        <?php 
        } 
        else {
            ?>
                <span style="line-height:20px"><b>GOVERNMENT OF PAKISTAN</b></span><br/>
                <span style="line-height:20px"><b>CMU</b></span><br/>
                <span style="line-height:20px"><b>REGULATIONS & COORDINATION</b></span><br/>
                <span style="line-height:20px">DIRECTORATE OF CENTRAL WAREHOUSE & SUPPLIES</span><br/>
                <!--<span style="line-height:20px"><?php // echo $logo1[1]?></span><br/>-->
        <?php 
        
        }?>
        <span style="line-height:15px"><b>Store: </b><?php foreach($whName as $whname)  echo $whname['wh_name']; ?></span>
        <hr style="margin:3px 10px;" />
        <p><b><?php echo $rptName;?> as on: <?php echo date('d-M-Y');?></b>
        </p>
    </div>
</div>
        <table id="myTable" class="table-condensed">
            <thead>
                <tr>
                    <th>S. No.</th>
                    <th>Product</th>
                    <th>Strength</th>
                    <th>Quantity</th>
                    <th>Unit</th>
                    <!--<th>Cartons</th>-->
                    <th>Unit Price</th>
                    <th>Total Price (PKR)</th>
                </tr>
            </thead>
            <tbody>
                <?php
                //check num
                if ($result) {
                    $i = 1;
                    $totalQty = $totalCartons = '';
                    $grand_total_price = 0;
                    //fetch data from qryRes
                    foreach ($result as $row) {
                        //total qty
                        $totalQty += abs($row['Vials']);
                        //total cartons
                        if(!empty($row['qty_carton']))
                        {
                            $totalCartons += abs($row['Vials']) / $row['qty_carton'];
                        }
                        else{
                            $totalCartons += 0;
                        }
                        $t_price = 0;
                        if($row['unit_price'] > 0 && $row['Vials'] >  0){
                            $t_price = $row['Vials'] * $row['unit_price'];
                        }
                        $grand_total_price += $t_price;
                        ?>
                        <!-- Table row -->
                        <tr>
                            <td style="text-align:center;"><?php echo $i; ?></td>
                            <td><?php echo $row['itm_name']; ?></td>
                            <td><?php echo $row['strength']; ?></td>
                            <td style="text-align:right;"><?php echo number_format($row['Vials']); ?></td>
                            <td style="text-align:right;"><?php echo $row['unit']; ?></td>
                            <!--<td style="text-align:right;">-->
                            <?php
//                            if(!empty($row['qty_carton']))
//                            {
//                                echo number_format($row['Vials'] / $row['qty_carton']); 
//                            }
//                            else{
//                                echo '0';
//                            }
                            ?>
                            <!--</td>-->
                            <td style="text-align:right;"><?php echo number_format($row['unit_price'],2); ?></td>
                            <td style="text-align:right;"><?php echo number_format($t_price); ?></td>
                        </tr>
            <?php $i++;
        }
    } ?>
                <!-- // Table row END -->
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="3" style="text-align:right;">Total</th>
                    <th style="text-align:right;"><?php echo number_format($totalQty); ?></th>
                    <th>&nbsp;</th>
                    <!--<th style="text-align:right;"><?php echo number_format($totalCartons); ?></th>-->
                    <th>&nbsp;</th>
                    <th style="text-align:right;"><?php echo number_format($grand_total_price); ?></th>
                </tr>
            </tfoot>
        </table>
        <div style="float:right; margin-top:10px;" id="printButt">
            <!--<input type="button" name="print" value="Print" class="btn btn-warning" onclick="javascript:printCont();" />-->
            <button type="button" class="btn btn-warning sprintbuttonstyle" onclick="javascript:printCont();"> Print </button>
        </div>

    </div>

    <?php
} else {
    //check product
    if (isset($_REQUEST['product']) && !empty($_REQUEST['product'])) {
        //get product
        $product = trim($_REQUEST['product']);
    }
    //check status
    if (isset($_REQUEST['status']) && !empty($_REQUEST['status'])) {
        //get status
        $status = trim($_REQUEST['status']);
    }
    //check batch_no
    if (isset($_REQUEST['batch_no']) && !empty($_REQUEST['batch_no'])) {
        //get batch_no
        $batch_no = trim($_REQUEST['batch_no']);
    }
    //check ref_no
    if (isset($_REQUEST['ref_no']) && !empty($_REQUEST['ref_no'])) {
        //get ref_no
        $ref_no = trim($_REQUEST['ref_no']);
    }
    //check funding_source
    if (isset($_REQUEST['funding_source']) && !empty($_REQUEST['funding_source'])) {
        //get funding_source
        $funding_source = trim($_REQUEST['funding_source']);
        $objStockBatch->funding_source = $funding_source;
    }

    $result = $objStockBatch->search($product, $batch_no, $ref_no, $status);
    ?>
    <div id="content_print">
        <style type="text/css" media="print">
            @media print
            {    
                #printButt
                {
                    display: none !important;
                }
            }
        </style>
        <?php
        $rptName = 'Batch Management';
        include('report_header.php');
        ?>
        <div>
            <table id="myTable" class="table-condensed">
                <thead>
                    <tr>
                        <th>S. No.</th>
                        <th>Product</th>
                        <th>Batch No.</th>
                        <th>Expiry Date</th>
                        <th>Quantity</th>
                        <th>Unit</th>
                        <!--<th>Cartons</th>-->
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (mysql_num_rows($result) > 0) {
                        $i = 1;
                        $totalCartons = $totalQty = '';
                        while ($row = mysql_fetch_object($result)) {
                            $totalQty += abs($row->BatchQty);
                            $totalCartons += abs($row->BatchQty) / $row->qty_carton;
                            ?>
                            <!-- Table row -->
                            <tr class="gradeX">
                                <td style="text-align:center;"><?php echo $i; ?></td>
                                <td style="padding-left:5px;"><?php echo $row->itm_name; ?></td>
                                <td><?php echo $row->batch_no; ?></td>
                                <td style="text-align:center;"><?php echo date("d/m/y", strtotime($row->batch_expiry)); ?></td>
                                <td style="text-align:right;"><?php echo number_format($row->BatchQty); ?></td>
                                <td style="text-align:right;"><?php echo $row->unit; ?></td>
                                <!--<td style="text-align:right;"><?php echo number_format($row->BatchQty / $row->qty_carton); ?></td>-->
                                <td id="batch<?php echo $row->batch_id; ?>-status" style="padding-left:5px;"><?php echo $row->status; ?></td>
                            </tr>
                            <?php
                            $i++;
                        }
                    }
                    ?>
                    <!-- // Table row END -->
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="4" style="text-align:right;">Total</th>
                        <th style="text-align:right;"><?php echo number_format($totalQty); ?></th>
                        <th>&nbsp;</th>
                        <!--<th style="text-align:right;"><?php echo number_format($totalCartons); ?></th>-->
                        <th>&nbsp;</th>
                    </tr>
                </tfoot>
            </table>
            <div style="float:right;" id="printButt">
                <input type="button" name="print" value="Print" class="btn btn-warning sprintbuttonstyle" onclick="javascript:printCont();" />
            </div>
        </div>
<iframe id="txtArea1" style="display:none"></iframe>
    </div>
    <?php
}
?>
<script src="<?php echo ASSETS; ?>global/plugins/jquery-1.11.0.min.js" type="text/javascript"></script>
<script language="javascript">
                $(function() {
                    printCont();
                })
                function printCont()
                {
                    window.print();
                }
                
</script>