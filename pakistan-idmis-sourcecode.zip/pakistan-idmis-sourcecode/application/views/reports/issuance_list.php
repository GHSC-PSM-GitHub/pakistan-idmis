<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons"> 
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                    <!-- // Heading END -->
                    <h3>Issuance Report</h3>
                    <div class="innerLR">
                        <br>


                        <div id="divToPrint">
                            <form action="" >
                                <div class="card">
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="col-md-3">
                                                <label for="date_from">Date From</label>
                                                <input name="date_from" id="date_from" type="date" class="form-control" value="<?=(!empty($date_from)?$date_from:'')?>">

                                            </div>
                                            <div class="col-md-3">
                                                <label for="date_from">Date To</label>

                                                <input name="date_to" id="date_to" type="date" class="form-control" value="<?=(!empty($date_to)?$date_to:'')?>">
                                            </div>
                                            <div class="col-md-3">
                                                <label for="btn_submit"></label>
                                                <input name="btn_submit" id="btn_submit" type="submit" value="Search" class="form-control btn btn-primary">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <table  id="datatable-buttons"  class="table table-striped table-bordered table-condensed dt-responsive nowrap">
                                <thead>
                                    <tr>
                                        <td>#</td>
                                        <td>Issuance Number</td>
                                        <td>From</td>
                                        <td>To</td>
                                        <td>Issuance Date</td>
                                        <td>Action</td>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php
                                    $c = 1;
                                    if (!empty($list))
                                        foreach ($list as $k => $row) {
                                            echo '<tr>';
                                            echo '<td>' . $c++ . '</td>';
                                            echo '<td><a target="_blank" href="transaction_detail/' . $row['pk_id'] . '">I-' . sprintf('%04d', $row['pk_id']) . '</a></td>';
                                            echo '<td>' . $row['wh_from'] . '</td>';
                                            echo '<td>' . ((!empty($row['issuance_to']) && $row['issuance_to'] == 'patients') ? $row['full_name'] . '-' . $row['nic_no'] : $row['wh_to']) . '</td>';
                                            echo '<td>' . $row['transaction_date'] . '</td>';
                                             echo '<td>';
                                            if($this->session->userdata('id')==$row['created_by']){
                                                echo '<a class="btn btn-secondary btn-sm" href="'.base_url('Reports/update_data/'.$row['pk_id']).'"> Update</a>';
                                            }
                                             echo '</td>';
                                            echo '</tr>';
                                        }
                                    ?>

                                </tbody>
                            </table>
                        </div>


                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

