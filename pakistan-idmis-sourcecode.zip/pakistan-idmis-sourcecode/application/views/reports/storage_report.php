<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
}
    
</style>
<?php 
$flag = false;
//check product
if (isset($_REQUEST['batch_mang_product']) && !empty($_REQUEST['batch_mang_product'])) {
    //get product
    $batch_mang_product = trim($_REQUEST['batch_mang_product']);
    //set product
//                $qryString .= '&product=' . $product;
    $flag = true;
}
//check ref number
if (isset($_REQUEST['ref_no']) && !empty($_REQUEST['ref_no'])) {
    //get ref number
    $ref_no = trim($_REQUEST['ref_no']);
    //set ref number
//                $qryString .= '&ref_no=' . $ref_no;
}
//check funding_source
if (isset($_REQUEST['storage']) && !empty($_REQUEST['storage'])) {
    //get funding_source
    $storage_type = $_REQUEST['storage'];
    //set funding_source
//                $objStockBatch->funding_source = $funding_source;
//                $qryString .= '&funding_source=' . $funding_source;
}
?>
<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Storage Report</h3>
                         
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                     <div class="innerLR">
                         
                         <form method="POST" name="dc_searchs" action="storage_report" >
                            <!-- Row -->
                  <div class="col-md-12">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <div class="form-group row ">
                                <div class="col-md-12">
                                    <div class="form-group row ">
                                        
                                        <div class="col-md-3">
                                            <div class="control-group">
                                                <label class="example-text-input" for="start_date"  >Start Date(MM/DD/YYYY)  </label>
                                                <div class="controls">
                                                    <input type="text" class="form-control" name="start_date" id="start_date"  value="<?php if(isset($form['start_date']) && !empty($form['start_date'])) {echo $form['start_date'];} else{ echo date("d/m/Y");} ?>" >

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="control-group">
                                                <label class="example-text-input" for="end_date"  >End Date(MM/DD/YYYY)  </label>
                                                <div class="controls">
                                                    <input type="text" class="form-control" name="end_date" id="end_date" value="<?php if(isset($form['end_date']) && !empty($form['end_date'])) {echo $form['end_date'];} else{ echo date("d/m/Y");} ?>" >

                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-3" id="show_receive_from_suppliers" >
                                            <label class="example-text-input" for="product_category"  >Product Category </label>
                                            <div class="controls">
                                                <select class="select2me input-medium"  name="product_category" id="product_category" style="width:100%;padding:10%;">
                                                    <option value="">Select</option>
                                                    <?php

                                                    foreach ($product_cat as $row) {
                                                        ?>
                                                        <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($_REQUEST['product_category']) && $_REQUEST['product_category'] == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['name'] ?></option>
                                                        <?php
                                                    }
                                                    ?>

                                                </select>  
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-3" id="show_receive_from_suppliers" >
                                            <label class="example-text-input" for="batch_mang_product"  >Product </label>
                                            <div class="controls">
                                                <select class="select2me input-medium"  name="batch_mang_product" id="batch_mang_products" style="width:100%;padding:10%;">
                                                    <option value="">Select</option>
                                                    <?php

                                                    foreach ($product as $row) {
                                                        ?>
                                                        <option value="<?php echo $row['itm_id'] ?>" <?php if (isset($_REQUEST['batch_mang_product']) && $_REQUEST['batch_mang_product'] == $row['itm_id']) echo "selected='selected'"; ?>><?php echo $row['itm_name'] ?></option>
                                                        <?php
                                                    }
                                                    ?>

                                                </select>  
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="form-group row">
                                        <div class="col-md-3">
                                            <label class="control-label" for="storage"> Storage </label>
                                            <div class="controls">
                                                <select name="storage" id="storage" class="select2me input-medium"  style="width:100%;padding:10%;"  >
                                                    <option value="">Select</option>
                                                    <?php
                                                    if ($storage) {
                                                        //fetch result
                                                        foreach ($storage as $row) {
                                                            //populate receive_from combo
    //                                                                if($_SESSION['user_stakeholder']=='145'){
    //                                                                    if($row->wh_id != '33677' && $row->wh_id != '33678' && $row->wh_id != '33680' && $row->wh_id != '20641'  && $row->wh_id != '9079') 
    //                                                                        continue;
    //                                                                }
                                                            ?>
                                                    <option value="<?php echo $row['pk_id']; ?>" <?php if (isset($storage_type) && $storage_type == $row['pk_id']) { ?> selected="" <?php } else if(isset ($form['storage']) &&  $form['storage'] == $row['pk_id']) { ?> selected="" <?php } ?>> <?php echo $row['name']; ?> </option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="control-group">
                                            <div class="input-group input-medium" style="margin-top: 21px;">
                                                <div class="controls">
                                                <button type="submit" class="btn btn-primary" name="submit" value="Search"> Search </button>
                                                </div>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                        
                                    </div>
                                <!--</div>-->
                            </div>
                            <div class="col-md-6" id="vaccine-detail" <?php if ($flag == true) { ?> style="display:block;" <?php } else { ?>style="display:none;" <?php } ?>> 
                                <!-- Widget -->
                                <?php
//                                $result = '';
//                                if (isset($product) && !empty($product)) {
//                                    $result = $objStockBatch->find_by_item($product);
//                                    (int) $RunningVials = $result->RunningQty;
//                                    (int) $StackedVials = $result->StackedQty;
//                                    (int) $FinishedVials = $result->FinishedQty;
//                                    (int) $total = $RunningVials + $StackedVials + $FinishedVials;
//                                } else {
//                                    $RunningVials = 0;
//                                    $StackedVials = 0;
//                                    $FinishedVials = 0;
//                                    $total = 0;
//                                }
                                ?>
                                <div class="widget row-fluid" data-toggle="collapse-widget"  id="batch_detail_ajax">
                                    <?php
//                                    if ($result) {
                                        ?>
                                        <!-- Widget heading -->
<!--                                        <div class="widget-head">
                                            <h4 class="heading"><?php echo $result->itm_name; ?></h4>
                                        </div>
                                         // Widget heading END 

                                        <div class="widget-body">
                                            <div class="col-md-4">
                                                <p><b>Batch Status</b></p>
                                                <p>Running</p>
                                                <p>Stacked</p>
                                                <p>Finished</p>
                                                <p><b>Total</b></p>
                                            </div>
                                            <div class="col-md-4 center">
                                                <p style="text-align:right"><b>No of Batches</b></p>
                                                <p style="text-align:right" id="running"><?php echo!empty($result->running) ? $result->running : 0; ?></p>
                                                <p style="text-align:right" id="stacked"><?php echo!empty($result->stacked) ? $result->stacked : 0; ?></p>
                                                <p style="text-align:right" id="finished"><?php echo!empty($result->finished) ? $result->finished : 0; ?></p>
                                                <p style="text-align:right" id="total"><b><?php echo $result->running + $result->stacked + $result->finished; ?></b></p>
                                            </div>
                                            <div class="col-md-4 center" >
                                                <p style="text-align:right"><b>Quantity (<?php echo $result->itm_type; ?>)</b></p>
                                                <p style="text-align:right"><?php echo number_format($result->RunningQty); ?></p>
                                                <p style="text-align:right"><?php echo number_format($result->StackedQty); ?></p>
                                                <p style="text-align:right"><?php echo number_format($result->FinishedQty); ?></p>
                                                <p style="text-align:right" id="total"><b><?php echo number_format($result->RunningQty + $result->StackedQty + $result->FinishedQty); ?></b></p>
                                            </div>
                                        </div>
                                        <div style="clear:both;"></div>-->
                                        <?php
//                                    }
                                    ?>
                                </div>
                                <!-- Widget --> 
                            </div>
                        </div>
                    </div>
                  </div>
                
            </form>
                    </div>
                        <br>
                        <?php
                        if (isset($storageinfo) && !empty($storageinfo)) {
                            ?>

                            <div id="divToPrint">
                                <table class="table table-striped table-bordered table-condensed dt-responsive nowrap" id="datatable-buttons">
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th width="60">Sr. No.</th>
                                            <th>Product</th>
                                            <th>Strength</th>
                                            <th>Storage</th>
                                            <th>Receive Quantity</th>
                                            <th>Issue Quantity</th>
                                            <th>Remaining Quantity</th>
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 

                                    <!-- Table body -->
                                    <tbody>
                                        <?php
                                        //check if result rxists
                                        if ($storageinfo) {
                                            $i = 1;
                                            //fetch result
//                                            while ($row = mysql_fetch_object($batchsearch)) {
                                               foreach ($storageinfo as $row) { ?>
                                                <!-- Table row -->
                                                <tr class="gradeX">
                                                    <td class="center"><?php echo $i; ?></td>
                                                    <td><?php echo $row['itm_name']; ?></td>
                                                    <td><?php echo $row['strength']; ?></td>
                                                    <td><?php echo $row['storage']; ?></td>
                                                    <td style="text-align:right;"><?php echo $row['stock_receive']; ?></td>
                                                    <td style="text-align:right;"><?php echo abs($row['issue_quantity']); ?></td>
                                                    <td style="text-align:right;"><?php echo abs($row['stock_receive']) - abs($row['issue_quantity']); ?></td>
                                                </tr>
                                                <?php
                                                $i++;
                                            }
                                        }
                                        ?>
                                        <!-- // Table row END -->

                                    </tbody>
                                    
                                </table> 
                            </div>

                            <!-- // Table END -->
                            <?php
                        } else {
                            echo "<hr><h5>No data found!</h5>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>