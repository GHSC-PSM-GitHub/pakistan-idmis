<style>
    h2 {
        margin-top:18px !important;
    }

    .datepicker.dropdown-menu {
        z-index: 9999 !important;
    }


    *{font-family:"Open Sans",sans-serif;}
    b{font-size:12px;}
    h3{font-size:13px;}
    #report_type{
        font-size:12px;
        font-family: arial;}
    #content_print
    {
        width:90%;
        margin-left:10px;
        margin-right:10px;
    }
    table#myTable{
        border:1px solid #E5E5E5;
        font-size:9pt;
        width:100%;
    }
    table, table#myTable tr td{
        border-collapse: collapse;
        border:1px solid #E5E5E5;
        font-size:12px;
    }
    table, table#myTable tr th{
        border:1px solid #E5E5E5;
        border-collapse: collapse;
        font-size:12px;
    }
    @media print
    {    
        #noprint, #noprint *
        {
            display: none !important;
        }
    }
</style>
<?php
$from_id = '';
$TranRef = '';
if (isset($form['start_date']) && !empty($form['start_date'])) {
    $date1 = str_replace('/', '-', $form['start_date']);
    $startdate = date('Y-m-d', strtotime($date1));
}
if (isset($form['end_date']) && !empty($form['end_date'])) {
    $date2 = str_replace('/', '-', $form['end_date']);
    $enddate = date('Y-m-d', strtotime($date2));
}
?>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title">Stock Ledger Report</h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Reports</a></li>
                        <li class="breadcrumb-item active">Stock Ledger</li>
                    </ol>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body" id='noprint'>
                        <form method="post" id="addwarehouse" name="addwarehouse" action="<?php echo base_url("reports/stock_ledger"); ?>">
                            <div class="form-group row" > 

                                <div class="col-md-3">
                                    <div class="control-group">
                                        <label class="example-text-input" for="start_date"  >Start Date(MM/DD/YYYY)  </label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="start_date" id="start_date"  value="<?php if (isset($form['start_date']) && !empty($form['start_date'])) {
    echo $form['start_date'];
} else {
    echo date("d/m/Y");
} ?>" >

                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="control-group">
                                        <label class="example-text-input" for="end_date"  >End Date(MM/DD/YYYY)  </label>
                                        <div class="controls">
                                            <input type="text" class="form-control" name="end_date" id="end_date" value="<?php if (isset($form['end_date']) && !empty($form['end_date'])) {
    echo $form['end_date'];
} else {
    echo date("d/m/Y");
} ?>" >

                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label class="example-text-input" required >Stakeholder </label>
                                    <div class="controls">
                                        <select class="select2me input-medium" name="stakeholder" id="stakeholder"  style="width:100%;padding:10%;">
                                            <option value="">Select</option>
                                            <?php
                                            foreach ($stakeholder as $row) {
                                                ?>
                                                <option value="<?php echo $row['stkid'] ?>" <?php if (isset($form['stakeholder']) && $form['stakeholder'] == $row['stkid']) echo "selected='selected'"; ?>><?php echo $row['stkname'] ?></option>
    <?php
}
?>
                                        </select>  
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label class="example-text-input" required >Product<span style="color: red">*</span> </label>
                                    <div class="controls">
                                        <select class="select2me input-medium" name="product" id="ledger_product" required style="width:100%;padding:10%;">
                                            <!--<option value="">Select</option>-->
                                            <?php
//                                                            foreach ($product as $row) {
                                            ?>
                                                <!--<option id="<?php // echo $row['itm_id'].'_'.$row['product_type'];  ?>" value="<?php echo $row['itm_id'] ?>" <?php if (isset($item_id) && $item_id == $row['itm_id']) echo "selected='selected'";
                                            else if (isset($product_id) && $product_id == $row['itm_id']) echo "selected='selected'"; ?>><?php echo $row['itm_name'] ?></option>-->
<?php
//                                                            }
?>
                                        </select>  
                                    </div>
                                </div>


                            </div>

                            <div class="form-group row" >
                                <!--                                                <div class="col-md-3" id="show_batch" style="display:none;">
                                                                                    <div class="control-group">
                                                                                        <label class="example-text-input" for="batch" >Batch<span style="color: red">*</span> </label>
                                                                                        <div class="controls">
                                                                                            <select class="select2me input-medium" name="batch" id="issue_batch" style="width:100%;padding:10%;">
                                                                                                <option value="">Select</option>-->
<?php // if(isset($form['batch']) && !empty($form['batch'])) { ?>
                                                                                                <!--<option value="<?php // echo $form['batch']  ?>" selected=""><?php // echo $form['batch']  ?></option>-->
<?php // }  ?>
                                <!--                                                            </select>                                                        
                                                                                        </div>
                                                                                    </div>
                                                                                </div>-->
                                <div class="col-md-3">
                                    <label class="control-label" for="source_type"> Funding Source </label>
                                    <div class="controls">
                                        <select name="source_type" id="source_type"  class="select2me input-medium"  style="width:100%;padding:10%;">
                                            <option value="">Select</option>
                                            <?php
                                            if ($funding_source) {
                                                //fetch result
                                                foreach ($funding_source as $row) {
                                                    //populate receive_from combo
                                                    //                                                                if($_SESSION['user_stakeholder']=='145'){
                                                    //                                                                    if($row->wh_id != '33677' && $row->wh_id != '33678' && $row->wh_id != '33680' && $row->wh_id != '20641'  && $row->wh_id != '9079') 
                                                    //                                                                        continue;
                                                    //                                                                }
                                                    ?>
                                                    <option value="<?php echo $row['stkid']; ?>" <?php if (isset($form['source_type']) && $form['source_type'] == $row['stkid']) { ?> selected="" <?php } ?>> <?php echo $row['stkname']; ?> </option>
        <?php
    }
}
?>
                                        </select>
                                    </div>
                                </div>

                                <!--                                                <div class="col-md-3">
                                                                                    <div class="control-group">
                                                                                        <label class="example-text-input" for="contact_no"  >Contact </label>
                                                                                        <div class="controls">
                                                                                            <input type="text" name="contact_no" readonly id="contact_no" class="form-control"  <?php if (isset($master_id)) echo 'readonly="true"' ?> 
<?php
//                                                            if (isset($refernce_number)) {
//                                                                echo 'value="' . $refernce_number . '"';
//                                                            }
?>
                                
                                                                                                   >
                                
                                                                                        </div>
                                                                                    </div>
                                                                                </div>-->

                            </div>

                            <div class="form-group row" >
                                <div class="col-md-11">
                                </div>
                                <div class="col-md-1">
                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
//                                                    if (isset($result))
//                                                        echo 'value="edit"';
?>>
                                <?php echo 'Search'; ?> </button>
                                    <!--                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                                                            Reset
                                                                                        </button>-->
                                </div> 
<?php // if (isset($result)) {
?>
                                    <!--<input type="hidden" id="wh_id" name="wh_id" value="<?php if (isset($result)) echo $_REQUEST['id'] ?>">-->
                    <?php // } ?>
                                <!--<input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />-->

                            </div>
                        </form>           
                    </div>
<?php if (isset($list) && !empty($list)) {
    ?>
                        <div class="card-body" >

    <?php // if(isset($form['batch']) && !empty($form['batch'])) {  ?>
        <!--<table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable">-->

                            <!-- Table heading -->
    <!--                                    <thead>
                                <tr>
                                    <th style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:16px;"> Batch Info</th>
                                </tr>
                            </thead>-->
                            <!-- // Table heading END --> 

                            <!-- Table body -->
    <!--                                    <tbody>
                            <?php
//                                        $i = 0;
//                                        $productname = '';
//                                            foreach($list as $k=> $row){
//                                                if($i <= 0)
//                                                {
//                                                                foreach ($product as $row1) {
//                                                                     if (isset($form['product']) && $form['product'] == $row1['itm_id'])
//                                                                     {
//                                                                          $productname =  $row1['itm_name'];
//                                                                 }
//                                                                }
                            ?>
                                        <tr>
                                            <td>
                                                //<?php
//                                                        
//                                                            //funding source
////                                                         '<b style="font-weight: 900;margin-left: 30px;">Funding Source : </b>' .$row['funding_source_name'] .
//                                                           
//                                                            $pop = 'onclick="window.open(\'print_ledger_history?id=' . $row['batch_id'] . '\',\'_blank\',\'scrollbars=1,width=840,height=595\')"';
//                                                            echo '<b style="font-weight: 900;">Product : </b>' .$productname . '<b style="font-weight: 900;margin-left: 30px;">Batch No : </b>'.'<a style="text-decoration: underline;" class="alert-link" ' . $pop . ' >' . $row['batch_no'] . '</a>' .'<b style="font-weight: 900;margin-left: 30px;">Batch Expiry : </b>' .$row['batch_expiry'];
                        ?>
                                            </td>
                                        </tr>
                                        //<?php
//                                                $i++;
//                                                }
//                                            }
                        ?>
                            </tbody>
                        </table>-->
    <?php // }  ?>

                            <div style="overflow-x:auto;" >
                                <div id="report_type" style=" text-align:center; background: greenyellow;">
                                <span style="line-height:20px"><b>STOCK LEDGER REPORT</b></span><br/>
                                <span style="line-height:20px"><b>NTP</b></span><br/>
                                <span style="line-height:20px"><b><?php foreach ($whName as $whname) { echo $whname['wh_name']; } ?></b></span><br/>
                                </div>
                                <table  id="content_print" style="width:100%;"  border='1'  class="table table-striped table-bordered dt-responsive nowrap">
                                    <style type="text/css" media="print">
                                        @media print
                                        {    
                                            #printButt
                                            {
                                                display: none !important;
                                            }
                                        }
                                    </style>
                                    <thead>
                                        <tr>
                                            <td>#</td>
                                            <td>Voucher Date</td>
                                            <td>Voucher Number</td>
                                            <td>Batch No.</td>
                                            <td>Batch Expiry</td>
                                            <td>Type</td>
                                            <td>Particulars</td>

    <!--                                <td>Funding Source</td>
    <td>Expiry</td>-->
                                            <td>Receive Quantity</td>
                                            <td>Issue Quantity</td>
                                            <td>Batch Balance</td>
                                            <td>Product Balance</td>
                                            <td>Created Date</td>
                                            <td>Created By</td>
                                        </tr>
                                    </thead>
                                    <tbody >
    <?php
    $count = 1;
    $batch_cb = array();
    $balance_vials_ob = 0;

    if (isset($batch_ob)) {
        foreach ($batch_ob as $b) {
            $balance_vials_ob = $balance_vials_ob + ($b['Qty']);
            ?>
                                                <tr>
                                                    <th><?php echo $count; ?></th>
                                                    <th><?php echo $startdate; ?></th>
                                                    <th></th>
                                                    <th></th>
                                                    <th></th>
                                                    <th></th>
                                                    <th>Opening Balance <?php if (isset($b['batch_no']) && !empty($b['batch_no'])) { ?>(<?php echo $b['batch_no']; ?>) <?php } ?></th>
                    <!--                                <th>
            <?php
//                                $pop = 'onclick="window.open(\'print_ledger_history?id=' . $b['batch_id'] . '\',\'_blank\',\'scrollbars=1,width=840,height=595\')"';
//                                echo "<a class='alert-link' " . $pop . " ></br>" . $b['batch_no'] . "</a>";
//                                echo $b['batch_no']; 
            ?>
                                                    </th>-->
                    <!--                                <th><?php echo $b['funding_source_name']; ?></th>
                                                    
                                                    <th></th>-->
                                                    <th class="right"><?php ?></th>
                                                    <th class="right"></th>
                                                    <th class="right"><?php echo number_format($b['Qty']); ?></th>
                                                    <th class="right"></th>
                                                    <th class="right"><?php ?></th>
                                                    <th class="right"></th>

                                                </tr>
            <?php
            $count++;
        }
    }
    ?>

                                        <tr>
                                            <th><?php echo $count; ?></th>
                                            <th><?php echo $startdate; ?></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th>Opening Balance (<?php if (isset($pr)) {
        foreach ($pr as $row) {
            echo $row['itm_name'] . ') (' . $row['strength'];
        }
    } ?>) </th>

    <!--                        <th></th>
    <th></th>
    <th class="right"><?php ?></th>-->
                                            <th class="right"></th>
                                            <th class="right"><?php ?></th>
                                            <th class="right"><?php echo number_format($balance_vials_ob); ?></th>
                                            <th class="right"></th>
                                            <th></th>


                                            <th class="right"></th>

                                        </tr>
                                        <?php
                                        $count++;
                                        $balance_vials = $balance_vials_ob;
                                        foreach ($list as $k => $row) {
//                            echo '<pre>';
//                         print_r($row); exit;
                                            if (!empty($row['trans_nature'])) {
                                                $nature = $row['trans_nature'];
                                            } else {
                                                $nature = '';
                                            }

                                            $quantity_vials = $row['quantity'];
                                            //$quantity_doses = $quantity_vials * $row->getStockBatchWarehouse()->getStockBatch()->getPackInfo()->getStakeholderItemPackSize()->getItemPackSize()->getNumberOfDoses();
                                            $balance_vials = $balance_vials + $quantity_vials;
                                            //$balance_doses = $balance_doses + ($nature . ABS($quantity_doses));
                                            $created_date = $row['created_on'];
                                            $created_by = $_SESSION['name'];

//                        if (array_key_exists($row['stock_batch_warehouse_id'], $batch_cb)) {
//
//                            $batch_cb[$row['stock_batch_warehouse_id']] = $batch_cb[$row['stock_batch_warehouse_id']] + ($nature . ABS($quantity_vials));
//                            //$batch_cb_doses = $batch_cb[$row->getStockBatchWarehouse()->getPkId()] * $row->getStockBatchWarehouse()->getStockBatch()->getPackInfo()->getStakeholderItemPackSize()->getItemPackSize()->getNumberOfDoses();
//                        } else {
//                            $batch_cb[$row['stock_batch_warehouse_id']] = $objStockMaster->getBatchOB($row['stock_batch_warehouse_id'], $date_from) + ($nature . ABS($quantity_vials));
//                            //$batch_cb_doses = $batch_cb[$row['stock_batch_warehouse_id']] * $row->getStockBatchWarehouse()->getStockBatch()->getPackInfo()->getStakeholderItemPackSize()->getItemPackSize()->getNumberOfDoses();
//                        }

                                            if (!empty($row['status_id']) && $row['status_id'] == 4) {
//                            $print_link = 'printIssue.php?id=' . $row['stock_master_id'];
                                                $warehouse_name = "To (" . $row['toWh'] . ")";
                                            } else {
//                            $print_link = 'printReceive.php?id=' . $row['stock_master_id'] . '&type=' . $row['TranTypeID'];
//                            $warehouse_name = "From " . $row['fromWh'];
                                                $warehouse_name = "From (" . $row['received_from_fs'] . ")";
                                            }
                                            ?>
                                            <tr>
                                                <td><?php echo $count; ?></td>
                                                <td title="<?php echo $row['tran_no']; ?>"><?php echo date('Y-m-d', strtotime($row['tran_date'])); ?></td>
                    <!--                            <td><a onclick="window.open('<?php echo $print_link; ?>', '_blank', 'scrollbars=1,width=860,height=595');" href="javascript:void(0);"><?php echo $row['tran_no']; ?></a></td>-->
                                                <!--<td><?php echo $row['tran_no']; ?> </td>-->

                                                <!--xxxxxxxxxxxxxxxxxxxxx CHanges by Mansoor  xxxxxxxxxxxxxxxxxx-->
                                                <td>
                                                    <?php
//                                echo $row['trans_nature']; exit;
                                                    if ($row['trans_type'] == 'Issue') {
                                                        $url_1 = base_url('inventory_management/printIssue?id=' . $row['stock_master_id'] . '&issue=1');
//                              $print_voc = 'onclick=window.open(\'$url_1\',\'_blank\',\'scrollbars=1,width=840,height=595\')"';
                                                        ?>
                                                        <a style="text-decoration: underline;" class="alert-link" onclick="window.open('<?php echo $url_1; ?>', '_blank', 'scrollbars=1,width=840,height=595')"  ><?php echo $row['tran_no']; ?></a>;
                                                    <?php
                                                    } elseif ($row['trans_type'] == 'Receive') {
                                                        $url_1 = base_url('inventory_management/print_receive?id=' . $row['stock_master_id'] . '&gwis=1');
//                                  $print_voc = 'onclick="window.open(\'http://localhost/cmu/inventory_management/print_receive?id=' . $row['stock_master_id'] . '&gwis=1'. '\',\'_blank\',\'scrollbars=1,width=840,height=595\')"';
                                                        ?>
                                                        <a style="text-decoration: underline;" class="alert-link" onclick="window.open('<?php echo $url_1; ?>', '_blank', 'scrollbars=1,width=840,height=595')"  ><?php echo $row['tran_no']; ?></a>;
                                                        <?php
                                                    } else {
                                                        $url_1 = base_url('inventory_management/print_adjst?id=' . $row['stock_master_id'] . '&gwis=1');
//                              $print_voc = 'onclick="window.open(\'http://localhost/cmu/inventory_management/print_adjst?id=' . $row['stock_master_id'] . '&gwis=1'. '\',\'_blank\',\'scrollbars=1,width=840,height=595\')"';
                                                        ?>
                                                        <a style="text-decoration: underline;" class="alert-link" onclick="window.open('<?php echo $url_1; ?>', '_blank', 'scrollbars=1,width=840,height=595')"  ><?php echo $row['tran_no']; ?></a>;

                                                        <?php
                                                    }
                                                    ?>
                                                </td>
                                                <!--xxxxxxxxxxxxxxxxxxxxx CHanges by Mansoor  xxxxxxxxxxxxxxxxxx-->

                                                <td>
        <?php
        //funding source
//                                                         '<b style="font-weight: 900;margin-left: 30px;">Funding Source : </b>' .$row['funding_source_name'] .

        $pop = 'onclick="window.open(\'print_ledger_history?id=' . $row['batch_id'] . '\',\'_blank\',\'scrollbars=1,width=840,height=595\')"';
        echo '<a style="text-decoration: underline;" class="alert-link" ' . $pop . ' >' . $row['batch_no'] . '</a>'
        ?>
                                                </td>

                                                <td>
                                                <?php echo $row['batch_expiry']; ?>
                                                </td>

                                                <td><?php echo $row['trans_type']; ?></td>
                                                <td><?php echo $warehouse_name; ?></td>
                    <!--                            <td title=""><?php
//                                $pop = 'onclick="window.open(\'print_ledger_history?id=' . $row['batch_id'] . '\',\'_blank\',\'scrollbars=1,width=840,height=595\')"';
//                                echo "<a class='alert-link' " . $pop . " ></br>" . $row['batch_no'] . "</a>";
//                                echo $b['batch_no']; 
                                                ?>
                                                </td>-->
                                                <!--<td title=""><?php echo $row['funding_source_name']; ?></td>-->
                                                <!--<td><?php echo $row['batch_expiry']; ?></td>-->
                                                <?php // if ($row['quantity'] > 0) {
                                                if (!empty($row['status_id']) && $row['status_id'] != 4) {
                                                    ?>
                                                    <td class="right"><?php echo number_format(ABS($quantity_vials)); ?></td>
                                                    <td class="right"></td>
        <?php } else { ?>
                                                    <td class="right"></td>
                                                    <td class="right"><?php echo number_format(ABS($quantity_vials)); ?></td>
        <?php } ?>
                        <!--<td class="right"><?php //echo number_format($batch_cb_doses);               ?></td> -->
                                                <td class="right"><?php echo ''; ?></td>
                                                 <!--<td class="right"><?php echo number_format($batch_cb[$row['stock_batch_warehouse_id']]); ?></td>-->
                                                 <!-- <td class="right"><?php //echo number_format($balance_doses);                  ?></td> -->
                                                <td class="right"><?php echo number_format($balance_vials); ?></td>
                                                <td><?php echo $created_date; ?></td>
                                                <td><?php echo $row['created_by']; ?></td>
                                                <!-- <td class="right"><?php ?></td> -->
                                            </tr>
        <?php
        $count++;
    }
    if (isset($batch_cb1)) {
        foreach ($batch_cb1 as $cb) {
            ?>
                                                <tr>
                                                    <th><?php echo $count; ?></th>
                                                    <th><?php echo $enddate; ?></th>
                                                    <th></th>
                                                    <th></th>
                                                    <th></th>
                                                    <th></th>
                                                    <th>Closing Balance <?php if (isset($cb['batch_no']) && !empty($cb['batch_no'])) { ?> (<?php echo $cb['batch_no']; ?>) <?php } ?></th>

            <!--                            <th><?php
//                            $pop = 'onclick="window.open(\'print_ledger_history?id=' . $cb['batch_id'] . '\',\'_blank\',\'scrollbars=1,width=840,height=595\')"';
//                            echo "<a class='alert-link' " . $pop . " ></br>" . $cb['batch_no'] .  "</a>";
                                        //echo $b['batch_no']; 
                                        ?>
            </th>-->

            <!--<th><?php echo $cb['funding_source_name']; ?></th>-->
            <!--<th></th>-->
                                                    <th class="right"><?php ?></th>
                                                    <th class="right"></th>
                                                    <th class="right"><?php echo number_format($cb['Qty']); ?></th>
                                                    <th class="right"></th>
                                                    <th class="right"><?php ?></th>
                                                    <th class="right"></th>

                                                                                              <!-- <th class="right"><?php ?></th> -->
                                                    <!-- </tr>-->
                                                </tr>
            <?php
            $count++;
        }
    }
    ?>

                                        <tr>
                                            <th><?php echo $count; ?></th>
                                            <th><?php echo $enddate; ?></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th>Closing Balance (<?php if (isset($pr)) {
        foreach ($pr as $row) {
            echo $row['itm_name'] . ') (' . $row['strength'];
        }
    } ?>)</th>
                    <!--                        <th></th>
                                            <th></th>
                                            <th class="right"><?php ?></th>-->
                                            <th class="right"></th>
                                            <th class="right"><?php ?></th>

                                            <th class="right"><?php echo number_format($balance_vials); ?></th>
                                            <th class="right"></th>
                                            <th class="right"></th>
                                                                       <!-- <th class="right"><?php ?></th> -->
                                        </tr>


                                    </tbody>
                                </table>
                                <div style="float:right; margin-top:10px;" id="printButt">
                                    <input type="button" name="print" value="Print" class="btn btn-warning" onclick="javascript:printCont();" />
                                </div>
                            </div>
                        </div>
<?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
$selproduct = '';
if (isset($form['product']) && !empty($form['product'])) {
    $selproduct = $form['product'];
}
?>

<script src="<?php echo PUBLIC_URL; ?>assets/global/plugins/jquery-1.11.0.min.js" type="text/javascript"></script>
<script language="javascript">
                $(function () {
                    //printCont();
                })
                function printCont()
                {
//	 var divToPrint=document.getElementById("content_print");
//   newWin= window.open("");
//   newWin.document.write(divToPrint.outerHTML);
//   newWin.print();
//   newWin.close();

                    window.print();
                }




//$('#example').dataTable( {
//  "scrollX": true
//} );
//alert('<?php echo $selproduct; ?>');
//$('#ledger_product').val('<?php echo $selproduct; ?>'); // Select the option with a value of '1'
//$('#ledger_product').trigger('change');


                $("#stakeholder").change(function () {

                    var value = $(this).val();
                    if (value == '')
                    {
                        value = $('#sstakeholder').val();
                    }
//            else{
//                $('#supplier_info').fadeOut();
//            }
//            alert(value);
                    $.ajax({
                        type: "POST",
                        url: '<?php echo base_url("ajax/getproduct_bystkid"); ?>',
                        data: {
                            id: value
                        },
                        dataType: 'json',
                        success: function (data) {
                            var user = JSON.parse(JSON.stringify(data));
//                    alert(user);
                            if (user)
                            {
//                        $("#product").html(user);
//                        $("#issue_product").html(user);
//                        $("#adj_product").html(user);
                                $("#ledger_product").html(user);
                            }
                            $('#ledger_product').val('<?php echo $selproduct; ?>'); // Select the option with a value of '1'
                            $('#ledger_product').trigger('change');
//                    $("#ledger_product").val(1); 
//                    $('#ledger_product').select2().trigger('change');
//                    $("#public_private").val(user.gender);
//                    $("#district").select2("val", "");
//                    $("#tehsil").select2("val", "");
//                    $("#uc").select2("val", "");
//                    $('#district').html(data);
                        }
                    });

//            var value = $(this).val();
//            if(value == '1')
//            {
//                $("#po_quantity").prop('required',true);
//                $("#wh_detail_info").prop('required',false);
//                $("#receive_from_warehouse").prop('required',false);
//                $("#receive_from_supplier").prop('required',true);
//                $("#po_detail_info").prop('required',true);
//                $('#show_receive_from_warehouse').fadeOut();
//                $('#show_receive_from_supplier').fadeIn();
//                $('#po_type_detail').fadeIn();
//                $('#fo_type_detail').fadeOut();
//                
//                $('#show_po_quantity').fadeIn();
//            }
                }).change();

</script>