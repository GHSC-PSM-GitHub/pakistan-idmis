<style>
    .sprintbuttonstyle{
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 4px;
}
    h2 {
        margin-top:18px !important;
    }
        
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
    }
  
*{font-family:"Open Sans",sans-serif;}
b{font-size:12px;}
h3{font-size:13px;}
#report_type{
font-size:12px;
font-family: arial;}
#content_print
{
	width:90%;
	margin-left:50px;
        margin-right:50px;
}
table#myTable{
	border:1px solid #E5E5E5;
	font-size:9pt;
	width:100%;
}
table, table#myTable tr td{
	border-collapse: collapse;
	border:1px solid #E5E5E5;
	font-size:12px;
}
table, table#myTable tr th{
	border:1px solid #E5E5E5;
	border-collapse: collapse;
	font-size:12px;
}

@media print
{    
    #noprint, #noprint *
    {
        display: none !important;
    }
}
</style>
<?php
    $from_id = '';
    $TranRef = '';
?>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title">Distribution Detail Report</h4>
                </div>
<!--                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Reports</a></li>
                        <li class="breadcrumb-item active">Stock Summary</li>
                    </ol>-->
                <!--</div>-->
            </div>
            <!-- end row -->
            <div style="float:right; margin-top:10px;" id="printButt">
                <input type="button" name="print" value="Print" class="btn btn-warning sprintbuttonstyle" onclick="javascript:printCont();" />
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
<!--            <div class="card-body" id="noprint">
                 <form method="post" id="addwarehouse" name="addwarehouse" action="<?php echo base_url("reports/stock_summary"); ?>">
                                <div class="form-group row"> 
                                            
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="start_date"  >Start Date(MM/DD/YYYY)  </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="start_date" id="start_date"  value="<?php if(isset($form['start_date']) && !empty($form['start_date'])) {echo $form['start_date'];} else{ echo date("d/m/Y");} ?>" >

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="end_date"  >End Date(MM/DD/YYYY)  </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="end_date" id="end_date" value="<?php if(isset($form['end_date']) && !empty($form['end_date'])) {echo $form['end_date'];} else{ echo date("d/m/Y");} ?>" >

                                                        </div>
                                                    </div>
                                                </div>
                                    
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Stakeholder </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="stakeholder" id="stakeholder"  style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                                <?php
                                                                foreach ($stakeholder as $row) {
                                                                    ?>
                                                                <option value="<?php echo $row['stkid'] ?>" <?php if (isset($form['stakeholder']) && $form['stakeholder'] == $row['stkid']) echo "selected='selected'"; ?>><?php echo $row['stkname'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>
                                            
                                                <div class="col-md-3">
                                                <label class="control-label" for="source_type"> Province </label>
                                                <div class="controls">
                                                        <select name="province" id="province"  class="select2me input-medium"  style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            if ($province) {
                                                                //fetch result
                                                                foreach ($province as $row) {
                                                                    //populate receive_from combo
    //                                                                if($_SESSION['user_stakeholder']=='145'){
    //                                                                    if($row->wh_id != '33677' && $row->wh_id != '33678' && $row->wh_id != '33680' && $row->wh_id != '20641'  && $row->wh_id != '9079') 
    //                                                                        continue;
    //                                                                }
                                                                    ?>
                                                            <option value="<?php echo $row['PkLocID']; ?>"  <?php if (isset($form['province']) && $form['province'] == $row['PkLocID']) echo "selected='selected'"; ?>> <?php echo $row['LocName']; ?> </option>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="contact_no"  >Contact </label>
                                                        <div class="controls">
                                                            <input type="text" name="contact_no" readonly id="contact_no" class="form-control"  <?php if (isset($master_id)) echo 'readonly="true"' ?> 
                                                            <?php
//                                                            if (isset($refernce_number)) {
//                                                                echo 'value="' . $refernce_number . '"';
//                                                            }
                                                            ?>

                                                                   >

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            
                                            <div class="form-group row">
                                                <div class="col-md-11">
                                                </div>
                                                <div class="col-md-1">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
//                                                    if (isset($result))
//                                                        echo 'value="edit"';
                                                    ?>>
                                                        <?php echo 'Search'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div> 
                                                <?php // if (isset($result)) {
                                                    ?>
                                                    <input type="hidden" id="wh_id" name="wh_id" value="<?php if (isset($result)) echo $_REQUEST['id'] ?>">
                                                <?php // } ?>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                        </form>           
            </div>-->
                    <?php // if(isset($list) && !empty($list))
//                    if(isset($_POST['wh_btn']) && isset($summaryinfo))
//                    {?>
                    <div class="card-body">
                        
                         
    <div id="content_print">
        <style type="text/css" media="print">
            @media print
            {    
                #printButt
                {
                    display: none !important;
                }
            }
        </style>
        <?php
//        $rptName = 'Batch Management Summary';
        $rptName = 'Distribution Detail Report';
        //include header
//        include('report_header.php');
        ?>
            
         <div style="line-height:1;">
    <div id="logoLeft" style="float:left; width:107px; text-align:right;">
    <!--<img src="<?php echo PUBLIC_URL;?>images/gop.png" />-->
        <img id="pics" style="border-radius: 50%;" src="<?php echo base_url('assets/images/lmis.jpg')?>" alt="" height="100">
    </div>
    <div id="report_type" style="float:left; width:100%; text-align:center;">
        <?php 
        $stkid = '';
        if ($stkid==1 && $provid==1 && $lvl==3) 
        {
            ?>
                <span style="line-height:20px"><b>POPULATION WELFARE DEPARTMENT</b></span><br/>
                <span style="line-height:20px"><b>GOVERNMENT OF PUNJAB</b></span><br/>
        <?php }
        elseif ($stkid==145) 
        {
            ?>
                <span style="line-height:20px"><b>PRIMARY & SECONDARY HEALTHCARE DEPARTMENT</b></span><br/>
                <span style="line-height:20px"><b>GOVERNMENT OF PUNJAB</b></span><br/>
                <span style="line-height:20px"><b>MEDICAL STORE DEPO LAHORE</b></span><br/>
        <?php 
        }elseif ($stkid==1) 
        {
            ?>
                <span style="line-height:20px"><b>GOVERNMENT OF PAKISTAN</b></span><br/>
                <span style="line-height:20px"><b>CMU</b></span><br/>
                <span style="line-height:20px"><b>REGULATIONS & COORDINATION</b></span><br/>
                <span style="line-height:20px">DIRECTORATE OF CENTRAL WAREHOUSE & SUPPLIES</span><br/>
        <?php 
        } 
        else {
            ?>
                <span style="line-height:20px"><b>GOVERNMENT OF PAKISTAN</b></span><br/>
                <span style="line-height:20px"><b>CMU</b></span><br/>
                <span style="line-height:20px"><b>REGULATIONS & COORDINATION</b></span><br/>
                <span style="line-height:20px">DIRECTORATE OF CENTRAL WAREHOUSE & SUPPLIES</span><br/>
                <!--<span style="line-height:20px"><?php // echo $logo1[1]?></span><br/>-->
        <?php 
        
        }?>
        <span style="line-height:15px"><b>Store: </b><?php // echo $whname;?></span>
        <hr style="margin:3px 10px;" />
        <p><b><?php echo $rptName;?> as on: <?php echo date('d-M-Y');?></b>
        </p>
    </div>
</div>
<div style="clear:both"></div>   
        <table id="myTable" class="table-condensed" cellpadding="3">
            <thead>
                <tr style="background:#35AA47;">
                    <th>S. No.</th>
                    <th>Stakeholder</th>
                    <th>Product</th>
                    <th>Strength</th>
<!--                    <th>Funding Source</th>
                    <th>Unit</th>                    
                    <th>Actual Receive Quantity</th>
                    <th>Stock Receive</th>
                    <th>Stock Issue</th>
                    <th>Stock Balance</th>-->
                    <th>Unit Cost</th>
                    <th>Total Cost</th>
                    <th>Quantity</th>
                    
                    <!--<th>Unit</th>-->
                    <!--<th>Cartons</th>-->
                </tr>
            </thead>
            <tbody>
                <?php
                //check num
                if (count($summaryinfo) > 0) {
                    $i = 1;
                    $actualrec = $stockbalance = $totalissue = '';
                    $totalQty = $totalCartons = '';$unit_cost_total = '0';$total_cost_total = '0';
                    //fetch data from qryRes
                    foreach ($summaryinfo as $row) { 
                        //total qty
                        $actualrec += abs($row['actual_rec_qty']);
                        $totalQty += abs($row['stock_receive']);
                        $totalissue += abs($row['issue_quantity']);
                        $stockbalance += abs($row['stock_receive']) - abs($row['issue_quantity']);
                        $unit_cost_total += abs($row['unit_price']);
                        $total_cost_total += $row['Vials']*$row['unit_price']*$row['conversion_rate'];
                        //total cartons
//                        $totalCartons += abs($row['Vials']) / $row['qty_carton'];
                        ?>
                        <!-- Table row -->
                        <tr>
                            <td style="text-align:center;"><?php echo $i; ?></td>
                            <td><?php echo $row['stk_name']; ?></td>
                            <td><?php echo $row['itm_name']; ?></td>
                            <td><?php echo $row['strength']; ?></td>
<!--                            <td><?php echo $row['funding_source']; ?></td>
                            <td><?php echo $row['method_type']; ?></td>
                            <td style="text-align:right;"><?php echo $row['actual_rec_qty']; ?></td>
                            <td style="text-align:right;"><?php echo $row['stock_receive']; ?></td>
                            <td style="text-align:right;"><?php echo abs($row['issue_quantity']); ?></td>-->
                            <td><?php echo $row['unit_price']; ?></td>
                            <td><?php echo number_format($row['Vials']*$row['unit_price']*$row['conversion_rate']); ?></td>
                            <td style="text-align:right;"><?php echo number_format(abs($row['stock_receive']) - abs($row['issue_quantity'])); ?></td>
                            <!--<td style="text-align:right;"><?php echo $row['UnitType']; ?></td>-->
                            <!--<td style="text-align:right;"><?php echo number_format($row['Vials'] / $row['qty_carton']); ?></td>-->
                        </tr>
            <?php $i++;
        }
    } ?>
                <!-- // Table row END -->
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="4" style="text-align:right;">Total</th>
<!--                    <th style="text-align:right;"><?php echo number_format($actualrec); ?></th>
                    <th style="text-align:right;"><?php echo number_format($totalQty); ?></th>
                    <th style="text-align:right;"><?php echo number_format($totalissue); ?></th>-->
                    <th style="text-align:right;"><?php echo number_format($unit_cost_total); ?></th> 
                    <th style="text-align:right;"><?php echo number_format($total_cost_total); ?></th> 
                    <th style="text-align:right;"><?php echo number_format($stockbalance); ?></th>                    
                    <!--<th>&nbsp;</th>-->
                    <!--<th style="text-align:right;"><?php echo number_format($totalCartons); ?></th>-->
                </tr>
            </tfoot>
        </table>

    </div> 
                        
                        
                        <!--<img id="pics" style="" src="<?php echo base_url('assets/images/summary.png')?>" alt="" width="100%" height="600">-->
<!--                        <table  id="datatable-buttons" style="width:100%;" class="table table-striped table-bordered dt-responsive nowrap">
                            <thead>
                            <tr>
                                <td>#</td>
                                <td>Voucher Date</td>
                                <td>Voucher Number</td>
                                <td>Type</td>
                                <td>Particulars</td>
                                <td>Batch No.</td>
                                <td>Funding Source</td>
                                <td>Expiry</td>
                                <td>Receive</td>
                                <td>Issue</td>
                                <td>Batch Balance</td>
                                <td>Product Balance</td>
                                <td>Created Date</td>
                                <td>Created By</td>
                            </tr>
                            </thead>
                            <tbody >
                        <?php
                        $c=1;
                        $balance_vials = '';
                        foreach($list as $k=> $row){
                            
                            $nature = $row['trans_nature'];
                        $quantity_vials = $row['quantity'];
                        //$quantity_doses = $quantity_vials * $row->getStockBatchWarehouse()->getStockBatch()->getPackInfo()->getStakeholderItemPackSize()->getItemPackSize()->getNumberOfDoses();
                        $balance_vials = $balance_vials + ($nature . ABS($quantity_vials));
                        //$balance_doses = $balance_doses + ($nature . ABS($quantity_doses));
                        $created_date = $row['CreatedOn'];
                        $created_by = '';

//                        if (array_key_exists($row['stock_batch_warehouse_id'], $batch_cb)) {
//
//                            $batch_cb[$row['stock_batch_warehouse_id']] = $batch_cb[$row['stock_batch_warehouse_id']] + ($nature . ABS($quantity_vials));
//                            //$batch_cb_doses = $batch_cb[$row->getStockBatchWarehouse()->getPkId()] * $row->getStockBatchWarehouse()->getStockBatch()->getPackInfo()->getStakeholderItemPackSize()->getItemPackSize()->getNumberOfDoses();
//                        } else {
//                            $batch_cb[$row['stock_batch_warehouse_id']] = $objStockMaster->getBatchOB($row['stock_batch_warehouse_id'], $date_from) + ($nature . ABS($quantity_vials));
//                            //$batch_cb_doses = $batch_cb[$row['stock_batch_warehouse_id']] * $row->getStockBatchWarehouse()->getStockBatch()->getPackInfo()->getStakeholderItemPackSize()->getItemPackSize()->getNumberOfDoses();
//                        }

                        if ($row['TranTypeID'] == 2) {
//                            $print_link = 'printIssue.php?id=' . $row['stock_master_id'];
                            $warehouse_name = "To " . $row['toWh'];
                        } else {
//                            $print_link = 'printReceive.php?id=' . $row['stock_master_id'] . '&type=' . $row['TranTypeID'];
                            $warehouse_name = "From " . $row['fromWh'];
                        }
                            ?>
                            <tr>
                            <td><?php echo $c; ?></td>
                            <td title="<?php echo $row['TranNo']; ?>"><?php echo date('Y-m-d',strtotime($row['TranDate'])); ?></td>
                            <td><a onclick="window.open('<?php echo $print_link; ?>', '_blank', 'scrollbars=1,width=860,height=595');" href="javascript:void(0);"><?php echo $row['TranNo']; ?></a></td>
                            <td><?php echo $row['TranNo']; ?></td>
                            <td><?php echo $row['trans_type']; ?></td>
                            <td><?php echo $warehouse_name; ?></td>
                            <td title=""><?php
                                $pop = 'onclick="window.open(\'product-ledger-history.php?id=' . $row['batch_id'] . '\',\'_blank\',\'scrollbars=1,width=840,height=595\')"';
                                echo "<a class='alert-link' " . $pop . " ></br>" . $row['batch_no'] . "</a>";

//                                echo $b['batch_no']; 
                                ?>
                            </td>
                            <td title=""><?php echo $row['funding_source_name']; ?></td>
                            <td><?php echo $row['batch_expiry']; ?></td>
                            <?php if ($row['quantity'] > 0) { ?>
                                <td class="right"><?php echo number_format(ABS($quantity_vials)); ?></td>
                                <td class="right"></td>
                            <?php } else { ?>
                                <td class="right"></td>
                                <td class="right"><?php echo number_format(ABS($quantity_vials)); ?></td>
                            <?php } ?>
        <td class="right"><?php //echo number_format($batch_cb_doses);              ?></td> 
                           <td class="right"><?php echo ''; ?></td>
                            <td class="right"><?php echo number_format($batch_cb[$row['stock_batch_warehouse_id']]); ?></td>
                             <td class="right"><?php //echo number_format($balance_doses);                  ?></td> 
                            <td class="right"><?php echo number_format($balance_vials); ?></td>
                            <td><?php echo $created_date; ?></td>
                            <td><?php echo $created_by; ?></td>
                             <td class="right"><?php ?></td> 
                        </tr>
                       <?php $c++; }
                        ?>
                            </tbody>
                        </table>-->
                    </div>
                    <?php // } ?>
        </div>
        </div>
        </div>
        </div>
        </div>
<script src="<?php echo PUBLIC_URL;?>assets/global/plugins/jquery-1.11.0.min.js" type="text/javascript"></script>
<script language="javascript">
$(function(){
	//printCont();
})
function printCont()
{
	window.print();
}
</script>