<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons"> 
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                    <!-- // Heading END -->
                    <h3>EDIT Transaction</h3>
                    <div class="innerLR">
                        <br>
                                                

                        <div id="divToPrint">
                            <form method="post"  action="<?php echo base_url("Reports/edit_report"); ?>" >
                                <div class="card">
                                    <div class="card-body">
                                    <?php
                                        foreach ($fetch_data as $row) {
                                            ?>
                                        
                                        <div class="row">
                                                <div class="col-md-3">
                                                  <b>  Issuance Number : </b><br><?php echo $row['pk_id'] ?><br>
                                                </div>
                                                <div class="col-md-3">
                                                   <b> From :</b> <br><?php echo $row['wh_from'] ?><br>
                                                </div>
                                                <div class="col-md-3">
                                                  <b>  To : </b><br> <?php echo ((!empty($row['issuance_to']) && $row['issuance_to'] == 'patients') ? $row['full_name'] . '-' . $row['nic_no'] : $row['wh_to']) ?>
                                                </div>
                                            
                                           
                                            
                                        </div>
                                        
                                        
                                        <div class="row">
                                            <div class="col-md-3">
                                                <label for="transaction_date">Transaction Date</label>
                                                <input name="transaction_date" id="transaction_date" type="date" class="form-control" value="<?php echo $row['transaction_date'] ?>">

                                            </div>
                                            <div class="col-md-3">
                                                <label for="transaction_reference">Transaction Reference</label>

                                                <input name="transaction_reference" id="transaction_reference" type="text" class="form-control" value="<?php echo $row['transaction_reference'] ?>">
                                            </div>
                                            <input type="hidden" name="hidden_id" value="<?php echo $row['pk_id']; ?>" />
                                            
                                            <div class="col-md-3">
                                               <br>
                                                <input class="form-control btn btn-primary" type="submit" name="update" value="Update"/> 
<!--                                                <input name="btn_submit" id="btn_submit" type="submit" value="Update" class="form-control btn btn-primary">-->
                                            </div>
                                        </div>
                                        
                                                       <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </form>
                         
                        </div>
       


                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<!--***********************************************************-->

