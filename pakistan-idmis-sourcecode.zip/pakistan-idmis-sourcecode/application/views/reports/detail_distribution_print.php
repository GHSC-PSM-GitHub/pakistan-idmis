<style>
*{font-family:"Open Sans",sans-serif;}
b{font-size:12px;}
h3{font-size:13px;}
#report_type{
font-size:12px;
font-family: arial;}
#content_print
{
	width:624px;
	margin-left:50px;
}
table#myTable{
	border:1px solid #B6B6B7;
	font-size:9pt;
	width:100%;
}
table, table#myTable tr td{
	border-collapse: collapse;
	border:1px solid #B6B6B7;
	font-size:12px;
}
table, table#myTable tr th{
	border:1px solid #B6B6B7;
	border-collapse: collapse;
	font-size:12px;
}

table#myTables{
	border:1px solid #B6B6B7;
	font-size:9pt;
	width:50%;
}
table, table#myTables tr td{
	border-collapse: collapse;
	border:1px solid #B6B6B7;
	font-size:12px;
}
table, table#myTables tr th{
	border:1px solid #B6B6B7;
	border-collapse: collapse;
	font-size:12px;
}

table#loc_from_to{
	border:1px solid #B6B6B7;
	font-size:9pt;
	width:40%;
}
table, table#loc_from_to tr td{
	border-collapse: collapse;
	border:1px solid #B6B6B7;
	font-size:12px;
}
table, table#loc_from_to tr th{
	border:1px solid #B6B6B7;
	border-collapse: collapse;
	font-size:12px;
}
.sprintbuttonstyle{
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 4px;
}
</style>
<?php
/**
 * printIssue
 * @package im
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
//includ AllClasses
//include("../includes/classes/AllClasses.php");

$title = "Stock Issue Voucher";
$print = 1;
$whNames = array();
$logo1 = array();
if(!empty($whName))
{
    foreach ($whName as $row)
    {
        $stkid = $row['stkid'];
        $whname = $row['wh_name'];
        $prov_id = $row['prov_id'];
        $lvl = $row['lvl'];
    }
}
else{
        $stkid = '';
        $whname = '';
        $prov_id = '';
        $lvl = '';
}
if(isset($logo) && !empty($logo))
{
    foreach ($logo as $rowlogo)
    {
        $logo1[1] = $rowlogo;
    }
}
//get id
$receiveArr = array();
//fetching data from stocks

if(isset($stocks) && !empty($stocks))
{
//    foreach ($stocks as $row) {
//    //issue_no 
//    $issue_no = $row['tran_no'];
//    //comments
//    $comments = $row['received_remarks'];
//    //tran_ref
//    $tran_ref = $row['tran_ref'];
//    //issue_date
//    $issue_date = date("d/m/y", strtotime($row['tran_date']));
//    //wh_to_id
//    $wh_to_id = $row['wh_id'];
//    $wh_to = $row['wh_to'];
//    //issue_to
//    $issue_to = $row['wh_name'];
//    //issued_by
//    $doc_no = $row['dc_no'];
//    $vehicle_reg = $row['vehicle_reg'];
//    $dc_date = date("d/m/y", strtotime($row['dc_date']));
//    $driver_name = $row['driver_name'];
//    $driver_contact = $row['driver_contract'];
//    $siv_no_of_cartons = $row['siv_no_of_cartons'];
//    $siv_weight = $row['siv_weight'];
//    
//    $siv_mode_of_transport = $row['siv_mode_of_transport'];
//    $siv_name_of_transporter = $row['siv_name_of_transporter'];
//    $siv_vehicle_type = $row['siv_vehicle_type'];
//    $siv_vehicle_plate_no = $row['siv_vehicle_plate_no'];
////    $issued_by = $row['issued_by'];
//    $issued_by = '';
    //receiveArr
//    $receiveArr[] = $row;
//}
}
// Get district Name
//$getDist = "SELECT
//			tbl_locations.LocName
//		FROM
//			tbl_warehouse
//		INNER JOIN tbl_locations ON tbl_warehouse.dist_id = tbl_locations.PkLocID
//		WHERE
//			tbl_warehouse.wh_id = $wh_to_id";
////query result
//$rowDist = mysql_fetch_object(mysql_query($getDist));
$rowDist = 'XYZ';
?>
<!--<br><br><br><br><br><br>-->

<div style="float:right; margin-top:20px;" id="printButt">
    <button type="button"class="btn btn-warning sprintbuttonstyle" onclick="javascript:printCont();"> Print </button>
</div>

<div id="content_print">
<!--<div class="wrapper">
    <div class="container-fluid">-->
	<?php 
        //include header
//        include(PUBLIC_PATH."/html/header.php");
        //include top_im
//        include PUBLIC_PATH."html/top_im.php";?>
	<!--<div style="float:right; font-size:12px;">QR/015/01.08.2</div>-->
	<style type="text/css" media="print">
    @media print
    {    
        #printButt
        {
            display: none !important;
        }
    }
    </style>
	<?php
		$rptName = 'Detail Distribution Report ';
//    	include('report_header');
                ?>
               
    
                
         <div style="line-height:1;">
    <div id="logoLeft" style="float:left; width:107px; text-align:right;">
    <!--<img src="<?php echo PUBLIC_URL;?>images/gop.png" />-->
        <img id="pics" style="border-radius: 50%;" src="<?php echo base_url('assets/images/lmis.jpg')?>" alt="" height="60">
    </div>
    <div id="report_type" style="float:left; width:386px; text-align:center;">
        <?php 
        if ($stkid==1 && $provid==1 && $lvl==3) 
        {
            ?>
                <span style="line-height:20px"><b>POPULATION WELFARE DEPARTMENT</b></span><br/>
                <span style="line-height:20px"><b>GOVERNMENT OF PUNJAB</b></span><br/>
        <?php }
        elseif ($stkid==145) 
        {
            ?>
                <span style="line-height:20px"><b>PRIMARY & SECONDARY HEALTHCARE DEPARTMENT</b></span><br/>
                <span style="line-height:20px"><b>GOVERNMENT OF PUNJAB</b></span><br/>
                <span style="line-height:20px"><b>MEDICAL STORE DEPO LAHORE</b></span><br/>
        <?php 
        }elseif ($stkid==1) 
        {
            ?>
                <span style="line-height:20px"><b>GOVERNMENT OF PAKISTAN</b></span><br/>
                <span style="line-height:20px"><b>CMU</b></span><br/>
                <span style="line-height:20px"><b>REGULATIONS & COORDINATION</b></span><br/>
                <span style="line-height:20px">DIRECTORATE OF CENTRAL WAREHOUSE & SUPPLIES</span><br/>
        <?php 
        } 
        else {
            ?>
                <span style="line-height:20px"><b>GOVERNMENT OF PAKISTAN</b></span><br/>
                <span style="line-height:20px"><b>MINISTRY OF NATIONAL HEALTH SERVICES REGULATIONS & COORDINATION</b></span><br/>
                <span style="line-height:20px"><b>NATIONAL TUBERCULOSIS, TB AND MALARIA CONTROL PROGRAMME</b></span><br/>
                <span style="line-height:20px">COMMON MANAGEMENT UNIT (CMU)</span><br/>
                <!--<span style="line-height:20px"><?php // echo $logo1[1]?></span><br/>-->
        <?php 
        
        }?>
        <!--<span style="line-height:15px"><b>Store: </b><?php echo $whname;?></span>-->
        <hr style="margin:3px 10px;" />
        <p><b><?php echo $rptName;?> as on: <?php echo date('d-M-Y');?></b>
        </p>
    </div>
    <div id="logoLeft" style="float:right; width:107px;">
    <!--<img src="<?php echo PUBLIC_URL;?>images/gop.png" />-->
        <img id="pics" style="border-radius: 50%;" src="<?php echo base_url('assets/images/global_fund.png')?>" alt="" height="60">
    </div>
</div>
<div style="clear:both"></div>       
                
                
                
         
<!--        <div style="text-align:center;">
            <b style="float:right;">District: <?php echo $rowDist; ?></b><br />
            <b style="float:left;">Issue Voucher: <?php echo $issue_no; ?></b>
            <b style="float:right;">Date of Departure: <?php echo date("d/m/y", strtotime($issue_date)); ?></b>
        </div>
        <div style="clear:both;">
            <b style="float:left;">Reference No.: <?php echo $tran_ref; ?></b>
            <b style="float:right;">Issue To: <?php echo $issue_to;?></b><br />
            <b style="float:right;">Issue By: <?php echo $issued_by;?></b>
        </div>-->


        <h5 class="page-title">
            Priority Vaccines Distribution (Detail)
        </h5>
        <div class="row">
            <div class="col-md-12">
                <table style="float:right;width:100%;" id="myTables" class="table-condensed" cellpadding="3">
                    <tbody>
                    <tr>
                        <th class="col-md-2" style="background: #35AA47;">Batch status</th>
                        <th class="col-md-10" style="background: #35AA47;">Description</th>
                    </tr>
                    <tr>
                        <td style="background: #ffc4c4 ;"><b>Unusable</b></td>
                        <td style="background: #ffc4c4 ;">If batch is expired.</td>
                    </tr>
                    <tr>
                        <td style="background: #F2CD00;"><b>Priority 1</b></td>
                        <td style="background: #F2CD00;">If expiry is less than 3 Months.</td>
                    </tr>
                    <tr>
                        <td style="background: #EDB459;"><b>Priority 2</b></td>
                        <td style="background: #EDB459;">If expiry is more than 3 months and less than 12 months.</td>
                    </tr>
                    <tr>
                        <td style="background: #7FC242;"><b>Priority 3</b></td>
                        <td style="background: #7FC242;">If expiry is more than 12 months.</td>
                    </tr>
                </tbody></table>
            </div>
        </div>


<br><br>


        <table id="myTable" class="table-condensed" cellpadding="3">
            <tr style="background: #35AA47;">
                <th width="8%">Sr #</th>
                <th>Stakeholder</th>
                <th>Description</th>
                <th>Strength</th>
                <th>Storage</th>
<!--                <th width="15%">UOM</th>
                <th width="15%">Pack Size</th>-->
                <th width="15%" align="center">Batch / Lot / Seriel No.</th>
                <th>Expiry Date</th>
                <th>Unit Cost</th>
                <th>Total Cost</th>
                <th width="15%">Quantity</th>
<!--                <th width="15%">Cartons</th>
                <th width="15%" align="center">Remarks</th>-->
            </tr>
            <tbody>
                <?php
                $i = 1;
				$totalQty = 0;
				$totalCartons = 0;
				$product = '';
                                $unusable_total = 0;
                                $priority1_total = 0;
                                $priority2_total = 0;
                                $priority3_total = 0;
                                $otherprod_total = 0;
                                $unusable_utotal = 0;
                                $priority1_utotal = 0;
                                $priority2_utotal = 0;
                                $priority3_utotal = 0;
                                $otherprod_utotal = 0;
                                $unusable_ctotal = 0;
                                $priority1_ctotal = 0;
                                $priority2_ctotal = 0;
                                $priority3_ctotal = 0;
                                $otherprod_ctotal = 0;
                //check receiveArr
                                if ($stocks) {
                ?>
                                    <tr>
                                        <th colspan="8" style="text-align:left;">Unusable</th>
                                    </tr>
                <?php
                    foreach ($stocks as $val) {
                        
                        if($val['expirymonths'] <= 0)
                        {
                            $unusable_total += $val['Qty'];
                            $unusable_utotal += $val['unit_price'];
                            $unusable_ctotal += $val['Qty']*$val['unit_price']*$val['conversion_rate'];
                        ?>
                        
                        <tr style="background: #ffc4c4 ;">
                            <td style="text-align:center;"><?php echo $i++; ?></td>
                            <td><?php echo $val['stakeholder_name']; ?></td>
                            <td><?php echo $val['itm_name']; ?></td>
                            <td><?php echo $val['strength']; ?></td>
                            <td><?php echo $val['storage']; ?></td>
<!--                            <td><?php echo $val['method_type']; ?></td>
                            <td style="text-align:center;"> <?php echo $val['pack_size']; ?></td>-->
                            <td style="text-align:right;"><?php echo $val['batch_no']; ?></td>
                            <td style="text-align:center;"> <?php if(!empty($val['batch_expiry'])) { echo date("d/m/y", strtotime($val['batch_expiry'])); } ?></td>
                            <td><?php echo $val['unit_price']; ?></td>
                            <td><?php echo number_format($val['Qty']*$val['unit_price']*$val['conversion_rate']); ?></td>
                            <td id="wpqty"><?php echo number_format(abs($val['Qty'])); ?></td>
<!--                            <td style="text-align:center;"> <?php echo $val['siv_no_of_cartons']; ?></td>
                            <td style="text-align:right;"><?php echo $val['received_remarks']; ?></td>-->
                        </tr>
                        <?php
                        }
                        
                    }
                    ?>
                                <tr>
                                    <th colspan="7" style="text-align:right;">
                                        Total:
                                    </th>
                                    <th  style="text-align:right;">
                                        <?php echo number_format($unusable_utotal); ?> 
                                    </th>
                                    <th  style="text-align:right;">
                                        <?php echo number_format($unusable_ctotal); ?> 
                                    </th>
                                    <th  style="text-align:right;">
                                        <?php echo number_format($unusable_total); ?> 
                                    </th>
                                </tr>
                    
                    
                        <tr>
                            <th colspan="8" style="text-align:left;">Priority 1</th>
                        </tr>
                    <?php
                
                    foreach ($stocks as $val) {
                        
                        if($val['expirymonths'] > 0 && $val['expirymonths'] <= 3 )
                        {
                            $priority1_total += $val['Qty'];
                            $priority1_utotal += $val['unit_price'];
                            $priority1_ctotal += $val['Qty']*$val['unit_price']*$val['conversion_rate'];
                        ?>
                        
                        <tr style="background: #F2CD00;">
                            <td style="text-align:center;"><?php echo $i++; ?></td>
                            <td><?php echo $val['stakeholder_name']; ?></td>
                            <td><?php echo $val['itm_name']; ?></td>
                            <td><?php echo $val['strength']; ?></td>
                            <td><?php echo $val['storage']; ?></td>
<!--                            <td><?php echo $val['method_type']; ?></td>
                            <td style="text-align:center;"> <?php echo $val['pack_size']; ?></td>-->
                            <td style="text-align:right;"><?php echo $val['batch_no']; ?></td>
                            <td style="text-align:center;"> <?php if(!empty($val['batch_expiry'])) { echo date("d/m/y", strtotime($val['batch_expiry'])); } ?></td>
                            <td><?php echo $val['unit_price']; ?></td>
                            <td><?php echo number_format($val['Qty']*$val['unit_price']*$val['conversion_rate']); ?></td>
                            <td id="wpqty"><?php echo number_format(abs($val['Qty'])); ?></td>
<!--                            <td style="text-align:center;"> <?php echo $val['siv_no_of_cartons']; ?></td>
                            <td style="text-align:right;"><?php echo $val['received_remarks']; ?></td>-->
                        </tr>
                        <?php
                        }
                        
                    }
                    
                    ?>
                        <tr>
                            <th colspan="7" style="text-align:right;">
                                Total:
                            </th>
                            <th  style="text-align:right;">
                                <?php echo number_format($priority1_utotal); ?>
                            </th>
                            <th  style="text-align:right;">
                                <?php echo number_format($priority1_ctotal); ?> 
                            </th>
                            <th  style="text-align:right;">
                                <?php echo number_format($priority1_total); ?> 
                            </th>
                        </tr>
                        <tr>
                            <th colspan="8" style="text-align:left;">Priority 2</th>
                        </tr>
                    <?php
                    
                    foreach ($stocks as $val) {
                        
                        if($val['expirymonths'] > 3 && $val['expirymonths'] <= 12 )
                        {
                            $priority2_total += $val['Qty'];
                            $priority2_utotal += $val['unit_price'];
                            $priority2_ctotal += $val['Qty']*$val['unit_price']*$val['conversion_rate'];
                        ?>
                        
                        <tr style="background: #EDB459;">
                            <td style="text-align:center;"><?php echo $i++; ?></td>
                            <td><?php echo $val['stakeholder_name']; ?></td>
                            <td><?php echo $val['itm_name']; ?></td>
                            <td><?php echo $val['strength']; ?></td>
                            <td><?php echo $val['storage']; ?></td>
<!--                            <td><?php echo $val['method_type']; ?></td>
                            <td style="text-align:center;"> <?php echo $val['pack_size']; ?></td>-->
                            <td style="text-align:right;"><?php echo $val['batch_no']; ?></td>
                            <td style="text-align:center;"> <?php if(!empty($val['batch_expiry'])) { echo date("d/m/y", strtotime($val['batch_expiry'])); } ?></td>
                            <td><?php echo $val['unit_price']; ?></td>
                            <td><?php echo number_format($val['Qty']*$val['unit_price']*$val['conversion_rate']); ?></td>
                            <td id="wpqty"><?php echo number_format(abs($val['Qty'])); ?></td>
<!--                            <td style="text-align:center;"> <?php echo $val['siv_no_of_cartons']; ?></td>
                            <td style="text-align:right;"><?php echo $val['received_remarks']; ?></td>-->
                        </tr>
                        <?php
                        }
                        
                    }
                    
                    ?>
                        <tr>
                            <th colspan="7" style="text-align:right;">
                                Total:
                            </th>
                            <th  style="text-align:right;">
                                <?php echo number_format($priority2_utotal); ?>
                            </th>
                            <th  style="text-align:right;">
                                <?php echo number_format($priority2_ctotal); ?> 
                            </th>
                            <th  style="text-align:right;">
                                <?php echo number_format($priority2_total); ?> 
                            </th>
                        </tr>
                        <tr>
                            <th colspan="8" style="text-align:left;">Priority 3</th>
                        </tr>
                    <?php
                    
                    foreach ($stocks as $val) {
                        
                        if($val['expirymonths'] > 12 )
                        {
                            $priority3_total += $val['Qty'];
                            $priority3_utotal += $val['unit_price'];
                            $priority3_ctotal += $val['Qty']*$val['unit_price']*$val['conversion_rate'];
                        ?>
                        
                        <tr style="background: #7FC242;">
                            <td style="text-align:center;"><?php echo $i++; ?></td>
                            <td><?php echo $val['stakeholder_name']; ?></td>
                            <td><?php echo $val['itm_name']; ?></td>
                            <td><?php echo $val['strength']; ?></td>
                            <td><?php echo $val['storage']; ?></td>
<!--                            <td><?php echo $val['method_type']; ?></td>
                            <td style="text-align:center;"> <?php echo $val['pack_size']; ?></td>-->
                            <td style="text-align:right;"><?php echo $val['batch_no']; ?></td>
                            <td style="text-align:center;"> <?php if(!empty($val['batch_expiry'])) { echo date("d/m/y", strtotime($val['batch_expiry'])); } ?></td>
                            <td><?php echo $val['unit_price']; ?></td>
                            <td><?php echo number_format($val['Qty']*$val['unit_price']*$val['conversion_rate']); ?></td>
                            <td id="wpqty"><?php echo number_format(abs($val['Qty'])); ?></td>
<!--                            <td style="text-align:center;"> <?php echo $val['siv_no_of_cartons']; ?></td>
                            <td style="text-align:right;"><?php echo $val['received_remarks']; ?></td>-->
                        </tr>
                        <?php
                        }
                        
                    }
                    
                    ?>
                        <tr>
                            <th colspan="7" style="text-align:right;">
                                Total:
                            </th>
                            <th  style="text-align:right;">
                                <?php echo number_format($priority3_utotal); ?>
                            </th>
                            <th  style="text-align:right;">
                                <?php echo number_format($priority3_ctotal); ?> 
                            </th>
                            <th  style="text-align:right;">
                                <?php echo number_format($priority3_total); ?> 
                            </th>
                        </tr>
<!--                        <tr>
                            <th colspan="7" style="text-align:left;">Other Products</th>
                        </tr>-->
                    <?php
                    
//                    foreach ($stocks as $val) {
//                        
//                        if($val['product_type'] != 36)
//                        {
//                            $otherprod_total += $val['Qty'];
                        ?>
                        
<!--                        <tr style="background: #DAF7A6;">
                            <td style="text-align:center;"><?php echo $i++; ?></td>
                            <td><?php echo $val['stakeholder_name']; ?></td>
                            <td><?php echo $val['itm_name']; ?></td>
                            <td><?php echo $val['storage']; ?></td>
                            <td><?php echo $val['method_type']; ?></td>
                            <td style="text-align:center;"> <?php echo $val['pack_size']; ?></td>
                            <td style="text-align:right;"><?php echo $val['batch_no']; ?></td>
                            <td style="text-align:center;"> <?php if(!empty($val['batch_expiry'])) { echo date("d/m/y", strtotime($val['batch_expiry'])); } ?></td>
                            <td id="wpqty"><?php echo number_format(abs($val['Qty'])); ?></td>
                            <td style="text-align:center;"> <?php echo $val['siv_no_of_cartons']; ?></td>
                            <td style="text-align:right;"><?php echo $val['received_remarks']; ?></td>
                        </tr>-->
                        <?php
//                        }
//                        
//                    }
                    ?>
                        
<!--                        <tr>
                            <th colspan="6" style="text-align:right;">
                                Total:
                            </th>
                            <th  style="text-align:right;">
                                <?php echo number_format($otherprod_total); ?> 
                            </th>
                        </tr>-->
                    
                <?php
                }
                ?>
<!--                <tr>
                    <th colspan="4" style="text-align:right;">Total</th>
                    <th style="text-align:right;"><?php echo number_format($totalQty);?></th>
                    <th>&nbsp;</th>
                    <th style="text-align:right;"><?php echo number_format($totalCartons);?></th>
                </tr>-->
            </tbody>
        </table>
        <?php if(!empty($comments)){?>
        <div style="font-size:12px; padding-top:3px;"><b>Comments:</b> <?php echo $comments;?></div>
        <?php }?>
        
        <?php // include('report_footer_issue.php');?>
        
        
        <div style="float:right; margin-top:20px;" id="printButt">
        	<button type="button"class="btn btn-warning sprintbuttonstyle" onclick="javascript:printCont();"> Print </button>
        </div>
    </div>
<!--</div>
</div>-->

<script src="<?php echo PUBLIC_URL;?>assets/global/plugins/jquery-1.11.0.min.js" type="text/javascript"></script>
<script language="javascript">
$(function(){
	//printCont();
})
function printCont()
{
	window.print();
}
</script>



