<?php
if (isset($result)) {

//    $row = $result->result_array();
    $row = $result[0];
    $warehouse_name = $row['wh_name'];
//    $category_id = $row['category_id'];
    $type_id = $row['wh_type_id'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Add Warehouse</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="addwarehouse" name="addwarehouse" action="<?php echo base_url("Warehouse_management/add_warehouse"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row">

                                                <div class="col-md-3" style="display:none">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="category"  >Category<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="category" id="category"  style="width:100%;padding:10%;">
                                                                <option value="2" selected>Health Facility</option>
                                                                
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
<!--                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="type"  >Type<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="type" id="type" required style="width:100%;padding:10%;">
                                                                <option value="">Select</option>
                                                                <option value="1">BHU</option>
                                                                <option value="2">RHC</option>
                                                                <option value="3">THQ</option>
                                                                <option value="4">DHQ</option>
                                                                <option value="5">Tertiary</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div> -->
 
                                                
                                              
                                                </div>
                                            
                                            
                                            <div class="form-group row"> 
                                                 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Stakeholder </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="stakeholder" id="stakeholder"  style="width:100%;padding:10%;" <?php if (isset($master_id)) echo 'disabled="true"' ?> >>
                                                            <option value="">Select</option>
                                                                <?php
                                                                foreach ($stakeholder as $row) {
                                                                    ?>
                                                                <option value="<?php echo $row['stkid'] ?>" <?php if (isset($form['stakeholder']) && $form['stakeholder'] == $row['stkid']) {echo "selected='selected'";}else if ((isset($editstkid)) && $editstkid == $row['stkid']) {echo "selected='selected'";} ?>><?php echo $row['stkname'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3" id="province_div">
                                                    <label class="example-text-input" for="province_village" required >Province <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="province" id="province_village" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php 
//                                                            $provinces = array(3 => "Khyber Pakhtunkhwa");
                                                            foreach ($provinces as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['PkLocID'] ?>" <?php if (isset($form['province']) && $form['province'] == $row['PkLocID']){ echo "selected='selected'";} ?>><?php echo $row['LocName'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div> 
                                                <div class="col-md-3" id="district_div">
                                                    <label class="example-text-input" for="district_village" required >District  </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="district" id="district_village" style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            if(isset($districts))
                                                            {
                                                                $dist_arr=$districts->result_array();
                                                                foreach ($dist_arr as $row) {
                                                                    ?>
                                                            <option value="<?php echo $row['pk_id']?>" <?php if(isset($district_id)&&$district_id==$row['pk_id']) echo 'selected="selected"'?>><?php echo $row['loc_name']?></option>
                                                                        <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="warehouse_name"   > Full Name of warehouse<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="warehouse_name" id="warehouse_name" class="form-control" required 
                                                            <?php
                                                            if (isset($result)) {
                                                                echo 'value="' . $warehouse_name . '"';
                                                            }
                                                            ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div> 
                                    </div>
                                                
                                                
                                                
                                            </div>
                                        </div>
                                    </div>

                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                    if (isset($result))
                                                        echo 'value="edit"';
                                                    ?>>
                                                        <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div> 
                                                <?php if (isset($result)) {
                                                    ?>
                                                    <input type="hidden" id="id" name="id" value="<?php echo $_GET['id']; ?>">
                                                <?php } ?>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                        </form>

                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>