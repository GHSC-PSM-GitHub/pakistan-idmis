<?php
if (isset($result)) {

//    $row = $result->result_array();
    $row = $result[0];
    $supplier_name = $row['stkname'];
    $cpname = $row['contact_person'];
    $cnnumber = $row['contact_numbers'];
    $email = $row['contact_emails'];
    $address = $row['contact_address'];
    $ntn = $row['ntn'];
    $gstn = $row['gstn'];
//    $category_id = $row['category_id'];
    $type_id = $row['stk_type_id'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Add Supplier</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="addwarehouse" name="addwarehouse" action="<?php echo base_url("Warehouse_management/add_supplier"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row">

                                                <div class="col-md-3" style="display:none">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="category"  >Category<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="category" id="category"  style="width:100%;padding:10%;">
                                                                <option value="3" selected>Supplier</option>
                                                               
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="type"  >Type<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="type" id="type" required style="width:100%;padding:10%;">
                                                                <!--<option value="">Select</option>-->
                                                                <option value="6">Supplier</option>
                                                              
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div> 
 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="supplier_name"   > Full Name of Supplier<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="supplier_name" id="supplier_name" class="form-control" required 
                                                            <?php
                                                            if (isset($result)) {
                                                                echo 'value="' . $supplier_name . '"';
                                                            }
                                                            ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div> 
                                                
                                            
                                             <div class="col-md-3">
                                                <div class="control-group">
                                                    <label>Contact Person Name</label>
                                                    <div class="controls">
                                                        <input name="cpname" <?php if (isset($result)) { echo 'value="' . $cpname . '"';}?> class="form-control input-medium" autocomplete="off" />
                                                    </div>
                                                </div>
                                            </div>
                                                <div class="col-md-3">
                                                 <div class="control-group">
                                                    <label>Contact/Phone Number</label>
                                                    <div class="controls">
                                                        <input name="cnnumber" <?php if (isset($result)) { echo 'value="' . $cnnumber . '"';}?> class="form-control input-medium" autocomplete="off" />
                                                    </div>
                                                </div>
                                            </div>
                                            </div>
						<div class="form-group row">
                                            <div class="col-md-3">
                                               <div class="control-group">
                                                     <label for="email">Email</label>
													 <div class="controls">
													<input type="email" class="form-control input-medium" id="email"  <?php if (isset($result)) { echo 'value="' . $email . '"';}?> name="email" autocomplete="off">
                                                    </div>
												</div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label>GSTN#</label>
                                                    <div class="controls">
                                                        <input name="gstn" <?php if (isset($result)) { echo 'value="' . $gstn . '"';}?> class="form-control input-medium" autocomplete="off" />
                                                    </div>
                                                </div>
                                            </div>
                                                    <div class="col-md-3">
                                                <div class="control-group">
                                                    <label>NTN#</label>
                                                    <div class="controls">
                                                        <input name="ntn" <?php if (isset($result)) { echo 'value="' . $ntn . '"';}?> class="form-control input-medium" autocomplete="off" />
                                                    </div>
                                                </div>
                                            </div>
											 <div class="col-md-3">
										   <div class="control-group">
                                                    <label>Address</label>
                                                    <div class="controls">
                                                        <input name="address" <?php if (isset($result)) { echo 'value="' . $address . '"';}?> class="form-control input-medium" autocomplete="off" />
                                                    </div>
                                                </div>
                                            </div>
                                                </div>
                                    </div>
                                                
                                                
                                                
                                            </div>
                                        </div>
                                    </div>

                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                    if (isset($result))
                                                        echo 'value="edit"';
                                                    ?>>
                                                        <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div> 
                                                <?php if (isset($result)) {
                                                    ?>
                                                    <input type="hidden" id="supplier_id" name="supplier_id" value="<?php echo $_GET['id']; ?>">
                                                <?php } ?>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                        </form>

                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>