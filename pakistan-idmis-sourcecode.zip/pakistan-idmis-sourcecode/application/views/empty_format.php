<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12">
                    <!-- Breadcrumb -->
                    <ul class="breadcrumb">
                        <li><a href="<?php echo base_url("profile/index"); ?>" class="glyphicons home"><i></i> Home</a></li>
                        <li class="divider"></li>
                        <li>PATH HERE</li>
                    </ul>
                    <div class="separator bottom"></div>
                   
                    <div class="heading-buttons">
                        <h3>TITLE HERE</h3>
                        <div class="buttons pull-right">
                            <a href="#add" data-toggle="modal" class="btn btn-primary btn-icon glyphicons circle_plus"><i></i>Add</a>
                        </div>
                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        
                        BODY HERE
                        
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>