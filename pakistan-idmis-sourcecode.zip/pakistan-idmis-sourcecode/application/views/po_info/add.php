<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
    }
  
</style>
<?php
$stkname = "";
$stktype = "";
$lvl_id  = "";
//print_r($result_edit);exit;
if (isset($result_edit)) {

    $row = $result_edit->result_array();
    $row = $row[0];
    $type = $row['type'];
    $number = $row['number'];
    $date = $row['date'];
}
else{
    $type = '';
    $number = '';
    $date = '';
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Add PO</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="add_ext_system" name="add_ext_system" action="<?php echo base_url("po_info/add"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row"> 
                                                 
<!--                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="ext_system" >Manufacturer Name <span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="manufacturer" id="manufacturer" required style="width:100%;" 
                                                               <?php
                                                               if(isset($manufacturer))
                                                               {
                                                                   echo 'value="'.$manufacturer.'"';
                                                               }
                                                               ?>
                                                               >
                                                    </div>
                                                </div> -->
<!--                                                <div class="col-md-3">
                                                <div class="control-group">
                                                    <label>Jurisdiction<font color="#FF0000">*</font></label>
                                                    <div class="controls">
                                                        <select name="lstLvl" id="lstLvl" class="form-control input-medium">
                                                            <?php
                                                            //populate lstLvl combo
                                                            foreach ($rslvl as $row) {
                                                                ?>
                                                                <option value="<?= $row['lvl_id'] ?>" <?php
                                                                if ($row['lvl_id'] == $lvl_id) {
                                                                    echo 'selected="selected"';
                                                                }
                                                                ?>>
                                                                            <?= $row['lvl_name'] ?>
                                                                </option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>
                                                        <span class="help-block">(National / Provincial / District /Field)</span> </div>
                                                </div>
                                            </div>-->
                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label>Type <font color="#FF0000">*</font></label>
                                                    <div class="controls">
                                                        <select name="po_type" class="form-control input-medium">
                                                            <option value="">Select</option>
                                                            <?php
                                                            //populate lstStktype combo
                                                            foreach ($po_arr as $row) {
                                                                ?>
                                                                <option value="<?= $row['pk_id'] ?>" <?php
                                                                if ($row['pk_id'] == $type) {
                                                                    echo 'selected="selected"';
                                                                }
                                                                ?>>
                                                                            <?= $row['name'] ?>
                                                                </option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label>Number <font color="#FF0000">*</font></label>
                                                    <div class="controls">
                                                        <input name="po_number" value="<?php if(isset($number) && !empty($number)) echo $number;?>" class="form-control input-medium" autocomplete="off" />
                                                    </div>
                                                </div>
                                            </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="po_info_date" required >Date(MM/DD/YYYY) <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="po_info_date" id="po_info_date" required  <?php // if (isset($master_id)) echo 'readonly="true"' ?>
                                                                   <?php
                                                                    if (isset($date) && !empty($date)) {
                                                                        echo 'value="' . $date . '"';
                                                                    } else {
                                                                        echo 'value="' . date("m/d/Y") . '"';
                                                                    }
                                                                    ?>
                                                                   >

                                                        </div>
                                                    </div>
                                                </div>
                                            </div> 
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                            if (isset($result))
                                                                echo 'value="edit"';
                                                            ?>>
                                                            <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div> 
                                                <?php if(isset($result_edit)){?>
                                                <input type="hidden" id="id" name="id" value="<?php echo $_REQUEST['id'] ?>">
                                                <?php
                                                }
                                                ?>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                    
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>
 