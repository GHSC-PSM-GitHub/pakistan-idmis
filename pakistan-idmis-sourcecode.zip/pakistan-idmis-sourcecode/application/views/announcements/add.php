<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Add New Announcement</h3>

                    </div> 
                    <form method="post" id="add_form" name="add_form" action="<?php echo base_url("Announcements/add");?>">
                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="form-group row"> 
                                            <div class="col-md-8">
                                                <label for="example-text-input" class="col-form-label">Announcement Text</label>
                                                <div class="controls">
                                                    <textarea class="form-control" rows="10" cols="" id="text" name="text" value=""   required="true"></textarea>
                                                </div> 
                                            </div>
                                             
                                            <div class="col-md-2" style="margin-top:3%;">
                                                <button type="submit" class="btn btn-primary waves-effect waves-light">
                                                    Submit
                                                </button>
                                                <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                    Reset
                                                </button>
                                            </div>
                                        </div> 
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div> 
        </div>
    </div>