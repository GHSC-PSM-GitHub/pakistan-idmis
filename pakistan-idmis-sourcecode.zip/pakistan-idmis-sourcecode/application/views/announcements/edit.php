<?php $result = $result[0]; ?>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Add New Announcement</h3>
                    </div> 
                    <form method="post" id="add_form" name="add_form" action="<?php //echo base_url("Lab_tests_management/add"); ?>">
                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="form-group row"> 

                                            <div class="col-md-8">
                                                <label class="control-label" for="username">Announcement Text</label>
                                                <div class="controls"> <textarea class="span12" rows="10" cols="60" id="text" name="text" ><?php echo $result['text']; ?></textarea></div>
                                            </div> 

                                            <div class="col-md-2" style="margin-top:3%;">
                                                <input type="hidden" name="edit_id" value="<?php echo $edit_id; ?>"/>
                                                <button type="submit" class="btn btn-primary waves-effect waves-light">
                                                    Submit
                                                </button>
                                                <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                    Reset
                                                </button>
                                            </div>
                                        </div> 
                                    </div>

                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div> 
        </div>
    </div>