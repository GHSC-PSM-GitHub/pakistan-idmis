<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Announcements</h3>
                        <div class="buttons pull-right">
                            <a href="<?php echo base_url("announcements/add"); ?>"   class="btn btn-primary btn-icon glyphicons circle_plus"><i class="fas fa-user-plus"></i> Add</a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                    <div class="innerLR">
                        <?php
                        if (!empty($result)) {
//                            echo '<pre>';
//                            print_r($result);
//                            echo '</pre>';
//                            exit;
                            ?>
                            <table  id="datatable-buttons"  class="table table-striped table-bordered dt-responsive nowrap">
                                <thead>
                                    <tr>
                                        <th style="width: 1%;" class="center">No.</th>
                                        <?php
                                            foreach($cols_to_display as $disp_name => $db_col){
                                                echo '<th>'.$disp_name.'</th>';
                                            }
                                        ?>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $count = 1;
                                    foreach ($result as $row) {
                                        ?>
                                        <tr class="">
                                            <td class="center"><?php echo $count; ?></td>
                                            <?php
                                                foreach($cols_to_display as $disp_name => $db_col){
                                                    echo '<td>'.$row[$db_col].'</td>';
                                                }
                                            ?>
                                            <td class="center">
                                                <a href="<?php echo base_url("announcements/edit?id=".$row['pk_id']); ?>" data-id="<?php echo $row['pk_id']; ?>" class="btn btn-sm btn-light glyphicons pen" title="edit"><i class="fa fa-edit"></i> Edit</a>
                                            
                                                <a href="<?php echo base_url("announcements/change_status?id=".$row['pk_id']."&status=0"); ?>" data-id="<?php echo $row['pk_id']; ?>" class="btn btn-sm btn-danger glyphicons pen" title="edit" onclick="return confirm('Are you sure you want to Remove this Announcement? This action is not revertible.');"><i class="fa fa-times"></i> Remove</a>
                                            </td>
                                        </tr>
                                        <?php
                                        $count++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                            <?php
                        } else {
                            echo "<hr><h5> No records found!</h5>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>