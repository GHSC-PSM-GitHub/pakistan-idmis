<?php
//    echo '<pre>';
//    print_r($total_vouchers);exit;

//-----------------------------   Total Voucher START     ------------------------
if (!empty($total_vouchers)) {
    $total_vouchers_label = '[';
    $total_vouchers_data = '[';
    foreach ($total_vouchers as $k1 => $val1) {
//            print_r($val); exit;
        $total_vouchers_data .= $val1['total'] . ",";
        $total_vouchers_label .= '"' . $val1['stkname'] . '",';
    }
    $total_vouchers_label = substr_replace($total_vouchers_label, "", -1);
    $total_vouchers_label .= ']';
    $total_vouchers_data = substr_replace($total_vouchers_data, "", -1);
    $total_vouchers_data .= ']';
} else {
    $total_vouchers_label = '["AIDS","TB","Malaria","Other"]';
    $total_vouchers_data = '[42764,28421,20258,31660]';
}
//echo $total_vouchers_label;
//echo $total_vouchers_data; exit; 

//-----------------------------   Total Voucher END     ------------------------
//-----------------------------   Monthly Transaction START     ------------------------
if (!empty($monthly_transaction)) {
    $monthly_transaction_label = '[';
    $monthly_transaction_data = '[';
    foreach ($monthly_transaction as $k2 => $val2) {
//            print_r($val); exit;
        $monthly_transaction_data .= $val2['total'] . ",";
        $monthly_transaction_label .= '"' . $val2['monthss'] . '",';
    }
    $monthly_transaction_label = substr_replace($monthly_transaction_label, "", -1);
    $monthly_transaction_label .= ']';
    $monthly_transaction_data = substr_replace($monthly_transaction_data, "", -1);
    $monthly_transaction_data .= ']';
} else {
    $monthly_transaction_label = '["Jun-22","Jul-22","Aug-22","Sep-22"]';
    $monthly_transaction_data = '[42760,21909,18500,31660]';
}
//echo $monthly_transaction_label;
//echo $monthly_transaction_data; exit; 

//-----------------------------   Monthly Transaction END     ------------------------
//-----------------------------   Type Wise Transaction START     ------------------------
if (!empty($type_wise_transaction)) {
    $type_wise_transaction_label = '[';
    $type_wise_transaction_data = '[';
    foreach ($type_wise_transaction as $k3 => $val3) {
//            print_r($val); exit;
        $type_wise_transaction_data .= $val3['total'] . ",";
        if ($val3['name'] == 3) {
        $type_wise_transaction_label .= '"' . 'GIWS' . '",';
        }
        elseif ($val3['name'] == 6) {
        $type_wise_transaction_label .= '"' . 'TAC' . '",';
        }
        elseif ($val3['name'] == 9) {
        $type_wise_transaction_label .= '"' . 'GRN' . '",';
        }
        elseif ($val3['name'] == 12) {
        $type_wise_transaction_label .= '"' . 'SIV' . '",';
        }
    }
    $type_wise_transaction_label = substr_replace($type_wise_transaction_label, "", -1);
    $type_wise_transaction_label .= ']';
    $type_wise_transaction_data = substr_replace($type_wise_transaction_data, "", -1);
    $type_wise_transaction_data .= ']';
} else {
    $type_wise_transaction_label = '["GRN","TAC","GWIS","SIV"]';
    $type_wise_transaction_data = '[7600,2090,1805,3010]';
}
//echo $type_wise_transaction_label;
//echo $type_wise_transaction_data; exit; 

//-----------------------------   Type Wise Transaction END     ------------------------
//-----------------------------   Product Wise SOH START     ------------------------
if (!empty($product_wise_soh)) {
    $product_wise_soh_label = '[';
    $product_wise_soh_data = '[';
    foreach ($product_wise_soh as $k4 => $val4) {
//            print_r($val); exit;
        $product_wise_soh_data .= $val4['total'] . ",";
        $product_wise_soh_label .= '"' . $val4['itm_name'] . '",';
    }
    $product_wise_soh_label = substr_replace($product_wise_soh_label, "", -1);
    $product_wise_soh_label .= ']';
    $product_wise_soh_data = substr_replace($product_wise_soh_data, "", -1);
    $product_wise_soh_data .= ']';
} else {
    $product_wise_soh_label = '["AIDS","TB","Malaria","Other"]';
    $product_wise_soh_data = '[42760,21909,18500,31660]';
}
//echo $product_wise_soh_label;
//echo $product_wise_soh_data; exit; 

//-----------------------------   Product Wise SOH END     ------------------------
//-----------------------------   Expire Stock START     ------------------------
if (!empty($expire_stock)) {
    $aids_1=$aids_3=$aids_6=$malaria_1=$malaria_3=$malaria_6=$tbfirst_1=$tbfirst_3=$tbfirst_6=$tbsecond_1=$tbsecond_3=$tbsecond_6=0;
    foreach ($expire_stock as $k5 => $val5) {
//            print_r($val); exit;     
        if ($val5['stkname'] == 'AIDS')
        {
            if($val5['duration'] == 'With in a month')
            {
                $aids_1 = $val5['total'];
            }elseif($val5['duration'] == 'With in 3 months')
            {
                $aids_3 = $val5['total'];
            }elseif($val5['duration'] == 'With in 6 months')
            {
                $aids_6 = $val5['total'];
            }
        }
        else if ($val5['stkname'] == 'Malaria')
        {
            if($val5['duration'] == 'With in a month')
            {
                $malaria_1 = $val5['total'];
            }elseif($val5['duration'] == 'With in 3 months')
            {
                $malaria_3 = $val5['total'];
            }elseif($val5['duration'] == 'With in 6 months')
            {
                $malaria_6 = $val5['total'];
            }
        }
        else if ($val5['stkname'] == 'TB First Line Drugs')
        {
            if($val5['duration'] == 'With in a month')
            {
                $tbfirst_1 = $val5['total'];
            }elseif($val5['duration'] == 'With in 3 months')
            {
                $tbfirst_3 = $val5['total'];
            }elseif($val5['duration'] == 'With in 6 months')
            {
                $tbfirst_6 = $val5['total'];
            }
        }
       else if ($val5['stkname'] == 'TB Second Line Drugs')
        {
            if($val5['duration'] == 'With in a month')
            {
                $tbsecond_1 = $val5['total'];
            }elseif($val5['duration'] == 'With in 3 months')
            {
                $tbsecond_3 = $val5['total'];
            }elseif($val5['duration'] == 'With in 6 months')
            {
                $tbsecond_6 = $val5['total'];
            }
        }
    }
    $aids_data = $tb_first_data = $tb_second_data = $malaria_data = '';
    $aids_data = "[" . $aids_1 . "," . $aids_3 . "," . $aids_6 . "]";
    $tb_first_data = "[" . $tbfirst_1 . "," . $tbfirst_3 . "," . $tbfirst_6 . "]";
    $tb_second_data = "[" . $tbsecond_1 . "," . $tbsecond_3 . "," . $tbsecond_6 . "]";
    $malaria_data = "[" . $malaria_1 . "," . $malaria_3 . "," . $malaria_6 . "]";
    
} else {
       $aids_data = "[" . '10' . "," . '15' . "," . '20' . "]";
    $tb_first_data = "[" . '13' . "," . '18' . "," . '15' . "]";
    $tb_second_data = "[" . '9' . "," . '10' . "," . '12' . "]";
    $malaria_data = "[" . '15' . "," . '22' . "," . '16' . "]";
}
//echo $expire_stock_label;
//echo $expire_stock_data; exit; 

//-----------------------------   Expire Stock END     ------------------------
//-----------------------------   MAX SOH START     ------------------------
if (!empty($max_soh)) {
    $max_soh_label = '[';
    $max_soh_data = '[';
    $m =1 ;
    foreach ($max_soh as $k6 => $val6) {
//            print_r($val); exit;
        if($m < 11){
        $max_soh_data .= $val6['total'] . ",";
        $max_soh_label .= '"' . $val6['itm_name'] . '",';
        $m++;
    }
    }
    $max_soh_label = substr_replace($max_soh_label, "", -1);
    $max_soh_label .= ']';
    $max_soh_data = substr_replace($max_soh_data, "", -1);
    $max_soh_data .= ']';
} else {
    $max_soh_label = '["AIDS","TB","Malaria","Other"]';
    $max_soh_data = '[760,209,180,310]';
}
//echo $max_soh_label;
//echo $max_soh_data; exit; 

//-----------------------------   MAX SOH END     ------------------------
//-----------------------------   Min SOH START     ------------------------
if (!empty($min_soh)) {
    $min_soh_label = '[';
    $min_soh_data = '[';
    $i =1 ;    
    foreach ($min_soh as $k7 => $val7) {
//            print_r($val); exit;
        if($i < 11){
        $min_soh_data .= $val7['total'] . ",";
        $min_soh_label .= '"' . $val7['itm_name'] . '",';
        $i++;
    }
    }
    $min_soh_label = substr_replace($min_soh_label, "", -1);
    $min_soh_label .= ']';
    $min_soh_data = substr_replace($min_soh_data, "", -1);
    $min_soh_data .= ']';
} else {
    $min_soh_label = '["AIDS","TB","Malaria","Other"]';
    $min_soh_data = '[42760,21909,18500,31660]';
}
//echo $min_soh_label;
//echo $min_soh_data; exit; 

//-----------------------------   Min SOH END     ------------------------
//-----------------------------   Expired Product START     ------------------------
if (!empty($expired_product)) {
    $expired_product_label = '[';
    $expired_product_data = '[';
    $mn =1 ;
    foreach ($expired_product as $k8 => $val8) {
//            print_r($val); exit;
        if($mn < 11){
            $name1 = str_replace('",', ' ', $val8['itm_name']);
        $expired_product_data .= $val8['total'] . ",";
        $expired_product_label .= '"' . $name1 . '",';
        $mn++;
    }
    }
    $expired_product_label = substr_replace($expired_product_label, "", -1);
    $expired_product_label .= ']';
    $expired_product_data = substr_replace($expired_product_data, "", -1);
    $expired_product_data .= ']';
} else {
    $expired_product_label = '["No Data","Zero","No Data"]';
    $expired_product_data = '[0,0,0]';
}
//echo $expired_product_label;
//echo $expired_product_data; exit; 

//-----------------------------   Expired Product END     ------------------------
?>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title">Dashboard</h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Graphs</a></li>
                    </ol>
                </div>
            </div>
            <!-- end row -->
        </div>

           <div class="row" >
                            <div class="col-md-12" > 
                               <form method="post"  name="form1" action="<?php echo base_url(); ?>dashboard/index">
                            <!-- Row -->
                            <div class="col-md-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="form-group row ">
                                            <!--<div class="col-md-12">-->

                                        <div class="col-md-3">
                                                <label class="example-text-input" required >From Date </label>
                                                <div class="controls">
                                                     <input class="form-control"  type="date" id ="from_date" name="from_date" value="<?php echo $from_date ?>">  
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label class="example-text-input" for="end_date"  >To Date</label>
                                                    <div class="controls">
                                                        <input class="form-control" type="date" id ="to_date" name="to_date" value="<?php echo $to_date ?>" >
                                                 

                                                    </div>
                                                </div>
                                            </div>
                                           

                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <div class="input-group input-medium" style="margin-top: 21px;float: right;">
                                                        <div class="controls">
                                                             <input class="btn btn-success form-control"  type="submit" name="save_btn1" id="save_btn1" value="Go"> 
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                            </div>
                        </div> 
         <div class="row">
            <div class="col-xl-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">Products Wise Stock on Hand</h4>
                        <canvas id="product" height="80"></canvas>
                    </div>
                </div>
            </div> <!-- end col -->
            
        </div>
          <div class="row">  
            
              <div class="col-xl-4">
                <div class="card m-b-30">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">Monthly Transactions</h4>
                        <canvas id="myChart" height="300"> </canvas>
                    </div> 
                </div> 
            </div>
            <div class="col-xl-4">
                <div class="card m-b-30">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">Total Vouchers</h4>
<!--                        <ul class="list-inline widget-chart m-t-20 m-b-15 text-center">
                            <li class="list-inline-item">
                                <h5>410</h5>
                                <p class="text-muted">Total</p>
                            </li>
                            <li class="list-inline-item">
                                <h5>50</h5>
                                <p class="text-muted">Last week</p>
                            </li>
                            <li class="list-inline-item">
                                <h5>180</h5>
                                <p class="text-muted">Last Month</p>
                            </li>
                        </ul>-->

                        <canvas id="totalvoucher" height="60"> </canvas>

                    </div>
                </div>
            </div> <!-- end col -->
           
          
            
            <div class="col-xl-4">
                <div class="card m-b-30">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">Type Wise Transactions</h4>
                        <canvas id="pie" height="160"></canvas>
                    </div>
                </div>
            </div> <!-- end col -->
          
            </div>
        
        <div class="row" >
               <div class="col-xl-6">
                <div class="card m-b-30">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">Expired Stock</h4>
                        <canvas id="new_pie" height="160"></canvas>
                    </div>
                </div>
            </div> <!-- end col -->
            <div class="col-xl-6">
                <div class="card m-b-30">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">Near to Expire (Products) </h4>
                        <canvas id="expire_product" height="150"></canvas>
                    </div>
                    <div> For Details: Click <a style="color: red" href="<?php echo base_url("reports/detail_distribution"); ?>" target="_blank" >Here</a> </div>
                </div>
                
            </div> <!-- end col -->
          
            </div>
       
      
        <div class="row">
             <div class="col-xl-6">
                <div class="card m-b-30">
                    <div class="card-body">
                        <h4 class="mt-0 header-title"> Maximum Stock on Hand Products</h4>
                        <canvas id="max_soh_products" height="160"> </canvas>
                    </div> 
                </div> 
            </div>
        
              <div class="col-xl-6">
                <div class="card m-b-30">
                    <div class="card-body">
                        <h4 class="mt-0 header-title"> Minimum Stock on Hand Products</h4>
                        <canvas id="min_soh_products" height="160"> </canvas>
                    </div> 
                </div> 
            </div>
        </div>
                <div class="row" style="display:none">      
            <div class="col-xl-3">
                <div class="card m-b-30">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">Medicines Availability at Different Level</h4>
                        <canvas id="medicine" height="160"></canvas>
                    </div>
                </div>
            </div> <!-- end col -->
            <div class="col-xl-3 ">
                <div class="card m-b-30">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">Disease Wise SOH at CMU</h4>
                        <canvas id="disease" height="160"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-xl-3">
                <div class="card m-b-30">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">Levels wise SOH</h4>
                        <canvas id="level" height="160"></canvas>
                    </div>
                </div>
            </div> <!-- end col -->
            <div class="col-xl-6">
                <div class="card m-b-30">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">Bubble </h4>
                        <canvas id="bubble" height="150"></canvas>
                    </div>
                </div>
            </div> <!-- end col -->
            <div class="col-xl-6">
                <div class="card m-b-30">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">Number of Transactions </h4>
                        <canvas id="line-chart" height="150"></canvas>
                    </div>
                </div>
            </div> <!-- end col -->
           
        </div>

    </div> <!-- end row -->  




</div>
<!-- end container-fluid -->
</div>
<!-- end wrapper -->
 <!--<script src="../plugins/chartjs/chart.min.js"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.8.0/chart.min.js"></script>

<script>

    $(document).ready(function () {
        //        "use strict";
        

  //        xxxxxxxxxxxxxxxxxxxxx  Transactions Start  (GRAPH 2)  xxxxxxxxxxxxxxxxxxxxxxxxxxxxx

        var ctx_exp = document.getElementById("expire_product").getContext("2d");

        const config_exp = {
            type: 'bar',
            data:  {
                labels: ["With in 1 Month","With in 3 Months","With in 12 Months"],
                datasets: [
                    {
                        
                        type: "bar",
                        backgroundColor: "rgba(158, 136, 155, 0.4)",
                        borderColor: "rgba(158, 136, 155, 1)",
                        borderWidth: 1,
                        label: "AIDS",
                        data: <?php echo $aids_data;?>
                    },
                    {
                        
                        type: "bar",
                        backgroundColor: "rgba(5, 45, 176, 0.4)",
                        borderColor: "rgba(5, 45, 176, 1)",
                        borderWidth: 1,
                        label: "TB First Line",
                        data: <?php echo $tb_first_data;?>
                    },
                    {
                        
                        type: "bar",
                        backgroundColor: "rgba(10, 131, 201, 0.4)",
                        borderColor: "rgba(10, 131, 201, 1)",
                        borderWidth: 1,
                        label: "TB Second Line",
                        data: <?php echo $tb_second_data;?>
                    },
                    {
                        
                        type: "bar",
                        backgroundColor: "rgba(227, 207, 30,0.4)",
                        borderColor: "rgba(227, 207, 30, 1)",
                        borderWidth: 1,
                        label: "Malaria",
                        data: <?php echo $malaria_data;?>
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                        display: true,
                    },
                    title: {
                        display: false,
                        text: 'Chart.js Bar Chart'
                    }
                }
                ,
    animations: {
      y: {
        easing: 'easeInOutBounce',
        from: (ctx) => {
          if (ctx.type === 'data') {
            if (ctx.mode === 'default' && !ctx.dropped) {
              ctx.dropped = true;
              return 0;
            }
          }
        }
      }
    }
            },
        }; // end of var config

        function chartClickEventtest(event, array)
        {
            if (myLiveCharttest_exp === undefined || myLiveCharttest_exp == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveCharttest_exp.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
//                        window.open("../dashboard/province_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveCharttest_exp = new Chart(ctx_exp, config_exp);
 
        //        xxxxxxxxxxxxxxxxxxxx   Transactions END GRAPH 2    xxxxxxxxxxxxxxxxxxxxxxxxxx 
        //        xxxxxxxxxxxxxxxxxxxxx  Total Voucher START   GRAPH 1     xxxxxxxxxxxxxxxxxxxxxxx    
var genderCanvas = document.getElementById("totalvoucher");
        var genderData = {
            labels:    <?php echo $total_vouchers_label;?>,
            datasets: [{
                    data: <?php echo $total_vouchers_data;?>,
                    backgroundColor: [
                        "rgba(255, 0, 0, 0.5)",
                        "rgba(100, 255, 0, 0.5)",
                        "rgba(200, 50, 255, 0.5)",
                        "rgba(0, 100, 255, 0.5)"
                    ]
                }]
        };
 
        var polarAreaChart = new Chart(genderCanvas, {
            type: 'polarArea',
            data: genderData
        });

        //        xxxxxxxxxxxxxxxxxxxxx  Total Voucher END  GRAPH 1  xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        
        //        xxxxxxxxxxxxxxxxxxxxx  Transactions Start  (GRAPH 2)  xxxxxxxxxxxxxxxxxxxxxxxxxxxxx

        var ctx_trans = document.getElementById("myChart").getContext("2d");

        const config_trans = {
            type: 'bar',
            data:  {
                labels: <?php echo $monthly_transaction_label;?>,
                datasets: [
                    {
                        backgroundColor: "rgba(250, 235, 32, 0.5)",
                        borderColor: "#02c58d",
                        borderWidth: 1,
                        hoverBackgroundColor: "rgba(2, 197, 141, 0.5)",
                        hoverBorderColor: "#02c58d",
                        data: <?php echo $monthly_transaction_data;?>
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                        display: false,
                    },
                    title: {
                        display: false,
                        text: 'Chart.js Bar Chart'
                    }
                }
                ,
    animations: {
      y: {
        easing: 'easeInOutBounce',
        from: (ctx) => {
          if (ctx.type === 'data') {
            if (ctx.mode === 'default' && !ctx.dropped) {
              ctx.dropped = true;
              return 0;
            }
          }
        }
      }
    },
     onClick: chartClickEventtrans
            },
        }; // end of var config

        function chartClickEventtrans(event, array)
        {
//            alert('hello');
            if (myLiveCharttrans === undefined || myLiveCharttrans == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveCharttrans.getElementsAtEventForMode(event, 'nearest', { intersect: true }, false);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
            //            window.open("../dashboard/province_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveCharttrans = new Chart(ctx_trans, config_trans);
 
        //        xxxxxxxxxxxxxxxxxxxx   Transactions END GRAPH 2    xxxxxxxxxxxxxxxxxxxxxxxxxx 
        
//-------------------------  Products SOH START   -------------------------------        
  var ctx_product = document.getElementById("product").getContext("2d");

        const config_product = {
            type: 'bar',
            data:  {
                labels: <?php echo $product_wise_soh_label; ?>,
                datasets: [
                    {
                        label: 'Quantity',
                        backgroundColor: "rgba(2, 197, 141, 0.4)",
                        borderColor: "#02c58d",
                        borderWidth: 1,
                        hoverBackgroundColor: "rgba(250, 235, 32, 0.7)",
                        hoverBorderColor: "#02c58d",
                        data: <?php echo $product_wise_soh_data; ?>
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                        display: false,
                    },
                    title: {
                        display: false,
                        text: 'Chart.js Bar Chart'
                    }
                }
                ,
    animations: {
      y: {
        easing: 'easeInOutBounce',
        from: (ctx) => {
          if (ctx.type === 'data') {
            if (ctx.mode === 'default' && !ctx.dropped) {
              ctx.dropped = true;
              return 0;
            }
          }
        }
      }
    }
            },
        }; // end of var config

        function chartClickEventtest(event, array)
        {
            if (myLiveCharttest_product === undefined || myLiveCharttest_product == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveCharttest_product.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
            //            window.open("../dashboard/province_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveCharttest_product = new Chart(ctx_product, config_product);
 
//---------------------------  Products SOH END     ------------------------------

         //        xxxxxxxxxxxxxxxxxxxxx  Transactions Start  (GRAPH 2)  xxxxxxxxxxxxxxxxxxxxxxxxxxxxx

        var ctx_max = document.getElementById("max_soh_products").getContext("2d");

        const config_max = {
            type: 'bar',
            data:  {
                labels: <?php echo $max_soh_label;?>,
                datasets: [
                    {
                        backgroundColor: "rgba(80, 197, 2, 0.4)",
                        borderColor: "#02c58d",
                        borderWidth: 1,
                        hoverBackgroundColor: "rgba(2, 197, 141, 0.5)",
                        hoverBorderColor: "#02c58d",
                        data: <?php echo $max_soh_data;?>
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                        display: false,
                    },
                    title: {
                        display: false,
                        text: 'Chart.js Bar Chart'
                    }
                }
                ,
    animations: {
      y: {
        easing: 'easeInOutBounce',
        from: (ctx) => {
          if (ctx.type === 'data') {
            if (ctx.mode === 'default' && !ctx.dropped) {
              ctx.dropped = true;
              return 0;
            }
          }
        }
      }
    }
            },
        }; // end of var config

        function chartClickEventtest(event, array)
        {
            if (myLiveCharttest_max === undefined || myLiveCharttest_max == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveCharttest_max.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
            //            window.open("../dashboard/province_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveCharttest_max = new Chart(ctx_max, config_max);
 
        //        xxxxxxxxxxxxxxxxxxxx   Transactions END GRAPH 2    xxxxxxxxxxxxxxxxxxxxxxxxxx 

  //        xxxxxxxxxxxxxxxxxxxxx  Minimum SOH Start  (GRAPH 2)  xxxxxxxxxxxxxxxxxxxxxxxxxxxxx

        var ctx_min = document.getElementById("min_soh_products").getContext("2d");

        const config_min = {
            type: 'bar',
            data:  {
                labels: <?php echo $min_soh_label;?>,
                datasets: [
                    {
                        backgroundColor: "rgba(197, 2, 87, 0.4)",
                        borderColor: "#02c58d",
                        borderWidth: 1,
                        hoverBackgroundColor: "rgba(197, 2, 87, 0.5)",
                        hoverBorderColor: "#02c58d",
                        data: <?php echo $min_soh_data;?>
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                        display: false,
                    },
                    title: {
                        display: false,
                        text: 'Chart.js Bar Chart'
                    }
                }
                ,
    animations: {
      y: {
        easing: 'easeInOutBounce',
        from: (ctx) => {
          if (ctx.type === 'data') {
            if (ctx.mode === 'default' && !ctx.dropped) {
              ctx.dropped = true;
              return 0;
            }
          }
        }
      }
    }
            },
        }; // end of var config

        function chartClickEventtest(event, array)
        {
            if (myLiveCharttest_min === undefined || myLiveCharttest_min == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveCharttest_min.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
            //            window.open("../dashboard/province_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveCharttest_min = new Chart(ctx_min, config_min);
 
        //        xxxxxxxxxxxxxxxxxxxx   Minimun SOH END    xxxxxxxxxxxxxxxxxxxxxxxxxx 
        //        xxxxxxxxxxxxxxxxxxxxx  Process wise Voucher Start  GRAPH 3  xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        var appCanvas = document.getElementById("pie");
        var appData = {
            labels:    <?php echo $type_wise_transaction_label;?>,
            datasets: [{
                    data: <?php echo $type_wise_transaction_data;?>,
                    backgroundColor: [
                        "rgba(255, 166, 0, 0.7)",
                        "rgba(255, 124, 67,0.7)",
                        "rgba(249, 93, 106, 0.7)",
                        "rgba(212, 80, 135,0.7)",
                        "rgba(33,150,243,1)",
                        "rgba(247, 184, 35,1)",
                        "rgba(250, 85, 192,1)",
                        "rgba(245, 146, 93,1)",
                        "rgba(56, 37, 184,1)",
                        "rgba(222, 108, 27,1)"
                    ]
                }]
        };
  

        var polarAreaChart = new Chart(appCanvas, {
            type: 'pie',
            data: appData
               
        });

        //        xxxxxxxxxxxxxxxxxxxxx  Process wise Voucher END  GRAPH 3  xxxxxxxxxxxxxxxxxxxxxxxxxxxxx

       
        
        //        xxxxxxxxxxxxxxxxxxxx   Medicine CHart Start GRAPH 5  xxxxxxxxxxxxxxxxxxxxxxxxx
        var appCanvas = document.getElementById("medicine");
        var appData = {
            labels:    ["GWIS","TAC","GRN","SIV"],
            datasets: [
                {
                    label:   'Issue',
                    backgroundColor: [ '#cc7676', '#76ccae' , '#78de64' , '#dec359'],
                    data: [21, 79 , 83, 11]
                },
                {
                    label:   'Received',
                    backgroundColor: [ '#cc7676', '#76ccae' , '#78de64' , '#dec359'],
                    data: [33, 67 , 22 , 92]
                },
                {
                    backgroundColor: [ '#cc7676', '#76ccae' , '#78de64' , '#dec359'],
                    data: [20, 80 , 55 , 76]
                },
                {
                    backgroundColor: [ '#cc7676', '#76ccae' , '#78de64' , '#dec359'],
                    data: [10, 90 , 45, 22]
                }
            ]
        };

        var polarAreaChart = new Chart(appCanvas, {
            type: 'pie',
            data: appData
        });

        //   xxxxxxxxxxxxxxxxxxxxxxxxxxx         Medicines CHART END GRAPH 5    xxxxxxxxxxxxxxxxxxxxxxxxx

        //        xxxxxxxxxxxxxxxxxxxxx  SOH Disease START  (GRAPH 6  xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        var appCanvas = document.getElementById("disease");
        var diseaseData = {
            labels:    ["Disease1","Disease2","Disease3","Disease4","Disease5","Disease6"],
            datasets: [{
                    data: [170, 450,332,555,432,255],
                    backgroundColor: [
                        "rgba(247, 184, 35,1)",
                        "#4266f5",
                        "rgba(250, 85, 192,1)",
                        "#42f5a4",
                        "#fc626f",
                        "#4529ab",
                        "rgba(33,150,243,1)",
                        "rgba(222, 108, 27,1)",
                        "#3fccc0",
                        "#8251b8",
                        "#4c8ce6"
                        
                       
                       
                    ]
                }]
        };

        var polarAreaChart = new Chart(appCanvas, {
            type: 'doughnut',
            data: diseaseData
        });

        //        xxxxxxxxxxxxxxxxxxxxx  SOH Disease END  (GRAPH 6)  xxxxxxxxxxxxxxxxxxxxxxxxxxxxx

        //        xxxxxxxxxxxxxxxxxxxx   LEVEL CHart Start GRAPH 7  xxxxxxxxxxxxxxxxxxxxxxxxx
        var appCanvas = document.getElementById("level");
        var levelData = {
            labels:    ["Issue","Received","SOH"],
            datasets: [
                {
                    label:   'National',
                    backgroundColor: [ '#fae932', '#FF861A' , '#5fb4f5' ],
                    data: [ 79 , 83, 11]
                },
                {
                    label:   'Provincial',
                    backgroundColor: [ '#fae932', '#FF861A' , '#5fb4f5' ],
                    data: [33,  22 , 92]
                },
                {
                    label: 'District',
                    backgroundColor: ['#fae932', '#FF861A' , '#5fb4f5' ],
                    data: [50 , 35 , 76]
                }
            ]
        };

        var polarAreaChart = new Chart(appCanvas, {
            type: 'pie',
            data: levelData
        });

        //   xxxxxxxxxxxxxxxxxxxxxxxxxxx         LEVEL CHART END GRAPH 7    xxxxxxxxxxxxxxxxxxxxxxxxx

        //  xxxxxxxxxxxxxxxxxxxxxxxxxxxx    SOH Bubble CHART START GRAPH 8  xxxxxxxxxxxxxxxxxxxxxxxxx

        var appCanvas9 = document.getElementById("bubble");
        var levelData9 = {
            type: 'bubble',
            labels:    ["National","Provincial","District"],
            datasets: [
                {
                    label:   'AIDS',
                    backgroundColor: [ '#fae932'],
                    data: [{
                            x: 4,
                            y: 3,
                            r: 12
                        },{
                            x: 1,
                            y: 2,
                            r: 9
                        },{
                            x: 5,
                            y: 3,
                            r: 7
                        }]
                },
                {
                    label:   'TB',
                    backgroundColor: [ '#FF861A' ],
                    data: [{
                            x: 1,
                            y: 1.2,
                            r: 10
                        },{
                            x: 1.4,
                            y: 4,
                            r: 8
                        },{
                            x: 1,
                            y: 3,
                            r: 6
                        }]
                }
            ],
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Chart.js Bubble Chart'
                    }
                }
            }
        };

        var polarAreaChart = new Chart(appCanvas9, {
            type: 'bubble',
            data: levelData9
        });

        //  xxxxxxxxxxxxxxxxxxxxxxxxxxxx    SOH Bubble CHART START GRAPH 8  xxxxxxxxxxxxxxxxxxxxxxxxx
  //        xxxxxxxxxxxxxxxxxxxxx  Products START Graph 4  xxxxxxxxxxxxxxxxxxxxxxxxxxxxx

    var ctx_expiredprod = document.getElementById("new_pie").getContext("2d");

        const config_expiredprod = {
            type: 'bar',
             data:  {
                labels: <?php echo $expired_product_label;?>,
                datasets: [
                    {
                        label: 'Quantity',
                        backgroundColor: "rgba(191, 19, 19, 0.7)",
                        borderColor: "#02c58d",
                        borderWidth: 1,
                        hoverBackgroundColor: "rgba(191, 19, 19, 0.9)",
                        hoverBorderColor: "#02c58d",
                        data: <?php echo $expired_product_data;?>
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                        display: false,
                    },
                    title: {
                        display: false,
                        text: 'Chart.js Bar Chart'
                    }
                }
                ,
    animations: {
      y: {
        easing: 'easeInOutBounce',
        from: (ctx) => {
          if (ctx.type === 'data') {
            if (ctx.mode === 'default' && !ctx.dropped) {
              ctx.dropped = true;
              return 0;
            }
          }
        }
      }
    }
            },
        }; // end of var config

        function chartClickEventtest(event, array)
        {
            if (myLiveCharttest_expiredprod === undefined || myLiveCharttest_expiredprod == null)
            {
                return;
            }
            if (event === undefined || event == null)
            {
                return;
            }
            if (array === undefined || array == null)
            {
                return;
            }
            if (array.length <= 0)
            {
                return;
            }
            var active = myLiveCharttest_expiredprod.getElementAtEvent(event);
            if (active === undefined || active == null)
            {
                return;
            }
            var elementIndex = active[0]._datasetIndex;
            console.log("elementIndex: " + elementIndex + "; array length: " + array.length);
            if (array[elementIndex] === undefined || array[elementIndex] == null)
            {
                return;
            }
            var chartData = array[elementIndex]['_chart'].config.data;
            var idx = array[elementIndex]['_index'];
            var label = chartData.labels[idx];
            var value = chartData.datasets[elementIndex].data[idx];
            var series = chartData.datasets[elementIndex].label;
            var from_date = document.getElementById("from_date").value;
            var to_date = document.getElementById("to_date").value;
            //            window.open("../dashboard/province_drill/" + label + "/" + from_date + "/" + to_date, '_blank');
            console.log(url);
            alert(series + ':' + label + ':' + value);
        }
        var myLiveCharttest_expiredprod = new Chart(ctx_expiredprod, config_expiredprod);

        //        xxxxxxxxxxxxxxxxxxxxx  Products END  (GRAPH 4)  xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    });
</script>
</html>