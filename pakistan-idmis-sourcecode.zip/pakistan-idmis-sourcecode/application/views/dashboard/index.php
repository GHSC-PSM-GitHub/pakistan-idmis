
<!--<div class="wrapper">
        <div class="container-fluid">
             Page-Title 
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Dashboard</h4>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-right">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">Main</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div>
                </div>
                 end row 
            </div>

            <div class="row">
                
                <div class="col-xl-12">
                    <div class="card faq-box border-warning  m-b-30" style="height:500px; overflow: scroll;">
                        <div class="card-body">
                            <h4 class="mt-0 header-title mb-4 text-warning">Stock Status</h4>
<table width=""   class="tablex table-condensedx table-bordered table-striped">
                            <?php
//                            $stock_arr = $prod_arr = array();
//                            if(!empty($stock_fac_wise)){
//                                foreach($stock_fac_wise as $k=> $row){
//                                    $stock_arr[$row['warehouse_name']][$row['product_name']] = $row['qty'];
//                                    $prod_arr[$row['product_name']] = $row['product_name'];
//                                }
//                             }
//                              echo '<tr>';
//                                    echo '<td width="20%"><b>Center</b></td>';
//                                    foreach($prod_arr as $k => $prod){
//                                        echo '<td><b>'.$prod.'</b></td>';
//                                    }
//                                    echo '</tr>';
//                            if(!empty($stock_arr)){
//                                foreach($stock_arr as $wh => $whdata){
//                                    echo '<tr>';
//                                    echo '<td>'.$wh.'</td>';
//                                    foreach($prod_arr as $k => $prod){
//                                        $qty = 0;
//                                        if(!empty($stock_arr[$wh][$prod])) $qty = $stock_arr[$wh][$prod];
//                                        echo '<td align="right">'.number_format($qty).'</td>';
//                                    }
//                                    echo '</tr>';
//                                }
//                             }
                            ?>
                            </table>
                            
                        </div>
                    </div>
                </div>
              
                <div class="col-xl-7">
                    <div class="card faq-box border-warning  m-b-30" style="height:420px; overflow: scroll;">
                        <div class="card-body">
                            <h4 class="mt-0 header-title mb-4 text-warning">Patients Summary</h4>
                            <table width=""   class="tablex table-condensedx table-bordered table-striped">
                            <?php
//                            $r_arr = $c_arr = array();
//                            if(!empty($patients_type_wise)){
//                                foreach($patients_type_wise as $k=> $row){
//                                    $r_arr[$row['warehouse_name']] = $row['warehouse_name'];
//                                    $c_arr[$row['diabetic_type']][$row['warehouse_name']] = $row['num'];
////                                    $c_arr['Type 2'][$row['warehouse_name']] = $row['num'];
//                                }
//                             }
//                             echo '<pre>';
//print_r($c_arr);
//echo '</pre>';
//exit;
//                              echo '<tr>';
//                                    echo '<td colspan="5"> Patient Registration Summary </td>';
//                                     
//                                    echo '</tr>';
//                              echo '<tr>';
//                                    echo '<td ><b>#</b></td>';
//                                    echo '<td width="20%"><b>Center</b></td>';
//                                    echo '<td align="center"><b>Type-I</b></td>';
//                                    echo '<td align="center"><b>Type-II</b></td>';
//                                    echo '<td align="center"><b>Total Registrations</b></td>';
//                                     
//                                    echo '</tr>';
//                                    $c=1;
//                                    $t1=$t2=$t3=0;
//                            if(!empty($r_arr)){
//                                foreach($r_arr as $wh => $whdata){
//                                    echo '<tr>';
//                                    echo '<td align="center">'.$c++.'</td>';
//                                    echo '<td>'.$wh.'</td>';
//                                    echo '<td align="center">'. (!empty($c_arr['type_1'][$wh])? ($c_arr['type_1'][$wh]):'').'</td>';
//                                    echo '<td align="center">'. (!empty($c_arr['type_2'][$wh])? ($c_arr['type_2'][$wh]):'').'</td>';
//                                    @$t =  $c_arr['type_1'][$wh] + $c_arr['type_2'][$wh];
//                                    echo '<td align="center">'. $t .'</td>';
//                                    echo '</tr>';
//                                    @$t1+=$c_arr['type_1'][$wh];
//                                    @$t2+=$c_arr['type_2'][$wh];
//                                    @$t3+=$t;
//                                }
//                                
//                                    echo '<tr>';
//                                    echo '<td align="center" colspan="2">Total</td>';
//                                    echo '<td align="center">'.$t1.'</td>';
//                                    echo '<td align="center">'.$t2.'</td>';
//                                    echo '<td align="center">'.$t3.'</td>';
//                                    echo '</tr>';
//                             }
//                            ?>
                            </table>
                            
                        </div>
                    </div>
                </div>
                 end col 

                <div class="col-xl-5">
                    <div class="card faq-box border-warning  m-b-30" style="height:420px; overflow: scroll;">
                        <div class="card-body">
                            <h4 class="mt-0 header-title mb-4 text-warning">Announcements</h4>

                            
                            //<?php
//                            if(!empty($announcements)){
//                                foreach($announcements as $k=> $row){
//                                    echo '<div class=" "> <h5><span class="badge   badge-info">'.$row['username'].'('.date('d-M-Y H:i:s',strtotime($row['created_at'])).') :</h5></span>'.nl2br($row['text']).'</div>';
//                                    echo '<hr/>';
//                                }
//                             }
                            ?>
                        </div>
                    </div>
                </div>
                 end col 
                
            </div>


        </div>
         end container-fluid 
    </div>
     end wrapper 
    
    <script>
$(function() {
    console.log( "ready!" );
    var Dashboard = function () {
  };   
 Dashboard.prototype.createAreaChart = function (element, pointSize, lineWidth, data, xkey, ykeys, labels, lineColors) {
          Morris.Area({
              element: element,
              pointSize: 0,
              lineWidth: 0,
              data: data,
              xkey: xkey,
              ykeys: ykeys,
              labels: labels,
              resize: true,
              gridLineColor: '#eef0f2',
              hideHover: 'auto',
              lineColors: lineColors,
              fillOpacity: .9,
              behaveLikeLine: true
          });
      };
      Dashboard.prototype.createLineChart1 = function(element, data, xkey, ykeys, labels, lineColors) {
      Morris.Line({
          element: element,
          data: data,
          xkey: xkey,
          ykeys: ykeys,
          labels: labels,
          gridLineColor: '#eef0f2',
          hideHover: 'auto',
          pointSize: 3,
          resize: true, //defaulted to true
          lineColors: lineColors
      });
  };
var list_names= '';
var list_id = '';
var $areaData = [
    <?php
//    $vars = $vars2 = '';
//    if(!empty($stock_arr)){
//        foreach($stock_arr as $wh => $whdata){
//            echo "{y: '".$wh."',";
//            foreach($prod_arr as $k => $prod){
//                $qty = 0;
//                if(!empty($stock_arr[$wh][$prod])) $qty = $stock_arr[$wh][$prod];
//                echo "'".$prod."': '".$qty."',";
//                $vars   .= "'".$prod."', ";
//                $vars2  .= "'".$prod."', ";
//            }
//           echo " z:0},";
//        }
//    }
//    echo "list_names =".$vars;
//    echo "list_id =".$vars2;
    ?>
//              {y: '2013', a: 0, b: 0, c:0},
//              {y: '2014', a: 150, b: 45, c:15},
//              {y: '2015', a: 60, b: 150, c:220},
//              {y: '2016', a: 180, b: 36, c:21},
//              {y: '2017', a: 90, b: 60, c:960},
//              {y: '2018', a: 75, b: 240, c:120},
//              {y: '2019', a: 30, b: 30, c:30}
          ];
//          Dashboard.prototype.createLineChart1('morris-area-example', 0, 0, $areaData, 'y', ['a', 'b', 'c'], ['Series A', 'Series B', 'Series C'], ['#fcbe2d', '#02c58d', '#30419b']);

});
    </script>-->