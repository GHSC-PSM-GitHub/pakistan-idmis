

<body>

    <div class="wrapper">
        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Dashboard</h4>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-right">
                            <li class="breadcrumb-item"><a href="javascript:void(0);">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="javascript:void(0);">Graphs</a></li>
                        </ol>
                    </div>
                </div>
                <!-- end row -->
            </div>
            
                        <div class="row">
                <div class="col-xl-6">
                    <div class="card m-b-30">
                        <div class="card-body">

                            <h4 class="mt-0 header-title">Total Vouchers</h4>
                  

                            <ul class="list-inline widget-chart m-t-20 m-b-15 text-center">
                                <li class="list-inline-item">
                                    <h5>410</h5>
                                    <p class="text-muted">Total</p>
                                </li>
                                <li class="list-inline-item">
                                    <h5>50</h5>
                                    <p class="text-muted">Last week</p>
                                </li>
                                <li class="list-inline-item">
                                    <h5>180</h5>
                                    <p class="text-muted">Last Month</p>
                                </li>
                            </ul>

                            <canvas id="polarArea" height="300"> </canvas>

                        </div>
                    </div>
                </div> <!-- end col -->
                
                       <div class="col-xl-6">
                    <div class="card m-b-30">
                        <div class="card-body">

                            <h4 class="mt-0 header-title">Received & Issued</h4>
     

                            <ul class="list-inline widget-chart m-t-20 m-b-15 text-center">
                                <li class="list-inline-item">
                                    <h5>3654</h5>
                                    <p class="text-muted">Total</p>
                                </li>
                                <li class="list-inline-item">
                                    <h5>954</h5>
                                    <p class="text-muted">Issued</p>
                                </li>
                                <li class="list-inline-item">
                                    <h5>8462</h5>
                                    <p class="text-muted">Received</p>
                                </li>
                            </ul>

                            <canvas id="doughnut" height="300"></canvas>

                        </div>
                    </div>
                </div> <!-- end col -->

            
            </div> <!-- end row -->  

            <div class="row">
                <div class="col-xl-6">
                    <div class="card m-b-30">
                        <div class="card-body">

                            <h4 class="mt-0 header-title">Applications</h4>
            
                            <ul class="list-inline widget-chart m-t-20 m-b-15 text-center">
                                <li class="list-inline-item">
                                    <h5>364</h5>
                                    <p class="text-muted">GWIS</p>
                                </li>
                                <li class="list-inline-item">
                                    <h5>254</h5>
                                    <p class="text-muted">TAC</p>
                                </li>
                                <li class="list-inline-item">
                                    <h5>162</h5>
                                    <p class="text-muted">GRN</p>
                                </li>
                                
                            </ul>

                            <canvas id="pie" height="160"></canvas>

                        </div>
                    </div>
                </div> <!-- end col -->

                  <div class="col-xl-6">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <h4 class="mt-0 header-title">Month Wise Applications</h4>


                            <canvas id="bar" height="380"></canvas>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->
            
                       <div class="row" hidden>
                <div class="col-xl-6">
                    <div class="card m-b-30">
                        <div class="card-body">

                            <h4 class="mt-0 header-title">Line Chart</h4>
                          

                            <ul class="list-inline widget-chart m-t-20 m-b-15 text-center">
                                <li class="list-inline-item">
                                    <h5>3654</h5>
                                    <p class="text-muted">Marketplace</p>
                                </li>
                                <li class="list-inline-item">
                                    <h5>954</h5>
                                    <p class="text-muted">Last week</p>
                                </li>
                                <li class="list-inline-item">
                                    <h5>8462</h5>
                                    <p class="text-muted">Last Month</p>
                                </li>
                            </ul>

                            <canvas id="lineChart" height="300"></canvas>

                        </div>
                    </div>
                </div> <!-- end col -->

       
            </div> <!-- end row -->

        </div>
        <!-- end container-fluid -->
    </div>
    <!-- end wrapper -->
    <!-- chartjs js -->
    <script src="../plugins/chartjs/chart.min.js"></script>
      <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.8.0/chart.min.js"></script>-->

</body>
<script>

!function($) {
    "use strict";

    var ChartJs = function() {};

    ChartJs.prototype.respChart = function(selector,type,data, options) {
        // get selector by context
        var ctx = selector.get(0).getContext("2d");
        // pointing parent container to make chart js inherit its width
        var container = $(selector).parent();

        // enable resizing matter
        $(window).resize( generateChart );

        // this function produce the responsive Chart JS
        function generateChart(){
            // make chart width fit with its container
            var ww = selector.attr('width', $(container).width() );
            switch(type){
                case 'Line':
                    new Chart(ctx, {type: 'line', data: data, options: options});
                    break;
                case 'Doughnut':
                    new Chart(ctx, {type: 'doughnut', data: data, options: options});
                    break;
                case 'Pie':
                    new Chart(ctx, {type: 'pie', data: data, options: options});
                    break;
                case 'Bar':
                    new Chart(ctx, {type: 'bar', data: data, options: options});
                    break;
                case 'Radar':
                    new Chart(ctx, {type: 'radar', data: data, options: options});
                    break;
                case 'PolarArea':
                    new Chart(ctx, {data: data, type: 'polarArea', options: options});
                    break;
            }
            // Initiate new chart or Redraw

        };
        // run function - render chart at first load
        generateChart();
    },
    //init
    ChartJs.prototype.init = function() {
        //creating lineChart
        var lineChart = {
            labels: ["January", "February", "March", "April", "May", "June", "July", "August", "September","October"],
            datasets: [
                {
                    label: "Sales Analytics",
                    fill: true,
                    lineTension: 0.5,
                    backgroundColor: "rgba(48, 65, 155, 0.2)",
                    borderColor: "#30419b",
                    borderCapStyle: 'butt',
                    borderDash: [],
                    borderDashOffset: 0.0,
                    borderJoinStyle: 'miter',
                    pointBorderColor: "#30419b",
                    pointBackgroundColor: "#fff",
                    pointBorderWidth: 1,
                    pointHoverRadius: 5,
                    pointHoverBackgroundColor: "#30419b",
                    pointHoverBorderColor: "#30419b",
                    pointHoverBorderWidth: 2,
                    pointRadius: 1,
                    pointHitRadius: 10,
                    data: [80, 59, 80, 81, 56, 55, 40, 55, 30, 80]
                },
                {
                    label: "Monthly Earnings",
                    fill: true,
                    lineTension: 0.5,
                    backgroundColor: "rgba(240, 244, 247, 0.2)",
                    borderColor: "#f0f4f7",
                    borderCapStyle: 'butt',
                    borderDash: [],
                    borderDashOffset: 0.0,
                    borderJoinStyle: 'miter',
                    pointBorderColor: "#f0f4f7",
                    pointBackgroundColor: "#fff",
                    pointBorderWidth: 1,
                    pointHoverRadius: 5,
                    pointHoverBackgroundColor: "#f0f4f7",
                    pointHoverBorderColor: "#eef0f2",
                    pointHoverBorderWidth: 2,
                    pointRadius: 1,
                    pointHitRadius: 10,
                    data: [30, 23, 56, 65, 23, 35, 85, 25, 92, 36]
                }
            ]
        };

        var lineOpts = {
            scales: {
                yAxes: [{
                    ticks: {
                        max: 100,
                        min: 20,
                        stepSize: 10
                    }
                }]
            }
        };

        this.respChart($("#lineChart"),'Line',lineChart, lineOpts);

        //donut chart
        var donutChart = {
            labels: [
                "Received",
                "Issued"
            ],
            datasets: [
                {
                    data: [150, 250],
                    backgroundColor: [
                        "#df64ed",
                        "#46c3cf"
                    ],
                    hoverBackgroundColor: [
                         "#df64ed",
                        "#46c3cf"
                    ],
                    hoverBorderColor: "#fff"
                }]
        };
        this.respChart($("#doughnut"),'Doughnut',donutChart);


        //Pie chart
//        var pieChart = {
//            labels: [
//                "GWIS",
//                "TAC",
//                "GRN",
//                "SIV"
//            ],
//            datasets: [
//                {
//                    data: [350, 200,220,150],
//                    backgroundColor: [
//                        "#ffa600",
//                        "#ff7c43",
//                        "#f95d6a",
//                        "#d45087",
//                    ],
//                    hoverBackgroundColor: [
//                        "#02c58d",
//                        "#f0f4f7"
//                    ],
//                    hoverBorderColor: "#fff"
//                }]
//        };
//        this.respChart($("#pie"),'Pie',pieChart);

  var data = {
            datasets: [{
                    data: [350, 200,220,150],
                    backgroundColor: [
                       "#ffa600",
                        "#ff7c43",
                        "#f95d6a",
                        "#d45087",
                        "rgba(33,150,243,1)",
                        "rgba(247, 184, 35,1)",
                        "rgba(250, 85, 192,1)",
                        "rgba(245, 146, 93,1)",
                        "rgba(56, 37, 184,1)",
                        "rgba(222, 108, 27,1)"
                    ]
                }],
            labels: ["GWIS","TAC","GRN","SIV"]
        };
        var pieOptions = {
//            events: false,
            animation: {
                duration: 2000,
                animateScale:true,
                easing: "easeOutQuart",
                onComplete: function () {
                    var ctx = this.chart.ctx;
                    ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'bottom';

                    this.data.datasets.forEach(function (dataset) {

                        for (var i = 0; i < dataset.data.length; i++) {
                            var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
                            total = dataset._meta[Object.keys(dataset._meta)[0]].total,
                            mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius) / 2,
                            start_angle = model.startAngle,
                            end_angle = model.endAngle,
                            mid_angle = start_angle + (end_angle - start_angle) / 2;

                            var x = mid_radius * Math.cos(mid_angle);
                            var y = mid_radius * Math.sin(mid_angle);

                            ctx.fillStyle = '#fff';
                            if (i == 3) { // Darker text color for lighter background
                                ctx.fillStyle = '#444';
                            }

                            var val = dataset.data[i];
                            var percent = String(Math.round(val / total * 100)) + "%";

                            if (val != 0) {
                                //                                ctx.fillText(dataset.data[i], model.x + x, model.y + y);
                                // Display percent in another line, line break doesn't work for fillText
                                ctx.fillText(percent, model.x + x, model.y + y + 15);
                            }
                        }
                    });
                }
            }
        };
        $(document).ready(
        function () {
            var canvas = document.getElementById("pie");
            var ctx = canvas.getContext("2d");
            var myNewChart = new Chart(ctx, {
                type: 'pie',
                data: data,
                options: pieOptions
            });

            canvas.onclick = function (evt) {
                var activePoints = myNewChart.getElementsAtEvent(evt);
                if (activePoints[0]) {
                    var chartData = activePoints[0]['_chart'].config.data;
                    var idx = activePoints[0]['_index'];

                    var label = chartData.labels[idx];
                    var value = chartData.datasets[0].data[idx];
//                    var from_date = document.getElementById("from_date").value;
//                    var to_date = document.getElementById("to_date").value;

                    //                            var url = "http://example.com/?label=" + label + "&value=" + value;
                    if (label != 'Submitted ( unassigned )') {
                        window.open("../dashboard/index/" , '_blank');
                    } else {
                        window.open("../dashboard/total_submitted/Submitted/" + from_date + "/" + to_date, '_blank');
                    }
                    console.log(url);
                    alert(url);
                }
            };
        }
    );

        //                  ------------------- PIE CHART END --------------------

        //barchart
        var barChart = {
            labels: ["January", "February", "March", "April", "May", "June", "July"],
            datasets: [
                {
                    label: "Applications",
                    backgroundColor: "rgba(2, 197, 141, 0.4)",
                    borderColor: "#02c58d",
                    borderWidth: 1,
                    hoverBackgroundColor: "rgba(2, 197, 141, 0.5)",
                    hoverBorderColor: "#02c58d",
                    data: [55, 63, 83, 65, 76, 80, 50,20]
                }
            ]
        };
        this.respChart($("#bar"),'Bar',barChart);



        //Polar area  chart
        var polarChart = {
            datasets: [{
                data: [
                    45,
                    20,
                    30,
                    25
                ],
                backgroundColor: [
                    
                    '#a05195',
'#d45087',
'#f95d6a',
'#ff7c43',
                ],
                label: 'My dataset', // for legend
                hoverBorderColor: "#fff"
            }],
            labels: [
                "AIDS",
                "TB",
                "Malaria",
                "COVID"
            ]
        };
        this.respChart($("#polarArea"),'PolarArea',polarChart);
    },
    $.ChartJs = new ChartJs, $.ChartJs.Constructor = ChartJs

}(window.jQuery),

//initializing
function($) {
    "use strict";
    $.ChartJs.init()
}(window.jQuery);

</script>
</html>