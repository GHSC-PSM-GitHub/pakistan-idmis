<?php
if (isset($result)) {
    $result = $result[0];
//    print_r($result);
    $user_name = $result['username'];
    $designation = $result['designation'];
    $login_id = $result['login_id'];
    $email_id = $result['email'];
    $contact_number = $result['phone'];
    $district_id = $result['district_id'];
    $province_id = $result['province_id'];
    $role_id = $result['role_id'];
    $status = $result['is_active'];
    $warehouse_id = $result['warehouse_id'];
    $stakeholder_id = $result['stakeholder_id'];
}
?>
<style>
	.required:after {
		content:" *";
		color: red;
	}
</style>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3><?= (!isset($result) ? 'Add' : 'Edit') ?> users</h3>

                    </div> 
                     <?php
                      if(isset($result) && $result['pk_id']==1){
                          ?>
                      
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-b-30">
                                <div class="card-body">
                                   
                                    You are not allowed to modify configurations of Super Admin 
                                  
                                </div> 
                            </div> 
                        </div> 
                    </div> 
                    <?php
                      }else{
                      ?>
                    <form method="post" id="add_user_form" name="add_user_form" action="<?php echo base_url("Users_management/add"); ?>">
                        <div class="row">
                            <div class="col-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="form-group row"> 
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label required">Full Name</label>
                                                <div class="controls">
                                                    <input class="form-control" id="username" name="username" value="<?php if (isset($user_name)) echo $user_name; ?>" type="text" required="true"/>
                                                </div> 
                                            </div>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Designation</label> 
                                                <div class="controls">
                                                    <input class="form-control" id="designation" name="designation" value="<?php if (isset($designation)) echo $designation; ?>" type="text" /></div>                                                
                                            </div>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label required">Login ID</label>

                                                <div class="controls">
                                                    <input class="form-control" id="login_id" name="login_id" value="<?php if (isset($login_id)) echo $login_id; ?>" <?php if (isset($login_id)) echo 'readonly'; ?> type="text" required="true"/></div>
                                            </div> 
                                        </div> 
                                        <div class="form-group row"> 
                                            <?php
                                            if (!isset($result)) {
                                                ?>
                                                <div class="col-md-4">
                                                    <label for="example-text-input" class="col-form-label required">Password</label>

                                                    <div class="controls"><input class="form-control" id="password" name="password" value="" type="password" placeholder="Enter password" required="true"/>
                                                    </div>
                                                </div>  
                                                <div class="col-md-4">
                                                    <label for="example-text-input" class="col-form-label required">Confirm Password</label>

                                                    <div class="controls">
                                                        <input class="form-control" id="confirm_password" name="confirm_password" value="" type="password" placeholder="Confirm password" required="true"/>
                                                    </div>
                                                </div>
                                            <?php }
                                            ?>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label required">Email</label>

                                                <div class="controls"><input class="form-control" id="email" name="email" value="<?php if (isset($email_id)) echo $email_id; ?>" type="email" required="true"/></div>
                                            </div>


                                        </div>
                                        <div class="form-group row"> 
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label required">Contact No.</label>

                                                <div class="controls"><input class="form-control" id="phone" name="phone" value="<?php if (isset($contact_number)) echo $contact_number; ?>" type="number" required="true"/></div>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label required">Province</label>
                                                <select class="form-control" id="province" name="province" required onchange="warehouse_by_province(this.value)">
                                                    <option value="">Select</option>
													<?php
													foreach ($provinces as $province){
														if ($province['LocLvl'] == 2){
															echo '<option value="' . $province['PkLocID'] . '">'. $province['LocName'] .'</option>';
														}
													}
													?>
                                                </select>
                                            </div>
                                            
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label required">Center </label>
                                                <div class="controls">
                                                    <select disabled class="form-control" id="hf" name="hf" required="true" >
                                                        <option value="">Select</option>
                                                        <?php
                                                        foreach ($warehouse as $row) {
                                                            ?>
                                                            <option class="<?= $row['prov_id'] ?>" value="<?php echo $row['wh_id'] ?>" <?php if (isset($warehouse_id) && $warehouse_id == $row['wh_id']) echo "selected='selected'"; ?>><?php echo $row['warehouse_name'] ?></option>
                                                            <?php
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
<!--                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">District:</label>

                                                <select class="form-control" id="district" name="district" required>
                                                    <option value="">Select</option>
                                                    <?php
                                                    if (isset($result)) {
                                                        foreach ($districts as $row) {
                                                            ?>
                                                            <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($district_id) && $district_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['location_name'] ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div> -->

                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-4"> 
                                                <label for="example-text-input" class="col-form-label required">Role</label>

                                                <div class="controls">
                                                    <select name="role_id" class="select2me input-medium" id="role_id" required style="width:100%;padding:10%;">
                                                        <option value="">Select</option>
                                                            <?php
                                                            foreach ($roles as $row) {
                                                                ?>
                                                            <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($role_id) && $role_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['role_name'] ?></option>
                                                            <?php
                                                        }
                                                        ?>
                                                    </select>  
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-4">
                                                <label for="example-text-input"  class="col-form-label required" >Stakeholder Name </label>
                                                <div class="controls">
                                                    <select name="stkid[]" multiple="" class="select2me input-medium" id="stkid" required style="width:100%;padding:10%;">
                                                        <option value="">Select</option>
                                                            <?php
                                                            foreach ($stakeholder as $row) {
                                                                //Display Stakeholder Info
//                                                                foreach ($stakeholder_id as $stakeholder_idd)
//                                                                {
                                                                    if($row['stkid'] == $stakeholder_id){
                                                                      $selected = "selected";
                                                                    }else{
                                                                      $selected = "";
                                                                    }
//                                                                }
                                                            ?>
                                                            <option value="<?php echo $row['stkid'] ?>" <?php echo $selected; ?>><?php echo $row['stkname'] ?></option>
                                                            <?php
                                                        }
                                                        ?>
                                                    </select>  
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="example-text-input" class="col-form-label">Status</label>

                                                <div class="controls">
                                                    <select class="form-control" id="status" name="status" required="true">
                                                        <option value="1"  <?php if (isset($status) && $status == 1) echo "selected='selected'"; ?>>Active</option>
                                                        <option value="0"  <?php if (isset($status) && $status == 0) echo "selected='selected'"; ?>>Inactive</option>                                
                                                    </select>
                                                </div>
                                            </div> 
                                            
                                            <div class="col-md-2">
                                                <?php if (isset($result)) { ?>
                                                    <input type="hidden" id="user_id" name="user_id" value="<?php echo $result['pk_id'] ?>">
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-10"></div>
                                            <div class="col-md-2" style="margin-top:3%;">
                                                <button type="submit" class="btn btn-primary waves-effect waves-light">
                                                    Submit
                                                </button>
                                                <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                    Reset
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <?php
                    
                      }
                      ?>
                </div>
            </div> 
        </div>
    </div>
</div>

<script>
	function warehouse_by_province(province_id){
		if (province_id != '') {
			$('#hf').prop("disabled", false);
			$("#hf option[class=" + province_id + "]").show();
			$("#hf option[class!=" + province_id + "]").hide();
		}
		else {
			$('#hf').prop("disabled", true);
		}
	}
</script>
