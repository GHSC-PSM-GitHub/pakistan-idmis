<div class="wrapper">
    <div class="container-fluid"> 
        <div class="page-content">
            <div class="row">
                <div class="col-md-12">
                    <div class="widget">
                        <div class="widget-head">
                            <h3 class="heading">Pending Requisitions - Provincial Distribution Plans - 2022</h3>
                        </div>
                        <div class="widget-body">
                            <div id="printing" style="clear:both;margin-top:20px;">
                                <div style="margin-left:0px !important; width:100% !important;">
                                    <style>
                                        body {
                                            margin: 0px !important;
                                            font-family: Arial, Helvetica, sans-serif;
                                        }

                                        table#myTable {
                                            margin-top: 20px;
                                            border-collapse: collapse;
                                            border-spacing: 0;
                                        }

                                        table#myTable tr td, table#myTable tr th {
                                            font-size: 11px;
                                            padding-left: 5px;
                                            text-align: left;
                                            border: 1px solid #999;
                                        }

                                        table#myTable tr td.TAR {
                                            text-align: right;
                                            padding: 5px;
                                            width: 50px !important;
                                        }

                                        .sb1NormalFont {
                                            color: #444444;
                                            font-family: Verdana, Arial, Helvetica, sans-serif;
                                            font-size: 11px;
                                            font-weight: bold;
                                            text-decoration: none;
                                        }

                                        p {
                                            margin-bottom: 5px;
                                            font-size: 11px !important;
                                            line-height: 1 !important;
                                            padding: 0 !important;
                                        }

                                        table#headerTable tr td {
                                            font-size: 11px;
                                        }

                                        /* Print styles */
                                        @media only print {
                                            table#myTable tr td, table#myTable tr th {
                                                font-size: 8px;
                                                padding-left: 2 !important;
                                                text-align: left;
                                                border: 1px solid #999;
                                            }

                                            #doNotPrint {
                                                display: none !important;
                                            }
                                        }
                                    </style>
                                    <div class="col-md-12">
                                        <div class="card m-b-30">
                                            <div class="card-body">
                                                <table width="100%" id="myTable"  class="requisitions table table-striped table-bordered table-condensed" cellspacing="0" align="center">


                                                    <thead>
                                                        <tr>
                                                            <td style="text-align:center;" >S. No.</td>
                                                            <td style="text-align:center;" >Duration From</td>
                                                            <td style="text-align:center;" >Duration To</td>
                                                            <td style="text-align:center;" >Pending Requisitions</td>
                                                            <td style="text-align:center;" >Status</td>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $count = 1;
                                                        foreach ($distribution_plan as $dp) {
                                                            ?>
                                                            <tr>
                                                                <td><?php echo $count++; ?></td>
                                                                <td><?php echo $dp['date_from']; ?></td>
                                                                <td><?php echo $dp['date_to']; ?></td>
                                                                <td><?php echo $dp['total']; ?></td>
                                                                <td>Pending Approvals</td>
                                                            </tr>
                                                        <?php } ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-12">
                                <div class="widget">
                                    <div class="widget-head">
                                        <h3 class="heading">Already Submitted Distribution Plans - 2022 </h3>
                                    </div>
                                    <div class="widget-body">

                                        <table width="100%" id="myTable" cellspacing="0" align="center" class="my_custom_datatable table table-striped table-bordered table-condensed" >
                                        </table>
                                    </div>   
                                </div>
                            </div>         
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<!-- END BODY -->
</html>