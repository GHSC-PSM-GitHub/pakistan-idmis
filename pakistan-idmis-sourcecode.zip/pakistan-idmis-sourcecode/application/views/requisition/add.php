<?php
// print_r($data1);exit; 
if (!empty($_REQUEST['year']) && !empty($_REQUEST['month']) && isset($_REQUEST['year']) && isset($_REQUEST['month'])) {
    //year
    $year = $_REQUEST['year'];
    //month
    $month = $_REQUEST['month'];
    //requisition To 
    $requisitionTo = $_REQUEST['wh_to'];
    //duration From 
    $durationFrom = date('Y-m-d', strtotime("+1 month", strtotime($year . '-' . $month . '-01')));
    //duration to
    $durationTo = date('Y-m-d', strtotime("-1 day", strtotime("+3 month", strtotime($durationFrom))));
    //duration
    $duration = date('M-Y', strtotime($durationFrom)) . ' to ' . date('M-Y', strtotime($durationTo));
}
?>
<div class="wrapper">
    <div class="container-fluid"> 
        <!-- BEGIN PAGE HEADER-->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h3 class="heading">New Requisition (3 Months)</h3>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <form name="frm" id="frm" action="" method="get">
                            <div class="form-group row">
                                <div class="col-md-3">
                                    <div class="control-group">
                                        <label class="example-text-input" for="year">Year</label>
                                        <select name="year" id="year" required="required" onchange="calc_to_month()" class="form-control input-small">
                                            <option value="">Select</option>
                                            <?php
                                            for ($i = date('Y'); $i >= 2016; $i--) {
                                                $sel = ($year == $i) ? 'selected="selected"' : '';
                                                //populate year year
                                                echo "<option value=\"$i\" $sel>$i</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="control-group">
                                        <label for="em" class="example-text-input">Ending Month</label>
                                        <select name="month" id="month" required="required" onchange="calc_to_month()" class="form-control">
                                            <option value="">Select</option>
                                            <?php
                                            for ($i = 1; $i <= 12; $i++) {
                                                if ($month == $i) {
                                                    $sel = "selected='selected'";
                                                } else {
                                                    $sel = "";
                                                }
                                                //populate month combo
                                                ?>
                                                <option value="<?php echo $i; ?>"<?php echo $sel; ?> ><?php echo date('F', mktime(0, 0, 0, $i, 1)); ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                 <div class="col-md-3 ">
                                    <div class="control-group">
                                        <label>Requisition Period</label>
                                        <div id="to_month_div">
                                            <?= (!empty($duration) ? $duration : '') ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-3">
                                    <div class="control-group">
                                        <label for="rt" class="example-text-input" >Requisition To</label>
                                        <select name="wh_to" id="wh_to" required="required" class="form-control">
                                            <option value="103114">Provincial</option>
                                        </select>
                                    </div>
                                </div>
                                <?php
                                if (!isset($_GET['view'])) {
                                    ?>
                                    <div class="col-md-3">
                                        <div class="control-group">
                                            <label>&nbsp;</label>
                                            <div class="controls">
                                                <input type="submit" id="submit" value="Create" class="btn btn-primary" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </form>
                    </div>

                </div>

            </div>

        </div>

    </div>
</div>
<?php
if (isset($_REQUEST['year']) && isset($_REQUEST['month'])) {
    ?>
    <br />
    <div class="wrapper">
        <div class="container-fluid"> 
            <div class="card m-b-30">
                <div class="card-body">
                    <div id="printing" style="clear:both;margin-top:20px;">
                        <div style="margin-left:0px !important; width:100% !important;">
                            <style>
                                table#myTable{margin-top:20px;border-collapse: collapse;border-spacing: 0; border:1px solid #999;}
                                table#myTable tr td{font-size:11px;padding:3px; text-align:left; border:1px solid #999;}
                                table#myTable tr th{font-size:11px;padding:3px; text-align:center; border:1px solid #999;}
                                table#myTable tr td.TAR{text-align:right; padding:5px;width:50px !important;}
                                .sb1NormalFont {
                                    color: #444444;
                                    font-size: 11px;
                                    font-weight: bold;
                                    text-decoration: none;
                                }

                                p{margin-bottom:5px; font-size:11px !important; line-height:1 !important; padding:0 !important;}
                                table#headerTable tr td{ font-size:11px;}


                                /* Print styles */
                                @media only print
                                {
                                    table#myTable tr th{font-size:8px;padding:3px !important; text-align:center; border:1px solid #999;}
                                    table#myTable tr td{font-size:8px;padding:3px !important; text-align:left; border:1px solid #999;}
                                    .cls_print_input{width:inherit}
                                    .remarks_box{width:inherit}
                                    #desc{width:500px !important;}
                                    #doNotPrint{display: none !important;}

                                }
                            </style>
                            <p style="color: #000000; font-size: 20px;text-align:center"><b><u>FLDs Demand Sheet</u></b><span style="float:right; font-weight:normal;">TB-11</span></p>
                            <p style="text-align:center;margin-right:35px;">(<?php // echo "For $mainStk District $distName";              ?>)</p>
                            <div style="clear:both;"></div>

                            <table width="100%" id="myTable" cellspacing="0" align="center">
                                <thead>
                                    <tr>
                                        <th style="text-align:center; width: 5%">S. No.</th>
                                        <th>Type of Patients</th>
                                        <th>Criteria</th>
                                        <th>Regimen</th>
                                        <th></th>
                                        <th style="text-align: center;">No. of Patients</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td style="text-align:center;">1</td>
                                        <td>Adult DS - TB Cases (R1)</td>
                                        <td>Newly Diagnosed Case & Sensitive to all FLDs</td>
                                        <td>2 RHZE / 4 RH</td>
                                        <td style="width: 5%"></td>
                                        <td style="text-align: center;" data-column='l8' class="patients">0</td>
                                    </tr>
                                    <tr>
                                        <td style="text-align:center;">2</td>
                                        <td>Adult Hr - TB 1 (R1 A)</td>
                                        <td>SS+ Case with R Sensitive, H & FQ Resistant</td>
                                        <td>6 RHZE</td>
                                        <td style="width: 5%"></td>
                                        <td style="text-align: center;" data-column='l9' class="patients">0</td>
                                    </tr>
                                    <tr>
                                        <td style="text-align:center;">3</td>
                                        <td>Adult Hr - TB 2  (R3)</td>
                                        <td>SS+ Case with R Sensitive, H resistant but FQ sensitive</td>
                                        <td>6 RHZE + Lfx</td>
                                        <td style="width: 5%"></td>
                                        <td style="text-align: center;" data-column='l10' class="patients">0</td>
                                    </tr>
                                    <tr>
                                        <td style="text-align:center;">4</td>
                                        <td>Pediatric TB Cases (R2A)</td>
                                        <td>Patients with 0 - 14 Years age & < 25 Kg Body Weight</td>
                                        <td>2 RHZ + E / 4 RH</td>
                                        <td style="width: 5%"></td>
                                        <td style="text-align: center;" data-column='l11' class="patients">0</td>
                                    </tr>
                                    <tr>
                                        <td style="text-align:center;">5</td>
                                        <td>Pediatric TB Cases (R2B)</td>
                                        <td>Patients with 0 - 14 Years age & > 25 Kg Body Weight</td>
                                        <td>2 RHZE / 4 RH</td>
                                        <td style="width: 5%"></td>
                                        <td style="text-align: center;" data-column='l12' class="patients">0</td>
                                    </tr>
                                    <tr>
                                        <td style="text-align:center;">6</td>
                                        <td>Ext. Adult DS TB Cases</td>
                                        <td>Adult Cases with TBM & Bone TB</td>
                                        <td>2 RHZE / 10 RH</td>
                                        <td style="width: 5%"></td>
                                        <td style="text-align: center;" data-column='l13' class="patients">0</td>
                                    </tr>
                                    <tr>
                                        <td style="text-align:center;">7</td>
                                        <td>Ext. Peds DS TB Cases</td>
                                        <td>Pediatric Cases with TBM & Bone TB</td>
                                        <td>2 RHZ + E / 10 RH</td>
                                        <td style="width: 5%"></td>
                                        <td style="text-align: center;" data-column='l14' class="patients">0</td>
                                    </tr>
                                    <tr>
                                        <td style="text-align:center;">8</td>
                                        <td>Adults Preventive Regimen</td>
                                        <td>Adult Individuals on 6 H PTT</td>
                                        <td>6 H 300</td>
                                        <td style="width: 5%"></td>
                                        <td style="text-align: center;" data-column='l15' class="patients">0</td>
                                    </tr>
                                    <tr>
                                        <td style="text-align:center;">9</td>
                                        <td>Peds Preventive Regimen</td>
                                        <td>Pediatric Individuals on 6 H PTT</td>
                                        <td>6 H 100</td>
                                        <td style="width: 5%"></td>
                                        <td style="text-align: center;" data-column='l16' class="patients">0</td>
                                    </tr>
                                    <tr>
                                        <td colspan="5"></td>
                                        <td style="text-align: center;" class="total_patients">0</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php
                    //reporting Date 
//                                    $reportingDate = $year . '-' . str_pad($month, 2, 0, STR_PAD_LEFT) . '-01';
                    $cons_level = 3;
                    if (!empty($SOHFieldArr))
                        ksort($SOHFieldArr);
                    $loop = 1;
//            echo base_url();exit;
                    ?>
                    <br />
                    <form name="frm" id="frm" method="post" action="<?php echo base_url() . 'Requisition/register' ?>">
                        <table width="100%" id="myTable" cellspacing="0" align="center">
                            <thead>
                                <tr>
                                    <th rowspan="2" style="text-align:center; width: 5%">S. No.</th>
                                    <th rowspan="2">No of Drugs</th>
                                    <th colspan="8" style="text-align: center;">Calculation of No. of Tablets</th>
                                    <th colspan="6" style="text-align: center;">Stock Details</th>
                                    <th rowspan="2">Net Demand</th>
                                    <th rowspan="2">Buffer Stock (10%)</th>
                                    <th rowspan="2">Total Demand</th>
                                </tr>
                                <tr>
                                    <th>Regimen 1 (Adult DS - TB)</th>
                                    <th>Regimen 2 (Adult Hr TB 1)</th>
                                    <th>Regimen 3 (Adult Hr TB 2)</th>
                                    <th>Pediatric (R2A)</th>
                                    <th>Pediatric (R2B)</th>
                                    <th>Extended Adult TB</th>
                                    <th>Extended Peds TB</th>
                                    <th><b>Total</b></th>
                                    <th>Opening Balance</th>
                                    <th>Received from PTP-KP</th>
                                    <th>Received from DoH</th>
                                    <th>Issued</th>
                                    <th>Expired/Near to Expiry</th>
                                    <th>Closing Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                            <input type="hidden" name="itm_id[]" value="" />
                            <?php
                            foreach ($data as $value) {
                                $total = 0;
                                ?>
                                <td style="text-align:center;"><?= $loop++; ?></td>

                                <td>
                                    <input type="checkbox" checked="checked" class="prod_chk" id="chk_<?= $value['itm_id']; ?>" name="chk[<?= $value['itm_id']; ?>]" value="<?= $value['itm_id']; ?>" >
                                    <?= $value['itm_name']; ?>
                                    <input type="hidden" id="itm_id" name="itm_id[]" value="<?= $value['itm_id']; ?>" >
                                </td>

                                <td style="text-align: right;" class="column_1">0</td>
                                <td style="text-align: right;" class="column_2">0</td>
                                <td style="text-align: right;" class="column_3">0</td>
                                <td style="text-align: right;" class="column_4">0</td>
                                <td style="text-align: right;" class="column_5">0</td>
                                <td style="text-align: right;" class="column_6">0</td>
                                <td style="text-align: right;" class="column_7">0</td>
                                <td style="text-align: right;" class="column_8">0</td>
                                <td style="text-align: right; background-color: #e28743;">

                                    <?php
                                    if (!empty($data1[$value['itm_id']]['wh_obl_a']))
                                        echo $data1[$value['itm_id']]['wh_obl_a'];
                                    else
                                        echo 0;
                                    ?></td>
                                <td style="text-align: right; background-color: #e28743;">
                                    <?php
                                    if (!empty($data1[$value['itm_id']]['wh_received']))
                                        echo $data1[$value['itm_id']]['wh_received'];
                                    else
                                        echo 0;
                                    ?></td>
                                <td style="text-align: right; background-color: #e28743;">0</td>
                                <td style="text-align: right; background-color: #e28743;">
                                    <?php
                                    if (!empty($data1[$value['itm_id']]['wh_issue_up']))
                                        echo $data1[$value['itm_id']]['wh_issue_up'];
                                    else
                                        echo 0;
                                    ?></td>
                                <td style="text-align: right; background-color: #e28743;">0</td>
                                <td style="text-align: right; background-color: #e28743;" class="closing_balance">
                                    <?php
                                    if (!empty($data1[$value['itm_id']]['wh_cbl_a']))
                                        echo $data1[$value['itm_id']]['wh_cbl_a'];
                                    else
                                        echo 0;
                                    ?></td>
                                <td style="text-align: right; background-color: #e28743;" class="net_demand">
                                    <?php
                                    if (!empty($data1[$value['itm_id']]['wh_cbl_a'])) {
                                        echo $data1[$value['itm_id']]['wh_cbl_a'];
                                        $total = $data1[$value['itm_id']]['wh_cbl_a'];
                                    } else
                                        echo 0;
                                    ?></td>
                                <td style="text-align: right; background-color: #e28743;" class="buffer_stock">
                                    <?php
                                    if (!empty($data1[$value['itm_id']]['wh_cbl_a'])) {
                                        echo (($data1[$value['itm_id']]['wh_cbl_a'] * 10) / 100);
                                        $total += (($data1[$value['itm_id']]['wh_cbl_a'] * 10) / 100);
                                    } else
                                        echo 0;
                                    ?></td>
                                <td style="text-align: right; background-color: #e28743;" class="total_demand"><?= $total; ?></td>
                                <input type="hidden" class="form-control input-sm qty cls_print_input" data-id="" name="quantity_requested[]" value="" data-orig-val="" />

                                </tr>
                                <?php
                            }
                        }
                        ?>
                        <tr id="doNotPrint">
                            <td colspan="19" style="text-align:right; border:none; padding-top:15px;">
                                <input type="hidden"  name="date_from" value="<?= !empty($durationFrom) ? $durationFrom : ''; ?>" />
                                <input type="hidden"  name="date_to" value="<?= !empty($durationFrom) ? date('Y-m-d', strtotime("-1 day", strtotime("+3 month", strtotime($durationFrom)))) : ''; ?>" />
                                <input type="hidden"  name="requisition_to" value="<?= !empty($_GET['wh_to']) ? $_GET['wh_to'] : ''; ?>" />
                                <input type="hidden"  name="wh_id" value="<?= !empty($_SESSION['warehouse_id']) ? $_SESSION['warehouse_id'] : ''; ?>" />
                                <input type="hidden"  name="requested_by" value="<?= !empty($_SESSION['id']) ? $_SESSION['id'] : ''; ?>" />
                                <input type="hidden"  name="stkId" value="<?= !empty($_SESSION['stakeholder_id']) ? $_SESSION['stakeholder_id'] : ''; ?>" />
                                <input type="submit" name="submit" value="Save" class="btn btn-primary" />
                                <input type="button" onClick="printContents()" value="Print" class="btn btn-warning" />
                            </td>
                        </tr>
                        </tbody>
                    </table>
                    <span class="text-warning">Near to expiry means expiry less than one month</span>
                </form>
            </div>
        </div>

        <?php
        if (isset($_REQUEST['err']) && $_REQUEST['err'] == '0') {
            ?>
            <script>
                var self = $('[data-toggle="notyfy"]');
                notyfy({
                    force: true,
                    text: 'CLR-6 of the items you selected already exists. ',
                    type: 'error',
                    layout: self.data('layout')
                });

            </script>
            <?php
        }
        if (isset($_REQUEST['err']) && $_REQUEST['err'] == '2') {
            ?>
            <script>
                var self = $('[data-toggle="notyfy"]');
                notyfy({
                    force: true,
                    text: 'Please select atleast one product to create CLR-6.',
                    type: 'error',
                    layout: self.data('layout')
                });

            </script>
        <?php }
        ?>
        <script>
            $(document).on('click', '.patients', function () {
                var patients_value = parseInt($(this).html());
                if (patients_value != 'NaN') {
                    $(this).html('<input type="number" name="patients" value="' + patients_value + '" />');
                    $('input[name="patients"]').focus();
                }
            });

            $(document).on('focusout', 'input[name="patients"]', function (e) {
                e.preventDefault();
                var patients_value = $(this).val();
                var parent_td = $(this).parent().html(patients_value);
                var total_patients = 0;
                $('.patients').each(function (i, obj) {
                    total_patients += parseInt($(obj).html());
                });
                $('.total_patients').html(total_patients);
                var data_column = $(parent_td).attr('data-column');
                var l_value = parseInt($(parent_td).html());
                if (data_column == 'l8') {
                    $('.column_1').each(function (i, obj) {
                        if (i == 0) {
                            $(obj).html(l_value * 180);
                        } else if (i == 3) {
                            $(obj).html(l_value * 360);
                        } else if (i == 5) {
                            $(obj).html(l_value * 0 * 3 * 30);
                        }
                    });

                    $('.column_8').each(function (i, obj) {
                        if (i == 9) {
                            $(obj).html(((l_value * 3) / 100) * 180); //(L8*3/100)*180
                        }
                    });
                } else if (data_column == 'l9') {
                    $('.column_2').each(function (i, obj) {
                        if (i == 0) {
                            $(obj).html(l_value * 540);
                        } else if (i == 3) {
                            $(obj).html(l_value * 0);
                        } else if (i == 5) {
                            $(obj).html(l_value * 0 * 3 * 30);
                        }
                    });
                } else if (data_column == 'l10') {
                    $('.column_3').each(function (i, obj) {
                        if (i == 0) {
                            $(obj).html(l_value * 540);
                        } else if (i == 3) {
                            $(obj).html(l_value * 0);
                        } else if (i == 5) {
                            $(obj).html(l_value * 6 * 3 * 30);
                        }
                    });

                    $('.column_4').each(function (i, obj) {
                        if (i == 5) {
                            $(obj).html(l_value * 0 * 3 * 30);
                        }
                    });

                    $('.column_6').each(function (i, obj) {
                        if (i == 5) {
                            $(obj).html(l_value * 0 * 3 * 30);
                        }
                    });

                    $('.column_7').each(function (i, obj) {
                        if (i == 5) {
                            $(obj).html(l_value * 0 * 3 * 30);
                        }
                    });
                } else if (data_column == 'l11') {
                    $('.column_4').each(function (i, obj) {
                        if (i == 0) {
                            $(obj).html(l_value * 0);
                        } else if (i == 1) {
                            $(obj).html(l_value * 2 * 3 * 30);
                        } else if (i == 2) {
                            $(obj).html(l_value * 4 * 3 * 30);
                        } else if (i == 3) {
                            $(obj).html(l_value * 0);
                        }
                    });
                } else if (data_column == 'l12') {
                    $('.column_5').each(function (i, obj) {
                        if (i == 0) {
                            $(obj).html(l_value * 180);
                        } else if (i == 3) {
                            $(obj).html(l_value * 360);
                        }
                    });
                } else if (data_column == 'l13') {
                    $('.column_6').each(function (i, obj) {
                        if (i == 0) {
                            $(obj).html(l_value * 180);
                        } else if (i == 2) {
                            $(obj).html(l_value * 0 * 3 * 30);
                        } else if (i == 3) {
                            $(obj).html(l_value * 720);
                        }
                    });
                } else if (data_column == 'l14') {
                    $('.column_7').each(function (i, obj) {
                        if (i == 0) {
                            $(obj).html(l_value * 0);
                        } else if (i == 1) {
                            $(obj).html(l_value * 2 * 3 * 30);
                        } else if (i == 2) {
                            $(obj).html(l_value * 10 * 3 * 30);
                        } else if (i == 3) {
                            $(obj).html(l_value * 0);
                        }
                    });

                    $('.column_6').each(function (i, obj) {
                        if (i == 1) {
                            $(obj).html(l_value * 0);
                        }
                    });
                } else if (data_column == 'l15') {
                    $('.column_8').each(function (i, obj) {
                        if (i == 6) {
                            $(obj).html(l_value * 180);
                        }
                    });
                } else if (data_column == 'l16') {
                    $('.column_8').each(function (i, obj) {
                        if (i == 7) {
                            $(obj).html(l_value * 180);
                        }
                    });
                }

                for (var loop = 0; loop < 10; loop++) {
                    if (loop != 4 && loop != 6 && loop != 7 && loop != 8 && loop != 9) {
                        var total_value = parseInt($(".column_1").slice(loop).first().html());
                        total_value += parseInt($(".column_2").slice(loop).first().html());
                        total_value += parseInt($(".column_3").slice(loop).first().html());
                        total_value += parseInt($(".column_4").slice(loop).first().html());
                        total_value += parseInt($(".column_5").slice(loop).first().html());
                        total_value += parseInt($(".column_6").slice(loop).first().html());
                        total_value += parseInt($(".column_7").slice(loop).first().html());
                        $(".column_8").slice(loop).first().html(total_value);
                    }
                }
                for (var loop = 0; loop < 10; loop++) {
                    var total_value = parseInt($(".column_8").slice(loop).first().html());
                    total_value += parseInt($(".closing_balance").slice(loop).first().html());
                    var buffer_stock = ((total_value * 10) / 100);
                    $(".net_demand").slice(loop).first().html(total_value);
                    $(".buffer_stock").slice(loop).first().html(buffer_stock);
                    $(".total_demand").slice(loop).first().html(total_value + buffer_stock);
                    $(".qty").slice(loop).first().val(total_value + buffer_stock);
                }
            });

            // $(function() {
            //     $('.qty').priceFormat({
            //         prefix: '',
            //         thousandsSeparator: ',',
            //         suffix: '',
            //         centsLimit: 0,
            //         limit: 10,
            //         clearOnEmpty: false
            //     });
            // })

            // $('.qty').change(function(){
            //     //to make the remarks required , when the quantity is changed
            //     var orig_val=$(this).data('orig-val');
            //     var now_val = $(this).val();
            //     var a=$(this).data('id');
            //     if(now_val != orig_val)
            //     {
            //         $('.remarks_box[data-id='+a+']').attr('required','required');
            //         $('#msg_'+a).html('Required');
            //     }
            //     else
            //     {
            //         $('.remarks_box[data-id='+a+']').attr('required',false);
            //         $('#msg_'+a).html('');
            //     }
            // });

            // $('.prod_chk').click(function(){
            //     var v = $(this).val();
            //     var ch = $(this).attr('checked');
            //     if(ch == 'checked'){
            //         $('.td_chk[data-itm-id='+v+']').attr('bgcolor','');

            //         $('.qty[data-id='+v+']').attr('readonly',false);
            //         $('.remarks_box[data-id='+v+']').attr('readonly',false);
            //     }
            //     else
            //     {
            //         $('.td_chk[data-itm-id='+v+']').attr('bgcolor','#eeeeee');

            //         $('.qty[data-id='+v+']').attr('readonly',true);
            //         $('.qty[data-id='+v+']').val('0');
            //         $('.remarks_box[data-id='+v+']').attr('readonly',true);
            //         $('.remarks_box[data-id='+v+']').attr('required',false);
            //     }
            //     //alert('value:'+v+',cehck:'+ch);
            // });

            function calc_to_month() {

                var a = $('#year').val() + '-' + $('#month').val() + '-01';
                var d = new Date(a);
                var months = ["January", "February", "March", "April", "May", "June",
                    "July", "August", "September", "October", "November", "December"];

                d.setMonth(d.getMonth( ) + 1);
                var m2 = d.getMonth( );
                var s2 = months[m2];
                var y = s2 + ' - ' + d.getFullYear( );

                d.setMonth(d.getMonth( ) + 2);
                var m = d.getMonth( );

                var s = months[m];
                var z = s + ' - ' + d.getFullYear( );

                console.log(y + ' to ' + z);
                $('#to_month_div').html(y + ' to ' + z);
            }
        </script>
        <!-- END JAVASCRIPTS -->
        </body>
        <!-- END BODY -->
        </html>