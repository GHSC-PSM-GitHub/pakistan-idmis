<script>
    function printContents() {
        var dispSetting = "toolbar=yes,location=no,directories=yes,menubar=yes,scrollbars=yes, left=100, top=25";
        var printingContents = document.getElementById("printing").innerHTML;

        var docprint = window.open("", "", printing);


        docprint.document.open();
        docprint.document.write('<html><head><title>CLR6</title>');

        //setting up CSS for the watermark

        docprint.document.write('</head><body onLoad="self.print();"><center>');
        docprint.document.write(printingContents);
        //docprint.document.write('<div id="watermark"><?php echo $print_word; ?></div>');
        docprint.document.write('</center>');

        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
</script>
</head>
<!-- END HEAD -->

<body class="page-header-fixed page-quick-sidebar-over-content">
    <!-- BEGIN HEADER -->
    <div class="page-container">
        <div class="page-content-wrapper">
            <div class="page-content"> 

                <!-- BEGIN PAGE HEADER-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget">
                            <div class="widget-head">
                                <h3 class="heading">Requisitions</h3>
                            </div>
                            <div class="widget-body">
                                <div id="printing" style="clear:both;margin-top:20px;">
                                    <div style="margin-left:0px !important; width:100% !important;">
                                        <style>
                                            body {
                                                margin: 0px !important;
                                                font-family: Arial, Helvetica, sans-serif;
                                            }

                                            table#myTable {
                                                margin-top: 20px;
                                                border-collapse: collapse;
                                                border-spacing: 0;
                                            }

                                            table#myTable tr td, table#myTable tr th {
                                                font-size: 11px;
                                                padding-left: 5px;
                                                text-align: left;
                                                border: 1px solid #999;
                                            }

                                            table#myTable tr td.TAR {
                                                text-align: right;
                                                padding: 5px;
                                                width: 50px !important;
                                            }

                                            .sb1NormalFont {
                                                color: #444444;
                                                font-family: Verdana, Arial, Helvetica, sans-serif;
                                                font-size: 11px;
                                                font-weight: bold;
                                                text-decoration: none;
                                            }

                                            p {
                                                margin-bottom: 5px;
                                                font-size: 11px !important;
                                                line-height: 1 !important;
                                                padding: 0 !important;
                                            }

                                            table#headerTable tr td {
                                                font-size: 11px;
                                            }

                                            /* Print styles */
                                            @media only print {
                                                table#myTable tr td, table#myTable tr th {
                                                    font-size: 8px;
                                                    padding-left: 2 !important;
                                                    text-align: left;
                                                    border: 1px solid #999;
                                                }

                                                #doNotPrint {
                                                    display: none !important;
                                                }
                                            }
                                        </style>

                                        <p style="color: #000000; font-size: 20px;text-align:center">
                                            <span style="float:left; font-weight:normal;"><i style="color:black !important"  onClick="history.go(-1)" class="fa fa-arrow-left" /></i></span>
                                            <b><u>KPTB Requisition Form</u></b>
                                            <span style="float:right; font-weight:normal;">CLR-6</span>
                                        </p>
                                        <p style="text-align:center;margin-right:35px;">
                                            (<?php echo "For $mainStk District $distName"; ?>)
                                        </p>
                                        <table width="200" id="headerTable" align="right">
                                            <tr>
                                                <td align="left"><p style="width: 100%; display: table;"> <span style="display: table-cell; width: 20px;">For: </span> <span style="display: table-cell; border-bottom: 1px solid black;"><?php // echo $duration; ?></span> </p></td>
                                            </tr>
                                            <tr>
                                                <td><p style="width: 100%; display: table;"> <span style="display: table-cell; width: 75px;">Requisition No: </span> <span style="display: table-cell; border-bottom: 1px solid black;"><?php // echo $requisitionNum; ?></span> </p></td>
                                            </tr>
                                            <tr>
                                                <td><p style="width: 100%; display: table;"> <span style="display: table-cell; width: 83px;">Requisition Date: </span> <span style="display: table-cell; border-bottom: 1px solid black;"><?php // echo $requestedOn; ?></span> </p></td>
                                            </tr>
                                        </table>
                                        <div style="clear:both;"></div>
                                        <table width="100%" id="myTable" cellspacing="0" align="center">
                                            <thead>
                                                <tr>
                                                    <td width="40" style="text-align:center;">S. No.</td>
                                                    <td width="150" id="desc">Tablets</td>
                                                    <td width="150" id="desc">Quantity Actually Required</td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            </tbody>
                                        </table>
                                        <table width="100%">
                                            <tr>
                                                <td colspan="4">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="text-align:right;" width="10%" class="sb1NormalFont">Name:</td>
                                                <td width="40%">__________________________</td>
                                                <td width="30%" style="text-align:right;" class="sb1NormalFont">Signature:</td>
                                                <td width="20%">__________________________</td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="text-align:right;" class="sb1NormalFont">Designation:</td>
                                                <td>__________________________</td>
                                                <td style="text-align:right;" class="sb1NormalFont">Date:</td>
                                                <td>__________________________</td>
                                            </tr>
                                            <tr id="doNotPrint">
                                                <td colspan="4" style="text-align:right; border:none; padding-top:15px;">
                                                    <input type="button" onClick="history.go(-1)" value="Back" class="btn btn-primary" />
                                                    <input type="button" onClick="printContents()" value="Print" class="btn btn-warning" />
                                                </td>
                                            </tr>
                                        </table>

                                        <div id="watermark" style="font-size:<?php echo $print_size; ?>px;font-color:#eeeee;opacity: 0.2;z-index: 5;right: <?php echo $print_right; ?>%;top: 30%;position: absolute;display: block;   -ms-transform: rotate(340deg);  -webkit-transform: rotate(340deg);  transform: rotate(340deg);"><?php echo $print_word; ?></div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END FOOTER -->
    <?php include PUBLIC_PATH . "/html/footer.php"; ?>
    <!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>