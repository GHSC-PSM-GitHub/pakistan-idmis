<?php
// print_r($search);exit;
//print_r($_SESSION);exit; 
?>
<div class="wrapper">
    <div class="container-fluid"> 
        <div class="page-content">
            <div class="row">
                <form name="frm" id="frm" action="" method="get">
                    <div class="col-md-12">
                        <div class="card m-b-30">
                            <div class="card-body">
                                    <h3 class="heading">Requisition Search</h3>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="input-group">
                                            <label class="control-label">Province</label>
                                            <?php
                                            if (!empty($provinces)) {
                                                foreach ($provinces as $prov) {
                                                    ?>
                                                    <select name="province" id="province" class="form-control input-medium">
                                                        <option value="" ><?php echo $prov['prov_title']; ?></option>
                                                    </select>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>

                                    <div class="col-sm-4">
                                        <div class="input-group">
                                            <label class="control-label">District</label>
                                            <select name="districts" id="districts" class="form-control input-medium">
                                                <?php
                                                foreach ($districts as $dist) {
                                                    ?>

                                                    <option value=""><?php echo $dist['LocName']; ?></option>

                                                <?php }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="input-group">
                                            <label class="control-label">Status</label>

                                            <select name="status" id="status" class="form-control input-medium">
                                                <option value="All" >All</option>
                                                <option value="Pending" >Pending</option>

                                                <option value="Prov_Approved" >Approved by Province</option>

                                                <option value="Issued" >Issued</option>
                                                <option value="Issue in Process" >Issue in Process</option>
                                                <option value="Approved" >Approved</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                           
                            <div class="row">


                                <div class="col-md-3">
                                    <div class="control-group ">
                                        <label class="control-label">Requested On (From)</label>
                                        <div class="controls">
                                            <input type="text" name="date_from" id="date_from" class="form-control input-medium" value="" />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="control-group ">
                                        <label class="control-label">Requested On (To)</label>
                                        <div class="controls">
                                            <input type="text" name="date_to" id="date_to" value="" class="form-control input-medium" />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="control-group ">
                                        <label class="control-label">Requisitions #</label>
                                        <div class="controls">
                                            <input type="text" name="req_num" id="req_num" value="" class="form-control input-medium" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                                 </div>
                            <div class="row">
                                <div class="col-md-12 right">
                                    <div class="control-group">
                                        <label class="control-label">&nbsp;</label>
                                        <div class="controls">
                                            <input type="submit" name="submit" value="Search" class="btn btn-primary" />
                                            <input type="button" onClick="window.location = '<?php echo $_SERVER['PHP_SELF']; ?>'" value="Reset" class="btn btn-info" />
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                
            </div>
</form>
        </div>
           
        <div class="row">
            <div class="col-md-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <div class="widget" data-toggle="collapse-widget">
                            <div class="widget-head">
                                <h3 class="heading">Requisitions</h3>
                            </div>
                            <div class="widget-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <table class="requisitions table table-striped table-bordered table-condensed">
                                            <thead>
                                                <tr>
                                                    <th>Sr. No.</th>
                                                    <th>Requisition No.</th>
                                                    <th>Created By</th>
                                                    <th>From</th>
                                                    <th>To</th>
                                                    <th>Store Name</th>
                                                    <th>Requested On</th>
                                                    <th>Status</th>
                                                    <th>Issue Vouchers</th>
                                                    <th>Action</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                            <input type="hidden" name="warehouse" id="warehouse" value=""/>
                                            <input type="hidden" name="clr6_id" id="clr6_id" value=""/>
                                            <input type="hidden" name="rq_no" value=""/>
                                            <?php
                                            $count = 1;
                                            foreach ($search as $list) {
                                                ?>
                                                <tr>
                                                    <td style="text-align:center;"><?php echo $count++; ?></td>
                                                    <td><?php echo $list['requisition_num']; ?></td>
                                                    <td><?php echo $list['LocName']; ?></td>
                                                    <td><?php echo $list['date_from']; ?></td>
                                                    <td><?php echo $list['date_to']; ?></td>
                                                    <td><?php echo $list['wh_name']; ?></td>
                                                    <td><?php echo $list['requested_on']; ?></td>
                                                    <td><?php echo $list['approval_status']; ?></td>
                                                    <td><?php echo 'NILL'; ?></td>
                                                    <td class="left">
                                                        <a href="requisition_view">View</a>

                                                    </td>
                                                </tr>
                                            <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
    </div>
        <script type="text/javascript">
            $(function () {
                $("#date_from, #date_to").datepicker({
                    dateFormat: 'dd/mm/yy',
                    constrainInput: false,
                    changeMonth: true,
                    changeYear: true
                });
            })
        </script>
        <script>
<?php
//check districts
$dist = '';
if (!empty($_SESSION['user_district']) && $_SESSION['user_level'] > 2) {
    $dist = $_SESSION['user_district'];
    ?>
                //show districts    
                showDistricts('<?php echo $dist; ?>');
    <?php
} else if (isset($_REQUEST['districts']) && !empty($_REQUEST['districts'])) {
    $dist = $_REQUEST['districts'];
    ?>
                //show districts    
                showDistricts('<?php echo $dist; ?>');
    <?php
}
$sel_dist = $dist;
//check item
if (isset($_REQUEST['item']) && !empty($_REQUEST['item'])) {
    ?>
                //show products
                showProducts('<?php echo $_REQUEST['item']; ?>');
    <?php
}
?>

            $(function () {
                showDistricts();
                $('#province').change(function (e) {
                    showDistricts();
                });
            })
            $(function () {
                $('#stakeholder').change(function (e) {
                    $('#item').html('<option value="">Select</option>');
                    showProducts('');
                });
            })
            $("#approve_status").click(function () {
                var id, warehouse;
                id = $("#clr6_id").val();
                warehouse = $("#warehouse").val();
                window.open('<?php echo APP_URL ?>im/print_approve_clr6.php?id=' + id + '&wh_id=' + warehouse, '_blank', 'scrollbars=1,width=842,height=595');
            });
            function showDistricts() {
                /* var pid = $('#province').val();
                 pid = <?php echo $_SESSION['user_province1']; ?>;
                 if (pid != '')
                 {
                 $.ajax({
                 url: 'fetchDistricts.php',
                 type: 'POST',
                 data: {pid: pid, distId: '<?php echo $sel_dist; ?>', user_level: '<?php echo (!empty($_SESSION['user_level']) ? $_SESSION['user_level'] : ''); ?>'},
                 success: function(data) {
                 $('#districtsCol').html(data);
                 var test = $('#districts').html();
                 $('#districts').html(test);
                 }
                 })
                 }*/
            }
            function showProducts(pid) {
                var stk = $('#stakeholder').val();
                $.ajax({
                    url: '<?php echo APP_URL; ?>reports/my_report_ajax.php',
                    type: 'POST',
                    data: {stakeholder: stk, productId: pid},
                    success: function (data) {
                        $('#item').html(data);
                    }
                })
            }
        </script>
        <?php
//check session
        if (isset($_SESSION['e']) && $_SESSION['e'] == '0') {
            ?>
            <script>
                var self = $('[data-toggle="notyfy"]');
                notyfy({
                    force: true,
                    text: 'Requisition has been successfully deleted',
                    type: 'success',
                    layout: self.data('layout')
                });
            </script>
            <?php
            unset($_SESSION['e']);
        }
        ?>

        <?php
        if (isset($_REQUEST['e']) && $_REQUEST['e'] == '1') {
            ?>
            <script>
                var self = $('[data-toggle="notyfy"]');
                notyfy({
                    force: true,
                    text: 'CLR-6 is successfully saved',
                    type: 'success',
                    layout: self.data('layout')
                });
            </script>
        <?php } ?>
        </html>