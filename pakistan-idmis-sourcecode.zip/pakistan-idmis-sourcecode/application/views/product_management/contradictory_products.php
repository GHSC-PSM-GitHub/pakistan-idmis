<?php
if (isset($result)) {

    $row = $result->result_array();
    $row = $row[0];
    $stakeholder_id = $row['stakeholder_id'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Add Conflicting Medicines Configuration</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="addmdm" name="addmdm" action="<?php echo base_url("product_management/contradictory_products"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body"> 
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Generic Name <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="generic_name_id" id="generic_name_id" required style="width:100%;padding:10%;">
                                                                <option value="">Select</option>
                                                                <?php
                                                                foreach ($generic as $row) {
                                                                    ?>
                                                                    <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($generic_name_id) && $generic_name_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['generic_name'] ?></option>
                                                                    <?php
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Contradictory Generic Name <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="generic_contradictory_id[]" id="generic_contradictory_id" required style="width:100%;padding:10%;" multiple>
                                                                <option value="">Select</option>
                                                                <?php
                                                                foreach ($generic as $row) {
                                                                    ?>
                                                                    <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($generic_name_id) && $generic_name_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['generic_name'] ?></option>
                                                                    <?php
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                    if (isset($result))
                                                        echo 'value="edit"';
                                                    ?>>
                                                        <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div> 

                                                <input type="hidden" name="generic_name" id="generic_name" value=""> 
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>