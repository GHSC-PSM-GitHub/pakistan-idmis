<?php
if (isset($result_edit)) {

    $row = $result_edit->result_array();
    $row = $row[0];
    $product_name = $row['itm_name'];
    $generic_name_id = $row['generic_name'];
    $method_type_id = $row['method_type'];
    $strength_id = $row['strength_id'];
    $manufacturer_id = $row['manufacturer_id'];
    $category_id = $row['itm_category'];
    $registration_number = $row['drug_reg_num'];
    $desc = $row['itm_des'];
    $suppliers = $row['supplier_id'];
    $product_code = $row['product_code'];
    $min_quantity = $row['min_quantity'];
    $max_quantity = $row['max_quantity'];
    $reorder_quantity = $row['reorder_quantity'];
    $cold_chain_temp = $row['cold_chain_temp'];
    $product_type_id = $row['product_type'];
    $barcode_no = $row['barcode'];
    $pack_size = $row['pack_size'];
    $carton_size = $row['carton_size'];
    $unit = $row['unit'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <!--<h3>Add Items / Medicines / Products</h3>-->
                        <h3>Add Products</h3>
                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="add_product" name="add_product" action="<?php echo base_url("product_management/add"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row">
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="acode" required >Product Auto Generated Code </label>
                                                        <div class="controls">
                                                            <input type="text" name="acode" id="acode" class="form-control" readonly value="Auto Generated" <?php if (isset($master_id)) echo 'readonly="true"' ?> 
                                                                <?php
//                                                                if (isset($refernce_number)) {
//                                                                    echo 'value="' . $refernce_number . '"';
//                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="product_type" required >Product Type <span style="color: red">*</span>  <a href="../lists_management/add/6" target="_blank" class="btn btn-sm btn-primary">+</a></label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="product_type" id="product_type" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($product_type as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($product_type_id) && $product_type_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="product_code" required >Product Code </label>
                                                        <div class="controls">
                                                            <input type="text" name="product_code" id="product_code" class="form-control"
                                                                <?php
                                                                if (isset($product_code) && !empty($product_code)) {
                                                                    echo 'value="' . $product_code . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Product Name <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="product_name" id="product_name" class="form-control" required=""  <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $product_name . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-3" id="show_genericname" style="display: none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Generic Name <span style="color: red">*</span> <a href="../productgeneric_management/add" target="_blank" class="btn btn-sm btn-primary">+</a></label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="generic_name_id" id="generic_name_id"  style="width:100%;padding:10%;">
                                                                <option value="">Select</option>
                                                                <?php
                                                                foreach ($generic as $row) {
                                                                    ?>
                                                                    <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($generic_name_id) && $generic_name_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['generic_name'] ?></option>
                                                                    <?php
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div> 
                                                <div class="col-md-3" id="show_strength" style="display: none;">
                                                    <label class="example-text-input" for="strength" required >Strength <span style="color: red">*</span>  <a href="../productstrength_management/add" target="_blank" class="btn btn-sm btn-primary">+</a></label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="strength_id" id="strength_id"  style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($strength as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($strength_id) && $strength_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['strength'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3" id="show_method" style="display: none;">
                                                    <label class="example-text-input" for="method_type" required >Method type <span style="color: red">*</span>  <a href="../productmethodtype_management/add" target="_blank" class="btn btn-sm btn-primary">+</a></label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="method_type_id" id="method_type_id"  style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($method_type as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($method_type_id) && $method_type_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['method_type'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>
<!--                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="manufacturer" required >Manufacturer  
                                                        <a href="../productmanufacturer_management/add" target="_blank" class="btn btn-sm btn-primary">+</a>
                                                    </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="manufacturer_id" id="manufacturer_id"  style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($manufacturer as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['stkid'] ?>" <?php if (isset($manufacturer_id) && $manufacturer_id == $row['stkid']) echo "selected='selected'"; ?>><?php echo $row['stkname'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                    </div>
                                                </div>-->
                                                
                                                
                                                
                                                
                                                
<!--                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="sub_category" required >Sub Category <span style="color: red">*</span>  <a href="../productsubcategory_management/add" class="btn btn-sm btn-primary">+</a></label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="sub_category_id" id="sub_category_id" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($sub_category as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($sub_category_id) && $sub_category_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['sub_category'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                    </div>
                                                </div>-->
<!--                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="registration_number" required >Registration Number </label>
                                                        <div class="controls">
                                                            <input type="text" name="registration_number" id="registration_number" class="form-control" 
                                                            <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $registration_number . '"';
                                                            }
                                                            ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>-->
                                                
                                                

                                                
<!--                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Supplier <span style="color: red">*</span> <a href="../warehouse_management/add_supplier" class="btn btn-sm btn-primary">+</a></label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="supplier_name_id" id="supplier_name_id" required style="width:100%;padding:10%;">
                                                                <option value="">Select</option>
                                                                <?php
//                                                                foreach ($supplier as $row) {
                                                                    ?>
                                                                    <option value="<?php // echo $row['stkid'] ?>" <?php // if (isset($suppliers) && $suppliers == $row['stkid']) echo "selected='selected'"; ?>><?php // echo $row['stkname'] ?></option>
                                                                    <?php
//                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div> -->


                                            </div>
                                            
                                            <div class="form-group row">
                                                <!--<div class="col-md-3">-->
                                                    <!--<label class="example-text-input" for="category" required >Stakeholder Category <span style="color: red">*</span>--> 
                                                        <!--<a href="../productcategory_management/add" target="_blank" class="btn btn-sm btn-primary">+</a>-->
                                                    <!--</label>-->
                                                    <!--<div class="controls">-->
                                                        <!--<select class="select2me input-medium" name="category_id" id="category_id" required style="width:100%;padding:10%;">-->
                                                            <!--<option value="">Select</option>-->
                                                            <?php
//                                                            foreach ($category as $row) {
                                                                ?>
                                                                <!--<option value="<?php echo $row['pk_id'] ?>" <?php if (isset($category_id) && $category_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['category'] ?></option>-->
                                                                <?php
//                                                            }
                                                            ?>

                                                        <!--</select>--> 
                                                        
                                                        <input type="hidden" name="category_id" id="category_id" value="1">
<!--                                                    </div>
                                                </div>-->
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="min_quantity" required >Min Quantity </label>
                                                        <div class="controls">
                                                            <input type="number" name="min_quantity" id="min_quantity" class="form-control"   <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $min_quantity . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="max_quantity" required >Max Quantity </label>
                                                        <div class="controls">
                                                            <input type="number" name="max_quantity" id="max_quantity" class="form-control"    <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $max_quantity . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="reorder_quantity" required >Re-Order Quantity </label>
                                                        <div class="controls">
                                                            <input type="number" name="reorder_quantity" id="reorder_quantity" class="form-control"    <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $reorder_quantity . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="pack_size" required >Pack Size/Qty Per Pack </label>
                                                        <div class="controls">
                                                            <input type="text" name="pack_size" id="pack_size" class="form-control"    <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $pack_size . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                
                                                
                                            </div>
                                            
                                            <div class="form-group row">
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="carton_size" required >Carton Size/Qty Per Carton </label>
                                                        <div class="controls">
                                                            <input type="text" name="carton_size" id="carton_size" class="form-control"    <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $carton_size . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="unit" required >Unit </label>
                                                        <div class="controls">
                                                            <input type="text" name="unit" id="unit" class="form-control"    <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $unit . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="barcode_no" required >Bar Code </label>
                                                        <div class="controls">
                                                            <input type="text" name="barcode_no" id="barcode_no" maxlength="50" class="form-control" 
                                                            <?php
                                                            if (isset($result_edit) && isset($barcode_no) && !empty($barcode_no)) {
                                                                echo 'value="' . $barcode_no . '"';
                                                            }
                                                            ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
<!--                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="cold_chain_temp" required >Cold Chain Temperature </label>
                                                        <div class="controls">
                                                            <input type="text" name="cold_chain_temp" id="cold_chain_temp" class="form-control"   <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $cold_chain_temp . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>-->
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Description </label>
                                                        <div class="controls">
<!--                                                            <input type="text" name="description" id="description" class="form-control"  <?php
//                                                            if (isset($result_edit)) {
//                                                                echo 'value="' . $desc . '"';
//                                                            }
                                                            ?>>-->
                                                            <textarea name="description" id="description" class="form-control"   <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $desc . '"';
                                                            }
                                                            ?>><?php if (isset($result_edit)) {
                                                                echo $desc;
                                                            } ?></textarea>
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div>
                                            
                                            
<!--                                            <div class="form-group row">
                                             <div class="col-md-3">
                                                <div class="control-group">
                                                    <label>Contact Person Name</label>
                                                    <div class="controls">
                                                        <input name="cpname" id="cpname" <?php if (isset($result)) { echo 'value="' . $cpname . '"';}?> class="form-control input-medium" autocomplete="off" readonly/>
                                                    </div>
                                                </div>
                                            </div>
                                                <div class="col-md-3">
                                                 <div class="control-group">
                                                    <label>Contact/Phone Number</label>
                                                    <div class="controls">
                                                        <input name="cnnumber" id="cnnumber" <?php if (isset($result)) { echo 'value="' . $cnnumber . '"';}?> class="form-control input-medium" autocomplete="off" readonly/>
                                                    </div>
                                                </div>
                                            </div>
                                                <div class="col-md-3">
                                               <div class="control-group">
                                                     <label for="email">Email</label>
                                                        <div class="controls">
                                                        <input type="email" class="form-control input-medium" id="email"  <?php if (isset($result)) { echo 'value="' . $email . '"';}?> name="email" autocomplete="off" readonly/>
                                                        </div>
                                                        </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="control-group">
                                                    <label>GSTN#</label>
                                                    <div class="controls">
                                                        <input name="gstn" id="gstn" <?php if (isset($result)) { echo 'value="' . $gstn . '"';}?> class="form-control input-medium" autocomplete="off" readonly/>
                                                    </div>
                                                </div>
                                            </div>
                                            </div>-->
                                            <!--<div class="form-group row">-->
<!--                                                    <div class="col-md-3">
                                                <div class="control-group">
                                                    <label>NTN#</label>
                                                    <div class="controls">
                                                        <input name="ntn" id="ntn" <?php if (isset($result)) { echo 'value="' . $ntn . '"';}?> class="form-control input-medium" autocomplete="off" readonly />
                                                    </div>
                                                </div>
                                            </div>-->
<!--											 <div class="col-md-3">
										   <div class="control-group">
                                                    <label>Address</label>
                                                    <div class="controls">
                                                        <input name="address" id="address" <?php if (isset($result)) { echo 'value="' . $address . '"';}?> class="form-control input-medium" autocomplete="off" readonly />
                                                    </div>
                                                </div>
                                            </div>-->
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
<!--                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Barcode </label>
                                                        <div class="controls">
                                                            <input type="text" name="barcode" id="barcode" class="form-control"   <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $barcode . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Code/GTIN </label>
                                                        <div class="controls">
                                                            <input type="text" name="gtin" id="gtin" class="form-control"   <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $gtin . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>-->
                                                <!--</div>-->
<!--                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Description </label>
                                                        <div class="controls">
                                                            <input type="text" name="description" id="description" class="form-control"  <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $desc . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >No of items in one packet </label>
                                                        <div class="controls">
                                                            <input type="text" name="products_packet" id="products_packet" class="form-control"   <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $products_packets . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >No of packets in one carton </label>
                                                        <div class="controls">
                                                            <input type="text" name="packets_carton" id="packets_carton" class="form-control"  <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $packet_carton . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>  
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required > Limit for issuance to Patients (0 = No Limit)</label>
                                                        <div class="controls">
                                                            <input type="text" name="issuance_limit" id="issuance_limit" class="form-control"  <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . $issuance_limit . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div>-->
<!--                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required > Daily units in single item</label>
                                                        <div class="controls">
                                                            <input type="text" name="daily_units_in_single_item" id="daily_units_in_single_item" class="form-control"  <?php
                                                            if (isset($result_edit)) {
                                                                echo 'value="' . @$daily_units_in_single_item . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="disease_id" required >Disease <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="disease_id" id="disease_id" required style="width:100%;padding:10%;">
                                                                <option value="">Select</option>
                                                                <?php 
                                                                    if (isset($disease_array)) {

                                                                        foreach ($disease_array as $row) {
                                                                            $sel = '';
                                                                            ?>
                                                                            <option value="<?php echo $row['pk_id']; ?>" <?php echo $sel; ?>><?php echo $row['disease_name']; ?></option>
                                                                            <?php
                                                                        }
                                                                    }
                                                                ?>
                                                                <option value="1">Malaria</option>
                                                                <option value="2">Other</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div> 
                                                
                                            </div>-->
                                            
                                            <div id="malaria_treatment_info"  style="display: none">
                                                
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="formula_or_hardcode" required >Formula Or Hardcode </label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="formula_or_hardcode" id="formula_or_hardcode" style="width:100%;padding:10%;">
                                                                <!--<option value="">Select</option>-->
                                                                <option value="1">Formula</option>
                                                                <option value="2">Hardcode</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="treatment_id" required >Treatment Type </label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="treatment_id" id="treatment_id" style="width:100%;padding:10%;">
                                                                <option value="">Select</option>
                                                                <?php 
                                                                    if (isset($treatment_type)) {

                                                                        foreach ($treatment_type as $row) {
                                                                            $sel = '';
                                                                            ?>
                                                                            <option value="<?php echo $row['pk_id']; ?>" <?php echo $sel; ?>><?php echo $row['treatment_type']; ?></option>
                                                                            <?php
                                                                        }
                                                                    }
                                                                ?>
<!--                                                                <option value="5">N/A</option>
                                                                <option value="1">First Line</option>
                                                                <option value="2">Second Line</option>-->
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="species_id" required >Species Type </label>
                                                        <div class="controls">
                                                            <select class="form-control" id="species_id" name="species_id" >
                                                                <option value="">Select</option>
                                                                    <?php 
                                                                    if (isset($species_array)) {

                                                                        foreach ($species_array as $row) {
                                                                            $sel = '';
                                                                            ?>
                                                                            <option value="<?php echo $row['pk_id']; ?>" <?php echo $sel; ?>><?php echo $row['malaria_species']; ?></option>
                                                                            <?php
                                                                        }
                                                                    }
                                                                            ?>
                                                             </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="from_year" required >From Year </label>
                                                        <div class="controls">
                                                            <input type="text" name="from_year" id="from_year" class="form-control"   <?php
                                                            if (isset($result_edit) && isset($from_year)) {
                                                                echo 'value="' . $from_year . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="to_year" required >To Year </label>
                                                        <div class="controls">
                                                            <input type="text" name="to_year" id="to_year" class="form-control"   <?php
                                                            if (isset($result_edit) && isset($to_year)) {
                                                                echo 'value="' . $to_year . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="from_weight" required >From Weight  </label>
                                                        <div class="controls">
                                                            <input type="text" name="from_weight" id="from_weight" class="form-control"   <?php
                                                            if (isset($result_edit) && isset($from_weight)) {
                                                                echo 'value="' . $from_weight . '"';
                                                            }
                                                            ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="example-text-input" for="to_weight" required >To Weight </label>
                                                            <div class="controls">
                                                                <input type="text" name="to_weight" id="to_weight" class="form-control"   <?php
                                                                if (isset($result_edit) && isset($to_weight)) {
                                                                    echo 'value="' . $to_weight . '"';
                                                                }
                                                                ?>>
                                                            </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="example-text-input" for="to_weight" required >Comments </label>
                                                            <div class="controls">
                                                                <!--<input class="form-control" type="text" id="add_notes" name="add_notes">--> 
                                                                <textarea class="form-control" type="text" id="comments" name="comments" rows="2"></textarea>
                                                            </div>
                                                        </div>
                                                </div>   
                                            </div>
                                                
                                                
                                                <div class="form-group row">
                                                    <div class="col-md-3">
                                                    <div class="control-group">
                                                            <label class="example-text-input" for="pregnant_id"  >Pregnant Or Not </label>
                                                            <div class="controls">
                                                                <select class="form-control" name="pregnant_id" id="pregnant_id">
                                                                    <option value="">Select</option>
                                                                    <option value="1">Pregnant</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3" id="pregnant_info" style="display: none;">
                                                        <div class="control-group">
                                                            <label class="example-text-input" for="pregnant_stage"  >Pregnant Stage </label>
                                                            <div class="controls">
                                                                <select class="form-control" name="pregnant_stage" id="pregnant_stage">
                                                                    <option value="">Select</option>
                                                                <?php 
                                                                    if (isset($pregnant_stage)) {

                                                                        foreach ($pregnant_stage as $row) {
                                                                            $sel = '';
                                                                            ?>
                                                                            <option value="<?php echo $row['pk_id']; ?>" <?php echo $sel; ?>><?php echo $row['pregnant_stage']; ?></option>
                                                                            <?php
                                                                        }
                                                                    }
                                                                ?>
                                                                    <!--                                                                   
                                                                    <option value="">N/A</option>
                                                                    <option value="1">1st Trimester</option>
                                                                    <option value="2">2nd & 3rd Trimester</option>-->
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
<!--                                                    <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="example-text-input" for="method_type"  >Method Type </label>
                                                            <div class="controls">
                                                                <select class="form-control" name="method_type" id="method_type">
                                                                    <option value="">Select</option>
                                                                    <option value="1">Dose</option>
                                                                    <option value="2">Tablet</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>-->
                                                    <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="example-text-input" for="dose_id"  >Dose / KG </label>
                                                            <div class="controls">
                                                                <input class="form-control" type="text" value="<?php echo isset($dose_id) ? $dose_id : ''; ?>" id="dose_id" name="dose_id">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3" >
                                                        <div class="control-group">
                                                            <label class="example-text-input" for="quantity"  >Quantity </label>
                                                            <div class="controls">
                                                                <input class="form-control" type="text" value="<?php echo isset($quantity) ? $quantity : ''; ?>" id="quantity" name="quantity">
                                                            </div>
                                                        </div>
                                                    </div>
<!--                                                    <div class="col-md-3"  id="tablet_info" style="display: none;">
                                                        <div class="control-group">
                                                            <label class="example-text-input" for="tablet_id"  >Tablet </label>
                                                            <div class="controls">
                                                                <input class="form-control" type="text" value="<?php echo isset($tablet_id) ? $tablet_id : ''; ?>" id="tablet_id" name="tablet_id">
                                                            </div>
                                                        </div>
                                                    </div>-->
                                                </div>
                                                
                                                
                                                <div class="form-group row">
                                                    <div class="col-md-3" >
                                                        <div class="control-group">
                                                            <label class="example-text-input" for="times_a_day"  >Times a day </label>
                                                            <div class="controls">
                                                                <input class="form-control" type="text" value="<?php echo isset($weight) ? $weight : ''; ?>" id="times_a_day" name="times_a_day">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3" >
                                                        <div class="control-group">
                                                            <label class="example-text-input" for="dose_a_day"  >Dose a day </label>
                                                            <div class="controls">
                                                                <input class="form-control" type="text" value="<?php echo isset($dose_a_day) ? $dose_a_day : ''; ?>" id="dose_a_day" name="dose_a_day">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3" >
                                                        <div class="control-group">
                                                            <label class="example-text-input" for="no_of_days"  >No of days </label>
                                                            <div class="controls">
                                                                <input class="form-control" type="text" value="<?php echo isset($no_of_days) ? $no_of_days : ''; ?>" id="no_of_days" name="no_of_days">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            
                                            </div>
                                            
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                            if (isset($result_edit))
                                                                echo 'value="edit"';
                                                            ?>>
                                                            <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div> 

                                                <input type="hidden" name="generic_name" id="generic_name" value="">
                                                <input type="hidden" name="strength" id="strength" value="">
                                                <input type="hidden" name="method_type"  id="method_type" value="">
                                                <input type="hidden" name="manufacturer" id="manufacturer" value="">
                                                <input type="hidden" name="category" id="category" value="">
                                                <input type="hidden" name="sub_category" id="sub_category" value="">
                                                <?php if (isset($result_edit)) {
                                                    ?>
                                                    <input type="hidden" name="pk_id" id="pk_id" value="<?php echo $_REQUEST['id'] ?>"> 
                                                <?php }
                                                ?>    
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>