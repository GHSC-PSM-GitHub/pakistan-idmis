<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Contradictory Products List</h3>
                        <div class="buttons pull-right">
                            <a href="<?php echo base_url("product_management/contradictory_products"); ?>"   class="btn btn-primary btn-icon glyphicons circle_plus"><i class="fas fa-user-plus"></i> Add</a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                     <div class="innerLR">
                        <br>
                        <?php
                        if (isset($result)) {
                            ?>

                            <div id="divToPrint">
                                <table class="table table-striped table-bordered table-condensed dt-responsive " id="datatable-buttons">
                                    <thead>
                                        <tr>
                                            <th style="width: 1%;" class="center">No.</th>
                                            <th>Generic Name</th>
                                            <th>Contradictory Generic Name</th> 
                                            <!--<th></th>-->
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Table row -->
                                        <?php
                                        $count = 1;
//        echo '<pre>';
//        print_r($result->result_array());
//        exit;
                                        foreach ($result->result_array() as $row) {
                                            ?>
                                            <tr>
                                                <td class="center"><?php echo $count; ?></td>
                                                <td><?php echo $row['generic_name']; ?></td>
                                                <td class="important"><?php echo $row['contradictory_name']; ?></td>
                                                 
                                            </tr>
                                            <?php
                                            $count++;
                                        }
                                        ?>
                                        <!-- // Table row END -->
                                        <!-- Table row -->

                                        <!-- // Table row END -->
                                    </tbody>
                                </table> 
                            </div>

                            <!-- // Table END -->
                            <?php
                        } else {
                            echo "<hr><h5>No data found!</h5>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>