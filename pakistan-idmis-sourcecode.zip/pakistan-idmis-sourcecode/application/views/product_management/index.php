<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Products</h3>
                        <div class="buttons pull-right">
                            <a href="<?php echo base_url("product_management/add"); ?>"   class="btn btn-primary btn-icon glyphicons circle_plus"><i class="fas fa-user-plus"></i> Add</a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                     <div class="innerLR">
                        <br>
                        <?php
                        if (is_object($result)) {
                            ?>

                            <div id="divToPrint">
                                <table class="table table-striped table-bordered table-condensed dt-responsive " id="datatable-buttons">
                                    <thead>
                                        <tr>
                                            <th style="width: 1%;" class="center">No.</th>
                                            <th>Auto Generated</th>
                                            <th>Product type</th>
                                            <!--<th>Product Code</th>-->
                                            <th>Product Name</th>
                                            <th>Product Strength</th>
                                            <th>Product Description</th>
                                            <th>Action</th>
                                            <th style="width:100px;"></th>
                                            <!--<th></th>-->
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Table row -->
                                        <?php
                                        $count = 1;
//        echo '<pre>';
//        print_r($result->result_array());
//        exit;
                                        foreach ($result->result_array() as $row) {
                                            ?>
                                            <tr>
                                                <td class="center"><?php echo $count; ?></td>
                                                <td><?php echo $row['itmrec_id']; ?></td>
                                                <td class="important"><?php echo $row['product_type']; ?></td>
                                                <!--<td class="important"><?php echo $row['product_code']; ?></td>-->
                                                <td class="important"><?php echo $row['itm_name']; ?></td>
                                                <td class="important"><?php echo $row['strength']; ?></td>
                                                <td class="important"><?php echo $row['itm_des']; ?></td>
                                                <td> <a href="<?php echo base_url("product_management/edit?id=") . $row['itm_id']; ?> " class="btn btn-danger" title="edit">Edit</a>
                                                </td>
                                                <td>    <?php  
                                                    if($row['itm_status'] == 0){
                                                ?>
                                                <a onclick="return confirm('Are you sure you want to Activate?');" href="<?php echo base_url("product_management/deactivate?id=") . $row['itm_id']; ?>&itm_status=1" class="btn btn-sm btn-light glyphicons bin" ><i class="fas fa-check success"></i> Activate</a>

                                                <?php
                                                    }else{
                                                ?>
                                                    <a onclick="return confirm('Are you sure you want to Deactivate?');" href="<?php echo base_url("product_management/deactivate?id=") . $row['itm_id']; ?>&itm_status=0" class="btn btn-sm btn-light glyphicons bin" ><i class="fas fa-times red"></i> Disable</a>

                                                <?php
                                                }
                                                ?>
                                                </td>
<!--                                                <td>
                                                    <a href="<?php echo base_url("masterdata_management/add_mdm?id=") . $row['pk_id']; ?>&type=warehouse" class="btn btn-success" title="add_ext">MDM</a>
                                                </td>-->
                                            </tr>
                                            <?php
                                            $count++;
                                        }
                                        ?>
                                        <!-- // Table row END -->
                                        <!-- Table row -->

                                        <!-- // Table row END -->
                                    </tbody>
                                </table> 
                            </div>

                            <!-- // Table END -->
                            <?php
                        } else {
                            echo "<hr><h5>No data found!</h5>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>