<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12">
                    <!-- Breadcrumb -->
                    <ul class="breadcrumb">
                        <li><a href="<?php echo base_url("profile/index"); ?>" class="glyphicons home"><i></i> Home</a></li>
                        <li class="divider"></li>
                        <li>Under Construction</li>
                    </ul>
                    <div class="separator bottom"></div>
                   
                    <div class="heading-buttons">
                        <h3>Work in progress</h3>
                        <div class="buttons pull-right">
                        </div>
                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        
                        We are working on this module. Will be available soon.
                        
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>