<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
}
    
</style>
<?php
$from_id = '';
date_default_timezone_set('Asia/Karachi');
$receivedatetime = date('m/d/Y h:i:s a', time());
//print_r($tran_reference_number);exit;
if (isset($stock_master_records)) {
    $row = $stock_master_records[0];
    $refernce_number = $row['TranRef'];
    $warehouse_from = $row['WHIDFrom'];
    $warehouse_from_supplier = $row['WHIDFromSupplier'];
    
    //Check 
    $from_id = $row['WHIDFrom'];
    $TranRef = $row['TranRef'];
    
} else if (isset($tran_reference_number)) {

    $refernce_number = $tran_reference_number;
}
if(isset($_REQUEST['batchid']) && !empty($_REQUEST['batchid']))
{
    $batchid = $_REQUEST['batchid'];
}
if(isset($_REQUEST['fkstockid']) && !empty($_REQUEST['fkstockid']))
{
    $pkmasterid = $_REQUEST['fkstockid'];
}
if(isset($_REQUEST['pkdetailid']) && !empty($_REQUEST['pkdetailid']))
{
    $pkdetailid = $_REQUEST['pkdetailid'];
}
if(isset($gwis_records) && $gwis_records != 'NF')
{
    $row = $gwis_records[0];
    $masterid = $row['pkmasterid'];
    $detailid = $row['pk_id'];
    $stockstatus = $row['status_id'];
    $gwis_tran_ref = $row['tran_no'];
    $gwis_item_id = $row['item_id'];
    $gwis_batch_no = $row['batch_no'];
    $gwis_production_date = $row['production_date'];
    $gwis_batch_expiry = $row['batch_expiry'];
    $gwis_received_remarks = $row['received_remarks'];
    $gwis_quantity = $row['quantity'];
    $gwis_challan_type = $row['delivery_challan_type'];
    $gwis_challan_type_detail = $row['challan_type_detail'];
    $gwis_warehouse = $row['wh_id_from'];
    $gwis_supplier = $row['wh_id_from_supplier'];
    $source_type = $row['source_type'];
//    $Qty = $row['Qty'];
//    $dtl = $row['dtl'];
//    $dtl_result = $row['dtl_result'];
//    print_r($stockstatus);exit;
}
else if(isset($gwis_records) && $gwis_records == 'NF')
{
    $data_not_found = $gwis_records;
}
if(isset($_GET['pkdetailid']) && !empty($_GET['pkdetailid']))
{
    if(isset($stockReceive) && !empty($stockReceive))
    {
        foreach ($stockReceive as $rowdata) {
    //        $rowsdata = $rowdata[0];
            $ReceivedRemarks = $rowdata['ReceivedRemarks'];
            $source_type = $rowdata['source_type'];
    //        print_r($source_type);exit;
        }
    }
}

?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>GRN Approver</h3>
                        <?php
                            if ($approval_code) {

                                //fetch results
                                foreach ($approval_code AS $row)
                                {
                                    $approval_codess = preg_split ("/\,/", $row['approval_code']);  
                                    $approval_code_idd = preg_split ("/\,/", $row['approval_code_id']);  
                                    $approve_fromm = preg_split ("/\,/", $row['approve_from']);  
                                    $approve_too = preg_split ("/\,/", $row['approve_to']);  
                                    $process_statuss = preg_split ("/\,/", $row['process_status']); 
                                    $final_statuss = preg_split ("/\,/", $row['final_status']); 
                                    $approver_designation = preg_split ("/\,/", $row['approver_designation']); 
                                    $approver_desg_id = preg_split ("/\,/", $row['approver_desg_id']);
                                    $approvalcount = count($approval_code);
 //                                   $val = array("'" . str_replace(",", "','", $row['approval_code']) . "'");

 //                                   $val = explode($row['approval_code']);
 //                                   print_r($approval_codes);

                                }
                             }
                        ?>
                    </div>
                    <div class="separator bottom"></div>
                    
                    <div class="row">
                        <div class="col-md-12"><?php 
//                        if(isset($issueVoucher) && !empty($issueVoucher)) {
//                            echo 'Pending Vouchers are : ';
//                            echo implode(',', $issueVoucher);
//                            echo '<hr>';
//                        }
                        
//                        if(isset($getStockIssues) && !empty($getStockIssues)) {
                            
                            $issueVoucher = array();
                        $a='';
                           if ($getStockIssues) {

                               //fetch results
                               foreach ($getStockIssues AS $row)
                               {
                                   $a= " <a style='color:red;' href=\"stock_receive?receivetype=2&receiveno=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
                                   $issueVoucher[ $row['tran_no']] = $a;
                               }

//                           }
                            
                                echo '<table style="font-family: arial;border: 2px solid #1F8564; sans-serif;border-collapse: collapse;width:100%"><tr><th style=" border: 2px solid #1F8564;text-align: left;padding: 8px;width:20%;font-size:16px;">Pending Vouchers are : </th><td  style="border: 1px solid #dddddd;text-align: left;padding: 8px;text-decoration: underline;">';
                                echo implode(',', $issueVoucher);
                                echo '</td></table><hr>';
                            }
                            
                            if (in_array("69", $approver_desg_id)){
                                if ($getRejectedVoucher) {

                                   //fetch results
                                   foreach ($getRejectedVoucher AS $row)
                                   {
                                       $a= " <a style='color:red;' href=\"stock_receive?receivetype=2&receiveno=" . $row['tran_no'] . "&isrejvoucher=1&rej_issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
                                       $issueRegVoucher[$row['tran_no']] = $a;
                                   }

    //                           }

                                    echo '<table style="font-family: arial;border:2px solid #1F8564; sans-serif;border-collapse: collapse;width:100%"><tr><th style="border: 2px solid #1F8564;text-align: left;padding: 8px;width:20%;font-size:16px;">Rejected Vouchers are : </th><td  style="border: 1px solid #dddddd;text-align: left;padding: 8px;text-decoration: underline;">';
                                    echo implode(',', $issueRegVoucher);
                                    echo '</td></table><hr>';
                                }
                            }
                            
                         ?></div>
                    </div>
                    
                    <div class="innerLR">
                        
                        <form method="POST" name="receive_search" 
                              <?php if(isset($_REQUEST['tranno']))
                              {?>
                                    action="<?php echo "stock_receive?pkdetailid=" . $_REQUEST['pkdetailid']."&batchid=".$_REQUEST['batchid']."&fkstockid=".$_REQUEST['fkstockid']."&tranno=".$_REQUEST['tranno']."&whidto=".$_REQUEST['whidto']."&tranref=".$_REQUEST['tranref']."&search=true"; ?>" 
                              <?php } else { ?>
                                    action="stock_receive" 
                              <?php }?>
                              >
                            <!-- Row -->
                            <?php 
                            //get e
                            if(isset($_GET['e'])){?>
                            <span style="padding-left:15px; color:#F00;">Please select at least one product by clicking checkboxes at right</span>
                            <?php }?>
                            
<!--                            <div class="col-md-3">
                                <div class="control-group">
                                    <label class="example-text-input" for="hf" required >Quantity <span style="color: red">*</span></label>
                                    <div class="controls">
                                        <input type="number" name="quantity" id="quantity" class="form-control"   required >
                                    </div>
                                </div>
                            </div>-->
                            
                            <div class="form-group row ">
                                <!--<div class="col-md-12">-->
                                    <div class="col-md-3">
                                        <div class="control-group">
                                            <label class="example-text-input" for="receivetype" required >Receive Type <span style="color: red">*</span> </label>     
                                            <div class="controls">
                                                <select name="receivetype" id="receivetype" required class="select2me input-medium" style="width:100%;padding:10%;">
                                                    <option value="" selected="selected">Select</option>
                                                    <!--<option value="1" <?php if (isset($receivetype) && $receivetype == 1){ echo "selected='selected'"; } else if (isset($_REQUEST['receivetype']) && $_REQUEST['receivetype'] == 1){ echo "selected='selected'"; } ?>>Direct</option>-->
                                                    <option value="2" <?php if (isset($receivetype) && $receivetype == 2){ echo "selected='selected'"; } else  if (isset($_REQUEST['receivetype']) && $_REQUEST['receivetype'] == 2){ echo "selected='selected'"; } ?>>GWIS(PI,TI)Completed</option>
                                                </select>
                                            </select>

                                            </div>
                                        </div>
                                    </div>
                                
                                    <div class="col-md-3" id="show_receiveno" style="display:none;"> 
                                        <!-- Group Receive No-->
                                        <div class="control-group">
                                            <label for="receiveno"> GWIS No </label>
                                            <div class="controls">
                                                <input class="form-control" tabindex="1" id="receiveno" value="<?php if(isset($_REQUEST['tranref'])) {echo $_REQUEST['tranref']; } else if(isset($_REQUEST['receiveno'])) echo $_REQUEST['receiveno']; ?>" name="receiveno" type="text" required />
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" class="form-control" name="isrejvoucher" id="isrejvoucher" value="<?php if (isset($isrejvoucher)){ echo $isrejvoucher; } else if (isset($_REQUEST['isrejvoucher'])) echo $_REQUEST['isrejvoucher']; else {echo '';} ?>" >
                                
                                    <div class="col-md-3">
                                        <div class="control-group">
                                        <div class="input-group input-medium" style="margin-top: 21px;">
                                            <div class="controls">
                                            <button type="submit" class="btn btn-primary" name="submit" value="Search"> Search </button>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                <!--</div>-->
                            </div>
                    </form>
                        
                        <?php // if(isset($_POST['submit']) && isset($stockstatus) && $stockstatus != '2' || (isset($data_not_found) && !empty($data_not_found)) ) { ?>
                        <!--<br>-->
                        <?php // if(isset($stockstatus) && $stockstatus == '0') { ?>
<!--                        <div class="success" style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:20px;">
                           <p><strong>&nbsp;Note!</strong> Delivery Challan Completed Waiting For Physical Inspection</p>
                        </div>-->
                        <?php // }
//                         else if(isset($stockstatus) && $stockstatus == '1') { ?>
<!--                        <div class="success" style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:20px;">
                           <p><strong>&nbsp;Note!</strong> Physical Inspection Completed Waiting For Technical Inspection</p>
                        </div>-->
                        <?php // }
//                        else if(isset($data_not_found) && !empty($data_not_found)) { ?>
<!--                        <div class="success" style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:20px;">
                           <p><strong>&nbsp;Note!</strong> Record Not Found</p>
                        </div>-->
                        <?php // } } 
//                        else 
                            if(isset ($_POST['submit']) || isset ($_REQUEST['wh_btn']) || isset($_REQUEST['tranno'])){ ?>
                        
                        <form method="post" id="stock_receive" name="stock_receive" enctype="multipart/form-data" action="<?php echo base_url("inventory_management/stock_receive"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            
                            <?php if(isset($gwis_records) && $gwis_records != 'NF')
                            { ?>                
<!--                                <table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable">
                                    
                                     Table heading 
                                    <thead>
                                        <tr>
                                            <th style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:20px;"> Comments</th>
                                        </tr>
                                    </thead>
                                     // Table heading END  
                                    
                                     Table body 
                                    <tbody>
                                        <?php
                                        $i = 0;
                                        
                                            foreach ($gwis_records as $row) {
                                        if($i <= 0)
                                        {
//                                                $stockID = $row['fk_stock_id'];
//                                                $issuance_date = $row['tran_date'];
                                                ?>
                                        <tr>
                                            <?php // if(empty($row['wh_from'])) { ?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">PO Quantity : </b>'. '0'. '<b style="font-weight: 900;margin-left: 40px;">DC Quantity : </b>' .$row['dc_quantity'] .'<b style="font-weight: 900;margin-left: 40px;">GWIS PI Quantity : </b>' .$row['pi_quantity']. 
                                                 '<b style="font-weight: 900;margin-left: 40px;">GWIS TI Quantity : </b>' .$row['ti_quantity'];?>
                                            </td>
                                        </tr>
                                        <?php 
                                                } 
                                            $i++;
                                            }
                                            ?>
                                    </tbody>
                                </table>-->
                            <?php } ?>     
                                            <br>
                                            
                                            
                                            <div class="form-group row"> 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="reference_number"  >Reference No / Official Letter No  </label>
                                                        <div class="controls">
                                                            <input type="text" name="refernce_number" id="reference_number" class="form-control" readonly  <?php // if (isset($master_id)) echo 'readonly="true"' ?> 
                                                                <?php
                                                                if(isset($gwis_tran_ref)){
                                                                    echo 'value="' . $gwis_tran_ref . '"';
                                                                }
                                                                else if (isset($refernce_number)) {
                                                                    echo 'value="' . $refernce_number . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Receiving Date(MM/DD/YYYY) <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="receiving_time" id="stock_receiving_time" disabled value="<?php echo $receivedatetime; ?>" <?php // if (isset($master_id)) echo 'disabled="true"' ?>>

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3" id="dctypes">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="challan_type" required >Delivery Challan Type <span style="color: red">*</span> </label>     
                                                        <div class="controls">
                                                            <?php
                                                        
                                                        if (isset($challan_type) && !empty($challan_type)) {
                                                            
                                                        ?>
                                                        <select class="select2me input-medium" name="challan_type" id="challan_type" style="width:100%;padding:10%;" disabled <?php // if (isset($master_id)) echo 'disabled="true"' ?> >
                                                            <option value="">Select</option>
                                                            <?php
                                                                                                                    
                                                            foreach ($challan_type as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($gwis_challan_type) && $gwis_challan_type == $row['pk_id']){ echo "selected='selected'"; } else if (isset($form['challan_type']) && $form['challan_type'] == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['challan_type'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                        <?php
                                                        }
                                                        if(isset($master_id)) { ?>
                                                            
                                                            <input type="hidden" class="form-control" name="challan_type" id="challan_type" value="<?php if (isset($gwis_challan_type)){ echo $gwis_challan_type; } else if (isset($form['challan_type'])) echo $form['challan_type']; ?>" >
                                                            
                                                        <?php } ?>

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3" id="po_type_detail" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="po_detail_info" >PO#</label>     
                                                        <div class="controls">
                                                            <input type="text"  name="po_detail_info" id="po_detail_info" class="form-control" readonly="" <?php // if (isset($master_id)) echo 'readonly="true"' ?> 
                                                                <?php
                                                                if(isset($gwis_challan_type_detail)){
                                                                    echo 'value="' . $gwis_challan_type_detail . '"';
                                                                }
                                                                else if (isset($form['po_detail_info'])) {
                                                                    echo 'value="' . $form['po_detail_info'] . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </select>

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3" id="fo_type_detail" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="wh_detail_info" >WH# </label>     
                                                        <div class="controls">
                                                            <input type="text"  name="wh_detail_info" id="wh_detail_info" class="form-control" readonly <?php // if (isset($master_id)) echo 'readonly="true"' ?> 
                                                                <?php
                                                                 if(isset($gwis_challan_type_detail)){
                                                                    echo 'value="' . $gwis_challan_type_detail . '"';
                                                                }
                                                                else if (isset($form['wh_detail_info'])) {
                                                                    echo 'value="' . $form['wh_detail_info'] . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </select>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row"> 
                                                
                                                <div class="col-md-3" style="display:none;" id="show_receive_from_supplier" >
                                                    <label class="example-text-input" for="strength" required >Received From (Supplier)<span style="color: red">*</span> <?=(empty($temp_records) ) ? '<a class="btn btn-sm btn-primary" target="_blank" href="../warehouse_management/add_supplier">+</a>':''?></label>
                                                    <div class="controls">
                                                        <?php
                                                        
                                                        if (empty($temp_records)) {
                                                            
                                                        ?>
                                                        <select class="select2me input-medium" name="receive_from_supplier" id="receive_from_supplier" style="width:100%;padding:10%;" disabled=""<?php // if (isset($master_id)) echo 'disabled="true"' ?> >
                                                            <option value="">Select</option>
                                                            <?php
                                                                                                                    
                                                            foreach ($suppliers as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['wh_id'] ?>" <?php if (isset($gwis_supplier) && $gwis_supplier == $row['wh_id']){ echo "selected='selected'"; } else if (isset($supplier_from) && $supplier_from == $row['wh_id']) echo "selected='selected'"; ?>><?php echo $row['wh_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                        <?php
                                                        }else
                                                        {
                                                            foreach ($suppliers as $row) {
//                                                                if(isset($warehouse_from) && $warehouse_from == $row['stkid']) echo  '<input class="form-control" disabled value="'.$row['stkname'].'">';
                                                                if(isset($warehouse_from_supplier) && $warehouse_from_supplier == $row['wh_id']) { echo  '<input class="form-control" disabled value="'.$row['wh_name'].'">';   } 
                                                                else if (isset($gwis_supplier) && $gwis_supplier == $row['wh_id']){ echo '<input class="form-control" disabled value="'.$row['wh_name'].'">'; } 
                                                                                                                              
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3" id="show_receive_from_warehouse" style="display:none;" >
                                                    <label class="example-text-input" for="receive_from_warehouse" required >Received From (Warehouse)<span style="color: red">*</span> <?=(empty($temp_records) ) ? '<a class="btn btn-sm btn-primary" target="_blank" href="../warehouse_management/add_warehouse">+</a>':''?></label>
                                                    <div class="controls">
                                                        <?php
                                                        
                                                        if (empty($temp_records)) {
                                                            
                                                        ?>
                                                        <select class="select2me input-medium" name="receive_from_warehouse" id="receive_from_warehouse"  style="width:100%;padding:10%;" disabled=""<?php // if (isset($master_id)) echo 'disabled="true"' ?> >
                                                            <option value="">Select</option>
                                                            <?php
                                                                                                                    
                                                            foreach ($warehouses as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['wh_id'] ?>" <?php if (isset($gwis_warehouse) && $gwis_warehouse == $row['wh_id']){ echo "selected='selected'"; } else if (isset($warehouse_from) && $warehouse_from == $row['wh_id']) echo "selected='selected'"; ?>><?php echo $row['wh_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                        <?php
                                                        }else
                                                        {
                                                            foreach ($warehouses as $row) {
//                                                                if(isset($warehouse_from) && $warehouse_from == $row['stkid']) echo  '<input class="form-control" disabled value="'.$row['stkname'].'">';
                                                                if(isset($warehouse_from) && $warehouse_from == $row['wh_id']) { echo  '<input class="form-control" disabled value="'.$row['wh_name'].'">';  } 
                                                                else if (isset($gwis_warehouse) && $gwis_warehouse == $row['wh_id']){ echo  '<input class="form-control" disabled value="'.$row['wh_name'].'">'; }
                                                                                                                               
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                <label class="control-label" for="source_type"> Received From (Funding Source)<span style="color: red">*</span>  <?=(empty($temp_records) ) ? '<a class="btn btn-sm btn-primary" target="_blank" href="../fundingsource_management/add">+</a>':''?></label>
                                                <div class="controls">
                                                    <select name="source_type" id="source_type" required="true" class="select2me input-medium"  style="width:100%;padding:10%;"<?php if (!empty($from_id) && !empty($TranNo)) { ?>disabled="" <?php } ?>>
                                                        <option value="">Select</option>
                                                        <?php
                                                        if ($funding_source) {
                                                            //fetch result
                                                            foreach ($funding_source as $row) {
                                                                //populate receive_from combo
//                                                                if($_SESSION['user_stakeholder']=='145'){
//                                                                    if($row->wh_id != '33677' && $row->wh_id != '33678' && $row->wh_id != '33680' && $row->wh_id != '20641'  && $row->wh_id != '9079') 
//                                                                        continue;
//                                                                }
                                                                ?>
                                                        <option value="<?php echo $row['stkid']; ?>" <?php if(isset($source_type) && $source_type == $row['stkid']) {?> selected="" <?php } else if ($from_id == $row['stkid']) { ?> selected="" <?php } ?>> <?php echo $row['stkname']; ?> </option>
                                                                <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                    <?php if (!empty($from_id) && !empty($TranNo)) { ?>
                                                        <input type="hidden" name="source_type" id="source_type" value="<?php echo $from_id; ?>" />
<?php } ?>
                                                </div>
                                            </div>
                                                
<!--                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Product<span style="color: red">*</span> <?=(empty($temp_records) ) ? '<a class="btn btn-sm btn-primary" href="../product_management/add">+</a>':''?></label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="product" id="product" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                                <?php
                                                                foreach ($product as $row) {
                                                                    ?>
                                                                <option value="<?php echo $row['itm_id'] ?>" <?php if (isset($gwis_item_id) && $gwis_item_id == $row['itm_id']){ echo "selected='selected'"; } else if (isset($product_id) && $product_id == $row['itm_id']) {echo "selected='selected'";} ?>><?php echo $row['itm_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>-->
                                                
<!--                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="registration_number" required >Batch Number<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="batch_number" id="batch_number" class="form-control" <?php
                                                                if(isset($gwis_batch_no)){
                                                                    echo 'value="' . $gwis_batch_no . '"';
                                                                }
                                                                ?>  required >
                                                        </div>
                                                    </div>
                                                </div>-->
                                                
                                            </div> 
                                            
<!--                                            <div class="form-group row m-b-0" id="msg_shelf">
                                                <div class="alert alert-danger alert-dismissiblex fade show" role="alert">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button> <span id="msg_shelf_text">Attention: The Batch must have shelf life of at least 85% , as per instructions from DRAP.</span>
                                                </div>
                                            </div>-->
                                            <div class="form-group row">
                                                
<!--                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Manufacturing Date(MM/DD/YYYY) <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" name="manufacturing_date" id="manufacturing_date" class="form-control"   required 
                                                                   <?php
                                                                if(isset($gwis_production_date)){
                                                                    echo 'value="' . $gwis_production_date . '"';
                                                                }
                                                                else {
                                                                    echo 'value="' . date("m/d/Y") . '"';
                                                                }
                                                                ?> >
                                                        </div>
                                                    </div>
                                                </div>-->
<!--                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Expiry Date(MM/DD/YYYY) <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" name="expiry_date" id="expiry_date" class="form-control"   required 
                                                                   <?php
                                                                if(isset($gwis_batch_expiry)){
                                                                    echo 'value="' . $gwis_batch_expiry . '"';
                                                                }
                                                                else {
                                                                    echo 'value="' . date("m/d/Y") . '"';
                                                                }
                                                                ?>>
                                                        </div>
                                                    </div>
                                                </div>-->
<!--                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="quantity" id="quantity" class="form-control" required 
                                                                   <?php
                                                                if(isset($gwis_quantity)){
                                                                    echo 'value="' . $gwis_quantity . '"';
                                                                }?> >
                                                        </div>
                                                    </div>
                                                </div>-->
<!--                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Remarks</label>
                                                        <div class="controls">
                                                            <textarea name="remarks" id="remarks" class="form-control" 
                                                                      <?php
                                                                if(isset($gwis_received_remarks)){
                                                                    echo 'value="' . $gwis_received_remarks . '"';
                                                                }?> ></textarea>
                                                        </div>
                                                    </div>
                                                </div>-->
                                            </div>

                                            <div class="form-group row">
                                                
                                                <div class="col-md-12" id="supplier_info" style="display:none;background-color: #e3f4eb;">
                                                    <div class="control-group">
                                                        <h3 style="color:#2A3988;">Supplier Details</h3>
                                                        <div class="form-group row">
                                                            
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-2 col-form-label">Contact Person : </label>
                                                            <div class="col-sm-4">
                                                              <input type="text" readonly class="form-control-plaintext" id="contact_person" value="">
                                                            </div>
                                                            
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-2 col-form-label">Contact Numbers: </label>
                                                            <div class="col-sm-4">
                                                              <input type="text" readonly class="form-control-plaintext" id="contact_number" value="">
                                                            </div>
                                                            
                                                        </div>
<!--                                                        <div class="form-group row">
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-4 col-form-label">Contact Numbers: </label>
                                                            <div class="col-sm-8">
                                                              <input type="text" readonly class="form-control-plaintext" id="contact_number" value="">
                                                            </div>
                                                        </div>-->
                                                        <div class="form-group row">
                                                            
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-2 col-form-label">Contact Email : </label>
                                                            <div class="col-sm-4">
                                                              <input type="text" readonly class="form-control-plaintext" id="contact_email" value="">
                                                            </div>
                                                            
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-2 col-form-label">Address : </label>
                                                            <div class="col-sm-4">
                                                                <textarea type="text" readonly class="form-control-plaintext" id="address" value=""></textarea>
                                                            </div>
                                                            
                                                        </div>
<!--                                                        <div class="form-group row">
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-4 col-form-label">Address : </label>
                                                            <div class="col-sm-8">
                                                                <textarea type="text" readonly class="form-control-plaintext" id="address" value=""></textarea>
                                                            </div>
                                                        </div>-->
                                                        
                                                        
                                                    </div>
                                                </div>
                                                
                                            </div>
                                             

                                <table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable">
                                    
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:16px;"> Driver Info</th>
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 
                                    
                                    <!-- Table body -->
                                    <tbody>
                                        <?php
                                        $i = 0;
                                        
                                            foreach ($stockReceive as $row) {
                                        if($i <= 0)
                                        {
                                                $stockID = $row['fk_stock_id'];
                                                $issuance_date = $row['tran_date'];
                                                ?>
                                        <tr>
                                            <?php if(empty($row['wh_from'])) { ?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">Driver Name : </b>' .$row['driver_name'] . '<b style="font-weight: 900;margin-left: 30px;">Driver Contract : </b>' .$row['driver_contract'] .'<b style="font-weight: 900;margin-left: 30px;">Vehicle Reg# : </b>' .$row['vehicle_reg'] ;?>
                                            </td>
                                        </tr>
                                        <?php 
                                            } else{?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">Warehouse : </b>' .$row['wh_from']; 
                                                 ?>
                                            </td>
                                            <?php  }
                                            $i++;
                                            }
                                        }
                                            ?>
                                    </tbody>
                                </table>            
                                      
                                <table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable">
                                    
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:16px;"> Other Info</th>
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 
                                    
                                    <!-- Table body -->
                                    <tbody>
                                        <?php
                                        $i = 0;
                                        
                                            foreach ($stockReceive as $row) {
                                        if($i <= 0)
                                        {
                                                $stockID = $row['fk_stock_id'];
                                                $issuance_date = $row['tran_date'];
                                                ?>
                                        <tr>
                                            <?php if(empty($row['wh_from'])) { ?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">DC Number : </b>' .$row['dc_no'] . '<b style="font-weight: 900;margin-left: 30px;">DC Date : </b>' .$row['dc_date'] .'<b style="font-weight: 900;margin-left: 30px;">Invoice : </b>' .$row['invoice']. 
                                                 '<b style="font-weight: 900;margin-left: 30px;">Challan Type : </b>' .$row['challan_type']. '<b style="font-weight: 900;margin-left: 30px;">Challan Type Detail : </b>' .$row['challan_type_detail'].
                                                '<br><br><b style="font-weight: 900;">Inspection Date : </b>' .$row['inspection_date']. '<b style="font-weight: 900;margin-left: 30px;">Delivery Location : </b>' .$row['delivery_location']. '<b style="font-weight: 900;margin-left: 30px;"> Vehicle Type & Plate #  : </b>' .$row['vehicle_type_and_plate'].  '<b style="font-weight: 900;margin-left: 30px;"> PO CMU Date : </b>' .$row['po_cmu_date'] . '<b style="font-weight: 900;margin-left: 30px;"> PO# CMU  : </b>' .$row['po_cmu_no']. '<b style="font-weight: 900;margin-left: 30px;">PO GF Date : </b>' .$row['po_gf_date'].
                                                '<br><br><b style="font-weight: 900;">PO# GF : </b>' .$row['po_gf_no']. '<b style="font-weight: 900;margin-left: 30px;">Date Of Receiving : </b>' .$row['date_of_receiving']. '<b style="font-weight: 900;margin-left: 30px;"> Air waybill No : </b>'  .$row['air_bill_no']. '<b style="font-weight: 900;margin-left: 30px;"> Shipment number : </b>' .$row['shipment_no']. '<b style="font-weight: 900;margin-left: 30px;">Origin of Country : </b>' .$row['origin_of_country']. '<b style="font-weight: 900;margin-left: 30px;">Weight of consignment : </b>' .$row['consignment_weight'];?>
                                            </td>
                                        </tr>
                                        <?php 
                                            } else{?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">Warehouse : </b>' .$row['wh_from']; 
                                                 ?>
                                            </td>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">DC Number : </b>' .$row['dc_no'] . '<b style="font-weight: 900;margin-left: 30px;">DC Date : </b>' .$row['dc_date'] .'<b style="font-weight: 900;margin-left: 30px;">Invoice : </b>' .$row['invoice']. 
                                                 '<b style="font-weight: 900;margin-left: 30px;">Challan Type : </b>' .$row['challan_type']. '<b style="font-weight: 900;margin-left: 30px;">Challan Type Detail : </b>' .$row['challan_type_detail'].
                                                '<br><br><b style="font-weight: 900;">Inspection Date : </b>' .$row['inspection_date']. '<b style="font-weight: 900;margin-left: 30px;">Delivery Location : </b>' .$row['delivery_location']. '<b style="font-weight: 900;margin-left: 30px;"> Vehicle Type & Plate #  : </b>' .$row['vehicle_type_and_plate'].  '<b style="font-weight: 900;margin-left: 30px;"> PO CMU Date : </b>' .$row['po_cmu_date'] . '<b style="font-weight: 900;margin-left: 30px;"> PO# CMU  : </b>' .$row['po_cmu_no']. '<b style="font-weight: 900;margin-left: 30px;">PO GF Date : </b>' .$row['po_gf_date'].
                                                '<br><br><b style="font-weight: 900;">PO# GF : </b>' .$row['po_gf_no']. '<b style="font-weight: 900;margin-left: 30px;">Date Of Receiving : </b>' .$row['date_of_receiving']. '<b style="font-weight: 900;margin-left: 30px;"> Air waybill No : </b>'  .$row['air_bill_no']. '<b style="font-weight: 900;margin-left: 30px;"> Shipment number : </b>' .$row['shipment_no']. '<b style="font-weight: 900;margin-left: 30px;">Origin of Country : </b>' .$row['origin_of_country']. '<b style="font-weight: 900;margin-left: 30px;">Weight of consignment : </b>' .$row['consignment_weight'];?>
                                            </td>
                                            <?php  }
                                            $i++;
                                            }
                                        }
                                            ?>
                                    </tbody>
                                </table>
                                <br>
                                
                                <div style="overflow-x: scroll;width:100%;">
                                                        <!-- Table -->
                                <table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable">
                                    
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th style="background-color: #ddffdd;font-size:14px;border-left: 6px solid #04AA6D;border-right: 6px solid #04AA6D;"> Electronic Approval</th>
                                            <th> Product </th>
                                            <!--<th> Warehouse Location </th>-->
                                            <th> Storage </th>
                                            <th> Manufacturer </th>
                                            <?php 
//                                            $sr = 0;
//                                            foreach ($stockReceive as $row) {
//                                               if(isset($row['product_type']) && $row['product_type'] == '36' && $sr == 0) {?>
                                            
                                            <th> Batch </th>
                                            <th> Mfg Date </th>
                                            <th> Exp Date </th>
                                            <th> Shelf Life </th>
                                            
                                            <?php // $sr++;
//                                               }
//                                            } ?>
                                            <th> Serial No </th>
                                            <th> Warranty </th>
                                            <th> Pack Size </th>
                                            <th> Unit Price </th>
                                            <th> Currency </th>
                                            <th> Conversion Rate </th>
                                            <th> PO Quantity </th>
                                            <th> DC Quantity </th>
                                            <th> Actual Received Quantity </th>
                                            <th> GWIS PI Quantity </th>
                                            <th> GWIS TI Quantity </th>
                                            <th> Received Quantity </th>
                                            <th> Total Price </th>
                                            <th> Approver Comment</th>
                                            <th> DTL Values</th>
                                            <th> DTL Result</th>
                                            <!--<th> Adjustment Type</th>-->
                                            <!--<th style="width: 1%;"> <input type="checkbox" id="checkAll" /></th>-->
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 
                                    
                                    <!-- Table body -->
                                    <tbody>
                                        <!-- Table row -->
                                        <?php
                                        if(isset($rejected_real_masterid))
                                        {
                                            foreach ($rejected_real_masterid as $row) {?>
                                        
                                            <input type="hidden" id="stkmasterid" name='stkmasterid' value="<?php echo $row['stkmasterid']; ?>" />
                                        
                                        <?php }
                                            }
                                            $startDate = '';
                                            $i = 1;
                                            foreach ($stockReceive as $row) {?>
                                                <!-- <input type="hidden" id="detailpkid" name='detailpkid[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['pk_id']; ?>" />
                                                <input type="hidden" id="wh_from_supplier" name='wh_from_supplier' value="<?php echo $row['wh_id_from_supplier']; ?>" />
                                                <input type="hidden" id="wh_from" name='wh_from' value="<?php echo $row['wh_id_from']; ?>" />
                                                <input type="hidden" id="rejected_voucher" name='rejected_voucher' value="<?php if(isset($row['electronic_approval'])) {echo $row['electronic_approval'];} else{echo '';} ?>" />
                                                
                                                <input type="hidden" id="field1" name='field1[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field1']; ?>" />
                                                <input type="hidden" id="field2" name='field2[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field2']; ?>" />
                                                <input type="hidden" id="field3" name='field3[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field3']; ?>" />
                                                <input type="hidden" id="field4" name='field4[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field4']; ?>" />
                                                <input type="hidden" id="field5" name='field5[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field5']; ?>" />
                                                <input type="hidden" id="field6" name='field6[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field6']; ?>" />
                                                <input type="hidden" id="field7" name='field7[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field7']; ?>" />
                                                <input type="hidden" id="field8" name='field8[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field8']; ?>" />
                                                <input type="hidden" id="field9" name='field9[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field9']; ?>" />
                                                <input type="hidden" id="field10" name='field10[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field10']; ?>" />
                                                
                                                <input type="hidden" id="delivery_challan_type" name='delivery_challan_type[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['delivery_challan_type']; ?>" />
                                                <input type="hidden" id="challan_type_detail" name='challan_type_detail[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['challan_type_detail']; ?>" />
                                                <input type="hidden" id="driver_name" name='driver_name[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['driver_name']; ?>" />
                                                <input type="hidden" id="driver_contract" name='driver_contract[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['driver_contract']; ?>" />
                                                <input type="hidden" id="vehicle_reg" name='vehicle_reg[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['vehicle_reg']; ?>" />
                                                <input type="hidden" id="dc_no" name='dc_no[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['dc_no']; ?>" />
                                                <input type="hidden" id="dc_date" name='dc_date[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['dc_date']; ?>" />
                                                <input type="hidden" id="invoice" name='invoice[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['invoice']; ?>" />
                                        
                                                <input type="hidden" id="masterpkid" name='masterpkid' value="<?php echo $row['masterpkid']; ?>" />
                                                <input type="hidden" id="tran_no" name='tran_no' value="<?php echo $row['tran_no']; ?>" />
                                                <input type="hidden" id="batch_id" name='batch_id[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['batch_id']; ?>" />
                                               
                                                <input type="hidden" id="stk_id" name='stk_id' value="<?php echo $row['stk_id']; ?>" />
                                                
                                                <input type="hidden" id="inspection_date" name='inspection_date' value="<?php echo $row['inspection_date']; ?>" />
                                                <input type="hidden" id="delivery_location" name='delivery_location' value="<?php echo $row['delivery_location']; ?>" />
                                                <input type="hidden" id="po_cmu_no" name='po_cmu_no' value="<?php echo $row['po_cmu_no_id']; ?>" />
                                                <input type="hidden" id="po_cmu_date" name='po_cmu_date' value="<?php echo $row['po_cmu_date']; ?>" />
                                                <input type="hidden" id="po_gf_no" name='po_gf_no' value="<?php echo $row['po_gf_no_id']; ?>" />
                                                <input type="hidden" id="po_gf_date" name='po_gf_date' value="<?php echo $row['po_gf_date']; ?>" />
                                                <input type="hidden" id="date_of_receiving" name='date_of_receiving' value="<?php echo $row['date_of_receiving']; ?>" />
                                                <input type="hidden" id="air_bill_no" name='air_bill_no' value="<?php echo $row['air_bill_no']; ?>" />
                                                <input type="hidden" id="shipment_no" name='shipment_no' value="<?php echo $row['shipment_no']; ?>" />
                                                <input type="hidden" id="origin_of_country" name='origin_of_country' value="<?php echo $row['origin_of_country']; ?>" />
                                                <input type="hidden" id="vehicle_type_and_plate" name='vehicle_type_and_plate' value="<?php echo $row['vehicle_type_and_plate']; ?>" />
                                                <input type="hidden" id="consignment_weight" name='consignment_weight' value="<?php echo $row['consignment_weight']; ?>" />
                                                <input type="hidden" id="file" name='file' value="<?php echo $row['file']; ?>" />
                                                <input type="hidden" id="pi_type" name='pi_type[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['pi_type']; ?>" />
                                                <input type="hidden" id="sbtr_dc_rec" name='sbtr_dc_rec[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['sbtr_dc_rec']; ?>" />    
                                                <input type="hidden" id="shipment_temperature" name='shipment_temperature[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['shipment_temprature']; ?>" /> -->
                                                <?php
                                                if(isset($row['field3']))
                                                {
                                                    $startDate = new DateTime($row['field3']);
                                                }
                                                else{
                                                    $startDate = new DateTime();
                                                }
                                                
                                                if(isset($row['field2']) && !empty($row['field2']))
                                                {
                                                    $endDate = new DateTime($row['field2']);
                                                }
                                                else
                                                {
                                                    $endDate = new DateTime(date("Y-m-d",strtotime($row['tran_date'])));
                                                }
                                                
                                                // $difference = $endDate->diff($startDate);
                                                // $daysss = $difference->format("%a");
                                                
                                                // $months = floor($daysss / 30);
                                                // $dayss = $daysss - ($months*30);
                                                // $days = $months ." Months " . $dayss ." Days";
                                                
                                                $stockID = $row['fk_stock_id'];
                                                $issuance_date = $row['tran_date'];
                                                ?>
                                        <tr>
                                            <td style="background-color: #ddffdd;font-size:14px;border-left: 6px solid #04AA6D;border-right: 6px solid #04AA6D;">
                                                <?php if (in_array("69", $approver_desg_id)){
                                                ?>    
                                                <select disabled="" name="approve_or_rej[<?php echo $row['pk_id']; ?>]" id="approve_or_rej" required class="select2me input-medium" style="width:100%;padding:10%;">
                                                    
                                                    <option value="1" <?php // if(isset($_REQUEST['tranno']) && $row['dtl'] = '1')  echo "selected='selected'";  ?>>Approve</option>
                                                    <!--<option value="2" <?php // if(isset($_REQUEST['tranno']) && $row['dtl'] = '2')  echo "selected='selected'";  ?>>Reject</option>-->
                                                </select>
                                                <input type="hidden" id="approve_or_rej" name='approve_or_rej[<?php echo $row['pk_id']; ?>]' value="1" />
                                                <?php } else { ?>
                                                <select name="approve_or_rej[<?php echo $row['pk_id']; ?>]" id="approve_or_rej" required class="select2me input-medium" style="width:100%;padding:10%;">
                                                    
                                                    <option value="1" <?php // if(isset($_REQUEST['tranno']) && $row['dtl'] = '1')  echo "selected='selected'";  ?>>Approve</option>
                                                    <option value="2" <?php // if(isset($_REQUEST['tranno']) && $row['dtl'] = '2')  echo "selected='selected'";  ?>>Reject</option>
                                                </select>
                                                <?php } ?>
                                            </td>
                                            <td style="white-space: nowrap;"><?php echo $row['itm_name']; ?>
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-qty" name='itm_id[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['itm_id']; ?>" />     -->
                                            </td>
                                            
<!--                                            <td><input <?php if (in_array("69", $approver_desg_id)){ echo ''; }else { echo ''; } ?> style="width:100px" type="text" name="wh_location[<?php echo $row['pk_id']; ?>]" id="<?php echo $i; ?>-missing" value="<?php if(!empty($row['wh_location'])) { echo $row['wh_location'];} ?>" class="form-control input-sm input-small" /></td>-->
                                            
                                            <td>
                                                <select name="storage_info[<?php echo $row['pk_id']; ?>]" id="storage_info" required class="select2me input-medium" style="width:100%;padding:10%;">
                                                    <option value="">Select</option>
                                                    <?php foreach ($storage as $rowstorage) { ?>
                                                        <option value="<?php echo $rowstorage['pk_id'] ?>" ><?php echo $rowstorage['name'] ?></option>
                                                    <?php } ?>
                                                </select>
                                            </td>
                                            
                                            <td  style="white-space: nowrap;"><?php echo $row['manufacturer_name']; ?>
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-qty" name='manufacturer[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['manufacturer']; ?>" /> -->
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-qty" name='manufacturer_name[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['manufacturer_name']; ?>" /> -->
                                            </td>
                                            
                                            <?php // if(isset($row['product_type']) && $row['product_type'] == '36') {?>
                                            
                                            <td><?php if(isset($row['field1'])) echo $row['field1']; ?>
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-batch_no" name='batch_no[<?php echo $row['pk_id']; ?>]' value="<?php if(isset($row['field1'])) echo $row['field1']; ?>" /> -->
                                            </td>
                                            <td style="white-space: nowrap;"><?php if(isset($row['field2'])) echo $row['field2']; ?>
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-batch_no" name='production_date[<?php echo $row['pk_id']; ?>]' value="<?php if(isset($row['field2'])) echo $row['field2']; ?>" /> -->
                                            </td>
                                            <td style="white-space: nowrap;"><?php if(isset($row['field3'])) echo $row['field3']; ?>
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-batch_no" name='batch_expiry[<?php echo $row['pk_id']; ?>]' value="<?php if(isset($row['field3'])) echo $row['field3']; ?>" /> -->
                                            </td>
                                            <td  style="white-space: nowrap;" ><?php echo shelf_life($row['tran_date'],$row['batch_expiry']); ?></td>
                                            
                                            <?php // } ?>
                                            
                                            <td style="white-space: nowrap;"><?php echo $row['field4']; ?> </td>
                                            <td style="white-space: nowrap;"><?php echo $row['field5']; ?> </td>
                                            <td style="white-space: nowrap;"><?php echo $row['field6']; ?> </td>
                                            
                                            <td class="right srunitprice"><?php echo $row['unit_price']; ?>
                                                <input type="hidden" id="<?php echo $i; ?>-qty" name='unit_price[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['unit_price']; ?>" /></td>
                                            <td class="right">
                                                
                                                <select class="select2me input-medium" name="scurrency[]" id="scurrency" style="width:100%;padding:10%;" disabled <?php // if (isset($master_id)) echo 'disabled="true"' ?> >
                                                    <?php

                                                    foreach ($currency_type as $currencytype) {
                                                        ?>
                                                        <option value="<?php echo $currencytype['pk_id'] ?>" <?php if (isset($row['currency']) && $row['currency'] == $currencytype['pk_id']){ echo "selected='selected'"; } ?>><?php echo $currencytype['name'] ?></option>
                                                        <?php
                                                    }
                                                    ?>

                                                </select>  
                                                
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-qty" name='currency[<?php echo $row['pk_id']; ?>]' value="<?php echo abs($row['currency']); ?>" /></td> -->
                                            <td class="right srconversionrate"><?php echo $row['conversion_rate']; ?>
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-qty" name='conversion_rate[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['conversion_rate']; ?>" /></td> -->
                                            <td class="right"><?php echo 0; ?></td>
                                            <td class="right"><?php echo number_format(abs($row['dc_quantity'])); ?>
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-qty" name='dc_quantity[<?php echo $row['pk_id']; ?>]' value="<?php echo abs($row['dc_quantity']); ?>" /></td> -->
                                            <td class="right"><?php echo number_format(abs($row['actual_rec_qty'])); ?>
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-qty" name='actual_rec_qty[<?php echo $row['pk_id']; ?>]' value="<?php echo abs($row['actual_rec_qty']); ?>" /></td> -->
                                            <td class="right"><?php echo number_format(abs($row['pi_quantity'])); ?>
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-qty" name='pi_quantity[<?php echo $row['pk_id']; ?>]' value="<?php echo abs($row['pi_quantity']); ?>" /></td> -->
                                            <td class="right tiqty"><?php echo number_format(abs($row['ti_quantity'])); ?>
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-qty" name='ti_quantity[<?php echo $row['pk_id']; ?>]' value="<?php echo abs($row['ti_quantity']); ?>" /></td> -->
                                            
                                            <td><input <?php if (in_array("69", $approver_desg_id)){ echo ''; }else { echo 'readonly'; } ?> style="width:100px" type="number" name="missing[<?php echo $row['pk_id']; ?>]" id="<?php echo $i; ?>-missing" value="<?php if(!empty(floatval($row['grn_quantity']))) { echo $row['grn_quantity'];} else {echo abs($row['ti_quantity']);} ?>" min="0" class="form-control input-sm input-small srmissingqty" /></td>
                                            <td><input style="width:100px" type="number" readonly name="batch_totalprice[<?php echo $row['pk_id']; ?>]" id="<?php echo $i; ?>-batch_totalprice" value="<?php if(isset($row['batch_totalprice']) && !empty($row['batch_totalprice'])) { echo $row['batch_totalprice'];} ?>" min="0" class="form-control input-sm input-small batch_totalprice" /></td>
                                            <td><textarea style="width:150px" name="comment[<?php echo $row['pk_id']; ?>]" id="<?php echo $i; ?>-comment" value='<?php if(isset($row['comments']) && !empty($row['comments'])) { echo $row['comments'];} ?>' class="form-control input-sm input-small" ></textarea></td>
                                            
                                            <td>
                                                <?php if($row['dtl'] == '1') { echo 'Not Required';} else { echo 'Required';} ?>
                                                <select style="display: none;" name="dtl[<?php echo $row['pk_id']; ?>]" id="dtl"  >
                                                    <option value="1" <?php if(isset($row['dtl']) && $row['dtl'] == '1') echo 'selected="selected"';  ?> >Not Required</option>
                                                    <option value="2" <?php if(isset($row['dtl']) && $row['dtl'] == '2') echo 'selected="selected"';  ?>  >Required</option>
                                                </select>
                                            </td>
                                            
                                            <td>
                                                <?php if($row['dtl_result'] == '1') {echo 'N/A';} else if($row['dtl_result'] == '2') {echo 'Result Pending';} 
                                                   else if($row['dtl_result'] == '3' && $row['dtl'] == '2') {echo 'Positive';} else if($row['dtl_result'] == '4' && $row['dtl'] == '2') {echo 'Negative';} else { echo 'N/A';}  ?>
                                                <select style="display: none;" name="dtl_result[<?php echo $row['pk_id']; ?>]" id="dtl_result"  >
                                                    <option value="1" <?php if(isset($row['dtl_result']) && $row['dtl_result'] == '1') echo 'selected="selected"';  ?>  >N/A</option>
                                                    <option value="2" <?php if(isset($row['dtl_result']) && $row['dtl_result'] == '2') echo 'selected="selected"';  ?>   >Result Pending </option>
                                                    <option value="3" <?php if(isset($row['dtl_result']) && $row['dtl_result'] == '3') echo 'selected="selected"';  ?>   >Positive</option>
                                                    <option value="4" <?php if(isset($row['dtl_result']) && $row['dtl_result'] == '4') echo 'selected="selected"';  ?>   >Negative</option>
                                                </select>
                                            </td>

                                            <!--<td class="col-md-3">-->
<!--                                                <select name="types[<?php echo $row['pk_id']; ?>]" id="<?php echo $i; ?>-types" class="form-control input-sm input-small types_select">
                                                    <?php
//                                                        if (!empty($types)) {
//                                                            
//                                                            foreach ($types as $type) {
//                                                                if($type->trans_id != 20 && $type->trans_id != 24)
//                                                                echo "<option value=" . $type->trans_id . ">" . $type->trans_type . "</option>";
//                                                            }
//                                                        }
                                                        ?>
                                                </select>-->
                                            <!--</td>-->
<!--                                            <td class="center"><input type="checkbox" name="stockid[<?php echo $row['pk_id']; ?>]" value="<?php echo $row['pk_id']; ?>" /></td>-->
                                            <input type="checkbox" checked=“true” name="stockid[<?php echo $row['pk_id']; ?>]" value="<?php echo $row['pk_id']; ?>" style="display:none;" />
                                        </tr>
                                        <?php $i++;
                                            } ?>
<!--                                        <tr>
                                            <td style="text-align: right;font-weight: bold;" colspan="14">Grand Total</td>
                                            <td id="gtotal"><?php echo '0' ?></td>
                                            <td colspan="4"></td>
                                        </tr>-->
                                        <!-- // Table row END -->
                                    </tbody>
                                    <!-- // Table body END -->
                                    
                                </table>
                                <!-- // Table END --> 
                                </div>        
                                            
                                            
                                <div class="form-group row">
                                    <!--<div class="col-md-12">-->
<!--                                        <div class="col-md-2">
                                            <div class="control-group">
                                                <br>
                                                <button type="submit" id="stockreceive_buttons" name="wh_btn" class="btn btn-primary waves-effect waves-light" > Save</button>
                                            </div>
                                        </div>-->
                                    <div class="col-md-3">
                                        <div class="control-group">
                                            <label class="control-label" for="remarks">Approver Remarks </label>
                                            <div class="controls">
                                                <textarea name="remarks" id="remarks" class="form-control" 
                                                          <?php
                                                            if(isset($ReceivedRemarks) && !empty($ReceivedRemarks)){
                                                                echo 'value="' . $ReceivedRemarks . '"';
                                                            }
                                                          ?>
                                                          ></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-2">
                                        <div class="control-group">
                                            <label class="example-text-input" for="fileToUploads"  >Select File to upload:</label>
                                            <div class="controls">
                                                <input type="file" name="fileToUpload">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-1">
                                        <div class="control-group">
                                            <div class="controls">
                                                <?php 
                                                $i = 0;
                                                foreach ($stockReceive as $row) {
                                                    if($i < 1)
                                                {
                                                    ?>

                                                <a href="<?php echo base_url(); ?>uploads/<?php echo $row['file']; ?>" target="_blank">View Uploaded File</a>
                                                <!--// For Download-->
                                                <!--<a href="<?php echo base_url(); ?>uploads/<?php echo $row['file']; ?>" download>Download</a>-->

                                                <?php $i++;
                                                    } 
                                                } ?>
                                            </div>
                                        </div>
                                    </div>

                                    <!--</div>-->
                                </div> 
                                            
                                            
                                            
                                            
<!--                                            <div class="form-group row">
                                                <div class="col-md-12">
                                                    <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="control-label" for="remarks"> Remarks </label>
                                                            <div class="controls">
                                                                <textarea name="remarks" id="remarks" class="form-control" ></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="control-label" for="rec_ref"> Receive Reference </label>
                                                            <div class="controls">
                                                                <input name="rec_ref" readonly id="rec_ref" type="text" class="form-control input-sm input-small" value="<?=$issue_no?>" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="control-label" for="rec_date"> Receive Date </label>
                                                            <div class="controls">
                                                                <input name="rec_date" id="rec_date"  class="form-control input-sm input-small" value="<?php echo date("d/m/Y"); ?>" type="text" readonly />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-md-3 right">
                                                        <div class="control-group">
                                                            <label class="control-label">&nbsp;</label>
                                                        </div>
                                                        <div class="controls">
                                                            <button type="submit" id="save" class="btn btn-primary"> Save </button>
                                                            <input type="hidden" name="stock_id" id="stock_id" value="<?php if(isset($stockID)) echo $stockID; ?>"/>
                                                            <input type="hidden" name="issue_no" id="issue_no" value="<?php echo $issue_no ?>">
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                            </div>-->


                                            <div class="form-group row">
                                                <div class="col-md-12" style="text-align:center;">
                                                    <button type="submit" id="stockreceive_buttons" name="wh_btn" class="btn btn-success waves-effect waves-light" > Save</button>
                                                    <a href="<?php echo base_url("dashboard/index"); ?> " class="btn btn-danger" title="cancel">Cancel</a>
                                                    <!--<button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" > Add Receiving</button>-->
                                                </div>  
                                                <!--<div class="col-md-2">-->
                                                    <input type="hidden" name="stock_id" id="stock_id" value="<?php if(isset($stockID)) echo $stockID; ?>"/>
                                                    <input type="hidden" name="pkdetailid" id="pkdetailid" value="<?php if(isset($pkdetailid)) echo $pkdetailid; ?>">
                                                    <input type="hidden" name="pkmasterid" id="pkmasterid" value="<?php if(isset($pkmasterid)) echo $pkmasterid; ?>">
                                                    <input type="hidden" name="detailid" id="detailid" value="<?php if(isset($detailid)) echo $detailid; ?>">
                                                    <input type="hidden" name="masterid" id="masterid" value="<?php if(isset($masterid)) echo $masterid; ?>">
                                                    <input type="hidden" name="batchid" id="batchid" value="<?php if(isset($batchid)) echo $batchid; ?>">
                                                    <input type="hidden" name="receiveno" id="receiveno" value="<?php if(isset($_REQUEST['receiveno'])) echo $_REQUEST['receiveno']; ?>">
                                                    <input type="hidden" name="receivetype" id="receivetype" value="<?php if(isset($_REQUEST['receivetype'])) echo $_REQUEST['receivetype']; ?>">
                                                    <input type="hidden" name="receive_from_supplier" id="receive_from_supplier" value="<?php if(isset($gwis_supplier)) echo $gwis_supplier; ?>">
                                                    <input type="hidden" name="receive_from_warehouse" id="receive_from_warehouse" value="<?php if(isset($gwis_warehouse)) echo $gwis_warehouse; ?>">
                                                    <input type="hidden" name="challan_type" id="challan_type" value="<?php if(isset($gwis_challan_type)) echo $gwis_challan_type; ?>">
                                                     <?php  foreach($approval_codess as $approval_codes)
                                                            {?>
                                                            <input type="hidden" name="approvalcode[]" id="approvalcode" value="<?php if(isset($approval_codes) && !empty($approval_codes)) { echo $approval_codes;}else { echo '';} ?>"> 
                                                            <?php } foreach($approval_code_idd as $approval_code_id)
                                                            {?>
                                                            <input type="hidden" name="approval_code_id[]" id="approval_code_id" value="<?php if(isset($approval_code_id) && !empty($approval_code_id)) { echo $approval_code_id;}else { echo '';} ?>">
                                                            <?php } foreach($approve_fromm as $approve_from)
                                                            {?>
                                                            <input type="hidden" name="approve_from[]" id="approve_from" value="<?php if(isset($approve_from) && !empty($approve_from)) { echo $approve_from;}else { echo '';} ?>">
                                                            <?php } foreach($approve_too as $approve_to)
                                                            {?>
                                                            <input type="hidden" name="approve_to[]" id="approve_to" value="<?php if(isset($approve_to) && !empty($approve_to)) { echo $approve_to;}else { echo '';} ?>">
                                                            <?php } foreach($process_statuss as $process_status)
                                                            {?>
                                                            <input type="hidden" name="process_status[]" id="process_status" value="<?php if(isset($process_status) && !empty($process_status)) { echo $process_status;}else { echo '';} ?>">
                                                            <?php } foreach($final_statuss as $final_status)
                                                            {?>
                                                            <input type="hidden" name="final_status[]" id="final_status" value="<?php if(isset($final_status) && !empty($final_status)) { echo $final_status;}else { echo '';} ?>">
                                                            <?php } ?>
                                                <!--</div>-->  
<?php if (isset($temp_records) && (!empty($temp_records))) {
    ?>                                              
                                                    <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>"> 
                                                <?php }
                                                ?>    
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <br>

                        </form>
                        <?php }
                        ?>
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>
