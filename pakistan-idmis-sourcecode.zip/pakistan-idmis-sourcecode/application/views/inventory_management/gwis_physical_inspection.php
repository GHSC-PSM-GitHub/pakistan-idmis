<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
}
    
</style>
<?php
$from_id = '';
//print_r($tran_reference_number);exit;
if (isset($gwis_data)) {
    $row = $gwis_data[0];
//    print_r($row);exit;
    $date1 = str_replace('-', '/', $row['batch_expiry']);  
    $date2 = str_replace('-', '/', $row['production_date']);  
    $date3 = str_replace('-', '/', $row['dc_date']);
    $batch_expiry = date('m/d/Y', strtotime($date1));
    $production_date   = date('m/d/Y', strtotime($date2));
    $dc_date   = date('m/d/Y', strtotime($date3));
    $batch_no = $row['batch_no'];
//    $batch_expiry = $row['batch_expiry'];
    $item_id = $row['item_id'];
    $unit_price = $row['unit_price'];
//    $production_date = $row['production_date'];
    $vvm_type = $row['vvm_type'];
    $quantity = $row['quantity'];
    $dc_quantity = $row['dc_quantity'];
    $pi_quantity = $row['pi_quantity'];
    $ti_quantity = $row['ti_quantity'];
    $funding_source = $row['funding_source'];
    $pi_comment = $row['pi_comment'];
    $ti_comment = $row['ti_comment'];
    $delivery_challan_type = $row['delivery_challan_type'];
    $challan_type_detail = $row['challan_type_detail'];
    $dc_no = $row['dc_no'];
//    $dc_date = $row['dc_date'];
    $invoice = $row['invoice'];
    $po_quantity = $row['po_quantity'];
    $actual_rec_qty = $row['actual_rec_qty'];
    $vehicle_reg = $row['vehicle_reg'];
    $driver_contract = $row['driver_contract'];
    $driver_name = $row['driver_name'];
    $wh_id_from_supplier = $row['wh_id_from_supplier'];
    $currency = $row['currency'];
    $conversion_rate = $row['conversion_rate'];
    $wh_id_from = $row['wh_id_from'];
    $tran_ref = $row['tran_ref'];
    $fkstockid = $row['fk_stock_id'];
    $pkdetailid = $row['pk_id'];
    $batchid = $row['batch_id'];
    $editstkid = $row['stk_id'];
    
    $cinspection_date = str_replace('-', '/', $row['inspection_date']);  
    $inspection_date = date('m/d/Y', strtotime($cinspection_date));
    $delivery_location = $row['delivery_location'];
    $po_cmu_no = $row['po_cmu_no'];
    $cpo_cmu_date = str_replace('-', '/', $row['po_cmu_date']);  
    $po_cmu_date = date('m/d/Y', strtotime($cpo_cmu_date));
    $po_gf_no = $row['po_gf_no'];
    $cpo_gf_date = str_replace('-', '/', $row['po_gf_date']); 
    $po_gf_date = date('m/d/Y', strtotime($cpo_gf_date));
    $pi_type = $row['pi_type'];
    $sbtr_dc_rec = $row['sbtr_dc_rec'];
    
    $cdate_of_receiving = str_replace('-', '/', $row['date_of_receiving']);  
    $date_of_receiving = date('m/d/Y', strtotime($cdate_of_receiving));
    $air_bill_no = $row['air_bill_no'];
    $shipment_no = $row['shipment_no'];
    $origin_of_country = $row['origin_of_country'];
    $vehicle_type_and_plate = $row['vehicle_type_and_plate'];
    $consignment_weight = $row['consignment_weight'];
//    $districts = $districts->result_object();
//    $tehsils = $tehsils->result_object();
//    $ucs = $ucs->result_object();
//    $str_arr = str_replace("-",",",$string);
//    $age = explode (",", $str_arr);
//    $diff = abs(strtotime(date("Y-m-d"))-strtotime($string));
//    $years = floor($diff / (365*60*60*24));
//    print_r($years);
//    $patient_month = $row['patient_month'];
//    $email = $row['email'];
//    $patient_id = $row['pk_id'];
//    print_r($age);
    
}

if (isset($stock_master_records)) {
    $row = $stock_master_records[0];
    $refernce_number = $row['tran_ref'];
    $supplier_from = $row['wh_id_from_supplier'];
    $warehouse_from_supplier = $row['wh_id_from_supplier'];
    $warehouse_from = $row['wh_id_from'];
    $warehouse_from_warehouse = $row['wh_id_from'];
    
    //Check 
//    $from_id = $row['wh_id_from'];
    $from_id = $row['source_type'];
    $TranRef = $row['tran_ref'];
    
} else if (isset($tran_reference_number)) {

    $refernce_number = $tran_reference_number;
}

// Change the line below to your timezone!
date_default_timezone_set('Asia/Karachi');
$receivedatetime = date('m/d/Y h:i:s a', time());
//$receivedatetime = date('m/d/Y H:i:s',strtotime(date(). ' '.date_default_timezone_set("Asia/Karachi"))); 

?>
<div id="ajaxloadcss">
    <?php // include "stock_receive_js.php"; ?>
    <!--<link id="ajaxloadcss" href="" rel="stylesheet" type="text/css">-->
</div>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>GIWS</h3>
                        <?php // print_r(implode(",", $_SESSION['approval_code_id'])); ?>
                    </div>
                    
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="delivery_challan" name="delivery_challan" enctype="multipart/form-data" action="<?php echo base_url("inventory_management/gwis_physical_inspection"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            
                                            <div class="form-group row"> 
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="challan_number" required >GIWS Number </label>
                                                        <div class="controls">
                                                            <input type="text" name="challan_number" id="challan_number" class="form-control" readonly value="Auto Generated" <?php if (isset($master_id)) echo 'readonly="true"' ?> 
                                                                <?php
//                                                                if (isset($refernce_number)) {
//                                                                    echo 'value="' . $refernce_number . '"';
//                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf"  >GIWS Date(MM/DD/YYYY)<span style="color: red">*</span>  </label>
                                                        <div class="controls">
                                                            <input required type="text" class="form-control" name="receiving_time" id="giws_date" <?php if (isset($master_id)) echo 'disabled="true"' ?>
                                                                    <?php
                                                                    if (isset($form['receiving_time'])) {
                                                                        echo 'value="' . $form['receiving_time'] . '"';
                                                                    }else  {
                                                                        echo 'value="' . date("m/d/Y") . '"';
                                                                    }
                                                                    ?>
                                                                   >

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="challan_type" required >Source Doc Type <span style="color: red">*</span> </label>     
                                                        <div class="controls">
                                                            <?php
                                                        
                                                        if (isset($challan_type) && !empty($challan_type)) {
                                                            
                                                        ?>
                                                        <select class="select2me input-medium" name="challan_type" id="challan_type" style="width:100%;padding:10%;" <?php if (isset($master_id)) echo 'disabled="true"' ?> >
                                                            <option value="">Select</option>
                                                            <?php
                                                                   if(isset($form['challan_type']))
                                                                   {
                                                                       $ctype = '';
                                                                   }
                                                                   else
                                                                   {
                                                                       $ctype = '2';
                                                                   }
                                                            foreach ($challan_type as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($delivery_challan_type) && $delivery_challan_type == $row['pk_id']){ echo "selected='selected'";}else if (isset($form['challan_type']) && $form['challan_type'] == $row['pk_id']){ echo "selected='selected'";}else if ( $ctype == $row['pk_id']){ echo "selected='selected'";} ?>><?php echo $row['challan_type'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                        <?php
                                                        }
                                                        if(isset($master_id)) { ?>
                                                            
                                                            <input type="hidden" class="form-control" name="challan_type" id="challan_type" value="<?php if (isset($form['challan_type'])){ echo $form['challan_type'];} else if(isset($delivery_challan_type)) {echo $delivery_challan_type;} ?>" >
                                                            
                                                        <?php } ?>

                                                        </div>
                                                    </div>
                                                </div>
                                                
<!--                                                <div class="col-md-3" id="po_type_detail" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="po_detail_info" required >PO# <span style="color: red">*</span> </label>     
                                                        <div class="controls">
                                                            <input type="text"  name="po_detail_info" id="po_detail_info" class="form-control"   <?php // if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
//                                                                if (isset($form['po_detail_info'])) {
//                                                                    echo 'value="' . $form['po_detail_info'] . '"';
//                                                                }else if (isset($challan_type_detail)) {
//                                                                    echo 'value="' . $challan_type_detail . '"';
//                                                                }
                                                                ?>
                                                                   >
                                                        </select>

                                                        </div>
                                                    </div>
                                                </div>-->
                                                
<!--                                                <div class="col-md-3" id="fo_type_detail" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="wh_detail_info" required >WH# <span style="color: red">*</span> </label>     
                                                        <div class="controls">
                                                            <input type="text"  name="wh_detail_info" id="wh_detail_info" class="form-control" -->
                                                                                                            <?php // if (isset($master_id)) echo 'readonly="true"' ?>    
                                                                <?php
//                                                                if (isset($form['wh_detail_info'])) {
//                                                                    echo 'value="' . $form['wh_detail_info'] . '"';
//                                                                }else if (isset($challan_type_detail)) {
//                                                                    echo 'value="' . $challan_type_detail . '"';
//                                                                }
                                                                ?>
<!--                                                                   >
                                                        </select>

                                                        </div>
                                                    </div>
                                                </div>-->
                                                
<!--                                                <div class="col-md-3" id="nr_type_detail" style="display:none;">
                                                        <div class="control-group">
                                                            <label class="example-text-input" for="hf" required >Ref No/Letter No </label>
                                                            <div class="controls">
                                                                <input type="text" name="refernce_number" id="reference_number" class="form-control" <?php // if (isset($master_id)) echo 'readonly="true"' ?>
                                                                    <?php
                                                                    if (isset($form['refernce_number']) && !empty($form['refernce_number']))
                                                                    {
                                                                        echo 'value="' . $form['refernce_number'] . '"';
                                                                    }else if (isset($tran_ref) && !empty($tran_ref))
                                                                    {
                                                                        echo 'value="' . $tran_ref . '"';
                                                                    }
                                                                    ?>
                                                                       >
                                                            </div>
                                                        </div>
                                                </div>-->
                                                
                                            </div>
                                            
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="inspection_date" required >Inspection Date(MM/DD/YYYY) </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="inspection_date" id="inspection_date" <?php if (isset($master_id)) echo 'disabled="true"' ?>
                                                                    <?php
                                                                    if (isset($form['inspection_date'])) {
                                                                        echo 'value="' . $form['inspection_date'] . '"';
                                                                    }
                                                                    else if (isset($inspection_date)) {
                                                                        echo 'value="' . $inspection_date . '"';
                                                                    } else {
                                                                        echo 'value="' . date("m/d/Y") . '"';
                                                                    }
                                                                    ?>
                                                                   >

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="delivery_location" required >Delivery Location </label>
                                                        <div class="controls">
                                                            <input type="text" name="delivery_location" id="delivery_location" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                
                                                                if (isset($form['delivery_location']) && !empty($form['delivery_location']))
                                                                {
                                                                    echo 'value="' . $form['delivery_location'] . '"';
                                                                }else if (isset($delivery_location) && !empty($delivery_location))
                                                                {
                                                                    echo 'value="' . $delivery_location . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="date_of_receiving" required >Date of Receiving(MM/DD/YYYY) </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="date_of_receiving" id="date_of_receiving" <?php if (isset($master_id)) echo 'disabled="true"' ?>
                                                                    <?php
//                                                                    echo '>>>>>'.$date_of_receiving;exit;
                                                                    if (isset($form['date_of_receiving'])) {
                                                                        echo 'value="' . $form['date_of_receiving'] . '"';
                                                                    }
                                                                    else if (isset($date_of_receiving)) {
                                                                        echo 'value="' . $date_of_receiving . '"';
                                                                    } else {
                                                                        echo 'value="' . date("m/d/Y") . '"';
                                                                    }
                                                                    ?>
                                                                   >

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="air_bill_no" required >Air waybill No. / Bill of Lading </label>
                                                        <div class="controls">
                                                            <input type="text" name="air_bill_no" id="air_bill_no" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['air_bill_no']) && !empty($form['air_bill_no']))
                                                                {
                                                                    echo 'value="' . $form['air_bill_no'] . '"';
                                                                }else if (isset($air_bill_no) && !empty($air_bill_no))
                                                                {
                                                                    echo 'value="' . $air_bill_no . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="shipment_no" required >Shipment number </label>
                                                        <div class="controls">
                                                            <input type="text" name="shipment_no" id="shipment_no" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['shipment_no']) && !empty($form['shipment_no']))
                                                                {
                                                                    echo 'value="' . $form['shipment_no'] . '"';
                                                                }else if (isset($shipment_no) && !empty($shipment_no))
                                                                {
                                                                    echo 'value="' . $shipment_no . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="origin_of_country" required >Origin of Country </label>
                                                        <div class="controls">
                                                            <input type="text" name="origin_of_country" id="origin_of_country" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['origin_of_country']) && !empty($form['origin_of_country']))
                                                                {
                                                                    echo 'value="' . $form['origin_of_country'] . '"';
                                                                }else if (isset($origin_of_country) && !empty($origin_of_country))
                                                                {
                                                                    echo 'value="' . $origin_of_country . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="vehicle_type_and_plate" required >Vehicle Type & Plate # </label>
                                                        <div class="controls">
                                                            <input type="text" name="vehicle_type_and_plate" id="vehicle_type_and_plate" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['vehicle_type_and_plate']) && !empty($form['vehicle_type_and_plate']))
                                                                {
                                                                    echo 'value="' . $form['vehicle_type_and_plate'] . '"';
                                                                }else if (isset($vehicle_type_and_plate) && !empty($vehicle_type_and_plate))
                                                                {
                                                                    echo 'value="' . $vehicle_type_and_plate . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="consignment_weight" required >Total weight of consignment </label>
                                                        <div class="controls">
                                                            <input type="text" name="consignment_weight" id="consignment_weight" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['consignment_weight']) && !empty($form['consignment_weight']))
                                                                {
                                                                    echo 'value="' . $form['consignment_weight'] . '"';
                                                                }else if (isset($consignment_weight) && !empty($consignment_weight))
                                                                {
                                                                    echo 'value="' . $consignment_weight . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
<!--                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="missing_short_qty" required >Missing / Short-Landed Units </label>
                                                        <div class="controls">
                                                            <input type="text" name="missing_short_qty" id="missing_short_qty" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['missing_short_qty']) && !empty($form['missing_short_qty']))
                                                                {
                                                                    echo 'value="' . $form['missing_short_qty'] . '"';
                                                                }else if (isset($missing_short_qty) && !empty($missing_short_qty))
                                                                {
                                                                    echo 'value="' . $missing_short_qty . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="damaged_broken_torn_qty" required >Damaged / Broken / Torn </label>
                                                        <div class="controls">
                                                            <input type="text" name="damaged_broken_torn_qty" id="damaged_broken_torn_qty" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['damaged_broken_torn_qty']) && !empty($form['damaged_broken_torn_qty']))
                                                                {
                                                                    echo 'value="' . $form['damaged_broken_torn_qty'] . '"';
                                                                }else if (isset($damaged_broken_torn_qty) && !empty($damaged_broken_torn_qty))
                                                                {
                                                                    echo 'value="' . $damaged_broken_torn_qty . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>-->
                                            
                                            <div class="form-group row">
                                            
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="po_cmu" required >PO# CMU<span style="color: red">*</span> </label>     
                                                        <div class="controls">
														<input type="text" name="po_cmu" id="po_cmu" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['po_cmu']) && !empty($form['po_cmu']))
                                                                {
                                                                    echo 'value="' . $form['po_cmu'] . '"';
                                                                }else if (isset($po_cmu_no) && !empty($po_cmu_no))
                                                                {
                                                                    echo 'value="' . $po_cmu_no . '"';
                                                                }
                                                                ?>
                                                                   >
                                                            <?php
                                                        
                                                        //if (isset($po_no_cmu_arr) && !empty($po_no_cmu_arr)) {
                                                            
                                                        ?>
                                                        <!-- <select class="select2me input-medium" name="po_cmu" id="po_cmu" style="width:100%;padding:10%;" <?php //if (isset($master_id)) echo 'disabled="true"' ?> >
                                                            <option value="">Select</option>
                                                            <?php
                                                            //foreach ($po_no_cmu_arr as $row) {
                                                                ?>
                                                                <option value="<?php //echo $row['pk_id'] ?>" <?php //if (isset($po_cmu_no) && $po_cmu_no == $row['pk_id']){ echo "selected='selected'";}else if (isset($form['po_cmu']) && $form['po_cmu'] == $row['pk_id']){ echo "selected='selected'";}else if ( $ctype == $row['pk_id']){ echo "selected='selected'";} ?>><?php echo $row['number'] ?></option>
                                                                <?php
                                                            //}
                                                            ?>

                                                        </select>   -->
                                                        <?php
                                                        //}
                                                        if(isset($master_id)) { ?>
                                                            
                                                            <input type="hidden" class="form-control" name="challan_type" id="challan_type" value="<?php if (isset($form['po_cmu'])){ echo $form['po_cmu'];} else if(isset($delivery_challan_type)) {echo $delivery_challan_type;} ?>" >
                                                            
                                                        <?php } ?>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3" id="show_po_cmu_date" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Date(MM/DD/YYYY) </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="po_cmu_date" id="po_cmu_date" <?php if (isset($master_id)){ echo 'disabled="true"'; }?>
                                                                    <?php
                                                                    if (isset($form['po_cmu_date'])) {
                                                                        echo 'value="' . $form['po_cmu_date'] . '"';
                                                                    }
                                                                    else if (isset($po_cmu_date)) {
                                                                        echo 'value="' . $po_cmu_date . '"';
                                                                    }
                                                                    else  {
                                                                        echo 'value="' . date("m/d/Y") . '"';
                                                                    }
                                                                    ?>
                                                                   >

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="po_gf" required >PO# GF <span style="color: red">*</span> </label>     
                                                        <div class="controls">
														<input type="text" name="po_gf" id="po_gf" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['po_gf']) && !empty($form['po_gf']))
                                                                {
                                                                    echo 'value="' . $form['po_gf'] . '"';
                                                                }else if (isset($po_gf_no) && !empty($po_gf_no))
                                                                {
                                                                    echo 'value="' . $po_gf_no . '"';
                                                                }
                                                                ?>
                                                                   >
                                                            <?php
                                                        
                                                        //if (isset($po_no_gf_arr) && !empty($po_no_gf_arr)) {
                                                            
                                                        ?>
                                                        <!-- <select class="select2me input-medium" name="po_gf" id="po_gf" style="width:100%;padding:10%;" <?php if (isset($master_id)) echo 'disabled="true"' ?> >
                                                            <option value="">Select</option>
                                                            <?php
                                                           // foreach ($po_no_gf_arr as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($po_gf_no) && $po_gf_no == $row['pk_id']){ echo "selected='selected'";}else if (isset($form['po_gf']) && $form['po_gf'] == $row['pk_id']){ echo "selected='selected'";}else if ( $ctype == $row['pk_id']){ echo "selected='selected'";} ?>><?php echo $row['number'] ?></option>
                                                                <?php
                                                            //}
                                                            ?>

                                                        </select>   -->
                                                        <?php
                                                        //}
                                                        if(isset($master_id)) { ?>
                                                            
                                                            <input type="hidden" class="form-control" name="challan_type" id="challan_type" value="<?php if (isset($form['po_gf'])){ echo $form['po_gf'];} else if(isset($delivery_challan_type)) {echo $delivery_challan_type;} ?>" >
                                                            
                                                        <?php } ?>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3" id="show_po_gf_date" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Date(MM/DD/YYYY) </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="po_gf_date" id="po_gf_date" <?php if (isset($master_id)){ echo 'disabled="true"'; }?>
                                                                    <?php
                                                                    if (isset($form['po_gf_date'])) {
                                                                        echo 'value="' . $form['po_gf_date'] . '"';
                                                                    }
                                                                    else if (isset($po_gf_date)) {
                                                                        echo 'value="' . $po_gf_date . '"';
                                                                    }
                                                                    else  {
                                                                        echo 'value="' . date("m/d/Y") . '"';
                                                                    }
                                                                    ?>
                                                                   >

                                                        </div>
                                                    </div>
                                                </div>
                                            
                                            </div>
                                            
                                            <div class="form-group row">
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Stakeholder<span style="color: red">*</span>  </label>
                                                    <div class="controls">
                                                        <select required class="select2me input-medium" name="stakeholder" id="stakeholder"  style="width:100%;padding:10%;" <?php if (isset($master_id)) echo 'disabled="true"' ?> >>
                                                            <option value="">Select</option>
                                                                <?php
                                                                foreach ($stakeholder as $row) {
                                                                    ?>
                                                                <option value="<?php echo $row['stkid'] ?>" <?php if (isset($form['stakeholder']) && $form['stakeholder'] == $row['stkid']) {echo "selected='selected'";}else if ((isset($editstkid)) && $editstkid == $row['stkid']) {echo "selected='selected'";} ?>><?php echo $row['stkname'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>
                                                <input type="hidden" value="<?php 
                                                                if (isset($form['stakeholder']) && !empty($form['stakeholder']))
                                                                {
                                                                    echo $form['stakeholder'] ;
                                                                } else if ((isset($form['sstakeholder'])) && !empty($form['sstakeholder']))
                                                                {
                                                                    echo $form['sstakeholder'] ;
                                                                } else if ((isset($editstkid)) && !empty($editstkid))
                                                                {
                                                                    echo $editstkid ;
                                                                }?>" name="sstakeholder" id="sstakeholder"> 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="dc_no" required >DC Number# </label>
                                                        <div class="controls">
                                                            <input type="text" name="dc_no" id="dc_no" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['dc_no']) && !empty($form['dc_no']))
                                                                {
                                                                    echo 'value="' . $form['dc_no'] . '"';
                                                                } else if (isset($dc_no) && !empty($dc_no))
                                                                {
                                                                    echo 'value="' . $dc_no . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="dc_date" required >DC Date </label>
                                                        <div class="controls">
                                                            <input type="text" name="dc_date" id="dc_date" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['dc_date']) && !empty($form['dc_date']))
                                                                {
                                                                    echo 'value="' . $form['dc_date'] . '"';
                                                                } else if (isset($dc_date) && !empty($dc_date))
                                                                {
                                                                    echo 'value="' . $dc_date . '"';
                                                                }
                                                                else{
                                                                    echo 'value=" '. date("m/d/Y"). '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="invoice" required >Invoice # </label>
                                                        <div class="controls">
                                                            <input type="text" name="invoice" id="invoice" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['invoice']) && !empty($form['invoice']))
                                                                {
                                                                    echo 'value="' . $form['invoice'] . '"';
                                                                }else if (isset($invoice) && !empty($invoice))
                                                                {
                                                                    echo 'value="' . $invoice . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                
                                                
                                            </div>
                                            
                                            <div class="form-group row">
                                                
                                                <div class="col-md-3" style="display:none;" id="show_receive_from_supplier" >
                                                    <label class="example-text-input" for="strength" required >Received From (Supplier)<span style="color: red">*</span> <?=(empty($temp_records) ) ? '<a class="btn btn-sm btn-primary" target="_blank" href="../warehouse_management/add_supplier">+</a>':''?></label>
                                                    <div class="controls">
                                                        <?php
                                                        
//                                                        if (empty($temp_records)) {
                                                            
                                                        ?>
                                                        <select class="select2me input-medium" name="receive_from_supplier" id="receive_from_supplier" style="width:100%;padding:10%;" <?php if (isset($master_id)) echo 'disabled="true"' ?> >
                                                            <option value="">Select</option>
                                                            <?php
                                                                                                                    
                                                            foreach ($suppliers as $row) {
                                                                ?>
                                                            <option value="<?php echo $row['wh_id'] ?>" <?php if (isset($wh_id_from_supplier) && $wh_id_from_supplier == $row['wh_id']){ echo "selected='selected'";} else if (isset($supplier_from) && $supplier_from == $row['wh_id']) echo "selected='selected'"; ?>><?php echo $row['wh_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                        <?php
//                                                        }else
//                                                        {
//                                                            foreach ($suppliers as $row) {
////                                                                if(isset($warehouse_from) && $warehouse_from == $row['stkid']) echo  '<input class="form-control" disabled value="'.$row['stkname'].'">';
//                                                                if(isset($warehouse_from_supplier) && $warehouse_from_supplier == $row['wh_id']) echo  '<input class="form-control" name="receive_from_supplier" id="receive_from_supplier" disabled value="'.$row['wh_name'].'">';                                                                
//                                                            }
//                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3" id="show_receive_from_warehouse" style="display:none;" >
                                                    <label class="example-text-input" for="receive_from_warehouse" required >Received From (Warehouse)<span style="color: red">*</span> <?=(empty($temp_records) ) ? '<a class="btn btn-sm btn-primary" href="../warehouse_management/add_warehouse">+</a>':''?></label>
                                                    <div class="controls">
                                                        <?php
                                                        
//                                                        if (empty($temp_records)) {
                                                            
                                                        ?>
                                                        <select class="select2me input-medium" name="receive_from_warehouse" id="receive_from_warehouse"  style="width:100%;padding:10%;" <?php if (isset($master_id)) echo 'disabled="true"' ?> >
                                                            <option value="">Select</option>
                                                            <?php
                                                                                                                    
                                                            foreach ($warehouses as $row) {
                                                                ?>
                                                            <option value="<?php echo $row['wh_id'] ?>" <?php if (isset($wh_id_from) && $wh_id_from == $row['wh_id']) {echo "selected='selected'";} else if (isset($warehouse_from) && $warehouse_from == $row['wh_id']) echo "selected='selected'"; ?>><?php echo $row['warehouse_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                        <?php
//                                                        }else
//                                                        {
//                                                            foreach ($warehouses as $row) {
////                                                                if(isset($warehouse_from) && $warehouse_from == $row['stkid']) echo  '<input class="form-control" disabled value="'.$row['stkname'].'">';
//                                                                if(isset($warehouse_from_warehouse) && $warehouse_from_warehouse == $row['wh_id']) echo  '<input class="form-control" name="receive_from_warehouse" id="receive_from_warehouse"  disabled value="'.$row['wh_name'].'">';                                                                
//                                                            }
//                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                                
                                                
                                                <div class="col-md-9" id="supplier_info" style="display:none;background-color: #e3f4eb;">
                                                    <div class="control-group">
                                                        <h3 style="color:#2A3988;">Supplier Details</h3>
                                                        <div class="form-group row">
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-2 col-form-label">Contact Person : </label>
                                                            <div class="col-sm-4">
                                                              <input type="text" readonly class="form-control-plaintext" id="contact_person" value="">
                                                            </div>
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-2 col-form-label">Contact Numbers: </label>
                                                            <div class="col-sm-4">
                                                              <input type="text" readonly class="form-control-plaintext" id="contact_number" value="">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-2 col-form-label">Contact Email : </label>
                                                            <div class="col-sm-4">
                                                              <input type="text" readonly class="form-control-plaintext" id="contact_email" value="">
                                                            </div>
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-2 col-form-label">Address : </label>
                                                            <div class="col-sm-4">
                                                                <textarea type="text" readonly class="form-control-plaintext" id="address" value=""></textarea>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            
                                            <div class="form-group row"> 
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="driver_name" required >Driver Name </label>
                                                        <div class="controls">
<!--                                                            <input type="text" name="driver_name" id="driver_name" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
//                                                                if (isset($form['driver_name']) && !empty($form['driver_name']))
//                                                                {
//                                                                    echo 'value="' . $form['driver_name'] . '"';
//                                                                }else if (isset($driver_name) && !empty($driver_name))
//                                                                {
//                                                                    echo 'value="' . $driver_name . '"';
//                                                                }
                                                                ?>
                                                                   >-->
                                                            
                                                                   <textarea  name="driver_name" id="driver_name" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                      <?php
                                                                        if (isset($form['driver_name']) && !empty($form['driver_name']))
                                                                        {
                                                                            echo 'value="' . $form['driver_name'] . '"';
                                                                        }else if (isset($driver_name) && !empty($driver_name))
                                                                        {
                                                                            echo 'value="' . $driver_name . '"';
                                                                        }
                                                                    ?>
                                                                      ><?php
                                                                        if (isset($form['driver_name']) && !empty($form['driver_name']))
                                                                        {
                                                                            echo $form['driver_name'];
                                                                        }else if (isset($driver_name) && !empty($driver_name))
                                                                        {
                                                                            echo $driver_name;
                                                                        }
                                                                    ?></textarea>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="driver_contract" required >Driver contact # <span style="color: red">*</span></label>
                                                        <div class="controls">
<!--                                                            <input type="text" name="driver_contract" id="driver_contract_s" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
//                                                                if (isset($form['driver_contract']) && !empty($form['driver_contract']))
//                                                                {
//                                                                    echo 'value="' . $form['driver_contract'] . '"';
//                                                                }else if (isset($driver_contract) && !empty($driver_contract))
//                                                                {
//                                                                    echo 'value="' . $driver_contract . '"';
//                                                                }
                                                                ?>
                                                                   >-->
                                                            
                                                            <textarea  name="driver_contract" id="driver_contract_s" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                      <?php
                                                                        if (isset($form['driver_contract']) && !empty($form['driver_contract']))
                                                                        {
                                                                            echo 'value="' . $form['driver_contract'] . '"';
                                                                        }else if (isset($driver_contract) && !empty($driver_contract))
                                                                        {
                                                                            echo 'value="' . $driver_contract . '"';
                                                                        }
                                                                    ?>
                                                                      ><?php
                                                                        if (isset($form['driver_contract']) && !empty($form['driver_contract']))
                                                                        {
                                                                            echo $form['driver_contract'];
                                                                        }else if (isset($driver_contract) && !empty($driver_contract))
                                                                        {
                                                                            echo $driver_contract;
                                                                        }
                                                                    ?></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="vehicle_reg" required >Vehicle Reg# </label>
                                                        <div class="controls">
<!--                                                            <input type="text" name="vehicle_reg" id="vehicle_reg" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
//                                                                if (isset($form['vehicle_reg']) && !empty($form['vehicle_reg']))
//                                                                {
//                                                                    echo 'value="' . $form['vehicle_reg'] . '"';
//                                                                }else if (isset($vehicle_reg) && !empty($vehicle_reg))
//                                                                {
//                                                                    echo 'value="' . $vehicle_reg . '"';
//                                                                }
                                                                ?>
                                                                   >-->
                                                            <textarea  name="vehicle_reg" id="vehicle_reg" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                      <?php
                                                                        if (isset($form['vehicle_reg']) && !empty($form['vehicle_reg']))
                                                                        {
                                                                            echo 'value="' . $form['vehicle_reg'] . '"';
                                                                        }else if (isset($vehicle_reg) && !empty($vehicle_reg))
                                                                        {
                                                                            echo 'value="' . $vehicle_reg . '"';
                                                                        }
                                                                    ?>
                                                                      ><?php
                                                                        if (isset($form['vehicle_reg']) && !empty($form['vehicle_reg']))
                                                                        {
                                                                            echo $form['vehicle_reg'];
                                                                        }else if (isset($vehicle_reg) && !empty($vehicle_reg))
                                                                        {
                                                                            echo $vehicle_reg;
                                                                        }
                                                                    ?></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                                
                                            <div class="form-group row"> 
                                                
<!--                                                <div id="productinfo">
                                                    
                                                </div>-->
                                                
                                                <div class="col-md-3" >
                                                    <label class="example-text-input" required >Product<span style="color: red">*</span> <?=(empty($temp_records) ) ? '<a class="btn btn-sm btn-primary" target="_blank" href="../product_management/add">+</a>':''?></label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="product" id="product" required style="width:100%;padding:10%;">
                                                            <!--<option value="">Select</option>-->
                                                                <?php
//                                                                foreach ($product as $row) {
                                                                    ?>
                                                                <!--<option value="<?php echo $row['itm_id'] ?>" <?php if (isset($product_id) && $product_id == $row['itm_id']) echo "selected='selected'"; ?>><?php echo $row['itm_name'] ?></option>-->
                                                                    <?php
//                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="manufacturer" required >Manufacturer  
                                                        <a href="../productmanufacturer_management/add" target="_blank" class="btn btn-sm btn-primary">+</a>
                                                    </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="manufacturer_id" id="manufacturer_id"  style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($manufacturer as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['stkid'] ?>" <?php if (isset($manufacturer_id) && $manufacturer_id == $row['stkid']) echo "selected='selected'"; ?>><?php echo $row['stkname'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                    </div>
                                                </div>

<!--                                                <div class="col-md-3" id="sh_manufacturer" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="vehicle_reg" required >Manufacturer </label>
                                                        <div class="controls">
                                                            <input type="text" name="manufacturer_name" id="manufacturer_name" class="form-control" readonly="true" value="">
                                                            <input type="hidden" name="manufacturer_id" id="manufacturer_id" class="form-control" value="" >
                                                        </div>
                                                    </div>
                                                </div>-->

                                                <div class="col-md-3" id="sh_dosage_form" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="dosage_form_sh" required >Dosage Form </label>
                                                        <div class="controls">
                                                            <input type="text" name="dosage_form_sh" id="dosage_form_sh" class="form-control" readonly="true" value="">
                                                            <!--<input type="hidden" name="dosage_from_sh" id="dosage_from_sh" class="form-control" value="" >-->
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="shipment_temprature" required >Shipment Temperature </label>
                                                        <div class="controls">
                                                            <input type="text" name="shipment_temprature" id="shipment_temprature" class="form-control" value="">
                                                            <!--<input type="hidden" name="dosage_from_sh" id="dosage_from_sh" class="form-control" value="" >-->
                                                        </div>
                                                    </div>
                                                </div>    

<!--                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="manufacturer" required >Manufacturer <span style="color: red">*</span>  <a href="../productmanufacturer_management/add"  target="_blank" class="btn btn-sm btn-primary">+</a></label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="manufacturer_id" id="manufacturer_id" required style="width:100%;padding:10%;" onchange="document.getElementById('manufacturer_name').value=this.options[this.selectedIndex].text">
                                                            <option value="">Select</option>
                                                            <?php
//                                                            foreach ($manufacturer as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['stkid'] ?>" <?php if (isset($manufacturer_id) && $manufacturer_id == $row['stkid']) echo "selected='selected'"; ?>><?php echo $row['stkname'] ?></option>
                                                                <?php
//                                                            }
                                                            ?>

                                                        </select>  
                                                        <input type='hidden' id='manufacturer_name' name="manufacturer_name" value=''>
                                                    </div>
                                                </div>-->
<!--                                                <div class="col-md-3" id="show_batch" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="registration_number" required >Batch Number<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="batch_number" id="batch_number" class="form-control" 
                                                                   <?php
                                                                        if (isset($batch_no) && !empty($batch_no))
                                                                        {
                                                                            echo 'value="' . $batch_no . '"';
                                                                        }
                                                                   ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3" id="show_manufacturer_Date" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Manufacturing Date(MM/DD/YYYY) <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" name="manufacturing_date" id="manufacturing_date" class="form-control"   
                                                                   <?php
                                                                        if (isset($production_date) && !empty($production_date))
                                                                        {
                                                                            echo 'value="' . $production_date . '"';
                                                                        }else{
                                                                            echo 'value="' . date("m/d/Y") . '"';
                                                                        }
                                                                   ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3" id="show_expiry_date" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Expiry Date(MM/DD/YYYY) <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" name="expiry_date" id="expiry_date" class="form-control"    
                                                                   <?php
                                                                        if (isset($batch_expiry) && !empty($batch_expiry))
                                                                        {
                                                                            echo 'value="' . $batch_expiry . '"';
                                                                        }else{
                                                                            echo 'value="' . date("m/d/Y") . '"';
                                                                        }
                                                                   ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>-->
                                                
                                            </div> 
                                            
                                            <div class="form-group row" id='product_fields'>
                                                
                                            </div>
                                            
<!--                                            <div class="form-group row m-b-0" id="msg_shelf">
                                                <div class="alert alert-danger alert-dismissiblex fade show" role="alert">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button> <span id="msg_shelf_text">Attention: The Batch must have shelf life of at least 85% , as per instructions from DRAP.</span>
                                                </div>
                                            </div>-->
                                            <div class="form-group row">
                                                
                                                <div class="col-md-3" id="show_po_quantity" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="po_quantity" required >PO Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="po_quantity" id="po_quantity" class="form-control"   required 
                                                                   <?php
                                                                        if (isset($po_quantity) && !empty($po_quantity))
                                                                        {
                                                                            echo 'value="' . $po_quantity . '"';
                                                                        }
                                                                    ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="dc_quantity" required >DC Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="dc_quantity" id="dc_quantity" class="form-control" min="0"  required 
                                                                   <?php
                                                                        if (isset($dc_quantity) && !empty($dc_quantity))
                                                                        {
                                                                            echo 'value="' . $dc_quantity . '"';
                                                                        }
                                                                    ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="actual_rec_qty" required >Good Unit Received <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="actual_rec_qty" id="actual_rec_qty" class="form-control" min="0"  required 
                                                                   <?php
                                                                        if (isset($actual_rec_qty) && !empty($actual_rec_qty))
                                                                        {
                                                                            echo 'value="' . $actual_rec_qty . '"';
                                                                        }
                                                                    ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="dc_remove_rec" required >DC – Recv </label>
                                                        <div class="controls">
                                                            <input type="number" readonly="" name="dc_remove_rec" id="dc_remove_rec" class="form-control" min="0" value="" 
                                                                   <?php
//                                                                        if (isset($actual_rec_qty) && !empty($actual_rec_qty))
//                                                                        {
//                                                                            echo 'value="' . $actual_rec_qty . '"';
//                                                                        }
                                                                    ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="pi_type" required >PI Type <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="pi_type" id="pi_type"  style="width:100%;padding:10%;" >
                                                                    <option value="">Select</option>
                                                                <?php

                                                                foreach ($pi_arr as $pitype) {
                                                                        ?>
                                                                        <option value="<?php echo $pitype['pk_id'] ?>" <?php if (isset($currency) && $currency == $pitype['pk_id']){ echo "selected='selected'"; } else if (isset($row['currency']) && $row['currency'] == $pitype['pk_id']){ echo "selected='selected'"; } ?>><?php echo $pitype['name'] ?></option>
                                                                        <?php
                                                                    }
                                                                    ?>

                                                            </select>  
                                                        </div>
                                                    </div>
                                                </div>
                                                
<!--                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="pi_quantity" required >GIWS PI Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="pi_quantity" id="pi_quantity" class="form-control" min="0"  required
                                                                   <?php
                                                                        if (isset($pi_quantity) && !empty($pi_quantity))
                                                                        {
                                                                            echo 'value="' . $pi_quantity . '"';
                                                                        }
                                                                    ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>-->
<!--                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="quantity" id="quantity" class="form-control"   required >
                                                        </div>
                                                    </div>
                                                </div>-->
                                            </div>
                                            
                                            <div class="form-group row">
                                                
                                                <div class="col-md-3" >
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="unit_price" required >Unit Price <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number"  step="0.01" min="0" name="unit_price" id="unit_price" class="form-control"   required 
                                                                   <?php
                                                                        if (isset($unit_price) && !empty($unit_price))
                                                                        {
                                                                            echo 'value="' . $unit_price . '"';
                                                                        }
                                                                    ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="currency" required >Currency <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="currency" id="currency"  style="width:100%;padding:10%;" >
                                                                    <!--<option value="">Select</option>-->
                                                                <?php

                                                                foreach ($currency_type as $currencytype) {
                                                                        ?>
                                                                        <option value="<?php echo $currencytype['pk_id'] ?>" <?php if (isset($currency) && $currency == $currencytype['pk_id']){ echo "selected='selected'"; } else if (isset($row['currency']) && $row['currency'] == $currencytype['pk_id']){ echo "selected='selected'"; } ?>><?php echo $currencytype['name'] ?></option>
                                                                        <?php
                                                                    }
                                                                    ?>

                                                            </select>  
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="conversion_rate" required >Conversion Rate <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="conversion_rate" id="conversion_rate" class="form-control"   required 
                                                                   <?php
                                                                        if (isset($conversion_rate) && !empty($conversion_rate))
                                                                        {
                                                                            echo 'value="' . $conversion_rate . '"';
                                                                        }
                                                                    ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="amount_in_pkr" required >Amount In PKR </label>
                                                        <div class="controls">
                                                            <input type="number" name="amount_in_pkr" id="amount_in_pkr" class="form-control"   readonly=""
                                                                   <?php
                                                                        if (isset($amount_in_pkr) && !empty($amount_in_pkr))
                                                                        {
                                                                            echo 'value="' . $amount_in_pkr . '"';
                                                                        }
                                                                    ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
<!--                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="pi_quantity" required >GWIS PI Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="pi_quantity" id="pi_quantity" class="form-control"   required >
                                                        </div>
                                                    </div>
                                                </div>-->
<!--                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="quantity" id="quantity" class="form-control"   required >
                                                        </div>
                                                    </div>
                                                </div>-->
                                            </div>

                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="fileToUploads"  >Select File to upload:</label>
                                                        <div class="controls">
                                                            <input type="file" name="fileToUpload">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Remarks</label>
                                                        <div class="controls">
                                                            <textarea name="remarks" id="remarks" class="form-control" 
                                                                      <?php
                                                                        if (isset($pi_comment) && !empty($pi_comment))
                                                                        {
                                                                            echo 'value="' . $pi_comment . '"';
                                                                        }
                                                                    ?>
                                                                      ></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-success waves-effect waves-light" > Add Receiving</button>
                                                    
                                                    <?php if((isset($_REQUEST['pkmasteridedit']) && !empty($_REQUEST['pkmasteridedit'])) || (isset($pkmasteridedit) && !empty($pkmasteridedit))) { ?>
                                                    
                                                    <input type="hidden" name="vouchertno" id="vouchertno" value="<?php if(isset($_REQUEST['vouchertno']) && !empty($_REQUEST['vouchertno'])) { echo $_REQUEST['vouchertno'];}else { echo $vouchertno;} ?>">
                                                    <input type="hidden" name="pkmasteridedit" id="pkmasteridedit" value="<?php if(isset($_REQUEST['pkmasteridedit']) && !empty($_REQUEST['pkmasteridedit'])) { echo $_REQUEST['pkmasteridedit'];}else { echo $pkmasteridedit;} ?>">
                                                    <input type="hidden" name="edit" id="edit" value="<?php if(isset($_REQUEST['edit']) && !empty($_REQUEST['edit'])) { echo $_REQUEST['edit'];}else { echo $edit;} ?>">
                                                    
                                                    <?php } ?>
                                                    
                                                    <input type="hidden" name="pkmasterid" id="pkmasterid" value="<?php if(isset($fkstockid) && !empty($fkstockid)) { echo $fkstockid;}else { echo '';} ?>"> 
                                                    <input type="hidden" name="pkdetailid" id="pkdetailid" value="<?php if(isset($pkdetailid) && !empty($pkdetailid)) { echo $pkdetailid;}else { echo '';} ?>">
                                                    <input type="hidden" name="batchid" id="batchid" value="<?php if(isset($batchid) && !empty($batchid)) { echo $batchid;}else { echo '';} ?>"> 
                                                </div>  
<?php if (isset($temp_records) && (!empty($temp_records))) {
    ?>
                                                    <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>"> 
                                                <?php }
                                                ?>    
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <br>
                            <!--<div id="dc_result">-->
                            <div style="overflow-x:auto;width:100%;">
<?php
if ((isset($temp_records) && (!empty($temp_records))) || (isset($_REQUEST['edit']) && !empty($_REQUEST['edit'])) || (isset($edit) && !empty($edit))) {
    ?>
                            
                                <div id="dc_result">
                                    <table class="table table-striped table-bordered table-condensed dt-responsive " >
                                        <thead>
                                            <tr>
                                                <th style="width: 1%;" class="center">No.</th>
                                                <th>Item Name</th>
                                                <?php 
//                                                $sr = 0;
//                                                foreach ($temp_records->result_array() as $row1) {
//                                                if($row1['product_type'] == '36' && $sr == 0) {?>
                                                <th>Batch#</th>
                                                <th>Mfg Date</th>
                                                <th>Exp. Date</th>
                                                <th>Serial No</th>
                                                <th>Warranty (years)</th>
                                                <th>Pack Size</th>
                                                <!--<th>Unit</th>-->
                                                <th>Temp From</th>
                                                <th>Temp to</th>
                                                <th>Shelf Life </th>
                                                <?php // $sr++;} else if($row1['product_type'] == '37' && $sr == 0) {?>
<!--                                                <th>Serial No</th>
                                                <th>warranty</th>-->
                                                <?php // $sr++;} 
                                                
//                                                } ?>
                                                <th>DC Qty</th> 
                                                <th>Physical Inspection <br> Qty</th> 
                                                <th>Comments</th>
                                                <th>Action</th>  
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- Table row -->
                            <?php
                            $count = 1;
                            foreach ($temp_records->result_array() as $row) {
								//print_r($row);
								//exit;
        
                                   
                                                // $daysss = $difference->format("%a");
                                                
                                                // $months = floor($daysss / 30);
                                                // $dayss = $daysss - ($months*30);
                                                // $days = $months ." Months " . $dayss ." Days";
                                                
//                                                echo '>>>>>s:'.$row['field3'];
//                                                echo 'e:'.$date_of_receiving;
//                                                echo 'd:'.$days;
//                                                exit;
                            ?>
                                            
                                                <tr>
                                                    <td class="center"><?php echo $count; ?></td>
                                                    <!--<td class="important"><?php if(isset($row['wh_from']) && !empty($row['wh_from'])) { echo $row['wh_from']; } else {echo $row['wh_from_supplier'];}?></td>-->
                                                    <td><?php echo $row['product_name']; ?></td> 
                                                    
                                                    <?php 
//                                                    if($row['product_type'] == '36') {?>
                                                    
                                                    <td><?php echo $row['field1']; ?></td> 
                                                    <td><?php echo $row['field2']; ?></td> 
                                                    <td class="important"><?php echo $row['field3']; ?></td>
                                                    <td><?php echo $row['field4']; ?></td> 
                                                    <td><?php echo $row['field5']; ?></td> 
                                                    <td><?php echo $row['field6']; ?></td> 
                                                    <!--<td><?php echo $row['field7']; ?></td>--> 
                                                    <td><?php echo $row['field8']; ?></td> 
                                                    <td><?php echo $row['field9']; ?></td> 
                                                    <td class="important"><?php echo shelf_life($row['batch_expiry'],$row['tran_date']); ?></td>
                                                    
                                                    <?php // } else if($row['product_type'] == '37') {?>
                                                    
<!--                                                    <td><?php echo $row['field4']; ?></td> 
                                                    <td><?php echo $row['field5']; ?></td> -->
                                                    
                                                    <?php // }
                                                     ?>
                                                    <td class="important"><?php echo $row['dc_quantity']; ?></td> 
                                                    <td class="important"><?php echo $row['pi_quantity']; ?></td> 
                                                    <td class="important"><?php echo $row['pi_comment']; ?></td>
                                                    <td>  
                                                      <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row['pk_id']."_".$row['fk_stock_id']; ?>-deletedc">
                                                          <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Delete
                                                      </button>  
                                                    <!--<a onclick="return confirm('Are you sure you want to Delete?');" href="<?php echo base_url("inventory_management/delete?id=") . $row['pk_id']; ?>&status=1" class="btn btn-sm btn-light glyphicons bin" > Delete</a>-->
                                                    </td> 
                                                </tr>
        <?php
        $count++;
    }
    ?>
                                            <!-- // Table row END -->
                                            <!-- Table row -->

                                            <!-- // Table row END -->
                                        </tbody>
                                    </table> 
                                </div>
                            
                                <button type="button" id="dc_save_temp_receive" name="save_temp_receive" class="btn btn-success waves-effect waves-light" style="margin-left:90%;">Save</button>

                                <!-- // Table END -->
    <?php
}
?>
                            </div>
                            <!--</div>-->
                        </form>
                        
                        
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>

<div id="ajaxloadjs">
    <?php // include "stock_receive_js.php"; ?>
</div>
