<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
    }
  
</style>
<?php
//print_r($stock_master_records);exit;
    if (isset($stock_master_records)) {
        
        $row = $stock_master_records[0];
        $demand_req_date = date('d/m/Y', strtotime($row['demand_req_date']));
        $location_from = $row['location_from'];
        $location_to = $row['location_to'];
        $demand_requisition = $row['demand_requisition'];
        
    } 
else if(isset($tran_reference_number)){
    $refernce_number=$tran_reference_number;
//    $temp_row = $temp_records->result_array();
    $temp_row = $temp_records[0];
//    print_r($temp_records->result_array());exit;
//    $row_temp = $temp_row[0];
//    $issue_to = $row_temp['issuance_to'];
//    $center_name = $row_temp['warehouse_name'];
//    $patient_name = $row_temp['full_name'] . "-" . $row_temp['nic_no'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="row">
                        <div class="col-md-12">
                            
                            
                            
                            <?php 
//                        if(isset($issueVoucher) && !empty($issueVoucher)) {
//                            echo 'Pending Vouchers are : ';
//                            echo implode(',', $issueVoucher);
//                            echo '<hr>';
//                        }
                        
//                        if(isset($getStockIssues) && !empty($getStockIssues)) {
                            
                            $issueVoucher = '';
                            $a='';
                                if ($getStockIssues) {

                                    //fetch results
                                    foreach ($getStockIssues AS $row)
                                    {
                                        $a= " <a style='color:red;' href=\"transport_req_approve_form?issue_no=" . $row['tran_no'] . "&trmasterid=". $row['pk_id'] ."&search=true\">" . $row['tran_no'] . "</a>";
                                        $issueVoucher[ $row['tran_no']] = $a;
                                    }

     //                           }

                                     echo '<table style="font-family: arial;border:2px solid #1F8564; sans-serif;border-collapse: collapse;width:100%"><tr><th style="border: 2px solid #1F8564;text-align: left;padding: 8px;width:20%;font-size:16px;">Pending Vouchers are : </th><td  style="border: 1px solid #dddddd;text-align: left;padding: 8px;text-decoration: underline;">';
                                     echo implode(',', $issueVoucher);
                                     echo '</td></table><hr>';
                                 }
                            
                            
//                            if (in_array("69", $approver_desg_id)){
                                if ($getRejectedVoucher) {

                                    //fetch results
                                    foreach ($getRejectedVoucher AS $row)
                                    {
                                        $a= " <a style='color:red;' href=\"transport_req_approve_form?rej_issue_no=" . $row['tran_no'] . "&trmasterid=". $row['pk_id'] ."&search=true\">" . $row['tran_no'] . "</a>";
                                        $issueRegVoucher[$row['tran_no']] = $a;
                                    }

     //                           }

                                     echo '<table style="font-family: arial;border:2px solid #1F8564; sans-serif;border-collapse: collapse;width:100%"><tr><th style="border: 2px solid #1F8564;text-align: left;padding: 8px;width:20%;font-size:16px;">Rejected Vouchers are : </th><td  style="border: 1px solid #dddddd;text-align: left;padding: 8px;text-decoration: underline;">';
                                     echo implode(',', $issueRegVoucher);
                                     echo '</td></table><hr>';
                                }
//                            }
//                            else{
////                                    echo "Match not found";
//                            }
                            
                            
                            
                         ?></div>
                    </div>
                    
                    
                    
                    <div class="heading-buttons">
                        <h3>Transport Request Form</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <?php
//                         print_r($stockReceive);exit;
                        if(isset($stockReceive) && !empty($stockReceive))
                        {
                            foreach ($stockReceive as $row) {
                               $pkmasterides = $row['masterpkid'];
                               $status = $row['status'];
                               $approver_status = $row['approver_status'];
                               $demand_req_date = date('d/m/Y', strtotime($row['demand_req_date']));
                               $location_from = $row['location_from'];
                               $location_to = $row['location_to'];
                               $demand_requisition = $row['demand_requisition'];
                           }
                    ?>
                    
                    <div class="innerLR">
                        <form method="post" id="transport_req" name="transport_req" enctype="multipart/form-data" action="<?php echo base_url("inventory_management/transport_req_approve_form"); ?>">
                            <input type="hidden" name="center_from" id="center_from" value="<?=($this->session->warehouse_id)?>"
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            
                                            <div class="form-group row"> 
                                                
                                                <div class="col-md-12" style="text-align:right;">
                                                    <?php if ($status == '1'){
                                                    ?>   
                                                    <a href="<?php echo base_url("inventory_management/transport_req_form_new?vouchertno=$issue_no&pkmasteridedit=$pkmasterides&edit=1"); ?> " class="btn btn-warning" title="edit">Edit Transport Request</a>
                                                    <button type="submit" id="save" name="update_approve" value="1" class="btn btn-success"> Approve And Update </button>
                                                    <?php } else { ?>
                                                    <button type="submit" id="save" class="btn btn-success"> Save </button>
                                                    <?php } ?>
                                                    <a href="<?php echo base_url("dashboard/index"); ?> " class="btn btn-danger" title="cancel">Cancel</a>
                                                    <!--<button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" > Add Receiving</button>-->
                                                </div>
                                                
                                                <br><br>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="tr_number" required >Transport Req# (Auto) </label>
                                                        <div class="controls">
                                                            <input type="text" name="tr_number" id="tr_number" class="form-control" readonly value="Auto Generated" <?php if (isset($master_id)) echo 'readonly="true"' ?> 
                                                                <?php
//                                                                if (isset($refernce_number)) {
//                                                                    echo 'value="' . $refernce_number . '"';
//                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="date_vehicle_req"  >Date Vehicle(s) Required<span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="date_vehicle_req" id="date_vehicle_req" required="" value="<?php if(isset($demand_req_date) && !empty($demand_req_date)) {echo $demand_req_date;} else{ echo date("d/m/Y");} ?>"  >

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="location_from"  >Location From <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="location_from" id="location_from" required="" value="<?php if(isset($location_from) && !empty($location_from)) {echo $location_from;} else{ echo '';} ?>"  >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="location_to"  >Location To <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="location_to" id="location_to" required="" value="<?php if(isset($location_to) && !empty($location_to)) {echo $location_to;} else{ echo '';} ?>"  >
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group row"> 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="demand_requisition"  >Demand/Requisition# </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="demand_requisition" id="demand_requisition" required="" value="<?php if(isset($demand_requisition) && !empty($demand_requisition)) {echo $demand_requisition;} else{ echo '';} ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="fileToUploads"  >Select File to upload:</label>
                                                        <div class="controls">
                                                            <input type="file" name="fileToUpload">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <!--save vehicle info-->
                                            
                                            <br>
                                            <p style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:18px;margin-left: 5px;"> &nbsp;&nbsp;&nbsp;Vehicle Info</p>
                                            
                                            
                                            
                                            <div style="overflow-x:auto;width:100%;">
                                            <?php
                                            if (isset($stockReceive) && (!empty($stockReceive))) {
                                                ?>

                                                <div id="divToPrint">
                                                    <table class="table table-striped table-bordered table-condensed dt-responsive " >
                                                        <thead>
                                                            <tr>
                                                                <th style="width: 1%;" class="center">No.</th>
                                                                <th>Vehicle</th>
                                                                <th>Date Vehicle(s) Required </th>
                                                                <th>No. Of Vehicle</th>
                                                                <th>Rent / Vehicle </th>
                                                                <th>Amount</th>
                                                                <!--<th>Action</th>-->  
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <!-- Table row -->
                                                            <?php
                                                            $count = 1;
                                                            foreach ($stockReceive as $row) {
                                                                ?>
                                                                <tr>
                                                                    <td class="center"><?php echo $count; ?></td>
                                                                    <td><?php echo $row['vehicle_type']; ?></td> 
                                                                    <td><?php echo $row['vehicle_req_date']; ?></td> 
                                                                    <td><?php echo $row['no_of_vehicle']; ?></td> 
                                                                    <td><?php echo $row['vehicle_rent']; ?></td> 
                                                                    <td><?php echo $row['amount']; ?></td>

<!--                                                                    <td>  
                                                                      <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row['pk_id']."_".$row['tr_master_id']; ?>-deletetvreq">
                                                                          <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Delete
                                                                      </button>  
                                                                    </td>-->
                                                                    
                                                                </tr>
                                                                <?php
                                                                $count++;
                                                            }
                                                            ?>
                                                            <!-- // Table row END -->
                                                            <!-- Table row -->

                                                            <!-- // Table row END -->
                                                        </tbody>
                                                    </table> 
                                                </div>
                                                

                                                <!-- // Table END -->
                                                <?php
                                            }
                                            ?>
                                            </div>
                                            
                                            
                                            
                                            
                                            
                                            <!--save product info-->
                                            
                                            
                                            
                                            <br>
                                            <p style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:18px;margin-left: 5px;"> &nbsp;&nbsp;&nbsp;Product Info</p>
                                            
                                           
                                            <div style="overflow-x:auto;width:100%;">
                                            <?php
                                            if (isset($stockReceiveprod) && (!empty($stockReceiveprod))) {
                                                ?>

                                                <div id="divToPrint">
                                                    <table class="table table-striped table-bordered table-condensed dt-responsive " >
                                                        <thead>
                                                            <tr>
                                                                <th style="width: 1%;" class="center">No.</th>
                                                                <th>Product</th>
                                                                <th>Quantity</th>
                                                                <th>Cartons</th>
                                                                <th>Manufacturer</th>
                                                                <!--<th>Action</th>-->  
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <!-- Table row -->
                                                            <?php
                                                            $count = 1;
                                                            foreach ($stockReceiveprod as $row) {
                                                                ?>
                                                                <tr>
                                                                    <td class="center"><?php echo $count; ?></td>
                                                                    <td><?php echo $row['product']; ?></td> 
                                                                    <td><?php echo $row['quantity']; ?></td> 
                                                                    <td><?php echo $row['cartons']; ?></td> 
                                                                    <td><?php echo $row['manufacturer']; ?></td>

<!--                                                                    <td>  
                                                                      <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row['pk_id']."_".$row['tr_master_id']; ?>-deletetpreq">
                                                                          <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Delete
                                                                      </button>  
                                                                    </td>-->
                                                                </tr>
                                                                <?php
                                                                $count++;
                                                            }
                                                            ?>
                                                            <!-- // Table row END -->
                                                            <!-- Table row -->

                                                            <!-- // Table row END -->
                                                        </tbody>
                                                    </table> 
                                                </div>
                                                

                                                <!-- // Table END -->
                                                <?php
                                            }
                                            ?>
                                            </div>
                                            
                                            
                                            <br>
                                            <div class="col-md-12" style="text-align:center;">
                                                <?php if ($status == '1'){
                                                ?>  
                                                <a href="<?php echo base_url("inventory_management/transport_req_approve_form?vouchertno=$issue_no&pkmasteridedit=$pkmasterides&edit=1"); ?> " class="btn btn-warning" title="edit">Edit Transport Request</a>
                                                <button type="submit" id="save" name="update_approve" value="1" class="btn btn-success"> Approve And Update </button>
                                                <?php } else { ?>
                                                <!--<button type="submit" id="save" class="btn btn-success"> Save </button>-->
                                                <?php } ?>
                                                <a href="<?php echo base_url("dashboard/index"); ?> " class="btn btn-danger" title="cancel">Cancel</a>
                                                <!--<button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" > Add Receiving</button>-->
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            
                            
                            
                            </div>
                    
                    <?php 
                        }
                    ?>
                                   <?php if(isset($_REQUEST['trmasterid']) && !empty($_REQUEST['trmasterid'])) {?>
                                        <input type="hidden" name="trmasterid" id="trmasterid" value="<?php echo $_REQUEST['trmasterid'] ?>">
                                   <?php } ?>
                                   
                                    <?php if ((isset($temp_records_vehicle) && (!empty($temp_records_vehicle))) || (isset($temp_records_prod) && !empty($temp_records_prod))) { ?>
                                        <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>">
                                    <?php } ?> 
                                   
                        </form>    
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>