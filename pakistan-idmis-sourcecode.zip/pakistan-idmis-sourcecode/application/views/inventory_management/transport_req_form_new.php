<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
    }
  
</style>
<?php
//print_r($stock_master_records);exit;
    if (isset($stock_master_records)) {
        
        $row = $stock_master_records[0];
        $demand_req_date = $row['demand_req_date'];
        $location_from = $row['location_from'];
        $location_to = $row['location_to'];
        $demand_requisition = $row['demand_requisition'];
        
    } 
else if(isset($tran_reference_number)){
    $refernce_number=$tran_reference_number;
//    $temp_row = $temp_records->result_array();
    $temp_row = $temp_records[0];
//    print_r($temp_records->result_array());exit;
//    $row_temp = $temp_row[0];
//    $issue_to = $row_temp['issuance_to'];
//    $center_name = $row_temp['warehouse_name'];
//    $patient_name = $row_temp['full_name'] . "-" . $row_temp['nic_no'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Transport Request Form</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        
                        <form method="post" id="transport_req" name="transport_req" enctype="multipart/form-data" action="<?php echo base_url("inventory_management/transport_req_form_new"); ?>">
                            <input type="hidden" name="center_from" id="center_from" value="<?=($this->session->warehouse_id)?>"
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            
                                            <div class="form-group row"> 
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="tr_number" required >Transport Req# (Auto) </label>
                                                        <div class="controls">
                                                            <input type="text" name="tr_number" id="tr_number" class="form-control" readonly value="Auto Generated" <?php if (isset($master_id)) echo 'readonly="true"' ?> 
                                                                <?php
//                                                                if (isset($refernce_number)) {
//                                                                    echo 'value="' . $refernce_number . '"';
//                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="demand_req_date"  >Demand / Requisition date <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="demand_req_date" id="demand_req_date" required="" value="<?php if(isset($demand_req_date) && !empty($demand_req_date)) {echo $demand_req_date;} else{ echo date("d/m/Y");} ?>"  <?php if (isset($master_id)) echo 'disabled="true"' ?>>

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="location_from"  >Location From <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="location_from" id="location_from" required="" value="<?php if(isset($location_from) && !empty($location_from)) {echo $location_from;} else{ echo 'Islamabad';} ?>"  <?php if (isset($master_id)) echo 'disabled="true"' ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="location_to"  >Location To <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="location_to" id="location_to" required="" value="<?php if(isset($location_to) && !empty($location_to)) {echo $location_to;} else{ echo '';} ?>"  <?php if (isset($master_id)) echo 'disabled="true"' ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row"> 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="demand_requisition"  >Demand/Requisition# </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="demand_requisition" id="demand_requisition" required="" value="<?php if(isset($demand_requisition) && !empty($demand_requisition)) {echo $demand_requisition;} else{ echo '';} ?>"  <?php if (isset($master_id)) echo 'disabled="true"' ?>>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="fileToUploads"  >Select File to upload:</label>
                                                        <div class="controls">
                                                            <input type="file" name="fileToUpload">
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                
                                            </div>
                                            
                                            <!--save vehicle info-->
                                            
                                            <br>
                                            <p style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:18px;margin-left: 5px;"> &nbsp;&nbsp;&nbsp;Vehicle Info</p>
                                            
                                            <div class="form-group row">
                                                
                                                <div class="col-md-3">
                                                <label class="control-label" for="vehicle_type"> Vehicle </label>
                                                <div class="controls">
                                                    <select name="vehicle_type" id="vehicle_type"  class="select2me input-medium"  style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            if ($vehicle_type) {
                                                                //fetch result
                                                                foreach ($vehicle_type as $row) {
                                                                    //populate receive_from combo
    //                                                                if($_SESSION['user_stakeholder']=='145'){
    //                                                                    if($row->wh_id != '33677' && $row->wh_id != '33678' && $row->wh_id != '33680' && $row->wh_id != '20641'  && $row->wh_id != '9079') 
    //                                                                        continue;
    //                                                                }
                                                                    ?>
                                                            <option value="<?php echo $row['name']; ?>" > <?php echo $row['name']; ?> </option>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="no_of_vehicle"  >No. Of Vehicle  </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="no_of_vehicle" id="no_of_vehicle" value="" >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="vehicle_rent"  >Rent / Vehicle </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="vehicle_rent" id="vehicle_rent" value="" >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="vehicle_amount"  >Amount </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="vehicle_amount" id="vehicle_amount" value="" >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            
                                            <div class="form-group row">


                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="vehicle_req_date"  >Date Vehicle(s) Required </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="vehicle_req_date" id="vehicle_req_date" value="<?php echo date("d/m/Y"); ?>" >

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-7">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="vehicle_req" name="vehicle_req" value="vehicle_req" class="btn btn-success waves-effect waves-light" > Add </button>
                                                </div>
                                            </div>
                                            
                                            
                                            
                                            <div style="overflow-x:auto;width:100%;">
                                            <?php
                                            if ((isset($temp_records_vehicle) && (!empty($temp_records_vehicle))) || (isset($_REQUEST['edit']) && !empty($_REQUEST['edit'])) || (isset($edit) && !empty($edit))) {
                                                ?>

                                                <div id="divToPrint">
                                                    <table class="table table-striped table-bordered table-condensed dt-responsive " >
                                                        <thead>
                                                            <tr>
                                                                <th style="width: 1%;" class="center">No.</th>
                                                                <th>Vehicle</th>
                                                                <th>Date Vehicle(s) Required </th>
                                                                <th>No. Of Vehicle</th>
                                                                <th>Rent / Vehicle </th>
                                                                <th>Amount</th>
                                                                <th>Action</th>  
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <!-- Table row -->
                                                            <?php
                                                            $count = 1;
                                                            foreach ($temp_records_vehicle->result_array() as $row) {
                                                                ?>
                                                                <tr>
                                                                    <td class="center"><?php echo $count; ?></td>
                                                                    <td><?php echo $row['vehicle_type']; ?></td> 
                                                                    <td><?php echo $row['vehicle_req_date']; ?></td> 
                                                                    <td><?php echo $row['no_of_vehicle']; ?></td> 
                                                                    <td><?php echo $row['vehicle_rent']; ?></td> 
                                                                    <td><?php echo $row['amount']; ?></td>

                                                                    <td>  
                                                                      <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row['pk_id']."_".$row['tr_master_id']; ?>-deletetvreq">
                                                                          <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Delete
                                                                      </button>  
                                                                    </td>
                                                                    
                                                                </tr>
                                                                <?php
                                                                $count++;
                                                            }
                                                            ?>
                                                        </tbody>
                                                    </table> 
                                                </div>
                                                

                                                <!-- // Table END -->
                                                <?php
                                            }
                                            ?>
                                            </div>
                                            
                                            
                                            
                                            
                                            
                                            <!--save product info-->
                                            
                                            
                                            
                                            <br>
                                            <p style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:18px;margin-left: 5px;"> &nbsp;&nbsp;&nbsp;Product Info</p>
                                            
                                            <div class="form-group row"> 
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input"  >Product </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="product" id="transport_req_product"  style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($product as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['itm_id'] ?>" ><?php echo $row['itm_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="product_quantity"  >Quantity </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="product_quantity" id="product_quantity" value="" >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="no_of_cartons"  >Cartons </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="no_of_cartons" id="no_of_cartons" value="" >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="manufacturer" required >Manufacturer  
                                                        <!--<a href="../productmanufacturer_management/add" target="_blank" class="btn btn-sm btn-primary">+</a>-->
                                                    </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="manufacturer" id="manufacturer"  style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($manufacturer as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['stkid'] ?>" ><?php echo $row['stkname'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            
                                            
                                            
                                            
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="prod_req" name="prod_req" value="prod_req" class="btn btn-success waves-effect waves-light" > Add </button>
                                                </div>
                                            </div>
                                            
                                            <div style="overflow-x:auto;width:100%;">
                                            <?php
                                            if ((isset($temp_records_prod) && (!empty($temp_records_prod))) || (isset($_REQUEST['edit']) && !empty($_REQUEST['edit'])) || (isset($edit) && !empty($edit))) {
                                                ?>

                                                <div id="divToPrint">
                                                    <table class="table table-striped table-bordered table-condensed dt-responsive " >
                                                        <thead>
                                                            <tr>
                                                                <th style="width: 1%;" class="center">No.</th>
                                                                <th>Product</th>
                                                                <th>Quantity</th>
                                                                <th>Cartons</th>
                                                                <th>Manufacturer</th>
                                                                <th>Action</th>  
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <!-- Table row -->
                                                            <?php
                                                            $count = 1;
                                                            foreach ($temp_records_prod->result_array() as $row) {
                                                                ?>
                                                                <tr>
                                                                    <td class="center"><?php echo $count; ?></td>
                                                                    <td><?php echo $row['product']; ?></td> 
                                                                    <td><?php echo $row['quantity']; ?></td> 
                                                                    <td><?php echo $row['cartons']; ?></td> 
                                                                    <td><?php echo $row['manufacturer']; ?></td>

                                                                    <td>  
                                                                      <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row['pk_id']."_".$row['tr_master_id']; ?>-deletetpreq">
                                                                          <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Delete
                                                                      </button>  
                                                                    </td>
                                                                </tr>
                                                                <?php
                                                                $count++;
                                                            }
                                                            ?>
                                                        </tbody>
                                                    </table> 
                                                </div>
                                                

                                                <!-- // Table END -->
                                                <?php
                                            }
                                            ?>
                                            </div>
                                            
                                            <?php if((isset($_REQUEST['pkmasteridedit']) && !empty($_REQUEST['pkmasteridedit'])) || (isset($pkmasteridedit) && !empty($pkmasteridedit))) { ?>
                                                    
                                            <input type="hidden" name="vouchertno" id="vouchertno" value="<?php if(isset($_REQUEST['vouchertno']) && !empty($_REQUEST['vouchertno'])) { echo $_REQUEST['vouchertno'];}else { echo $vouchertno;} ?>">
                                            <input type="hidden" name="pkmasteridedit" id="pkmasteridedit" value="<?php if(isset($_REQUEST['pkmasteridedit']) && !empty($_REQUEST['pkmasteridedit'])) { echo $_REQUEST['pkmasteridedit'];}else { echo $pkmasteridedit;} ?>">
                                            <input type="hidden" name="edit" id="edit" value="<?php if(isset($_REQUEST['edit']) && !empty($_REQUEST['edit'])) { echo $_REQUEST['edit'];}else { echo $edit;} ?>">

                                            <?php } ?>
                                                    
                                            <br>
                                            <button type="button" id="save_temp_transport_req" name="save_temp_transport_req" class="btn btn-success waves-effect waves-light" style="margin-left:90%;">Save</button>
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            
                            
                            
                            </div>

                                   
                                    <?php if ((isset($temp_records_vehicle) && (!empty($temp_records_vehicle))) || (isset($temp_records_prod) && !empty($temp_records_prod))) { ?>
                                        <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>">
                                    <?php } ?> 
                                   
                        </form>    
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>