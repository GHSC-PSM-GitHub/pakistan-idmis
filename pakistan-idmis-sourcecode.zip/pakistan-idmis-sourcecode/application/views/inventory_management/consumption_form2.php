<?php // print_r($_SESSION);exit; ?>
<div class="wrapper">
    <div class="container-fluid">
        <div class="col-sm-12"> 
            <div class="card m-b-30">
                <div class="card-body">
                    <div class="heading-buttons">
                        <h3>Consumption Data Entry</h3>
                    </div>
                    <div class="row">
                        <div class="col-md-3 center red">Please enter Field/SDP Report (Pre requisite) and then District store report. </div>
                        <div class="col-md-9 right"><img src=<?php echo base_url()."assets/images/urdu.png"; ?> /></div
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-12"> 
            <div class="card m-b-30">
                <div class="card-body">
                    <div class="portlet box green ">
<!--                        <div class="portlet-title">
                            <div class="caption">District/Field Stores</div>
                        </div>
                        <div class="portlet-body">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th width="8%">Sr. No.</th>
                                        <th>Store Name</th>
                                        <th>Months</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $counter = 1;
                                    foreach ($data as $diststore) {
                                        echo "<tr>";
                                        echo "<td class=\"center\">" . $counter++ . "</td>";
                                        echo "<td class=\"center\">" . $diststore['wh_name'] . "</td>";
//                            echo "<td class=\"center\"><a onclick=\"window.open($url_1)\" class=\"btn btn-success btn-xs\"> Add".$data2[0]['MaxDate']."  <i class=\"fa fa-plus\"></i></a></td>";
                                        ?>
                                    <td><?php echo get_reporting_months($diststore['wh_id']); ?></td>
                                    <?php
                                    echo "</tr>";
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>-->
                        <div class="portlet-title">
                            <div class="caption">Health Facilities</div>
                            <div class="tools"> <a class="collapse" href="javascript:;"></a> </div>
                        </div>
                        <div class="portlet-body">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th width="8%">Sr. No.</th>
                                        <th>Health Facility</th>
                                        <th>Months</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $counter = 1;
                                    foreach ($data1 as $hfstore) {
                                        
                                        echo "<tr>";
                                        echo "<td class=\"center\">" . $counter++ . "</td>";
                                        echo "<td class=\"center\">" . $hfstore['wh_name'] . "</td>";
//                            echo "<td class=\"center\"><a onclick=\"window.open($url_1)\" class=\"btn btn-success btn-xs\"> Add".$data2[0]['MaxDate']."  <i class=\"fa fa-plus\"></i></a></td>";
//                                        $nmonths = getlast3months($hfstore['wh_id']);
//                                        if(isset($nmonths)){
//                                            $new_month = $nmonths['new_report_month'];
//                                        } else {
//                                            $new_month = '';
//                                        }
                                        
                                        
                                        ?>
<!--                                    <td><?php //echo get_reporting_months($hfstore['wh_id']).''.$new_month;//$temp['new_report_month']; ?></td>-->
                                <td>
                                    <?php for($i=8; $i<=12; $i++) { 
                                      //  $monthNum  = 3;
$dateObj   = DateTime::createFromFormat('!m', $i);
$monthName = $dateObj->format('F'); // March
$monthno = $dateObj->format('m');

    if(checkmonth($hfstore['wh_id'], '2022-'.$monthno.'-01')){
        $icon = "pen";
        $color = "danger";
    } else {
        $icon = "plus";
        $color = "success";
    }
                                        ?>
                                    <a href="add_cons_hf?wh_id=<?php echo $hfstore['wh_id']; ?>&date=<?php echo '2022-'.$monthno.'-01'; ?>" class="btn btn-<?php echo $color; ?> green"> <?php echo $monthName; ?>-22 <i class="fa fa-<?php echo $icon; ?>"></i></a>

                                    <?php } ?>                                </td>
                                    <?php
                                    echo "</tr>";
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>