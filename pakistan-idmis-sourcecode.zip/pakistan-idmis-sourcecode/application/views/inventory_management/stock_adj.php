<style>

    .datepicker.dropdown-menu {
        z-index: 9999 !important;
    }

</style>
<?php
//print_r($stock_master_records);exit;
if (isset($stock_master_records)) {


    $row = $stock_master_records[0];
    $refernce_number = $row['tran_ref'];
//    $temp_row = $temp_records->result_array();
//    $temp_row = $temp_records[0];
//    $row_temp = $temp_row[0];
//    $issue_to = $row_temp['issuance_to'];
//    $center_name = $row_temp['warehouse_name'];
//    $patient_name = $row_temp['full_name'] . "-" . $row_temp['nic_no'];
//    print_r($patient_name);exit;
} else if (isset($tran_reference_number)) {
    $refernce_number = $tran_reference_number;
//    $temp_row = $temp_records->result_array();
    $temp_row = $temp_records[0];
//    print_r($temp_records->result_array());exit;
//    $row_temp = $temp_row[0];
//    $issue_to = $row_temp['issuance_to'];
//    $center_name = $row_temp['warehouse_name'];
//    $patient_name = $row_temp['full_name'] . "-" . $row_temp['nic_no'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Stock Adjustment</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="stock_issue" name="stock_issue" action="<?php echo base_url("inventory_management/stock_adjustment"); ?>">
                            <input type="hidden" name="center_from" id="center_from" value="<?= ($this->session->warehouse_id) ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row"> 

                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Adjustment / Transaction Date <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="receiving_time" id="receiving_time" required value="<?php echo date("m/d/Y"); ?>" <?php if (isset($master_id)) echo 'readonly' ?>>

                                                        </div>
                                                    </div>
                                                </div> 

                                                <div class="col-md-3">
                                                    <label class="example-text-input"  >Reason for Adjustment<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                            <?php
                                                            if (!empty($temp_records)) {
                                                                if (isset($temp_records) && (!empty($temp_records->result_array()))) {
                                                                    $trans_type_id = $temp_records->result_array()[0]['trans_id'];
                                                                    $trans_type = $temp_records->result_array()[0]['trans_type'];
                                                                    $trans_nature = $temp_records->result_array()[0]['trans_nature'];
                                                                    if (empty($this_tran)) {
                                                                        $this_tran = '';
                                                                    }
                                                                    ?>
                                                         <select class="select2me input-medium " name="tran_type" id="tran_type" required style="width:100%;padding:10%;">
                                                            <option value="<?php echo $trans_type_id; ?>" readonly><?php echo $trans_type. ' (' . $trans_nature . ')'; ?> </option>
                                                            </select>
                                                                        <?php
                                                                }
                                                            }
                                                            else{
                                                            ?>
                                                             <select class="select2me input-medium " name="tran_type" id="tran_type" required style="width:100%;padding:10%;" >
                                                            <option value="">Select</option>
                                                            
                                                            <?php
                                                            foreach ($trans as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['trans_id'] ?>" <?php if (isset($tran) && $tran == $row['trans_id']) {
                                                                echo "selected='selected'";
                                                                $this_tran = $row['trans_type'];
                                                            } ?>><?php echo $row['trans_type'] . ' (' . $row['trans_nature'] . ')'; ?></option>
                                                                <?php
                                                            }}
                                                            ?>

                                                         </select>

                                                    </div>
                                                </div>

                                                <div class="col-md-3">
                                                    <label class="example-text-input">Category <span style="color: red">*</span></label>
                                                    <div class="controls">
                                                                     <?php
                                                            if (!empty($temp_records)) {
                                                                if (isset($temp_records) && (!empty($temp_records->result_array()))) {
                                                                    $stk_type_id = $temp_records->result_array()[0]['stkid'];
                                                                    $stk_name = $temp_records->result_array()[0]['stkname'];
                                                                    if (empty($this_stk)) {
                                                                        $this_stk = '';
                                                                    }
                                                                    ?>
                                                         <select class="select2me input-medium " name="stakeholder" id="stakeholder" required style="width:100%;padding:10%;">
                                                            <option value="<?php echo $stk_type_id; ?>" readonly><?php echo $stk_name; ?></option>
                                                            </select>
                                                                        <?php
                                                                }
                                                            }
                                                            else{
                                                            ?>
                                                             <select class="select2me input-medium " name="stakeholder" id="stakeholder" required style="width:100%;padding:10%;" >
                                                            <option value="">Select</option>
                                                            
                                                            <?php
                                                             foreach ($stakeholder as $row) {
                                                                ?>
                                                            <option value="<?php echo $row['stkid'] ?>" <?php if (isset($form['stakeholder']) && $form['stakeholder'] == $row['stkid']) echo "selected='selected'"; ?>><?php echo $row['stkname'] ?></option>
                                                                <?php
                                                            }}
                                                            ?>
                                                            </select>
                                                    </div>
                                                </div>

                                                <!--                                                <div class="col-md-3">
                                                                                                    <label class="example-text-input" required >Product / Item<span style="color: red">*</span> </label>
                                                                                                    <div class="controls">
                                                                                                        <select class="select2me input-medium" name="product" id="product" required style="width:100%;padding:10%;">
                                                                                                            <option value="">Select</option>
                                                <?php
                                                foreach ($product as $row) {
                                                    ?>
                                                                                                                    <option value="<?php echo $row['itm_id'] ?>" <?php if (isset($product_id) && $product_id == $row['itm_id']) echo "selected='selected'"; ?>><?php echo $row['itm_name'] ?></option>
                                                    <?php
                                                }
                                                ?>
                                                                                                        </select>  
                                                                                                    </div>
                                                                                                </div>-->

                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Product<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="product" id="adj_product" required style="width:100%;padding:10%;">
                                                            <!--<option value="">Select</option>-->
                                                            <?php
//                                                            foreach ($product as $row) {
                                                            ?>
                                                                <!--<option id="<?php // echo $row['itm_id'].'_'.$row['product_type']; ?>" value="<?php echo $row['itm_id'] ?>" <?php if (isset($item_id) && $item_id == $row['itm_id']) echo "selected='selected'";
                                                            else if (isset($product_id) && $product_id == $row['itm_id']) echo "selected='selected'"; ?>><?php echo $row['itm_name'] ?></option>-->
<?php
//                                                            }
?>
                                                        </select>  
                                                    </div>
                                                </div>

                                            </div>

                                            <div class="form-group row" >
                                                <div class="col-md-3" id="show_batch" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="batch" >Batch<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="batch" id="issue_batch" style="width:100%;padding:10%;" onchange="unit_price_check(this.value)">
                                                                <!--<option value="">Select</option>-->
                                                            </select>                                                        
                                                        </div>
                                                    </div> 
                                                </div>
                                            </div>

                                            <div class="form-group row"  id="show_main_info"> 

                                                <!--                                                <div class="col-md-3">
                                                                                                    <div class="control-group">
                                                                                                        <label class="example-text-input" for="batch" required >Batch<span style="color: red">*</span> </label>
                                                                                                        <div class="controls">
                                                                                                            <select class="select2me input-medium" name="batch" id="batch" required style="width:100%;padding:10%;">
                                                                                                                <option value="">Select</option>
                                                
                                                                                                            </select>                                                        
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>-->
                                                <!--                                                <div class="col-md-3" id="show_batch" style="display:none;">
                                                                                                    <div class="control-group">
                                                                                                        <label class="example-text-input" for="batch" >Batch<span style="color: red">*</span> </label>
                                                                                                        <div class="controls">
                                                                                                            <select class="select2me input-medium" name="batch" id="issue_batch" style="width:100%;padding:10%;">
                                                                                                                <option value="">Select</option>
                                                                                                                <option value="13">Others</option>
                                                                                                            </select>                                                        
                                                                                                        </div>
                                                                                                    </div> 
                                                                                                </div>-->
                                                <input type="hidden" name="otherproduct_batch" id="otherproduct_batch" value=""> 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="quantity" required >Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="quantity" id="quantity" class="form-control"   required >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="available_quantity" required >Available Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input name="available_quantity" id="available_quantity" class="form-control"   required readonly="true">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Expiry Date <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" name="batch_expiry" id="batch_expiry" class="form-control"   required value="" readonly="true">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div> 

                                            <div class="form-group row" id="other_show_info" style="display:none;">

                                                <div class="col-md-3" >
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="other_batch" >Batch<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="other_batch" id="other_batch" class="form-control">
                                                        </div>
                                                    </div> 
                                                </div>

                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="other_quantity" required >Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="other_quantity" id="other_quantity" class="form-control"  >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="other_prod_date" >Production Date(MM/DD/YYYY) </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="other_prod_date" id="other_prod_date" <?php // if (isset($master_id)) echo 'disabled="true"' ?>
                                                            <?php
                                                            if (isset($form['other_prod_date'])) {
                                                                echo 'value="' . $form['other_prod_date'] . '"';
                                                            } else {
                                                                echo 'value="' . date("m/d/Y") . '"';
                                                            }
                                                            ?>
                                                                   >

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="other_expiry_date" >Expiry Date(MM/DD/YYYY)<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="other_expiry_date" id="other_expiry_date" required <?php // if (isset($master_id)) echo 'disabled="true"' ?>
                                                            <?php
                                                            if (isset($form['other_expiry_date'])) {
                                                                echo 'value="' . $form['other_expiry_date'] . '"';
                                                            } else {
                                                                echo 'value="' . date("m/d/Y") . '"';
                                                            }
                                                            ?>
                                                                   >

                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3" >
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="unit_price"  >Unit Price<span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number"  step="0.01" min="0" name="unit_price" id="unit_price" class="form-control"
                                                            <?php
                                                            if (isset($unit_price) && !empty($unit_price)) {
                                                                echo 'value="' . $unit_price . '"';
                                                            }
                                                            ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="currency"  >Currency </label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="currency" id="currency"  style="width:100%;padding:10%;" >
                                                                <!--<option value="">Select</option>-->
                                                                <?php
                                                                foreach ($currency_type as $currencytype) {
                                                                    ?>
                                                                    <option value="<?php echo $currencytype['pk_id'] ?>" <?php if (isset($currency) && $currency == $currencytype['pk_id']) {
                                                                    echo "selected='selected'";
                                                                } ?>><?php echo $currencytype['name'] ?></option>
    <?php
}
?>

                                                            </select>  
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>


                                            <div class="form-group row">


                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Details about this adjustment</label>
                                                        <div class="controls">
                                                            <textarea name="remarks" id="remarks" class="form-control" ></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div id="issue_batch_details">

                                            </div>

                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-success waves-effect waves-light" > Add Adjustment</button>
<!--                                                    <input type="hidden" name="prod_conversion_rate" id="conversion_rate" value="">
                                                    <input type="hidden" name="prod_unit_price" id="unit_price" value=""> 
                                                    <input type="hidden" name="prod_currency" id="currency" value="">
                                                    <input type="hidden" name="prod_actual_rec_qty" id="actual_rec_qty" value="">-->
                                                    <input type="hidden" name="prod_field1" id="prod_field1" value="">
                                                    <input type="hidden" name="prod_field2" id="prod_field2" value="">
                                                    <input type="hidden" name="prod_field3" id="prod_field3" value="">
                                                    <input type="hidden" name="prod_field4" id="prod_field4" value="">
                                                    <input type="hidden" name="prod_field5" id="prod_field5" value="">
                                                    <input type="hidden" name="prod_field6" id="prod_field6" value="">
                                                    <input type="hidden" name="prod_field7" id="prod_field7" value="">
                                                    <input type="hidden" name="prod_field8" id="prod_field8" value="">
                                                    <input type="hidden" name="prod_field9" id="prod_field9" value="">
                                                    <input type="hidden" name="prod_field10" id="prod_field10" value="">
                                                </div>  
                                                <?php if (isset($temp_records) && (!empty($temp_records))) {
                                                    ?>
                                                    <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>"> 
<?php }
?>    
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <br>
                            <div style="overflow-x:auto;width:100%;">
<?php
if (isset($temp_records) && (!empty($temp_records))) {
    ?>

                                    <div id="divToPrint">
                                        <table class="table table-striped table-bordered table-condensed dt-responsive " >
                                            <thead>
                                                <tr>
                                                    <th style="width: 1%;" class="center">No.</th>
    <!--                                                <th>Funding Source</th>-->
                                                    <th>Product Name</th>  
                                                    <th>Product Category</th>  
    <!--                                                <th>Manufacturer</th>-->
                                                    <th>Batch#</th>
                                                    <!--<th>Mfg Date</th>-->
                                                    <th>Exp. Date</th>
    <!--                                                <th>Serial No</th>
                                                    <th>Warranty (years)</th>
                                                    <th>Pack Size</th>
                                                    <th>Unit</th>
                                                    <th>Temp From</th>
                                                    <th>Temp to</th>-->
                                                    <th>Quantity</th> 
                                                    <th>Adjustment Type</th> 
                                                    <th>Action</th>  
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <!-- Table row -->
                                                <?php
                                                $count = 1;
                                                foreach ($temp_records->result_array() as $row) {
                                                    ?>
                                                    <tr>
                                                        <td class="center"><?php echo $count; ?></td>
        <!--                                                    <td class="important"><?php // echo $row['funding_source_name'];  ?></td>-->
                                                        <td><?php echo $row['product_name']; ?></td> 
                                                         <td><?php echo $row['stkname']; ?></td> 

        <!--                                                    <td><?php if (!empty($row['field1'])) {
                                                        echo $row['field1'];
                                                    } else echo ''; ?></td>
        <td><?php if (!empty($row['field2'])) {
                                                        echo $row['field2'];
                                                    } else echo ''; ?></td>
        <td class="important"><?php if (!empty($row['field3'])) {
                                                        echo $row['field3'];
                                                    } else echo ''; ?></td>
        <td><?php if (!empty($row['field4'])) {
                                                        echo $row['field4'];
                                                    } else echo ''; ?></td>
        <td><?php if (!empty($row['field5'])) {
                                                        echo $row['field5'];
                                                    } else echo ''; ?></td>
        <td><?php if (!empty($row['field6'])) {
                                                        echo $row['field6'];
                                                    } else echo ''; ?></td>
        <td><?php if (!empty($row['field7'])) {
                                                        echo $row['field7'];
                                                    } else echo ''; ?></td>
        <td><?php if (!empty($row['field8'])) {
                                                echo $row['field8'];
                                            } else echo ''; ?></td>
        <td><?php if (!empty($row['field9'])) {
                                                echo $row['field9'];
                                            } else echo ''; ?></td>-->

        <!--                                                    <td class="important"><?php // echo $row['manufacturer'];  ?></td>-->
                                                        <td class="important"><?php echo $row['batch_no']; ?></td>
                                                        <td class="important"><?php echo $row['batch_expiry']; ?></td> 
                                                        <td class="important"><?php echo $row['quantity']; ?></td> 
                                                        <td class="important"><?php echo $row['trans_type']; ?></td>
                                                        <td><button class="btn btn-danger btn-sm" type="button" id="<?php echo $row['pk_id'] . "_" . $row['fk_stock_id'] . "_" . $row['batch_id'] . "_" . $row['quantity']; ?>-deletegsi">
                                                                <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Delete
                                                            </button></td>

                        <!--                                                <td>  
                                                                            <a onclick="return confirm('Are you sure you want to Delete?');" href="<?php echo base_url("product_management/deactivate?id=") . $row['pk_id']; ?>&status=1" class="btn btn-sm btn-light glyphicons bin" > Delete</a>
                                                                        </td> -->
                                                    </tr>
        <?php
        $count++;
    }
    ?>
                                                <!-- // Table row END -->
                                                <!-- Table row -->

                                                <!-- // Table row END -->
                                            </tbody>
                                        </table> 
                                    </div>
                                    <button type="button" id="save_temp_issue" name="save_temp_issue" class="btn btn-success waves-effect waves-light" style="margin-left:90%;">Save</button>

                                    <!-- // Table END -->
    <?php
}
?>
                            </div>
                        </form>    
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>

<script>
    function unit_price_check(val) {
        if (val == 'others') {
            $("#unit_price").attr('required', true);
        } else {
            $("#unit_price").prop('required', false);
        }
    }
</script>
