<style>
*{font-family:"Open Sans",sans-serif;}
b{font-size:12px;}
h3{font-size:13px;}
#report_type{
font-size:12px;
font-family: arial;}
#content_print
{
	width:624px;
	margin-left:50px;
}
table#myTable{
	border:1px solid #B6B6B7;
	font-size:9pt;
	width:80%;
}
table, table#myTable tr td{
	border-collapse: collapse;
	border:1px solid #B6B6B7;
	font-size:12px;
}
table, table#myTable tr th{
	border:1px solid #B6B6B7;
	border-collapse: collapse;
	font-size:12px;
}

table#myTables{
	border:1px solid #B6B6B7;
	font-size:9pt;
	width:50%;
}
table, table#myTables tr td{
	border-collapse: collapse;
	border:1px solid #B6B6B7;
	font-size:12px;
}
table, table#myTables tr th{
	border:1px solid #B6B6B7;
	border-collapse: collapse;
	font-size:12px;
}

table#loc_from_to{
	border:1px solid #B6B6B7;
	font-size:9pt;
	width:40%;
}
table, table#loc_from_to tr td{
	border-collapse: collapse;
	border:1px solid #B6B6B7;
	font-size:12px;
}
table, table#loc_from_to tr th{
	border:1px solid #B6B6B7;
	border-collapse: collapse;
	font-size:12px;
}
#printbuttonstyle {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 4px;
}
</style>
<?php
/**
 * printIssue
 * @package im
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
//includ AllClasses
//include("../includes/classes/AllClasses.php");

$title = "Stock Issue Voucher";
$print = 1;
$whNames = array();
$logo1 = array();
if(!empty($whName))
{
    foreach ($whName as $row)
    {
        $stkid = $row['stkid'];
        $whname = $row['wh_name'];
        $prov_id = $row['prov_id'];
        $lvl = $row['lvl'];
    }
}
else{
        $stkid = '';
        $whname = '';
        $prov_id = '';
        $lvl = '';
}
if(isset($logo) && !empty($logo))
{
    foreach ($logo as $rowlogo)
    {
        $logo1[1] = $rowlogo;
    }
}
//get id
$receiveArr = array();
//fetching data from stocks
foreach ($stocks as $row) {
    //issue_no 
    $issue_no = $row['tran_no'];
    //comments
    $comments = $row['received_remarks'];
    //tran_ref
    $tran_ref = $row['tran_ref'];
    //issue_date
    $issue_date = $row['tran_date'];
    //wh_to_id
    $wh_to_id = $row['wh_id'];
    //issue_to
    $issue_to = $row['wh_name'];
    //issued_by
//    $issued_by = $row['issued_by'];
    $issued_by = '';
    
    $wh_from_supplier = $row['wh_from_supplier'];
//    $date_of_receiving = $row['tran_date'];
    $invoice = $row['invoice'];
    
    $po_cmu_date = $row['po_cmu_date'];
    $po_cmu_no = $row['po_cmu_no'];
    $po_gf_no = $row['po_gf_no'];
    $po_gf_date = $row['po_gf_date'];
    
    $air_bill_no = $row['air_bill_no'];
    $dc_no = $row['dc_no'];
    $shipment_no = $row['shipment_no'];
    
    $origin_of_country = $row['origin_of_country'];
    $inspection_date = $row['inspection_date'];
    $delivery_location = $row['delivery_location'];
    $vehicle_type_and_plate = $row['vehicle_type_and_plate'];
    $date_of_receiving = $row['date_of_receiving'];
    $consignment_weight = $row['consignment_weight'];
    $username = $row['username'];
    $designation = $row['designation'];
    $quantity_fixed = $row['quantity'];
//    $issue_to = $row['wh_name'];
    //receiveArr
    $receiveArr[] = $row;
}
// Get district Name
//$getDist = "SELECT
//			tbl_locations.LocName
//		FROM
//			tbl_warehouse
//		INNER JOIN tbl_locations ON tbl_warehouse.dist_id = tbl_locations.PkLocID
//		WHERE
//			tbl_warehouse.wh_id = $wh_to_id";
////query result
//$rowDist = mysql_fetch_object(mysql_query($getDist));
$rowDist = 'XYZ';
?>
<!--<br><br><br><br><br><br><br><br>-->
<!--<i id="btnExport" onclick="fnExcelReport();" class="fa fa-file-excel-o" style="font-size:32px;color:#33B23F;float: right;">excel</i>-->
<!--<button onclick="fnExcelReport()" style="float:right;background: #B5E4CB;color:black;" class="btn btn-success">Excel Export</button>
    <br><br>-->
<div id="content_print">
	<?php 
        //include header
//        include(PUBLIC_PATH."/html/header.php");
        //include top_im
//        include PUBLIC_PATH."html/top_im.php";?>
	<!--<div style="float:right; font-size:12px;">QR/015/01.08.2</div>-->
	<style type="text/css" media="print">
    @media print
    {    
        #printButt
        {
            display: none !important;
        }
/*        body {
            zoom:200%;
            width:100%; 
            height:100%;
        }*/
    }
    </style>
	<?php
        if(isset($_REQUEST['gwis']) && $_REQUEST['gwis'] == '1')
        {
		$rptName = 'GOODS RECEIVED NOTE (GRN)';
     	}
        else
            if(isset($_REQUEST['gatepass']) && $_REQUEST['gatepass'] == '1')
        {
		$rptName = 'Gate Pass Voucher';
     	}
//    	include('report_header');
                ?>
                
                
         <div style="line-height:1;">
    <div id="logoLeft" style="float:left; width:107px; text-align:right;">
    <!--<img src="<?php echo PUBLIC_URL;?>images/gop.png" />-->
        <img id="pics" style="border-radius: 50%;" src="<?php echo base_url('assets/images/lmis.jpg')?>" alt="" height="60">
    </div>
    <div id="report_type" style="float:left; width:386px; text-align:center;">
        <?php 
        if ($stkid==1 && $provid==1 && $lvl==3) 
        {
            ?>
                <span style="line-height:20px"><b>POPULATION WELFARE DEPARTMENT</b></span><br/>
                <span style="line-height:20px"><b>GOVERNMENT OF PUNJAB</b></span><br/>
        <?php }
        elseif ($stkid==145) 
        {
            ?>
                <span style="line-height:20px"><b>PRIMARY & SECONDARY HEALTHCARE DEPARTMENT</b></span><br/>
                <span style="line-height:20px"><b>GOVERNMENT OF PUNJAB</b></span><br/>
                <span style="line-height:20px"><b>MEDICAL STORE DEPO LAHORE</b></span><br/>
        <?php 
        }elseif ($stkid==1) 
        {
            ?>
                <span style="line-height:20px"><b>GOVERNMENT OF PAKISTAN</b></span><br/>
                <span style="line-height:20px"><b>CMU</b></span><br/>
                <span style="line-height:20px"><b>REGULATIONS & COORDINATION</b></span><br/>
                <span style="line-height:20px">DIRECTORATE OF CENTRAL WAREHOUSE & SUPPLIES</span><br/>
        <?php 
        } 
        else {
            ?>
                <span style="line-height:20px"><b>GOVERNMENT OF PAKISTAN</b></span><br/>
                <span style="line-height:20px"><b>MINISTRY OF NATIONAL HEALTH SERVICES REGULATIONS & COORDINATION</b></span><br/>
                <span style="line-height:20px"><b>NATIONAL TUBERCULOSIS, TB AND MALARIA CONTROL PROGRAMME</b></span><br/>
                <span style="line-height:20px">COMMON MANAGEMENT UNIT (CMU)</span><br/>
                <!--<span style="line-height:20px"><?php // echo $logo1[1]?></span><br/>-->
        <?php 
        
        }?>
        <!--<span style="line-height:15px"><b>Store: </b><?php echo $whname;?></span>-->
        <hr style="margin:3px 10px;" />
        <p><b><?php echo $rptName;?> as on: <?php echo date('d-M-Y');?></b>
        </p>
    </div>
    <div id="logoLeft" style="float:right; width:107px;">
    <!--<img src="<?php echo PUBLIC_URL;?>images/gop.png" />-->
        <img id="pics" style="border-radius: 50%;" src="<?php echo base_url('assets/images/global_fund.png')?>" alt="" height="60">
    </div>
</div>
<div style="clear:both"></div>       
                
                
        <div style="width:100%;">
            <!--<b style="float:right;">District: <?php echo $rowDist; ?></b><br />-->
            <!--<b style="float:left;">Issue Voucher: <?php echo $issue_no; ?></b>-->
            <table style="float:left;width: 45%;" id="loc_from_to" class="table-condensed" cellpadding="3">
                <tbody>
                <tr>
                    <th style="background-color:#79D0FF;"> GIWS NO</th>
                    <td><?php echo str_replace(array('T'), 'P',$tran_ref);?></td>
                </tr>
                <tr>
                    <th style="background-color:#79D0FF;"> TAC NO</th>
                    <td><?php echo $tran_ref;?></td>
                </tr>
                <tr>
                    <th style="background-color:#79D0FF;"> GRN NO</th>
                    <td><?php echo $issue_no;?></td>
                </tr>
                <tr>
                    <th style="background-color:#79D0FF;"> GRN Date</th>
                    <td><?php echo date('d-M-Y', strtotime($issue_date));?></td>
                </tr>
                </tbody>
            </table>
            <table style="float:right;width: 45%;" id="myTables" class="table-condensed" cellpadding="3">
                <tr style="background-color:#79D0FF;">
                    <th width="5%"> PO # CMU</th>
                    <th width="5%"> CMU PO Date </th>
                    <th width="5%"> PO # GF/GDF</th>
                    <th width="5%"> GF/GDF PO Date</th>
    <!--                <th width="10%" align="center">Unit</th>
                    <th width="15%" align="center">Cartons</th>-->
                </tr>
                <tbody>
                    <?php // foreach ($stocks as $row) { ?>
                    <tr>
                        <td><?php echo $po_cmu_no; ?></td>
                        <td><?php if (!empty($po_cmu_date) && $po_cmu_date != '0000-00-00'){ echo $po_cmu_date; } ?></td>
                        <td><?php echo $po_gf_no; ?></td>
                        <td><?php if (!empty($po_gf_date) && $po_gf_date != '0000-00-00'){ echo $po_gf_date; } ?></td>
                    </tr>
                    <?php // } ?>
                </tbody>
            </table>
            <!--<b style="float:right;">Date of Departure: <?php echo date('d-M-Y', strtotime($issue_date)); ?></b>-->
        </div>

<br><br><br><br><br><br><br><br><br><br>
        <div style="width:100%;">
            <!--<b style="float:right;">District: <?php echo $rowDist; ?></b><br />-->
            <!--<b style="float:left;">Issue Voucher: <?php echo $issue_no; ?></b>-->
            <table style="float:left;width:45%;" id="loc_from_to" class="table-condensed" cellpadding="3">
                <tr style="background-color:#79D0FF;">
                    <th width="5%" colspan="2" > Documentation Received with Supplies</th>
                    <th width="5%"> Details </th>
    <!--                <th width="10%" align="center">Unit</th>
                    <th width="15%" align="center">Cartons</th>-->
                </tr>
                <tbody>
                    <tr>
                        <td class="center"><input type="checkbox" <?php if(!empty($air_bill_no)) { ?>checked=“true” <?php } ?>  /></td>
                        <td style="background-color:#79D0FF;"><?php echo 'Air waybill No. / Bill of Lading';?></td>
                        <td><?php echo $air_bill_no;?></td>
                    </tr>
                    <tr>
                        <td class="center"><input type="checkbox" <?php if(!empty($invoice)) { ?>checked=“true” <?php } ?>  /></td>
                        <td style="background-color:#79D0FF;"><?php echo 'Supplier Invoice No.';?></td>
                        <td><?php echo $invoice;?></td>
                    </tr>
                    <tr>
                        <td class="center"><input type="checkbox" <?php if(!empty($dc_no)) { ?>checked=“true” <?php } ?> /></td>
                        <td style="background-color:#79D0FF;"><?php echo 'Supplier Delivery Note No.';?></td>
                        <td><?php echo $dc_no;?></td>
                    </tr>
                    <tr>
                        <td class="center"><input type="checkbox" <?php if(!empty($shipment_no)) { ?>checked=“true” <?php } ?>  /></td>
                        <td style="background-color:#79D0FF;"><?php echo 'Shipment number';?></td>
                        <td><?php echo $shipment_no;?></td>
                    </tr>
                </tbody>
            </table>
            <table style="float:right;width:45%;" id="myTables" class="table-condensed" cellpadding="3">
                
                <tbody>
                    <tr>
                        <th width="5%" style="background-color:#79D0FF;"> Origin of Country</th>
                        <td width="5%"> <?php echo $origin_of_country; ?></td>
                    </tr>
                    <tr>
                        <th width="5%" style="background-color:#79D0FF;"> Name of Supplier</th>
                        <td width="5%"> <?php echo $wh_from_supplier; ?></td>
                    </tr>
                    <tr>
                        <th width="5%" style="background-color:#79D0FF;"> Date of inspection</th>
                        <td width="5%"> <?php if (!empty($inspection_date) && $inspection_date != '0000-00-00'){ echo $inspection_date; } ?></td>
                    </tr>
                    <tr>
                        <th width="5%" style="background-color:#79D0FF;"> Delivery Location</th>
                        <td width="5%"> <?php echo $delivery_location; ?></td>
                    </tr>
                    <tr>
                        <th width="5%" style="background-color:#79D0FF;"> Vehicle Type & Plate #</th>
                        <td width="5%"> <?php echo $vehicle_type_and_plate; ?></td>
                    </tr>
                    <tr>
                        <th width="5%" style="background-color:#79D0FF;"> Date of Receiving</th>
                        <td width="5%"> <?php if (!empty($date_of_receiving) && $date_of_receiving != '0000-00-00'){ echo $date_of_receiving; } ?></td>
                    </tr>
                    <tr>
                        <th width="5%" style="background-color:#79D0FF;"> Total weight of consignment</th>
                        <td width="5%"> <?php echo $consignment_weight; ?></td>
                    </tr>
                </tbody>
            </table>
            <!--<b style="float:right;">Date of Departure: <?php echo date('d-M-Y', strtotime($issue_date)); ?></b>-->
        </div>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
         
<!--        <div style="text-align:center;">
            <b style="float:right;">District: <?php echo $rowDist; ?></b><br />
            <b style="float:left;">Issue Voucher: <?php echo $issue_no; ?></b>
            <b style="float:right;">Date of Departure: <?php echo date('d-M-Y', strtotime($issue_date)); ?></b>
        </div>
        <div style="clear:both;">
            <b style="float:left;">Reference No.: <?php echo $tran_ref; ?></b>
            <b style="float:right;">Issue To: <?php echo $issue_to;?></b><br />
            <b style="float:right;">Issue By: <?php echo $issued_by;?></b>
        </div>-->
        
<table id="myTable" style="width:100%;" class="table-condensed" cellpadding="3">
            <tr>
                <th width="8%" rowspan="2">Line No.</th>
                <th rowspan="2">Item Code</th>
                <th rowspan="2" width="15%">Item Description</th>
                <th rowspan="2" width="15%">UoM</th>
                <th rowspan="2">Qty Received</th>
                <th rowspan="2" width="15%">Unit Cost</th>
                <th rowspan="2" width="15%">Total Cost</th>
                <th rowspan="2" width="15%" align="center">Expiry Date</th>
                <th rowspan="2" width="10%" align="center">Batch / Lot Number</th>
                <th rowspan="2" width="10%" align="center">Comments</th>
            </tr>
            <tbody>
                
                <?php 
                                                $startDate = new DateTime($row['batch_expiry']);
                                                $endDate = new DateTime(date('d-M-Y',strtotime($row['tran_date'])));

                                                $difference = $endDate->diff($startDate);
                                                $days = $difference->format("%a");
//                                                $secs = $datetime2 - $datetime1;// == <seconds between the two times>
//                                                $days = $secs / 86400;
                                                
//                                                $stockID = $row['fk_stock_id'];
                                                $issuance_date = $row['tran_date'];
                                                ?>
                
                
                <?php
                $i = 1;
				$totalQty = 0;
				$totalCartons = 0;
				$product = '';
                //check receiveArr
                                if (!empty($receiveArr)) {
                    foreach ($receiveArr as $val) {
//						print_r($val);exit();
//						if ( $val['itm_name'] != $product && $i > 1 )
//						{
						?>
<!--                        <tr>
                            <th colspan="4" style="text-align:right;">Total</th>
                            <th style="text-align:right;"><?php echo number_format($totalQty);?></th>
                            <th>&nbsp;</th>
                            <th style="text-align:right;"><?php echo number_format($totalCartons);?></th>
                        </tr>-->
                        <?php
							$totalQty = abs($val['quantity']);
//							$totalCartons = abs($val['quantity']) / $val['qty_carton'];
//						}
//						else
//						{	
//							$totalQty += abs($val['quantity']);
////							$totalCartons += abs($val['Qty']) / $val['qty_carton'];
//						}
//						$product = $val['itm_name'];
						$conversion_rate = $val['conversion_rate'];
						if (0 >= $conversion_rate){
							$conversion_rate = 1;
						}
                        ?>
                        <tr>
                            <td style="text-align:center;"><?php echo $i++; ?></td>
                            <td><?php echo $val['itmrec_id']; ?></td>
                            <td><?php echo $val['itm_name']; ?></td>
                            <td style="text-align:center;"> <?php echo $val['method_type']; ?></td>
                    <?php if(!empty($val['ti_quantity']) && !empty($val['pi_quantity'])) {?>
                            <td><?php if(!empty($val['ti_quantity'])) {echo $val['ti_quantity'];}else {echo $val['pi_quantity'];} ?></td>
                    <?php } else {?> 
                            <td><?php echo $val['quantity']; ?></td>
                            <?php }?> 
 <!--<td style="text-align:center;"> <?php echo date('d-M-Y', strtotime($val['batch_expiry'])); ?></td>-->
                            <td style="text-align:right;"><?php echo $val['unit_price']; ?></td>
                              <?php if(!empty($val['grn_quantity']) && $val['grn_quantity'] != 0) {?>
                            <td style="text-align:center;"><?php echo $val['unit_price'] * $conversion_rate * $val['grn_quantity']; ?></td>
                             <?php } else {?> 
                             <td style="text-align:center;"><?php echo $val['unit_price'] * $conversion_rate * $val['quantity']; ?></td>
                                <?php }?> 
                            <td style="text-align:right;"><?php echo date('d-M-Y', strtotime($val['batch_expiry'])); ?></td>
                            <td style="text-align:right;"><?php echo $val['batch_no']; ?></td>
                            <td style="text-align:right;"><?php echo $val['received_remarks']; ?></td>
                        </tr>
                        <?php
                    }
                }
                ?>
<!--                <tr>
                    <th colspan="4" style="text-align:right;">Total</th>
                    <th style="text-align:right;"><?php echo number_format($totalQty);?></th>
                    <th>&nbsp;</th>
                    <th style="text-align:right;"><?php echo number_format($totalCartons);?></th>
                </tr>-->
            </tbody>
        </table>
        <?php if(!empty($comments)){?>
        <div style="font-size:12px; padding-top:3px;"><b>Comments:</b> <?php echo $comments;?></div>
        <?php }?>
        
        <?php // include('report_footer_issue.php');?>
        
        <div style="width:100%; clear:both;margin-top:30px;">
            <table width="100%" cellpadding="5" style="float:left; border:2px solid #E5E5E5 !important; border-collapse:collapse; margin-top:10px;">
                <tr>
                    <td><b>Goods Receiver Comments</b> : ____________________________________________________________________________________________________________</td>
                </tr>
            </table>
        </div>
        
        <div style="width:100%; clear:both; margin-top:100px;">
        
    <table width="48%" cellpadding="5" style="float:left; border:2px solid #E5E5E5 !important; border-collapse:collapse;">
        <tr>
            <td><b>Prepared By</b><hr> Name: <u><?php echo $_SESSION['name']; ?></u></td>
        </tr>
        <tr>
            <td>Designation: <u><?php echo $_SESSION['designation']; ?></u></td>
        </tr>
        <tr>
            <td>Signature: _______________________________________</td>
        </tr>
        <tr>
            <td>Date: ____________________________________________</td>
        </tr>
    </table>
    <table width="48%" cellpadding="5" style="float:right; border:2px solid #E5E5E5 !important; border-collapse:collapse;">
        <tr>
            <td><b>Reviewed By</b><hr> Name: ___________________________________________</td>
        </tr>
        <tr>
            <td>Designation: _____________________________________</td>
        </tr>
        <tr>
            <td>Signature: _______________________________________</td>
        </tr>
        <tr>
            <td>Date: ____________________________________________</td>
        </tr>
    </table>
</div>
        
        
        <div style="width:100%; clear:both;">
            <table width="48%" cellpadding="5" style="float:left; border:2px solid #E5E5E5 !important; border-collapse:collapse; margin-top:10px;">
                <tr>
                    <td><b>Approved By</b><hr> Name: <?php if(isset($username) && !empty($username)) {?><u><?php echo $username; ?></u> <?php } else { ?>___________________________________________<?php } ?></td>
        </tr>
        <tr>
            <td>Designation: <?php if(isset($designation) && !empty($designation)) {?><u><?php echo $designation; ?></u> <?php } else { ?>_____________________________________<?php } ?></td>
        </tr>
        <tr>
            <td>Signature: _______________________________________</td>
        </tr>
        <tr>
            <td>Date: ____________________________________________</td>
        </tr>
            </table>
        </div>
        
        <div style="float:right; margin-top:100px;" id="printButt">
        	<button type="button" id="printbuttonstyle" class="btn btn-warning" onclick="javascript:printCont();"> Print </button>
        </div>
    </div>
<script src="<?php echo PUBLIC_URL;?>assets/global/plugins/jquery-1.11.0.min.js" type="text/javascript"></script>
<script language="javascript">
$(function(){
	//printCont();
})
function printCont()
{
	window.print();
}

function fnExcelReport()
{
    var tab_text="<table border='2px'><tr bgcolor='#33B23F'>";
    var textRange; var j=0;
    tab = document.getElementById('loc_from_to'); // id of table

    for(j = 0 ; j < tab.rows.length ; j++) 
    {     
        tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
        //tab_text=tab_text+"</tr>";
    }

    tab_text=tab_text+"</table>";
    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE "); 

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea1.document.open("txt/html","replace");
        txtArea1.document.write(tab_text);
        txtArea1.document.close();
        txtArea1.focus(); 
        sa=txtArea1.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xls");
    }  
    else                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

    return (sa);
}

</script>
