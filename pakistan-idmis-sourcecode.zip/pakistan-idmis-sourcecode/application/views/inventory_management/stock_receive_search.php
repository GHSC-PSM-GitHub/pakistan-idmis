<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
}
    
</style>
<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Stock Receive Search</h3>
                         
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                     <div class="innerLR">
                        
                         <form method="POST" name="sr_search" action="stock_receive_search" >
                            <!-- Row -->
                  <div class="col-md-12">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <div class="form-group row ">
                                <!--<div class="col-md-12">-->
                                
                                    <div class="col-md-3">
                                        <div class="control-group">
                                            <label class="example-text-input" for="start_date"  >Date From(DD/MM/YYYY) <span style="color: red">*</span> </label>
                                            <div class="controls">
                                                <input type="text" class="form-control" name="start_date" id="start_date" required="" value="<?php if(isset($_REQUEST['start_date']) && !empty($_REQUEST['start_date'])) { echo $_REQUEST['start_date'];} else { echo date("d/m/Y");} ?>" >

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="control-group">
                                            <label class="example-text-input" for="end_date"  >Date To(DD/MM/YYYY) <span style="color: red">*</span> </label>
                                            <div class="controls">
                                                <input type="text" class="form-control" name="end_date" id="end_date" required=""  value="<?php if(isset($_REQUEST['end_date']) && !empty($_REQUEST['end_date'])) { echo $_REQUEST['end_date'];} else { echo date("d/m/Y");} ?>" >

                                            </div>
                                        </div>
                                    </div>
                                
                                    <div class="col-md-3" id="show_receive_from_suppliers" >
                                        <label class="example-text-input" for="suppliers"  >Received From (Supplier) </label>
                                        <div class="controls">
                                            <?php

//                                            if (empty($temp_records)) {

                                            ?>
                                            <select class="select2me input-medium"  name="receive_from_suppliers" id="receive_from_suppliers" style="width:100%;padding:10%;">
                                                <option value="">Select</option>
                                                <?php

                                                foreach ($suppliers as $row) {
                                                    ?>
                                                    <option value="<?php echo $row['wh_id'] ?>" <?php if (isset($_REQUEST['receive_from_suppliers']) && $_REQUEST['receive_from_suppliers'] == $row['wh_id']) echo "selected='selected'"; ?>><?php echo $row['wh_name'] ?></option>
                                                    <?php
                                                }
                                                ?>

                                            </select>  
                                            <?php
//                                            }else
//                                            {
//                                                foreach ($suppliers as $row) {
////                                                                if(isset($warehouse_from) && $warehouse_from == $row['stkid']) echo  '<input class="form-control" disabled value="'.$row['stkname'].'">';
//                                                    if(isset($warehouse_from_supplier) && $warehouse_from_supplier == $row['wh_id']) { echo  '<input class="form-control" disabled value="'.$row['wh_name'].'">';   } 
//                                                    else if (isset($gwis_supplier) && $gwis_supplier == $row['wh_id']){ echo '<input class="form-control" disabled value="'.$row['wh_name'].'">'; } 
//
//                                                }
//                                            }
                                            ?>
                                        </div>
                                    </div>
                                
                                    <div class="col-md-3">
                                        <div class="control-group">
                                        <div class="input-group input-medium" style="margin-top: 21px;">
                                            <div class="controls">
                                            <button type="submit" class="btn btn-primary" name="submit" value="Search"> Search </button>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                <!--</div>-->
                            </div>
                        </div>
                    </div>
                  </div>
            </form>
                         
                         <br>
                        <?php
                        if (isset($_REQUEST['submit']) && !empty($result)) {
                            ?>

                            <div id="divToPrint">
                                <table class="table table-striped table-bordered table-condensed dt-responsive nowrap" id="datatable-buttons">
                                    <thead>
                                        <tr>
                                            <th style="width: 1%;" class="center">No.</th>
                                            <th>Transaction Number</th>
                                            <th>Reference Number</th>
                                            <!--<th>Receiving Date</th>-->
                                            <th>Supplier</th>
                                            <th>Warehouse</th>
                                            <th>Product Name</th>   
                                            <th>Batch Number</th>
                                            <th>Expiry Date</th> 
                                            <th>Quantity</th> 
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Table row -->
                                        <?php
                                        $count = 1; 
                                        foreach ($result->result_array() as $row) {
                                            ?>
                                            <tr>
                                                <td class="center"><?php echo $count; ?></td>
                                                <!--<td class="important"><?php echo "R-".sprintf('%04d', $row['fkStockID']); ?></td>-->
                                                <td>
                                                    <a style="text-decoration: underline;" onclick="window.open('print_receive?id=<?php echo $row['PkStockID']; ?>&receive=1', '_blank', 'scrollbars=1,width=842,height=595');" href="javascript:void(0);"><?php echo $row['TranNo']; ?></a><br>
                                                    <!--<a style="text-decoration: underline;" onclick="window.open('print_receive?id=<?php echo $row['PkStockID']; ?>&gatepass=1', '_blank', 'scrollbars=1,width=842,height=595');" href="javascript:void(0);"><?php echo 'Gate Pass'; ?></a>-->
                                                </td>
                                                <td class="important"><?php echo $row['TranRef']; ?></td>
                                                 <!--<td class="important"><?php echo $row['TranDate']; ?></td>-->
                                                 <td class="important"><?php echo $row['wh_from']; ?></td>
                                                 <td class="important"><?php echo $row['wh_from_supplier']; ?></td>
                                                <td><?php echo $row['product_name']; ?></td>  
                                                <td class="important"><?php echo $row['batch_no']; ?></td>
                                                <td class="important"><?php echo $row['batch_expiry']; ?></td> 
                                                <td class="important"><?php echo $row['quantity']; ?></td> 
                                                <td>
                                                    <?php if($row['TranTypeID'] == '1') { ?>
                                                     <a class="btn btn-primary" href="<?php echo base_url("inventory_management/stock_receive?pkdetailid=" . $row['PkDetailID']."&batchid=".$row['BatchID']."&fkstockid=".$row['fkStockID']."&tranno=".$row['TranNo']."&whidto=".$row['WHIDTo']."&tranref=".$row['TranRef']."&search=true") ?>">Edit</a>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <?php
                                            $count++;
                                        }
                                        ?>
                                        <!-- // Table row END -->
                                        <!-- Table row -->

                                        <!-- // Table row END -->
                                    </tbody>
                                </table> 
                            </div>

                            <!-- // Table END -->
                            <?php
                        } else {
                            echo "<hr><h5>No data found!</h5>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>