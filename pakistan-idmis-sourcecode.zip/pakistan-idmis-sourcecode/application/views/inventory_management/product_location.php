<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
    }
  
</style>
<?php
//print_r($stock_master_records);exit;
if (isset($stock_master_records)) {


    $row = $stock_master_records[0];
        $refernce_number = $row['tran_ref'];
//    $temp_row = $temp_records->result_array();
//    $temp_row = $temp_records[0];
//    $row_temp = $temp_row[0];
//    $issue_to = $row_temp['issuance_to'];
//    $center_name = $row_temp['warehouse_name'];
//    $patient_name = $row_temp['full_name'] . "-" . $row_temp['nic_no'];
//    print_r($patient_name);exit;
} 
else if(isset($tran_reference_number)){
    $refernce_number=$tran_reference_number;
//    $temp_row = $temp_records->result_array();
    $temp_row = $temp_records[0];
//    print_r($temp_records->result_array());exit;
//    $row_temp = $temp_row[0];
//    $issue_to = $row_temp['issuance_to'];
//    $center_name = $row_temp['warehouse_name'];
//    $patient_name = $row_temp['full_name'] . "-" . $row_temp['nic_no'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Product Location</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="stock_issue" name="stock_issue" action="<?php echo base_url("inventory_management/product_location"); ?>">
                            <input type="hidden" name="center_from" id="center_from" value="<?=($this->session->warehouse_id)?>"
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row"> 
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Stakeholder </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="stakeholder" id="stakeholder"  style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                                <?php
                                                                foreach ($stakeholder as $row) {
                                                                    ?>
                                                                <option value="<?php echo $row['stkid'] ?>" <?php if (isset($form['stakeholder']) && $form['stakeholder'] == $row['stkid']) echo "selected='selected'"; ?>><?php echo $row['stkname'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>
                                                
<!--                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Product / Item<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="product" id="product" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($product as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['itm_id'] ?>" <?php if (isset($product_id) && $product_id == $row['itm_id']) echo "selected='selected'"; ?>><?php echo $row['itm_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>-->
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Product<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="change_product_loc" id="change_product_loc" required style="width:100%;padding:10%;">
                                                            <!--<option value="">Select</option>-->
                                                            <?php
//                                                            foreach ($product as $row) {
                                                                ?>
                                                                <!--<option id="<?php // echo $row['itm_id'].'_'.$row['product_type']; ?>" value="<?php echo $row['itm_id'] ?>" <?php if (isset($item_id) && $item_id == $row['itm_id']) echo "selected='selected'"; else if (isset($product_id) && $product_id == $row['itm_id']) echo "selected='selected'"; ?>><?php echo $row['itm_name'] ?></option>-->
                                                                <?php
//                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3" id="show_batch" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="change_product_batch" >Batch<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <select class="select2me input-medium" name="change_product_batch" id="change_product_batch" style="width:100%;padding:10%;">
                                                                <!--<option value="">Select</option>-->
                                                            </select>                                                        
                                                        </div>
                                                    </div> 
                                                </div>

                                            </div>
                                            
                                            <div class="form-group row"  id="show_main_info"> 

                                                <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="example-text-input" for="wh_location" >Warehouse Location </label>
                                                            <div class="controls">
                                                                <input type="text" name="wh_location" id="wh_location" class="form-control" value="" >
                                                            </div>
                                                        </div>
                                                    </div>
                                            </div> 
                                            
                                                
                                           
                                            
                                            <div id="change_product_batch_details">
                                                
                                            </div>
                                            
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-success waves-effect waves-light" > Update</button>
<!--                                                    <input type="hidden" name="prod_conversion_rate" id="conversion_rate" value="">
                                                    <input type="hidden" name="prod_unit_price" id="unit_price" value=""> 
                                                    <input type="hidden" name="prod_currency" id="currency" value="">
                                                    <input type="hidden" name="prod_actual_rec_qty" id="actual_rec_qty" value="">-->
                                                    <input type="hidden" name="prod_field1" id="prod_field1" value="">
                                                    <input type="hidden" name="prod_field2" id="prod_field2" value="">
                                                    <input type="hidden" name="prod_field3" id="prod_field3" value="">
                                                    <input type="hidden" name="prod_field4" id="prod_field4" value="">
                                                    <input type="hidden" name="prod_field5" id="prod_field5" value="">
                                                    <input type="hidden" name="prod_field6" id="prod_field6" value="">
                                                    <input type="hidden" name="prod_field7" id="prod_field7" value="">
                                                    <input type="hidden" name="prod_field8" id="prod_field8" value="">
                                                    <input type="hidden" name="prod_field9" id="prod_field9" value="">
                                                    <input type="hidden" name="prod_field10" id="prod_field10" value="">
                                                    <input type="hidden" name="detailpk_id" id="detailpk_id" value="">
                                                </div>  
                                                <?php if (isset($temp_records) && (!empty($temp_records))) {
                                                    ?>
                                                    <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>"> 
                                                <?php }
                                                ?>    
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>    
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>