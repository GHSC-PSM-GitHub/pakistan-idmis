<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
    }
    
table#myTable{
	border:1px solid #B6B6B7;
	font-size:14pt;
	width:100%;
}
table, table#myTable tr td{
	border-collapse: collapse;
	border:1px solid #B6B6B7;
	font-size:14px;
}
table, table#myTable tr th{
	border:1px solid #B6B6B7;
	border-collapse: collapse;
	font-size:14px;
}

table.alltable{
	border:1px solid #B6B6B7;
	font-size:14pt;
	width:100%;
}
table, table.alltable tr td{
	border-collapse: collapse;
	border:1px solid #B6B6B7;
	font-size:14px;
}
table, table.alltable tr th{
	border:1px solid #B6B6B7;
	border-collapse: collapse;
	font-size:14px;
}

.sprintbuttonstyle{
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 4px;
}

@media print
    {    
        body {-webkit-print-color-adjust: exact;}
        #printButt
        {
            display: none !important;
        }
        #wpprintButt
        {
            display: none !important;
        }
        #excelprintButt
        {
            display: none !important;
        }
/*        body {
            zoom:200%;
            width:100%; 
            height:100%;
        }*/
    }
</style>
<?php
$province_name = '';
$warehouse_name = '';
if(isset($rsRow22))
{
    $rsRow2 = $rsRow22;
//  echo '<pre>';print_r($rsRow2);
    $province_name = $rsRow2[0]['province_name'];
    $warehouse_name = $rsRow2[0]['warehouse_name'];
}

//print_r($stock_master_records);exit;
if (isset($stock_master_records)) {


    $row = $stock_master_records[0];
        $refernce_number = $row['tran_ref'];
//    $temp_row = $temp_records->result_array();
//    $temp_row = $temp_records[0];
//    $row_temp = $temp_row[0];
//    $issue_to = $row_temp['issuance_to'];
//    $center_name = $row_temp['warehouse_name'];
//    $patient_name = $row_temp['full_name'] . "-" . $row_temp['nic_no'];
//    print_r($patient_name);exit;
} 
else if(isset($tran_reference_number)){
    $refernce_number=$tran_reference_number;
//    $temp_row = $temp_records->result_array();
    $temp_row = $temp_records[0];
//    print_r($temp_records->result_array());exit;
//    $row_temp = $temp_row[0];
//    $issue_to = $row_temp['issuance_to'];
//    $center_name = $row_temp['warehouse_name'];
//    $patient_name = $row_temp['full_name'] . "-" . $row_temp['nic_no'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <!--<h3>Consumption Form</h3>-->

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">     
                        <?php
//                           if ($src_count > 0) {
//                               $src_count += 1;
//                               $rowcolspan = "colspan=$src_count";
//                           } else {
//                               $rowcolspan = "rowspan=2";
//                               Add by self
                               $rowcolspan = "colspan=2";
//                           }
                        ?>       
                        
                        <h4>
                        <?php
                            $monthName = '';
                            if(isset($form ['month']))
                            {
                                $monthNum  = $form ['month'];
                                $dateObj   = DateTime::createFromFormat('!m', $monthNum);
                                $monthName = $dateObj->format('F');
                            }
                            foreach ($warehouse as $row) {

                                if(isset($form['warehouse']) && $form['warehouse'] == $row['wh_id']) {
                                    echo $row['wh_name'] . '  ' . $monthName .'  '. $form['year'];
                                }
                            }
                        ?>
                        </h4>
                        
<!--            <br>
            <i id="btnExport" onclick="fnExcelReport();" class="fa fa-file-excel-o" style="font-size:32px;color:#33B23F;float: right;"></i>
            <br>-->
            
<!--            <div style="float:right; margin-top:5px;">
                    <button id="btnExport" type="button" class="btn btn-warning sprintbuttonstyle" onclick="fnExcelReport();"> Excel </button>
            </div>-->
                <a id="dlink" style="display:none;"></a>
                <input id="excelprintButt" style="float:right; margin-top:5px;" type="button" onclick="tablesToExcel(array1, 'Sheet1', 'myfile.xls')" class="sprintbuttonstyle" value="Export to Excel">
                        
                <form name="frmF7" id="frmF7" method="post">     
                    <div class="row">
                        <div class="col-12">
                            <div class="card m-b-30">
                                <div class="card-body">
                    
                        <div class="row">
                            <div class="col-md-12">
                                <div id="errMsg"></div>
                                <table id="export_table_to_excel_1" class="table-condensed alltable" cellpadding="3">
                                    <tr>
                                        <th colspan="14">Monthly ARVs Status and Request Performa</th>
                                    </tr>
                                    <tr>
                                        <th colspan="2">Document No</th>
                                        <td colspan="2" style="text-align:center;"><?php echo ''; ?></th>
                                        <th colspan="2">Version</th>
                                        <td colspan="2" style="background:lightgray;text-align:center;">1</th>
                                        <th colspan="2">Issue Date</th>
                                        <td colspan="4" style="text-align:center;"><?php echo date("Y-m-d"); ?></th>
                                    </tr>
                                    <tr>
                                        <th colspan="2">Date of Request</th>
                                        <td colspan="2" style="text-align:center;"><?php echo date("Y-m-d"); ?></th>
                                        <th colspan="2">Province</th>
                                        <td colspan="2" style="text-align:center;"><?php echo $province_name; ?></th>
                                        <th colspan="2">Reporting Month</th>
                                        <td colspan="4" style="text-align:center;">
                                            <?php 
                                                $monthNums  = $_REQUEST['month'];
                                                $monthNames = date('F', mktime(0, 0, 0, $monthNums, 10)); // March
                                                echo $monthNames;
                                            ?>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th colspan="2">Name of Center</th>
                                        <td colspan="4" style="text-align:center;"><?php echo $warehouse_name; ?></th>
                                        <th colspan="2">Demand For the Period</th>
                                        <td colspan="6" style="text-align:center;"></th>
                                    </tr>
                                    <tr>
                                        <th colspan="4">List of Health Products</th>
                                        <th colspan="9"></th>
                                        <th colspan="1" rowspan="2">(J) Proposed required quantity (No. of Packs)</th>
                                    </tr>
                                    <tr>
                                        <th rowspan="2" class="text-center">S.No.</th>
                                        <th rowspan="2" class="text-center">Article</th>
                                        <th rowspan="2" class="text-center">Strength</th>
                                        <th rowspan="2" class="text-center">Pack Size</th>
                                        <th rowspan="2" class="text-center">No. of Patients on this ARV (Mandatory)<br>(A)</th>
                                        <th rowspan="2" class="text-center">Stock On hand at center at begining of reporting period <br>(B)</th>
                                        <th rowspan="2" <?php // echo $rowcolspan; ?> class="text-center">Stock Received during reporting period<br>(C)</th>
                                        
                                        
                                        <th rowspan="2" class="text-center">Total Stock during current Period<br>(D) = (B+C)</th>
                                        
                                        
                                        
                                        <th rowspan="2" class="text-center">Quantity consumed during period<br>(E)</th>
                                        <th colspan="2" class="text-center">Quantity Adjusted during during period (Expired, Damaged or any quantity transferred  etc.)<br>(F)</th>
                                        <th rowspan="2" class="text-center">Viable Stock on hand at the end of reporting period <br>G= (D-E-F)</th>
                                        <!--<th colspan="2" class="text-center">Cases/Clients</th>-->
                                        <?php
//                                        if ($hfTypeId == 4 || $hfTypeId == 5) {
                                        ?>
                                        <!--<th rowspan="2" class="text-center">Removals</th>-->
                                        <th rowspan="2" class="text-center">Monthly Demand</th>
                                        
                                        
                                        
                                        
                                        
                                        <?php // } ?>
                                    </tr>
                                    <tr>
                                        <?php // foreach ($sources as $rowsrc) { ?>
                                        <!--<th class="text-center"><?php if(isset($rowsrc)) { echo $rowsrc;} ?></th>-->
                                        
                                        <!--Adding new by self--> 
                                        <!--<th class="text-center">From District</th>-->
                                        
                                        <?php // } if ($src_count > 0) { ?>
                                            <!--<th class="text-center">Total</th>-->
                                        <?php // } ?>
                                        <th class="text-center">(+)</th>
                                        <th class="text-center">(-)</th>
<!--                                        <th class="text-center">New</th>
                                        <th class="text-center">Old</th>-->
                                        <th rowspan="1" colspan="1" class="text-center">Quarterly Demand</th>
                                    </tr>
                                    <?php
//                                    foreach ($user_list as $row) {
                                    //query 
                                    //gets
                                    //all from itminfo_tab
//                                    $q1 = "SELECT * FROM `itminfo_tab` WHERE `itm_status`=1 AND `itm_id` IN (SELECT `Stk_item` FROM `stakeholder_item` WHERE `stkid` =$stkid) ORDER BY `frmindex`";
//                                    $rsTemp1 = mysql_query($q1);

                                    $SlNo = 1;
                                    $fldIndex = 0;
                                    $loopno = 0;
                                    //loop
                                    if(isset($rsRow11))
                                    {
                                        foreach ($rsRow11 as $rsRow1) {
                                            
//                                      while ($rsRow1 = $rsRow11->result_array()) {
                                        if ((isset($hfTypeId) && $hfTypeId == 1) && (isset($result_province['prov_id']) && $result_province['prov_id'] == 1)) {
                                            if (in_array($rsRow1['itm_id'], array(8, 13, 30, 34,81)))
                                                continue;
                                        }
					
                                        if((isset($result_province['prov_id']) && !($result_province['prov_id'] == 2 || $result_province['prov_id'] == 3))){
                                            if (in_array($rsRow1['itm_id'], array(34)))
                                                continue;
                                        }
//                                        $item_char = $rsRow1['itm_id'];
//                                        $qry_cf = "SELECT REPUpdateCarryForwardHF('$RptDate','$item_char', $wh_id) FROM DUAL";
//                                        mysql_query($qry_cf);
                                        //$SlNo = ((strlen($SlNo) < 2) ? $SlNo : $SlNo);
                                        //query
                                        //gets
                                        //all from tbl_hf_data
//                                        $qry = "SELECT * FROM tbl_hf_data WHERE `warehouse_id`='" . $wh_id . "' AND reporting_date='" . $PrevMonthDate . "' AND `item_id`='$rsRow1[itm_id]'";
                                        //result
                                        //echo $qry;exit;
//                                        $rsTemp3 = mysql_query($qry);
                                        
                                        //Check this again ;
                                        $rsRow2 = array();
                                        
                                        $add_date = '';
                                        $hf_data_id = '';
                                        if(isset($rsRow22))
                                        {
                                            foreach($rsRow22 as $arr){
                                                $rsRow2[$arr['item_id']] = $arr;
      //                                          echo '<pre>';print_r($result);
                                            }
//                                            $rsRow2[$rsRow1['itm_id']] = $rsRow22;
//                                            echo '<pre>';print_r($rsRow2);
//                                            echo '<pre>';print_r($rsRow2[$rsRow1['itm_id']]['closing_balance']);
                                            //add date
                                            if(isset($rsRow2[$rsRow1['itm_id']]))
                                            {
                                                $add_date = $rsRow2[$rsRow1['itm_id']]['created_date'];
//                                              $ob_a = $rsRow2['closing_balance'];
                                                ///// Code for Receive column bifurcation
                                                $hf_data_id = $rsRow2[$rsRow1['itm_id']]['pk_id'];
                                            }
                                        }
                                        
//                                        $qryd = "SELECT
//	stock_sources_data.stock_sources_id,
//	stock_sources_data.received,
//	tbl_hf_data.item_id
//FROM
//	stock_sources_data
//INNER JOIN tbl_hf_data ON stock_sources_data.hf_data_id = tbl_hf_data.pk_id
//WHERE
//	stock_sources_data.hf_data_id = '$hf_data_id'";
//                                        //echo $qryd;
//                                        //result
//                                        $rsTemp4 = mysql_query($qryd);
//                                        $sources_data = array();
//                                        while ($rsRow4 = mysql_fetch_array($rsTemp4)) {
//                                            $sources_data[$rsRow4['stock_sources_id']][$rsRow4['item_id']] = $rsRow4['received'];
//                                        }

//                                        $qry4 = "SELECT
//                                                        stock_batch.wh_id,
//                                                        stock_batch.batch_id,
//                                                        stock_batch.batch_no,
//                                                        stock_batch.`status`,
//                                                        Sum(tbl_stock_detail.Qty) as Qty,
//                                                        tbl_stock_detail.IsReceived,
//                                                        tbl_stock_master.TranDate,
//                                                        stock_batch.item_id
//                                                    FROM
//                                                    stock_batch
//                                                    INNER JOIN tbl_stock_detail ON tbl_stock_detail.BatchID = stock_batch.batch_id
//                                                    INNER JOIN tbl_stock_master ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
//                                                    WHERE
//                                                        stock_batch.wh_id = $wh_id AND
//                                                        tbl_stock_detail.IsReceived = 1 AND
//                                                          DATE_FORMAT(tbl_stock_master.TranDate,'%Y-%m') = '$yy-$mm'
//                                                    GROUP BY
//                                                            stock_batch.item_id
//                                                    ";
                                        //result
                                        //echo $qry4;exit;
//                                        $rsTemp4 = mysql_query($qry4);
                                        $rcvd_array = array();
                                        if(isset($rsRow44))
                                        {
                                            foreach ($rsRow44 as $rsRow4) {
                                                $rcvd_array[$rsRow4['item_id']] = $rsRow4['Qty'];
                                            }
                                        }
                                        ///// End of Code for Receive column bifurcation
                                        // if new report
                                         
                                        //Add by self
                                        $isNewRpt = 1;
                                        
                                        if ($isNewRpt == 1) {

                                            //check itm_category
//                                            if ($rsRow1['itm_category'] == 1) {
                                                //wh_issue_up
                                                $wh_issue_up = 0;
                                                //wh_adja
                                                $wh_adja = 0;
                                                //wh_adjb
                                                $wh_adjb = 0;
                                                //wh_received
                                                $wh_received = ((!empty($rcvd_array[$rsRow1['itm_id']])) ? $rcvd_array[$rsRow1['itm_id']] : '0');
                                                //ob_a
                                                if(!empty($rsRow2[$rsRow1['itm_id']]['closing_balance']))
                                                {
                                                    $ob_a = $rsRow2[$rsRow1['itm_id']]['closing_balance'];
                                                    $cb_a = $wh_received + $rsRow2[$rsRow1['itm_id']]['closing_balance'];
                                                }
                                                else{
                                                    $ob_a = '';
                                                    $cb_a = '';
                                                }
                                                
                                                //For Print
                                                
                                                $received = '';
                                                $issued = '';
                                                $adj_pos = '';
                                                $adj_neg = '';
                                                $cases_old = '';
                                                $cases_new = '';
                                                $removal_qty = '';
                                                $next_month_req = '';
                                                $strength = '';
                                                $pack_size = '';
                                                $arv_patients = '';
                                                $total_stock_dcurperiod = '';
                                                $quarterly_demand = '';
                                                
                                                if(!empty($rsRow2) && isset($rsRow2[$rsRow1['itm_id']]))
                                                {
                                                    $received = $rsRow2[$rsRow1['itm_id']]['received_balance'];
                                                    $issued = $rsRow2[$rsRow1['itm_id']]['issue_balance'];
                                                    $adj_pos = $rsRow2[$rsRow1['itm_id']]['adjustment_positive'];
                                                    $adj_neg = $rsRow2[$rsRow1['itm_id']]['adjustment_negative'];
                                                    $cases_old = $rsRow2[$rsRow1['itm_id']]['old'];
                                                    $cases_new = $rsRow2[$rsRow1['itm_id']]['new'];
                                                    $removal_qty = $rsRow2[$rsRow1['itm_id']]['removals'];
                                                    $next_month_req = $rsRow2[$rsRow1['itm_id']]['demand'];
                                                    $strength = $rsRow2[$rsRow1['itm_id']]['strength'];
                                                    $pack_size = $rsRow2[$rsRow1['itm_id']]['pack_size'];
                                                    $arv_patients = $rsRow2[$rsRow1['itm_id']]['arv_patients'];
                                                    $total_stock_dcurperiod = $rsRow2[$rsRow1['itm_id']]['total_stock_dcurperiod'];
                                                    $quarterly_demand = $rsRow2[$rsRow1['itm_id']]['quarterly_demand'];
                                                }
                                                //cb_a
                                                
                                                $new = 0;
                                                $old = 0;
                                                $removals = 0;
                                                $drop_outs = 0;
                                                $demand = 0;
                                                $retrieved = 0;
                                                $change_pos = 0;
                                                $change_neg = 0;
                                                ?>
                                                <tr>
                                                    <td class="text-center"><?php echo $SlNo++; ?></td>
                                                    <td>
                                                        <?php echo $rsRow1['itm_name']; ?>
                                                        <input type="hidden" name="flitmrec_id[]" value="<?php echo $rsRow1['itm_id']; ?>">
                                                        <input type="hidden" name="flitm_category[]" value="<?php echo $rsRow1['itm_category']; ?>">
                                                        <input type="hidden" name="flitmname<?php echo $rsRow1['itm_id']; ?>" value="<?php echo $rsRow1['itm_name']; ?>">
                                                    </td>
                                                    <td><?php echo $strength; ?></td>
                                                    <td><?php echo $pack_size; ?></td>
                                                    <td><?php echo $arv_patients; ?></td>
                                                    <td><?php echo $ob_a; ?></td>
                                                    <!--<td><input class="form-control input-sm text-right" <?php echo (!empty($openOB)) ? 'readonly="readonly"' : ''; ?> autocomplete="off"  type="text" name="FLDOBLA[<?php echo $rsRow1['itm_id']; ?>]" id="FLDOBLA<?php echo $rsRow1['itm_id']; ?>" size="8" maxlength="10" value="<?php echo $ob_a; ?>" onKeyUp="cal_balance('<?php echo $rsRow1['itm_id']; ?>');"></td>-->
                                                        
                                                   
                                                    
                                                    
                                                    
                                                    <!--<td><input class="form-control input-sm text-right" autocomplete="off" type="text" name="Receivedfrom[<?php echo $rsRow1['itm_id']; ?>]" id="Receivedfrom<?php echo $rsRow1['itm_id']; ?>" size="8" maxlength="10"  value="<?php echo $demand; ?>"></td>-->
                                                    
                                                    
                                                    
                                                        
                                                        
                                                        
                                                   <?php
                                                    if(isset($sources))
                                                    {
                                                    foreach ($sources as $key => $rowsrc) {
                                                        $sdf = 0;
                                                        ?>
                                                        <td><input style="border:none;outline-width: 0;" readonly class="form-control input-sm text-right FLDSrcs<?php echo $rsRow1['itm_id']; ?>" <?php
                                                            if ($key == 130 || $key == 216) {
                                                                echo $isReadOnly . $style;
                                                                $sdf = $wh_received;
                                                            }
                                                            ?> autocomplete="off"  type="text" name="FLDSrcs[<?php echo $rsRow1['itm_id']; ?>][<?php echo $key; ?>]" id="<?php echo $rowsrc . $rsRow1['itm_id']; ?>" size="8" maxlength="10"  value="<?php echo $sdf; ?>" onKeyUp="cal_balance('<?php echo $rsRow1['itm_id']; ?>');"></td>
                                                        <?php 
                                                            }
                                                    }
                                                         $removal_readonly=true;
                                                        if($rsRow1['method_type']=='IUD' || $rsRow1['method_type']=='Implant') {
                                                            $removal_readonly = false;
                                                        }
                                                        ?>
                                                    <td><?php echo $received; ?></td>
                                                    <td style="background: #FFFBA3;"><?php echo $total_stock_dcurperiod; ?></td>
                                                    <td><?php echo $issued; ?></td>
                                                    <td><?php echo $adj_pos; ?></td>
                                                    <td><?php echo $adj_neg; ?></td>
                                                    <td style="background: #FFFBA3;"><?php echo $cb_a; ?></td>
<!--                                                    <td><input class="form-control input-sm text-right" autocomplete="off" type="text" name="FLDnew[<?php echo $rsRow1['itm_id']; ?>]" id="FLDnew<?php echo $rsRow1['itm_id']; ?>" size="8" maxlength="10"  value="<?php echo $cases_new; ?>"></td>
                                                    <td><input class="form-control input-sm text-right" autocomplete="off" type="text" name="FLDold[<?php echo $rsRow1['itm_id']; ?>]" id="FLDold<?php echo $rsRow1['itm_id']; ?>" size="8" maxlength="10"  value="<?php echo $cases_old; ?>"></td>-->
                                                    <?php
//                                                    if ( isset($hfTypeId))
//                                                    {
//                                                        if ( $hfTypeId == 4 || $hfTypeId == 5) {
                                                        ?>
                                                        <!--<td><input class="form-control input-sm text-right" autocomplete="off" type="text" name="Removals[<?php echo $rsRow1['itm_id']; ?>]" id="Removals<?php echo $rsRow1['itm_id']; ?>" size="8" maxlength="10"  value="<?php echo $removal_qty; ?>" <?=(($removal_readonly)?' readonly ':'')?>></td>-->
                                                        <td><?php echo $next_month_req; ?></td>
                                                        <?php 
//                                                            }
//                                                    }
                                                    ?>
                                                    <td><?php echo $quarterly_demand; ?></td>
                                                </tr>
                                                <?php
//                                            } else if ($rsRow1['itm_category'] == 2) {
//                                                $surgeyArr[$rsRow1['itm_id']]['pk_id'] = $rsRow2[$rsRow1['itm_id']]['pk_id'];
//                                                $surgeyArr[$rsRow1['itm_id']]['name'] = $rsRow1['itm_name'];
//                                                $surgeyArr[$rsRow1['itm_id']]['category'] = $rsRow1['itm_category'];
//                                                $surgeyArr[$rsRow1['itm_id']]['cases'] = $wh_issue_up;
//                                            }
                                            
                                            
                                            
                                        }
                                        else {
                                            //edit mode

                                            //check itm_category
                                            if ($rsRow1['itm_category'] == 1) {
                                                ?>
                                                <tr>
                                                    <td class="text-center"><?php echo $SlNo++; ?></td>
                                                    <td>
                                                        <?php echo $rsRow1['itm_name']; ?>
                                                        <input type="hidden" name="flitmrec_id[]" value="<?php echo $rsRow1['itm_id']; ?>">
                                                        <input type="hidden" name="flitm_category[]" value="<?php echo $rsRow1['itm_category']; ?>">
                                                        <input type="hidden" name="flitmname<?php echo $rsRow1['itm_id']; ?>" value="<?php echo $rsRow1['itm_name']; ?>">
                                                    </td>
                                                    <td><input class="form-control input-sm text-right" <?php echo (!empty($openOB)) ? 'readonly="readonly"' : ''; ?> autocomplete="off"  type="text" name="FLDOBLA<?php echo $rsRow1['itm_id']; ?>" id="FLDOBLA<?php echo $rsRow1['itm_id']; ?>" size="8" maxlength="10" value="<?php echo $rsRow2[$rsRow1['itm_id']]['opening_balance']; ?>" onKeyUp="cal_balance('<?php echo $rsRow1['itm_id']; ?>');"></td>
                                                    <?php
                                                    if(isset($sources))
                                                    {
                                                    foreach ($sources as $key => $rowsrc) {
                                                        $this_value = (!empty($sources_data[$key][$rsRow1['itm_id']]) ? $sources_data[$key][$rsRow1['itm_id']] : '0');
                                                        ?>
                                                        <td><input class="form-control input-sm text-right FLDSrcs<?php echo $rsRow1['itm_id']; ?>" <?php
                                                            if ($key == 130 || $key == 216) {
                                                                echo $isReadOnly . $style;
                                                                if($readonly_for_im){
                                                                    $this_value = ((!empty($rcvd_array[$rsRow1['itm_id']])) ? $rcvd_array[$rsRow1['itm_id']] : '0');
                                                                    $rsRow2[$rsRow1['itm_id']]['received_balance'] = $this_value;
                                                                } 
                                                            }
                                                            ?> autocomplete="off"  type="text" name="FLDSrcs<?php echo $rsRow1['itm_id']; ?>[<?php echo $key; ?>]" id="<?php echo $rowsrc . $rsRow1['itm_id']; ?>" size="8" maxlength="10"  value="<?php echo $this_value; ?>" onKeyUp="cal_balance('<?php echo $rsRow1['itm_id']; ?>');"></td>
                                                    <?php } 
                                                    }
                                                    $removal_readonly=true;
                                                    if($rsRow1['method_type']=='IUD' || $rsRow1['method_type']=='Implant') {
                                                        $removal_readonly = false;
                                                    }    
                                                        ?>
                                                        <td><input class="form-control input-sm text-right" <?= ((isset($src_count) && $src_count > 0 || isset($readonly_for_im) && $readonly_for_im) ? 'readonly' : '') ?> autocomplete="off"  type="text" name="FLDRecv<?php echo $rsRow1['itm_id']; ?>" id="FLDRecv<?php echo $rsRow1['itm_id']; ?>" size="8" maxlength="10"  value="<?php echo $rsRow2[$rsRow1['itm_id']]['received_balance']; ?>" onKeyUp="cal_balance('<?php echo $rsRow1['itm_id']; ?>');" <?= $isReadOnly ?> ></td>
                                                    <td><input class="form-control input-sm text-right" autocomplete="off" name="FLDIsuueUP<?php echo $rsRow1['itm_id']; ?>" id="FLDIsuueUP<?php echo $rsRow1['itm_id']; ?>" value="<?php echo $rsRow2[$rsRow1['itm_id']]['issue_balance']; ?>" type="text" size="8" maxlength="10" onKeyUp="cal_balance('<?php echo $rsRow1['itm_id']; ?>');"></td>
                                                    <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" name="FLDReturnTo<?php echo $rsRow1['itm_id']; ?>" id="FLDReturnTo<?php echo $rsRow1['itm_id']; ?>" size="8" maxlength="10" value="<?php echo $rsRow2[$rsRow1['itm_id']]['adjustment_positive']; ?>" onKeyUp="cal_balance('<?php echo $rsRow1['itm_id']; ?>');"></td>
                                                    <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" name="FLDUnusable<?php echo $rsRow1['itm_id']; ?>" id="FLDUnusable<?php echo $rsRow1['itm_id']; ?>" size="8" maxlength="10" value="<?php echo $rsRow2[$rsRow1['itm_id']]['adjustment_negative']; ?>" onKeyUp="cal_balance('<?php echo $rsRow1['itm_id']; ?>');"></td>
                                                    <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" name="FLDCBLA<?php echo $rsRow1['itm_id']; ?>" id="FLDCBLA<?php echo $rsRow1['itm_id']; ?>" size="8" maxlength="10" value="<?php echo $rsRow2[$rsRow1['itm_id']]['closing_balance']; ?>" readonly></td>
                                                    <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" name="FLDnew<?php echo $rsRow1['itm_id']; ?>" id="FLDnew<?php echo $rsRow1['itm_id']; ?>" size="8" maxlength="10"  value="<?php echo $rsRow2[$rsRow1['itm_id']]['new']; ?>"></td>
                                                    <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" name="FLDold<?php echo $rsRow1['itm_id']; ?>" id="FLDold<?php echo $rsRow1['itm_id']; ?>" size="8" maxlength="10"  value="<?php echo $rsRow2[$rsRow1['itm_id']]['old']; ?>"></td>
                                                    <?php
                                                    if ($hfTypeId == 4 || $hfTypeId == 5) {
                                                    ?>
                                                    <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" name="Removals<?php echo $rsRow1['itm_id']; ?>" id="Removals<?php echo $rsRow1['itm_id']; ?>" size="8" maxlength="10"  value="<?php echo $rsRow2[$rsRow1['itm_id']]['removals']; ?>" <?=(($removal_readonly)?' readonly ':'')?>></td>
                                                    <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" name="Demand[<?php echo $rsRow1['itm_id']; ?>]" id="Demand<?php echo $rsRow1['itm_id']; ?>" size="8" maxlength="10"  value="<?php echo $rsRow2[$rsRow1['itm_id']]['demand']; ?>"></td>
                                                    <?php
                                                    }
                                                    ?>
                                                </tr>
                                                <?php
                                            } else if ($rsRow1['itm_category'] == 2) {
                                                //pk_id
                                                $surgeyArr[$rsRow1['itm_id']]['pk_id'] = $rsRow2[$rsRow1['itm_id']]['pk_id'];
                                                //name
                                                $surgeyArr[$rsRow1['itm_id']]['name'] = $rsRow1['itm_name'];
                                                //category
                                                $surgeyArr[$rsRow1['itm_id']]['category'] = $rsRow1['itm_category'];
                                                //cases
                                                $surgeyArr[$rsRow1['itm_id']]['cases'] = $rsRow2[$rsRow1['itm_id']]['issue_balance'];
                                            }
                                        }
                                        //$SlNo++;
                                        $fldIndex = $fldIndex + 13;
                                        $loopno++;
                                    }
                                    }
                                    //echo '<pre>';print_r($surgeyArr);exit;
                                    //free result
//                                    mysql_free_result($rsTemp1);
                                    ?>
                                </table>
                            </div>
                        </div>
<!--                        <div class="form-group row"> 
                                <div class="col-md-10 text-right" style="padding-top: 10px">
                                    <div id="eMsg" style="color:#060;"></div>
                                </div>
                                <div class="col-md-2">
                                    <button class="btn btn-primary" id="saveBtn" name="saveBtn" type="button" onClick="return formvalidate1()"> Save </button>
                                    <button class="btn btn-primary" id="saveBtn" name="saveBtn" value="Save" type="submit" onclick="window.open('print_consumption_form?id=<?php echo 1; ?>&issue=1', '_blank', 'scrollbars=1,width=842,height=595');" > Save </button>
                                    <button class="btn btn-info" type="submit" onClick="document.frmF7.reset()"> Reset </button>
                                    <button class="btn btn-primary" id="saveBtn" name="saveBtn" value="Save" type="submit" >
                                        <a style="text-decoration: underline;" onclick="window.open('printIssue?id=<?php echo $row['fk_stock_id']; ?>&issue=1', '_blank', 'scrollbars=1,width=842,height=595');" href="javascript:void(0);"><?php echo $row['tran_no']; ?></a><br>
                                    </button>
                                </div>
                        </div>-->

                        <input type="hidden" name="ActionType" value="Add">
<!--                        <input type="hidden" name="RptDate" value="<?php echo $RptDate; ?>">-->
                        <input type="hidden" name="wh_id" value="<?php if(isset($form['warehouse'])) { echo $form['warehouse'];} ?>">
                        <input type="hidden" name="yy" value="<?php if(isset($form['year'])) { echo $form['year'];} ?>">
                        <input type="hidden" name="mm" value="<?php if(isset($form['month'])) { echo $form['month'];} ?>">
                        <!--
                        <input type="hidden" name="isNewRpt" id="isNewRpt" value="<?php echo $isNewRpt; ?>" />
                        <input type="hidden" name="add_date" id="add_date" value="<?php echo $add_date; ?>" />-->
                        </div>
                    </div>
                </div>
            </div>

        </form>
                        
                        <div style="width:100%; clear:both; margin-top:50px;">
                            <table id="export_table_to_excel_2" class="alltable" cellpadding="5" style="width: 50%;float:left; border:2px solid #E5E5E5 !important; border-collapse:collapse;">
                                <tr>
                                    <td colspan="2">
                                        <b>Note:</b>
                                    </td>
                                </tr>
                                <tr style="font-size:12px;">
                                    <td colspan="2"> 1) Please must mention total No. of PLHIVs against each FDC or single dose ARV.</td>
                                </tr>
                                <tr style="font-size:12px;">
                                    <td colspan="2"> 2) Please ensure physical check before filling this template.</td>
                                </tr>
                                <tr style="font-size:12px;">
                                    <td colspan="2"> 3) Retain a hard copy of this report at Center.</td>
                                </tr>
                            </table>
                        </div>
                        <br>
                        <div style="width:100%; clear:both; margin-top:20px;">
                            <table id="export_table_to_excel_3" class="alltable" cellpadding="5" style="width: 50%;float:left; border:2px solid #E5E5E5 !important; border-collapse:collapse;">
                                <tr>
                                    <td colspan="2"><b>Prepared By</b>
                                        <hr> Signature: ___________________________________________</td>
                                </tr>
                                <tr>
                                    <td colspan="2">Name: ______________________________________________</td>
                                </tr>
                                <tr>
                                    <td colspan="2">Designation: _________________________________________</td>
                                </tr>
                            </table>
                            <table id="export_table_to_excel_4" class="alltable" cellpadding="5" style="width: 50%;float:left; border:2px solid #E5E5E5 !important; border-collapse:collapse;">
                                <tr>
                                    <td colspan="2"><b>Approved By</b>
                                        <hr>Signature: ___________________________________________</td>
                                </tr>
                                <tr>
                                    <td colspan="2">Name: ______________________________________________</td>
                                </tr>
                                <tr>
                                    <td colspan="2">Designation: _________________________________________</td>
                                </tr>
                            </table>
                        </div>
                        
                        <div style="float:right; margin-top:20px;" id="printButt">
                                <button type="button" class="btn btn-warning sprintbuttonstyle" onclick="javascript:printCont();"> Print </button>
                        </div>
                        
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
    //table to excel (multiple table)
    var array1 = new Array();
    var n = 4; //Total table
    for ( var x=1; x<=n; x++ ) {
        array1[x-1] = 'export_table_to_excel_' + x;
    }
    var tablesToExcel = (function () {
        var uri = 'data:application/vnd.ms-excel;base64,'
            , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets>'
            , templateend = '</x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head>'
            , body = '<body>'
            , tablevar = '<table>{table'
            , tablevarend = '}</table>'
            , bodyend = '</body></html>'
            , worksheet = '<x:ExcelWorksheet><x:Name>'
            , worksheetend = '</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet>'
            , worksheetvar = '{worksheet'
            , worksheetvarend = '}'
            , base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
            , format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
            , wstemplate = ''
            , tabletemplate = '';

        return function (table, name, filename) {
            var tables = table;
            var wstemplate = '';
            var tabletemplate = '';

            wstemplate = worksheet + worksheetvar + '0' + worksheetvarend + worksheetend;
            for (var i = 0; i < tables.length; ++i) {
                tabletemplate += tablevar + i + tablevarend;
            }

            var allTemplate = template + wstemplate + templateend;
            var allWorksheet = body + tabletemplate + bodyend;
            var allOfIt = allTemplate + allWorksheet;

            var ctx = {};
            ctx['worksheet0'] = name;
            for (var k = 0; k < tables.length; ++k) {
                var exceltable;
                if (!tables[k].nodeType) exceltable = document.getElementById(tables[k]);
                ctx['table' + k] = exceltable.innerHTML;
            }

            document.getElementById("dlink").href = uri + base64(format(allOfIt, ctx));;
            document.getElementById("dlink").download = filename;
            document.getElementById("dlink").click();
        }
    })();
    
    
    
    
    
    
    
    function printCont()
    {
            window.print();
    }
    
//    function fnExcelReport()
//{
//    var tab_text="<table border='2px'><tr bgcolor='#33B23F'>";
//    var textRange; var j=0;
//    tab = document.getElementById('myTable'); // id of table
//
//    for(j = 0 ; j < tab.rows.length ; j++) 
//    {     
//        tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
//        //tab_text=tab_text+"</tr>";
//    }
//
//    tab_text=tab_text+"</table>";
//    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
//    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
//    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params
//
//    var ua = window.navigator.userAgent;
//    var msie = ua.indexOf("MSIE "); 
//
//    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
//    {
//        txtArea1.document.open("txt/html","replace");
//        txtArea1.document.write(tab_text);
//        txtArea1.document.close();
//        txtArea1.focus(); 
//        sa=txtArea1.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xls");
//    }  
//    else                 //other browser not tested on IE 11
//        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  
//
//    return (sa);
//}
    
</script>