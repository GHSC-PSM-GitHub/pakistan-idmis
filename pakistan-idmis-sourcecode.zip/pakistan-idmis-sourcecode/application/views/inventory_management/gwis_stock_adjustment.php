<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
}
    
</style>
<?php
$from_id = '';

if (isset($gwis_data)) {
    $row = $gwis_data[0];
//    print_r($row);exit;
    $date1 = str_replace('-', '/', $row['batch_expiry']);  
    $date2 = str_replace('-', '/', $row['production_date']);  
    $date3 = str_replace('-', '/', $row['dc_date']);
    $batch_expiry = date('m/d/Y', strtotime($date1));
    $production_date   = date('m/d/Y', strtotime($date2));
    $dc_date   = date('m/d/Y', strtotime($date3));
    $batch_no = $row['batch_no'];
//    $batch_expiry = $row['batch_expiry'];
    $item_id = $row['item_id'];
    $unit_price = $row['unit_price'];
//    $production_date = $row['production_date'];
    $vvm_type = $row['vvm_type'];
    $quantity = $row['quantity'];
    $dc_quantity = $row['dc_quantity'];
    $pi_quantity = $row['pi_quantity'];
    $ti_quantity = $row['ti_quantity'];
    $funding_source = $row['funding_source'];
    $pi_comment = $row['pi_comment'];
    $ti_comment = $row['ti_comment'];
    $delivery_challan_type = $row['delivery_challan_type'];
    $challan_type_detail = $row['challan_type_detail'];
    $dc_no = $row['dc_no'];
//    $dc_date = $row['dc_date'];
    $invoice = $row['invoice'];
    $po_quantity = $row['po_quantity'];
    $actual_rec_qty = $row['actual_rec_qty'];
    $vehicle_reg = $row['vehicle_reg'];
    $driver_contract = $row['driver_contract'];
    $driver_name = $row['driver_name'];
    $wh_id_from_supplier = $row['wh_id_from_supplier'];
    $currency = $row['currency'];
    $conversion_rate = $row['conversion_rate'];
    $wh_id_from = $row['wh_id_from'];
    $tran_ref = $row['tran_ref'];
    $fkstockid = $row['fk_stock_id'];
    $pkdetailid = $row['pk_id'];
    $batchid = $row['batch_id'];
//    $districts = $districts->result_object();
//    $tehsils = $tehsils->result_object();
//    $ucs = $ucs->result_object();
//    $str_arr = str_replace("-",",",$string);
//    $age = explode (",", $str_arr);
//    $diff = abs(strtotime(date("Y-m-d"))-strtotime($string));
//    $years = floor($diff / (365*60*60*24));
//    print_r($years);
//    $patient_month = $row['patient_month'];
//    $email = $row['email'];
//    $patient_id = $row['pk_id'];
//    print_r($age);
    
}
//print_r($tran_reference_number);exit;
if (isset($stock_master_records)) {
    $row = $stock_master_records[0];
    $refernce_number = $row['tran_ref'];
    $warehouse_from = $row['wh_id_from'];
    $warehouse_from_supplier = $row['wh_id_from_supplier'];
    
    //Check 
    $from_id = $row['wh_id_from'];
    $TranRef = $row['tran_ref'];
    
} else if (isset($tran_reference_number)) {

    $refernce_number = $tran_reference_number;
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="row">
                        <div class="col-md-12"><?php 
//                        if(isset($issueVoucher) && !empty($issueVoucher)) {
//                            echo 'Pending Vouchers are : ';
//                            echo implode(',', $issueVoucher);
//                            echo '<hr>';
//                        }
                        
//                        if(isset($getStockIssues) && !empty($getStockIssues)) {
                            
                            $issueVoucher = '';
                        $a='';
                           if ($getStockIssues) {

                               //fetch results
                               foreach ($getStockIssues AS $row)
                               {
                                   $a= " <a style='color:red;' href=\"gwis_stock_adjustment?issue_no=" . $row['tran_no'] . "&status_id=" . $row['status_id'] . "&pkid=" . $row['pk_id'] . "&search=true\">" . $row['tran_no'] . "</a>";
                                   $issueVoucher[ $row['tran_no']] = $a;
                               }

//                           }
                            
                                echo '<table style="font-family: arial;border:2px solid #1F8564; sans-serif;border-collapse: collapse;width:100%"><tr><th style="border: 2px solid #1F8564;text-align: left;padding: 8px;width:20%;font-size:16px;">Pending Vouchers are : </th><td  style="border: 1px solid #dddddd;text-align: left;padding: 8px;text-decoration: underline;">';
                                echo implode(',', $issueVoucher);
                                echo '</td></table><hr>';
                            }
                         ?></div>
                    </div>
                    
                    <br>
                    
                    <div class="heading-buttons">
                        <h3>GWIS Stock Adjustment</h3>

                    </div>
                    <div class="separator bottom"></div>
                    
                    <div class="innerLR">
                        
                        <form method="POST" name="gwis_adjustment_search" action="gwis_stock_adjustment" >
                            <!-- Row -->
                            <?php 
                            //get e
                            if(isset($_GET['e'])){?>
                            <span style="padding-left:15px; color:#F00;">Please select at least one product by clicking checkboxes at right</span>
                            <?php }?>
                            
<!--                            <div class="col-md-3">
                                <div class="control-group">
                                    <label class="example-text-input" for="hf" required >Quantity <span style="color: red">*</span></label>
                                    <div class="controls">
                                        <input type="number" name="quantity" id="quantity" class="form-control"   required >
                                    </div>
                                </div>
                            </div>-->
                            
                            <div class="form-group row ">
                                <!--<div class="col-md-12">-->
                                    <div class="col-md-3"> 
                                        <!-- Group Receive No-->
                                        <div class="control-group">
                                            <label for="issue_no"> Issue No </label>
                                            <div class="controls">
                                            <input class="form-control" tabindex="1" id="issue_no" value="<?php if(isset($issue_no)) echo $issue_no; ?>" name="issue_no" type="text" required />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="control-group">
                                        <div class="input-group input-medium" style="margin-top: 21px;">
                                            <div class="controls">
                                            <button type="submit" class="btn btn-primary" name="search" value="Search"> Search </button>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                <!--</div>-->
                            </div>
                    </form>
                        
                       <?php if(isset($stockReceive)) { ?> 
                        <form method="post" id="gwis_adjustment" name="gwis_adjustment" action="<?php echo base_url("inventory_management/gwis_stock_adjustment"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            
                                            
                                <table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable">
                                    
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:16px;"> Supplier Info</th>
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 
                                    
                                    <!-- Table body -->
                                    <tbody>
                                        <?php
                                        $i = 0;
                                        
                                            foreach ($stockReceive as $row) {
                                        if($i <= 0)
                                        {
                                                $stockID = $row['fk_stock_id'];
                                                $issuance_date = $row['tran_date'];
                                                ?>
                                        <tr>
                                            <?php if(empty($row['wh_from'])) { ?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">Supplier : </b>' .$row['wh_from_supplier'] . '<b style="font-weight: 900;margin-left: 30px;">Contact Person : </b>' .$row['contact_person'] .'<b style="font-weight: 900;margin-left: 30px;">Contact Number : </b>' .$row['contact_numbers']. '<b style="font-weight: 900;margin-left: 30px;">Contact Email :</b> ' .$row['contact_emails'] .
                                                 '<br><br><b style="font-weight: 900;">Contact Address : </b>' .$row['contact_address'];?>
                                            </td>
                                        </tr>
                                        <?php 
                                            } else{?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">Warehouse : </b>' .$row['wh_from']; 
                                                 ?>
                                            </td>
                                            <?php  }
                                            $i++;
                                            }
                                        }
                                            ?>
                                    </tbody>
                                </table>
                                            
                                            
                                <table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable">
                                    
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:16px;"> Driver Info</th>
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 
                                    
                                    <!-- Table body -->
                                    <tbody>
                                        <?php
                                        $i = 0;
                                        
                                            foreach ($stockReceive as $row) {
                                        if($i <= 0)
                                        {
                                                $stockID = $row['fk_stock_id'];
                                                $issuance_date = $row['tran_date'];
                                                ?>
                                        <tr>
                                            <?php if(empty($row['wh_from'])) { ?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">Driver Name : </b>' .$row['driver_name'] . '<b style="font-weight: 900;margin-left: 30px;">Driver Contract : </b>' .$row['driver_contract'] .'<b style="font-weight: 900;margin-left: 30px;">Vehicle Reg# : </b>' .$row['vehicle_reg'] ;?>
                                            </td>
                                        </tr>
                                        <?php 
                                            } else{?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">Warehouse : </b>' .$row['wh_from']; 
                                                 ?>
                                            </td>
                                            <?php  }
                                            $i++;
                                            }
                                        }
                                            ?>
                                    </tbody>
                                </table>            
                                      
                                <table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable">
                                    
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:16px;"> Other Info</th>
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 
                                    
                                    <!-- Table body -->
                                    <tbody>
                                        <?php
                                        $i = 0;
                                        
                                            foreach ($stockReceive as $row) {
                                        if($i <= 0)
                                        {
                                                $stockID = $row['fk_stock_id'];
                                                $issuance_date = $row['tran_date'];
                                                ?>
                                        <tr>
                                            <?php if(empty($row['wh_from'])) { ?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">DC Number : </b>' .$row['dc_no'] . '<b style="font-weight: 900;margin-left: 30px;">DC Date : </b>' .$row['dc_date'] .'<b style="font-weight: 900;margin-left: 30px;">Invoice : </b>' .$row['invoice']. 
                                                 '<b style="font-weight: 900;margin-left: 30px;">Challan Type : </b>' .$row['challan_type']. '<b style="font-weight: 900;margin-left: 30px;">Challan Type Detail : </b>' .$row['challan_type_detail'];?>
                                            </td>
                                        </tr>
                                        <?php 
                                            } else{?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">Warehouse : </b>' .$row['wh_from']; 
                                                 ?>
                                            </td>
                                            <?php  }
                                            $i++;
                                            }
                                        }
                                            ?>
                                    </tbody>
                                </table>            
                                     
                                            <br>
                                            
                                            <!-- Table -->
                                <table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable">
                                    
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th> Product </th>
                                           <?php 
                                           $sr = 0;
                                           foreach ($stockReceive as $row) {
                                               if($row['product_type'] == '36' && $sr == 0) {?>
                                            <th> Batch </th>
                                            <th> Mfg Date </th>
                                            <th> Exp Date </th>
                                            <th> Shelf Life </th>
                                          <?php $sr++;
                                               }
                                            } ?>
                                            <th> PO Quantity </th>
                                            <th> DC Quantity </th>
                                            <th> Actual Received<br> Quantity </th>
                                            <th> GWIS PI Quantity </th>
                                            <?php if(isset($_REQUEST['status_id']) && $_REQUEST['status_id'] == '2') {?>
                                            <th> Technical Inspection Quantity </th>
                                            <?php } ?>
                                            <th> Return Quantity</th>
                                            <th> Comment</th>
                                            <!--<th>Reason for Adjustment </th>-->
                                            <!--<th> Adjustment Type</th>-->
                                            <th style="width: 1%;"> <input type="checkbox" id="checkAll" /></th>
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 
                                    
                                    <!-- Table body -->
                                    <tbody>
                                        <!-- Table row -->
                                        <?php
                                            $i = 1;
                                            foreach ($stockReceive as $row) {?>
                                                <input type="hidden" id="pkdetailid" name='pkdetailid[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['pk_id']; ?>" />
                                                <input type="hidden" id="batchid" name='batchid[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['batch_id']; ?>" />
                                                <input type="hidden" id="tran_no" name='tran_no' value="<?php echo $row['tran_no']; ?>" />
                                                <input type="hidden" id="unit_price" name='unit_price[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['unit_price']; ?>" />
                                                <input type="hidden" id="currency" name='currency[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['currency']; ?>" />
                                                <input type="hidden" id="conversion_rate" name='conversion_rate[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['conversion_rate']; ?>" />
                                                <?php 
                                                $startDate = new DateTime($row['field3']);
                                                $endDate = new DateTime(date("Y-m-d",strtotime($row['tran_date'])));

                                                $difference = $endDate->diff($startDate);
                                                $days = $difference->format("%a");
//                                                $secs = $datetime2 - $datetime1;// == <seconds between the two times>
//                                                $days = $secs / 86400;
                                                
                                                $stockID = $row['fk_stock_id'];
                                                $issuance_date = $row['tran_date'];
                                                ?>
                                        <tr>
                                            <td  style="white-space: nowrap;"><?php echo $row['itm_name']; ?>
                                                <input type="hidden" id="<?php echo $i; ?>-qty" name='itm_id[<?php echo $row['itm_id']; ?>]' value="<?php echo $row['itm_name']; ?>" />    
                                            </td>
                                            
                                           <?php if($row['product_type'] == '36') {?>
                                            
                                            <td><?php echo $row['field1']; ?>
                                                <input type="hidden" id="<?php echo $i; ?>-batch_no" name='batch_no[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field1']; ?>" />
                                            </td>
                                            <td style="white-space: nowrap;"><?php echo $row['field2']; ?>
                                                <input type="hidden" id="<?php echo $i; ?>-batch_no" name='production_date[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field2']; ?>" />
                                            </td>
                                            <td style="white-space: nowrap;"><?php echo $row['field3']; ?>
                                                <input type="hidden" id="<?php echo $i; ?>-batch_no" name='batch_expiry[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field3']; ?>" />
                                            </td>
                                            <td style="white-space: nowrap;"><?php echo $days . ' Days'; ?></td>
                                            
                                           <?php } ?>
                                            
                                            <td class="right"><?php echo 0; ?></td>
                                            <td class="right"><?php echo number_format(abs($row['dc_quantity'])); ?>
                                                <input type="hidden" id="<?php echo $i; ?>-qty" name='dc_quantityy[<?php echo $row['pk_id']; ?>]' value="<?php echo abs($row['dc_quantity']); ?>" /></td>
                                            <td class="right actualqty"><?php echo number_format(abs($row['actual_rec_qty'])); ?>
                                                <input type="hidden" id="<?php echo $i; ?>-qty" name='actual_rec_qty[<?php echo $row['pk_id']; ?>]' value="<?php echo abs($row['actual_rec_qty']); ?>" /></td>
                                            
                                            <td class="right piqty"><?php echo number_format(abs($row['pi_quantity'])); ?>
                                                <input type="hidden" id="<?php echo $i; ?>-qty" name='pi_quantity[<?php echo $row['pk_id']; ?>]' value="<?php echo abs($row['pi_quantity']); ?>"  /></td>
                                            
                                            <?php if(isset($_REQUEST['status_id']) && $_REQUEST['status_id'] == '2') {?>
                                            <td class="right tiqty"><?php if(isset($_REQUEST['issue_no']) && $_REQUEST['status_id'] == '2') echo abs($row['ti_quantity']); ?>
                                                <input type="hidden" name="tiqty[<?php echo $row['pk_id']; ?>]" id="<?php echo $i; ?>-tiqty" value="<?php if(isset($_REQUEST['issue_no']) && $_REQUEST['status_id'] == '2') echo abs($row['ti_quantity']); ?>"  class="form-control input-sm input-small" /></td>
                                            <?php } ?>
                                            
                                            <?php if(isset($_REQUEST['status_id']) && $_REQUEST['status_id'] == '2') {?>
                                            <td class="col-md-3"  style="width:20%;"><input type="number" name="returntiqty[<?php echo $row['pk_id']; ?>]" id="<?php echo $i; ?>-returntiqty" value="" min="0" class="form-control input-sm input-small returntiqty" /></td>
                                            <?php } else if(isset($_REQUEST['status_id']) && $_REQUEST['status_id'] == '1') {?>
                                            <td class="col-md-3"  style="width:20%;"><input type="number" name="returnpiqty[<?php echo $row['pk_id']; ?>]" id="<?php echo $i; ?>-returnpiqty" value="" min="0" class="form-control input-sm input-small returnpiqty" /></td>
                                            <?php } ?>
                                            
                                            <td class="col-md-3"><textarea name="comment[<?php echo $row['pk_id']; ?>]" id="<?php echo $i; ?>-comment" value="<?php if(isset($_REQUEST['tranno'])) echo abs($row['ti_comment']); ?>" class="form-control input-sm input-small" ></textarea></td>
<!--                                            <td class="col-md-3">
                                                <select class="select2me input-medium " name="tran_type" id="tran_type" required style="width:100%;padding:10%;" >
                                                    <option value="">Select</option>
                                                    <?php
                                                    foreach ($trans as $trans_row) {
                                                        ?>
                                                        <option value="<?php echo $trans_row['trans_id'] ?>" ><?php echo $trans_row['trans_type'].' ('.$trans_row['trans_nature'].')'; ?></option>
                                                        <?php
                                                    }
                                                    ?>

                                                </select> 
                                            </td>-->
                                            
                                            
                                            <td class="center"><input type="checkbox" name="stockid[<?php echo $row['pk_id']; ?>]" value="<?php echo $row['pk_id']; ?>" /></td>
                                        </tr>
                                        <?php $i++;
                                            } ?>
                                        <!-- // Table row END -->
                                    </tbody>
                                    <!-- // Table body END -->
                                    
                                </table>
                                <!-- // Table END --> 
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            <div class="form-group row">
                                                <!--<div class="col-md-12">-->
                                                    <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="control-label" for="remarks"> Remarks </label>
                                                            <div class="controls">
                                                                <textarea name="remarks" id="remarks" class="form-control" ></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="control-label" for="rec_ref"> Receive Reference </label>
                                                            <div class="controls">
                                                                <input name="rec_ref" readonly id="rec_ref" type="text" class="form-control input-sm input-small" value="<?=$issue_no?>" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="control-label" for="rec_date"> Receive Date </label>
                                                            <div class="controls">
                                                                <input name="rec_date" id="rec_date"  class="form-control input-sm input-small" value="<?php echo date("d/m/Y"); ?>" type="text" readonly />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-md-3 right">
                                                        <div class="control-group">
                                                            <label class="control-label">&nbsp;</label>
                                                        </div>
                                                        <div class="controls">
                                                            <button type="submit" id="save" class="btn btn-success"> Save </button>
                                                            <input type="hidden" id="status_id" name='status_id' value="<?php if(isset($_REQUEST['status_id']) && !empty($_REQUEST['status_id'])) { echo $_REQUEST['status_id'];}else { echo '';} ?>"> 
                                                            <input type="hidden" name="stock_id" id="stock_id" value="<?php if(isset($stockID)) echo $stockID; ?>"/>
                                                            <!--<input type="hidden" name="issue_no" id="issue_no" value="<?php echo $issue_no ?>">-->
                                                            <input type="hidden" name="pkmasterid" id="pkmasterid" value="<?php if(isset($_REQUEST['fkstockid']) && !empty($_REQUEST['fkstockid'])) { echo $_REQUEST['fkstockid'];}else { echo '';} ?>"> 
                                                            <!--<input type="hidden" name="pkdetailid" id="pkdetailid" value="<?php if(isset($_REQUEST['pkdetailid']) && !empty($_REQUEST['pkdetailid'])) { echo $_REQUEST['pkdetailid'];}else { echo '';} ?>">-->
                                                            <!--<input type="hidden" name="batchid" id="batchid" value="<?php if(isset($_REQUEST['batchid']) && !empty($_REQUEST['batchid'])) { echo $_REQUEST['batchid'];}else { echo '';} ?>">--> 
                                                        </div>
                                                    </div>
                                                    
                                                <!--</div>-->
                                            </div>
                                
                                            <div class="form-group row">
<!--                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" > Add Receiving</button>
                                                </div>  -->
<?php if (isset($temp_records) && (!empty($temp_records))) {
    ?>
                                                    <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>">
                                                     
                                                <?php }
                                                ?>    
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                       <?php } else {
                           echo '<br>';
                           echo '<hr>';
                           echo '<h3>No Record Found</h3>';
                       }?>
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>