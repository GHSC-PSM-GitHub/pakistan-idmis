<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
}
    
</style>
<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>TAC Search</h3>
                         
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                     <div class="innerLR">
                         
                <form method="POST" name="dc_search" action="tac_search" >
                            <!-- Row -->
                  <div class="col-md-12">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <div class="form-group row ">
                                <!--<div class="col-md-12">-->
                                
                                    <div class="col-md-3">
                                        <div class="control-group">
                                            <label class="example-text-input" for="start_date"  >Date From(DD/MM/YYYY) <span style="color: red">*</span> </label>
                                            <div class="controls">
                                                <input type="text" class="form-control" name="start_date" id="start_date" required="" value="<?php if(isset($_REQUEST['start_date']) && !empty($_REQUEST['start_date'])) { echo $_REQUEST['start_date'];} else { echo date("d/m/Y");} ?>" >

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="control-group">
                                            <label class="example-text-input" for="end_date"  >Date To(DD/MM/YYYY) <span style="color: red">*</span> </label>
                                            <div class="controls">
                                                <input type="text" class="form-control" name="end_date" id="end_date" required=""  value="<?php if(isset($_REQUEST['end_date']) && !empty($_REQUEST['end_date'])) { echo $_REQUEST['end_date'];} else { echo date("d/m/Y");} ?>" >

                                            </div>
                                        </div>
                                    </div>
                                
                                    <div class="col-md-3" id="show_receive_from_suppliers" >
                                        <label class="example-text-input" for="suppliers"  >Received From (Supplier) </label>
                                        <div class="controls">
                                            <?php

//                                            if (empty($temp_records)) {

                                            ?>
                                            <select class="select2me input-medium"  name="receive_from_suppliers" id="receive_from_suppliers" style="width:100%;padding:10%;">
                                                <option value="">Select</option>
                                                <?php

                                                foreach ($suppliers as $row) {
                                                    ?>
                                                    <option value="<?php echo $row['wh_id'] ?>" <?php if (isset($_REQUEST['receive_from_suppliers']) && $_REQUEST['receive_from_suppliers'] == $row['wh_id']) echo "selected='selected'"; ?>><?php echo $row['wh_name'] ?></option>
                                                    <?php
                                                }
                                                ?>

                                            </select>  
                                            <?php
//                                            }else
//                                            {
//                                                foreach ($suppliers as $row) {
////                                                                if(isset($warehouse_from) && $warehouse_from == $row['stkid']) echo  '<input class="form-control" disabled value="'.$row['stkname'].'">';
//                                                    if(isset($warehouse_from_supplier) && $warehouse_from_supplier == $row['wh_id']) { echo  '<input class="form-control" disabled value="'.$row['wh_name'].'">';   } 
//                                                    else if (isset($gwis_supplier) && $gwis_supplier == $row['wh_id']){ echo '<input class="form-control" disabled value="'.$row['wh_name'].'">'; } 
//
//                                                }
//                                            }
                                            ?>
                                        </div>
                                    </div>
                                
                                    <div class="col-md-3">
                                        <div class="control-group">
                                        <div class="input-group input-medium" style="margin-top: 21px;">
                                            <div class="controls">
                                            <button type="submit" class="btn btn-primary" name="submit" value="Search"> Search </button>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                <!--</div>-->
                            </div>
                        </div>
                    </div>
                  </div>
            </form>
                         
                        <br>
                        <?php
                        if (isset($_REQUEST['submit']) && !empty($result)) {
                            ?>

                            <div id="divToPrint">
                                <table class="table table-striped table-bordered table-condensed dt-responsive nowrap" id="datatable-buttons">
                                    <thead>
                                        <tr>
                                            <th style="width: 1%;" class="center">No.</th>
                                            <th>Transaction Number</th>
                                            <th>Reference Number</th>
                                            <th>Created/Approved By</th>
                                            <!--<th>Receiving Date</th>-->
                                            <th>Supplier</th>
                                            <th>Warehouses</th>
                                            <th>Product Name</th>   
                                            <th>Batch#</th>
                                            <th>Mfg Date</th>
                                            <th>Exp. Date</th>
                                            <th>Serial No</th>
                                            <th>Warranty (years)</th>
                                            <th>Pack Size</th>
                                            <!--<th>Unit</th>-->
                                            <th>Temp From</th>
                                            <th>Temp to</th> 
                                            <th>Quantity</th> 
                                            <th>Active Process</th>
<!--                                            <th>Approve From</th>
                                            <th>Approve To</th>-->
                                            <!--<th>Created By</th>-->
                                            <!--<th>Action</th>--> 
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Table row -->
                                        <?php
                                        $count = 1; 
                                        foreach ($result->result_array() as $row) {
                                            ?>
                                            <tr>
                                                <td class="center"><?php echo $count; ?></td>
                                                <td>
                                                    <a style="text-decoration: underline;" onclick="window.open('print_tac?id=<?php echo $row['fk_stock_id']; ?>&tac=1', '_blank', 'scrollbars=1,width=842,height=595');" href="javascript:void(0);"><?php echo $row['tran_no']; ?></a><br>
                                                    <!--<a style="text-decoration: underline;" onclick="window.open('print_gwis?id=<?php echo $row['fk_stock_id']; ?>&gatepass=1', '_blank', 'scrollbars=1,width=842,height=595');" href="javascript:void(0);"><?php echo 'Gate Pass'; ?></a>-->
                                                </td>
                                                <!--<td class="important"><?php echo "DC-".sprintf('%04d', $row['fk_stock_id']); ?></td>-->
                                                <td class="important"><?php echo $row['tran_ref']; ?></td>
                                                <td class="important"><?php echo $row['username']; ?></td>
                                                <!--<td class="important"><?php echo $row['tran_date']; ?></td>-->
                                                <!--<td class="important"><?php if(isset($row['wh_from']) && !empty($row['wh_from'])) { echo $row['wh_from']; } else {echo $row['wh_from_supplier'];}?></td>-->
                                                <td class="important"><?php echo $row['wh_from_supplier'];?></td>
                                                <td class="important"><?php echo $row['wh_from'];?></td>
                                                <td><?php echo $row['product_name']; ?></td>  
                                                <td><?php echo $row['field1']; ?></td> 
                                                <td><?php echo $row['field2']; ?></td> 
                                                <td class="important"><?php echo $row['field3']; ?></td>
                                                <td><?php echo $row['field4']; ?></td> 
                                                <td><?php echo $row['field5']; ?></td> 
                                                <td><?php echo $row['field6']; ?></td> 
                                                <!--<td><?php echo $row['field7']; ?></td>--> 
                                                <td><?php echo $row['field8']; ?></td> 
                                                <td><?php echo $row['field9']; ?></td> 
<!--                                                <td class="important"><?php echo $row['field1']; ?></td>
                                                <td class="important"><?php echo $row['field4']; ?></td>
                                                <td class="important"><?php echo $row['manufacturer']; ?></td>
                                                <td class="important"><?php echo $row['field5']; ?></td>
                                                <td class="important"><?php echo $row['field6']; ?></td>
                                                <td class="important"><?php echo $row['batch_expiry']; ?></td> -->
                                                <td class="important"><?php echo $row['quantity']; ?></td> 
                                                <td class="important"><?php if($row['active_process'] == '1'){ ?>
                                                    <a class="btn btn-sm btn-light glyphicons bin" style="background-color:#1f8564;color: white;" ><i class="fas fa-check"></i> Active</a>
                                                <?php } else { ?>
                                                    <a class="btn btn-sm btn-light glyphicons bin" style="background-color:#FC3B3B;color: white;" ><i class="fas fa-times red"></i> Not Active</a>
                                                <?php } ?>
                                                </td> 
<!--                                                <td class="important"><?php echo $row['approve_from']; ?></td> 
                                                <td class="important"><?php echo $row['approve_to']; ?></td>-->
                                                <!--<td class="important"><?php echo $row['username']; ?></td>--> 
                                                <!--<td>-->
                                                    <?php // if($row['status_id'] == '1') { ?>
                                                     <!--<a class="btn btn-primary" href="<?php echo base_url("inventory_management/gwis_physical_inspection?pkdetailid=" . $row['pk_id']."&batchid=".$row['batch_id']."&fkstockid=".$row['fk_stock_id']) ?>">Edit</a>-->
                                                    <?php // } else if($row['status_id'] == '2') { ?>
                                                     <!--<a class="btn btn-primary" href="<?php echo base_url("inventory_management/gwis_technical_inspection?tranno=" . $row['tran_no']."&whidto=".$row['wh_id_to']."&pkdetailid=" . $row['pk_id']."&batchid=".$row['batch_id']."&fkstockid=".$row['fk_stock_id']) ?>">Edit</a>-->
                                                    <?php // } else if($row['status_id'] == '3') { ?>
<!--                                                     <button class="btn btn-danger btn-sm" type="button" id="">
                                                        <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Sub Document Submitted
                                                    </button>-->
                                                     <?php // } ?>
<!--                                                    <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row['pk_id']."_".$row['fk_stock_id']; ?>-deletedc">
                                                        <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Delete
                                                    </button>  -->
                                                <!--</td>-->
                                            </tr>
                                            <?php
                                            $count++;
                                        }
                                        ?>
                                        <!-- // Table row END -->
                                        <!-- Table row -->

                                        <!-- // Table row END -->
                                    </tbody>
                                </table> 
                            </div>

                            <!-- // Table END -->
                            <?php
                        } else {
                            echo "<hr><h5>No data found!</h5>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
