<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
}
    
</style>
<?php
$from_id = '';

if (isset($gwis_data)) {
    $row = $gwis_data[0];
//    print_r($row);exit;
    $date1 = str_replace('-', '/', $row['batch_expiry']);  
    $date2 = str_replace('-', '/', $row['production_date']);  
    $date3 = str_replace('-', '/', $row['dc_date']);
	$batch_no = $row['batch_no'];

	if($batch_no == 'NA' || $batch_no == 'N/A'){
		$batch_expiry = 'NA';
		$production_date = 'NA';
	} else {		
		$batch_expiry = date('m/d/Y', strtotime($date1));
		$production_date   = date('m/d/Y', strtotime($date2));
	}
    $dc_date   = date('m/d/Y', strtotime($date3));
    
//    $batch_expiry = $row['batch_expiry'];
    $item_id = $row['item_id'];
    $unit_price = $row['unit_price'];
//    $production_date = $row['production_date'];
    $vvm_type = $row['vvm_type'];
    $quantity = $row['quantity'];
    $dc_quantity = $row['dc_quantity'];
    $pi_quantity = $row['pi_quantity'];
    $ti_quantity = $row['ti_quantity'];
    $funding_source = $row['funding_source'];
    $pi_comment = $row['pi_comment'];
    $ti_comment = $row['ti_comment'];
    $delivery_challan_type = $row['delivery_challan_type'];
    $challan_type_detail = $row['challan_type_detail'];
    $dc_no = $row['dc_no'];
//    $dc_date = $row['dc_date'];
    $invoice = $row['invoice'];
    $po_quantity = $row['po_quantity'];
    $actual_rec_qty = $row['actual_rec_qty'];
    $vehicle_reg = $row['vehicle_reg'];
    $driver_contract = $row['driver_contract'];
    $driver_name = $row['driver_name'];
    $wh_id_from_supplier = $row['wh_id_from_supplier'];
    $currency = $row['currency'];
    $conversion_rate = $row['conversion_rate'];
    $wh_id_from = $row['wh_id_from'];
    $tran_ref = $row['tran_ref'];
    $fkstockid = $row['fk_stock_id'];
    $pkdetailid = $row['pk_id'];
    $batchid = $row['batch_id'];
//    $districts = $districts->result_object();
//    $tehsils = $tehsils->result_object();
//    $ucs = $ucs->result_object();
//    $str_arr = str_replace("-",",",$string);
//    $age = explode (",", $str_arr);
//    $diff = abs(strtotime(date("Y-m-d"))-strtotime($string));
//    $years = floor($diff / (365*60*60*24));
//    print_r($years);
//    $patient_month = $row['patient_month'];
//    $email = $row['email'];
//    $patient_id = $row['pk_id'];
//    print_r($age);
    
}
//print_r($tran_reference_number);exit;
if (isset($stock_master_records)) {
    $row = $stock_master_records[0];
    $refernce_number = $row['tran_ref'];
    $warehouse_from = $row['wh_id_from'];
    $warehouse_from_supplier = $row['wh_id_from_supplier'];
    
    //Check 
    $from_id = $row['wh_id_from'];
    $TranRef = $row['tran_ref'];
    
} else if (isset($tran_reference_number)) {

    $refernce_number = $tran_reference_number;
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="row">
                        <div class="col-md-12">
                            
                            <?php
                            if ($approval_code) {
                               //fetch results
                               foreach ($approval_code AS $row)
                               {
                                   $approval_codess = preg_split ("/\,/", $row['approval_code']);  
                                   $approval_code_idd = preg_split ("/\,/", $row['approval_code_id']);  
                                   $approve_fromm = preg_split ("/\,/", $row['approve_from']);  
                                   $approve_too = preg_split ("/\,/", $row['approve_to']);  
                                   $process_statuss = preg_split ("/\,/", $row['process_status']); 
                                   $final_statuss = preg_split ("/\,/", $row['final_status']); 
                                   $approver_designation = preg_split ("/\,/", $row['approver_designation']); 
                                   $approver_desg_id = preg_split ("/\,/", $row['approver_desg_id']);
//                                   if($row['process_status'] == '1')
//                                   {
//                                       $process_status_ids = preg_split ("/\,/", $row['process_status']); 
//                                   }
//                                   else{
////                                       $pstatus = $row['process_status']-1;
//                                       $process_status_ids .= preg_split ("/\,/", $row['process_status']-1); 
//                                   }
//                                   for($i = 0 ; $i < count($approval_codess) ;$i++)
//                                   {
//                                       if($process_statuss[$i] == '1')
//                                       {
//                                            $process_status_ids[] = $process_statuss[$i]; 
////                                          print_r($process_status_ids);exit;
//                                       }
//                                        else{
//                                            $process_status_ids[] .= $process_statuss[$i]-1; 
//                                        }
//                                   }
//                                   print_r(implode(",",$process_status_ids));exit;
                                   $approvalcount = count($approval_codess);
//                                   print_r($row['process_status']);exit;
//                                   $val = array("'" . str_replace(",", "','", $row['approval_code']) . "'");
                                   
//                                   $val = explode($row['approval_code']);
//                                   print_r($approval_codes);
                                   
                               }
//                               print_r($row['process_status']);
//                               if (in_array("Initiator", $approver_designation)){
//                                        echo "Match found";
//                                }
//                                else{
//                                        echo "Match not found";
//                                }
//                                exit;
                            }
                        ?>
                            
                            
                            <?php 
//                        if(isset($issueVoucher) && !empty($issueVoucher)) {
//                            echo 'Pending Vouchers are : ';
//                            echo implode(',', $issueVoucher);
//                            echo '<hr>';
//                        }
                        
//                        if(isset($getStockIssues) && !empty($getStockIssues)) {
                            
                            $issueVoucher = array();
                            $a='';
                                if ($getStockIssues) {

                                    //fetch results
                                    foreach ($getStockIssues AS $row)
                                    {
                                        $a= " <a style='color:red;' href=\"gwis_initiator?issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
                                        $issueVoucher[ $row['tran_no']] = $a;
                                    }

     //                           }

                                     echo '<table style="font-family: arial;border:2px solid #1F8564; sans-serif;border-collapse: collapse;width:100%"><tr><th style="border: 2px solid #1F8564;text-align: left;padding: 8px;width:20%;font-size:16px;">Pending Vouchers are : </th><td  style="border: 1px solid #dddddd;text-align: left;padding: 8px;text-decoration: underline;">';
                                     echo implode(',', $issueVoucher);
                                     echo '</td></table><hr>';
                                 }
                            
                            
                            if (in_array("69", $approver_desg_id)){
                                if ($getRejectedVoucher) {

                                    //fetch results
                                    foreach ($getRejectedVoucher AS $row)
                                    {
                                        $a= " <a style='color:red;' href=\"gwis_initiator?rej_issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
                                        $issueRegVoucher[$row['tran_no']] = $a;
                                    }

     //                           }

                                     echo '<table style="font-family: arial;border:2px solid #1F8564; sans-serif;border-collapse: collapse;width:100%"><tr><th style="border: 2px solid #1F8564;text-align: left;padding: 8px;width:20%;font-size:16px;">Rejected Vouchers are : </th><td  style="border: 1px solid #dddddd;text-align: left;padding: 8px;text-decoration: underline;">';
                                     echo implode(',', $issueRegVoucher);
                                     echo '</td></table><hr>';
                                }
                            }
                            else{
//                                    echo "Match not found";
                            }
                            
                            
                            
                         ?></div>
                    </div>
                    
                    <br>
                    
                    <div class="heading-buttons">
                        <h3>GIWS Approver</h3>
                        

                    </div>
                    <div class="separator bottom"></div>
                    
                    <div class="innerLR">
                        
                        <form method="POST" name="batch_search" action="gwis_initiator" >
                            <!-- Row -->
                            <?php 
                            //get e
                            if(isset($_GET['e'])){?>
                            <span style="padding-left:15px; color:#F00;">Please select at least one product by clicking checkboxes at right</span>
                            <?php }?>
                            
<!--                            <div class="col-md-3">
                                <div class="control-group">
                                    <label class="example-text-input" for="hf" required >Quantity <span style="color: red">*</span></label>
                                    <div class="controls">
                                        <input type="number" name="quantity" id="quantity" class="form-control"   required >
                                    </div>
                                </div>
                            </div>-->
                            
                            <div class="form-group row ">
                                <!--<div class="col-md-12">-->
                                    <div class="col-md-3"> 
                                        <!-- Group Receive No-->
                                        <div class="control-group">
                                            <label for="issue_no"> Issue No </label>
                                            <div class="controls">
                                            <input class="form-control" tabindex="1" id="issue_no" value="<?php if(isset($issue_no)) echo $issue_no; ?>" name="issue_no" type="text" required />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="control-group">
                                        <div class="input-group input-medium" style="margin-top: 21px;">
                                            <div class="controls">
                                            <button type="submit" class="btn btn-primary" name="search" value="Search"> Search </button>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                <!--</div>-->
                            </div>
                    </form>
                        
                       <?php 
                       if(isset($stockReceive)) { 
                           foreach ($stockReceive as $row) {
                               $pkmasterides = $row['masterpkid'];
                           }
                           ?> 
                        <form method="post" id="delivery_challan" enctype="multipart/form-data" name="delivery_challan" action="<?php echo base_url("inventory_management/gwis_initiator_submit"); ?>">
                            
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                
                                <div class="form-group row">
                                    <div class="col-md-12" style="text-align:right;">
                                        <?php if (in_array("69", $approver_desg_id)){
                                        ?>   
                                        <a href="<?php echo base_url("inventory_management/gwis_physical_inspection?vouchertno=$issue_no&pkmasteridedit=$pkmasterides&edit=1"); ?> " class="btn btn-warning" title="edit">Edit Products / Items</a>
                                        <button type="submit" id="save" class="btn btn-success"> Update </button>
                                        <?php } else { ?>
                                        <button type="submit" id="save" class="btn btn-success"> Save </button>
                                        <?php } ?>
                                        <a href="<?php echo base_url("dashboard/index"); ?> " class="btn btn-danger" title="cancel">Cancel</a>
                                        <!--<button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" > Add Receiving</button>-->
                                    </div>  
                                    <?php if (isset($temp_records) && (!empty($temp_records))) {
                                        ?>
                                        <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>">

                                    <?php }
                                    ?>    
                                    <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                </div> 
                                            
                                            
                                <table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable">
                                    
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:16px;"> Supplier Info</th>
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 
                                    
                                    <!-- Table body -->
                                    <tbody>
                                        <?php
                                        $i = 0;
                                        
                                            foreach ($stockReceive as $row) {
                                        if($i <= 0)
                                        {
                                                $stockID = $row['fk_stock_id'];
                                                $issuance_date = $row['tran_date'];
                                                ?>
                                        <tr>
                                            <?php if(empty($row['wh_from'])) { ?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">Supplier : </b>' .$row['wh_from_supplier'] . '<b style="font-weight: 900;margin-left: 30px;">Contact Person : </b>' .$row['contact_person'] .'<b style="font-weight: 900;margin-left: 30px;">Contact Number : </b>' .$row['contact_numbers']. '<b style="font-weight: 900;margin-left: 30px;">Contact Email :</b> ' .$row['contact_emails'] .
                                                 '<br><br><b style="font-weight: 900;">Contact Address : </b>' .$row['contact_address'];?>
                                            </td>
                                        </tr>
                                        <?php 
                                            } else{?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">Warehouse : </b>' .$row['wh_from']; 
                                                 ?>
                                            </td>
                                            <?php  }
                                            $i++;
                                            }
                                        }
                                            ?>
                                    </tbody>
                                </table>
                                            
                                            
                                <table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable">
                                    
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:16px;"> Driver Info</th>
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 
                                    
                                    <!-- Table body -->
                                    <tbody>
                                        <?php
                                        $i = 0;
                                        
                                            foreach ($stockReceive as $row) {
                                        if($i <= 0)
                                        {
                                                $stockID = $row['fk_stock_id'];
                                                $issuance_date = $row['tran_date'];
                                                ?>
                                        <tr>
                                            <?php if(empty($row['wh_from'])) { ?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">Driver Name : </b>' .$row['driver_name'] . '<b style="font-weight: 900;margin-left: 30px;">Driver Contract : </b>' .$row['driver_contract'] .'<b style="font-weight: 900;margin-left: 30px;">Vehicle Reg# : </b>' .$row['vehicle_reg'] ;?>
                                            </td>
                                        </tr>
                                        <?php 
                                            } else{?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">Warehouse : </b>' .$row['wh_from']; 
                                                 ?>
                                            </td>
                                            <?php  }
                                            $i++;
                                            }
                                        }
                                            ?>
                                    </tbody>
                                </table>            
                                      
                                <table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable">
                                    
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th style="background-color: #ddffdd;border-left: 6px solid #04AA6D;font-size:16px;"> Other Info</th>
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 
                                    
                                    <!-- Table body -->
                                    <tbody>
                                        <?php
                                        $i = 0;
                                        
                                            foreach ($stockReceive as $row) {
                                        if($i <= 0)
                                        {
                                                $stockID = $row['fk_stock_id'];
                                                $issuance_date = $row['tran_date'];
                                                ?>
                                        <tr>
                                            <?php if(empty($row['wh_from'])) { ?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">DC Number : </b>' .$row['dc_no'] . '<b style="font-weight: 900;margin-left: 30px;">DC Date : </b>' .$row['dc_date'] .'<b style="font-weight: 900;margin-left: 30px;">Invoice : </b>' .$row['invoice']. 
                                                 '<b style="font-weight: 900;margin-left: 30px;">Challan Type : </b>' .$row['challan_type']. '<b style="font-weight: 900;margin-left: 30px;">Challan Type Detail : </b>' .$row['challan_type_detail'].
                                                '<br><br><b style="font-weight: 900;">Inspection Date : </b>' .$row['inspection_date']. '<b style="font-weight: 900;margin-left: 30px;">Delivery Location : </b>' .$row['delivery_location']. '<b style="font-weight: 900;margin-left: 30px;"> Vehicle Type & Plate #  : </b>' .$row['vehicle_type_and_plate'].  '<b style="font-weight: 900;margin-left: 30px;"> PO CMU Date : </b>' .$row['po_cmu_date'] . '<b style="font-weight: 900;margin-left: 30px;"> PO# CMU  : </b>' .$row['po_cmu_no']. '<b style="font-weight: 900;margin-left: 30px;">PO GF Date : </b>' .$row['po_gf_date'].
                                                '<br><br><b style="font-weight: 900;">PO# GF : </b>' .$row['po_gf_no']. '<b style="font-weight: 900;margin-left: 30px;">Date Of Receiving : </b>' .$row['date_of_receiving']. '<b style="font-weight: 900;margin-left: 30px;"> Air waybill No : </b>'  .$row['air_bill_no']. '<b style="font-weight: 900;margin-left: 30px;"> Shipment number : </b>' .$row['shipment_no']. '<b style="font-weight: 900;margin-left: 30px;">Origin of Country : </b>' .$row['origin_of_country']. '<b style="font-weight: 900;margin-left: 30px;">Weight of consignment : </b>' .$row['consignment_weight'];?>
                                            </td>
                                        </tr>
                                        <?php 
                                            } else{?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">Warehouse : </b>' .$row['wh_from']; 
                                                 ?>
                                            </td>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">DC Number : </b>' .$row['dc_no'] . '<b style="font-weight: 900;margin-left: 30px;">DC Date : </b>' .$row['dc_date'] .'<b style="font-weight: 900;margin-left: 30px;">Invoice : </b>' .$row['invoice']. 
                                                 '<b style="font-weight: 900;margin-left: 30px;">Challan Type : </b>' .$row['challan_type']. '<b style="font-weight: 900;margin-left: 30px;">Challan Type Detail : </b>' .$row['challan_type_detail'].
                                                '<br><br><b style="font-weight: 900;">Inspection Date : </b>' .$row['inspection_date']. '<b style="font-weight: 900;margin-left: 30px;">Delivery Location : </b>' .$row['delivery_location']. '<b style="font-weight: 900;margin-left: 30px;"> Vehicle Type & Plate #  : </b>' .$row['vehicle_type_and_plate'].  '<b style="font-weight: 900;margin-left: 30px;"> PO CMU Date : </b>' .$row['po_cmu_date'] . '<b style="font-weight: 900;margin-left: 30px;"> PO# CMU  : </b>' .$row['po_cmu_no']. '<b style="font-weight: 900;margin-left: 30px;">PO GF Date : </b>' .$row['po_gf_date'].
                                                '<br><br><b style="font-weight: 900;">PO# GF : </b>' .$row['po_gf_no']. '<b style="font-weight: 900;margin-left: 30px;">Date Of Receiving : </b>' .$row['date_of_receiving']. '<b style="font-weight: 900;margin-left: 30px;"> Air waybill No : </b>'  .$row['air_bill_no']. '<b style="font-weight: 900;margin-left: 30px;"> Shipment number : </b>' .$row['shipment_no']. '<b style="font-weight: 900;margin-left: 30px;">Origin of Country : </b>' .$row['origin_of_country']. '<b style="font-weight: 900;margin-left: 30px;">Weight of consignment : </b>' .$row['consignment_weight'];?>
                                            </td>
                                            <?php  }
                                            $i++;
                                            }
                                        }
                                            ?>
                                    </tbody>
                                </table>            
                                     
                                            <?php if (in_array("69", $approver_desg_id)){ ?>
                                            <div class="form-group row">
                                                 
                                                <?php
                                        $supplierid = 0;
                                        
                                            foreach ($stockReceive as $rowsw) {
                                        if($supplierid <= 0)
                                        {
                                            
                                            $dcnumber = $rowsw['dc_no'];
                                            $correctdate = str_replace('-', '/', $rowsw['dc_date']);  
                                            $dcdates = date('m/d/Y', strtotime($correctdate));
                                            $invoices = $rowsw['invoice'];
                                            $driversnames = $rowsw['driver_name'];
                                            $drivercontracts = $rowsw['driver_contract'];
                                            $vehicleregs = $rowsw['vehicle_reg'];
                                            
                                            $cinspection_date = str_replace('-', '/', $rowsw['inspection_date']);  
                                            $inspection_date = date('m/d/Y', strtotime($cinspection_date));
                                            $delivery_location = $rowsw['delivery_location'];
                                            $po_cmu_no = $rowsw['po_cmu_no_id'];
                                            $cpo_cmu_date = str_replace('-', '/', $rowsw['po_cmu_date']);  
                                            $po_cmu_date = date('m/d/Y', strtotime($cpo_cmu_date));
                                            $po_gf_no = $rowsw['po_gf_no_id'];
                                            $cpo_gf_date = str_replace('-', '/', $rowsw['po_gf_date']); 
                                            $po_gf_date = date('m/d/Y', strtotime($cpo_gf_date));
                                            $pi_type = $rowsw['pi_type'];
                                            $sbtr_dc_rec = $rowsw['sbtr_dc_rec'];
                                            
                                            $cdate_of_receiving = str_replace('-', '/', $row['date_of_receiving']);  
                                            $date_of_receiving = date('m/d/Y', strtotime($cdate_of_receiving));
                                            $air_bill_no = $row['air_bill_no'];
                                            $shipment_no = $row['shipment_no'];
                                            $origin_of_country = $row['origin_of_country'];
                                            $vehicle_type_and_plate = $row['vehicle_type_and_plate'];
                                            $consignment_weight = $row['consignment_weight'];
                                            
                                             if(empty($rowsw['wh_id_from'])) { ?>
                                            
                                            <div class="col-md-3" id="show_receive_from_supplierr" >
                                                    <label class="example-text-input" for="strength"  >Received From (Supplier)</label>
                                                    <div class="controls">
                                                        <?php
                                                        
//                                                        if (empty($temp_records)) {
                                                            
                                                        ?>
                                                        <select class="select2me input-medium" name="receive_from_supplier" id="receive_from_supplier" style="width:100%;padding:10%;" >
                                                            <option value="">Select</option>
                                                            <?php
                                                                                                                    
                                                            foreach ($suppliers as $rowsuppliers) {
                                                                ?>
                                                            <option value="<?php echo $rowsuppliers['wh_id'] ?>" <?php if (isset($rowsw['wh_id_from_supplier']) && $rowsw['wh_id_from_supplier'] == $rowsuppliers['wh_id']){ echo "selected='selected'";} ?>><?php echo $rowsuppliers['wh_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                        <?php
//                                                        }else
//                                                        {
//                                                            foreach ($suppliers as $row) {
////                                                                if(isset($warehouse_from) && $warehouse_from == $row['stkid']) echo  '<input class="form-control" disabled value="'.$row['stkname'].'">';
//                                                                if(isset($warehouse_from_supplier) && $warehouse_from_supplier == $row['wh_id']) echo  '<input class="form-control" name="receive_from_supplier" id="receive_from_supplier" disabled value="'.$row['wh_name'].'">';                                                                
//                                                            }
//                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                             <?php } else { ?>
                                                <div class="col-md-3" id="show_receive_from_warehousee"  >
                                                    <label class="example-text-input" for="receive_from_warehouse"  >Received From (Warehouse) </label>
                                                    <div class="controls">
                                                        <?php
                                                        
//                                                        if (empty($temp_records)) {
                                                            
                                                        ?>
                                                        <select class="select2me input-medium" name="receive_from_warehouse" id="receive_from_warehouse"  style="width:100%;padding:10%;" <?php if (isset($master_id)) echo 'disabled="true"' ?> >
                                                            <option value="">Select</option>
                                                            <?php
                                                                                                                    
                                                            foreach ($warehouses as $rowwarehouses) {
                                                                ?>
                                                            <option value="<?php echo $rowwarehouses['wh_id'] ?>" <?php if (isset($rowsw['wh_id_from']) && $rowsw['wh_id_from'] == $rowwarehouses['wh_id']) {echo "selected='selected'";} ?>><?php echo $rowwarehouses['wh_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                        <?php
//                                                        }else
//                                                        {
//                                                            foreach ($warehouses as $row) {
////                                                                if(isset($warehouse_from) && $warehouse_from == $row['stkid']) echo  '<input class="form-control" disabled value="'.$row['stkname'].'">';
//                                                                if(isset($warehouse_from_warehouse) && $warehouse_from_warehouse == $row['wh_id']) echo  '<input class="form-control" name="receive_from_warehouse" id="receive_from_warehouse"  disabled value="'.$row['wh_name'].'">';                                                                
//                                                            }
//                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            
                                            
                                             <?php }
                                            $supplierid++;
                                            }
                                        }
                                            ?>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="dcnumber" required >DC Number# </label>
                                                        <div class="controls">
                                                            <input type="text" name="dcnumber" id="dcnumber" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['dc_no']) && !empty($form['dc_no']))
                                                                {
                                                                    echo 'value="' . $form['dc_no'] . '"';
                                                                } else if (isset($dcnumber) && !empty($dcnumber))
                                                                {
                                                                    echo 'value="' . $dcnumber . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="dcdates" required >DC Date </label>
                                                        <div class="controls">
                                                            <input type="text" name="dcdates" id="dc_date" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['dc_date']) && !empty($form['dc_date']))
                                                                {
                                                                    echo 'value="' . $form['dc_date'] . '"';
                                                                } else if (isset($dcdates) && !empty($dcdates))
                                                                {
                                                                    echo 'value="' . $dcdates . '"';
                                                                }
                                                                else{
                                                                    echo 'value=" '. date("m/d/Y"). '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="invoices" required >Invoice # </label>
                                                        <div class="controls">
                                                            <input type="text" name="invoices" id="invoices" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['invoice']) && !empty($form['invoice']))
                                                                {
                                                                    echo 'value="' . $form['invoice'] . '"';
                                                                }else if (isset($invoices) && !empty($invoices))
                                                                {
                                                                    echo 'value="' . $invoices . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="inspection_date" required >Inspection Date(MM/DD/YYYY) </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="inspection_date" id="inspection_date" <?php if (isset($master_id)) echo 'disabled="true"' ?>
                                                                    <?php
                                                                    if (isset($inspection_date)) {
                                                                        echo 'value="' . $inspection_date . '"';
                                                                    }else  {
                                                                        echo 'value="' . date("m/d/Y") . '"';
                                                                    }
                                                                    ?>
                                                                   >

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="delivery_location" required >Delivery Location </label>
                                                        <div class="controls">
                                                            <input type="text" name="delivery_location" id="delivery_location" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($delivery_location) && !empty($delivery_location))
                                                                {
                                                                    echo 'value="' . $delivery_location . '"';
                                                                }else if (isset($tran_ref) && !empty($tran_ref))
                                                                {
                                                                    echo 'value="' . $tran_ref . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                            <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="date_of_receiving" required >Date of Receiving(MM/DD/YYYY) </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="date_of_receiving" id="date_of_receiving" <?php if (isset($master_id)) echo 'disabled="true"' ?>
                                                                    <?php
                                                                    if (isset($date_of_receiving)) {
                                                                        echo 'value="' . $date_of_receiving . '"';
                                                                    } else {
                                                                        echo 'value="' . date("m/d/Y") . '"';
                                                                    }
                                                                    ?>
                                                                   >

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="air_bill_no" required >Air waybill No. / Bill of Lading </label>
                                                        <div class="controls">
                                                            <input type="text" name="air_bill_no" id="air_bill_no" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['air_bill_no']) && !empty($form['air_bill_no']))
                                                                {
                                                                    echo 'value="' . $form['air_bill_no'] . '"';
                                                                }else if (isset($air_bill_no) && !empty($air_bill_no))
                                                                {
                                                                    echo 'value="' . $air_bill_no . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="shipment_no" required >Shipment number </label>
                                                        <div class="controls">
                                                            <input type="text" name="shipment_no" id="shipment_no" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['shipment_no']) && !empty($form['shipment_no']))
                                                                {
                                                                    echo 'value="' . $form['shipment_no'] . '"';
                                                                }else if (isset($shipment_no) && !empty($shipment_no))
                                                                {
                                                                    echo 'value="' . $shipment_no . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="origin_of_country" required >Origin of Country </label>
                                                        <div class="controls">
                                                            <input type="text" name="origin_of_country" id="origin_of_country" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['origin_of_country']) && !empty($form['origin_of_country']))
                                                                {
                                                                    echo 'value="' . $form['origin_of_country'] . '"';
                                                                }else if (isset($origin_of_country) && !empty($origin_of_country))
                                                                {
                                                                    echo 'value="' . $origin_of_country . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="vehicle_type_and_plate" required >Vehicle Type & Plate # </label>
                                                        <div class="controls">
                                                            <input type="text" name="vehicle_type_and_plate" id="vehicle_type_and_plate" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['vehicle_type_and_plate']) && !empty($form['vehicle_type_and_plate']))
                                                                {
                                                                    echo 'value="' . $form['vehicle_type_and_plate'] . '"';
                                                                }else if (isset($vehicle_type_and_plate) && !empty($vehicle_type_and_plate))
                                                                {
                                                                    echo 'value="' . $vehicle_type_and_plate . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="consignment_weight" required >Total weight of consignment </label>
                                                        <div class="controls">
                                                            <input type="text" name="consignment_weight" id="consignment_weight" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['consignment_weight']) && !empty($form['consignment_weight']))
                                                                {
                                                                    echo 'value="' . $form['consignment_weight'] . '"';
                                                                }else if (isset($consignment_weight) && !empty($consignment_weight))
                                                                {
                                                                    echo 'value="' . $consignment_weight . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group row">
                                            
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="po_cmu" required >PO# CMU<span style="color: red">*</span> </label>     
                                                        <div class="controls">
                                                            <?php
                                                        
                                                        if (isset($po_no_cmu_arr) && !empty($po_no_cmu_arr)) {
                                                            
                                                        ?>
                                                        <select class="select2me input-medium" name="po_cmu" id="po_cmu" style="width:100%;padding:10%;" <?php if (isset($master_id)) echo 'disabled="true"' ?> >
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($po_no_cmu_arr as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($po_cmu_no) && $po_cmu_no == $row['pk_id']){ echo "selected='selected'";}else if (isset($form['po_cmu']) && $form['po_cmu'] == $row['pk_id']){ echo "selected='selected'";}else if ( $ctype == $row['pk_id']){ echo "selected='selected'";} ?>><?php echo $row['number'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                        <?php
                                                        }
                                                        if(isset($master_id)) { ?>
                                                            
                                                            <input type="hidden" class="form-control" name="po_cmu" id="po_cmu" value="<?php if(isset($po_cmu_no)) {echo $po_cmu_no;} ?>" >
                                                            
                                                        <?php } ?>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3" id="show_po_cmu_date" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Date(MM/DD/YYYY) </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="po_cmu_date" id="po_cmu_date" <?php if (isset($master_id)){ echo 'disabled="true"'; }else{echo 'readonly';}?>
                                                                    <?php
                                                                    if (isset($po_cmu_date)) {
                                                                        echo 'value="' . $po_cmu_date . '"';
                                                                    }else  {
                                                                        echo 'value="' . date("m/d/Y") . '"';
                                                                    }
                                                                    ?>
                                                                   >

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="po_gf" required >PO# GF <span style="color: red">*</span> </label>     
                                                        <div class="controls">
                                                            <?php
                                                        
                                                        if (isset($po_no_gf_arr) && !empty($po_no_gf_arr)) {
                                                            
                                                        ?>
                                                        <select class="select2me input-medium" name="po_gf" id="po_gf" style="width:100%;padding:10%;" <?php if (isset($master_id)) echo 'disabled="true"' ?> >
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($po_no_gf_arr as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($po_gf_no) && $po_gf_no == $row['pk_id']){ echo "selected='selected'";}else if (isset($form['po_gf']) && $form['po_gf'] == $row['pk_id']){ echo "selected='selected'";}else if ( $ctype == $row['pk_id']){ echo "selected='selected'";} ?>><?php echo $row['number'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                        <?php
                                                        }
                                                        if(isset($master_id)) { ?>
                                                            
                                                            <input type="hidden" class="form-control" name="po_gf" id="po_gf" value="<?php if (isset($po_gf_no)){ echo $po_gf_no;} ?>" >
                                                            
                                                        <?php } ?>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3" id="show_po_gf_date" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Date(MM/DD/YYYY) </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="po_gf_date" id="po_gf_date" <?php if (isset($master_id)){ echo 'disabled="true"'; }else{echo 'readonly';}?>
                                                                    <?php
                                                                    if (isset($po_gf_date)) {
                                                                        echo 'value="' . $po_gf_date . '"';
                                                                    }else  {
                                                                        echo 'value="' . date("m/d/Y") . '"';
                                                                    }
                                                                    ?>
                                                                   >

                                                        </div>
                                                    </div>
                                                </div>
                                            
                                            </div>
                                            
                                            <div class="form-group row"> 
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="driversnames" required >Driver Name </label>
                                                        <div class="controls">
<!--                                                            <input type="text" name="driversnames" id="driversnames" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
//                                                                if (isset($form['driver_name']) && !empty($form['driver_name']))
//                                                                {
//                                                                    echo 'value="' . $form['driver_name'] . '"';
//                                                                }else if (isset($driversnames) && !empty($driversnames))
//                                                                {
//                                                                    echo 'value="' . $driversnames . '"';
//                                                                }
                                                                ?>
                                                                   >-->
                                                            
                                                            <textarea  name="driversnames" id="driversnames" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                      <?php
                                                                        if (isset($form['driver_name']) && !empty($form['driver_name']))
                                                                        {
                                                                            echo 'value="' . $form['driver_name'] . '"';
                                                                        }else if (isset($driversnames) && !empty($driversnames))
                                                                        {
                                                                            echo 'value="' . $driversnames . '"';
                                                                        }
                                                                    ?>
                                                                      ><?php
                                                                        if (isset($form['driver_name']) && !empty($form['driver_name']))
                                                                        {
                                                                            echo $form['driver_name'];
                                                                        }else if (isset($driversnames) && !empty($driversnames))
                                                                        {
                                                                            echo $driversnames;
                                                                        }
                                                                    ?>
                                                            </textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="drivercontracts" required >Driver contact # <span style="color: red">*</span></label>
                                                        <div class="controls">
<!--                                                            <input type="number" name="drivercontracts" id="drivercontracts" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
//                                                                if (isset($form['driver_contract']) && !empty($form['driver_contract']))
//                                                                {
//                                                                    echo 'value="' . $form['driver_contract'] . '"';
//                                                                }else if (isset($drivercontracts) && !empty($drivercontracts))
//                                                                {
//                                                                    echo 'value="' . $drivercontracts . '"';
//                                                                }
                                                                ?>
                                                                   >-->
                                                            
                                                            <textarea  name="drivercontracts" id="drivercontracts_s" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                      <?php
                                                                        if (isset($form['driver_contract']) && !empty($form['driver_contract']))
                                                                        {
                                                                            echo 'value="' . $form['driver_contract'] . '"';
                                                                        }else if (isset($drivercontracts) && !empty($drivercontracts))
                                                                        {
                                                                            echo 'value="' . $drivercontracts . '"';
                                                                        }
                                                                    ?>
                                                                      ><?php
                                                                        if (isset($form['driver_contract']) && !empty($form['driver_contract']))
                                                                        {
                                                                            echo $form['driver_contract'];
                                                                        }else if (isset($drivercontracts) && !empty($drivercontracts))
                                                                        {
                                                                            echo $drivercontracts;
                                                                        }
                                                                    ?>
                                                            </textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="vehicleregs" required >Vehicle Reg# </label>
                                                        <div class="controls">
<!--                                                            <input type="text" name="vehicleregs" id="vehicleregs" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
//                                                                if (isset($form['vehicle_reg']) && !empty($form['vehicle_reg']))
//                                                                {
//                                                                    echo 'value="' . $form['vehicle_reg'] . '"';
//                                                                }else if (isset($vehicleregs) && !empty($vehicleregs))
//                                                                {
//                                                                    echo 'value="' . $vehicleregs . '"';
//                                                                }
                                                                ?>
                                                                   >-->
                                                            
                                                            <textarea  name="vehicleregs" id="vehicleregs" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                      <?php
                                                                        if (isset($form['vehicle_reg']) && !empty($form['vehicle_reg']))
                                                                        {
                                                                            echo 'value="' . $form['vehicle_reg'] . '"';
                                                                        }else if (isset($vehicleregs) && !empty($vehicleregs))
                                                                        {
                                                                            echo 'value="' . $vehicleregs . '"';
                                                                        }
                                                                    ?>
                                                                      ><?php
                                                                        if (isset($form['vehicle_reg']) && !empty($form['vehicle_reg']))
                                                                        {
                                                                            echo $form['vehicle_reg'];
                                                                        }else if (isset($vehicleregs) && !empty($vehicleregs))
                                                                        {
                                                                            echo $vehicleregs;
                                                                        }
                                                                    ?>
                                                            </textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="fileToUploads"  >Select File to upload:</label>
                                                        <div class="controls">
                                                            <input type="file" name="fileToUpload">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-1">
                                                    <div class="control-group">
                                                        <div class="controls">
                                                            <?php
                                                            $i = 0;
                                                            foreach ($stockReceive as $row) {
                                                                 if($i < 1)
                                                                    {
                                                                ?>
                                                            
                                                            <a href="<?php echo base_url(); ?>uploads/<?php echo $row['file']; ?>" target="_blank">View Uploaded File</a>
                                                            <!--// For Download-->
                                                            <!--<a href="<?php echo base_url(); ?>uploads/<?php echo $row['file']; ?>" download>Download</a>-->
                                                                
                                                            <?php $i++;
                                                                    } 
                                                                } ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                
                                                
                                            </div>
                                            
                       <?php } ?>
                                            
                                        </div>
                                             
                                            
                                <div style="overflow-x: scroll;width:100%;">                  
                                            <!-- Table -->
                                <table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable">
                                    
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th style="background-color: #ddffdd;font-size:14px;border-left: 6px solid #04AA6D;border-right: 6px solid #04AA6D;"> Electronic Approval</th>
                                            <th> Product </th>
                                            <th> Manufacturer </th>
                                           <?php 
                                           $sr = 0;
//                                           foreach ($stockReceive as $row) {
//                                               if($row['product_type'] == '36' && $sr == 0) {?>
                                            <th> Batch </th>
                                            <th> Mfg Date </th>
                                            <th> Exp Date </th>
                                            <th> Shelf Life </th>
                                            <th> Serial No </th>
                                            <th> Warranty </th>
                                            <!--<th> Pack Size </th>-->
                                            <th>Temp From</th>
                                            <th>Temp to</th>
                                          <?php // $sr++;
//                                               }
//                                            } ?>
                                            <th> PO Quantity </th>
                                            <th> DC Quantity </th>
                                            <th> Actual Received<br> Quantity </th>
                                            <th> GIWS PI Quantity </th>
                                            <th> Comment</th>
<!--                                            <th> DTL Values</th>
                                            <th> DTL Result</th>-->
                                            
                                            <!--<th style="width: 1%;"> <input type="checkbox" id="checkAll" /></th>-->
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 
                                    
                                    <!-- Table body -->
                                    <tbody>
                                        <!-- Table row -->
                                        <?php
                                        if(isset($rejected_real_masterid))
                                        {
                                            foreach ($rejected_real_masterid as $row) {?>
                                        
                                            <input type="hidden" id="stkmasterid" name='stkmasterid' value="<?php echo $row['stkmasterid']; ?>" />
                                        
                                        <?php }
                                            }
                                        
                                            $i = 1;
                                            foreach ($stockReceive as $row) {?>
                                            <!-- <input type="hidden" id="detailpkid" name='detailpkid[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['pk_id']; ?>" />
                                                <input type="hidden" id="wh_from_supplier" name='wh_from_supplier' value="<?php echo $row['wh_id_from_supplier']; ?>" />
                                                <input type="hidden" id="wh_from" name='wh_from' value="<?php echo $row['wh_id_from']; ?>" />
                                            <input type="hidden" id="rejected_voucher" name='rejected_voucher' value="<?php if(isset($row['electronic_approval'])) {echo $row['electronic_approval'];} else{echo '';} ?>" />
                                                
                                                <input type="hidden" id="field1" name='field1[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field1']; ?>" />
                                                <input type="hidden" id="field2" name='field2[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field2']; ?>" />
                                                <input type="hidden" id="field3" name='field3[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field3']; ?>" />
                                                <input type="hidden" id="field4" name='field4[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field4']; ?>" />
                                                <input type="hidden" id="field5" name='field5[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field5']; ?>" />
                                                <input type="hidden" id="field6" name='field6[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field6']; ?>" />
                                                <input type="hidden" id="field7" name='field7[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field7']; ?>" />
                                                <input type="hidden" id="field8" name='field8[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field8']; ?>" />
                                                <input type="hidden" id="field9" name='field9[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field9']; ?>" />
                                                <input type="hidden" id="field10" name='field10[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field10']; ?>" />
                                                
                                                <input type="hidden" id="delivery_challan_type" name='delivery_challan_type[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['delivery_challan_type']; ?>" />
                                                <input type="hidden" id="challan_type_detail" name='challan_type_detail[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['challan_type_detail']; ?>" />
                                                <input type="hidden" id="driver_name" name='driver_name[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['driver_name']; ?>" />
                                                <input type="hidden" id="driver_contract" name='driver_contract[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['driver_contract']; ?>" />
                                                <input type="hidden" id="vehicle_reg" name='vehicle_reg[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['vehicle_reg']; ?>" />
                                                <input type="hidden" id="dc_no" name='dc_no[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['dc_no']; ?>" />
                                                <input type="hidden" id="dc_date" name='dc_date[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['dc_date']; ?>" />
                                                <input type="hidden" id="invoice" name='invoice[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['invoice']; ?>" />
                                                
                                                <input type="hidden" id="tran_no" name='tran_no' value="<?php echo $row['tran_no']; ?>" />
                                                <input type="hidden" id="masterpkid" name='masterpkid' value="<?php echo $row['masterpkid']; ?>" />
                                                <input type="hidden" id="unit_price" name='unit_price[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['unit_price']; ?>" />
                                                <input type="hidden" id="currency" name='currency[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['currency']; ?>" />
                                                <input type="hidden" id="conversion_rate" name='conversion_rate[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['conversion_rate']; ?>" />
                                                
                                                <input type="hidden" id="batch_id" name='batch_id[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['batch_id']; ?>" />
                                                
                                                <input type="hidden" id="stk_id" name='stk_id' value="<?php echo $row['stk_id']; ?>" />
                                                
                                                <input type="hidden" id="inspection_date" name='inspection_date' value="<?php echo $row['inspection_date']; ?>" />
                                                <input type="hidden" id="delivery_location" name='delivery_location' value="<?php echo $row['delivery_location']; ?>" />
                                                <input type="hidden" id="po_cmu_no" name='po_cmu_no' value="<?php echo $row['po_cmu_no_id']; ?>" />
                                                <input type="hidden" id="po_cmu_date" name='po_cmu_date' value="<?php echo $row['po_cmu_date']; ?>" />
                                                <input type="hidden" id="po_gf_no" name='po_gf_no' value="<?php echo $row['po_gf_no_id']; ?>" />
                                                <input type="hidden" id="po_gf_date" name='po_gf_date' value="<?php echo $row['po_gf_date']; ?>" />
                                                <input type="hidden" id="date_of_receiving" name='date_of_receiving' value="<?php echo $row['date_of_receiving']; ?>" />
                                                <input type="hidden" id="air_bill_no" name='air_bill_no' value="<?php echo $row['air_bill_no']; ?>" />
                                                <input type="hidden" id="shipment_no" name='shipment_no' value="<?php echo $row['shipment_no']; ?>" />
                                                <input type="hidden" id="origin_of_country" name='origin_of_country' value="<?php echo $row['origin_of_country']; ?>" />
                                                <input type="hidden" id="vehicle_type_and_plate" name='vehicle_type_and_plate' value="<?php echo $row['vehicle_type_and_plate']; ?>" />
                                                <input type="hidden" id="consignment_weight" name='consignment_weight' value="<?php echo $row['consignment_weight']; ?>" />
                                                <input type="hidden" id="file" name='file' value="<?php echo $row['file']; ?>" />
                                                <input type="hidden" id="pi_type" name='pi_type[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['pi_type']; ?>" />
                                                <input type="hidden" id="sbtr_dc_rec" name='sbtr_dc_rec[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['sbtr_dc_rec']; ?>" />
                                                <input type="hidden" id="shipment_temperature" name='shipment_temperature[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['shipment_temprature']; ?>" /> -->
                                                <?php
												//print_r($row);

//                                                 $startDate = new DateTime($row['field3']);
// //                                                $endDate = new DateTime(date("Y-m-d",strtotime($row['tran_date'])));
//                                                 $endDate = new DateTime($row['field2']);
                                                
//                                                 $difference = $endDate->diff($startDate);
//                                                 $daysss = $difference->format("%a");
                                                
//                                                 $months = floor($daysss / 30);
//                                                 $dayss = $daysss - ($months*30);
//                                                 $days = $months ." Months " . $dayss ." Days";
//                                                $secs = $datetime2 - $datetime1;// == <seconds between the two times>
//                                                $days = $secs / 86400;
                                                
                                                $stockID = $row['fk_stock_id'];
                                                $issuance_date = $row['tran_date'];
                                                ?>
                                        <tr>
                                            
                                            <td style="background-color: #ddffdd;border-left: 6px solid #04AA6D;border-right: 6px solid #04AA6D;">
                                                <?php if (in_array("69", $approver_desg_id)){
                                                ?>    
                                                <select disabled="" name="approve_or_rej[<?php echo $row['pk_id']; ?>]" id="approve_or_rej" required class="select2me input-medium" style="width:100%;padding:10%;">
                                                    
                                                    <option value="1" <?php // if(isset($_REQUEST['tranno']) && $row['dtl'] = '1')  echo "selected='selected'";  ?>>Approve</option>
                                                    <!--<option value="2" <?php // if(isset($_REQUEST['tranno']) && $row['dtl'] = '2')  echo "selected='selected'";  ?>>Reject</option>-->
                                                </select>
                                                <input type="hidden" id="approve_or_rej" name='approve_or_rej[<?php echo $row['pk_id']; ?>]' value="1" />
                                                <?php } else { ?>
                                                <select name="approve_or_rej[<?php echo $row['pk_id']; ?>]" id="approve_or_rej" required class="select2me input-medium" style="width:100%;padding:10%;">
                                                    
                                                    <option value="1" <?php // if(isset($_REQUEST['tranno']) && $row['dtl'] = '1')  echo "selected='selected'";  ?>>Approve</option>
                                                    <option value="2" <?php // if(isset($_REQUEST['tranno']) && $row['dtl'] = '2')  echo "selected='selected'";  ?>>Reject</option>
                                                </select>
                                                <?php } ?>
                                            </td>
                                            
                                            <td  style="white-space: nowrap;"><?php echo $row['itm_name']; ?>
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-qty" name='itm_id[<?php echo $row['itm_id']; ?>]' value="<?php echo $row['itm_name']; ?>" />     -->
                                            </td>
                                            
                                            <td  style="white-space: nowrap;"><?php echo $row['manufacturer_name']; ?>
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-qty" name='manufacturer[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['manufacturer']; ?>" /> -->
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-qty" name='manufacturer_name[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['manufacturer_name']; ?>" /> -->
                                            </td>
                                            
                                           <?php // if($row['product_type'] == '36') {?>
                                            
                                            <td><?php echo $row['field1']; ?>
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-batch_no" name='batch_no[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field1']; ?>" /> -->
                                            </td>
											<?php 
											if($row['field1'] == 'NA' || $row['field1'] == 'N/A'){
												$row['field3'] = 'N/A';
												$row['field2'] = 'N/A';
												$days = 'N/A';
											}
											?>

                                            <td style="white-space: nowrap;"><?php echo (!empty($row['field2']) && $row['field2'] > '1970-01-01')?$row['field2']:'NA'; ?>
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-batch_no" name='production_date[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field2']; ?>" /> -->
                                            </td>
											
                                            <td style="white-space: nowrap;"><?php echo (!empty($row['field3']) && $row['field3'] > '1970-01-01')?$row['field3']:'NA'; ?>
                                                <!-- <input type="hidden" id="<?php echo $i; ?>-batch_no" name='batch_expiry[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['field3']; ?>" /> -->
                                            </td>
                                            <td style="white-space: nowrap;"><?php echo shelf_life($row['tran_date'], $row['batch_expiry']); ?></td>
                                            
                                           <?php // } ?>
                                            
                                            <td style="white-space: nowrap;"><?php echo $row['field4']; ?> </td>
                                            <td style="white-space: nowrap;"><?php echo $row['field5']; ?> </td>
                                            <!--<td style="white-space: nowrap;"><?php echo $row['field6']; ?> </td>-->
                                            <td><?php echo $row['field8']; ?></td> 
                                            <td><?php echo $row['field9']; ?></td> 
                                            
                                            <td class="right"><?php echo 0; ?></td>
                                            <td class="right">
                                                <input type="number" <?php if (in_array("69", $approver_desg_id)){ echo ''; }else { echo 'readonly'; } ?> style="width:100px" id="dcquantity" name='dc_quantityy[<?php echo $row['pk_id']; ?>]' value="<?php echo abs($row['dc_quantity']); ?>" min="0" class="form-control input-sm input-small dcqty" /></td>
                                            <td class="right">
                                                <input type="number" <?php if (in_array("69", $approver_desg_id)){ echo ''; }else { echo 'readonly'; } ?> style="width:100px" id="arquantity" name='actual_rec_qty[<?php echo $row['pk_id']; ?>]' value="<?php echo abs($row['actual_rec_qty']); ?>" min="0" class="form-control input-sm input-small arqty" /></td>
                                            <td class="right">
                                                <input type="number" <?php if (in_array("69", $approver_desg_id)){ echo ''; }else { echo 'readonly'; } ?> style="width:100px" id="piquantity" name='pi_quantity[<?php echo $row['pk_id']; ?>]' value="<?php echo abs($row['pi_quantity']); ?>" min="0" class="form-control input-sm input-small phyiqty"  /></td>
                                            <!--<td class="col-md-3"><input type="number" name="missing[<?php echo $row['pk_id']; ?>]" id="<?php echo $i; ?>-missing" value="<?php if(isset($_REQUEST['tranno'])) echo abs($row['ti_quantity']); ?>" min="0" class="form-control input-sm input-small missingqty" /></td>-->
                                            
                                            <td class="col-md-3"><textarea name="comment[<?php echo $row['pk_id']; ?>]" id="<?php echo $i; ?>-comment" value="<?php if($row['pi_comment']) echo $row['pi_comment']; ?>" class="form-control input-sm input-small" ><?php if($row['pi_comment']) echo $row['pi_comment']; ?></textarea></td>
                                            
<!--                                            <td>
                                                <select name="dtl[<?php echo $row['pk_id']; ?>]" id="dtl" required class="select2me input-medium" style="width:100%;padding:10%;">
                                                    
                                                    <option value="1" <?php if(isset($_REQUEST['tranno']) && $row['dtl'] = '1')  echo "selected='selected'";  ?>>Not Required</option>
                                                    <option value="2" <?php if(isset($_REQUEST['tranno']) && $row['dtl'] = '2')  echo "selected='selected'";  ?>>Required</option>
                                                </select>
                                            </td>
                                            
                                            <td>
                                                <select name="dtl_result[<?php echo $row['pk_id']; ?>]" id="dtl_result" required class="select2me input-medium" style="width:100%;padding:10%;">
                                                    
                                                    <option value="1" <?php if(isset($_REQUEST['tranno']) && $row['dtl_result'] = '1')  echo "selected='selected'";  ?> >N/A</option>
                                                    <option value="2" <?php if(isset($_REQUEST['tranno']) && $row['dtl_result'] = '2')  echo "selected='selected'";  ?> >Result Pending </option>
                                                    <option value="3" <?php if(isset($_REQUEST['tranno']) && $row['dtl_result'] = '3')  echo "selected='selected'";  ?> >Positive</option>
                                                    <option value="4" <?php if(isset($_REQUEST['tranno']) && $row['dtl_result'] = '4')  echo "selected='selected'";  ?> >Negative</option>
                                                </select>
                                            </td>-->
                                            
                                            
                                            
                                            <!--<td class="col-md-3">-->
<!--                                                <select name="types[<?php echo $row['pk_id']; ?>]" id="<?php echo $i; ?>-types" class="form-control input-sm input-small types_select">
                                                    <?php
//                                                        if (!empty($types)) {
//                                                            
//                                                            foreach ($types as $type) {
//                                                                if($type->trans_id != 20 && $type->trans_id != 24)
//                                                                echo "<option value=" . $type->trans_id . ">" . $type->trans_type . "</option>";
//                                                            }
//                                                        }
                                                        ?>
                                                </select>-->
                                            <!--</td>-->
                                            <!--<td class="center"><input type="checkbox" name="stockid[<?php echo $row['pk_id']; ?>]" value="<?php echo $row['pk_id']; ?>" /></td>-->
                                        <input type="checkbox" checked=“true” name="stockid[<?php echo $row['pk_id']; ?>]" value="<?php echo $row['pk_id']; ?>" style="display:none;" />
                                        </tr>
                                        <?php $i++;
                                            } ?>
                                        <!-- // Table row END -->
                                    </tbody>
                                    <!-- // Table body END -->
                                    
                                </table>
                                <!-- // Table END --> 
                                </div>
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            <div class="form-group row">
                                                <!--<div class="col-md-12">-->
<!--                                                <div class="col-md-1">
                                                        <div class="control-group">
                                                            <br>
                                                <button type="submit" id="save" class="btn btn-success"> Save </button>
                                                
                                                    <a href="<?php echo base_url("inventory_management/gwis_physical_inspection?vouchertno=$issue_no&pkmasteridedit=$pkmasterides&edit=1"); ?> " class="btn btn-secondary" title="edit">Edit</a>
                                                    <a href="<?php echo base_url("inventory_management/gwis_physical_inspection?vouchertno=$issue_no&pkmasteridedit=$pkmasterides&edit=1"); ?> " class="btn btn-danger" title="cancel">Cancel</a>
                                                        </div>
                                                </div>-->
                                                    <br>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                                    <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="control-label" for="remarks"> Approver Remarks </label>
                                                            <div class="controls">
                                                                <textarea name="remarks" id="remarks" class="form-control" ></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="control-label" for="rec_ref"> Approver Receive Reference </label>
                                                            <div class="controls">
                                                                <input name="rec_ref" readonly id="rec_ref" type="text" class="form-control input-sm input-small" value="<?=$issue_no?>" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="control-label" for="rec_date"> Approver Receive Date </label>
                                                            <div class="controls">
                                                                <input name="rec_date" id="rec_date"  class="form-control input-sm input-small" value="<?php echo date("d/m/Y"); ?>" type="text" readonly />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="control-label">&nbsp;</label>
                                                        </div>
                                                        <div class="controls">
                                                            
                                                            <input type="hidden" name="stock_id" id="stock_id" value="<?php if(isset($stockID)) echo $stockID; ?>"/>
                                                            <input type="hidden" name="issue_no" id="issue_no" value="<?php echo $issue_no ?>">
                                                            <!-- <input type="hidden" name="pkmasterid" id="pkmasterid" value="<?php if(isset($_REQUEST['fkstockid']) && !empty($_REQUEST['fkstockid'])) { echo $_REQUEST['fkstockid'];}else { echo '';} ?>">  -->
                                                            <!-- <input type="hidden" name="pkdetailid" id="pkdetailid" value="<?php if(isset($_REQUEST['pkdetailid']) && !empty($_REQUEST['pkdetailid'])) { echo $_REQUEST['pkdetailid'];}else { echo '';} ?>"> -->
                                                            <!-- <input type="hidden" name="batchid" id="batchid" value="<?php if(isset($_REQUEST['batchid']) && !empty($_REQUEST['batchid'])) { echo $_REQUEST['batchid'];}else { echo '';} ?>">  -->
                                                          <?php  foreach($approval_codess as $approval_codes)
                                                            {?>
                                                            <input type="hidden" name="approvalcode[]" id="approvalcode" value="<?php if(isset($approval_codes) && !empty($approval_codes)) { echo $approval_codes;}else { echo '';} ?>"> 
                                                            <?php } foreach($approval_code_idd as $approval_code_id)
                                                            {?>
                                                            <input type="hidden" name="approval_code_id[]" id="approval_code_id" value="<?php if(isset($approval_code_id) && !empty($approval_code_id)) { echo $approval_code_id;}else { echo '';} ?>">
                                                            <?php } foreach($approve_fromm as $approve_from)
                                                            {?>
                                                            <input type="hidden" name="approve_from[]" id="approve_from" value="<?php if(isset($approve_from) && !empty($approve_from)) { echo $approve_from;}else { echo '';} ?>">
                                                            <?php } foreach($approve_too as $approve_to)
                                                            {?>
                                                            <input type="hidden" name="approve_to[]" id="approve_to" value="<?php if(isset($approve_to) && !empty($approve_to)) { echo $approve_to;}else { echo '';} ?>">
                                                            <?php } foreach($process_statuss as $process_status)
                                                            {?>
                                                            <input type="hidden" name="process_status[]" id="process_status" value="<?php if(isset($process_status) && !empty($process_status)) { echo $process_status;}else { echo '';} ?>">
                                                            <?php } foreach($final_statuss as $final_status)
                                                            {?>
                                                            <input type="hidden" name="final_status[]" id="final_status" value="<?php if(isset($final_status) && !empty($final_status)) { echo $final_status;}else { echo '';} ?>">
                                                            <?php } ?>
                                                        </div>
                                                    </div>
                                                    
                                                <!--</div>-->
                                            </div>
                                
                                            <div class="form-group row">
                                                <div class="col-md-12" style="text-align:center;">
                                                    <?php if (in_array("69", $approver_desg_id)){
                                                    ?>   
                                                    <a href="<?php echo base_url("inventory_management/gwis_physical_inspection?vouchertno=$issue_no&pkmasteridedit=$pkmasterides&edit=1"); ?> " class="btn btn-warning" title="edit">Edit Products / Items</a>
                                                    <button type="submit" id="save" class="btn btn-success"> Update </button>
                                                    <?php } else { ?>
                                                    <button type="submit" id="save" class="btn btn-success"> Save </button>
                                                    <?php } ?>
                                                    <a href="<?php echo base_url("dashboard/index"); ?> " class="btn btn-danger" title="cancel">Cancel</a>
                                                    <!--<button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" > Add Receiving</button>-->
                                                </div>  
                                                <?php if (isset($temp_records) && (!empty($temp_records))) {
                                                    ?>
                                                    <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>">
                                                     
                                                <?php }
                                                ?>    
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />
                                                
                                                
                                            </div>
                                        
                                        <?php if (in_array("69", $approver_desg_id)){ ?> 
                                            <div class="form-group row">
                                                <div class="col-md-6" style="width:90%;margin-right: 10px;margin-left: 30px;border: 1px solid #02AC7B;background-color: #DDFFDD">
                                                     <br><p style="font-size:12px;margin-left: 10px;"><b style="color:#02AC7B;font-size: 14px;">Note:</b>
                                                         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Products/Items can be deleted and added in edit mode.</p>
                                                </div>
                                            </div>
                                        <?php } ?>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </form>
                       <?php } else {
                           echo '<br>';
                           echo '<hr>';
                           echo '<h3>No Record Found</h3>';
                       }?>
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>
