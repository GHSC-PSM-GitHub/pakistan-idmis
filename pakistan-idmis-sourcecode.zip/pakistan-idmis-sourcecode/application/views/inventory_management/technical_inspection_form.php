<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
}
    
</style>
<?php
$from_id = '';
//print_r($tran_reference_number);exit;
if (isset($stock_master_records)) {
    $row = $stock_master_records[0];
    $refernce_number = $row['tran_ref'];
    $warehouse_from = $row['wh_id_from'];
    $warehouse_from_supplier = $row['wh_id_from_supplier'];
    
    //Check 
    $from_id = $row['wh_id_from'];
    $TranRef = $row['tran_ref'];
    
} else if (isset($tran_reference_number)) {

    $refernce_number = $tran_reference_number;
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="row">
                        <div class="col-md-12"><?php 
//                        if(isset($issueVoucher) && !empty($issueVoucher)) {
//                            echo 'Pending Vouchers are : ';
//                            echo implode(',', $issueVoucher);
//                            echo '<hr>';
//                        }
                        
//                        if(isset($getStockIssues) && !empty($getStockIssues)) {
                            
                            $issueVoucher = '';
                        $a='';
                           if ($getStockIssues) {

                               //fetch results
                               foreach ($getStockIssues AS $row)
                               {
                                   $a= " <a style='color:red;' href=\"technical_inspection_form?issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
                                   $issueVoucher[ $row['tran_no']] = $a;
                               }

//                           }
                            
                                echo '<table style="font-family: arial, sans-serif;border-collapse: collapse;width:100%"><tr><th style="border: 1px solid #dddddd;text-align: left;padding: 8px;width:20%;font-size:16px;">Pending Vouchers are : </th><td  style="border: 1px solid #dddddd;text-align: left;padding: 8px;text-decoration: underline;">';
                                echo implode(',', $issueVoucher);
                                echo '</td></table><hr>';
                            }
                         ?></div>
                    </div>
                    
                    <br>
                    
                    <div class="heading-buttons">
                        <h3>Technical Inspection Form</h3>

                    </div>
                    <div class="separator bottom"></div>
                    
                    <div class="innerLR">
                        
                        <form method="POST" name="batch_search" action="technical_inspection_form" >
                            <!-- Row -->
                            <?php 
                            //get e
                            if(isset($_GET['e'])){?>
                            <span style="padding-left:15px; color:#F00;">Please select at least one product by clicking checkboxes at right</span>
                            <?php }?>
                            
<!--                            <div class="col-md-3">
                                <div class="control-group">
                                    <label class="example-text-input" for="hf" required >Quantity <span style="color: red">*</span></label>
                                    <div class="controls">
                                        <input type="number" name="quantity" id="quantity" class="form-control"   required >
                                    </div>
                                </div>
                            </div>-->
                            
                            <div class="form-group row ">
                                <!--<div class="col-md-12">-->
                                    <div class="col-md-3"> 
                                        <!-- Group Receive No-->
                                        <div class="control-group">
                                            <label for="issue_no"> Issue No </label>
                                            <div class="controls">
                                            <input class="form-control" tabindex="1" id="issue_no" value="<?php if(isset($issue_no)) echo $issue_no; ?>" name="issue_no" type="text" required />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="control-group">
                                        <div class="input-group input-medium" style="margin-top: 21px;">
                                            <div class="controls">
                                            <button type="submit" class="btn btn-primary" name="search" value="Search"> Search </button>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                <!--</div>-->
                            </div>
                    </form>
                        
                       <?php if(isset($stockReceive)) { ?> 
                        <form method="post" id="delivery_challan" name="delivery_challan" action="<?php echo base_url("inventory_management/technical_inspection_form"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            

                                <table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable">
                                    
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th> Product Info</th>
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 
                                    
                                    <!-- Table body -->
                                    <tbody>
                                        <?php
                                        $i = 0;
                                        
                                            foreach ($stockReceive as $row) {
                                        if($i <= 0)
                                        {
                                                $stockID = $row['fk_stock_id'];
                                                $issuance_date = $row['tran_date'];
                                                ?>
                                        <tr>
                                            <?php if(empty($row['wh_from'])) { ?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">Supplier : </b>' .$row['wh_from_supplier'] . '<b style="font-weight: 900;margin-left: 30px;">Contact Person : </b>' .$row['contact_person'] .'<b style="font-weight: 900;margin-left: 30px;">Contact Number : </b>' .$row['contact_numbers']. 
                                                 '<br><br><b style="font-weight: 900;">Contact Email : </b>' .$row['contact_emails']. '<b style="font-weight: 900;margin-left: 30px;">Transfer Date : </b>' .$row['tran_date'].'<b style="font-weight: 900;margin-left: 30px;">Contact Address :</b> ' .$row['contact_address'];?>
                                            </td>
                                        </tr>
                                        <?php 
                                            } else{?>
                                            <td>
                                                <?php echo '<b style="font-weight: 900;">Warehouse : </b>' .$row['wh_from']; 
                                                 ?>
                                            </td>
                                            <?php  }
                                            $i++;
                                            }
                                        }
                                            ?>
                                    </tbody>
                                </table>    
                                            
                                            <!-- Table -->
                                <table class="table table-bordered table-condensed table-striped table-vertical-center checkboxs js-table-sortable">
                                    
                                    <!-- Table heading -->
                                    <thead>
                                        <tr>
                                            <th> Product </th>
                                            <th> Batch </th>
                                            <th> PO Quantity </th>
                                            <th> DC Quantity </th>
                                            <th> PI Quantity </th>
                                            <th> Remaining Quantity </th>
                                            <th> Technical Inspection Qty </th>
                                            <th> Comment</th>
                                            <!--<th> Adjustment Type</th>-->
                                            <th style="width: 1%;"> <input type="checkbox" id="checkAll" /></th>
                                        </tr>
                                    </thead>
                                    <!-- // Table heading END --> 
                                    
                                    <!-- Table body -->
                                    <tbody>
                                        <!-- Table row -->
                                        <?php
                                            $i = 1;
                                            foreach ($stockReceive as $row) {
                                                $stockID = $row['fk_stock_id'];
                                                $issuance_date = $row['tran_date'];
                                                ?>
                                        <tr>
                                            <td><?php echo $row['itm_name']; ?>
                                                <input type="hidden" id="<?php echo $i; ?>-qty" name='itm_id[<?php echo $row['itm_id']; ?>]' value="<?php echo $row['itm_name']; ?>" />    
                                            </td>
                                            <td><?php echo $row['batch_no']; ?>
                                                <input type="hidden" id="<?php echo $i; ?>-batch_no" name='batch_no[<?php echo $row['pk_id']; ?>]' value="<?php echo $row['batch_no']; ?>" />
                                            </td>
                                            <td class="right"><?php echo 0; ?></td>
                                            <td class="right"><?php echo number_format(abs($row['dc_quantity'])); ?>
                                                <input type="hidden" id="<?php echo $i; ?>-qty" name='dc_quantityy[<?php echo $row['pk_id']; ?>]' value="<?php echo abs($row['dc_quantity']); ?>" /></td>
                                            <td class="right"><?php echo number_format(abs($row['pi_quantity'])); ?>
                                                <input type="hidden" id="<?php echo $i; ?>-qty" name='pi_quantity[<?php echo $row['pk_id']; ?>]' value="<?php echo abs($row['pi_quantity']); ?>" /></td>
                                            <td class="right"><?php echo number_format(abs($row['quantity'])); ?>
                                                <input type="hidden" id="<?php echo $i; ?>-qty" name='dc_quantity[<?php echo $row['pk_id']; ?>]' value="<?php echo abs($row['quantity']); ?>" /></td>
                                            <td class="col-md-3"><input type="number" name="missing[<?php echo $row['pk_id']; ?>]" id="<?php echo $i; ?>-missing" value="" min="0" class="form-control input-sm input-small" /></td>
                                            <td class="col-md-3"><textarea name="comment[<?php echo $row['pk_id']; ?>]" id="<?php echo $i; ?>-comment" value='' class="form-control input-sm input-small" ></textarea></td>
                                            <!--<td class="col-md-3">-->
<!--                                                <select name="types[<?php echo $row['pk_id']; ?>]" id="<?php echo $i; ?>-types" class="form-control input-sm input-small types_select">
                                                    <?php
//                                                        if (!empty($types)) {
//                                                            
//                                                            foreach ($types as $type) {
//                                                                if($type->trans_id != 20 && $type->trans_id != 24)
//                                                                echo "<option value=" . $type->trans_id . ">" . $type->trans_type . "</option>";
//                                                            }
//                                                        }
                                                        ?>
                                                </select>-->
                                            <!--</td>-->
                                            <td class="center"><input type="checkbox" name="stockid[<?php echo $row['pk_id']; ?>]" value="<?php echo $row['pk_id']; ?>" /></td>
                                        </tr>
                                        <?php $i++;
                                            } ?>
                                        <!-- // Table row END -->
                                    </tbody>
                                    <!-- // Table body END -->
                                    
                                </table>
                                <!-- // Table END --> 
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            <div class="form-group row">
                                                <!--<div class="col-md-12">-->
                                                    <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="control-label" for="remarks"> Remarks </label>
                                                            <div class="controls">
                                                                <textarea name="remarks" id="remarks" class="form-control" ></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="control-label" for="rec_ref"> Receive Reference </label>
                                                            <div class="controls">
                                                                <input name="rec_ref" readonly id="rec_ref" type="text" class="form-control input-sm input-small" value="<?=$issue_no?>" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="control-group">
                                                            <label class="control-label" for="rec_date"> Receive Date </label>
                                                            <div class="controls">
                                                                <input name="rec_date" id="rec_date"  class="form-control input-sm input-small" value="<?php echo date("d/m/Y"); ?>" type="text" readonly />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-md-3 right">
                                                        <div class="control-group">
                                                            <label class="control-label">&nbsp;</label>
                                                        </div>
                                                        <div class="controls">
                                                            <button type="submit" id="save" class="btn btn-primary"> Save </button>
                                                            <input type="hidden" name="stock_id" id="stock_id" value="<?php if(isset($stockID)) echo $stockID; ?>"/>
                                                            <!--<input type="hidden" name="issue_no" id="issue_no" value="<?php echo $issue_no ?>">-->
                                                        </div>
                                                    </div>
                                                    
                                                <!--</div>-->
                                            </div>
                                
                                            <div class="form-group row">
<!--                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" > Add Receiving</button>
                                                </div>  -->
                                                <?php if (isset($temp_records) && (!empty($temp_records))) { ?>
                                                    <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>">
                                                <?php } ?>    
                                                    
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                       <?php } else {
                           echo '<br>';
                           echo '<hr>';
                           echo '<h3>No Record Found</h3>';
                       }?>
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>