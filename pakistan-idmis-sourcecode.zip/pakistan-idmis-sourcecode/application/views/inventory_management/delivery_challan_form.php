<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
}
    
</style>
<?php
$from_id = '';
//print_r($tran_reference_number);exit;
if (isset($stock_master_records)) {
    $row = $stock_master_records[0];
    $refernce_number = $row['tran_ref'];
    $supplier_from = $row['wh_id_from_supplier'];
    $warehouse_from_supplier = $row['wh_id_from_supplier'];
    $warehouse_from = $row['wh_id_from'];
    $warehouse_from_warehouse = $row['wh_id_from'];
    
    //Check 
//    $from_id = $row['wh_id_from'];
    $from_id = $row['source_type'];
    $TranRef = $row['tran_ref'];
    
} else if (isset($tran_reference_number)) {

    $refernce_number = $tran_reference_number;
}

// Change the line below to your timezone!
date_default_timezone_set('Asia/Karachi');
$receivedatetime = date('m/d/Y h:i:s a', time());
//$receivedatetime = date('m/d/Y H:i:s',strtotime(date(). ' '.date_default_timezone_set("Asia/Karachi"))); 

?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Delivery Challan Form</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="delivery_challan" name="delivery_challan" action="<?php echo base_url("inventory_management/delivery_challan_form"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row"> 
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="challan_number" required >DC Challan Number </label>
                                                        <div class="controls">
                                                            <input type="text" name="challan_number" id="challan_number" class="form-control" readonly value="Auto Generated" <?php if (isset($master_id)) echo 'readonly="true"' ?> 
                                                                <?php
//                                                                if (isset($refernce_number)) {
//                                                                    echo 'value="' . $refernce_number . '"';
//                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Receiving Date(MM/DD/YYYY) </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="receiving_time" id="stock_receiving_time" disabled value="<?php echo $receivedatetime; ?>" <?php if (isset($master_id)) echo 'disabled="true"' ?>>

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="challan_type" required >Delivery Challan Type <span style="color: red">*</span> </label>     
                                                        <div class="controls">
                                                            <?php
                                                        
                                                        if (isset($challan_type) && !empty($challan_type)) {
                                                            
                                                        ?>
                                                        <select class="select2me input-medium" name="challan_type" id="challan_type" style="width:100%;padding:10%;" <?php if (isset($master_id)) echo 'disabled="true"' ?> >
                                                            <option value="">Select</option>
                                                            <?php
                                                                                                                    
                                                            foreach ($challan_type as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($form['challan_type']) && $form['challan_type'] == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['challan_type'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                        <?php
                                                        }
                                                        if(isset($master_id)) { ?>
                                                            
                                                            <input type="hidden" class="form-control" name="challan_type" id="challan_type" value="<?php if (isset($form['challan_type'])) echo $form['challan_type']; ?>" >
                                                            
                                                        <?php } ?>

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3" id="po_type_detail" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="po_detail_info" required >PO# <span style="color: red">*</span> </label>     
                                                        <div class="controls">
                                                            <input type="text"  name="po_detail_info" id="po_detail_info" class="form-control"   <?php if (isset($master_id)) echo 'readonly="true"' ?>
                                                                <?php
                                                                if (isset($form['po_detail_info'])) {
                                                                    echo 'value="' . $form['po_detail_info'] . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </select>

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3" id="fo_type_detail" style="display:none;">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="wh_detail_info" required >WH# <span style="color: red">*</span> </label>     
                                                        <div class="controls">
                                                            <input type="text"  name="wh_detail_info" id="wh_detail_info" class="form-control" <?php if (isset($master_id)) echo 'readonly="true"' ?>    
                                                                <?php
                                                                if (isset($form['wh_detail_info'])) {
                                                                    echo 'value="' . $form['wh_detail_info'] . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </select>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row"> 
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Reference No / Official Letter No </label>
                                                        <div class="controls">
                                                            <input type="text" name="refernce_number" id="reference_number" class="form-control" 
                                                                <?php
                                                                if (isset($refernce_number)) {
                                                                    echo 'value="' . $refernce_number . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3" style="display:none;" id="show_receive_from_supplier" >
                                                    <label class="example-text-input" for="strength" required >Received From (Supplier)<span style="color: red">*</span> <?=(empty($temp_records) ) ? '<a class="btn btn-sm btn-primary" href="../warehouse_management/add_supplier">+</a>':''?></label>
                                                    <div class="controls">
                                                        <?php
                                                        
                                                        if (empty($temp_records)) {
                                                            
                                                        ?>
                                                        <select class="select2me input-medium" name="receive_from_supplier" id="receive_from_supplier" style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                                                                                    
                                                            foreach ($suppliers as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['wh_id'] ?>" <?php if (isset($supplier_from) && $supplier_from == $row['wh_id']) echo "selected='selected'"; ?>><?php echo $row['wh_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                        <?php
                                                        }else
                                                        {
                                                            foreach ($suppliers as $row) {
//                                                                if(isset($warehouse_from) && $warehouse_from == $row['stkid']) echo  '<input class="form-control" disabled value="'.$row['stkname'].'">';
                                                                if(isset($warehouse_from_supplier) && $warehouse_from_supplier == $row['wh_id']) echo  '<input class="form-control" disabled value="'.$row['wh_name'].'">';                                                                
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3" id="show_receive_from_warehouse" style="display:none;" >
                                                    <label class="example-text-input" for="receive_from_warehouse" required >Received From (Warehouse)<span style="color: red">*</span> <?=(empty($temp_records) ) ? '<a class="btn btn-sm btn-primary" href="../warehouse_management/add_warehouse">+</a>':''?></label>
                                                    <div class="controls">
                                                        <?php
                                                        
                                                        if (empty($temp_records)) {
                                                            
                                                        ?>
                                                        <select class="select2me input-medium" name="receive_from_warehouse" id="receive_from_warehouse"  style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                                                                                    
                                                            foreach ($warehouses as $row) {
                                                                ?>
                                                                <option value="<?php echo $row['wh_id'] ?>" <?php if (isset($warehouse_from) && $warehouse_from == $row['wh_id']) echo "selected='selected'"; ?>><?php echo $row['wh_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                        <?php
                                                        }else
                                                        {
                                                            foreach ($warehouses as $row) {
//                                                                if(isset($warehouse_from) && $warehouse_from == $row['stkid']) echo  '<input class="form-control" disabled value="'.$row['stkname'].'">';
                                                                if(isset($warehouse_from_warehouse) && $warehouse_from_warehouse == $row['wh_id']) echo  '<input class="form-control" disabled value="'.$row['wh_name'].'">';                                                                
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Product<span style="color: red">*</span> <?=(empty($temp_records) ) ? '<a class="btn btn-sm btn-primary" href="../product_management/add">+</a>':''?></label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="product" id="product" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                                <?php
                                                                foreach ($product as $row) {
                                                                    ?>
                                                                <option value="<?php echo $row['itm_id'] ?>" <?php if (isset($product_id) && $product_id == $row['itm_id']) echo "selected='selected'"; ?>><?php echo $row['itm_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="registration_number" required >Batch Number<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="batch_number" id="batch_number" class="form-control"  required>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div> 
                                            
<!--                                            <div class="form-group row m-b-0" id="msg_shelf">
                                                <div class="alert alert-danger alert-dismissiblex fade show" role="alert">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button> <span id="msg_shelf_text">Attention: The Batch must have shelf life of at least 85% , as per instructions from DRAP.</span>
                                                </div>
                                            </div>-->
                                            <div class="form-group row">
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Manufacturing Date(MM/DD/YYYY) <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" name="manufacturing_date" id="manufacturing_date" class="form-control"   required value="<?php echo date("m/d/Y"); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Expiry Date(MM/DD/YYYY) <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" name="expiry_date" id="expiry_date" class="form-control"   required value="<?php echo date("m/d/Y"); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="quantity" id="quantity" class="form-control"   required >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Remarks</label>
                                                        <div class="controls">
                                                            <textarea name="remarks" id="remarks" class="form-control" ></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                
                                                
                                                <div class="col-md-6" id="supplier_info" style="display:none;background-color: #e3f4eb;">
                                                    <div class="control-group">
                                                        <h3 style="color:#2A3988;">Supplier Details</h3>
                                                        <div class="form-group row">
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-4 col-form-label">Contact Person : </label>
                                                            <div class="col-sm-8">
                                                              <input type="text" readonly class="form-control-plaintext" id="contact_person" value="">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-4 col-form-label">Contact Numbers: </label>
                                                            <div class="col-sm-8">
                                                              <input type="text" readonly class="form-control-plaintext" id="contact_number" value="">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-4 col-form-label">Contact Email : </label>
                                                            <div class="col-sm-8">
                                                              <input type="text" readonly class="form-control-plaintext" id="contact_email" value="">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-4 col-form-label">Address : </label>
                                                            <div class="col-sm-8">
                                                                <textarea type="text" readonly class="form-control-plaintext" id="address" value=""></textarea>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                    </div>
                                                </div>
                                                
                                            </div>

                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" > Add Receiving</button>
                                                </div>  
<?php if (isset($temp_records) && (!empty($temp_records))) {
    ?>
                                                    <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>"> 
                                                <?php }
                                                ?>    
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <br>
                            <!--<div id="dc_result">-->
<?php
if (isset($temp_records) && (!empty($temp_records))) {
    ?>
                            
                                <div id="dc_result">
                                    <table class="table table-striped table-bordered table-condensed dt-responsive " >
                                        <thead>
                                            <tr>
                                                <th style="width: 1%;" class="center">No.</th>
                                                <th>Supplier</th>
                                                <th>Product Name</th>  
                                                <!--<th>Manufacturer</th>-->
                                                <th>Batch Number</th>
                                                <th>Expiry Date</th> 
                                                <th>Quantity</th> 
                                                <th>Action</th>  
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- Table row -->
    <?php
    $count = 1;
    foreach ($temp_records->result_array() as $row) {
        ?>
                                                <tr>
                                                    <td class="center"><?php echo $count; ?></td>
                                                    <td class="important"><?php if(isset($row['wh_from']) && !empty($row['wh_from'])) { echo $row['wh_from']; } else {echo $row['wh_from_supplier'];}?></td>
                                                    <td><?php echo $row['product_name']; ?></td> 
                                                    <!--<td class="important"><?php echo $row['manufacturer']; ?></td>-->
                                                    <td class="important"><?php echo $row['batch_no']; ?></td>
                                                    <td class="important"><?php echo $row['batch_expiry']; ?></td> 
                                                    <td class="important"><?php echo $row['quantity']; ?></td> 

                                                    <td>  
                                                      <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row['pk_id']."_".$row['fk_stock_id']; ?>-deletedc">
                                                          <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Delete
                                                      </button>  
                                                    <!--<a onclick="return confirm('Are you sure you want to Delete?');" href="<?php echo base_url("inventory_management/delete?id=") . $row['pk_id']; ?>&status=1" class="btn btn-sm btn-light glyphicons bin" > Delete</a>-->
                                                    </td> 
                                                </tr>
        <?php
        $count++;
    }
    ?>
                                            <!-- // Table row END -->
                                            <!-- Table row -->

                                            <!-- // Table row END -->
                                        </tbody>
                                    </table> 
                                </div>
                            
                                <button type="button" id="dc_save_temp_receive" name="save_temp_receive" class="btn btn-primary waves-effect waves-light" style="margin-left:90%;">Save</button>

                                <!-- // Table END -->
    <?php
}
?>
                            <!--</div>-->
                        </form>
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>