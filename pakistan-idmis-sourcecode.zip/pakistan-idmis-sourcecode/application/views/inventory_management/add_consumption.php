<?php
// print_r($_SESSION['stakeholder_id']);exit;
if ($_SESSION['stakeholder_id'] == 1682) {
    ?>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-12"> 
                        <div class="separator bottom"></div>
                        <div class="heading-buttons">
                            <h3 class="text-info">Consumption Data Entry (<?php echo date_format(new DateTime($rdate), 'M-Y'); ?>)</h3>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
            <form name="frmF7" id="frmF7" method="post" action='<?php echo base_url() . 'Dataentry2/insert_data'; ?>'>
                <div class="portlet box green">
                    <div class="portlet-body">
                        <table class="table table-bordered table-hover">
                            <thead>    <tr class="table-primary">
                                    <th rowspan="2" class="text-center">S.No.</th>
                                    <th rowspan="2" class="text-center">Article</th>
                                    <th rowspan="2" class="text-center">Opening balance</th>
                                    <th class="text-center">Received</th>                    
                                    <th rowspan="2" class="text-center">Issued</th>
                                    <th colspan="2" class="text-center">Adjustments</th>
                                    <th rowspan="2" class="text-center">Closing Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 1;
                                foreach ($data3 as $d) {

                                    if ($rdate == '2022-01-01') {
                                        $readonly = "";
                                    } else {
                                        $readonly = "readonly=''";
                                    }
                                    ?>
                                    <tr>
                                        <td class="text-center" title=""><?php echo $count++; ?></td>
                                        <td><?php echo $d['itm_name'] ?>
                                            <input type="hidden" name="flitmrec_id[]" value="<?php echo $d['itm_id']; ?>">
                                            <input type="hidden" name="flitmname<?php echo $d['itm_id']; ?>" value="<?php echo $d['itm_name']; ?>">
                                        </td>
                                        <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" onchange="Calculate();" name="ob[<?php echo $d['itm_id']; ?>]" id="FLDOBLA<?php echo $d['itm_id']; ?>" size="8" maxlength="10"  value="<?php echo (!empty($result[$d['itm_id']]['opening_balance']) ? $result[$d['itm_id']]['opening_balance'] : (!empty($item_opening_balances[$d['itm_id']]) ? $item_opening_balances[$d['itm_id']] : '0')); ?>" onfocusout="cal_balance(<?php echo $d['itm_id']; ?>)" <?php echo $readonly; ?>></td>
                                        <td><input class="form-control input-sm text-right"  autocomplete="off"  type="text" onchange="Calculate();" name="rcv[<?php echo $d['itm_id']; ?>]" id="FLDRecv<?php echo $d['itm_id']; ?>" size="8" maxlength="10"  value="<?php echo (!empty($result[$d['itm_id']]['received_balance']) ? $result[$d['itm_id']]['received_balance'] : (!empty($item_received_balances[$d['itm_id']]) ? $item_received_balances[$d['itm_id']] : '0')); ?>" onfocusout="cal_balance(<?php echo $d['itm_id']; ?>)"></td>
                                        <td><input class="form-control input-sm text-right" autocomplete="off" onchange="Calculate();" name="iss[<?php echo $d['itm_id']; ?>]" id="FLDIsuueUP<?php echo $d['itm_id']; ?>" value="<?php echo (!empty($result[$d['itm_id']]['issue_balance']) ? $result[$d['itm_id']]['issue_balance'] : '0') ?>" type="text" size="8" maxlength="10" onfocusout="cal_balance(<?php echo $d['itm_id']; ?>)"></td>
                                        <td><input class="form-control input-sm text-right" autocomplete="off"  onchange="Calculate();" type="text" name="adja[<?php echo $d['itm_id']; ?>]" id="FLDReturnTo<?php echo $d['itm_id']; ?>" size="8" maxlength="10" value="<?php echo (!empty($result[$d['itm_id']]['adjustment_positive']) ? $result[$d['itm_id']]['adjustment_positive'] : '0') ?>" onfocusout="cal_balance(<?php echo $d['itm_id']; ?>)"></td>
                                        <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" onchange="Calculate();" name="adjb[<?php echo $d['itm_id']; ?>]" id="FLDUnusable<?php echo $d['itm_id']; ?>" size="8" maxlength="10" value="<?php echo (!empty($result[$d['itm_id']]['adjustment_negative']) ? $result[$d['itm_id']]['adjustment_negative'] : '0') ?>" onfocusout="cal_balance(<?php echo $d['itm_id']; ?>)"></td>
                                        <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" name="cb[<?php echo $d['itm_id']; ?>]" id="FLDCBLA<?php echo $d['itm_id']; ?>" size="8" maxlength="10" value="<?php echo (!empty($result[$d['itm_id']]['closing_balance']) ? $result[$d['itm_id']]['closing_balance'] : '0'); ?>" readonly=""></td>
                                    </tr>
                                <?php }
                                ?>
                            </tbody>
                        </table>
                        <div class="col-md-2 text-right">
                            <input id="wh_id" name="wh_id" type="hidden" value="<?php echo $wh_id; ?>">
                            <input id="rdate" name="rdate" type="hidden" value="<?php echo $rdate; ?>">
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <script>
        function Calculate()
        {
            var ob1 = parseInt(document.getElementById('ob').value);
            var rcv1 = parseInt(document.getElementById('rcv').value);
            var iss1 = parseInt(document.getElementById('iss').value);
            var adja = parseInt(document.getElementById('adja').value);
            var adjb = parseInt(document.getElementById('adjb').value);
            var add = ob1 + rcv1 - iss1 + adja - adjb;
            document.getElementById('cb').value = add;
        }
    </script>
    <div class="wrapper">
        <div class="container-fluid">
            <h2 class="text-info">Monthly Cascade of care/cure (<?php echo date_format(new DateTime($rdate), 'M-Y'); ?>)</h2>
            <table class="table table-bordered table-responsive table-condensed text-center caption-top">
                <tr class="table-primary">
                    <th colspan="5">
                        Screening and Testing (diagnosis) 
                    </th>
                    <th colspan="4">
                        Treatment initiation and continuation 
                    </th>
                    <th colspan="2">
                        Monitoring of treatment effectiveness [C8] 
                    </th>
                    <th colspan="3">
                        Mortality from sequelae
                    </th>
                </tr>
                <tr class="table-secondary">
                    <td rowspan="2">Treatment</td>
                    <td rowspan="2">
                        Number of persons screened (HBsAg/anti-HCV) in reporting month
                    </td>
                    <td rowspan="2">
                        Number of screened positive
                    </td>
                    <td rowspan="2">
                        Number of persons tested for Disease Confirmation
                    </td>
                    <td rowspan="2">
                        Number of confirmed patients
                    </td>
                    <td rowspan="2">
                        Number of persons continuing a treatment started before reporting month
                    </td>
                    <td colspan="2">
                        Number of persons newly started on treatment in reporting month
                    </td>
                    <td rowspan="2">
                        Number of persons completing treatment  
                    </td>
                    <td rowspan="2">
                        Number of persons tested for SVR
                    </td>
                    <td rowspan="2">
                        Number of persons cured
                    </td>
                    <td rowspan="2">
                        Proportion of cirrhosis deaths with viral hepatitis infection <h6>(%)</h6>
                    </td>
                    <td rowspan="2">
                        Proportion of hepatocellular carcinoma deaths with viral hepatitis infection<h6>(%)</h6>
                    </td>
                </tr>
                <tr>
                    <td>
                        General Population
                    </td>
                    <td>
                        Among key populations (FSW, TGs,MSM, PWID)
                    </td>
                </tr>
                <tr class="table-success">
                    <td>
                        HBV
                    </td>
                    <td>
                        <input type="number" class="form-control"> 
                    </td>
                    <td>
                        <input type="number" class="form-control"> 
                    </td>
                    <td>
                        <input type="number" class="form-control"> 
                    </td>
                    <td>
                        <input type="number" class="form-control"> 
                    </td>
                    <td>
                        <input type="text" class="form-control" value="0" readonly> 
                    </td>
                    <td>
                        <input type="number" class="form-control">
                    </td>
                    <td>
                        <input type="number" class="form-control">
                    </td>
                    <td>
                        N/A
                    </td>
                    <td>
                        N/A
                    </td>
                    <td>
                        N/A
                    </td>
                    <td>
                        <input type="number" class="form-control">
                    </td>
                    <td>
                        <input type="number" class="form-control">
                    </td>
                </tr>
                <tr class="table-success">
                    <td>
                        HCV
                    </td>
                    <td>
                        <input type="number" class="form-control">
                    </td>
                    <td>
                        <input type="number" class="form-control">
                    </td>
                    <td>
                        <input type="number" class="form-control">
                    </td>
                    <td>
                        <input type="number" class="form-control">
                    </td>
                    <td>
                        <input type="text" class="form-control" value="0" readonly>
                    </td>
                    <td>
                        <input type="number" class="form-control">
                    </td>
                    <td>
                        <input type="number" class="form-control">
                    </td>
                    <td>
                        <input type="number" class="form-control">
                    </td>
                    <td>
                        <input type="number" class="form-control">
                    </td>
                    <td>
                        <input type="number" class="form-control">
                    </td>
                    <td>
                        <input type="number" class="form-control">
                    </td>
                    <td>
                        <input type="number" class="form-control">
                    </td>
                </tr>
            </table>
        </div>
        <div class="col-md-2 text-right">
            <input class="btn btn-primary" id="saveBtn" name="saveBtn" type="submit" value="Save" onClick="return formvalidate1()">
            <button class="btn btn-info" type="submit" onclick="document.frmF7.reset()"> Reset </button>
        </div>
    </div>

<?php } else { ?>

    <div class="wrapper">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-12"> 
                        <div class="separator bottom"></div>
                        <div class="heading-buttons">
                            <h3>Consumption Data Entry</h3>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
            <form name="frmF7" id="frmF7" method="post" action='<?php echo base_url() . 'Dataentry2/insert_data'; ?>'>
                <div class="portlet box green">
                    <div class="portlet-body">
                        <table class="table table-bordered table-hover">
                            <thead>    <tr>
                                    <th rowspan="3" class="text-center">S.No.</th>
                                    <th rowspan="3" class="text-center">Article</th>
                                    <th rowspan="3" class="text-center">Opening balance</th>
                                    <th rowspan="3" class="text-center">Received</th>                    
                                    <th rowspan="3" class="text-center">Issued</th>
                                    <th colspan="2" class="text-center">Adjustments</th>
                                    <th rowspan="3" class="text-center">Closing Balance</th>
                                </tr>
                                <tr>
                                    <th class="text-center">+</th>
                                    <th class="text-center">-</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 1;
                                foreach ($data3 as $d) {

                                    if ($rdate == '2022-08-01') {
                                        $readonly = "";
                                    } else {
                                        $readonly = "readonly=''";
                                    }
                                    ?>
                                    <tr>
                                        <td class="text-center" title=""><?php echo $count++; ?></td>
                                        <td><?php echo $d['itm_name'] ?>
                                            <input type="hidden" name="flitmrec_id[]" value="<?php echo $d['itm_id']; ?>">
                                            <input type="hidden" name="flitmname<?php echo $d['itm_id']; ?>" value="<?php echo $d['itm_name']; ?>">
                                        </td>
                                        <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" onchange="Calculate();" name="ob[<?php echo $d['itm_id']; ?>]" id="FLDOBLA<?php echo $d['itm_id']; ?>" size="8" maxlength="10"  value="<?php echo (!empty($result[$d['itm_id']]['opening_balance']) ? $result[$d['itm_id']]['opening_balance'] : (!empty($item_opening_balances[$d['itm_id']]) ? $item_opening_balances[$d['itm_id']] : '0')); ?>" onfocusout="cal_balance(<?php echo $d['itm_id']; ?>)" <?php echo $readonly; ?>></td>
                                        <td><input class="form-control input-sm text-right"  autocomplete="off"  type="text" onchange="Calculate();" name="rcv[<?php echo $d['itm_id']; ?>]" id="FLDRecv<?php echo $d['itm_id']; ?>" size="8" maxlength="10"  value="<?php echo (!empty($result[$d['itm_id']]['received_balance']) ? $result[$d['itm_id']]['received_balance'] : (!empty($item_received_balances[$d['itm_id']]) ? $item_received_balances[$d['itm_id']] : '0')); ?>" onfocusout="cal_balance(<?php echo $d['itm_id']; ?>)"></td>
                                        <td><input class="form-control input-sm text-right" autocomplete="off" onchange="Calculate();" name="iss[<?php echo $d['itm_id']; ?>]" id="FLDIsuueUP<?php echo $d['itm_id']; ?>" value="<?php echo (!empty($result[$d['itm_id']]['issue_balance']) ? $result[$d['itm_id']]['issue_balance'] : '0') ?>" type="text" size="8" maxlength="10" onfocusout="cal_balance(<?php echo $d['itm_id']; ?>)"></td>
                                        <td><input class="form-control input-sm text-right" autocomplete="off"  onchange="Calculate();" type="text" name="adja[<?php echo $d['itm_id']; ?>]" id="FLDReturnTo<?php echo $d['itm_id']; ?>" size="8" maxlength="10" value="<?php echo (!empty($result[$d['itm_id']]['adjustment_positive']) ? $result[$d['itm_id']]['adjustment_positive'] : '0') ?>" onfocusout="cal_balance(<?php echo $d['itm_id']; ?>)"></td>
                                        <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" onchange="Calculate();" name="adjb[<?php echo $d['itm_id']; ?>]" id="FLDUnusable<?php echo $d['itm_id']; ?>" size="8" maxlength="10" value="<?php echo (!empty($result[$d['itm_id']]['adjustment_negative']) ? $result[$d['itm_id']]['adjustment_negative'] : '0') ?>" onfocusout="cal_balance(<?php echo $d['itm_id']; ?>)"></td>
                                        <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" name="cb[<?php echo $d['itm_id']; ?>]" id="FLDCBLA<?php echo $d['itm_id']; ?>" size="8" maxlength="10" value="<?php echo (!empty($result[$d['itm_id']]['closing_balance']) ? $result[$d['itm_id']]['closing_balance'] : '0'); ?>" readonly=""></td>
                                    </tr>
                                <?php }
                                ?>
                            </tbody>
                        </table>
                        <div class="col-md-2 text-right">
                            <input id="wh_id" name="wh_id" type="hidden" value="<?php echo $wh_id; ?>">
                            <input id="rdate" name="rdate" type="hidden" value="<?php echo $rdate; ?>">
                            <input class="btn btn-primary" id="saveBtn" name="saveBtn" type="submit" value="Save" onClick="return formvalidate1()">
                            <button class="btn btn-info" type="submit" onclick="document.frmF7.reset()"> Reset </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <script>
        function Calculate()
        {
            var ob1 = parseInt(document.getElementById('ob').value);
            var rcv1 = parseInt(document.getElementById('rcv').value);
            var iss1 = parseInt(document.getElementById('iss').value);
            var adja = parseInt(document.getElementById('adja').value);
            var adjb = parseInt(document.getElementById('adjb').value);
            var add = ob1 + rcv1 - iss1 + adja - adjb;
            document.getElementById('cb').value = add;
        }
    </script>
<?php } ?>