<?php // print_r($data3);exit;  ?>
<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Consumption Data Entry</h3>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
        <form name="frmF7" id="frmF7" method="post" action='<?php echo base_url().'Dataentry2/insert_data_dist'; ?>'>
        <div class="portlet box green">
            <div class="portlet-body">
                <table class="table table-bordered table-hover">
                    <thead>    <tr>
                            <th rowspan="2" class="text-center">S.No.</th>
                            <th rowspan="2" class="text-center">Article</th>
                            <th rowspan="2" class="text-center">Opening balance</th>
                            <th class="text-center">Received</th>                    
                            <th rowspan="2" class="text-center">Issued</th>
                            <th colspan="2" class="text-center">Adjustments</th>
                            <th rowspan="2" class="text-center">Closing Balance</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $count = 1;
                        foreach ($data3 as $d) {
                            ?>
                            <tr>
                                <td class="text-center" title=""><?php echo $count++; ?></td>
                                <td><?php echo $d['itm_name'] ?></td>
                                <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" name="ob" id="ob" size="8" maxlength="10"  value="" onfocusout=""></td>
                                <td><input class="form-control input-sm text-right"  autocomplete="off"  type="text" name="rc" id="rc" size="8" maxlength="10"  value="" onfocusout=""></td>
                                <td><input class="form-control input-sm text-right" autocomplete="off" name="iss" id="iss" value="" type="text" size="8" maxlength="10" onfocusout=""></td>
                                <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" name="adja" id="adja" size="8" maxlength="10" value="" onfocusout=""></td>
                                <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" name="adjb" id="adjb" size="8" maxlength="10" value="" onfocusout=""></td>
                                <td><input class="form-control input-sm text-right" autocomplete="off"  type="text" name="cb" id="cb" size="8" maxlength="10" value="" readonly="readonly"></td>
                            </tr>
                        <?php }
                        ?>
                    </tbody>
                </table>
                <div class="col-md-2 text-right">
                    <input class="btn btn-primary" id="saveBtn" name="saveBtn" type="submit" value="Save">
                    <button class="btn btn-info" type="submit" onclick="document.frmF7.reset()"> Reset </button>
                </div>
            </div>
        </div>
        </form>
    </div>
</div>