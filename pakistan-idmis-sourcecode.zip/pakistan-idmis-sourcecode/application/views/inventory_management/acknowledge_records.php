<div class="wrapper">
    <div class="container-fluid">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3>Pending Stock Received</h3>

                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                    <div class="innerLR">
                        <br>
                        <?php
//                        print_r($_SESSION);exit;
                        if (isset($result)&&!empty($result)) {
                            ?>

                            <div id="divToPrint">
                                <form method="post" id="stock_issue" name="stock_issue" action="<?php echo base_url("inventory_management/issue_to_receive"); ?>">
                                    <table class="table table-striped table-bordered table-condensed dt-responsive nowrap" id="datatable-buttons">
                                        <thead>
                                            <tr>
                                                <th style="width: 1%;" class="center">No.</th>
                                                <th>Transaction Number</th>
                                                <th>Item / Product</th> 
                                                <th>Issuance Date</th> 
                                                <th>Reference Number</th>
                                                <th>Issued By</th>
                                                <th>Batch</th>
                                                <th>Quantity</th>
                                                <th>Action</th>  
                                            </tr>
                                        </thead>

                                        <tbody>

                                            <!-- Table row -->
                                            <?php
                                            $count = 1;
                                            foreach ($result->result_array() as $row) {
                                                ?>
                                                <tr>
                                                    <td class="center"><?php echo $count; ?></td>
                                                    <td class=""><?php echo "I-" . sprintf('%04d', $row['pk_id']); ?></td>
                                                    <td class=""><?php echo $row['product_name']; ?></td> 
                                                    <td class=""><?php echo $row['transaction_date']; ?></td> 
                                                    <td class=""><?php echo $row['transaction_reference']; ?></td>
                                                    <td class=""><?php echo ($row['warehouse_name']); ?></td>
                                                    <td class=""><?php echo ($row['batch_number']); ?></td>
                                                    <td class="" align="right"><?php echo number_format(abs($row['quantity'])); ?></td>

                                                    <td>  
                                                        <input type="checkbox" name="approved[]" value="<?php echo $row['pk_id'] ?>" class="check_box_indi">
                                                    </td> 
                                                </tr>
                                                <?php
                                                $count++;
                                            }
                                            ?>
                                            <!-- // Table row END -->
                                            <!-- Table row -->

                                            <!-- // Table row END -->

                                        </tbody>
                                    </table> 
                                    <div class="form-group row">
                                        <div class="col-md-10">
                                        </div>
                                        <div class="col-md-2">
                                            <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" > Approve Records</button>

                                        </div>
                                    </div>
                                </form>
                            </div>

                            <!-- // Table END -->
                            <?php
                        } else {
                            echo "<hr><h5>No data found!</h5>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>