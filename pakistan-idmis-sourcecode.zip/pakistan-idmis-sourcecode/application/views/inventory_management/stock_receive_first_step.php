<style>
    
    .datepicker.dropdown-menu {
    z-index: 9999 !important;
}
    
</style>
<?php
//print_r($tran_reference_number);exit;
if (isset($stock_master_records)) {
    $row = $stock_master_records[0];
    $refernce_number = $row['TranRef'];
    $warehouse_from = $row['WHIDFrom'];
} else if (isset($tran_reference_number)) {

    $refernce_number = $tran_reference_number;
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Stock Receive</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="stock_receive" name="stock_receive" action="<?php echo base_url("inventory_management/stock_receive"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row"> 
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Reference Number  </label>
                                                        <div class="controls">
                                                            <input type="text" name="refernce_number" id="reference_number" class="form-control" required  <?php if (isset($master_id)) echo 'readonly="true"' ?> 
                                                                <?php
                                                                if (isset($refernce_number)) {
                                                                    echo 'value="' . $refernce_number . '"';
                                                                }
                                                                ?>
                                                                   >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Receiving Date(MM/DD/YYYY) <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="receiving_time" id="stock_receiving_time" required value="<?php echo date("m/d/Y"); ?>" <?php if (isset($master_id)) echo 'readonly="true"' ?>>

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Document Type <span style="color: red">*</span> <?=(empty($temp_records) ) ? '<a class="btn btn-sm btn-primary" href="../stock_document_type_mang/add">Add New</a>':''?></label>                                                      <div class="controls">
                                                            <select name="document_type" id="document_type" required class="select2me input-medium" style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                                <?php
                                                                foreach ($document_type as $row) {
                                                                    ?>
                                                                <option value="<?php echo $row['pk_id'] ?>" <?php if (isset($product_id) && $product_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['document_type'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Document No <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="document_no" id="document_no" class="form-control"  required>
                                                        

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row"> 
                                                <div class="col-md-3" style="">
                                                    <label class="example-text-input" for="strength" required >Received From (Supplier)<span style="color: red">*</span> <?=(empty($temp_records) ) ? '<a class="btn btn-sm btn-primary" href="../warehouse_management/add_supplier">Add New</a>':''?></label>
                                                    <div class="controls">
                                                        <?php
                                                        
                                                        if (empty($temp_records)) {
                                                            
                                                        ?>
                                                        <select class="select2me input-medium" name="received_from" id="received_from" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <?php
                                                                                                                    
foreach ($suppliers as $row) {
    ?>
                                                                <option value="<?php echo $row['stkid'] ?>" <?php if (isset($warehouse_from) && $warehouse_from == $row['stkid']) echo "selected='selected'"; ?>><?php echo $row['stkname'] ?></option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>  
                                                        <?php
                                                        }else
                                                        {
                                                            foreach ($suppliers as $row) {
                                                                if(isset($warehouse_from) && $warehouse_from == $row['stkid']) echo  '<input class="form-control" disabled value="'.$row['stkname'].'">';
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Status <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <select name="status" id="status" required class="select2me input-medium" style="width:100%;padding:10%;">
                                                            <option value="" selected="selected">Select</option>
                                                            <option value="1">Active</option>
                                                        </select>

                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Status Date(MM/DD/YYYY) <span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" class="form-control" name="status_date" id="status_date" required value="<?php echo date("m/d/Y"); ?>" <?php if (isset($master_id)) echo 'readonly="true"' ?>>

                                                        </div>

                                                        </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Product<span style="color: red">*</span> <?=(empty($temp_records) ) ? '<a class="btn btn-sm btn-primary" href="../product_management/add">Add New</a>':''?></label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="product" id="product" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                                <?php
                                                                foreach ($product as $row) {
                                                                    ?>
                                                                <option value="<?php echo $row['itm_id'] ?>" <?php if (isset($product_id) && $product_id == $row['itm_id']) echo "selected='selected'"; ?>><?php echo $row['itm_name'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>
                                                
                                            </div> 
                                            
<!--                                            <div class="form-group row m-b-0" id="msg_shelf">
                                                <div class="alert alert-danger alert-dismissiblex fade show" role="alert">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button> <span id="msg_shelf_text">Attention: The Batch must have shelf life of at least 85% , as per instructions from DRAP.</span>
                                                </div>
                                            </div>-->
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="registration_number" required >Batch Number<span style="color: red">*</span> </label>
                                                        <div class="controls">
                                                            <input type="text" name="batch_number" id="batch_number" class="form-control"  required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Manufacturing Date(MM/DD/YYYY) <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" name="manufacturing_date" id="manufacturing_date" class="form-control"   required value="<?php echo date("m/d/Y"); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Expiry Date(MM/DD/YYYY) <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" name="expiry_date" id="expiry_date" class="form-control"   required value="<?php echo date("m/d/Y"); ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="quantity" id="quantity" class="form-control"   required >
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >MCC Year <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <select class="form-control" id="mcc_year" name="mcc_year" required>
                                                                <?php
                                                                for ($y = date("Y"); $y >= 1980 ; $y--) { 
                                                                    ?>
                                                                    <option value="<?php echo $y; ?>"><?php echo $y; ?></option>
                                                                <?php } ?>
                                                            </select>                                                        
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Physical Inspection <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" name="physical_inspection" id="physical_inspection" class="form-control"   required >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Technical Inspection <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="text" name="technical_inspection" id="technical_inspection" class="form-control"   required >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Physical Inspection Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="physical_inspection_qty" id="physical_inspection_qty" class="form-control"   required >
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Technical Inspection Quantity <span style="color: red">*</span></label>
                                                        <div class="controls">
                                                            <input type="number" name="technical_inspection_qty" id="technical_inspection_qty" class="form-control"   required >
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="control-group">
                                                        <label class="example-text-input" for="hf" required >Remarks</label>
                                                        <div class="controls">
                                                            <textarea name="remarks" id="remarks" class="form-control" ></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="col-md-6" id="supplier_info" style="display:none;background-color: #e3f4eb;">
                                                    <div class="control-group">
                                                        <h3 style="color:#2A3988;">Supplier Details</h3>
                                                        <div class="form-group row">
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-4 col-form-label">Contact Person : </label>
                                                            <div class="col-sm-8">
                                                              <input type="text" readonly class="form-control-plaintext" id="contact_person" value="">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-4 col-form-label">Contact Numbers: </label>
                                                            <div class="col-sm-8">
                                                              <input type="text" readonly class="form-control-plaintext" id="contact_number" value="">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-4 col-form-label">Contact Email : </label>
                                                            <div class="col-sm-8">
                                                              <input type="text" readonly class="form-control-plaintext" id="contact_email" value="">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label for="staticEmail" style="color:#2A3988;" class="col-sm-4 col-form-label">Address : </label>
                                                            <div class="col-sm-8">
                                                                <textarea type="text" readonly class="form-control-plaintext" id="address" value=""></textarea>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" > Add Receiving</button>
                                                </div>  
<?php if (isset($temp_records) && (!empty($temp_records))) {
    ?>
                                                    <input type="hidden" name="stock_master_id" id="stock_master_id" value="<?php echo $master_id ?>"> 
                                                <?php }
                                                ?>    
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <br>
<?php
if (isset($temp_records) && (!empty($temp_records))) {
    ?>

                                <div id="divToPrint">
                                    <table class="table table-striped table-bordered table-condensed dt-responsive " >
                                        <thead>
                                            <tr>
                                                <th style="width: 1%;" class="center">No.</th>
                                                <th>Supplier</th>
                                                <th>Product Name</th>  
                                                <th>Manufacturer</th>
                                                <th>Batch Number</th>
                                                <th>Expiry Date</th> 
                                                <th>Quantity</th> 
                                                <!--<th>Action</th>-->  
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- Table row -->
    <?php
    $count = 1;
    foreach ($temp_records->result_array() as $row) {
        ?>
                                                <tr>
                                                    <td class="center"><?php echo $count; ?></td>
                                                    <td class="important"><?php echo $row['wh_from']; ?></td>
                                                    <td><?php echo $row['product_name']; ?></td> 
                                                    <td class="important"><?php echo $row['manufacturer']; ?></td>
                                                    <td class="important"><?php echo $row['batch_no']; ?></td>
                                                    <td class="important"><?php echo $row['batch_expiry']; ?></td> 
                                                    <td class="important"><?php echo $row['quantity']; ?></td> 

                        <!--                                                <td>  
                        <a onclick="return confirm('Are you sure you want to Delete?');" href="<?php echo base_url("product_management/deactivate?id=") . $row['pk_id']; ?>&status=1" class="btn btn-sm btn-light glyphicons bin" > Delete</a>
                        </td> -->
                                                </tr>
        <?php
        $count++;
    }
    ?>
                                            <!-- // Table row END -->
                                            <!-- Table row -->

                                            <!-- // Table row END -->
                                        </tbody>
                                    </table> 
                                </div>
                                <button type="button" id="save_temp_receive" name="save_temp_receive" class="btn btn-primary waves-effect waves-light" style="margin-left:90%;">Save</button>

                                <!-- // Table END -->
    <?php
}
?>
                        </form>
                    </div>
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>