<style>
*{font-family:"Open Sans",sans-serif;}
b{font-size:12px;}
h3{font-size:13px;}
#report_type{
font-size:12px;
font-family: arial;}
#content_print
{
	width:624px;
	margin-left:50px;
}
table#myTable{
	border:1px solid #B6B6B7;
	font-size:9pt;
	width:100%;
}
table, table#myTable tr td{
	border-collapse: collapse;
	border:1px solid #B6B6B7;
	font-size:12px;
}
table, table#myTable tr th{
	border:1px solid #B6B6B7;
	border-collapse: collapse;
	font-size:12px;
}

table#myTables{
	border:1px solid #B6B6B7;
	font-size:9pt;
	width:50%;
}
table, table#myTables tr td{
	border-collapse: collapse;
	border:1px solid #B6B6B7;
	font-size:12px;
}
table, table#myTables tr th{
	border:1px solid #B6B6B7;
	border-collapse: collapse;
	font-size:12px;
}

table#loc_from_to{
	border:1px solid #B6B6B7;
	font-size:9pt;
	width:40%;
}
table, table#loc_from_to tr td{
	border-collapse: collapse;
	border:1px solid #B6B6B7;
	font-size:12px;
}
table, table#loc_from_to tr th{
	border:1px solid #B6B6B7;
	border-collapse: collapse;
	font-size:12px;
}
</style>
<?php
/**
 * printIssue
 * @package im
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
//includ AllClasses
//include("../includes/classes/AllClasses.php");

$title = "Stock Issue Voucher";
$print = 1;
$whNames = array();
$logo1 = array();
//if(!empty($whName))
//{
//    foreach ($whName as $row)
//    {
//        $stkid = $row['stkid'];
//        $whname = $row['wh_name'];
//        $prov_id = $row['prov_id'];
//        $lvl = $row['lvl'];
//    }
//}
//else{
        $stkid = '';
        $whname = '';
        $prov_id = '';
        $lvl = '';
//}
if(isset($logo) && !empty($logo))
{
    foreach ($logo as $rowlogo)
    {
        $logo1[1] = $rowlogo;
    }
}
//get id
$receiveArr = array();
//fetching data from stocks
foreach ($stocks_vehicle as $row) {
    //issue_no 
    $tran_no = $row['tran_no'];
    //issue_date
//    $issue_date = $row['tran_date'];
     
//    $wh_from_supplier = $row['wh_from_supplier'];
    $location_from = $row['location_from'];
    $location_to = $row['location_to'];
    $date_vehicle_req = $row['date_vehicle_req'];
    $no_of_vehicle = $row['no_of_vehicle'];
    $vehicle_type = $row['vehicle_type'];
//    $product = $row['product'];
    $product_type = '';
//    $product_type = $row['product_type'];
    $temperature_requirement = '';
//    $temperature_requirement = $row['temperature_requirement'];
//    $no_of_cartons = $row['no_of_cartons'];
//    $value_of_product = $row['value_of_product'];
//    $product_quantity = $row['product_quantity'];
    $transport_req_remarks = '';
//    $transport_req_remarks = $row['transport_req_remarks'];
//    $issued_by = $row['issued_by'];
    $issued_by = '';
    //receiveArr
    $receiveArr[] = $row;
}
// Get district Name
//$getDist = "SELECT
//			tbl_locations.LocName
//		FROM
//			tbl_warehouse
//		INNER JOIN tbl_locations ON tbl_warehouse.dist_id = tbl_locations.PkLocID
//		WHERE
//			tbl_warehouse.wh_id = $wh_to_id";
////query result
//$rowDist = mysql_fetch_object(mysql_query($getDist));
$rowDist = 'XYZ';
?>
<br><br><br><br><br><br>
<div id="content_print">
	<?php 
        //include header
//        include(PUBLIC_PATH."/html/header.php");
        //include top_im
//        include PUBLIC_PATH."html/top_im.php";?>
	<!--<div style="float:right; font-size:12px;">QR/015/01.08.2</div>-->
	<style type="text/css" media="print">
    @media print
    {    
        #printButt
        {
            display: none !important;
        }
    }
    </style>
	<?php
        if(isset($_REQUEST['gwis']) && $_REQUEST['gwis'] == '1')
        {
		$rptName = 'Transport Requisition Form';
     	}
        else
            if(isset($_REQUEST['gatepass']) && $_REQUEST['gatepass'] == '1')
        {
		$rptName = 'Gate Pass Voucher';
     	}
//    	include('report_header');
                ?>
                
                
         <div style="line-height:1;">
    <div id="logoLeft" style="float:left; width:107px; text-align:right;">
    <!--<img src="<?php echo PUBLIC_URL;?>images/gop.png" />-->
        <img id="pics" style="border-radius: 50%;" src="<?php echo base_url('assets/images/lmis.jpg')?>" alt="" height="60">
    </div>
    <div id="report_type" style="float:left; width:386px; text-align:center;">
        <?php 
        if ($stkid==1 && $provid==1 && $lvl==3) 
        {
            ?>
                <span style="line-height:20px"><b>POPULATION WELFARE DEPARTMENT</b></span><br/>
                <span style="line-height:20px"><b>GOVERNMENT OF PUNJAB</b></span><br/>
        <?php }
        elseif ($stkid==145) 
        {
            ?>
                <span style="line-height:20px"><b>PRIMARY & SECONDARY HEALTHCARE DEPARTMENT</b></span><br/>
                <span style="line-height:20px"><b>GOVERNMENT OF PUNJAB</b></span><br/>
                <span style="line-height:20px"><b>MEDICAL STORE DEPO LAHORE</b></span><br/>
        <?php 
        }elseif ($stkid==1) 
        {
            ?>
                <span style="line-height:20px"><b>GOVERNMENT OF PAKISTAN</b></span><br/>
                <span style="line-height:20px"><b>CMU</b></span><br/>
                <span style="line-height:20px"><b>REGULATIONS & COORDINATION</b></span><br/>
                <span style="line-height:20px">DIRECTORATE OF CENTRAL WAREHOUSE & SUPPLIES</span><br/>
        <?php 
        } 
        else {
            ?>
                <span style="line-height:20px"><b>GOVERNMENT OF PAKISTAN</b></span><br/>
                <span style="line-height:20px"><b>Ministry  of National Health Services  Regulations & Coordination</b></span><br/>
                <span style="line-height:20px"><b>Common Management Unit (CMU)</b></span><br/>
                <span style="line-height:20px">CMU Warehouse, Islamabad</span><br/>
                <!--<span style="line-height:20px"><?php // echo $logo1[1]?></span><br/>-->
        <?php 
        
        }?>
        <!--<span style="line-height:15px"><b>Store: </b><?php echo $whname;?></span>-->
        <hr style="margin:3px 10px;" />
        <p><b><?php echo $rptName;?> as on: <?php echo date('d-M-Y');?></b>
        </p>
    </div>
    <div id="logoLeft" style="float:right; width:107px;">
    <!--<img src="<?php echo PUBLIC_URL;?>images/gop.png" />-->
        <img id="pics" style="border-radius: 50%;" src="<?php echo base_url('assets/images/global_fund.png')?>" alt="" height="60">
    </div>
</div>
<div style="clear:both"></div>       
                
                
<br>
        <div style="width:100%;">
            <!--<b style="float:right;">District: <?php echo $rowDist; ?></b><br />-->
            <!--<b style="float:left;">Issue Voucher: <?php echo $issue_no; ?></b>-->
            <table style="float:left;" id="loc_from_to" class="table-condensed" cellpadding="3">
                <tr>
                    <th width="8%"> Location From</th>
                    <th width="15%"> Location To </th>
                    <th width="8%"> Date Vehicle Required</th>
    <!--                <th width="10%" align="center">Unit</th>
                    <th width="15%" align="center">Cartons</th>-->
                </tr>
                <tbody>
                    <tr>
                        <td><?php echo $location_from; ?></td>
                        <td><?php echo $location_to; ?></td>
                        <td><?php echo $date_vehicle_req; ?></td>
                    </tr>
                </tbody>
            </table>
            <table style="float:right;" id="myTables" class="table-condensed" cellpadding="3">
                <tr>
                    <th width="8%"> Vehicle Type</th>
                    <th width="15%"> No of Vehicle </th>
                    <th width="15%"> Vehicle Rent </th>
                    <th width="15%"> Amount </th>
    <!--                <th width="10%" align="center">Unit</th>
                    <th width="15%" align="center">Cartons</th>-->
                </tr>
                <tbody>
                    <?php
                    $cno = 0;
                    $totalAmount = 0;
                    foreach ($stocks_vehicle as $row) { ?>
                    
                    <?php 
                        $totalAmount += $row['no_of_vehicle']*$row['vehicle_rent'];
                    ?>
                    
                    <tr>
                        <td><?php echo $row['vehicle_type']; ?></td>
                        <td><?php echo $row['no_of_vehicle']; ?></td>
                        <td><?php echo $row['vehicle_rent']; ?></td>
                        <td style="text-align:center;"><?php echo $row['no_of_vehicle']*$row['vehicle_rent']; ?></td>
                    </tr>
                    <?php $cno++;}  ?>
                    
                    
                    <tr>
                        <th colspan="3" style="text-align:right;">Total Amount</th>
                        <th style="text-align:center;"><?php echo number_format($totalAmount);?></th>
                    </tr>
                    
                </tbody>
            </table>
            <!--<b style="float:right;">Date of Departure: <?php echo date("d/m/y", strtotime($issue_date)); ?></b>-->
        </div>
<!--        <div style="clear:both;width:50%;">
            <b style="float:left;">Location From: <?php echo $issue_no; ?></b>
            <br><b style="float:left;">Location To: <?php echo $tran_ref; ?></b>
            <b style="float:right;">Issue To: <?php echo $issue_to;?></b><br />
            <b style="float:right;">Issue By: <?php echo $issued_by;?></b>
        </div>-->


<!--        <div style="text-align:center;">
            <b style="float:right;">District: <?php echo $rowDist; ?></b><br />
            <b style="float:left;width:50%;">Issue Voucher: <?php echo $issue_no; ?></b>
            <table id="myTables" class="table-condensed" cellpadding="3">
                <tr>
                    <th width="8%"> Sr #</th>
                    <th width="15%"> Type of Product </th>
                    <th width="10%" align="center">Unit</th>
                    <th width="15%" align="center">Cartons</th>
                </tr>
                <tbody>
                    <tr>
                        <td>saad</td>
                        <td>saad</td>
                    </tr>
                </tbody>
            </table>
            <b style="float:right;">Date of Departure: <?php echo date("d/m/y", strtotime($issue_date)); ?></b>
        </div>
        <div style="clear:both;">
            <b style="float:left;">Reference No.: <?php echo $tran_ref; ?></b>
            <b style="float:right;">Issue To: <?php echo $issue_to;?></b><br />
            <b style="float:right;">Issue By: <?php echo $issued_by;?></b>
        </div>-->
        
    <div style="width:100%; clear:both; margin-top:30px; padding-top: 30px;">    

    <table id="myTable" class="table-condensed" cellpadding="3" >
            <tr>
                <th width="8%"> Sr #</th>
                <th width="15%"> Product Name </th>
                <th width="15%"> Quantity </th>
                <th width="15%"> No. of Cartons </th>
                <th width="15%"> Manufacturer  </th>
<!--                <th width="10%" align="center">Unit</th>
                <th width="15%" align="center">Cartons</th>-->
            </tr>
            <tbody>
                <?php
                $i = 1;
				$totalQty = 0;
				$totalCartons = 0;
                                $totalqty = 0;
                                $totalcarton = 0;
				$product = '';
                //check receiveArr
                                if (!empty($stocks_prod)) {
                    foreach ($stocks_prod as $row) { 
//						if ( $val['itm_name'] != $product && $i > 1 )
//						{
						?>
<!--                        <tr>
                            <th colspan="4" style="text-align:right;">Total</th>
                            <th style="text-align:right;"><?php echo number_format($totalQty);?></th>
                            <th>&nbsp;</th>-->
                            <!--<th style="text-align:right;"><?php echo number_format($totalCartons);?></th>-->
                        <!--</tr>-->
                        <?php 
                            $totalqty += $row['quantity'];
                            $totalcarton += $row['cartons'];
                        ?>
                        <tr>
                            <td style="text-align:center;"><?php echo $i++; ?></td>
                            <td><?php echo $row['product']; ?></td>
                            <td style="text-align:center;"><?php echo $row['quantity']; ?></td>
                            <td style="text-align:center;"><?php echo $row['cartons']; ?></td>
                            <td><?php echo $row['manufacturer']; ?></td>
                            <!--<td><?php // echo $row['transport_req_remarks']; ?></td>-->
<!--                            <td style="text-align:center;"><?php echo $row['UnitType']; ?></td>
                            <td style="text-align:right;"><?php echo number_format(abs($row['quantity']) / $row['qty_carton']); ?></td>-->
                        </tr>
                        <?php
                    }
                }
                ?>
                        
                <tr>
                    <th colspan="2" style="text-align:right;">Total</th>
                    <th style="text-align:center;"><?php echo number_format($totalqty);?></th>
                    <th style="text-align:center;"><?php echo number_format($totalcarton);?></th>
                    <th>&nbsp;</th>
                </tr>
            </tbody>
        </table>

    </div>

        <?php if(!empty($comments)){?>
        <div style="font-size:12px; padding-top:3px;"><b>Comments:</b> <?php echo $comments;?></div>
        <?php }?>
        

        <?php // include('report_footer_issue.php');?>
        
        <div style="width:100%; clear:both; margin-top:30px;">
    <table width="48%" cellpadding="5" style="float:left; border:2px solid #E5E5E5 !important; border-collapse:collapse;">
        <tr>
            <td><b>Issued by</b> - Name: ________________________________________</td>
        </tr>
        <tr>
            <td>Designation: ________________________________________</td>
        </tr>
        <tr>
            <td>Signature & Date: ________________________________________</td>
        </tr>
    </table>
    <table width="48%" cellpadding="5" style="float:right; border:2px solid #E5E5E5 !important; border-collapse:collapse;">
        <tr>
            <td><b>Received by</b> - Name: ________________________________________</td>
        </tr>
        <tr>
            <td>Designation: ________________________________________</td>
        </tr>
        <tr>
            <td>Signature & Date: ________________________________________</td>
        </tr>
    </table>
</div>
        
        
        <div style="width:100%; clear:both;">
            <table width="48%" cellpadding="5" style="float:left; border:2px solid #E5E5E5 !important; border-collapse:collapse; margin-top:10px;">
                <tr>
                    <td><b>Approved by</b> - Name: ________________________________________</td>
                </tr>
                <tr>
                    <td>Designation: ________________________________________</td>
                </tr>
                <tr>
                    <td>Signature & Date: ________________________________________</td>
                </tr>
            </table>
        </div>
        
        <div style="float:right; margin-top:100px;" id="printButt">
        	<button type="button"class="btn btn-warning" onclick="javascript:printCont();"> Print </button>
        </div>
    </div>
<script src="<?php echo PUBLIC_URL;?>assets/global/plugins/jquery-1.11.0.min.js" type="text/javascript"></script>
<script language="javascript">
$(function(){
	//printCont();
})
function printCont()
{
	window.print();
}
</script>