<style>
*{font-family:"Open Sans",sans-serif;}
b{font-size:12px;}
h3{font-size:13px;}
#report_type{
font-size:12px;
font-family: arial;}
#content_print
{
	width:624px;
	margin-left:50px;
}
table#myTable{
	border:1px solid #B6B6B7;
	font-size:9pt;
	width:100%;
}
table, table#myTable tr td{
	border-collapse: collapse;
	border:1px solid #B6B6B7;
	font-size:12px;
}
table, table#myTable tr th{
	border:1px solid #B6B6B7;
	border-collapse: collapse;
	font-size:12px;
}

table#myTables{
	border:1px solid #B6B6B7;
	font-size:9pt;
	width:50%;
}
table, table#myTables tr td{
	border-collapse: collapse;
	border:1px solid #B6B6B7;
	font-size:12px;
}
table, table#myTables tr th{
	border:1px solid #B6B6B7;
	border-collapse: collapse;
	font-size:12px;
}

table#loc_from_to{
	border:1px solid #B6B6B7;
	font-size:9pt;
	width:40%;
}
table, table#loc_from_to tr td{
	border-collapse: collapse;
	border:1px solid #B6B6B7;
	font-size:12px;
}
table, table#loc_from_to tr th{
	border:1px solid #B6B6B7;
	border-collapse: collapse;
	font-size:12px;
}
/*#printbuttonstyle {
  background-color: #4CAF50;  Green 
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 4px;
}*/
.sprintbuttonstyle{
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 4px;
}
</style>
<?php
/**
 * printIssue
 * @package im
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
//includ AllClasses
//include("../includes/classes/AllClasses.php");

$title = "Stock Issue Voucher";
$print = 1;
$whNames = array();
$logo1 = array();
if(!empty($whName))
{
    foreach ($whName as $row)
    {
        $stkid = $row['stkid'];
        $whname = $row['wh_name'];
        $prov_id = $row['prov_id'];
        $lvl = $row['lvl'];
    }
}
else{
        $stkid = '';
        $whname = '';
        $prov_id = '';
        $lvl = '';
}
if(isset($logo) && !empty($logo))
{
    foreach ($logo as $rowlogo)
    {
        $logo1[1] = $rowlogo;
    }
}
//get id
$receiveArr = array();
//fetching data from stocks
foreach ($stocks as $row) {
    //issue_no 
    $issue_no = $row['tran_no'];
    //comments
    $comments = $row['received_remarks'];
    //tran_ref
    $tran_ref = $row['tran_ref'];
    //issue_date
    $issue_date = date("d/m/y", strtotime($row['tran_date']));
    //wh_to_id
    $wh_to_id = $row['wh_id'];
    $wh_to = $row['wh_to'];
    $issue_to_info = $row['issue_to_info'];
    //issue_to
    $issue_to = $row['wh_name'];
    //issued_by
    $doc_no = $row['dc_no'];
    $vehicle_reg = $row['vehicle_reg'];
    $dc_date = date("d-M-Y", strtotime($row['tran_date']));
    $driver_name = $row['siv_driver_name'];
    $driver_contact = $row['siv_contatc_number'];
    $siv_no_of_cartons = $row['siv_no_of_cartons'];
    $siv_weight = $row['siv_weight'];
    
    $siv_mode_of_transport = $row['siv_mode_of_transport'];
    $siv_name_of_transporter = $row['siv_name_of_transporter'];
    $siv_vehicle_type = $row['siv_vehicle_type'];
    $siv_vehicle_plate_no = $row['siv_vehicle_plate_no'];
    $username = $row['username'];
    $designation = $row['designation'];
    $tracking_no = $row['siv_tracking_no'];
    
    $ausername = '';
    $adesignation = '';
    
//    $issued_by = $row['issued_by'];
    $issued_by = '';
    //receiveArr
    $receiveArr[] = $row;
}

if(isset($fcreator) && !empty($fcreator))
{
    foreach ($fcreator as $row11) {
        $fusername = $row11['username'];
        $fdesignation = $row11['designation'];
    }
}

// Get district Name
//$getDist = "SELECT
//			tbl_locations.LocName
//		FROM
//			tbl_warehouse
//		INNER JOIN tbl_locations ON tbl_warehouse.dist_id = tbl_locations.PkLocID
//		WHERE
//			tbl_warehouse.wh_id = $wh_to_id";
////query result
//$rowDist = mysql_fetch_object(mysql_query($getDist));
$rowDist = 'XYZ';
?>
<!--<br><br><br><br><br><br>-->
<div id="content_print">
	<?php 
        //include header
//        include(PUBLIC_PATH."/html/header.php");
        //include top_im
//        include PUBLIC_PATH."html/top_im.php";?>
	<!--<div style="float:right; font-size:12px;">QR/015/01.08.2</div>-->
	<style type="text/css" media="print">
    @media print
    {    
        #printButt
        {
            display: none !important;
        }
        #wpprintButt
        {
            display: none !important;
        }
/*        body {
            zoom:200%;
            width:100%; 
            height:100%;
        }*/
    }
    </style>
	<?php
        if(isset($_REQUEST['issue']) && $_REQUEST['issue'] == '1')
        {
		$rptName = 'Stock Issue Voucher';
     	}
        else
            if(isset($_REQUEST['gatepass']) && $_REQUEST['gatepass'] == '1')
        {
//		$rptName = 'Gate Pass Voucher';
                $rptName = 'Voucher';
     	}
//    	include('report_header');
                ?>
                
                
         <div style="line-height:1;">
    <div id="logoLeft" style="float:left; width:107px; text-align:right;">
    <!--<img src="<?php echo PUBLIC_URL;?>images/gop.png" />-->
        <img id="pics" style="border-radius: 50%;" src="<?php echo base_url('assets/images/lmis.jpg')?>" alt="" height="60">
    </div>
    <div id="report_type" style="float:left; width:386px; text-align:center;">
        <?php 
        if ($stkid==1 && $provid==1 && $lvl==3) 
        {
            ?>
                <span style="line-height:20px"><b>POPULATION WELFARE DEPARTMENT</b></span><br/>
                <span style="line-height:20px"><b>GOVERNMENT OF PUNJAB</b></span><br/>
        <?php }
        elseif ($stkid==145) 
        {
            ?>
                <span style="line-height:20px"><b>PRIMARY & SECONDARY HEALTHCARE DEPARTMENT</b></span><br/>
                <span style="line-height:20px"><b>GOVERNMENT OF PUNJAB</b></span><br/>
                <span style="line-height:20px"><b>MEDICAL STORE DEPO LAHORE</b></span><br/>
        <?php 
        }elseif ($stkid==1) 
        {
            ?>
                <span style="line-height:20px"><b>GOVERNMENT OF PAKISTAN</b></span><br/>
                <span style="line-height:20px"><b>CMU</b></span><br/>
                <span style="line-height:20px"><b>REGULATIONS & COORDINATION</b></span><br/>
                <span style="line-height:20px">DIRECTORATE OF CENTRAL WAREHOUSE & SUPPLIES</span><br/>
        <?php 
        } 
        else {
            ?>
<!--                <span style="line-height:20px"><b>GOVERNMENT OF PAKISTAN</b></span><br/>
                <span style="line-height:20px"><b>MINISTRY OF NATIONAL HEALTH SERVICES REGULATIONS & COORDINATION</b></span><br/>
                <span style="line-height:20px"><b>NATIONAL TUBERCULOSIS, TB AND MALARIA CONTROL PROGRAMME</b></span><br/>
                <span style="line-height:20px">COMMON MANAGEMENT UNIT (CMU)</span><br/>-->
                <span style="line-height:20px"><b>GOVERNMENT OF PAKISTAN</b></span><br/>
                <span style="line-height:20px"><b>Combined warehouse for AIDS, TB & Malaria</b></span><br/>
                <span style="line-height:20px"><b>Main Park Road Opposite NARC</b></span><br/>
                <span style="line-height:20px"><b>National Institute of Health Chak Shehzad Islamabad </b></span><br/>
                <span style="line-height:20px">COMMON MANAGEMENT UNIT (CMU)</span><br/>
                <!--<span style="line-height:20px"><?php // echo $logo1[1]?></span><br/>-->
        <?php 
        
        }?>
        <!--<span style="line-height:15px"><b>Store: </b><?php echo $whname;?></span>-->
        <hr style="margin:3px 10px;" />
        <!--<p><b><?php echo $rptName;?> as on: <?php echo date('d-M-Y');?></b>-->
        <p><b><?php if(isset($rptName) && !empty($rptName)) { echo $rptName;} else { echo 'Stock Issue Voucher';}?> as on: <?php echo $dc_date;?></b>
        </p>
    </div>
    <div id="logoLeft" style="float:right; width:107px;">
    <!--<img src="<?php echo PUBLIC_URL;?>images/gop.png" />-->
        <img id="pics" style="border-radius: 50%;" src="<?php echo base_url('assets/images/global_fund.png')?>" alt="" height="60">
    </div>
</div>
<div style="clear:both"></div>       
                
                
                
         
<!--        <div style="text-align:center;">
            <b style="float:right;">District: <?php echo $rowDist; ?></b><br />
            <b style="float:left;">Issue Voucher: <?php echo $issue_no; ?></b>
            <b style="float:right;">Date of Departure: <?php echo date("d/m/y", strtotime($issue_date)); ?></b>
        </div>
        <div style="clear:both;">
            <b style="float:left;">Reference No.: <?php echo $tran_ref; ?></b>
            <b style="float:right;">Issue To: <?php echo $issue_to;?></b><br />
            <b style="float:right;">Issue By: <?php echo $issued_by;?></b>
        </div>-->
        
        <div style="width:100%;">
            <!--<b style="float:right;">District: <?php echo $rowDist; ?></b><br />-->
            <!--<b style="float:left;">Issue Voucher: <?php echo $issue_no; ?></b>-->
            
            <table style="float:right;width:100%;" id="myTables" class="table-condensed" cellpadding="3">
                
                <tbody>
                    <tr>
                        <th style="width:20%;font-size: 18px;"> Issued To:</th>
                        <th style="width:20%"> Document/File #</th>
                        <td style="width:20%"> <?php echo $doc_no; ?> </td>
                        <th style="width:20%"> Vehicle Type </th>
                        <td style="width:20%"> <?php echo $siv_vehicle_type; ?> </td>
                    </tr>
                    <tr>
                        <td rowspan="5" style="font-size:12px;font-weight:bold"> <?php echo $wh_to.'<br><br>'.$issue_to_info; ?></td>
                        <th> Document Date</th>
                        <td> <?php echo $dc_date; ?></td>
                        <th> Vehicle Plate #</th>
                        <td> <?php echo $siv_vehicle_plate_no; ?></td>
                    </tr>
                    <tr>
<!--                        <td> </td>-->
                        <th> Mode of Transport</th>
                        <td> <?php echo $siv_mode_of_transport; ?></td>
                        <th> Total Number of Cartons</th>
                        <td> <?php echo $siv_no_of_cartons; ?></td>
                    </tr>
                    <tr>
                        <!--<td> </td>-->
                        <th> Name of Transporter</th>
                        <td> <?php echo $siv_name_of_transporter; ?></td>
                        <th> Weight of Shipment</th>
                        <td> <?php echo $siv_weight; ?></td>
                    </tr>
                    <tr>
                        <!--<td> </td>-->
                        <th> Name of Driver</th>
                        <td> <?php echo $driver_name; ?></td>
                        <th> SIV #</th>
                        <td> <?php echo $issue_no; ?></td>
                    </tr>
                    <tr>
                        <!--<td> </td>-->
                        <th> Driver Contact #</th>
                        <td> <?php echo $driver_contact; ?></td>
                        <th> SIV Date</th>
                        <td> <?php echo $issue_date; ?></td>
                    </tr>
                    <tr>
                        <td colspan="3"> </td>
                        <th colspan="1"> Tracking No #</th>
                        <td> <?php echo $tracking_no; ?></td>
                    </tr>
                </tbody>
            </table>
            <!--<b style="float:right;">Date of Departure: <?php echo date("d/m/y", strtotime($issue_date)); ?></b>-->
        </div>
<br><br><br><br><br><br><br><br><br><br><br><br>

        <table id="myTable" class="table-condensed" cellpadding="3">
            <tr>
                <th width="8%">Sr #</th>
                <th>Description</th>
                <th width="15%">UOM</th>
                <th width="15%">Pack Size</th>
                <th width="15%" align="center">Batch / Lot / Seriel No.</th>
                <th>Expiry Date</th>
                <th width="15%">Quantity</th>
                <th id="wpquantity">Price</th>
                <!--<th width="15%">Cartons</th>-->
                <th width="15%" align="center">Remarks</th>
            </tr>
            <tbody>
                <?php
                $i = 1;
				$totalQty = 0;
				$totalCartons = 0;
				$product = '';
                //check receiveArr
                                if (!empty($receiveArr)) {
                    foreach ($receiveArr as $val) {
//						if ( $val['itm_name'] != $product && $i > 1 )
//						{
						?>
<!--                        <tr>
                            <th colspan="4" style="text-align:right;">Total</th>
                            <th style="text-align:right;"><?php echo number_format($totalQty);?></th>
                            <th>&nbsp;</th>-->
                            <!--<th style="text-align:right;"><?php echo number_format($totalCartons);?></th>-->
                        <!--</tr>-->
                        <?php
//							$totalQty = abs($val['quantity']);
//							$totalCartons = abs($val['quantity']) / $val['qty_carton'];
//						}
//						else
//						{	
//							$totalQty += abs($val['quantity']);
////							$totalCartons += abs($val['quantity']) / $val['qty_carton'];
//						}
//						$product = $val['itm_name'];
                        ?>
                        <tr>
                            <td style="text-align:center;"><?php echo $i++; ?></td>
                            <td><?php echo $val['itm_name']; ?></td>
                            <td><?php echo $val['unit']; ?></td>
                            <td style="text-align:center;"> <?php echo $val['pack_size']; ?></td>
                            <td style="text-align:right;"><?php echo $val['batch_no']; ?></td>
                            <td style="text-align:center;"> <?php if(!empty($val['stock_batch_expiry'])) { echo date("d/m/y", strtotime($val['stock_batch_expiry'])); } ?></td>
                            <td><?php echo abs($val['giv_quantity']); ?></td>
                            <!--<td id="wpqty"><?php // echo number_format(abs($val['giv_quantity'])*$val['conversion_rate']*$val['unit_price']); ?></td>-->
                            <td id="wpqty"><?php echo number_format(abs($val['unit_price'])); ?></td>
                            <!--<td style="text-align:center;"> <?php echo $val['siv_no_of_cartons']; ?></td>-->
                            <!--<td style="text-align:right;"><?php echo $val['received_remarks']; ?></td>-->
                            <!--<td style="text-align:right;"><?php echo $val['comments']; ?></td>-->
                            <td style="text-align:right;">
                                <?php
                                    if(!empty($val['pack_size'])) 
                                    {
                                        echo round(abs($val['giv_quantity'])/$val['pack_size'],2).' Packs ,'; 
                                    }
                                    else 
                                    {
                                        echo '0 Packs ,';
                                    }
                                    if(!empty($val['carton_size']) && !empty($val['field6'])) 
                                    {
                                        echo round(abs($val['giv_quantity'])/($val['pack_size']*$val['carton_size']),2).' Cartons'; 
                                    }
                                    else 
                                    {
                                        echo '0 Cartons';
                                    }
                                ?>
                            </td>
                        </tr>
                        <?php
                    }
                }
                ?>
<!--                <tr>
                    <th colspan="4" style="text-align:right;">Total</th>
                    <th style="text-align:right;"><?php echo number_format($totalQty);?></th>
                    <th>&nbsp;</th>
                    <th style="text-align:right;"><?php echo number_format($totalCartons);?></th>
                </tr>-->
            </tbody>
        </table>
        <?php if(!empty($comments)){?>
        <div style="font-size:12px; padding-top:3px;"><b>Comments:</b> <?php echo $comments;?></div>
        <?php }?>
        
        <?php // include('report_footer_issue.php');?>
        
        <div style="width:100%; clear:both; margin-top:30px;">
    <table width="48%" cellpadding="5" style="float:left; border:2px solid #E5E5E5 !important; border-collapse:collapse;">
        <tr>
            <td><b>Prepared By</b>
                <hr> Name: <u><?php echo $_SESSION['name']; ?></u>___________________________________________</td>
        </tr>
        <tr>
            <td>Designation: <u><?php echo $_SESSION['designation']; ?></u>_____________________________________</td>
        </tr>
        <tr>
            <td>Signature: _______________________________________</td>
        </tr>
        <tr>
            <td>Date: ____________________________________________</td>
        </tr>
    </table>
    <table width="48%" cellpadding="5" style="float:right; border:2px solid #E5E5E5 !important; border-collapse:collapse;">
        <tr>
            <td><b>Reviewed By</b>
                <hr> Name: ___________________________________________</td>
        </tr>
        <tr>
            <td>Designation: _____________________________________</td>
        </tr>
        <tr>
            <td>Signature: _______________________________________</td>
        </tr>
        <tr>
            <td>Date: ____________________________________________</td>
        </tr>
    </table>
    
</div>
        
         <div style="width:100%; clear:both; margin-top:220px;">
    <table width="48%" cellpadding="5" style="float:left; border:2px solid #E5E5E5 !important; border-collapse:collapse;">
        <tr>
            <td><b>Approved By</b>
                <hr> Name: <?php if(isset($fcreator) && !empty($fcreator) && isset($process_status_id) && $process_status_id == '12') {?><u><?php echo $username; ?></u> <?php } else { ?>___________________________________________<?php } ?></td>
        </tr>
        <tr>
            <td>Designation: <?php if(isset($fcreator) && !empty($fcreator) && isset($process_status_id) && $process_status_id == '12') {?><u><?php echo $designation; ?></u> <?php } else { ?>_____________________________________<?php } ?></td>
        </tr>
        <tr>
            <td>Signature: _______________________________________</td>
        </tr>
        <tr>
            <td>Date: ____________________________________________</td>
        </tr>
    </table>
    
    
</div>
        
        <div style="width:100%; clear:both; margin-top:400px;">
            <h3>Receiving Acknowledgment</h3>
    <table width="48%" cellpadding="5" style="float:left; border:2px solid #E5E5E5 !important; border-collapse:collapse;">
        <tr>
            <td><b>Varified By</b>
                <hr> Name: ___________________________________________</td>
        </tr>
        <tr>
            <td>Designation: _____________________________________</td>
        </tr>
        <tr>
            <td>Signature: _______________________________________</td>
        </tr>
        <tr>
            <td>Date: ____________________________________________</td>
        </tr>
    </table>
    <table width="48%" cellpadding="5" style="float:right; border:2px solid #E5E5E5 !important; border-collapse:collapse;">
        <tr>
            <td><b>Received By</b>
                <hr> Name: ___________________________________________</td>
        </tr>
        <tr>
            <td>Designation: _____________________________________</td>
        </tr>
        <tr>
            <td>Signature: _______________________________________</td>
        </tr>
        <tr>
            <td>Date: ____________________________________________</td>
        </tr>
    </table>
</div>
        
        <div style="width:100%; clear:both; margin-top:200px;">
            <b>Note:</b>
            <p style="font-size:12px;">It is strictly requested that the copy of the said Stock Issuance Voucher (SIV) after confirmation and counting of all goods (within 48 hours ) may kindly be acknowledge returned back to NTP-Warehouse address at Main Park Road Opposite NARC, National Institute of Health Chak Shehzad Islamabad. Contact No: 051-9255389</p>
        </div>
        
        <div style="float:left; margin-top:20px;" id="printButt">
        	<button type="button" class="btn btn-warning sprintbuttonstyle" onclick="javascript:printCont();"> Print With Price </button>
        </div>
        <!--&nbsp;&nbsp;&nbsp;-->
        <div style="float:right; margin-top:20px;" id="wpprintButt">
        	<button type="button" class="btn btn-warning sprintbuttonstyle" id="printwprint" onclick="javascript:wpprintCont();"> Print Without Price </button>
        </div>
        
    </div>
<script src="<?php echo PUBLIC_URL;?>assets/global/plugins/jquery-1.11.0.min.js" type="text/javascript"></script>
<script language="javascript">
$(function(){
        $("#wpquantity").show();
//        $("#wpqty").show();
        $('tr td:nth-child(8)').show();
	//printCont();
});
function printCont()
{
        $("#wpquantity").show();
//        $("#wpqty").show();
        $('tr td:nth-child(8)').show();
	window.print();
}
function wpprintCont()
{
        $("#wpquantity").hide();
//        $("#wpqty").hide();
        $('tr td:nth-child(8)').hide();
	window.print();
//        $(window).on('load', function () {
//            alert("Window Loaded");
//       });
}
$('#printwprint').click(function() {
    location.reload();
});
</script>
