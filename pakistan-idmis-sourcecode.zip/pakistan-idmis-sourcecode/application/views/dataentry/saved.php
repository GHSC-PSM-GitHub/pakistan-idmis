<div class="wrapper">
        <div class="container-fluid">
            <!-- Page-Title -->
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-12">
                        <h4 class="page-title">Data has been saved Successfully!</h4>
                    </div>
                    
                </div>
                <!-- end row -->
            </div>

        </div>
        <!-- end container-fluid -->
    </div>
    <!-- end wrapper -->