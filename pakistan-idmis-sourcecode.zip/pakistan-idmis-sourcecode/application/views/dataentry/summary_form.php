<style>
    h2 {
        margin-top:18px !important;
    }
</style>
<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4 class="page-title">Summary Form</h4>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Dataentry</a></li>
                        <li class="breadcrumb-item active">Summary Form</li>
                    </ol>
                </div>
            </div>
            <!-- end row -->
        </div>
        <form method="post" id="data" name="data" action="">
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <div class="form-group row">
                            <label for="example-text-input" class="col-form-label col-sm-2">Auto Number:</label>
                            <div class="col-sm-4">
                                <input class="form-control" readonly="" type="text" value="<?php echo date("my");?>-<?php echo date("dh");?>-<?php echo date("is");?>" id="example-text-input">
                            </div>

                            <label for="example-text-input" class="col-form-label col-md-2">Reporting Month:</label>
                            <div class="col-sm-4">
                                <div class="input-group">
                                <select class="form-control" id="month" name="month" required>
                                <?php for($m=1;$m<=12;$m++) {
                                    $sel = "";
                                    if($m == (date("m")-1)) {
                                        $sel = "selected=selected";
                                    }
                                    if($m >= date("m")) {                                        
                                        break;
                                    }
                                    ?>
                                    <option value="<?php echo $m; ?>" <?php echo $sel; ?>><?php echo date('F', mktime(0, 0, 0, $m, 10)); ?></option>
                                <?php } ?>
                                </select>
                                <select class="form-control" id="year" name="year" required>
                                <?php for($y=2020;$y<=date("Y");$y++) { ?>
                                    <option value="<?php echo $y; ?>"><?php echo $y; ?></option>
                                <?php } ?>
                                </select>
                                    
                                </div><!-- input-group -->
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="example-text-input" class="col-form-label col-sm-2">Province:</label>
                            <div class="col-sm-4">
                                <select class="form-control" id="province" name="province" required>
                                    <option value="">Select</option>
                                    <option value="1">Punjab</option>
                                    <option value="2">Sindh</option>
                                    <option value="3">Khyber Pakhtunkhwa</option>
                                    <option value="4">Balochistan</option>
                                </select>
                            </div>
                            <label for="example-text-input" class="col-form-label col-sm-2">District:</label>
                            <div class="col-sm-4">
                                <select class="form-control" id="district" name="district" required>
                                <option value="">Select</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="example-text-input" class="col-form-label col-sm-2">Tehsil:</label>
                            <div class="col-sm-4">
                                <select class="form-control" id="tehsil" name="tehsil" required>
                                <option value="">Select</option>
                                </select>
                            </div>

                            <label for="example-text-input" class="col-form-label col-sm-2">UC:</label>
                            <div class="col-sm-4">
                                <select class="form-control" id="uc" name="uc" required>
                                <option value="">Select</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row m-b-0">
                            <label for="example-search-input" class="col-sm-2 col-form-label">Facility</label>
                            <div class="col-sm-4">
                                <select class="form-control" id="facility" name="facility" required>
                                <option value="">Select</option>
                                </select>
                                
                            </div>
                        </div>

                    </div>

                </div>

            </div> <!-- end col -->
        </div>
        <div class="row alert-light" id="wh_population">
            
        </div>
        <?php
        $types = array(
            1 => 'Screened/RDT',
            3 => 'Lab Test',
            4 => 'Positive',
            5 => 'Treatment',
            6 => 'Recovered'
        );
        $classes = array(
            1 => 'alert-success',
            3 => 'alert-info',
            4 => 'alert-warning',
            5 => 'alert-danger',
            6 => 'alert-dark'
        );
        ?>
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30">
                    <div class="card-body">
                    <?php foreach($types as $typek=>$typev){ ?>
                        <div class="row <?php echo $classes[$typek]; ?>">
                            <div class="col-3">
                                <h2><?php echo $typev; ?></h2>
                            </div>

                            <div class="col-3">
                                <div class="form-group">
                                    <label for="example-text-input-sm" class="col-form-label">12-17 Years</label>
                                    <div>
                                        <input class="form-control form-control-sm" name="years1217[<?php echo $typek; ?>]" id="<?php echo $typek; ?>-tid" type="number" placeholder="Enter numbers only" id="example-text-input-sm" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="form-group">
                                    <label for="example-text-input-sm" class="col-form-label">>= 18 Years</label>
                                    <div>
                                        <input class="form-control form-control-sm" name="years18[<?php echo $typek; ?>]" id="<?php echo $typek; ?>-eid" type="number" placeholder="Enter numbers only" id="example-text-input-sm" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="form-group">
                                    <label for="example-text-input-sm" class="col-form-label">Total</label>
                                    <div>
                                        <input class="form-control form-control-sm" name="total[<?php echo $typek; ?>]" id="<?php echo $typek; ?>-sumid" type="number" readonly="" placeholder="Enter numbers only" id="example-text-input-sm">
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                    </div>
                </div>
            </div>
        </div> <!-- end row -->  
        <div class="row">
        <div class="col-9"></div>
        <div class="col-3">
            <div class="form-group">
                <div>                
                    <button type="submit" class="btn btn-primary waves-effect waves-light">
                        Submit
                    </button>
                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                        Reset
                    </button>
                </div>
            </div>
        </div>
        </div>
        <br>
</form>
    </div>
    <!-- end container-fluid -->
</div>
<!-- end wrapper -->