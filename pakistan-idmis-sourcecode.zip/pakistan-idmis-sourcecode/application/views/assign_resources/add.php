<?php
//print_r($result_edit);exit;
if (isset($result_edit)) {

//    $row = $result_edit->result_array();
//    $row = $row[0];
//    $role_name = $row['role_name'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Assign Resources</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="add_stk" name="add_stk" action="<?php echo base_url("Assign_resources/add"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row">
                                             
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Stakeholder Name<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select name="stkid" class="select2me input-medium" id="stkid" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                                <?php
                                                                foreach ($stakeholder as $row) {
                                                                    ?>
                                                                <option value="<?php echo $row['stkid'] ?>" <?php if (isset($product_id) && $product_id == $row['stkid']) echo "selected='selected'"; ?>><?php echo $row['stkname'] ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>  
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                            <table class="table">

                                                    <!-- Table heading -->
                                                    <thead>
                                                        <tr>
                                                            <th style="width: 1%;"> <input type="checkbox" id="checkAll" /></th>
                                                            <th> Product </th>
                                                            <!--<th> Adjustment Type</th>-->

                                                        </tr>
                                                    </thead>
                                                    <!-- // Table heading END --> 

                                                    <!-- Table body -->
                                                    <tbody>
                                                        <!-- Table row -->
                                                        <?php
                                                            $i = 1;
                                                            foreach ($product as $row) {

//$checked = (in_array($item['pk_id'], $assignedArr['resource'])) ? 'checked="checked"' : '';
                                                                ?>
                                                        <tr>
                                                            <td></td>
                                                            <td class="center"><input type="checkbox" id="products" name="products[<?php echo $row['itm_id']; ?>]" value="<?php echo $row['itm_id']; ?>" /><?php echo '  ' .$row['itm_name']; ?></td>
                                                        </tr>
                                                        <?php $i++;
                                                            } ?>
                                                        <!-- // Table row END -->
                                                    </tbody>
                                                    <!-- // Table body END -->

                                            </table>
                                            
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                            if (isset($result))
                                                                echo 'value="edit"';
                                                            ?>>
                                                            <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div> 
                                                <?php if(isset($result_edit)){?>
                                                <input type="hidden" id="id" name="id" value="<?php echo $_REQUEST['id'] ?>">
                                                <?php
                                                }
                                                ?>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                    
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>
 