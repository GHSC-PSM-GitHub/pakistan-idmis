<div class="wrapper">
     <!-- style="background: url(<?= base_url().'uploads/'.($this->session->userdata('landing_background'));?>); height: 90vh!important;" -->
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <!-- <a href="#" class="logo logo-admin">
                            <img style="border-radius: 50%;" src="<?= base_url().'uploads/'.($this->session->userdata('report_logo'));?>" height="120">
                        </a>
                        <h3><?= $this->session->userdata('designation');?></h3> -->
                    </div>
                    <div class="separator bottom"></div>
                    <div class="innerLR">
                        <div class="row">
                            <div class="col-12">
                                <!-- <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="row"> 
                                            <div class="col-md-12">
                                                <div class="m-t-0 m-b-15">
                                                    <a href="#" class="logo logo-admin">
                                                        <img style="border-radius: 50%;" src="<?= base_url().'uploads/'.($this->session->userdata('report_logo'));?>" height="120">
                                                    </a>
                                                </div>
                                                 <h3><?= $this->session->userdata('designation');?></h3>
                                            </div> 
                                        </div>
                                    </div>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->
    </div>
</div>