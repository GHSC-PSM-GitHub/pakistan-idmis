<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons">
                        <h3><?= $page_title;?></h3>
                    </div>
                    <div class="separator bottom"></div>
                    <div class="innerLR">
                        <form method="POST" action="<?= base_url().'manage_stakeholders/edit/'.$manage_stakeholder[0]['stkid'];?>" enctype='multipart/form-data'>
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="stkname">
                                                        Stakeholder Name 
                                                        <span style="color: red">*</span> 
                                                    </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="stkname" id="stkname" value="<?= $manage_stakeholder[0]['stkname'];?>" required>
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="short_name">
                                                        Stakeholder Short Name 
                                                        <span style="color: red">*</span> 
                                                    </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="short_name" id="short_name" value="<?= $manage_stakeholder[0]['short_name'];?>" required>
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="report_title1">
                                                        Report Header 1
                                                        <span style="color: red">*</span> 
                                                    </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="report_title1" id="report_title1" value="<?= $manage_stakeholder[0]['report_title1'];?>" required>
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="report_title2">
                                                        Report Header 2
                                                        <span style="color: red">*</span> 
                                                    </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="report_title2" id="report_title2" value="<?= $manage_stakeholder[0]['report_title2'];?>" required>
                                                    </div>
                                                </div> 
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="report_title3">
                                                        Report Header 3
                                                        <span style="color: red">*</span> 
                                                    </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="report_title3" id="report_title3" value="<?= $manage_stakeholder[0]['report_title3'];?>" required>
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="abbreviation">
                                                        Abbreviation
                                                        <span style="color: red">*</span> 
                                                    </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="abbreviation" id="abbreviation" value="<?= $manage_stakeholder[0]['abbreviation'];?>" required>
                                                        <span class="text-danger abbreviation_message"></span>
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="default_login_path">
                                                        Default Login Path
                                                        <span style="color: red">*</span> 
                                                    </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="default_login_path" id="default_login_path" value="<?= $manage_stakeholder[0]['default_login_path'];?>" required>
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="default_landing_path">
                                                        Default Landing Path
                                                        <span style="color: red">*</span> 
                                                    </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="default_landing_path" id="default_landing_path" value="<?= $manage_stakeholder[0]['default_landing_path'];?>" required>
                                                    </div>
                                                </div> 
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="landing_text">
                                                        Landing Text
                                                        <span style="color: red">*</span> 
                                                    </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="landing_text" id="landing_text" value="<?= $manage_stakeholder[0]['landing_text'];?>" required>
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="report_logo">
                                                        Logo
                                                    </label>
                                                    <div class="controls">
                                                        <input type="file" class="form-control" name="report_logo" id="report_logo">
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="login_background">
                                                        Login Background
                                                    </label>
                                                    <div class="controls">
                                                        <input type="file" class="form-control" name="login_background" id="login_background" />
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="landing_background">
                                                        Landing Background
                                                    </label>
                                                    <div class="controls">
                                                        <input type="file" class="form-control" name="landing_background" id="landing_background" />
                                                    </div>
                                                </div> 
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="details">
                                                        Details
                                                    </label>
                                                    <div class="controls">
                                                        <textarea class="form-control" name="details" id="details"><?= $manage_stakeholder[0]['details'];?></textarea>
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="contact_person">
                                                        Contact Person
                                                    </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="contact_person" id="contact_person" value="<?= $manage_stakeholder[0]['contact_person'];?>" />
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="contact_numbers">
                                                        Contact Number
                                                    </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="contact_numbers" id="contact_numbers" value="<?= $manage_stakeholder[0]['contact_numbers'];?>" />
                                                    </div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="contact_emails">
                                                        Contact Email
                                                    </label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" name="contact_emails" id="contact_emails" value="<?= $manage_stakeholder[0]['contact_emails'];?>" />
                                                    </div>
                                                </div> 
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <label class="example-text-input" for="contact_address">
                                                        Contact Address
                                                    </label>
                                                    <div class="controls">
                                                        <textarea class="form-control" name="contact_address" id="contact_address"><?= $manage_stakeholder[0]['contact_address'];?></textarea>
                                                    </div>
                                                </div> 
                                            </div> 
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" class="btn btn-primary waves-effect waves-light">Update</button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">Reset</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->
    </div>
</div>