<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>
                    <div class="heading-buttons"> 
                        <div class="clearfix"></div>
                    </div>
                    <div class="separator bottom"></div>
                    <!-- // Heading END -->
                    <h3><?= $page_title;?></h3>
                    <div class="buttons pull-right">
                        <a href="<?= base_url().'manage_stakeholders/create';?>" class="btn btn-primary btn-icon glyphicons circle_plus"><i class="fas fa-user-plus"></i> Add</a>
                    </div>
                     <div class="innerLR">
                        <br>
                        <div id="divToPrint" style="overflow: auto;">
                            <table  id="datatable-buttons"  class="table table-striped table-bordered table-condensed dt-responsive nowrap">
                                <thead>
                                    <tr>
                                        <th style="width: 10%; text-align: center;">#</th>
                                        <th>Stakeholder</th>
                                        <th>Stakeholder Short Name</th>
                                        <th>Report Header 1</th>
                                        <th>Report Header 2</th>
                                        <th>Report Header 3</th>
                                        <th>Abbreviation</th>
                                        <th>Landing Text</th>
                                        <th style="width: 8%; text-align: center;">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php if(!empty($manage_stakeholders[0]['stkid'])):?>
                                    <?php $loop = 0;?>
                                    <?php foreach($manage_stakeholders as $manage_stakeholder):?>
                                        <tr>
                                            <td style="text-align: center;"><?= ++$loop;?></td>
                                            <td><?= $manage_stakeholder['stkname'];?></td>
                                            <td><?= $manage_stakeholder['short_name'];?></td>
                                            <td><?= $manage_stakeholder['report_title1'];?></td>
                                            <td><?= $manage_stakeholder['report_title2'];?></td>
                                            <td><?= $manage_stakeholder['report_title3'];?></td>
                                            <td><?= $manage_stakeholder['abbreviation'];?></td>
                                            <td><?= $manage_stakeholder['landing_text'];?></td>
                                            <td style="text-align: center;">
                                                <a href="<?= base_url().'manage_stakeholders/edit/'.$manage_stakeholder['stkid'];?>">
                                                    <i class="fa fa-edit"></i>
                                                </a> &nbsp;&nbsp;
                                                <a href="<?= base_url().'manage_stakeholders/delete/'.$manage_stakeholder['stkid'];?>">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach;?>
                                <?php endif;?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>