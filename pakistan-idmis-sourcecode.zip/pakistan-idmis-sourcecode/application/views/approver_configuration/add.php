<?php
//print_r($result_edit);exit;
if (isset($result_edit)) {

    $row = $result_edit->result_array();
    $row = $row[0];
    $approver_code = $row['approval_code'];
    $document_id = $row['document_id'];
    $approver_designation_id = $row['approver_designation'];
    $level_id = $row['level'];
    $final_id = $row['final'];
}
?>

<div class="wrapper">
    <div class="container-fluid">
        <!-- Page-Title -->
        <div class="page-title-box">
            <div class="row align-items-center">

                <div class="col-sm-12"> 
                    <div class="separator bottom"></div>

                    <div class="heading-buttons">
                        <h3>Add Approver Code Configuration</h3>

                    </div>
                    <div class="separator bottom"></div>

                    <div class="innerLR">
                        <form method="post" id="add_ext_system" name="add_ext_system" action="<?php echo base_url("approver_configuration/add"); ?>">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card m-b-30">
                                        <div class="card-body">
                                            <div class="form-group row">
                                                <div class="col-md-3">
                                                    <label class="example-text-input" required >Approve From<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="approve_from" id="approve_from" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <option value="A0">A0</option>
                                                            <option value="A1">A1</option>
                                                            <option value="A2">A2</option>
                                                            <option value="A3">A3</option>
                                                            <option value="B0">B0</option>
                                                            <option value="B1">B1</option>
                                                            <option value="B2">B2</option>
                                                            <option value="B3">B3</option>
                                                            <option value="C0">C0</option>
                                                            <option value="C1">C1</option>
                                                            <option value="C2">C2</option>
                                                            <option value="C3">C3</option>
                                                            <option value="D0">D0</option>
                                                            <option value="D1">D1</option>
                                                            <option value="D2">D2</option>
                                                            <option value="D3">D3</option>
                                                            
                                                            <?php
//                                                            foreach ($document as $row) {
                                                                ?>
                                                                <!--<option value="<?php echo $row['pk_id'] ?>" <?php if (isset($document_id) && $document_id == $row['pk_id']) echo "selected='selected'"; ?>><?php echo $row['name'] ?></option>-->
                                                                <?php
//                                                            }
                                                            ?>

                                                        </select> 
                                                    </div>
                                                </div>
                                                 <div class="col-md-3">
                                                    <label class="example-text-input" required >Approve To<span style="color: red">*</span> </label>
                                                    <div class="controls">
                                                        <select class="select2me input-medium" name="approve_to" id="approve_to" required style="width:100%;padding:10%;">
                                                            <option value="">Select</option>
                                                            <option value="A0">A0</option>
                                                            <option value="A1">A1</option>
                                                            <option value="A2">A2</option>
                                                            <option value="A3">A3</option>
                                                            <option value="B0">B0</option>
                                                            <option value="B1">B1</option>
                                                            <option value="B2">B2</option>
                                                            <option value="B3">B3</option>
                                                            <option value="C0">C0</option>
                                                            <option value="C1">C1</option>
                                                            <option value="C2">C2</option>
                                                            <option value="C3">C3</option>
                                                            <option value="D0">D0</option>
                                                            <option value="D1">D1</option>
                                                            <option value="D2">D2</option>
                                                            <option value="D3">D3</option>
                                                        </select> 
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            
                                            <div class="form-group row">
                                                <div class="col-md-10">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="submit" id="wh_btn" name="wh_btn" class="btn btn-primary waves-effect waves-light" <?php
                                                            if (isset($result))
                                                                echo 'value="edit"';
                                                            ?>>
                                                            <?php echo 'Save'; ?> </button>
                                                    <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                                        Reset
                                                    </button>
                                                </div> 
                                                <?php if(isset($result_edit)){?>
                                                <input type="hidden" id="id" name="id" value="<?php echo $_REQUEST['id'] ?>">
                                                <?php
                                                }
                                                ?>
                                                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>" />

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                    
                </div>

            </div>
        </div>
        <!-- end row -->
    </div>
</div>
 