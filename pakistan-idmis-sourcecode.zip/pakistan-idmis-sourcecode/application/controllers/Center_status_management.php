<?php

class Center_status_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('center_status_model');
        $this->obj=new Center_status_model();
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = "Status";
        $data['main_content'] = $this->load->view('center_status_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            if(isset($_POST['id'])){
                $this->obj->pk_id = $_POST['id'];
            }
             
            $this->obj->status_name = $_POST['status_name'];
            $this->obj->is_active = 1;
            $this->obj->save(); 
            redirect(base_url() . 'center_status_management/index', 'refresh');
        }
//        exit;
        $data['page_title'] = "Center Status";
        $data['main_content'] = $this->load->view('center_status_management/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $data = array(); 
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('center_status_management/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'center_status_management/index', 'refresh');
    }

}

