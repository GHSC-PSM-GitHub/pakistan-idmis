<?php

class Assign_document_user extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('approval_code_model');
        $this->load->model('assign_approval_to_user');
        $this->load->model('user');
        $this->load->model('lists');
//        $this->load->model('Stakeholder');
//        $this->load->model('itminfo_tab_model');
        $this->approval_code = new Approval_code_model();
        $this->assign_approval_to_user = new Assign_approval_to_user();
        $this->obj_user = new User();
        $this->obj_lists = new Lists();
//        $this->obj_role =new Role_model();
//        $this->obj_stakeholder =new Stakeholder();
    }

    public function index() { 
        $data = array();
        
        $list_arr = $this->obj_user->find_active();
            $data['user_list'] = $list_arr->result_array();
        
        $list_arr = $this->approval_code->finddocument_andcode();
        if ($list_arr)
            $data['approval_code'] = $list_arr->result_array();    
            
        $getproduct_type = $this->assign_approval_to_user->getassigndocument();
        if ($list_arr)
            $data['getassigndocument'] = $getproduct_type->result_array();
        
        $data['result'] = $this->assign_approval_to_user->find_all();
        $data['page_title'] = "Assign Document List";
        $data['main_content'] = $this->load->view('assign_document_user/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $data = array();
//        if (isset($_POST) && !empty($_POST)) {
//            if(isset($_POST['id'])){
//                $this->obj->pk_id = $_POST['id'];
//            }
//             
//            $this->obj->role_name = $_POST['role_name'];
//            $this->obj->status = 1;
//            $this->obj->save(); 
//            redirect(base_url() . 'assign_resources/index', 'refresh');
//        }
        
        
        if (isset($_POST) && !empty($_POST)) {
//            exit;
            if(isset($_POST['id'])){
                $this->assign_approval_to_user->pk_id = $_POST['id'];
            }
            $user = $_REQUEST['user'];
            
            //if category exist then delete from database before insert
            
            $useridid = $this->assign_approval_to_user->getuserid($user); 
            if ($useridid) {
                        $userid_arr = $useridid->result_array();
                    foreach ($userid_arr as $row) {
                            $userids = $row['pk_id'];
                        }
            }
            if($user == $userids)
            {
                $this->assign_approval_to_user->deleteuserinfo($user); 
            }
            
            //deleted successfuly
            
            $approval_code = $_REQUEST['assign_code'];
//            $field_list = implode(",",$_REQUEST['field_list']);
//            print_r($field_list);exit;
            $count = count($user);
            foreach ($approval_code as $index => $detail_id) {
                //Stock Received
    //            $this->obj_gwis_detail->StockReceived($detail_id);
                //Get Batch Detail
//                $stkid = $_REQUEST['stkid'];
                
//                $this->obj->role_id = $_POST['role'];
                $this->assign_approval_to_user->user_id = $_POST['user'];
                if(isset($approval_code[$index]))
                {
                    $this->assign_approval_to_user->approval_code_id = $approval_code[$index];
                }
                else{
                    $this->assign_approval_to_user->approval_code_id = '0';
                }
//                $this->assign_approval_to_user->document_id = $field_list;
                $this->assign_approval_to_user->status = 1;
                $this->assign_approval_to_user->save(); 
            }
//        exit;
            redirect(base_url() . 'assign_document_user/index', 'refresh');
        }
        
        $list_arr = $this->approval_code->finddocument_andcode();
        if ($list_arr)
            $data['approval_code'] = $list_arr->result_array();
        
        $list_arr = $this->obj_user->find_active();
            $data['user_list'] = $list_arr->result_array();
            
//        $list_arr = $this->obj_lists->get_list(7);
//            $data['document_list'] = $list_arr->result_array();
        
//        $role_arr = $this->obj_role->find_active();
//        if ($role_arr)
//            $data['roles'] = $role_arr->result_array();
//        
//        $stakeholder_arr = $this->obj_stakeholder->get_all_stk();
//        if ($stakeholder_arr)
//            $data['stakeholder'] = $stakeholder_arr->result_array();
//        exit;
        $data['page_title'] = "Assign Document User";
        $data['main_content'] = $this->load->view('assign_document_user/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $data = array(); 
        $data['result_edit'] = $this->category_field_list->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('category_list/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->category_field_list->deactivate($id, $status);
        redirect(base_url() . 'category_list/index', 'refresh');
    }

}
