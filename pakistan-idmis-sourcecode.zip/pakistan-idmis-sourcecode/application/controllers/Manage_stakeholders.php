<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Manage_stakeholders extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->library('form_validation');
		$this->load->model('Manage_stakeholder_model');
		$this->load->library('encryption');
		date_default_timezone_set("Asia/Karachi");
	}// end __construct function

	public function index(){
		// echo $this->uri->segment(4);die;
		$data['page_title'] = 'Manage Stakeholders';
		$data['manage_stakeholders'] = $this->Manage_stakeholder_model->all();
		$data['main_content'] = $this->load->view('manage_stakeholders/index', $data, TRUE);
		$this->load->view('layout/main', $data);
	}// end index function

	public function create(){
		$this->form_validation->set_rules('stkname', 'Stakeholder Name', 'required');
		$this->form_validation->set_rules('short_name', 'Stakeholder Short Name', 'required');
		if ($this->form_validation->run() == false) {
			$data['page_title'] = 'Manage Stakeholder';
			$data['main_content'] = $this->load->view('manage_stakeholders/create', $data, TRUE);
			$this->load->view('layout/main', $data);
		}else{
			$formArray = array(
				'stkname'              => $this->input->post('stkname'),
				'short_name'           => $this->input->post('short_name'),
				'contact_person'       => $this->input->post('contact_person'),
				'contact_numbers'      => $this->input->post('contact_numbers'),
				'contact_emails'       => $this->input->post('contact_emails'),
				'contact_address'      => $this->input->post('contact_address'),
				'report_title1'        => $this->input->post('report_title1'),
				'report_title2'        => $this->input->post('report_title2'),
				'report_title3'        => $this->input->post('report_title3'),
				'abbreviation'         => $this->input->post('abbreviation'),
				'default_landing_path' => $this->input->post('default_landing_path'),
				'default_login_path'   => $this->input->post('default_login_path'),
				'landing_text'         => $this->input->post('landing_text'),
				'details'              => $this->input->post('details'),
				'is_reporting'         => 1,
			);
			$result_data = $this->upload_files();
			if (empty($result_data['login_background'])) {
				$result_data['login_background'] = 'default-background.jpg';
			}
			$formArray = array_merge($formArray, $result_data);
			$insert_id = $this->Manage_stakeholder_model->create($formArray);
			if ($insert_id) {
				$formArray = array(
					'username'             => $this->input->post('abbreviation').'_control_admin',
					'designation'          => 'Stakeholder Control Admin',
					'login_id'             => $this->input->post('abbreviation').'_control_admin',
					'password'             => md5('123'),
					'phone'                => $this->input->post('contact_numbers'),
					'email'                => $this->input->post('contact_emails'),
					'role_id'              => 8,
					'is_active'            => 1,
					'stakeholder_id'       => $insert_id,
				);
				$this->Manage_stakeholder_model->create_user($formArray);
			}
			$this->session->set_flashdata('success', 'Record Added Successfully!...');
			redirect(base_url().'manage_stakeholders/index');
		}
	}// end create function

	public function edit($id=''){
		$this->form_validation->set_rules('stkname', 'Stakeholder Name', 'required');
		$this->form_validation->set_rules('short_name', 'Stakeholder Short Name', 'required');
		if ($this->form_validation->run() == false) {
			$manage_stakeholder = $this->Manage_stakeholder_model->getDataById($id);
			if (!empty($manage_stakeholder[0]['stkid'])) {
				$data = array(
					'manage_stakeholder' => $manage_stakeholder,
				);
				$data['page_title'] = 'Manage Stakeholders';
				$data['main_content'] = $this->load->view('manage_stakeholders/edit', $data, TRUE);
				$this->load->view('layout/main', $data);
			}else{
				redirect(base_url().'manage_stakeholders/index');
			}
		}else{
			$formArray = array(
				'stkname'              => $this->input->post('stkname'),
				'short_name'           => $this->input->post('short_name'),
				'contact_person'       => $this->input->post('contact_person'),
				'contact_numbers'      => $this->input->post('contact_numbers'),
				'contact_emails'       => $this->input->post('contact_emails'),
				'contact_address'      => $this->input->post('contact_address'),
				'report_title1'        => $this->input->post('report_title1'),
				'report_title2'        => $this->input->post('report_title2'),
				'report_title3'        => $this->input->post('report_title3'),
				'abbreviation'         => $this->input->post('abbreviation'),
				'default_landing_path' => $this->input->post('default_landing_path'),
				'default_login_path'   => $this->input->post('default_login_path'),
				'landing_text'         => $this->input->post('landing_text'),
				'details'              => $this->input->post('details'),
			);
			$result_data = $this->upload_files();
			$formArray = array_merge($formArray, $result_data);
			$this->Manage_stakeholder_model->update($id, $formArray);
			$this->session->set_flashdata('success', 'Record Updated Successfully!...');
			redirect(base_url().'manage_stakeholders/index');
		}
	}// end edit function

	public function upload_files(){
		$data = array();
		if (!empty($_FILES)) {
			$config = array(
	            'upload_path'   => './uploads/',
	            'allowed_types' => 'jpg|png|jpeg',
	            'max_size'      => 6000,
	            'overwrite'     => true
	        );

	        $this->load->library('upload', $config);
	        foreach ($_FILES as $document_name => $file_data) {
	    		if (!empty($_FILES[$document_name]['name'])) {
					$file_name = strtolower(str_replace(' ', '_', $document_name).'_'.time().'_');
					$file_name .= '.'.pathinfo($_FILES[$document_name]["name"], PATHINFO_EXTENSION);
					$config['file_name'] = $file_name;
			        $this->upload->initialize($config);
			        if ($this->upload->do_upload($document_name)){
			        	$uploaded_data = $this->upload->data();
			        	$data[$document_name] = $uploaded_data['file_name'];
					}
				}
			}
		}
		return $data;
	}//end upload_files function

	public function check(){
		$abbreviation = $this->input->post('abbreviation');
		$result = $this->Manage_stakeholder_model->check_abbreviation($abbreviation);
		if (!empty($result[0]['stkid'])) {
			$data['status'] = true;
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}// end check function

	public function delete($id){
		$this->Manage_stakeholder_model->delete($id);
		$this->session->set_flashdata('success', 'Record Deleted Successfully!...');
		redirect(base_url().'manage_stakeholders/index');
	}//end delete function
}// end manage_stakeholders Class