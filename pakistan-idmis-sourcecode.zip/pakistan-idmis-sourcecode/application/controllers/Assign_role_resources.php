<?php

class Assign_role_resources extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('assign_resources_model');
        $this->load->model('role_model');
//        $this->load->model('Stakeholder');
        $this->load->model('resource_model');
        $this->load->model('reports_model');
        $this->obj=new assign_resources_model();
        $this->obj_resources =new Resource_model();
        $this->obj_role =new Role_model();
//        $this->obj_stakeholder =new Stakeholder();
        $this->obj_reports_model= new Reports_model();
    }

    public function index() { 
//        $result = $this->obj_resources->top_menu();
        
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = "Role Resources";
        $data['main_content'] = $this->load->view('assign_role_resources/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        $data = array();
//        if (isset($_POST) && !empty($_POST)) {
//            if(isset($_POST['id'])){
//                $this->obj->pk_id = $_POST['id'];
//            }
//             
//            $this->obj->role_name = $_POST['role_name'];
//            $this->obj->status = 1;
//            $this->obj->save(); 
//            redirect(base_url() . 'assign_role_resources/index', 'refresh');
//        }
        
        $roleidyids = '';
        if (isset($_POST) && !empty($_POST)) {
            
            if(isset($_POST['id'])){
                $this->obj->pk_id = $_POST['id'];
            }
            
            $role_id = $_REQUEST['role_id'];
            
            //if Assign Resources to Stakeholder exist then delete from database before insert
            
            $roleidyid = $this->obj->getroleid($role_id); 
            if ($roleidyid) {
                        $roleidyid_arr = $roleidyid->result_array();
                    foreach ($roleidyid_arr as $row) {
                            $roleidyids = $row['role_id'];
                        }
            }
            if($role_id == $roleidyids)
            {
                $this->obj->delete_roleresource_idy($role_id); 
            }
            
            $roleids = $_REQUEST['role_id'];
            $resourceslist = $_REQUEST['resources'];
            $rank = $_REQUEST['rank'];
            // echo "<pre>";
            // var_dump($rank);die;
//            $view = $_REQUEST['view'];
//            $add = $_REQUEST['add'];
            $count = count($roleids);
            foreach ($resourceslist as $index => $detail_id) {
                if (!empty($rank[$index])) {
                    $this->obj->role_id = $_POST['role_id'];
                    $this->obj->resource_id = $resourceslist[$index];
                    $this->obj->rank = $rank[$index];
                    $this->obj->is_default = 1;
                    $this->obj->save(); 
                }else{
                    // $this->obj->resource_id = $resourceslist[$index];
                    // $this->obj->role_id = $_POST['role_id'];
                    // $this->obj->delete(); 
                }
            }
//        exit;
            redirect(base_url() . 'assign_role_resources/add', 'refresh');
        }
        
        $res_arr = $this->obj_resources->find_allmain_resources();
        if ($res_arr)
            $data['main_resources'] = $res_arr->result_array();
        
        $res_arr = $this->obj_resources->find_all_resources();
        if ($res_arr)
            $data['resources'] = $res_arr->result_array();
        
        $role_arr = $this->obj_role->find_active();
        if ($role_arr)
            $data['roles'] = $role_arr->result_array();
        
//        $stakeholder_arr = $this->obj_reports_model->get_stakeholder();
//        $stakeholder_arr = $this->obj_stakeholder->get_all_stk();
//        if ($stakeholder_arr)
//            $data['stakeholder'] = $stakeholder_arr->result_array();
//        exit;
        $data['page_title'] = "Role Resources";
        $data['main_content'] = $this->load->view('assign_role_resources/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $data = array(); 
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('assign_role_resources/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'assign_role_resources/index', 'refresh');
    }

}
