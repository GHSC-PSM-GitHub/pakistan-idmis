<?php

class Externalsystems_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('externalsystems');
        $this->obj=new Externalsystems();
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = "External Systems";
        $data['main_content'] = $this->load->view('externalsystems_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add_ext_system() {
        
        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            if(isset($_POST['id'])){
                $this->obj->pk_id = $_POST['id'];
            }
             
            $this->obj->external_system_name = $_POST['ext_system'];
            $this->obj->is_active = 1;
            $this->obj->save(); 
            redirect(base_url() . 'externalsystems_management/index', 'refresh');
        }
//        exit;
        $data['page_title'] = "External Systems";
        $data['main_content'] = $this->load->view('externalsystems_management/add_ext_systems', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit_ext_system() { 
        $data = array(); 
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('externalsystems_management/add_ext_systems', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate_ext_systems() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'externalsystems_management/index', 'refresh');
    }

}
