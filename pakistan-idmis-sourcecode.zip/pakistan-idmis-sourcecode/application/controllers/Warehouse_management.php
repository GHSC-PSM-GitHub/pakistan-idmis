<?php

class Warehouse_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('warehouse');
        $this->load->model('locations');
        $this->load->model('stakeholder');
        $this->load->model('warehouse_categories');
        $this->load->model('warehouse_types');
        $this->load->model('cities');
        $this->load->model("center_status_model");
        $this->load->library("pagination");
        $this->load->model('reports_model');
        $this->obj = new Warehouse();
        $this->obj_location = new Locations();
        $this->obj_stakeholder = new Stakeholder();
        $this->obj_wh_categories = new Warehouse_categories();
        $this->obj_wh_types = new Warehouse_types();
        $this->obj_status = new Center_status_model();
        $this->obj_reports_model= new Reports_model();
//        $this->obj_cities = new Cities();
    }

    public function index() {
        $data = array();
        $data['result'] = $this->obj_stakeholder->find_suppliers();
        $data['page_title'] = 'Warehouses';
        $data['main_content'] = $this->load->view('warehouse_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    public function view_supplier() {
        $data = array();
        $data['result'] = $this->obj_stakeholder->find_by_idsupplier();
        $data['page_title'] = 'Warehouses';
        $data['main_content'] = $this->load->view('warehouse_management/view_supplier', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    public function view_warehouse() {
        $data = array();
        $data['result'] = $this->obj->find_by_idwarehouse();
        $data['page_title'] = 'Warehouses';
        $data['main_content'] = $this->load->view('warehouse_management/view_warehouse', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    public function add_warehouse() {

        if (isset($_POST) && !empty($_POST)) {
//            echo '<pre>';
//            print_r($_REQUEST);
//            echo '</pre>';
//            exit;
            if (isset($_POST['id'])) {
                $this->obj->wh_id = $_POST['id'];
            }
            
                $this->obj->wh_name = $_POST['warehouse_name'];
                $this->obj->hf_cat_id = $_POST['category'];
//                $this->obj->wh_type_id = $_POST['type'];
                $this->obj->prov_id = $_POST['province'];
                if(isset($_POST['district']) && !empty($_POST['district']))
                {
                    $this->obj->dist_id = $_POST['district'];
                }
                $this->obj->stkid = $_POST['stakeholder'];
                $this->obj->is_active = 1;
                $this->obj->created_by = $_SESSION['id'];
                $this->obj->created_date = date("Y-m-d h:i:sa");
                $this->obj->modified_by = $_SESSION['id'];
                $this->obj->modified_date = date("Y-m-d h:i:sa");

                $this->obj->save();
//            exit;
            redirect(base_url() . 'warehouse_management/view_warehouse', 'refresh');
        }
        $stk_arr = $this->obj_reports_model->get_stakeholder();
            if ($stk_arr)
                $data['stakeholder'] = $stk_arr->result_array();
        
        $prov_arr = $this->obj_location->find_by_parent_id(10,2);
            if ($prov_arr)
                $data['provinces'] = $prov_arr->result_array();
            
        $data['page_title'] = 'Add Warehouse';
        $data['main_content'] = $this->load->view('warehouse_management/add_warehouse', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function view_issue_to_center() {
        $data = array();
        // echo "<pre>";
        // var_dump($_SESSION);die;
        $role = $this->session->userdata('role');
        if ($role == '8') {
            $data['result'] = $this->obj->find_all($this->session->userdata('stakeholder_id'));
        }else{
            $data['result'] = $this->obj->find_all();
        }
        $data['page_title'] = 'Warehouse Management';
        $data['main_content'] = $this->load->view('warehouse_management/view_issue_to_center', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function warehouse_list() {
        $data = array();
        // echo "<pre>";
        // var_dump($_SESSION);die;
        $role = $this->session->userdata('role');
        if ($role == '8') {
            $data['result'] = $this->obj->find_all($this->session->userdata('stakeholder_id'));
        }else{
            $data['result'] = $this->obj->find_all();
        }
        $data['page_title'] = 'Warehouse Management';
        $data['main_content'] = $this->load->view('warehouse_management/view_issue_to_center', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    public function add_issue_to_center() {

        if (isset($_POST) && !empty($_POST)) {
//            echo '<pre>';
//            print_r($_REQUEST);
//            echo '</pre>';
//            exit;
            if (isset($_POST['id'])) {
                $this->obj->wh_id = $_POST['id'];
            }
            
                $this->obj->wh_name = $_POST['warehouse_name'];
//                $this->obj->hf_cat_id = $_POST['category'];
//                $this->obj->wh_type_id = $_POST['type'];
                
                $this->obj->prov_id = $_POST['province'];
                if(isset($_POST['district']) && !empty($_POST['district']))
                {
                    $this->obj->dist_id = $_POST['district'];
                }
                $this->obj->stkid = $_POST['stakeholder'];
                
                $this->obj->hf_cat_id = 1;
//                $this->obj->prov_id = 8;
                $this->obj->is_active = 1;
                $this->obj->created_by = $_SESSION['id'];
                $this->obj->created_date = date("Y-m-d h:i:sa");
                $this->obj->modified_by = $_SESSION['id'];
                $this->obj->modified_date = date("Y-m-d h:i:sa");

                $this->obj->save();
//            exit;
            redirect(base_url() . 'warehouse_management/warehouse_list', 'refresh');
        }

        $stk_arr = $this->obj_reports_model->get_stakeholder();
            if ($stk_arr)
                $data['stakeholder'] = $stk_arr->result_array();
        
        $prov_arr = $this->obj_location->find_by_parent_id(10,2);
            if ($prov_arr)
                $data['provinces'] = $prov_arr->result_array();
        
        $data['page_title'] = 'Add Warehouse';
        $data['main_content'] = $this->load->view('warehouse_management/add_issue_to_center', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    
//    public function add_wh() {
//
//        if (isset($_POST) && !empty($_POST)) {
//            if (isset($_POST['wh_id'])) {
//                $this->obj->pk_id = $_POST['wh_id'];
//            }
//            
////            $this->obj->auto_id = $_POST['auto_id'];
//            $this->obj->warehouse_name = $_POST['hf_name'];
//            $this->obj->facility_type_id = $_POST['center_type']; // chk
//            $this->obj->public_private_type = $_POST['public_private_type']; // chk
//            $this->obj->fnf_status = $_POST['fnf_status']; // chk
//            $this->obj->reason = $_POST['reason']; // chk
//            
//            $this->obj->village_id = $_POST['village']; // chk
//            $this->obj->district_id = $_POST['district'];
//            $this->obj->province_id = $_POST['province'];
////            $this->obj->stakeholder_id = $_POST['stakeholder'];
//            $this->obj->tehsil_id = $_POST['tehsil'];
//            $this->obj->uc_id = $_POST['uc'];
//            $this->obj->address = $_POST['address'];
//            $this->obj->longitude = $_POST['longitude'];
//            $this->obj->latitude = $_POST['latitude'];
//            
//            $this->obj->malaria_status = $_POST['malaria_status']; // chk
//            $this->obj->fnf_status_malaria = $_POST['fnf_status_malaria']; // chk
//            
//            $this->obj->status = 1;
//            $this->obj->created_by = $_SESSION['id'];
//            $this->obj->created_date = date("Y-m-d h:i:sa");
//            $this->obj->modified_by = $_SESSION['id'];
//            $this->obj->modified_date = date("Y-m-d h:i:sa");
//            
//            $this->obj->save();
//            
//            $wh_ids = $this->obj->get_max_id();
//            $wh_idss = $wh_ids->result_array();
//            foreach ($wh_idss as $row) {
//                $wh_id = $row['pk_id']; 
//            }
//            
//            if (isset($_POST['wh_id'])) {
//                $this->obj_hr_info->hr_id = $_POST['wh_id'];
//                $wid = '1';
//            }
//            else{
//                $this->obj_hr_info->hr_id = $wh_id;
//                $wid = '';
//            }
//            
//            $this->obj_hr_info->hr_type = $_POST['hr_type'];
//            $this->obj_hr_info->name = $_POST['name'];
//            $this->obj_hr_info->desg = $_POST['desg'];
//            $this->obj_hr_info->contact_no = $_POST['contact_no'];
//            $this->obj_hr_info->email = $_POST['email'];
//            $this->obj_hr_info->cnic = $_POST['cnic_no'];
//            $this->obj_hr_info->gender = $_POST['gender'];
//                        
//            
//            $this->obj_hr_info->save($wid);
//            
////            $this->obj->city_id = $_POST['city'];
////            $this->obj->province_name = $_POST['province_name'];
////            $this->obj->district_name = $_POST['district_name'];
////            $this->obj->uc_name = $_POST['uc_name'];
////            $this->obj->tehsil_name = $_POST['tehsil_name'];
////            $this->obj->city_name = $_POST['city_name'];
////            $this->obj->category_id = $_POST['category'];
////            $this->obj->category_name = $_POST['category_name'];
////            $this->obj->facility_type_id = $_POST['type'];
////            $this->obj->facility_type_name = $_POST['facility_type_name'];
////            $this->obj->stakeholder_name = $_POST['stakeholder_name'];
////            $this->obj->facility_code = $_POST['hf_code'];
////            $this->obj->contact_person = $_POST['contact_person'];
////            $this->obj->contact_designation = $_POST['designation'];
////            $this->obj->contact_number = $_POST['contact_number'];
////            
////            if (isset($_POST['parent_hospital'])) {
////                $this->obj->parent_hospital_id = $_POST['parent_hospital'];
////                $this->obj->parent_hospital_name = $_POST['parent_hospital_name'];
////            }
////            $this->obj->status = 1;
////            $this->obj->created_by = $_SESSION['id'];
////            $this->obj->created_date = date("Y-m-d h:i:sa");
////            $this->obj->modified_by = $_SESSION['id'];
////            $this->obj->modified_date = date("Y-m-d h:i:sa");
////
////
////
////            $this->obj->save();
////            exit;
//            redirect(base_url() . 'warehouse_management/index', 'refresh');
//        }
//        $stk_arr = $this->obj_stakeholder->find_all();
//        $data['stakeholders'] = $stk_arr->result_array();
//
//        $categories_arr = $this->obj_wh_categories->find_active();
//        $data['categories'] = $categories_arr->result_array();
//
//        $types_arr = $this->obj_wh_types->find_active();
//        $data['types'] = $types_arr->result_array();
//
//        $data['districts'] = $this->obj_location->district_dropdown();
//        $villages = $this->obj_location->find_village();
//        $data['village'] = $villages->result_array();
//        $rese = $this->obj_hr_type->find_active();
//        $data['hr_type'] = $rese->result_array();
//        $res = $this->obj_designation->find_active();
//        $data['designation'] = $res->result_array();
//        $res3 = $this->obj_malaria_status->find_active();
//        $data['malaria_status'] = $res3->result_array();
//        $res4 = $this->obj_types->find_active();
//        $data['public_private_types'] = $res4->result_array();
//        $res5 = $this->obj_gender->find_active();
//        $data['gender_info'] = $res5->result_array();
//        $res6 = $this->obj_status->find_active();
//        $data['status_info'] = $res6->result_array();
//        $data['hr_result'] = $this->obj_hr_info->find_all_hr_info();
//        $data['page_title'] = 'Add Facilities';
//        $data['main_content'] = $this->load->view('warehouse_management/add_warehouse', $data, TRUE);
//        $this->load->view('layout/main', $data);
//    }

    public function add_supplier() {

        if (isset($_POST) && !empty($_POST)) {
//            echo '<pre>';
//            print_r($_REQUEST);
//            echo '</pre>';
//            exit;
            if (isset($_POST['supplier_id'])) {
                $this->obj_stakeholder->stkid = $_POST['supplier_id'];
            }
            
            
            $GetMaxRank = $this->obj_stakeholder->GetMaxRank();
            $GetMaxRanks = $GetMaxRank->result_array();
            foreach ($GetMaxRanks as $row) {
                $maxvalue = $row['MaxOrder'];
            }
            $this->obj_stakeholder->stkorder = $maxvalue+1;
            
            $this->obj_stakeholder->stkname = $_POST['supplier_name'];
            $this->obj_stakeholder->contact_person = $_POST['cpname'];
            $this->obj_stakeholder->contact_emails = $_POST['email'];
            $this->obj_stakeholder->contact_numbers = $_POST['cnnumber'];
            $this->obj_stakeholder->contact_address = $_POST['address'];
            $this->obj_stakeholder->ntn = $_POST['ntn'];
            $this->obj_stakeholder->gstn = $_POST['gstn'];
            $this->obj_stakeholder->stk_type_id = $_POST['type'];
            
            $stakeholder_id = $this->obj_stakeholder->save();
            
            if ($stakeholder_id > 0) {
                if ($this->obj_stakeholder->MainStakeholder == 'NULL' || $this->obj_stakeholder->MainStakeholder == '') {
                    $Update_in_whid = $this->obj_stakeholder->Update_in_mainstk($stakeholder_id);
//                    $strSql1 = "Update stakeholder SET MainStakeholder=" . $id . " where stkid=" . $id;
//                    $rsSql = mysql_query($strSql1) or die($strSql1 . mysql_error());
                }
            }
            
            if (isset($_POST['supplier_id'])) {
                
                $this->obj->wh_name = $_POST['supplier_name'];
                $this->obj->stkid = $_POST['supplier_id'];
                $this->obj->stkofficeid = $_POST['supplier_id'];
                $this->obj->hf_cat_id = $_POST['category'];
                $this->obj->wh_type_id = $_POST['type'];
                $this->obj->is_active = 1;
                $this->obj->created_by = $_SESSION['id'];
                $this->obj->created_date = date("Y-m-d h:i:sa");
                $this->obj->modified_by = $_SESSION['id'];
                $this->obj->modified_date = date("Y-m-d h:i:sa");
                $this->obj->updatesupplier($_POST['supplier_id']);
            }else{
            
                $this->obj->wh_name = $_POST['supplier_name'];
                $this->obj->stkid = $stakeholder_id;
                $this->obj->stkofficeid = $stakeholder_id;
                $this->obj->hf_cat_id = $_POST['category'];
                $this->obj->wh_type_id = $_POST['type'];
                $this->obj->is_active = 1;
                $this->obj->created_by = $_SESSION['id'];
                $this->obj->created_date = date("Y-m-d h:i:sa");
                $this->obj->modified_by = $_SESSION['id'];
                $this->obj->modified_date = date("Y-m-d h:i:sa");



                $this->obj->save();
            }
//            exit;
            redirect(base_url() . 'warehouse_management/view_supplier', 'refresh');
        }

        $data['page_title'] = 'Add Supplier';
        $data['main_content'] = $this->load->view('warehouse_management/add_supplier', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit_wh() {
        
        $res = $this->obj->find_edit_data($_REQUEST['id']);
        $data['result'] = $res->result_array();
        $prov   = $data['result'][0]['province_id'];
        $dist   = $data['result'][0]['district_id'];
        $teh    = $data['result'][0]['tehsil_id'];
//        echo '<pre>';
//        print_r($_REQUEST);
//        print_r($data['result']);
//        echo '</pre>';
//        exit;
//        $districts = $this->obj_location->district_dropdown();
        $districts = $this->obj_location->find_by_parent_id($prov,4);
        $data['districts'] = $districts->result_array();
        
        $result = $this->obj_hr_type->find_active();
        $data['hr_type'] = $result->result_array();
        
        $result1 = $this->obj_designation->find_active();
        $data['designation'] = $result1->result_array();
        
        $stk_arr = $this->obj_stakeholder->find_all();
        $data['stakeholders'] = $stk_arr->result_array();

        $categories_arr = $this->obj_wh_categories->find_all();
        $data['categories'] = $categories_arr->result_array();

        $types_arr = $this->obj_wh_types->find_all();
        $data['types'] = $types_arr->result_array();
        
        $villages = $this->obj_location->find_village();
        $data['village'] = $villages->result_array();
        $data['hr_result'] = $this->obj_hr_info->find_all_hr_info();
        
        $res3 = $this->obj_malaria_status->find_active();
        $data['malaria_status'] = $res3->result_array();
//        $data['cities'] = $this->obj_cities->find_all();
        
        $res4 = $this->obj_types->find_active();
        $data['public_private_types'] = $res4->result_array();
        $res5 = $this->obj_gender->find_active();
        $data['gender_info'] = $res5->result_array();
        $res6 = $this->obj_status->find_active();
        $data['status_info'] = $res6->result_array();
        
//        $tehsils = $this->obj_location->find_by_location_level(5);
        $tehsils = $this->obj_location->find_by_parent_id($dist,5);
        if($tehsils)
        {
            $data['tehsils'] = $tehsils->result_array();
        }
//        $ucs = $this->obj_location->find_by_location_level(6);
        if(!empty($teh))
        {
            $ucs = $this->obj_location->find_by_parent_id($teh,6);
            if($ucs)
            {
            $data['ucs'] = $ucs->result_array();
            }
        } else {
            $data['ucs'] = array();
        }
        $data['js'] = array("warehouse_management/add_wh");
        $data['page_title'] = 'Edit Facilities';
        $data['main_content'] = $this->load->view('warehouse_management/add_warehouse', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    public function edit_supplier() {
        
        $res = $this->obj_stakeholder->find_by_id($_REQUEST['id']);
        $data['result'] = $res->result_array();

        $data['js'] = array("warehouse_management/add_wh");
        $data['page_title'] = 'Edit Facilities';
        $data['main_content'] = $this->load->view('warehouse_management/add_supplier', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate_wh() {
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'warehouse_management/index', 'refresh');
    }
    
    public function deactivate_supplier() {
        $id = $_REQUEST['id'];
//        $status = $_REQUEST['status'];
        $status = $_REQUEST['is_reporting'];
//        $this->obj->deactivate($id, $status);
        $this->obj->deactivate_supplier($id, $status);
        $this->obj_stakeholder->deactivate_supplier($id, $status);
        redirect(base_url() . 'warehouse_management/index', 'refresh');
    }
    
    public function deactivate_warehouse() {
        $id = $_REQUEST['id'];
//        $status = $_REQUEST['status'];
        $status = $_REQUEST['is_reporting'];
//        $this->obj->deactivate($id, $status);
        $this->obj->deactivate_warehouse($id, $status);
        redirect(base_url() . 'warehouse_management/view_warehouse', 'refresh');
    }
    
    public function deactivate_hr() {
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj_hr_info->deactivate($id, $status);
        redirect(base_url() . 'warehouse_management/add_wh', 'refresh');
    }
    
    public function edit_warehouse() {
        
        $res = $this->obj->find_by_id($_REQUEST['id']);
        $data['result'] = $res->result_array();
        
        $stk_arr = $this->obj_reports_model->get_stakeholder();
            if ($stk_arr)
                $data['stakeholder'] = $stk_arr->result_array();
        
        $prov_arr = $this->obj_location->find_by_parent_id(10,2);
            if ($prov_arr)
                $data['provinces'] = $prov_arr->result_array();
            
        $data['js'] = array("warehouse_management/add_warehouse");
        $data['page_title'] = 'Edit Facilities';
        $data['main_content'] = $this->load->view('warehouse_management/add_warehouse', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    public function deactivate_issue_to_center() {
        $id = $_REQUEST['id'];
//        $status = $_REQUEST['status'];
        $status = $_REQUEST['is_reporting'];
//        $this->obj->deactivate($id, $status);
        $this->obj->deactivate_center($id, $status);
        redirect(base_url() . 'warehouse_management/view_issue_to_center', 'refresh');
    }
    
    public function edit_issue_to_center() {
        
        $res = $this->obj->find_by_id($_REQUEST['id']);
        $data['result'] = $res->result_array();

        $stk_arr = $this->obj_reports_model->get_stakeholder();
            if ($stk_arr)
                $data['stakeholder'] = $stk_arr->result_array();
        
        $prov_arr = $this->obj_location->find_by_parent_id(10,2);
            if ($prov_arr)
                $data['provinces'] = $prov_arr->result_array();
        
        $data['js'] = array("warehouse_management/add_issue_to_center");
        $data['page_title'] = 'Edit Issue To Center';
        $data['main_content'] = $this->load->view('warehouse_management/add_issue_to_center', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

}
