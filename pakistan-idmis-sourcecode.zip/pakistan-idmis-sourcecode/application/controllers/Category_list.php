<?php

class Category_list extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('field_list_model');
        $this->load->model('category_field_list');
        $this->load->model('lists');
//        $this->load->model('Stakeholder');
//        $this->load->model('itminfo_tab_model');
        $this->field_list = new field_list_model();
        $this->category_field_list = new Category_field_list();
        $this->obj_lists = new Lists();
//        $this->obj_role =new Role_model();
//        $this->obj_stakeholder =new Stakeholder();
    }

    public function index() { 
        $data = array();
        
        $list_arr = $this->field_list->find_active();
        if ($list_arr)
            $data['field_list'] = $list_arr->result_array();
        
        $getproduct_type = $this->category_field_list->getproduct_type();
        if ($list_arr)
            $data['getproduct_type'] = $getproduct_type->result_array();
        
        $data['result'] = $this->category_field_list->find_all();
        $data['page_title'] = "Category Field List";
        $data['main_content'] = $this->load->view('category_list/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $data = array();
//        if (isset($_POST) && !empty($_POST)) {
//            if(isset($_POST['id'])){
//                $this->obj->pk_id = $_POST['id'];
//            }
//             
//            $this->obj->role_name = $_POST['role_name'];
//            $this->obj->status = 1;
//            $this->obj->save(); 
//            redirect(base_url() . 'assign_resources/index', 'refresh');
//        }
        
        
        if (isset($_POST) && !empty($_POST)) {
            
            if(isset($_POST['id'])){
                $this->category_field_list->pk_id = $_POST['id'];
            }
            $category = $_REQUEST['category'];
            
            //if category exist then delete from database before insert
            
            $categoryid = $this->category_field_list->getcategory($category); 
            if ($categoryid) {
                        $categoryid_arr = $categoryid->result_array();
                    foreach ($categoryid_arr as $row) {
                            $categoryids = $row['category_id'];
                        }
            }
            if($category == $categoryids)
            {
                $this->category_field_list->deletecategory($category); 
            }
            
            //deleted successfuly
            
            $field_list = $_REQUEST['field_list'];
            $is_mandatory = $_REQUEST['is_mandatory'];
//            $field_list = implode(",",$_REQUEST['field_list']);
//            print_r($field_list);exit;
            $count = count($category);
            foreach ($field_list as $index => $detail_id) {
                //Stock Received
    //            $this->obj_gwis_detail->StockReceived($detail_id);
                //Get Batch Detail
//                $stkid = $_REQUEST['stkid'];
                
//                $this->obj->role_id = $_POST['role'];
                $this->category_field_list->category_id = $_POST['category'];
                if(isset($is_mandatory[$index]))
                {
                    $this->category_field_list->is_mandatory = $is_mandatory[$index];
                }
                else{
                    $this->category_field_list->is_mandatory = '0';
                }
                $this->category_field_list->field_id = $field_list[$index];
//                $this->category_field_list->field_id = $field_list;
                $this->category_field_list->status = 1;
                $this->category_field_list->save(); 
            }
//        exit;
            redirect(base_url() . 'category_list/index', 'refresh');
        }
        
        $list_arr = $this->field_list->find_active();
        if ($list_arr)
            $data['field_list'] = $list_arr->result_array();
        
        $list_arr = $this->obj_lists->get_list(6);
            $data['product_type'] = $list_arr->result_array();
        
//        $role_arr = $this->obj_role->find_active();
//        if ($role_arr)
//            $data['roles'] = $role_arr->result_array();
//        
//        $stakeholder_arr = $this->obj_stakeholder->get_all_stk();
//        if ($stakeholder_arr)
//            $data['stakeholder'] = $stakeholder_arr->result_array();
//        exit;
        $data['page_title'] = "Assign Fields";
        $data['main_content'] = $this->load->view('category_list/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $data = array(); 
        $data['result_edit'] = $this->category_field_list->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('category_list/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->category_field_list->deactivate($id, $status);
        redirect(base_url() . 'category_list/index', 'refresh');
    }

}
