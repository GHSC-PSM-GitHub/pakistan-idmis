<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('dashboard_model');
        $this->obj = new Dashboard_model();
    }

    public function index_old() {
        $data = array();
        $data['announcements'] = $this->obj->fetch_announcements();
        $data['stock_fac_wise'] = $this->obj->fetch_stock_fac_wise();
        $data['patients_type_wise'] = $this->obj->fetch_patients_type_wise();

        $data['page_title'] = 'Dashboard';
        $data['main_content'] = $this->load->view('dashboard/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function videos() {
        $data = array();
        $data['page_title'] = 'Dashboard';
//                $data['main_content'] = $this->load->view('dashboard/index', $data, TRUE);
        $this->load->view('layout/idsmis_videos', $data);
    }

    public function lab_supervisor() {
        $data = array();
        $data['page_title'] = 'Dashboard';
        $data['main_content'] = $this->load->view('dashboard/lab_supervisor', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function lab_worker() {
        $data = array();
        $data['page_title'] = 'Dashboard';
        $data['main_content'] = $this->load->view('dashboard/lab_worker', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function index() {
        $data = array();
        $data['page_title'] = 'Dashboard';
        $from = $this->input->post("from_date");
        $to = $this->input->post("to_date");
        if (empty($from)) {
            $from = date('2021-01-01');
            $to = date('Y-m-d');
        }
        $data['from_date'] = $from;
        $data['to_date'] = $to;

        $data['total_vouchers'] = $this->dashboard_model->total_vouchers($from, $to);
        $data['monthly_transaction'] = $this->dashboard_model->monthly_transaction($from, $to);
        $data['type_wise_transaction'] = $this->dashboard_model->type_wise_transaction($from, $to);
        $data['product_wise_soh'] = $this->dashboard_model->product_wise_soh($from, $to);
        $data['max_soh'] = $this->dashboard_model->max_soh($from, $to);
        $data['min_soh'] = $this->dashboard_model->min_soh($from, $to);
        $data['expired_product'] = $this->dashboard_model->expired_product($from, $to);
        $data['expire_stock'] = $this->dashboard_model->expire_stock($from, $to);
        $data['main_content'] = $this->load->view('dashboard/main_dashboard', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

}
