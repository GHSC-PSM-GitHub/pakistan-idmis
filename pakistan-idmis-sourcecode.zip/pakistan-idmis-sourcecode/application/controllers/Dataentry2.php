<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Dataentry2 extends CI_Controller {

    public function __construct() {
//load database in autoload libraries 
        parent::__construct();
        $this->load->model('Dataentry2_model');
    }

    function warehouse() {
        $data['page_title'] = 'page_title';
        $products = new Dataentry2_model();
        $data['data'] = $products->get_districtstore();
        $data['data1'] = $products->get_hfstore();
//        echo '<pre>';
//        print_r($data['data1']);
//        exit();
//        foreach ($data['data1'] as $row) {
//            $data['data2'] = $products->GetLast3MonthsHF($row['wh_id']);
//        }
		//$data['last_update'] = $products->get_last_update();
		//$data['temp'] = $products->getlast3months();
//        echo '<pre>';
//        print_r($data['temp']);
//        exit();
//        $data['data1'] = $products->get_data();
        $data['main_content'] = $this->load->view('inventory_management/consumption_form2', $data, TRUE);
        $this->load->view('layout/main', $data);
//        print_r($data);exit;
    }

    function add_cons() {
        $data['page_title'] = 'page_title';
        $products = new Dataentry2_model();
        $data['data3'] = $products->get_products();
        $data['main_content'] = $this->load->view('inventory_management/add_consumption_dist_store', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    function add_cons_hf() {
        $wh_id = $this->input->get('wh_id');
        $date = $this->input->get('date');
        $msg = $this->input->get('msg');
        if(isset($msg) && !empty($msg)){
            $data['message'] = "Data has been saved successfully!";
        }
        
        $products = new Dataentry2_model();
        $dataob = $products->get_last_month_ob($wh_id,$date);
        
        $item_ob_arr = array();
        if(!empty($dataob)){
            foreach($dataob as $rr){
                //echo "<pre>";
                //print_r($rr);
                $item_ob_arr[$rr['item_id']] = $rr['closing_balance'];
            }
        }
        
        $datarcv = $products->get_this_month_rcv($wh_id,$date);
        
        $item_rcv_arr = array();
        if(!empty($datarcv)){
            foreach($datarcv as $rrcv){
                //echo "<pre>";
                //print_r($rr);
                $item_rcv_arr[$rrcv['item_id']] = $rrcv['Qty'];
            }
        }
        
        //print_r($item_ob_arr);
        //exit;
        
        $data['item_opening_balances'] = $item_ob_arr;
        $data['item_received_balances'] = $item_rcv_arr;
        $data['page_title'] = 'page_title';
        
        $data['data3'] = $products->get_products();
        $data['wh_id'] = $wh_id;
        $data['rdate'] = $date;
        
        $data['result'] = $products->get_reporting_data($wh_id,$date);
        
        $data['main_content'] = $this->load->view('inventory_management/add_consumption', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    function insert_data() {
        $arr = array();
        $arr = $this->input->post('ob');
        $rcv = $this->input->post('rcv');
        $iss = $this->input->post('iss');
        $adja = $this->input->post('adja');
        $adjb = $this->input->post('adjb');
        $cb = $this->input->post('cb');
        $rdate = $this->input->post('rdate');
        $wh_id = $this->input->post('wh_id');
//        print_r($iss);
        //$formarray = arrray
        $this->Dataentry2_model->delete_existing($wh_id,$rdate);
         
        foreach ($arr as $k => $ob) {
            $formarray = array('opening_balance' => $ob,
                'item_id' => $k,
                'received_balance' => $rcv[$k],
                'issue_balance' => $iss[$k],
                'adjustment_positive' => $adja[$k],
                'adjustment_negative' => $adjb[$k],
                'closing_balance' => $cb[$k],
                'reporting_date' => $rdate, //date_format($rdate,'Y-m-01'),
                'warehouse_id' => $wh_id);
//         print_r($formarray);exit;
            $this->Dataentry2_model->insert($formarray);
        }
//         foreach($arr as $k=>$ob)
//         {
//             $this->Dataentry2_model->warehouse_id = $wh_id;
//             $this->Dataentry2_model->item_id = $k;
//             $this->Dataentry2_model->ob = $ob;
//             $this->Dataentry2_model->rcv = $rcv[$k];
//             $this->Dataentry2_model->issue = $iss[$k];
//             $this->Dataentry2_model->adja = $adja[$k];
//             $this->Dataentry2_model->adjb = $adjb[$k];
//             $this->Dataentry2_model->cb = $cb[$k];
//             $this->Dataentry2_model->ip_address = $_SERVER['REMOTE_ADDR'];
//             $this->Dataentry2_model->created_by = $_SESSION['id'];
//             $this->Dataentry2_model->reporting_date = $rdate;
//            $this->Dataentry2_model->insert();
//         }
        redirect(base_url() . 'dataentry2/warehouse');
    }

    function insert_data_dist() {
        $formarray = array('wh_obl_a' => $this->input->post('ob'));
//         print_r($formarray);exit;
        $this->Dataentry2_model->insert_dist_store_data($formarray);
        redirect(base_url() . 'Dataentry2/add_cons');
    }

    function loadlast3months() {
        $flag1 = FALSE;
        if (isset($_SESSION['id'])) {
        $userid = $_SESSION['id'];
        $objwharehouse_user->m_npkId = $userid;
        $province = $_SESSION['province_id'];
        $mainStk = $_SESSION['stakeholder_id'];
        $district_id = $_SESSION['district_id'];
        }
        if (isset($_REQUEST['wh_id'])) {
            $wh_Id = $_REQUEST['wh_id'];
            
            $qryRes = $this->Dataentry2_model->getwarehouseinfo();
            
            
            $mainStk = $qryRes['stkid'];
            $lastUpdate = (!empty($qryRes['last_update'])) ? $qryRes['last_update'] : 'Not yet reported';
            //following condition removed on 3 aug 2017 , for lock/unlock data entry
            //if ($qryRes['prov_id'] == 2 && $mainStk == 1) {
            //check is_lock_data_entry
            if ($_SESSION['user_role'] != '2' && $_SESSION['user_role'] != '26') {
                if ($qryRes['is_lock_data_entry'] == 1 && $_SERVER['SERVER_NAME'] != 'localhost') {
                    echo '<span class="help-block">Last Update: ' . $lastUpdate . '</span>';
                    echo '<span class="help-block" style="color:#E04545">Data entry date for this facility has passed. Please contact administrator to enter data.</span>';
                    exit;
                }
            }

            //}
        } else {
            die('No warehouses selected.');
        }
//check dataEntryURL
        if (isset($_REQUEST['dataEntryURL'])) {
            //get dataEntryURL
            $dataEntryURL = $_REQUEST['dataEntryURL'];
        }

        $objReports->wh_id = $wh_Id;
        $objReports->stk = $mainStk;
        $objReports->province_id = $province;
        $objReports->district_id = $district_id;
//Get Last Report Date HF
        $LastReportDate = $objReports->GetLastReportDateHF();


        if ($LastReportDate != "") {
            $LRD_dt = new DateTime($LastReportDate);
            //Get Pending Report Month HF
            $NewReportDate = $objReports->GetPendingReportMonthHF();

            //Check for PWD KP
            if ($NewReportDate == "" && $qryRes['prov_id'] == 3 && $mainStk == 1) {
                $cur_day = date("d");
                if ($cur_day >= 25) {
                    if ($LRD_dt->format("m") != date("m") && $LRD_dt->format("y") != date("y")) {
                        $NewReportDate = date("Y-m-d");
                    }
                }
            }

            if ($NewReportDate != "") {
                $NRD_dt = new DateTime($NewReportDate);
                echo '<span class="help-block">Last Update: ' . $lastUpdate . '</span>';
                $do = urlencode("Z" . ($wh_Id + 77000) . '|' . $NRD_dt->format('Y-m-') . '01|1');
                ?>
                <td>
                <?php
                // Show last three months for which date is entered
                $allMonths = '';

                if ($_SESSION['user_province'] != 2 || ($_SESSION['user_province'] == 2 && !empty($qryRes['editable_data_entry_months']) && $qryRes['editable_data_entry_months'] > 1)) {
                    //Get Last 3 Months HF
                    $last3Months = $objReports->GetLast3MonthsHF();
                    for ($i = 0; $i < sizeof($last3Months); $i++) {
                        $L3M_dt = new DateTime($last3Months[$i]);
                        $do3Months = urlencode("Z" . ($wh_Id + 77000) . '|' . $L3M_dt->format('Y-m-') . '01|0');
                        //url
                        $url = $dataEntryURL . "?Do=" . $do3Months;
                        //all months
                        //echo "Data Entry is Lock";
                        $allMonths[] = "<a href=\"javascript:void(0);\" onclick=\"openPopUp('$url')\" class=\"btn btn-xs red\">" . $L3M_dt->format('M-Y') . " <i class=\"fa fa-edit\"></i></a>";
                    }
                }
                if (!empty($qryRes['ecr_start_month'])) {
                    echo " <a href=\"../ecr/search_clients.php\"   class=\"btn btn-xs blue\"> Open ECR </a> ";
                    $flag1 = TRUE;
                } else {
                    $url = $dataEntryURL . "?Do=" . $do;
                    echo " <a href=\"javascript:void(0);\" onclick=\"openPopUp('$url')\" class=\"btn btn-xs green\"> Add " . $NRD_dt->format('M-y') . " Report <i class=\"fa fa-plus\"></i></a> ";
                    echo (!empty($allMonths)) ? implode(' ', $allMonths) : '';
                    $flag1 = TRUE;
                }
                ?>

                </td>
                    <?php
                } else {
                    echo '<span class="help-block">Last Update: ' . $lastUpdate . '</span>';
                    ?>
                <td>
                    <?php
                    // Show last three months for which date is entered
                    $allMonths = '';
                    //Get Last 3 Months HF
                    $last3Months = $objReports->GetLast3MonthsHF();
                    for ($i = 0; $i < sizeof($last3Months); $i++) {
                        $L3M_dt = new DateTime($last3Months[$i]);
                        $do3Months = urlencode("Z" . ($wh_Id + 77000) . '|' . $L3M_dt->format('Y-m-') . '01|0');
                        //url
                        $url = $dataEntryURL . "?Do=" . $do3Months;
                        //all month

                        $allMonths[] = "<a href=\"javascript:void(0);\" onclick=\"openPopUp('$url')\" class=\"btn btn-xs red\">" . $L3M_dt->format('M-Y') . " <i class=\"fa fa-edit\"></i></a>";
                    }
                    echo (!empty($allMonths)) ? implode(' ', $allMonths) : '';
                    ?>

                </td>
                    <?php
                }
            }

            if ($flag1 != TRUE) {
                //Get This Month Report Date
                $NRD_dt = new DateTime($objReports->GetThisMonthReportDate());
                if (substr($LastReportDate, 0, 7) != $NRD_dt->format('Y-m')) {
                    if (substr($LastReportDate, 0, 7) < $NRD_dt->format('Y-m')) {
                        echo '<span class="help-block">Last Update: ' . $lastUpdate . '</span>';
                        $do = urlencode("Z" . ($wh_Id + 77000) . '|' . $NRD_dt->format('Y-m-') . '01|1');
                        $url = $dataEntryURL . "?Do=" . $do;
                        echo "<a href=\"javascript:void(0);\" onclick=\"openPopUp('$url')\" class=\"btn btn-xs green\"> Add " . $NRD_dt->format('M-y') . " Report <i class=\"fa fa-plus\"></i></a>";
                    }
                }
            }
            
}
}

?>
