<?php

class Field_list extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('Field_list_model');
        $this->obj = new Field_list_model();
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = "Field List";
        $data['main_content'] = $this->load->view('field_list/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            
            if(isset($_POST['id'])){
                $this->obj->pk_id = $_POST['id'];
                $this->obj->field_name = $_POST['name'];
                $this->obj->updatename(); 
            }
            else {
                $this->obj->field_name = $_POST['name'];
                $this->obj->type = $_POST['type'];
                $this->obj->rank = $_POST['rank'];


                $last_id = $this->obj->getLastFieldID();            
                    if (!empty($last_id)) {
                        if ($last_id)
                            $last_idd = $last_id->result_array();
                        foreach ($last_idd as $row) {
                                $lastid = $row['field_id'];
    //                            $fieldids = substr($lastid, -1);
                                $fieldids = (int) filter_var($lastid, FILTER_SANITIZE_NUMBER_INT);
                                $fieldid = $fieldids + 1;
                            }
                    }

                    if ($lastid == NULL) {
                        $lastid = 0;
                    }

                $this->obj->field_id = "field".$fieldid;


                $this->obj->created_date = date("Y-m-d");
                $this->obj->created_by = $_SESSION['id'];
                $this->obj->status = 1;
                $this->obj->save(); 
            }
            redirect(base_url() . 'field_list/index', 'refresh');
        }
//        exit;
        $data['page_title'] = "Field List";
        $data['main_content'] = $this->load->view('field_list/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $data = array(); 
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('field_list/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'field_list/index', 'refresh');
    }

}
