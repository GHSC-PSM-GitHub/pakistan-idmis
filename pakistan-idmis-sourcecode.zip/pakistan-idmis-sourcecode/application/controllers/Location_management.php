<?php

class Location_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user(); 
        $this->load->model('locations'); 
        $this->obj=new Locations(); 
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all();
         $data['page_title'] = ' Locations';
        $data['main_content'] = $this->load->view('location_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add_location() { 

        if (isset($_POST) && !empty($_POST)) {
            if (isset($_POST['pk_id'])) {
                $this->obj->pk_id = $_POST['pk_id'];
            }
            $this->obj->location_name = $_POST['location_name'];
            $this->obj->location_level = $_POST['location_level'];
            if ($_POST['location_level'] == 4) {
                $this->obj->parent_id = $_POST['province'];
                $this->obj->location_type = 4;
            } else if ($_POST['location_level'] == 5) {
                $this->obj->parent_id = $_POST['district'];
                $this->obj->location_type = 14;
            } else if ($_POST['location_level'] == 6) {
                $this->obj->parent_id = $_POST['tehsil'];
                $this->obj->location_type = 13;
            }
             $this->obj->longitude = $_POST['longitude'];
              $this->obj->latitude = $_POST['latitude'];
            $this->obj->status = 1;
            $this->obj->created_by = $_SESSION['id'];
            $this->obj->save();
//            exit;
            redirect(base_url() . 'location_management/index', 'refresh');
        }  
        $data['page_title'] = 'Add Locations';
        $data['main_content'] = $this->load->view('location_management/add_location', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit_location() { 
        $result = $this->obj->find_by_id($_REQUEST['id']);
        $result_array = $result->result_array();
        foreach ($result_array as $row) {
            if ($row['location_level'] == 5) {
                $data['district'] = $this->obj->find_by_id($row['parent_id']);
            } else if ($row['location_level'] == 6) {
                $tehsil = $this->obj->find_by_id($_REQUEST['id']);
                $tehsil_arr = $tehsil->result_array();
                foreach ($tehsil_arr as $row_1) {
                    $tehsil_id = $row_1['parent_id'];
                    $data['tehsil_id'] = $tehsil_id;
                    $tehsils = $this->obj->find_by_id($tehsil_id);
                    $teh_arr = $tehsils->result_array();
                    foreach ($teh_arr as $row1) {
                        $data['district'] = $this->obj->find_by_id($row1['parent_id']);
                    }
                }
            }
        }
        $data['districts'] = $this->obj->district_dropdown();
         $data['provinces'] = $this->obj->find_by_location_level(2);
        $data['tehsils']=$this->obj->find_by_location_level(5);
        $data['result'] = $result;
        $data['main_content'] = $this->load->view('location_management/add_location', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate_location() { 
        $id = $_REQUEST['id'];
        $this->obj->deactivate($id);
        redirect(base_url() . 'location_management/index', 'refresh');
    }

}
