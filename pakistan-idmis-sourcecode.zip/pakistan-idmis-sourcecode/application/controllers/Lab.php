<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lab extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('patient_lab_master_model');
        //$this->load->model('locations');
	}
	
	public function test_supervisor()
	{
		$data = array();
		$data['page_title'] = 'Lab Supervisor';

		$lab_master = new patient_lab_master_model();
		$data['data'] = $lab_master->find_all();

        $data['main_content'] = $this->load->view('lab/test_supervisor', $data, TRUE);
        $this->load->view('layout/main', $data);
	}

	public function lab_worker_dataentry()
	{
		$data = array();
		$data['page_title'] = 'Lab Supervisor';

		$lab_master = new patient_lab_master_model();
		$data['data'] = $lab_master->find_all();

        $data['main_content'] = $this->load->view('lab/lab_worker_dataentry', $data, TRUE);
        $this->load->view('layout/main', $data);
	}

	public function lab_worker()
	{
		$data = array();
		$data['page_title'] = 'Lab Worker';

		$lab_master = new patient_lab_master_model();
		$data['data'] = $lab_master->find_all();

        $data['main_content'] = $this->load->view('lab/lab_worker', $data, TRUE);
        $this->load->view('layout/main', $data);
	}

	public function ajax_lab_worker()
	{
		echo create_combo("lab_worker",array("Lab Worker 1", "Lab Worker 2"));
		echo '<br><div class="alert alert-success" role="alert" style="display:none">
		<span id="success_msg"></span>
		</div>';
		echo "";
	}

}
