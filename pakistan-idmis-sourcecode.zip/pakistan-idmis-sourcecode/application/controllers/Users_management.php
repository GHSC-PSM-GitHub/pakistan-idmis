<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Users_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('user');
        $this->load->model('locations');
        $this->load->model('warehouse');
        $this->load->model('Stakeholder');
        $this->load->model('role_model');
        $this->obj = new User();
        $this->obj_location = new Locations();
        $this->obj_warehouse = new Warehouse();
        $this->obj_stakeholder =new Stakeholder();
        $this->obj_role =new Role_model();
        $this->load->model('reports_model');
        $this->obj_reports_model= new Reports_model();
        
    }

    public function index() {
        $data = array();
        $role = $this->session->userdata('role');
        if ($role == 8) {
            $data['result'] = $this->obj->find_all($this->session->userdata('stakeholder_id'));
        }else{
            $data['result'] = $this->obj->find_all();
        }
        $data['page_title'] = 'Manage Users';
        $data['main_content'] = $this->load->view('users_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        if (!empty($_POST)) {
            if (isset($_POST['user_id'])) {
                $this->obj->pk_id = $_POST['user_id'];
            }
//            echo $_POST['user_id'];exit;
            $this->obj->username = $_POST['username'];
            $this->obj->designation = $_POST['designation'];
            $this->obj->login_id = $_POST['login_id'];
            if (isset($_POST['password']) && !empty($_POST['password'])) {
                $this->obj->password = md5($_POST['password']);
            }
            $this->obj->email = $_POST['email'];
            $this->obj->phone = $_POST['phone'];
            $this->obj->province_id = $_POST['province'];
            if(isset($_POST['district']))
            {
                $this->obj->district_id = $_POST['district'];
            }
            // $this->obj->district_id = $_POST['district'];
            $this->obj->role_id = $_POST['role_id'];
            // echo $this->session->userdata('id');die;
            $this->obj->created_by = $this->session->userdata('id');
            $this->obj->modified_by = $this->session->userdata('id');
            $this->obj->stakeholder_id = $this->session->userdata('stakeholder_id');
            $this->obj->warehouse_id = $_POST['hf'];
            $this->obj->is_active = $_POST['status'];
            $file = $this->obj->save();
            
            $this->obj->del_user_stkid($file); 
            
            $stkids = $_REQUEST['stkid'];
//            print_r($stkids);exit;
            $count = count($stkids);
            foreach ($stkids as $index => $detail_id) {
                //Stock Received
    //            $this->obj_gwis_detail->StockReceived($detail_id);
                //Get Batch Detail
//                $stkid = $_REQUEST['stkid'];
                
//                $this->obj->role_id = $_POST['role'];
//                $this->obj->stk_id = $_POST['stkid'];
//                $this->obj->product_id = $productlist[$index];
//                $this->obj->status = 1;
                
                $this->obj->add_user_stkid($stkids[$index],$file); 
            }

            redirect(base_url() . 'users_management/index', 'refresh');
        } else {
            $province_id = 1;
            $lvl = 4;
            $result = $this->obj_location->find_by_parent_id($province_id, $lvl);
            $data['provinces'] = $this->obj_location->find_active()->result_array();
//            $hf_arr = $this->obj_warehouse->gethf();
//            $data['hf'] = $hf_arr->result_array();
            $wh_arr = $this->obj_warehouse->find_all();
            if ($wh_arr)
                $data['warehouse'] = $wh_arr->result_array();
            
//            $stakeholder_arr = $this->obj_stakeholder->get_all_stk();
//            $stakeholder_arr = $this->obj_reports_model->get_stakeholder();
            $stakeholder_arr = $this->obj_stakeholder->get_all_stk_id();
            if ($stakeholder_arr)
                $data['stakeholder'] = $stakeholder_arr->result_array();
            
            $role_arr = $this->obj_role->find_active();
            if ($role_arr)
                $data['roles'] = $role_arr->result_array();
            
            $data['page_title'] = 'Add Users';
            $data['districts'] = $result;
            $data['main_content'] = $this->load->view('users_management/add_user', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }

    public function edit() {
        $user_id = $_REQUEST['userid'];
        $file = $this->obj->find_by_id_get_stk($user_id);
//        $districts = $this->obj_location->district_dropdown();
//        $data['districts'] = $districts->result_array();
//        $hf_arr = $this->obj_warehouse->find_active();
//        $data['hf'] = $hf_arr->result_array();
//        $wh_arr = $this->obj_warehouse->find_all();
//            if ($wh_arr)
//                $data['warehouse'] = $wh_arr->result_array();
        $data['result'] = $file->result_array();
        $data['user_id'] = $user_id;
        $data['page_title'] = 'Edit User';
        $province_id = 1;
        $lvl = 4;
        $result = $this->obj_location->find_by_parent_id($province_id, $lvl);
//            $hf_arr = $this->obj_warehouse->gethf();
//            $data['hf'] = $hf_arr->result_array();
        $wh_arr = $this->obj_warehouse->find_all();
        if ($wh_arr)
            $data['warehouse'] = $wh_arr->result_array();

//            $stakeholder_arr = $this->obj_stakeholder->get_all_stk();
//            $stakeholder_arr = $this->obj_reports_model->get_stakeholder();
        $stakeholder_arr = $this->obj_stakeholder->get_all_stk_id();
        if ($stakeholder_arr)
            $data['stakeholder'] = $stakeholder_arr->result_array();

        $role_arr = $this->obj_role->find_active();
        if ($role_arr)
            $data['roles'] = $role_arr->result_array();
//        echo '<pre>';
//        print_r($data['result']);
//        echo '</pre>';
//        exit;
        $data['main_content'] = $this->load->view('users_management/add_user', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    public function change_pass() {
        $user_id = $_REQUEST['userid'];
        $file = $this->obj->find_by_id($user_id);
        $data['result'] = $file->result_array();
        $data['user_id'] = $user_id;
        $data['page_title'] = 'Edit User';
//        echo '<pre>';
//        print_r($data['result']);
//        echo '</pre>';
//        exit;
        $data['main_content'] = $this->load->view('users_management/change_pass', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    public function change_my_pass() {
        $user_id = $this->session->id;
        $file = $this->obj->find_by_id($user_id);
        $data['result'] = $file->result_array();
        $data['user_id'] = $user_id;
        $data['page_title'] = 'Edit User';
//        echo '<pre>';
//        print_r($data['result']);
//        echo '</pre>';
//        exit;
        $data['main_content'] = $this->load->view('users_management/change_my_pass', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function change_status() {

        $this->obj->pk_id = $_REQUEST['id'];
        $this->obj->is_active = $_REQUEST['status'];
        $file = $this->obj->is_active();
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = 'Manage Users';
        $data['main_content'] = $this->load->view('users_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    public function update_pass() {

//            print_r($_POST);exit;
            if (!empty($_POST)) {
                if (isset($_POST['user_id'])) {
                    $this->obj->pk_id = $_POST['user_id'];
                }
              
                if (isset($_POST['password']) && !empty($_POST['password'])) {
                    $this->obj->password = md5($_POST['password']);
                }
               
                $file = $this->obj->save();

                if($this->session->id == '1'){
                    redirect(base_url() . 'users_management/index', 'refresh');
                }
                else{
                    redirect(base_url() . 'dashboard/index', 'refresh');
                }
            }
    }
}
