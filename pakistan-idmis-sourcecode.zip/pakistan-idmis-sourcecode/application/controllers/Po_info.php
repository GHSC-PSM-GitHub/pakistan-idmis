<?php

class Po_info extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('lists');
        $this->load->model('po_infos');
        $this->obj_lists = new Lists();
        $this->obj = new Po_infos();
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all_info();
        $data['page_title'] = "PO Info";
        $data['main_content'] = $this->load->view('po_info/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            if(isset($_POST['id'])){
                $this->obj->stkid = $_POST['id'];
            }
            
            $this->obj->type = $_POST['po_type'];
            $this->obj->number = $_POST['po_number'];
            $this->obj->date = date('Y-m-d', strtotime($_POST['po_info_date']));
            $this->obj->is_active = 1;
            $id = $this->obj->save(); 
            
            redirect(base_url() . 'po_info/index', 'refresh');
        }
        
//        $rslvls = $this->obj->GetAlllevels();
//        $data['rslvl'] = $rslvls->result_array();
        
        $po_arr = $this->obj_lists->get_list(15);
        if ($po_arr)
            $data['po_arr'] = $po_arr->result_array();
        
//        $rsstktypes = $this->obj->Getmanufacturer_types();
//        $data['rsstktype'] = $rsstktypes->result_array();
//        exit;
        $data['page_title'] = "PO Info";
        $data['main_content'] = $this->load->view('po_info/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $data = array(); 
        
        $po_arr = $this->obj_lists->get_list(15);
        if ($po_arr)
            $data['po_arr'] = $po_arr->result_array();
        
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('po_info/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'po_info/index', 'refresh');
    }

}
