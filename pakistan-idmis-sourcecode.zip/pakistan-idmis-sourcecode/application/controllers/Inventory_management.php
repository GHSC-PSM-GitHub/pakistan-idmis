<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Inventory_management extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		check_login_user();
		$this->load->model('Product_model');
		$this->load->model('Stock_master_tbl_model');
		$this->load->model('Stock_detail_tbl_model');
		$this->load->model('Stock_batch_tbl_model');
		$this->load->model('Warehouse');
		$this->load->model('Gwis_stock_detail_model');
		$this->load->model('Gwis_stock_master_model');
		//        $this->load->model('Patients_model');
		$this->load->model('lists');
		$this->load->model('stakeholder');
		$this->load->model('itminfo_tab_model');
		$this->load->model('Stock_document_type');
		$this->load->model('funding_source_model');
		$this->load->model('challan_type_model');
		$this->load->model('reports_model');
		$this->load->model('field_list_model');
		$this->load->model('lists');
		$this->load->model('po_infos');
		$this->load->model('transport_req_master');
		$this->load->model('transport_req_detail');
		$this->load->model('transport_product_info');
		$this->load->model('tbl_hf_data');
		$this->load->model('locations');
		$this->obj_transport_req_master = new Transport_req_master();
		$this->obj_transport_req_detail = new Transport_req_detail();
		$this->obj_transport_product_info = new Transport_product_info();
		$this->obj_po_infos = new Po_infos();
		$this->obj_lists = new Lists();
		$this->field_list = new field_list_model();
		$this->obj_stock_master = new Stock_master_tbl_model();
		$this->obj_stock_detail = new Stock_detail_tbl_model();
		$this->obj_stock_batch = new Stock_batch_tbl_model();
		$this->obj_product = new Product_model();
		$this->obj_warehouse = new Warehouse();
		//        $this->obj_patient = new Patients_model();
		$this->obj_lists = new Lists();
		$this->obj_stakeholder = new Stakeholder();
		$this->obj_itminfo = new Itminfo_tab_model();
		$this->obj_document_type = new Stock_document_type();
		$this->obj_funding_source = new Funding_source_model();
		$this->obj_gwis_detail = new Gwis_stock_detail_model();
		$this->obj_gwis_master = new Gwis_stock_master_model();
		$this->obj_challan_type = new Challan_type_model();
		$this->obj_reports_model = new Reports_model();
		$this->obj_tbl_hf_data = new Tbl_hf_data();
		$this->obj_location = new Locations();
	}

	public function stock_receive()
	{
		if (isset($_REQUEST['stockid']) && !empty($_REQUEST['stockid'])) {

			if (isset($_POST['pk_id'])) {
				$this->obj->pk_id = $_POST['pk_id'];
			}

			if (isset($_REQUEST['stockid']) && !empty($_REQUEST['stockid'])) {
				$masterstock_id = '';
				if (isset($_REQUEST['stock_id']) && !empty($_REQUEST['stock_id'])) {
					$masterstock_id = $_REQUEST['stock_id'];
				}

				// if (isset($_POST['pk_id'])) {
				// 	$this->obj->pk_id = $_POST['pk_id'];
				// }



				if (isset($_REQUEST['stockid']) && !empty($_REQUEST['stockid'])) {

					if (isset($_REQUEST['approve_or_rej']) && !empty($_REQUEST['approve_or_rej'])) {
						$electronic_approval = $_REQUEST['approve_or_rej'];
					}
					$uploadedFile = '';
					$masterloop = 1;
					$rvoucher = 1;



					//$dc_quantityy = $_REQUEST['dc_quantityy'];
					$actual_rec_qty = $_REQUEST['actual_rec_qty'];
					$pi_quantity = $_REQUEST['pi_quantity'];
					$missing = $_REQUEST['missing'];
					$comment = $_REQUEST['comment'];

					$dc_quantity = $_REQUEST['dc_quantity'];
					$ti_quantity = $_REQUEST['ti_quantity'];

					foreach ($_REQUEST['approvalcode'] as $indx => $detail_ida) {

						$approvefrom = $_REQUEST['approve_from'];
						$approveto = $_REQUEST['approve_to'];
						$processtatus = $_REQUEST['process_status'];
						$finalstatus = $_REQUEST['final_status'];

						$uploadedFile = '';
						$uploadDir = 'uploads/';
						if (!empty($_FILES["fileToUpload"]["name"])) {
							//                    $uploadedFile = 'test';
							// File path config 
							$fileName = basename($_FILES["fileToUpload"]["name"]);
							$targetFilePath = $uploadDir . $fileName;
							$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

							// Allow certain file formats 
							$allowTypes = array('pdf', 'doc', 'docx', 'jpg', 'png', 'jpeg');
							if (in_array($fileType, $allowTypes)) {
								// Upload file to the server 
								if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFilePath)) {
									$uploadedFile = $fileName;
								}
							}
						}

						if (!empty($uploadedFile)) {
							$fileto = $uploadedFile;
						} else if (isset($_REQUEST['file']) && !empty($_REQUEST['file'])) {
							$fileto = $this->input->post('file');
						}

						$trn_no  = $this->obj_gwis_master->generate_grn_number($processtatus[$indx]);

						$masterstock_id = $this->obj_gwis_master->clone_record_grn($masterstock_id, $approvefrom[$indx], $approveto[$indx], $processtatus[$indx], $finalstatus[$indx], $fileto, $_SESSION['id'], 3, 4, $trn_no);

						//        print_r($stock_ids);exit;
						foreach ($_REQUEST['stockid'] as $index => $detail_id) {


							if ($electronic_approval[$index] == '1') {

								$adj_type = 3;

								$this->obj_gwis_detail->update_batch_dtl_status($detail_id);
								$new_detail_id = $this->obj_gwis_detail->clone_record($detail_id, $masterstock_id, $missing[$index], $comment[$index], $adj_type);


								if ($processtatus[$indx] == '10') {
									//Start SMS Code
									//                        $this->sms($mobileno,$message);
									// End SMS Code
									// Start Email Code
									if ($_REQUEST['rejected_voucher'] == '2') {
										$stock_master_id_email = $_REQUEST['stkmasterid'];
									} else if (isset($_REQUEST['pkmasterid']) && !empty($_REQUEST['pkmasterid'])) {
										$stock_master_id_email = $_REQUEST['pkmasterid']; //
									} else {
										$stock_master_id_email = $masterstock_id;
									}
									$message = "New voucher no " . $_REQUEST['refernce_number'] . " created by " . $_SESSION['name'] . " Please Approve.";
									$this->email_printissue('muhammadsabir@ntp.gov.pk', $message, $stock_master_id_email);
									//End Email Code
								}

								//                $this->obj_gwis_master->status_id = '3';
								//                $this->obj_gwis_master->updategwisstatus('3',$_REQUEST['masterid']);
								//            }
							}
						}
					}
					// $this->obj_gwis_master->updatemasterpkid($_REQUEST['masterpkid']);
				}
			}




			if (isset($_REQUEST['detailid']) && !empty($_REQUEST['detailid'])) {
				$pk_id = $_REQUEST['detailid'];
				$this->obj_gwis_detail->receiveupdate_details_temp($pk_id);
			}


			$data['form'] = $_POST;
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$storage_arr = $this->obj_lists->get_list(16);
			$data['storage'] = $storage_arr->result_array();

			//            $suppliers_arr = $this->obj_stock_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();
			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$warehouse_arr = $this->obj_stakeholder->find_warehouseinfo();
			if ($warehouse_arr)
				$data['warehouses'] = $warehouse_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();

			$challan_type_arr = $this->obj_challan_type->find_active();
			if ($challan_type_arr)
				$data['challan_type'] = $challan_type_arr->result_array();
			if (empty($stock_master_id)) {
				$stock_master_id = '';
			}
			//            $stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			//            if ($stock_master_record)
			//                $data['stock_master_records'] = $stock_master_record->result_array();
			//            $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($stock_master_id);

			$code_arr = $this->obj_gwis_master->get_assign_approvalcode(3);
			if ($code_arr) {
				$data['approval_code'] = $code_arr->result_array();
				$approvalcodes = $code_arr->result_array();
			}
			$process_status_ids = array();
			if ($approvalcodes) {
				foreach ($approvalcodes as $row) {
					$approver_designation = preg_split("/\,/", $row['approver_designation']);
					$approver_desg_id = preg_split("/\,/", $row['approver_desg_id']);
					$process_statuss = preg_split("/\,/", $row['process_status']);
					$approval_codess = preg_split("/\,/", $row['approval_code']);
					for ($i = 0; $i < count($approval_codess); $i++) {
						$process_status_ids[] = $process_statuss[$i] - 1;
					}
					$process_status_nmbr = implode(",", $process_status_ids);
				}
			}

			//            $process_status_nmbr = '';
			$process_status_nmbrr = '';
			//            $qry_getprocess_status = $this->obj_gwis_master->getprocess_status(3);
			//            if($qry_getprocess_status)
			//            {
			//                $dataprocessstatus = $qry_getprocess_status->result_array();
			//            }
			//            foreach ($dataprocessstatus AS $row)
			//            {
			//                $process_status_nmbr = $row['process_status'];  
			//            }

			$qry_getprocess_statuss = $this->obj_gwis_master->getprocess_statusmax(2);
			if ($qry_getprocess_statuss) {
				$dataprocessstatuss = $qry_getprocess_statuss->result_array();
			}
			foreach ($dataprocessstatuss as $row) {
				$process_status_nmbrr = $row['process_status'];
			}

			$this->obj_gwis_master->status_id = '2,3';
			if (in_array("69", $approver_desg_id)) {
				$this->obj_gwis_master->process_status = $process_status_nmbr . ',' . $process_status_nmbrr;
				$dtlchk = "AND stock_batch.dtl_status = 'completed'";
			} else {
				$this->obj_gwis_master->process_status = $process_status_nmbr;
				$dtlchk = "";
			}
			$this->obj_gwis_master->process_status = $process_status_nmbr . ',' . $process_status_nmbrr;
			$qry_vouchers = $this->obj_gwis_master->get_grn_issue_vouchers($dtlchk);
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}

			$rejqry_getprocess_status = $this->obj_gwis_master->getprocess_status(3);
			if ($rejqry_getprocess_status) {
				$rejdataprocessstatus = $rejqry_getprocess_status->result_array();
			}
			foreach ($rejdataprocessstatus as $row) {
				$rejprocess_status_nmbr = $row['process_status'];
			}
			$this->obj_gwis_master->status_id = '3';
			$this->obj_gwis_master->process_status = $rejprocess_status_nmbr;
			$qry_rej_vouchers = $this->obj_gwis_master->get_rejected_vouchers();
			if ($qry_rej_vouchers) {
				$data['getRejectedVoucher'] = $qry_rej_vouchers->result_array();
			} else {
				$data['getRejectedVoucher'] = '';
			}

			if (isset($_REQUEST['receiveno']) && empty($_REQUEST['isrejvoucher']) && !empty($_REQUEST['receiveno'])) {
				$data['receiveno'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['receiveno']) && !empty($_REQUEST['receiveno'])) {
					//get issue number
					$receiveno = $_REQUEST['receiveno'];
					$data['receiveno'] = $_REQUEST['receiveno'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = '2,3';
				$this->obj_gwis_master->tran_no = $receiveno;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				//                    $stockReceive = $this->obj_gwis_master->GetWHStockByIssueNo();
				$stockReceive = $this->obj_gwis_master->GetAllStockReceiveByIssueNo($dtlchk);
				//                }
			}

			if (isset($_REQUEST['isrejvoucher']) && !empty($_REQUEST['isrejvoucher'])) {
				$data['receiveno'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['receiveno']) && !empty($_REQUEST['receiveno'])) {
					//get issue number
					$rej_issue_no = $_REQUEST['receiveno'];
					$data['issue_no'] = $_REQUEST['receiveno'];
					$data['receiveno'] = $_REQUEST['receiveno'];
					$data['isrejvoucher'] = $_REQUEST['isrejvoucher'];
					$rejected_real_masterids = $this->obj_gwis_master->rejected_real_masterid($_REQUEST['receiveno']);
					$data['rejected_real_masterid'] = $rejected_real_masterids->result_array();
				}
				//set issue number
				$this->obj_gwis_master->status_id = '3';
				$this->obj_gwis_master->tran_no = $rej_issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByRejIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if (isset($stockReceive) && !empty($stockReceive)) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}


			//            echo '<pre>';
			//            echo $stock_master_id;
			//            $a=array();
			//                foreach ($data['temp_records']->result_array() as $row) {
			//                    $a[]=$row;
			//                }
			//            print_r($a);
			//            echo '</pre>';
			//            exit;
			$data['master_id'] = $stock_master_id;
			$data['page_title'] = 'Stock Receive';

			$data['main_content'] = $this->load->view('inventory_management/stock_receive_search', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {

			$data = array();

			$code_arr = $this->obj_gwis_master->get_assign_approvalcode(3);
			if ($code_arr) {
				$data['approval_code'] = $code_arr->result_array();
				$approvalcodes = $code_arr->result_array();
			}
			$process_status_ids = array();
			if ($approvalcodes) {
				foreach ($approvalcodes as $row) {
					$approver_designation = preg_split("/\,/", $row['approver_designation']);
					$approver_desg_id = preg_split("/\,/", $row['approver_desg_id']);
					$process_statuss = preg_split("/\,/", $row['process_status']);
					$approval_codess = preg_split("/\,/", $row['approval_code']);
					for ($i = 0; $i < count($approval_codess); $i++) {
						$process_status_ids[] = $process_statuss[$i] - 1;
					}
					$process_status_nmbr = implode(",", $process_status_ids);
				}
			}

			//            $process_status_nmbr = '';
			$process_status_nmbrr = '';
			//            $qry_getprocess_status = $this->obj_gwis_master->getprocess_status(3);
			//            if($qry_getprocess_status)
			//            {
			//                $dataprocessstatus = $qry_getprocess_status->result_array();
			//            }
			//            foreach ($dataprocessstatus AS $row)
			//            {
			//                $process_status_nmbr = $row['process_status'];  
			//            }

			$qry_getprocess_statuss = $this->obj_gwis_master->getprocess_statusmax(2);
			if ($qry_getprocess_statuss) {
				$dataprocessstatuss = $qry_getprocess_statuss->result_array();
			}
			foreach ($dataprocessstatuss as $row) {
				$process_status_nmbrr = $row['process_status'];
			}

			$this->obj_gwis_master->status_id = '2,3';
			if (in_array("69", $approver_desg_id)) {
				$this->obj_gwis_master->process_status = $process_status_nmbr . ',' . $process_status_nmbrr;
				$dtlchk = "AND stock_batch.dtl_status = 'completed'";
			} else {
				$this->obj_gwis_master->process_status = $process_status_nmbr;
				$dtlchk = "";
			}
			$qry_vouchers = $this->obj_gwis_master->get_grn_issue_vouchers($dtlchk);
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}


			$rejqry_getprocess_status = $this->obj_gwis_master->getprocess_status(3);
			if ($rejqry_getprocess_status) {
				$rejdataprocessstatus = $rejqry_getprocess_status->result_array();
			}
			foreach ($rejdataprocessstatus as $row) {
				$rejprocess_status_nmbr = $row['process_status'];
			}

			$this->obj_gwis_master->status_id = '3';
			$this->obj_gwis_master->process_status = $rejprocess_status_nmbr;
			$qry_rej_vouchers = $this->obj_gwis_master->get_rejected_vouchers();
			if ($qry_rej_vouchers) {
				$data['getRejectedVoucher'] = $qry_rej_vouchers->result_array();
			} else {
				$data['getRejectedVoucher'] = '';
			}

			if (isset($_REQUEST['tranref'])) {
				$gwis_records_info = $this->obj_gwis_detail->getbatch_gwis_records($_REQUEST['tranref']);
				if ($gwis_records_info) {
					$data['gwis_records'] = $gwis_records_info->result_array();
				} else {
					$data['gwis_records'] = 'NF';
				}
			}

			if (isset($_POST['receiveno']) && !empty($_POST['receiveno'] && isset($_POST['receivetype']) && $_POST['receivetype'] == '2') && empty($this->input->get("tranref"))) {
				$gwis_records_info = $this->obj_gwis_detail->get_gwis_records($_POST['receiveno']);
				if ($gwis_records_info) {
					$data['gwis_records'] = $gwis_records_info->result_array();
				} else {
					$data['gwis_records'] = 'NF';
				}
			}

			$stockReceive = '';

			if (isset($_REQUEST['receiveno']) && empty($_REQUEST['isrejvoucher']) && empty($this->input->get("tranref"))) {
				$data['receiveno'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['receiveno']) && !empty($_REQUEST['receiveno'])) {
					//get issue number
					$receiveno = $_REQUEST['receiveno'];
					$data['receiveno'] = $_REQUEST['receiveno'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = '2,3';
				$this->obj_gwis_master->tran_no = $receiveno;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				//                    $stockReceive = $this->obj_gwis_master->GetWHStockByIssueNo();
				$stockReceive = $this->obj_gwis_master->GetAllStockReceiveByIssueNo($dtlchk);
				//                }
			}


			if ($this->input->get("tranref")) {
				$data['tranref'] = $this->input->get("tranref");
				$data['whidto'] = $this->input->get("whidto");
				$data['pkdetailid'] = $this->input->get("pkdetailid");
				//                $res = $this->obj_gwis_detail->GetBatchDetail($this->input->get("pkdetailid"),$this->input->get("batchid"));
				//            $row = $res->row();
				//                if ($res)
				//                {
				//                    $data['gwis_data'] = $res->result_array();
				//                }
				//                $data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				//                    $stockReceive = $this->obj_gwis_master->GetBatchqty();

				$receiveno = $this->input->get("tranref");
				$data['receiveno'] = $receiveno;
				$data['receivetype'] = '2';
				//set issue number
				$this->obj_gwis_master->status_id = 3;
				$this->obj_gwis_master->tran_no = $this->input->get("tranref");
				$this->obj_gwis_master->wh_id_to = $this->input->get("whidto");
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetBatchWHStockByIssueNo($this->input->get("pkdetailid"));
				//                }
			}


			if (isset($_REQUEST['isrejvoucher']) && !empty($_REQUEST['isrejvoucher'])) {
				$data['receiveno'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['receiveno']) && !empty($_REQUEST['receiveno'])) {
					//get issue number
					$rej_issue_no = $_REQUEST['receiveno'];
					$data['issue_no'] = $_REQUEST['receiveno'];
					$data['receiveno'] = $_REQUEST['receiveno'];
					$data['isrejvoucher'] = $_REQUEST['isrejvoucher'];
					$rejected_real_masterids = $this->obj_gwis_master->rejected_real_masterid($_REQUEST['receiveno']);
					$data['rejected_real_masterid'] = $rejected_real_masterids->result_array();
				}
				//set issue number
				$this->obj_gwis_master->status_id = '3';
				$this->obj_gwis_master->tran_no = $rej_issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByRejIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if ($stockReceive) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}


			$challan_type_arr = $this->obj_challan_type->find_active();
			if ($challan_type_arr)
				$data['challan_type'] = $challan_type_arr->result_array();
			//            else if(isset ($_POST['receivetype']) && !empty ($_POST['receivetype']))
			//            {
			//                
			//            }
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$currency_arr = $this->obj_itminfo->find_currency_type();
			if ($currency_arr)
				$data['currency_type'] = $currency_arr->result_array();

			$storage_arr = $this->obj_lists->get_list(16);
			$data['storage'] = $storage_arr->result_array();
			//            $suppliers_arr = $this->obj_stock_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$warehouse_arr = $this->obj_stakeholder->find_warehouseinfo();
			if ($warehouse_arr)
				$data['warehouses'] = $warehouse_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();
			//            $data['temp_records'] = $this->obj_stock_detail->get_temp_records($stock_master_id);
			//            $data['temp_records'] = $this->obj_stock_master->get_temp_master_records(1);
			//            $master_id_arr = $this->obj_stock_master->get_temp_master_records(1);
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['transaction_reference'];
				}
			}
			$data['page_title'] = 'Stock Receive';
			$data['main_content'] = $this->load->view('inventory_management/stock_receive', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function gwis_stock_issue()
	{
		// echo "<pre>";
		// print_r($_REQUEST);
		// echo "</pre>";
		//exit;

		if (isset($_REQUEST['stockid']) && !empty($_REQUEST['stockid'])) {
			$masterstock_id = '';
			if (isset($_REQUEST['stock_id']) && !empty($_REQUEST['stock_id'])) {
				$masterstock_id = $_REQUEST['stock_id'];
			}

			if (isset($_POST['pk_id'])) {
				$this->obj->pk_id = $_POST['pk_id'];
			}



			if (isset($_REQUEST['stockid']) && !empty($_REQUEST['stockid'])) {

				if (isset($_REQUEST['approve_or_rej']) && !empty($_REQUEST['approve_or_rej'])) {
					$electronic_approval = $_REQUEST['approve_or_rej'];
				}
				$uploadedFile = '';
				$masterloop = 1;
				$rvoucher = 1;

				if (isset($_REQUEST['siv_mode_of_transport']) && !empty($_REQUEST['siv_mode_of_transport'])) {
					$this->obj_gwis_detail->siv_mode_of_transport = $_REQUEST['siv_mode_of_transport'];
				}
				if (isset($_REQUEST['siv_vehicle_type']) && !empty($_REQUEST['siv_vehicle_type'])) {
					$this->obj_gwis_detail->siv_vehicle_type = $_REQUEST['siv_vehicle_type'];
				}
				if (isset($_REQUEST['driver_names']) && !empty($_REQUEST['driver_names'])) {
					$this->obj_gwis_detail->siv_driver_name = $_REQUEST['driver_names'];
				}
				if (isset($_REQUEST['driver_contact']) && !empty($_REQUEST['driver_contact'])) {
					$this->obj_gwis_detail->siv_contatc_number = $_REQUEST['driver_contact'];
				}
				if (isset($_REQUEST['driver_cnic']) && !empty($_REQUEST['driver_cnic'])) {
					$this->obj_gwis_detail->siv_cnic = $_REQUEST['driver_cnic'];
				}
				if (isset($_REQUEST['weight']) && !empty($_REQUEST['weight'])) {
					$this->obj_gwis_detail->siv_weight = $_REQUEST['weight'];
				}
				if (isset($_REQUEST['siv_no_of_cartons']) && !empty($_REQUEST['siv_no_of_cartons'])) {
					$this->obj_gwis_detail->siv_no_of_cartons = $_REQUEST['siv_no_of_cartons'];
				}
				if (isset($_REQUEST['transportation_po']) && !empty($_REQUEST['transportation_po'])) {
					$this->obj_gwis_detail->siv_transportation_po = $_REQUEST['transportation_po'];
				}
				if (isset($_REQUEST['siv_tracking_no']) && !empty($_REQUEST['siv_tracking_no'])) {
					$this->obj_gwis_detail->siv_tracking_no = $_REQUEST['siv_tracking_no'];
				}
				if (isset($_REQUEST['siv_name_of_transporter']) && !empty($_REQUEST['siv_name_of_transporter'])) {
					$this->obj_gwis_detail->siv_name_of_transporter = $_REQUEST['siv_name_of_transporter'];
				}
				if (isset($_REQUEST['siv_vehicle_plate_no']) && !empty($_REQUEST['siv_vehicle_plate_no'])) {
					$this->obj_gwis_detail->siv_vehicle_plate_no = $_REQUEST['siv_vehicle_plate_no'];
				}

				$pi_quantity = $_REQUEST['pi_quantity'];
				$grn_quantity = $_REQUEST['grn_quantity'];
				$giv_quantity = $_REQUEST['giv_quantity'];
				//            $missing = $_REQUEST['missing'];
				$comment = $_REQUEST['comment'];

				$dc_quantity = $_REQUEST['dc_quantity'];
				$ti_quantity = $_REQUEST['ti_quantity'];

				foreach ($_REQUEST['approvalcode'] as $indx => $detail_ida) {

					$approvefrom = $_REQUEST['approve_from'];
					$approveto = $_REQUEST['approve_to'];
					$processtatus = $_REQUEST['process_status'];
					$finalstatus = $_REQUEST['final_status'];

					$uploadedFile = '';
					$uploadDir = 'uploads/';
					if (!empty($_FILES["fileToUpload"]["name"])) {
						//                    $uploadedFile = 'test';
						// File path config 
						$fileName = basename($_FILES["fileToUpload"]["name"]);
						$targetFilePath = $uploadDir . $fileName;
						$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

						// Allow certain file formats 
						$allowTypes = array('pdf', 'doc', 'docx', 'jpg', 'png', 'jpeg');
						if (in_array($fileType, $allowTypes)) {
							// Upload file to the server 
							if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFilePath)) {
								$uploadedFile = $fileName;
							}
						}
					}

					if (!empty($uploadedFile)) {
						$fileto = $uploadedFile;
					} else if (isset($_REQUEST['file']) && !empty($_REQUEST['file'])) {
						$fileto = $this->input->post('file');
					}

					$masterstock_id = $this->obj_gwis_master->clone_record($masterstock_id, $approvefrom[$indx], $approveto[$indx], $processtatus[$indx], $finalstatus[$indx], $fileto, $_SESSION['id'], 4, 4);



					//        print_r($stock_ids);exit;
					foreach ($_REQUEST['stockid'] as $index => $detail_id) {


						if ($electronic_approval[$index] == '1') {

							if ($processtatus[0] == 12) {
								$adj_type = 4;
							} else {
								$adj_type = 'gwis_detail.adjustment_type';
							}

							$new_detail_id = $this->obj_gwis_detail->clone_record($detail_id, $masterstock_id, $giv_quantity[$index], $comment[$index], $adj_type);


							if ($processtatus[$indx] == '10') {
								//Start SMS Code
								//                        $this->sms($mobileno,$message);
								// End SMS Code
								// Start Email Code
								if ($_REQUEST['rejected_voucher'] == '2') {
									$stock_master_id_email = $_REQUEST['stkmasterid'];
								} else if (isset($_REQUEST['pkmasterid']) && !empty($_REQUEST['pkmasterid'])) {
									$stock_master_id_email = $_REQUEST['pkmasterid']; //
								} else {
									$stock_master_id_email = $masterstock_id;
								}
								$message = "New voucher no " . $_REQUEST['refernce_number'] . " created by " . $_SESSION['name'] . " Please Approve.";
								$this->email_printissue('muhammadsabir@ntp.gov.pk', $message, $stock_master_id_email);
								//End Email Code
							}

							//                $this->obj_gwis_master->status_id = '3';
							//                $this->obj_gwis_master->updategwisstatus('3',$_REQUEST['masterid']);
							//            }
						}
					}
				}
				// $this->obj_gwis_master->updatemasterpkid($_REQUEST['masterpkid']);
			}



			if (isset($_REQUEST['detailid']) && !empty($_REQUEST['detailid'])) {
				$pk_id = $_REQUEST['detailid'];
				$this->obj_gwis_detail->receiveupdate_details_temp($pk_id);
			}


			$data['form'] = $_POST;
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_stock_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();
			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$warehouse_arr = $this->obj_stakeholder->find_warehouseinfo();
			if ($warehouse_arr)
				$data['warehouses'] = $warehouse_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();

			$challan_type_arr = $this->obj_challan_type->find_active();
			if ($challan_type_arr)
				$data['challan_type'] = $challan_type_arr->result_array();




			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();

			$prov_arr = $this->obj_reports_model->get_province();
			if ($prov_arr)
				$data['province'] = $prov_arr->result_array();

			$vehicle_type_arr = $this->obj_lists->get_list(13);
			$data['vehicle_type'] = $vehicle_type_arr->result_array();





			//            $stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			//            if ($stock_master_record)
			//                $data['stock_master_records'] = $stock_master_record->result_array();
			//            $data['temp_records'] = $this->obj_stock_detail->get_temp_records($stock_master_id);





			if (isset($_REQUEST['receiveno']) && empty($_REQUEST['isrejvoucher']) && !empty($_REQUEST['receiveno'])) {
				$data['receiveno'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['receiveno']) && !empty($_REQUEST['receiveno'])) {
					//get issue number
					$receiveno = $_REQUEST['receiveno'];
					$data['issue_no'] = $_REQUEST['receiveno'];
					$data['receiveno'] = $_REQUEST['receiveno'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = 4;
				$this->obj_gwis_master->tran_no = $receiveno;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				//                    $stockReceive = $this->obj_gwis_master->GetWHStockByIssueNo();
				$stockReceive = $this->obj_gwis_master->GetWHStockByIssueNo();
				//                }
			}

			if (isset($_REQUEST['isrejvoucher']) && !empty($_REQUEST['isrejvoucher'])) {
				$data['receiveno'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['receiveno']) && !empty($_REQUEST['receiveno'])) {
					//get issue number
					$rej_issue_no = $_REQUEST['receiveno'];
					$data['issue_no'] = $_REQUEST['receiveno'];
					$data['isrejvoucher'] = $_REQUEST['isrejvoucher'];
					$rejected_real_masterids = $this->obj_gwis_master->rejected_real_masterid($_REQUEST['receiveno']);
					$data['rejected_real_masterid'] = $rejected_real_masterids->result_array();
				}
				//set issue number
				$this->obj_gwis_master->status_id = 4;
				$this->obj_gwis_master->tran_no = $rej_issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByRejIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if (isset($stockReceive) && !empty($stockReceive)) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}

			$code_arr = $this->obj_gwis_master->get_assign_approvalcode(4);
			if ($code_arr) {
				$data['approval_code'] = $code_arr->result_array();
				$approvalcodes = $code_arr->result_array();
			}
			$process_status_ids = array();
			if ($approvalcodes) {
				foreach ($approvalcodes as $row) {
					$approver_designation = preg_split("/\,/", $row['approver_designation']);
					$approver_desg_id = preg_split("/\,/", $row['approver_desg_id']);
					$process_statuss = preg_split("/\,/", $row['process_status']);
					$approval_codess = preg_split("/\,/", $row['approval_code']);
					for ($i = 0; $i < count($approval_codess); $i++) {
						$process_status_ids[] = $process_statuss[$i] - 1;
					}
					$process_status_nmbr = implode(",", $process_status_ids);
				}
			}
			//            $process_status_nmbr = '';
			$process_status_nmbrr = '';
			//            $qry_getprocess_status = $this->obj_gwis_master->getprocess_status(3);
			//            if($qry_getprocess_status)
			//            {
			//                $dataprocessstatus = $qry_getprocess_status->result_array();
			//            }
			//            foreach ($dataprocessstatus AS $row)
			//            {
			//                $process_status_nmbr = $row['process_status'];  
			//            }
			//            $qry_getprocess_statuss = $this->obj_gwis_master->getprocess_statusmax(2);
			//            if($qry_getprocess_statuss)
			//            {
			//                $dataprocessstatuss = $qry_getprocess_statuss->result_array();
			//            }
			//            foreach ($dataprocessstatuss AS $row)
			//            {
			//                $process_status_nmbrr = $row['process_status'];  
			//            }

			$this->obj_gwis_master->status_id = '4';
			//            $this->obj_gwis_master->process_status = $process_status_nmbr.','.$process_status_nmbrr;
			if (in_array("69", $approver_desg_id)) {
				$this->obj_gwis_master->process_status = $process_status_nmbr . ',0';
				//                $dtlchk = "AND stock_batch.dtl_status = 'completed'";
			} else {
				$this->obj_gwis_master->process_status = $process_status_nmbr;
				//                $dtlchk = "";
			}
			if (in_array("69", $approver_desg_id)) {
				$this->obj_gwis_master->parent_id = '0';
			}
			//            $this->obj_gwis_master->process_status = $process_status_nmbr.',0';
			$qry_vouchers = $this->obj_gwis_master->get_giv_issue_vouchers();
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}

			$rejqry_getprocess_status = $this->obj_gwis_master->getprocess_status(4);
			if ($rejqry_getprocess_status) {
				$rejdataprocessstatus = $rejqry_getprocess_status->result_array();
			}
			foreach ($rejdataprocessstatus as $row) {
				$rejprocess_status_nmbr = $row['process_status'];
			}
			$this->obj_gwis_master->status_id = '4';
			$this->obj_gwis_master->process_status = $rejprocess_status_nmbr;
			if (in_array("69", $approver_desg_id)) {
				$this->obj_gwis_master->parent_id = '0';
			}

			$qry_rej_vouchers = $this->obj_gwis_master->get_rejected_vouchers();
			if ($qry_rej_vouchers) {
				$data['getRejectedVoucher'] = $qry_rej_vouchers->result_array();
			} else {
				$data['getRejectedVoucher'] = '';
			}

			if (isset($_REQUEST['tranref'])) {
				$gwis_records_info = $this->obj_gwis_detail->getbatch_gwis_records($_REQUEST['tranref']);
				if ($gwis_records_info) {
					$data['gwis_records'] = $gwis_records_info->result_array();
				} else {
					$data['gwis_records'] = 'NF';
				}
			}

			if (isset($_POST['receiveno']) && !empty($_POST['receiveno'] && isset($_POST['receivetype']) && $_POST['receivetype'] == '2') && empty($this->input->get("tranref"))) {
				$gwis_records_info = $this->obj_gwis_detail->get_gwis_records($_POST['receiveno']);
				if ($gwis_records_info) {
					$data['gwis_records'] = $gwis_records_info->result_array();
				} else {
					$data['gwis_records'] = 'NF';
				}
			}





			//            $types = $objTransType->find_all();
			//            echo '<pre>';
			//            echo $stock_master_id;
			//            $a=array();
			//                foreach ($data['temp_records']->result_array() as $row) {
			//                    $a[]=$row;
			//                }
			//            print_r($a);
			//            echo '</pre>';
			//            exit;
			if (empty($stock_master_id)) {
				$stock_master_id = '';
			}
			$data['master_id'] = $stock_master_id;
			$data['page_title'] = 'Stock Issue Voucher';

			$data['main_content'] = $this->load->view('inventory_management/stock_issue_search', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			//            echo 'saad';exit;

			$data = array();

			$stockReceive = '';

			if ($this->input->get("tranref")) {
				$data['tranref'] = $this->input->get("tranref");
				$data['whidto'] = $this->input->get("whidto");
				$data['pkdetailid'] = $this->input->get("pkdetailid");
				//                $res = $this->obj_gwis_detail->GetBatchDetail($this->input->get("pkdetailid"),$this->input->get("batchid"));
				//            $row = $res->row();
				//                if ($res)
				//                {
				//                    $data['gwis_data'] = $res->result_array();
				//                }
				//                $data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				//                    $stockReceive = $this->obj_gwis_master->GetBatchqty();

				$receiveno = $this->input->get("tranref");
				$data['issue_no'] = $receiveno;
				$data['receiveno'] = $receiveno;
				$data['receivetype'] = '2';
				//set issue number
				$this->obj_gwis_master->status_id = 4;
				$this->obj_gwis_master->tran_no = $this->input->get("tranref");
				$this->obj_gwis_master->wh_id_to = $this->input->get("whidto");
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetBatchWHStockByIssueNo($this->input->get("pkdetailid"));
				//                }
			}

			if (isset($_REQUEST['receiveno']) && empty($_REQUEST['isrejvoucher']) && empty($this->input->get("tranref"))) {
				$data['receiveno'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['receiveno']) && !empty($_REQUEST['receiveno'])) {
					//get issue number
					$receiveno = $_REQUEST['receiveno'];
					$data['issue_no'] = $_REQUEST['receiveno'];
					$data['receiveno'] = $_REQUEST['receiveno'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = 4;
				$this->obj_gwis_master->tran_no = $receiveno;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByIssueNo();
				//                }
			}

			if (isset($_REQUEST['isrejvoucher']) && !empty($_REQUEST['isrejvoucher'])) {
				$data['receiveno'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['receiveno']) && !empty($_REQUEST['receiveno'])) {
					//get issue number
					$rej_issue_no = $_REQUEST['receiveno'];
					$data['issue_no'] = $_REQUEST['receiveno'];
					$data['isrejvoucher'] = $_REQUEST['isrejvoucher'];
					$rejected_real_masterids = $this->obj_gwis_master->rejected_real_masterid($_REQUEST['receiveno']);
					$data['rejected_real_masterid'] = $rejected_real_masterids->result_array();
				}
				//set issue number
				$this->obj_gwis_master->status_id = 4;
				$this->obj_gwis_master->tran_no = $rej_issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByRejIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if ($stockReceive) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}


			$code_arr = $this->obj_gwis_master->get_assign_approvalcode(4);
			if ($code_arr) {
				$data['approval_code'] = $code_arr->result_array();
				$approvalcodes = $code_arr->result_array();
			}
			$process_status_ids = array();
			if ($approvalcodes) {
				foreach ($approvalcodes as $row) {
					$approver_designation = preg_split("/\,/", $row['approver_designation']);
					$approver_desg_id = preg_split("/\,/", $row['approver_desg_id']);
					$process_statuss = preg_split("/\,/", $row['process_status']);
					$approval_codess = preg_split("/\,/", $row['approval_code']);
					for ($i = 0; $i < count($approval_codess); $i++) {
						$process_status_ids[] = $process_statuss[$i] - 1;
					}
					$process_status_nmbr = implode(",", $process_status_ids);
				}
			}
			//            $process_status_nmbr = '';
			$process_status_nmbrr = '';
			//            $qry_getprocess_status = $this->obj_gwis_master->getprocess_status(3);
			//            if($qry_getprocess_status)
			//            {
			//                $dataprocessstatus = $qry_getprocess_status->result_array();
			//            }
			//            foreach ($dataprocessstatus AS $row)
			//            {
			//                $process_status_nmbr = $row['process_status'];  
			//            }
			//            $qry_getprocess_statuss = $this->obj_gwis_master->getprocess_statusmax(2);
			//            if($qry_getprocess_statuss)
			//            {
			//                $dataprocessstatuss = $qry_getprocess_statuss->result_array();
			//            }
			//            foreach ($dataprocessstatuss AS $row)
			//            {
			//                $process_status_nmbrr = $row['process_status'];  
			//            }

			$this->obj_gwis_master->status_id = '4';
			//            $this->obj_gwis_master->process_status = $process_status_nmbr.','.$process_status_nmbrr;
			if (in_array("69", $approver_desg_id)) {
				$this->obj_gwis_master->process_status = $process_status_nmbr . ',0';
				//                $dtlchk = "AND stock_batch.dtl_status = 'completed'";
			} else {
				$this->obj_gwis_master->process_status = $process_status_nmbr;
				//                $dtlchk = "";
			}

			if (in_array("69", $approver_desg_id)) {
				$this->obj_gwis_master->parent_id = '0';
			}
			//            $this->obj_gwis_master->process_status = $process_status_nmbr.',0';
			$qry_vouchers = $this->obj_gwis_master->get_giv_issue_vouchers();
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}

			$rejqry_getprocess_status = $this->obj_gwis_master->getprocess_status(4);
			if ($rejqry_getprocess_status) {
				$rejdataprocessstatus = $rejqry_getprocess_status->result_array();
			}
			foreach ($rejdataprocessstatus as $row) {
				$rejprocess_status_nmbr = $row['process_status'];
			}
			$this->obj_gwis_master->status_id = '4';
			$this->obj_gwis_master->process_status = $rejprocess_status_nmbr;

			if (in_array("69", $approver_desg_id)) {
				$this->obj_gwis_master->parent_id = '0';
			}
			$qry_rej_vouchers = $this->obj_gwis_master->get_rejected_vouchers();
			if ($qry_rej_vouchers) {
				$data['getRejectedVoucher'] = $qry_rej_vouchers->result_array();
			} else {
				$data['getRejectedVoucher'] = '';
			}

			if (isset($_REQUEST['tranref'])) {
				$gwis_records_info = $this->obj_gwis_detail->getbatch_gwis_records($_REQUEST['tranref']);
				if ($gwis_records_info) {
					$data['gwis_records'] = $gwis_records_info->result_array();
				} else {
					$data['gwis_records'] = 'NF';
				}
			}

			if (isset($_POST['receiveno']) && !empty($_POST['receiveno'] && isset($_POST['receivetype']) && $_POST['receivetype'] == '2') && empty($this->input->get("tranref"))) {
				$gwis_records_info = $this->obj_gwis_detail->get_gwis_records($_POST['receiveno']);
				if ($gwis_records_info) {
					$data['gwis_records'] = $gwis_records_info->result_array();
				} else {
					$data['gwis_records'] = 'NF';
				}
			}

			$challan_type_arr = $this->obj_challan_type->find_active();
			if ($challan_type_arr)
				$data['challan_type'] = $challan_type_arr->result_array();
			//            else if(isset ($_POST['receivetype']) && !empty ($_POST['receivetype']))
			//            {
			//                
			//            }
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$currency_arr = $this->obj_itminfo->find_currency_type();
			if ($currency_arr)
				$data['currency_type'] = $currency_arr->result_array();

			//            $suppliers_arr = $this->obj_stock_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$warehouse_arr = $this->obj_stakeholder->find_warehouseinfo();
			if ($warehouse_arr)
				$data['warehouses'] = $warehouse_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();

			$prov_arr = $this->obj_reports_model->get_province();
			if ($prov_arr)
				$data['province'] = $prov_arr->result_array();

			$vehicle_type_arr = $this->obj_lists->get_list(13);
			$data['vehicle_type'] = $vehicle_type_arr->result_array();


			//            $data['temp_records'] = $this->obj_stock_detail->get_temp_records($stock_master_id);
			//            $data['temp_records'] = $this->obj_stock_master->get_temp_master_records(1);
			//            $master_id_arr = $this->obj_stock_master->get_temp_master_records(1);
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['transaction_reference'];
				}
			}
			$data['page_title'] = 'Stock Issue Voucher';
			$data['main_content'] = $this->load->view('inventory_management/gwis_stock_issue', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function gwis_stock_adjustment()
	{
		if (!empty($_POST) && empty($_REQUEST['issue_no'])) {

			if (isset($_POST['pk_id'])) {
				$this->obj->pk_id = $_POST['pk_id'];
			}



			//check stock id
			if (isset($_REQUEST['stock_id']) && !empty($_REQUEST['stock_id'])) {
				//get stock id
				$stock_id = $_REQUEST['stock_id'];

				$type_id = 1;
				//find by stock id
				//        $stockDetail = $objStockDetail->find_by_stock_id($stock_id);
				//check remarks
				if (isset($_REQUEST['remarks']) && !empty($_REQUEST['remarks'])) {
					//get remarks
					$remarks = $_REQUEST['remarks'];
				} else {
					$remarks = "";
				}
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
				}
				if (isset($_REQUEST['count']) && !empty($_REQUEST['count'])) {
					$count_o = $_REQUEST['count'];
				}
				//check receive date 
				if (isset($_REQUEST['rec_date']) && !empty($_REQUEST['rec_date'])) {
					//get receive date
					$rec_date = $_REQUEST['rec_date'];
				}
				//check receive reference
				if (isset($_REQUEST['rec_ref']) && !empty($_REQUEST['rec_ref'])) {
					//get receive reference
					$rec_ref = $_REQUEST['rec_ref'];
				}
				//check vvm
				if (isset($_REQUEST['vvmstage']) && !empty($_REQUEST['vvmstage'])) {
					//get vvm
					$vvmstage = $_REQUEST['vvmstage'];
				}
				//check cold chain
				if (isset($_REQUEST['cold_chain']) && !empty($_REQUEST['cold_chain'])) {
					//get cold chain
					$cold_chain = $_REQUEST['cold_chain'];
				}
			}
			//            


			if (isset($_REQUEST['stockid']) && !empty($_REQUEST['stockid'])) {
				//get stock id
				$stock_ids = $_REQUEST['stockid'];
				$count = count($stock_ids);

				foreach ($stock_ids as $index => $detail_id) {
					if (isset($_REQUEST['itm_id']) && !empty($_REQUEST['itm_id'])) {
						//get cold chain
						$itmid = $_REQUEST['itm_id'];
						//                    $item_id = $itmid[$index];
						$item_id = '1';
					}
				}


				//        print_r($stock_ids);exit;
				foreach ($stock_ids as $index => $detail_id) {
					//Stock Received
					//            $this->obj_gwis_detail->StockReceived($detail_id);
					//Get Batch Detail
					//            $dtl = $_POST['dtl'];
					//            $dtl_result = $_POST['dtl_result'];
					$uprice = $_REQUEST['unit_price'];
					$currency = $_REQUEST['currency'];
					$conversion_rate = $_POST['conversion_rate'];

					$pi_quantity = $_REQUEST['pi_quantity'];
					if (isset($_REQUEST['tiqty']) && !empty($_REQUEST['tiqty'])) {
						$tiqty = $_REQUEST['tiqty'];
					}
					$actual_rec_qty = $_REQUEST['actual_rec_qty'];
					$returnpiqty = '';
					$returntiqty = '';
					if (isset($_REQUEST['returnpiqty']) && !empty($_REQUEST['returnpiqty'])) {
						$returnpiqty = $_REQUEST['returnpiqty'];
					}
					if (isset($_REQUEST['returntiqty']) && !empty($_REQUEST['returntiqty'])) {
						$returntiqty = $_REQUEST['returntiqty'];
					}
					//            $missing = $_REQUEST['missing'];
					$comment = $_REQUEST['comment'];
					$pkdetailid = $_REQUEST['pkdetailid'];
					$batchid = $_REQUEST['batchid'];

					$stockBatch = $this->obj_stock_batch->GetBatchDetail($detail_id);
					if ($stockBatch) {
						$stockBatch1 = $stockBatch->result_array();
					}
					if (isset($stockBatch1)) {
						$row = $stockBatch1[0];
						$Qty = $row['quantity'];
						$item_id = $row['item_id'];
						$batch_no = $row['batch_no'];
						$batch_expiry = $row['batch_expiry'];
						$funding_source = $row['funding_source'];
						$manufacturer = $row['manufacturer'];
						$unit_price = $row['unit_price'];
						$production_date = $row['production_date'];
					}

					//            }
					//quantity
					$quantity = str_replace("-", "", $Qty);
					//product id
					$product_id = $item_id;
					if (isset($_REQUEST['status_id']) && $_REQUEST['status_id'] == '2') {
						$this->obj_gwis_detail->pk_id = $pkdetailid[$index];
						$this->obj_gwis_detail->quantity = $tiqty[$index] - $returntiqty[$index];
						$this->obj_gwis_detail->ti_quantity = $tiqty[$index] - $returntiqty[$index];
						// TI Comments
						$this->obj_gwis_detail->ti_comment = $comment[$index];
					} else if (isset($_REQUEST['status_id']) && $_REQUEST['status_id'] == '1') {
						$this->obj_gwis_detail->pk_id = $pkdetailid[$index];
						$this->obj_gwis_detail->quantity = $pi_quantity[$index] - $returnpiqty[$index];
						$this->obj_gwis_detail->pi_quantity = $pi_quantity[$index] - $returnpiqty[$index];
						// PI Comments
						$this->obj_gwis_detail->pi_comment = $comment[$index];
					}
					$this->obj_gwis_detail->update_gwis_stockadj($_REQUEST['status_id']);


					//            $this->obj_stock_batch->dtl = $dtl[$index];
					//            $this->obj_stock_batch->dtl_result = $dtl_result[$index];
					$this->obj_stock_batch->batch_id = $batchid[$index];
					if (isset($_REQUEST['status_id']) && $_REQUEST['status_id'] == '2') {
						$this->obj_stock_batch->Qty = $tiqty[$index] - $returntiqty[$index];
					} else if (isset($_REQUEST['status_id']) && $_REQUEST['status_id'] == '1') {
						$this->obj_stock_batch->Qty = $pi_quantity[$index] - $returnpiqty[$index];
					}
					$this->obj_stock_batch->update_gwis_stockadj($_REQUEST['status_id']);
				} // End foreach
			}

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();

			if (isset($_REQUEST['issue_no'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->pk_id = $_REQUEST['pkid'];
				$this->obj_gwis_master->status_id = $_REQUEST['status_id'];
				$this->obj_gwis_master->tran_no = $issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if (isset($stockReceive) && !empty($stockReceive)) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}



			$code_arr = $this->obj_gwis_master->get_assign_approvalcode(2);
			if ($code_arr) {
				$data['approval_code'] = $code_arr->result_array();
				$approvalcodes = $code_arr->result_array();
			}
			$process_status_ids = array();
			if ($approvalcodes) {
				foreach ($approvalcodes as $row) {
					$approver_designation = preg_split("/\,/", $row['approver_designation']);
					$approver_desg_id = preg_split("/\,/", $row['approver_desg_id']);
					$process_statuss = preg_split("/\,/", $row['process_status']);
					$approval_codess = preg_split("/\,/", $row['approval_code']);
					for ($i = 0; $i < count($approval_codess); $i++) {
						$process_status_ids[] = $process_statuss[$i] - 1;
					}
					$process_status_nmbr = implode(",", $process_status_ids);
				}
			}

			$qry_getprocess_statuss = $this->obj_gwis_master->getprocess_statusmax(1);
			if ($qry_getprocess_statuss) {
				$dataprocessstatuss = $qry_getprocess_statuss->result_array();
			}
			foreach ($dataprocessstatuss as $row) {
				$process_status_nmbrr = $row['process_status'];
			}
			$dtlchk = '';
			$this->obj_gwis_master->status_id = '1,2';
			if (in_array("69", $approver_desg_id)) {
				$this->obj_gwis_master->process_status = $process_status_nmbr . ',' . $process_status_nmbrr;
				//                $dtlchk = "AND stock_batch.dtl_status = 'completed'";
			} else {
				$this->obj_gwis_master->process_status = $process_status_nmbr;
				$dtlchk = "";
			}

			$qry_vouchers = $this->obj_gwis_master->get_tac_issue_vouchers($dtlchk);
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}
			//            
			//            $this->obj_gwis_master->status_id = 1;
			//            $qry_vouchers = $this->obj_gwis_master->get_gwis_adjustment();
			//            if($qry_vouchers)
			//            {
			//                $data['getStockIssues'] = $qry_vouchers->result_array();
			//            }
			//            else{
			//                $data['getStockIssues'] = '';
			//            }
			//
			//                //chech if record exists
			//             $issueVoucher = '';
			//             $a='';
			//                if ($getStockIssues) {
			//
			//                    //fetch results
			//                    foreach ($getStockIssues AS $row)
			//                    {
			//                        $a= " <a href=\"new_receive_wh.php?issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
			//                        $issueVoucher[ $row['tran_no']] = $a;
			//                    }
			//
			//                }
			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_by_idsupplier();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();

			//            $stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			//            if ($stock_master_record)
			//                $data['stock_master_records'] = $stock_master_record->result_array();
			//            $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($stock_master_id);
			//            echo '<pre>';
			//            echo $stock_master_id;
			//            $a=array();
			//                foreach ($data['temp_records']->result_array() as $row) {
			//                    $a[]=$row;
			//                }
			//            print_r($a);
			//            echo '</pre>';
			//            exit;
			//            $data['master_id'] = $stock_master_id;
			$data['page_title'] = 'GWIS Stock Adjustment';

			$data['main_content'] = $this->load->view('inventory_management/gwis_stock_adjustment', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();


			$code_arr = $this->obj_gwis_master->get_assign_approvalcode(2);
			if ($code_arr) {
				$data['approval_code'] = $code_arr->result_array();
				$approvalcodes = $code_arr->result_array();
			}
			$process_status_ids = array();
			if ($approvalcodes) {
				foreach ($approvalcodes as $row) {
					$approver_designation = preg_split("/\,/", $row['approver_designation']);
					$approver_desg_id = preg_split("/\,/", $row['approver_desg_id']);
					$process_statuss = preg_split("/\,/", $row['process_status']);
					$approval_codess = preg_split("/\,/", $row['approval_code']);
					for ($i = 0; $i < count($approval_codess); $i++) {
						$process_status_ids[] = $process_statuss[$i] - 1;
					}
					$process_status_nmbr = implode(",", $process_status_ids);
				}
			}

			$qry_getprocess_statuss = $this->obj_gwis_master->getprocess_statusmax(1);
			if ($qry_getprocess_statuss) {
				$dataprocessstatuss = $qry_getprocess_statuss->result_array();
			}
			foreach ($dataprocessstatuss as $row) {
				$process_status_nmbrr = $row['process_status'];
			}
			$dtlchk = '';
			$this->obj_gwis_master->status_id = '1,2';
			if (in_array("69", $approver_desg_id)) {
				$this->obj_gwis_master->process_status = $process_status_nmbr . ',' . $process_status_nmbrr;
				//                $dtlchk = "AND stock_batch.dtl_status = 'completed'";
			} else {
				$this->obj_gwis_master->process_status = $process_status_nmbr;
				$dtlchk = "";
			}

			$qry_vouchers = $this->obj_gwis_master->get_tac_issue_vouchers($dtlchk);
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}

			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();

			//            $this->obj_gwis_master->status_id = 1;
			//            $qry_vouchers = $this->obj_gwis_master->get_gwis_adjustment();
			//            if($qry_vouchers)
			//            {
			//                $data['getStockIssues'] = $qry_vouchers->result_array();
			//            }
			//            else{
			//                $data['getStockIssues'] = '';
			//            }


			$stockReceive = '';

			if ($this->input->get("tranno")) {
				$data['tranno'] = $this->input->get("tranno");
				$data['whidto'] = $this->input->get("whidto");
				//                $res = $this->obj_gwis_detail->GetBatchDetail($this->input->get("pkdetailid"),$this->input->get("batchid"));
				//            $row = $res->row();
				//                if ($res)
				//                {
				//                    $data['gwis_data'] = $res->result_array();
				//                }
				//                $data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				$issue_no = $this->input->get("tranno");
				$data['issue_no'] = $issue_no;
				//set issue number
				$this->obj_gwis_master->pk_id = $_REQUEST['pkid'];
				$this->obj_gwis_master->status_id = $_REQUEST['status_id'];
				$this->obj_gwis_master->tran_no = $this->input->get("tranno");
				$this->obj_gwis_master->wh_id_to = $this->input->get("whidto");
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByIssueNo();
				//                }
			}

			if (isset($_REQUEST['issue_no']) && empty($_REQUEST['tranno'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = $_REQUEST['status_id'];
				$this->obj_gwis_master->tran_no = $issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if ($stockReceive) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}

			//            $qry_vouchers = $this->obj_gwis_master->get_issue_vouchers();
			//            $getStockIssues = $qry_vouchers->result_array();
			//
			//
			//                //chech if record exists
			//             $issueVoucher = '';
			//             $a='';
			//                if ($getStockIssues) {
			//
			//                    //fetch results
			//                    foreach ($getStockIssues AS $row)
			//                    {
			//                        $a= " <a href=\"new_receive_wh.php?issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
			//                        $issueVoucher[ $row['tran_no']] = $a;
			//                    }
			//
			//                }
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_by_idsupplier();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();
			//            $data['temp_records'] = $this->obj_gwis_master->get_temp_master_records(1);
			//            $master_id_arr = $this->obj_gwis_master->get_temp_master_records(1);
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['transaction_reference'];
				}
			}
			$data['page_title'] = 'GWIS Stock Adjustment';
			$data['main_content'] = $this->load->view('inventory_management/gwis_stock_adjustment', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function delivery_challan_form()
	{
		if (!empty($_POST)) {

			if (isset($_POST['pk_id'])) {
				$this->obj->pk_id = $_POST['pk_id'];
			}
			if (!isset($_POST['stock_master_id'])) {

				$current_year = date("Y");
				//current month
				$current_month = date("m");
				if ($current_month < 7) {
					//from date
					$from_date = ($current_year - 1) . "-06-30";
					//to date
					$to_date = $current_year . "-07-30";
				} else {
					//from date
					$from_date = $current_year . "-06-30";
					//to date
					$to_date = ($current_year + 1) . "-07-30";
				}
				//get last id
				$last_id = $this->obj_gwis_master->getLastID($from_date, $to_date, 0);

				if (!empty($last_id)) {
					if ($last_id)
						$last_idd = $last_id->result_array();
					foreach ($last_idd as $row) {
						$lastid = $row['Maxtr'];
					}
				}

				if ($lastid == NULL) {
					$lastid = 0;
				}
				$trans_no = "DC" . date('ym') . str_pad(($lastid + 1), 4, "0", STR_PAD_LEFT);
				$this->obj_gwis_master->tran_no = $trans_no;
				$this->obj_gwis_master->tr_no = ($lastid + 1);

				date_default_timezone_set('Asia/Karachi');
				$receivedatetime = date('Y-m-d h:i:s', time());
				$this->obj_gwis_master->tran_date = $receivedatetime;
				//                $this->obj_gwis_master->tran_date = date('Y-m-d', strtotime($_POST['receiving_time']));

				$this->obj_gwis_master->status_id = '0';
				$this->obj_gwis_master->tran_ref = $this->input->post('refernce_number');
				//                $this->obj_gwis_master->wh_id_from = $this->input->post('receive_from');
				//                $this->obj_gwis_master->wh_id_from_supplier = $this->input->post('receive_from_supplier');
				//                $this->obj_gwis_master->source_type = $this->input->post('receive_from');

				$this->obj_gwis_master->wh_id_from_supplier = $this->input->post('receive_from_supplier');

				$this->obj_gwis_master->wh_id_from = $this->input->post('receive_from_warehouse');

				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				$this->obj_gwis_master->created_by = $_SESSION['id'];
				$this->obj_gwis_master->created_on = date("Y-m-d");
				$this->obj_gwis_master->user_from = 1;
				$this->obj_gwis_master->user_to = 1;
				$this->obj_gwis_master->temp = 0;
				$this->obj_gwis_master->mcc_year = $this->input->post('mcc_year');
				$this->obj_gwis_master->received_remarks = $this->input->post('remarks');
				$this->obj_gwis_master->issuance_to = 'centers';
				//                echo '<pre>';
				//            print_r($_REQUEST);
				//            print_r($this->obj_gwis_master);
				//            echo '</pre>';
				//            exit;
				$stock_master_id = $this->obj_gwis_master->save();
			} else {
				$stock_master_id = $_POST['stock_master_id'];
			}
			$this->obj_stock_batch->batch_no = $this->input->post('batch_number');
			$this->obj_stock_batch->batch_expiry = date('Y-m-d', strtotime($_POST['expiry_date']));
			$this->obj_stock_batch->production_date = date('Y-m-d', strtotime($_POST['manufacturing_date']));
			$this->obj_stock_batch->item_id = $this->input->post('product');
			$this->obj_stock_batch->wh_id = $this->session->userdata('warehouse_id');
			$this->obj_stock_batch->Qty = $this->input->post('quantity');
			$this->obj_stock_batch->funding_source = $this->input->post('receive_from');
			//            $this->obj_stock_batch->phy_inspection = $this->input->post('physical_inspection');
			//            $this->obj_stock_batch->dtl = $this->input->post('dtl');
			$stock_batch_id = $this->obj_stock_batch->save();


			//do this change in table and model.
			$this->obj_gwis_detail->delivery_challan_type = $this->input->post('challan_type');
			if (!empty($this->input->post('po_detail_info'))) {
				$this->obj_gwis_detail->challan_type_detail = $this->input->post('po_detail_info');
			}
			if (!empty($this->input->post('wh_detail_info'))) {
				$this->obj_gwis_detail->challan_type_detail = $this->input->post('wh_detail_info');
			}
			$this->obj_gwis_detail->fk_stock_id = $stock_master_id;              //check id name
			$this->obj_gwis_detail->batch_id = $stock_batch_id;
			$this->obj_gwis_detail->quantity = $_POST['quantity'];
			$this->obj_gwis_detail->dc_quantity = $_POST['quantity'];
			$this->obj_gwis_detail->temp = 0;
			$this->obj_gwis_detail->save();


			$data['form'] = $_POST;
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();
			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$warehouse_arr = $this->obj_stakeholder->find_warehouseinfo();
			if ($warehouse_arr)
				$data['warehouses'] = $warehouse_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();

			$challan_type_arr = $this->obj_challan_type->find_active();
			if ($challan_type_arr)
				$data['challan_type'] = $challan_type_arr->result_array();

			$stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			if ($stock_master_record)
				$data['stock_master_records'] = $stock_master_record->result_array();
			$data['temp_records'] = $this->obj_gwis_detail->get_temp_records($stock_master_id);
			//            echo '<pre>';
			//            echo $stock_master_id;
			//            $a=array();
			//                foreach ($data['temp_records']->result_array() as $row) {
			//                    $a[]=$row;
			//                }
			//            print_r($a);
			//            echo '</pre>';
			//            exit;
			$data['master_id'] = $stock_master_id;
			$data['page_title'] = 'Delivery Challan Form';

			$data['main_content'] = $this->load->view('inventory_management/delivery_challan_form', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();

			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$warehouse_arr = $this->obj_stakeholder->find_warehouseinfo();
			if ($warehouse_arr)
				$data['warehouses'] = $warehouse_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();

			$challan_type_arr = $this->obj_challan_type->find_active();
			if ($challan_type_arr)
				$data['challan_type'] = $challan_type_arr->result_array();
			//            $data['temp_records'] = $this->obj_gwis_master->get_temp_master_records(1);
			//            $master_id_arr = $this->obj_gwis_master->get_temp_master_records(1);
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['transaction_reference'];
				}
			}
			$data['page_title'] = 'Delivery Challan Form';
			$data['main_content'] = $this->load->view('inventory_management/delivery_challan_form', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function gwis_physical_inspection()
	{
		if (!empty($_POST)) {
			//            echo '<pre>';
			//            print_r($_REQUEST);
			//            echo '</pre>';
			//            exit;   

			if (isset($_POST['pk_id'])) {
				$this->obj->pk_id = $_POST['pk_id'];
			}
			if (!isset($_POST['stock_master_id'])) {

				$current_year = date("Y");
				//current month
				$current_month = date("m");
				if ($current_month < 7) {
					//from date
					$from_date = ($current_year - 1) . "-06-30";
					//to date
					$to_date = $current_year . "-07-30";
				} else {
					//from date
					$from_date = $current_year . "-06-30";
					//to date
					$to_date = ($current_year + 1) . "-07-30";
				}
				//get last id
				$last_id = $this->obj_gwis_master->getLastID($from_date, $to_date, 1);

				if (!empty($last_id)) {
					if ($last_id)
						$last_idd = $last_id->result_array();
					foreach ($last_idd as $row) {
						$lastid = $row['Maxtr'];
					}
				}

				if ($lastid == NULL) {
					$lastid = 0;
				}
				$stkkid = '';
				if (isset($_REQUEST['stakeholder']) && !empty($_REQUEST['stakeholder'])) {
					$stkkid = $_REQUEST['stakeholder'];
				} else if (isset($_REQUEST['sstakeholder']) && !empty($_REQUEST['sstakeholder'])) {
					$stkkid = $_REQUEST['sstakeholder'];
				}
				$itmnamea = $this->obj_itminfo->get_diseasetype($stkkid);
				$itmnameb = $itmnamea->result_array();
				foreach ($itmnameb as $row) {
					$did = $row['disease_type'];
				}
				$prefix = '';
				if (isset($did) && !empty($did)) {
					//                        $charc = substr($did, 0, 1);
					if ($did == '1') {
						$prefix = 'A';
					} else if ($did == '2') {
						$prefix = 'M';
					} else if ($did == '3') {
						$prefix = 'TB';
					} else {
						$prefix = '';
					}
				}

				$trans_no = $prefix . "GWISPI" . date('ym') . str_pad(($lastid + 1), 4, "0", STR_PAD_LEFT);
				$this->obj_gwis_master->tran_no = $trans_no;
				$this->obj_gwis_master->tr_no = ($lastid + 1);

				//                date_default_timezone_set('Asia/Karachi');
				//                $receivedatetime = date('Y-m-d h:i:s', time());

				$this->obj_gwis_master->tran_date = date("Y-m-d", strtotime($this->input->post('receiving_time')));

				$this->obj_gwis_master->status_id = '1';

				if (!empty($this->input->post('po_detail_info'))) {
					$this->obj_gwis_master->tran_ref = $this->input->post('po_detail_info');
				}
				if (!empty($this->input->post('wh_detail_info'))) {
					$this->obj_gwis_master->tran_ref = $this->input->post('wh_detail_info');
				}
				if (!empty($this->input->post('refernce_number'))) {
					$this->obj_gwis_master->tran_ref = $this->input->post('refernce_number');
				}
				//                $this->obj_gwis_master->wh_id_from = $this->input->post('receive_from');
				//                $this->obj_gwis_master->wh_id_from_supplier = $this->input->post('receive_from_supplier');
				//                $this->obj_gwis_master->source_type = $this->input->post('receive_from');

				$this->obj_gwis_master->wh_id_from_supplier = $this->input->post('receive_from_supplier');

				$this->obj_gwis_master->wh_id_from = $this->input->post('receive_from_warehouse');

				if (isset($_REQUEST['stakeholder']) && !empty($_REQUEST['stakeholder'])) {
					$this->obj_gwis_master->stk_id = $_REQUEST['stakeholder'];
				} else if (isset($_REQUEST['sstakeholder']) && !empty($_REQUEST['sstakeholder'])) {
					$this->obj_gwis_master->stk_id = $_REQUEST['sstakeholder'];
				}

				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				$this->obj_gwis_master->created_by = $_SESSION['id'];
				$this->obj_gwis_master->created_on = date("Y-m-d");
				$this->obj_gwis_master->user_from = 1;
				$this->obj_gwis_master->user_to = 1;
				$this->obj_gwis_master->temp = 1;
				$this->obj_gwis_master->mcc_year = $this->input->post('mcc_year');
				$this->obj_gwis_master->received_remarks = $this->input->post('remarks');
				$this->obj_gwis_master->issuance_to = 'centers';
				$this->obj_gwis_master->approve_from = '';
				$this->obj_gwis_master->approve_to = 'A0';
				$this->obj_gwis_master->process_status = '1';
				$this->obj_gwis_master->active_process = 1;

				$this->obj_gwis_master->inspection_date = date('Y-m-d', strtotime($this->input->post('inspection_date')));
				$this->obj_gwis_master->delivery_location = $this->input->post('delivery_location');
				$this->obj_gwis_master->po_cmu_no = $this->input->post('po_cmu');
				$this->obj_gwis_master->po_cmu_date = $this->input->post('po_cmu_date');
				$this->obj_gwis_master->po_gf_no = $this->input->post('po_gf');
				$this->obj_gwis_master->po_gf_date = $this->input->post('po_gf_date');

				$this->obj_gwis_master->date_of_receiving = date('Y-m-d', strtotime($this->input->post('date_of_receiving')));
				$this->obj_gwis_master->air_bill_no = $this->input->post('air_bill_no');
				$this->obj_gwis_master->shipment_no = $this->input->post('shipment_no');
				$this->obj_gwis_master->origin_of_country = $this->input->post('origin_of_country');
				$this->obj_gwis_master->vehicle_type_and_plate = $this->input->post('vehicle_type_and_plate');
				$this->obj_gwis_master->consignment_weight = $this->input->post('consignment_weight');

				//file upload
				$uploadedFile = '';
				$uploadDir = 'uploads/';
				if (!empty($_FILES["fileToUpload"]["name"])) {
					//                    $uploadedFile = 'test';
					// File path config 
					$fileName = basename($_FILES["fileToUpload"]["name"]);
					$targetFilePath = $uploadDir . $fileName;
					$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

					// Allow certain file formats 
					$allowTypes = array('pdf', 'doc', 'docx', 'jpg', 'png', 'jpeg');
					if (in_array($fileType, $allowTypes)) {
						// Upload file to the server 
						if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFilePath)) {
							$uploadedFile = $fileName;
						}
					}
				}

				$this->obj_gwis_master->file = $uploadedFile;

				//                echo '<pre>';
				//            print_r($_REQUEST);
				//            print_r($this->obj_gwis_master);
				//            echo '</pre>';
				//            exit;
				if ($this->input->post('pkmasterid')) {
					$this->obj_gwis_master->pk_id = $this->input->post('pkmasterid');
					$this->obj_gwis_master->updatebatchmaster();
					$stock_master_id = $this->input->post('pkmasterid');
				} else {
					$stock_master_id = $this->obj_gwis_master->save();
				}
			} else {
				$stock_master_id = $_POST['stock_master_id'];
			}
			//            $this->obj_stock_batch->batch_no = $this->input->post('batch_number');
			//            $this->obj_stock_batch->batch_expiry = date('Y-m-d', strtotime($_POST['expiry_date']));
			//            $this->obj_stock_batch->production_date = date('Y-m-d', strtotime($_POST['manufacturing_date']));
			//Get product name
			$prodname = '';
			$getproductnameinfo = $this->obj_stock_batch->getprodname($this->input->post('product'));
			if (!empty($getproductnameinfo)) {
				if ($getproductnameinfo)
					$getproductnameinfo_result = $getproductnameinfo->result_array();
				foreach ($getproductnameinfo_result as $row) {
					$prodname = $row['itm_name'];
				}
			}

			if (isset($_POST['field1']) && !empty($_POST['field1'])) {
				$this->obj_stock_batch->batch_no = $_POST['field1'];
				$cbatch_no = $_POST['field1'];
			} else {
				$this->obj_stock_batch->batch_no = 'NA';
			}
			if (isset($_POST['field2'])) {
				$this->obj_stock_batch->production_date = date('Y-m-d', strtotime($_POST['field2']));
			}
			if (isset($_POST['field3'])) {
				$this->obj_stock_batch->batch_expiry = date('Y-m-d', strtotime($_POST['field3']));
			}

			$this->obj_stock_batch->unit_price = $this->input->post('unit_price');
			$this->obj_stock_batch->currency = $this->input->post('currency');
			$this->obj_stock_batch->conversion_rate = $this->input->post('conversion_rate');
			$this->obj_stock_batch->item_id = $this->input->post('product');
			$this->obj_stock_batch->wh_id = $this->session->userdata('warehouse_id');

			//            if()
			//            $this->obj_stock_batch->wh_id_from_supplier = $this->input->post('receive_from_supplier');
			//            $this->obj_stock_batch->wh_id_from = $this->input->post('receive_from_warehouse');

			$this->obj_stock_batch->Qty = $_POST['actual_rec_qty'];
			$this->obj_stock_batch->funding_source = $this->input->post('receive_from');
			if ((isset($_REQUEST['manufacturer_id'])) && !empty($_REQUEST['manufacturer_id'])) {
				$this->obj_stock_batch->manufacturer = $this->input->post('manufacturer_id');
			}

			if ((isset($_REQUEST['manufacturer_id'])) && !empty($_REQUEST['manufacturer_id'])) {
				$get_manuf_arr_id_data = $this->obj_stakeholder->get_manuf_arr_id_data($_REQUEST['manufacturer_id']);
				if ($get_manuf_arr_id_data)
					$get_manuf_arr_id_data_res = $get_manuf_arr_id_data->result_array();
				foreach ($get_manuf_arr_id_data_res as $row) {
					$manuf_name = $row['stkname'];
				}
			}

			if ((isset($manuf_name)) && !empty($manuf_name)) {
				$this->obj_stock_batch->manufacturer_name = $manuf_name;
			}
			//            $this->obj_stock_batch->phy_inspection = $this->input->post('physical_inspection');
			//            $this->obj_stock_batch->dtl = $this->input->post('dtl');
			//            
			//            
			//            if($this->input->post('batchid'))
			//            {
			//                $this->obj_stock_batch->batch_id = $this->input->post('batchid');
			//                $this->obj_stock_batch->save();
			//                $stock_batch_id = $this->input->post('batchid');
			//            }
			//            else{
			//                $stock_batch_id = $this->obj_stock_batch->save();
			//            }

			if (!empty($cbatch_no)) {
				$get_batch_no_scriptinfo = $this->obj_reports_model->get_batch_no_info($cbatch_no, $this->input->post('product'));
				if ($get_batch_no_scriptinfo) {
					$get_batch_no_scriptinfo_arr = $get_batch_no_scriptinfo->result_array();
					//                        print_r($get_batch_no_scriptinfo_arr);exit;
					foreach ($get_batch_no_scriptinfo_arr as $row13) {
						$this->obj_stock_batch->update_recalculate_batch_qty($row13['batch_id'], $_POST['actual_rec_qty']);
						$stock_batch_id = $row13['batch_id'];
					}
				} else {
					$stock_batch_id = $this->obj_stock_batch->save();
				}
			} else {
				$get_batch_no_scriptinfo = $this->obj_reports_model->get_product_batch_id_info($prodname, $this->input->post('product'));
				if ($get_batch_no_scriptinfo) {
					$get_batch_no_scriptinfo_arr = $get_batch_no_scriptinfo->result_array();
					//                        print_r($get_batch_no_scriptinfo_arr);exit;
					foreach ($get_batch_no_scriptinfo_arr as $row13) {
						$this->obj_stock_batch->update_recalculate_batch_qty($row13['batch_id'], $_POST['actual_rec_qty']);
						$stock_batch_id = $row13['batch_id'];
					}
				} else {
					$stock_batch_id = $this->obj_stock_batch->save();
				}
			}


			//do this change in table and model.
			$this->obj_gwis_detail->delivery_challan_type = $this->input->post('challan_type');
			if (!empty($this->input->post('po_detail_info'))) {
				$this->obj_gwis_detail->challan_type_detail = $this->input->post('po_detail_info');
			}
			if (!empty($this->input->post('wh_detail_info'))) {
				$this->obj_gwis_detail->challan_type_detail = $this->input->post('wh_detail_info');
			}
			$this->obj_gwis_detail->fk_stock_id = $stock_master_id;              //check id name
			$this->obj_gwis_detail->batch_id = $stock_batch_id;
			$this->obj_gwis_detail->quantity = $_POST['actual_rec_qty'];
			$this->obj_gwis_detail->dc_quantity = $_POST['dc_quantity'];
			$this->obj_gwis_detail->po_quantity = $_POST['po_quantity'];
			//            $this->obj_gwis_detail->pi_quantity = $_POST['pi_quantity'];
			$this->obj_gwis_detail->pi_quantity = $_POST['actual_rec_qty'];
			$this->obj_gwis_detail->actual_rec_qty = $_POST['actual_rec_qty'];
			$this->obj_gwis_detail->pi_comment = $this->input->post('remarks');
			$this->obj_gwis_detail->driver_name = $_POST['driver_name'];
			$this->obj_gwis_detail->driver_contract = $_POST['driver_contract'];
			$this->obj_gwis_detail->vehicle_reg = $_POST['vehicle_reg'];
			$this->obj_gwis_detail->dc_no = $_POST['dc_no'];
			$this->obj_gwis_detail->dc_date = date('Y-m-d', strtotime($_POST['dc_date']));
			$this->obj_gwis_detail->invoice = $_POST['invoice'];
			$this->obj_gwis_detail->pi_type = $this->input->post('pi_type');
			$this->obj_gwis_detail->shipment_temprature = $this->input->post('shipment_temprature');

			$this->obj_gwis_detail->sbtr_dc_rec = $this->input->post('dc_remove_rec');

			if (isset($_POST['field1'])) {
				$this->obj_gwis_detail->field1 = $_POST['field1'];
			} else {
				$this->obj_gwis_detail->field1 = 'NA';
			}
			if (isset($_POST['field2'])) {
				$this->obj_gwis_detail->field2 = date('Y-m-d', strtotime($_POST['field2']));
			}
			if (isset($_POST['field3'])) {
				$this->obj_gwis_detail->field3 = date('Y-m-d', strtotime($_POST['field3']));
			}
			if (isset($_POST['field4'])) {
				$this->obj_gwis_detail->field4 = $_POST['field4'];
			}
			if (isset($_POST['field5'])) {
				$this->obj_gwis_detail->field5 = $_POST['field5'];
			}
			if (isset($_POST['field6'])) {
				$this->obj_gwis_detail->field6 = $_POST['field6'];
			}
			if (isset($_POST['field7'])) {
				$this->obj_gwis_detail->field7 = $_POST['field7'];
			}
			if (isset($_POST['field8'])) {
				$this->obj_gwis_detail->field8 = $_POST['field8'];
			}
			if (isset($_POST['field9'])) {
				$this->obj_gwis_detail->field9 = $_POST['field9'];
			}
			if (isset($_POST['field10'])) {
				$this->obj_gwis_detail->field10 = date('Y-m-d', strtotime($_POST['field10']));
			}
			if (isset($_POST['field11'])) {
				$this->obj_gwis_detail->field11 = $_POST['field11'];
			}
			if (isset($_POST['field12'])) {
				$this->obj_gwis_detail->field12 = $_POST['field12'];
			}
			if (isset($_POST['field13'])) {
				$this->obj_gwis_detail->field13 = $_POST['field13'];
			}
			if (isset($_POST['field14'])) {
				$this->obj_gwis_detail->field14 = $_POST['field14'];
			}
			if (isset($_POST['field15'])) {
				$this->obj_gwis_detail->field15 = $_POST['field15'];
			}
			if (isset($_POST['field16'])) {
				$this->obj_gwis_detail->field16 = $_POST['field16'];
			}
			if (isset($_POST['field17'])) {
				$this->obj_gwis_detail->field17 = $_POST['field17'];
			}
			if (isset($_POST['field18'])) {
				$this->obj_gwis_detail->field18 = $_POST['field18'];
			}
			if (isset($_POST['field19'])) {
				$this->obj_gwis_detail->field19 = $_POST['field19'];
			}
			if (isset($_POST['field20'])) {
				$this->obj_gwis_detail->field20 = $_POST['field20'];
			}
			//            for($i=1;$i<=20;$i++)
			//            {
			//                $this->obj_gwis_detail->field.$i  = $_POST['field'.$i.''];
			//            }

			$this->obj_gwis_detail->temp = 1;

			//            if($this->input->post('pkdetailid'))
			//            {
			//                $this->obj_gwis_detail->pk_id = $this->input->post('pkdetailid');
			//            }

			$this->obj_gwis_detail->save();


			$data['form'] = $_POST;
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();

			$po_no_cmu_arr = $this->obj_po_infos->find_all_po_cmu();
			if ($po_no_cmu_arr)
				$data['po_no_cmu_arr'] = $po_no_cmu_arr->result_array();

			$po_no_gf_arr = $this->obj_po_infos->find_all_po_gf();
			if ($po_no_gf_arr)
				$data['po_no_gf_arr'] = $po_no_gf_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();
			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			//            $warehouse_arr = $this->obj_stakeholder->find_warehouseinfo();
			$warehouse_arr = $this->obj_warehouse->find_all();
			if ($warehouse_arr)
				$data['warehouses'] = $warehouse_arr->result_array();

			$manuf_arr = $this->obj_stakeholder->get_all_info();
			$data['manufacturer'] = $manuf_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();

			$challan_type_arr = $this->obj_challan_type->find_active();
			if ($challan_type_arr)
				$data['challan_type'] = $challan_type_arr->result_array();

			$currency_arr = $this->obj_itminfo->find_currency_type();
			if ($currency_arr)
				$data['currency_type'] = $currency_arr->result_array();

			//            $stk_arr = $this->obj_stakeholder->get_all_stk();
			//                if ($stk_arr)
			//                    $data['stakeholder'] = $stk_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();

			$stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			if ($stock_master_record)
				$data['stock_master_records'] = $stock_master_record->result_array();

			$pi_arr = $this->obj_lists->get_list(14);
			if ($pi_arr)
				$data['pi_arr'] = $pi_arr->result_array();

			if (isset($_REQUEST['vouchertno']) && !empty($_REQUEST['vouchertno'])) {
				$data['pkmasteridedit'] = $_REQUEST['pkmasteridedit'];
				$data['vouchertno'] = $_REQUEST['vouchertno'];
				$data['edit'] = $_REQUEST['edit'];
				$data['temp_records'] = $this->obj_gwis_detail->get_temp_records_edit($_REQUEST['pkmasteridedit']);
			} else {
				$data['temp_records'] = $this->obj_gwis_detail->get_temp_records($stock_master_id);
			}
			//            echo '<pre>';
			//            echo $stock_master_id;
			//            $a=array();
			//                foreach ($data['temp_records']->result_array() as $row) {
			//                    $a[]=$row;
			//                }
			//            print_r($a);
			//            echo '</pre>';
			//            exit;
			$data['master_id'] = $stock_master_id;
			$data['page_title'] = 'GIWS – Physical Inspection';

			$data['main_content'] = $this->load->view('inventory_management/gwis_physical_inspection', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();


			if ($this->input->get("pkdetailid")) {
				$data['pkdetailid'] = $this->input->get("pkdetailid");
				$data['batchid'] = $this->input->get("batchid");
				$data['fkstockid'] = $this->input->get("fkstockid");
				$res = $this->obj_gwis_detail->GetBatchDetail($this->input->get("pkdetailid"), $this->input->get("batchid"));
				//            $row = $res->row();
				if ($res) {
					$data['gwis_data'] = $res->result_array();
				}
				//            $data['lab_list'] = $lab_test_master->get_combo();
				//            $res = $this->obj_visit->find_by_patient_id($this->input->get("patient_id"));
				//            $row = $res->row();
				//            if (isset($row) && !empty($row))
				//            {
				//                $data['vital_info'] = $res->result_array();
				//            }
			}

			if (isset($_REQUEST['pkmasteridedit']) && !empty($_REQUEST['pkmasteridedit'])) {
				//                $data['pkdetailid'] = $this->input->get("pkdetailid");
				//                $data['batchid'] = $this->input->get("batchid");
				//                $data['fkstockid'] = $this->input->get("fkstockid");
				$res = $this->obj_gwis_detail->GetBatchDetailForEdit($_REQUEST['pkmasteridedit']);
				//            $row = $res->row();
				if ($res) {
					$data['gwis_data'] = $res->result_array();
				}
				//            $data['lab_list'] = $lab_test_master->get_combo();
				//            $res = $this->obj_visit->find_by_patient_id($this->input->get("patient_id"));
				//            $row = $res->row();
				//            if (isset($row) && !empty($row))
				//            {
				//                $data['vital_info'] = $res->result_array();
				//            }
			}
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();

			$po_no_cmu_arr = $this->obj_po_infos->find_all_po_cmu();
			if ($po_no_cmu_arr)
				$data['po_no_cmu_arr'] = $po_no_cmu_arr->result_array();

			$po_no_gf_arr = $this->obj_po_infos->find_all_po_gf();
			if ($po_no_gf_arr)
				$data['po_no_gf_arr'] = $po_no_gf_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();
			//            $stk_arr = $this->obj_stakeholder->get_all_stk();
			//                if ($stk_arr)
			//                    $data['stakeholder'] = $stk_arr->result_array();
			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$manuf_arr = $this->obj_stakeholder->get_all_info();
			$data['manufacturer'] = $manuf_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			//            $warehouse_arr = $this->obj_stakeholder->find_warehouseinfo();
			$warehouse_arr = $this->obj_warehouse->find_all();
			if ($warehouse_arr)
				$data['warehouses'] = $warehouse_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();

			$currency_arr = $this->obj_itminfo->find_currency_type();
			if ($currency_arr)
				$data['currency_type'] = $currency_arr->result_array();

			$pi_arr = $this->obj_lists->get_list(14);
			if ($pi_arr)
				$data['pi_arr'] = $pi_arr->result_array();

			$challan_type_arr = $this->obj_challan_type->find_active();
			if ($challan_type_arr)
				$data['challan_type'] = $challan_type_arr->result_array();
			$data['temp_records'] = $this->obj_gwis_master->get_temp_master_records(1);
			$master_id_arr = $this->obj_gwis_master->get_temp_master_records(1);
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['tran_ref'];

					//Get Saved info in readonly fields
					$readonlyinfo = $this->obj_gwis_detail->GetBatchDetailForEdit($row['stock_master_id']);
					//            $row = $res->row();
					if ($readonlyinfo) {
						$data['gwis_data'] = $readonlyinfo->result_array();
					}
				}
			}
			if (isset($_REQUEST['vouchertno']) && !empty($_REQUEST['vouchertno'])) {
				$data['master_id'] = $_REQUEST['pkmasteridedit'];
				$data['temp_records'] = $this->obj_gwis_detail->get_temp_records_edit($_REQUEST['pkmasteridedit']);
			}
			$data['page_title'] = 'GIWS – Physical Inspection';
			$data['main_content'] = $this->load->view('inventory_management/gwis_physical_inspection', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function physical_inspection_form()
	{
		if (!empty($_POST) && empty($_REQUEST['issue_no'])) {

			if (isset($_POST['pk_id'])) {
				$this->obj->pk_id = $_POST['pk_id'];
			}

			//check stock id
			if (isset($_REQUEST['stock_id']) && !empty($_REQUEST['stock_id'])) {
				//get stock id
				$stock_id = $_REQUEST['stock_id'];

				$type_id = 1;
				//find by stock id
				//        $stockDetail = $objStockDetail->find_by_stock_id($stock_id);
				//check remarks
				if (isset($_REQUEST['remarks']) && !empty($_REQUEST['remarks'])) {
					//get remarks
					$remarks = $_REQUEST['remarks'];
				} else {
					$remarks = "";
				}
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
				}
				if (isset($_REQUEST['count']) && !empty($_REQUEST['count'])) {
					$count_o = $_REQUEST['count'];
				}
				//check receive date 
				if (isset($_REQUEST['rec_date']) && !empty($_REQUEST['rec_date'])) {
					//get receive date
					$rec_date = $_REQUEST['rec_date'];
				}
				//check receive reference
				if (isset($_REQUEST['rec_ref']) && !empty($_REQUEST['rec_ref'])) {
					//get receive reference
					$rec_ref = $_REQUEST['rec_ref'];
				}
				//check vvm
				if (isset($_REQUEST['vvmstage']) && !empty($_REQUEST['vvmstage'])) {
					//get vvm
					$vvmstage = $_REQUEST['vvmstage'];
				}
				//check cold chain
				if (isset($_REQUEST['cold_chain']) && !empty($_REQUEST['cold_chain'])) {
					//get cold chain
					$cold_chain = $_REQUEST['cold_chain'];
				}
			}
			//            
			//            
			//            
			//            
			//            
			//            
			//            
			if (isset($_REQUEST['stockid']) && !empty($_REQUEST['stockid'])) {
				//get stock id
				$stock_ids = $_REQUEST['stockid'];
				$count = count($stock_ids);
				//        print_r($stock_ids);exit;
				foreach ($stock_ids as $index => $detail_id) {
					//Stock Received
					//            $this->obj_gwis_detail->StockReceived($detail_id);
					//Get Batch Detail
					$stockBatch = $this->obj_stock_batch->GetBatchDetail($detail_id);
					if ($stockBatch) {
						$stockBatch1 = $stockBatch->result_array();
					}
					if (isset($stockBatch1)) {
						$row = $stockBatch1[0];
						$Qty = $row['quantity'];
						$item_id = $row['item_id'];
						$batch_no = $row['batch_no'];
						$batch_expiry = $row['batch_expiry'];
						$funding_source = $row['funding_source'];
						$manufacturer = $row['manufacturer'];
						$unit_price = $row['unit_price'];
						$production_date = $row['production_date'];
					}

					//get missing
					$array_missing = $_REQUEST['missing'];
					if (isset($array_missing[$index]) && !empty($array_missing[$index])) {
						//get missing
						$dc_quantity = $_REQUEST['dc_quantity'];
						$missing = $_REQUEST['missing'];
						$comment = $_REQUEST['comment'];
						//get type
						//                $type = $_REQUEST['types'];
						//find by detail id
						$stockDetail = $this->obj_gwis_detail->find_by_detail_id($detail_id);
						//
						if ($stockDetail) {
							//fetch results
							//                    $data = mysql_fetch_object($stockDetail);
							//                    $this->obj_gwis_master->pk_id = $stock_ids[$index];
							$this->obj_gwis_master->pk_id = $_REQUEST['stock_id'];

							$this->obj_gwis_master->status_id = 1;
							//User From
							$this->obj_gwis_master->user_from = 1;
							//User To
							$this->obj_gwis_master->user_to = 1;
							//transaction type
							//                    $this->obj_gwis_master->TranTypeID = $type[$index];
							//transaction date
							$this->obj_gwis_master->tran_date = date('Y-m-d', strtotime($rec_date));
							//transaction reference
							$this->obj_gwis_master->tran_ref = $rec_ref;
							//from warehouse
							//                    $this->obj_gwis_master->wh_id_from = $_SESSION['warehouse_id'];
							//                    //to warehouse
							//                    $this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
							//created by
							//                    $this->obj_gwis_master->CreatedBy = $_SESSION['user_id'];
							//created on
							$this->obj_gwis_master->created_on = date("Y-m-d");
							//received remarks
							$this->obj_gwis_master->received_remarks = $remarks;
							//temp
							$this->obj_gwis_master->temp = 0;
							//linked Tr
							//                    $this->obj_gwis_master->linked_tr = $fk_stock_id;
							//get fiscal year
							//                    $fy_dates = $objFiscalYear->getFiscalYear();
							//get Adj Last ID
							//                    $last_id = $this->obj_gwis_master->getAdjLastID($fy_dates['from_date'], $fy_dates['to_date']);
							//get PI Last ID

							$current_year = date("Y");
							//current month
							$current_month = date("m");
							if ($current_month < 7) {
								//from date
								$from_date = ($current_year - 1) . "-06-30";
								//to date
								$to_date = $current_year . "-07-30";
							} else {
								//from date
								$from_date = $current_year . "-06-30";
								//to date
								$to_date = ($current_year + 1) . "-07-30";
							}

							$last_id = $this->obj_gwis_master->getLastID($from_date, $to_date, 1);
							//if last id null set it to zero
							if (!empty($last_id)) {
								if ($last_id)
									$last_idd = $last_id->result_array();
								foreach ($last_idd as $row) {
									$lastid = $row['Maxtr'];
								}
							}

							if ($lastid == NULL) {
								$lastid = 0;
							}
							//transaction number
							$trans_no = "PI" . date('ym') . str_pad(($lastid + 1), 4, "0", STR_PAD_LEFT);
							//transaction number
							$this->obj_gwis_master->tran_no = $trans_no;
							$this->obj_gwis_master->tr_no = ($lastid + 1);
							//save stock master
							$StockID = $this->obj_gwis_master->update_master_using_id();
						}

						$adjustment = true;
					}
					//quantity
					$quantity = str_replace("-", "", $Qty);
					//product id
					$product_id = $item_id;

					//            $this->obj_stock_batch->fk_stock_id = $stock_ids[$index];
					//batch number
					$this->obj_stock_batch->batch_no = $batch_no;
					//batch expiry
					$this->obj_stock_batch->batch_expiry = $batch_expiry;
					$this->obj_stock_batch->funding_source = $funding_source;
					$this->obj_stock_batch->manufacturer = $manufacturer;
					//quantity
					$this->obj_stock_batch->Qty = $quantity;
					//item id
					$this->obj_stock_batch->item_id = $product_id;
					//status
					$this->obj_stock_batch->status = 'Stacked';
					//unit price
					$this->obj_stock_batch->unit_price = $unit_price;
					//production date
					$this->obj_stock_batch->production_date = $production_date;
					//warehouse id
					$this->obj_stock_batch->wh_id = $_SESSION['warehouse_id'];
					//save stock batch
					//            echo '<pre>';
					//            print_r($stockBatch);
					//            print_r($objStockBatch);
					//            exit;
					$batch_id1 = $this->obj_stock_batch->save();

					if ($adjustment) {
						// Detail Entry for Adjustment
						//fk stock id
						//                $this->obj_gwis_detail->fk_stock_id =  $stock_ids[$index];
						$this->obj_gwis_detail->pk_id = $stock_ids[$index];
						//batch id
						$this->obj_gwis_detail->batch_id = $batch_id1;
						//fk unit id
						//                $this->obj_gwis_detail->fk_unit_id = $data->fkUnitID;
						//quantity
						//                $this->obj_gwis_detail->quantity = $array_types[$type[$index]] . $missing[$index];
						$this->obj_gwis_detail->quantity = $dc_quantity[$index] - $missing[$index];
						// PI Quantity
						$this->obj_gwis_detail->pi_quantity = $missing[$index];
						// PI Comments
						$this->obj_gwis_detail->pi_comment = $comment[$index];
						//temp
						//                $this->obj_gwis_detail->temp = 0;
						$this->obj_gwis_detail->temp = 0;
						//is received
						$this->obj_gwis_detail->is_received = 0;
						//adjustment type
						//                $this->obj_gwis_detail->adjustment_type = $type[$index];
						//save stock detail
						//                $this->obj_gwis_detail->update_stock_using_id();
						$this->obj_gwis_detail->update_stock_using_id();
					}
					//fk stock id
					//            $this->obj_gwis_detail->fk_stock_id = $fkStockID;
					//            //batch id
					//            $this->obj_gwis_detail->batch_id = $batch_id1;
					//            //fk unit id
					//            $this->obj_gwis_detail->fk_unit_id = $data->fkUnitID;
					//            //quantity
					////            $this->obj_gwis_detail->quantity = $array_types[$type_id] . $quantity;
					//            $this->obj_gwis_detail->pi_quantity = $quantity;
					//            //temp
					//            $this->obj_gwis_detail->temp = 0;
					//            //is received
					//            $this->obj_gwis_detail->is_received = 1;
					//            //adjustment type
					//            $this->obj_gwis_detail->adjustment_type = $type_id;
					//            //save stock detail
					//            $this->obj_gwis_detail->save();
					// Adjust Batch Quantity
					//            $this->obj_stock_batch->adjustQtyByWh($batch_id1, $_SESSION['warehouse_id']);
					//            //auto Running LEFO Batch
					//            $this->obj_stock_batch->autoRunningLEFOBatch($product_id, $_SESSION['warehouse_id']);
				} // End foreach
			}














			if (!isset($_POST['stock_master_id'])) {
				//                $this->obj_gwis_master->tran_date = date('Y-m-d', strtotime($_POST['receiving_time']));
				//                $this->obj_gwis_master->status_id = $this->input->post('status_id');
				//                $this->obj_gwis_master->tran_ref = $this->input->post('refernce_number');
				//                $this->obj_gwis_master->wh_id_from = $this->input->post('receive_from');
				//                $this->obj_gwis_master->wh_id_from_supplier = $this->input->post('receive_from_supplier');
				//                $this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//                $this->obj_gwis_master->created_by = $_SESSION['id'];
				//                $this->obj_gwis_master->created_on = date("Y-m-d");
				//                $this->obj_gwis_master->user_from = 1;
				//                $this->obj_gwis_master->user_to = 1;
				//                $this->obj_gwis_master->temp = 1;
				//                $this->obj_gwis_master->mcc_year = $this->input->post('mcc_year');
				//                $this->obj_gwis_master->received_remarks = $this->input->post('remarks');
				//                $this->obj_gwis_master->issuance_to = 'centers';
				////                echo '<pre>';
				////            print_r($_REQUEST);
				////            print_r($this->obj_gwis_master);
				////            echo '</pre>';
				////            exit;
				//                $stock_master_id = $this->obj_gwis_master->save();
			} else {
				$stock_master_id = $_POST['stock_master_id'];
			}
			//            $this->obj_stock_batch->batch_no = $this->input->post('batch_number');
			//            $this->obj_stock_batch->batch_expiry = date('Y-m-d', strtotime($_POST['expiry_date']));
			//            $this->obj_stock_batch->production_date = date('Y-m-d', strtotime($_POST['manufacturing_date']));
			//            $this->obj_stock_batch->item_id = $this->input->post('product');
			//            $this->obj_stock_batch->wh_id = $this->session->userdata('warehouse_id');
			//            $this->obj_stock_batch->Qty = $this->input->post('quantity');
			//            $this->obj_stock_batch->funding_source = $this->input->post('receive_from');
			////            $this->obj_stock_batch->phy_inspection = $this->input->post('physical_inspection');
			////            $this->obj_stock_batch->dtl = $this->input->post('dtl');
			//            $stock_batch_id = $this->obj_stock_batch->save();
			//
			//
			//            $this->obj_gwis_detail->fk_stock_id = $stock_master_id;              //check id name
			//            $this->obj_gwis_detail->batch_id = $stock_batch_id;
			//            $this->obj_gwis_detail->dc_quantity = $_POST['quantity'];
			//            $this->obj_gwis_detail->temp = 1;
			//            $this->obj_gwis_detail->save();
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();

			if (isset($_REQUEST['issue_no'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = 0;
				$this->obj_gwis_master->tran_no = $issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if (isset($stockReceive) && !empty($stockReceive)) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}
			$this->obj_gwis_master->status_id = 0;
			$qry_vouchers = $this->obj_gwis_master->get_issue_vouchers();
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}
			//
			//                //chech if record exists
			//             $issueVoucher = '';
			//             $a='';
			//                if ($getStockIssues) {
			//
			//                    //fetch results
			//                    foreach ($getStockIssues AS $row)
			//                    {
			//                        $a= " <a href=\"new_receive_wh.php?issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
			//                        $issueVoucher[ $row['tran_no']] = $a;
			//                    }
			//
			//                }


			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_by_idsupplier();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();

			//            $stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			//            if ($stock_master_record)
			//                $data['stock_master_records'] = $stock_master_record->result_array();
			//            $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($stock_master_id);
			//            echo '<pre>';
			//            echo $stock_master_id;
			//            $a=array();
			//                foreach ($data['temp_records']->result_array() as $row) {
			//                    $a[]=$row;
			//                }
			//            print_r($a);
			//            echo '</pre>';
			//            exit;
			//            $data['master_id'] = $stock_master_id;
			$data['page_title'] = 'Physical Inspection Form';

			$data['main_content'] = $this->load->view('inventory_management/physical_inspection_form', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();
			$this->obj_gwis_master->status_id = 0;
			$qry_vouchers = $this->obj_gwis_master->get_issue_vouchers();
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}


			$stockReceive = '';
			if (isset($_REQUEST['issue_no'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = 0;
				$this->obj_gwis_master->tran_no = $issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if ($stockReceive) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}

			//            $qry_vouchers = $this->obj_gwis_master->get_issue_vouchers();
			//            $getStockIssues = $qry_vouchers->result_array();
			//
			//
			//                //chech if record exists
			//             $issueVoucher = '';
			//             $a='';
			//                if ($getStockIssues) {
			//
			//                    //fetch results
			//                    foreach ($getStockIssues AS $row)
			//                    {
			//                        $a= " <a href=\"new_receive_wh.php?issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
			//                        $issueVoucher[ $row['tran_no']] = $a;
			//                    }
			//
			//                }
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_by_idsupplier();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();
			//            $data['temp_records'] = $this->obj_gwis_master->get_temp_master_records(1);
			//            $master_id_arr = $this->obj_gwis_master->get_temp_master_records(1);
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['transaction_reference'];
				}
			}
			$data['page_title'] = 'Physical Inspection Form';
			$data['main_content'] = $this->load->view('inventory_management/physical_inspection_form', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function technical_inspection_form()
	{
		if (!empty($_POST) && empty($_REQUEST['issue_no'])) {

			if (isset($_POST['pk_id'])) {
				$this->obj->pk_id = $_POST['pk_id'];
			}











			//check stock id
			if (isset($_REQUEST['stock_id']) && !empty($_REQUEST['stock_id'])) {
				//get stock id
				$stock_id = $_REQUEST['stock_id'];

				$type_id = 1;
				//find by stock id
				//        $stockDetail = $objStockDetail->find_by_stock_id($stock_id);
				//check remarks
				if (isset($_REQUEST['remarks']) && !empty($_REQUEST['remarks'])) {
					//get remarks
					$remarks = $_REQUEST['remarks'];
				} else {
					$remarks = "";
				}
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
				}
				if (isset($_REQUEST['count']) && !empty($_REQUEST['count'])) {
					$count_o = $_REQUEST['count'];
				}
				//check receive date 
				if (isset($_REQUEST['rec_date']) && !empty($_REQUEST['rec_date'])) {
					//get receive date
					$rec_date = $_REQUEST['rec_date'];
				}
				//check receive reference
				if (isset($_REQUEST['rec_ref']) && !empty($_REQUEST['rec_ref'])) {
					//get receive reference
					$rec_ref = $_REQUEST['rec_ref'];
				}
				//check vvm
				if (isset($_REQUEST['vvmstage']) && !empty($_REQUEST['vvmstage'])) {
					//get vvm
					$vvmstage = $_REQUEST['vvmstage'];
				}
				//check cold chain
				if (isset($_REQUEST['cold_chain']) && !empty($_REQUEST['cold_chain'])) {
					//get cold chain
					$cold_chain = $_REQUEST['cold_chain'];
				}
			}
			//            
			//            
			//            
			//            
			//            
			//            
			//            
			if (isset($_REQUEST['stockid']) && !empty($_REQUEST['stockid'])) {
				//get stock id
				$stock_ids = $_REQUEST['stockid'];
				$count = count($stock_ids);
				//        print_r($stock_ids);exit;
				foreach ($stock_ids as $index => $detail_id) {
					//Stock Received
					//            $this->obj_gwis_detail->StockReceived($detail_id);
					//Get Batch Detail
					$stockBatch = $this->obj_stock_batch->GetBatchDetail($detail_id);
					if ($stockBatch) {
						$stockBatch1 = $stockBatch->result_array();
					}
					if (isset($stockBatch1)) {
						$row = $stockBatch1[0];
						$Qty = $row['quantity'];
						$item_id = $row['item_id'];
						$batch_no = $row['batch_no'];
						$batch_expiry = $row['batch_expiry'];
						$funding_source = $row['funding_source'];
						$manufacturer = $row['manufacturer'];
						$unit_price = $row['unit_price'];
						$production_date = $row['production_date'];
					}

					//get missing
					$array_missing = $_REQUEST['missing'];
					if (isset($array_missing[$index]) && !empty($array_missing[$index])) {
						//get missing
						$dc_quantity = $_REQUEST['dc_quantity'];
						$missing = $_REQUEST['missing'];
						$comment = $_REQUEST['comment'];
						//get type
						//                $type = $_REQUEST['types'];
						//find by detail id
						$stockDetail = $this->obj_gwis_detail->find_by_detail_id($detail_id);
						//
						if ($stockDetail) {
							//fetch results
							//                    $data = mysql_fetch_object($stockDetail);
							//                    $this->obj_gwis_master->pk_id = $stock_ids[$index];
							$this->obj_gwis_master->pk_id = $_REQUEST['stock_id'];

							$this->obj_gwis_master->status_id = 2;
							//User From
							$this->obj_gwis_master->user_from = 1;
							//User To
							$this->obj_gwis_master->user_to = 1;
							//transaction type
							//                    $this->obj_gwis_master->TranTypeID = $type[$index];
							//transaction date
							$this->obj_gwis_master->tran_date = date('Y-m-d', strtotime($rec_date));
							//transaction reference
							$this->obj_gwis_master->tran_ref = $rec_ref;
							//from warehouse
							//                    $this->obj_gwis_master->wh_id_from = $_SESSION['warehouse_id'];
							//                    //to warehouse
							//                    $this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
							//created by
							//                    $this->obj_gwis_master->CreatedBy = $_SESSION['user_id'];
							//created on
							$this->obj_gwis_master->created_on = date("Y-m-d");
							//received remarks
							$this->obj_gwis_master->received_remarks = $remarks;
							//temp
							$this->obj_gwis_master->temp = 0;
							//linked Tr
							//                    $this->obj_gwis_master->linked_tr = $fk_stock_id;
							//get fiscal year
							//                    $fy_dates = $objFiscalYear->getFiscalYear();
							//get Adj Last ID
							//                    $last_id = $this->obj_gwis_master->getAdjLastID($fy_dates['from_date'], $fy_dates['to_date']);
							//get PI Last ID

							$current_year = date("Y");
							//current month
							$current_month = date("m");
							if ($current_month < 7) {
								//from date
								$from_date = ($current_year - 1) . "-06-30";
								//to date
								$to_date = $current_year . "-07-30";
							} else {
								//from date
								$from_date = $current_year . "-06-30";
								//to date
								$to_date = ($current_year + 1) . "-07-30";
							}

							$last_id = $this->obj_gwis_master->getLastID($from_date, $to_date, 2);
							//if last id null set it to zero
							if (!empty($last_id)) {
								if ($last_id)
									$last_idd = $last_id->result_array();
								foreach ($last_idd as $row) {
									$lastid = $row['Maxtr'];
								}
							}

							if ($lastid == NULL) {
								$lastid = 0;
							}
							//transaction number
							$trans_no = "TI" . date('ym') . str_pad(($lastid + 1), 4, "0", STR_PAD_LEFT);
							//transaction number
							$this->obj_gwis_master->tran_no = $trans_no;
							$this->obj_gwis_master->tr_no = ($lastid + 1);
							//save stock master
							$StockID = $this->obj_gwis_master->update_master_using_id();
						}

						$adjustment = true;
					}
					//quantity
					$quantity = str_replace("-", "", $Qty);
					//product id
					$product_id = $item_id;

					//            $this->obj_stock_batch->fk_stock_id = $stock_ids[$index];
					//batch number
					$this->obj_stock_batch->batch_no = $batch_no;
					//batch expiry
					$this->obj_stock_batch->batch_expiry = $batch_expiry;
					$this->obj_stock_batch->funding_source = $funding_source;
					$this->obj_stock_batch->manufacturer = $manufacturer;
					//quantity
					$this->obj_stock_batch->Qty = $quantity;
					//item id
					$this->obj_stock_batch->item_id = $product_id;
					//status
					$this->obj_stock_batch->status = 'Stacked';
					//unit price
					$this->obj_stock_batch->unit_price = $unit_price;
					//production date
					$this->obj_stock_batch->production_date = $production_date;
					//warehouse id
					$this->obj_stock_batch->wh_id = $_SESSION['warehouse_id'];
					//save stock batch
					//            echo '<pre>';
					//            print_r($stockBatch);
					//            print_r($objStockBatch);
					//            exit;
					$batch_id1 = $this->obj_stock_batch->save();

					if ($adjustment) {
						// Detail Entry for Adjustment
						//fk stock id
						//                $this->obj_gwis_detail->fk_stock_id =  $stock_ids[$index];
						$this->obj_gwis_detail->pk_id = $stock_ids[$index];
						//batch id
						$this->obj_gwis_detail->batch_id = $batch_id1;
						//fk unit id
						//                $this->obj_gwis_detail->fk_unit_id = $data->fkUnitID;
						//quantity
						//                $this->obj_gwis_detail->quantity = $array_types[$type[$index]] . $missing[$index];
						$this->obj_gwis_detail->quantity = $dc_quantity[$index] - $missing[$index];
						// PI Quantity
						$this->obj_gwis_detail->ti_quantity = $missing[$index];
						// PI Comments
						$this->obj_gwis_detail->ti_comment = $comment[$index];
						//temp
						//                $this->obj_gwis_detail->temp = 0;
						$this->obj_gwis_detail->temp = 0;
						//is received
						$this->obj_gwis_detail->is_received = 0;
						//adjustment type
						//                $this->obj_gwis_detail->adjustment_type = $type[$index];
						//save stock detail
						//                $this->obj_gwis_detail->update_stock_using_id();
						$this->obj_gwis_detail->update_pistock_using_id();
					}
					//fk stock id
					//            $this->obj_gwis_detail->fk_stock_id = $fkStockID;
					//            //batch id
					//            $this->obj_gwis_detail->batch_id = $batch_id1;
					//            //fk unit id
					//            $this->obj_gwis_detail->fk_unit_id = $data->fkUnitID;
					//            //quantity
					////            $this->obj_gwis_detail->quantity = $array_types[$type_id] . $quantity;
					//            $this->obj_gwis_detail->pi_quantity = $quantity;
					//            //temp
					//            $this->obj_gwis_detail->temp = 0;
					//            //is received
					//            $this->obj_gwis_detail->is_received = 1;
					//            //adjustment type
					//            $this->obj_gwis_detail->adjustment_type = $type_id;
					//            //save stock detail
					//            $this->obj_gwis_detail->save();
					// Adjust Batch Quantity
					//            $this->obj_stock_batch->adjustQtyByWh($batch_id1, $_SESSION['warehouse_id']);
					//            //auto Running LEFO Batch
					//            $this->obj_stock_batch->autoRunningLEFOBatch($product_id, $_SESSION['warehouse_id']);
				} // End foreach
			}














			if (!isset($_POST['stock_master_id'])) {
				//                $this->obj_gwis_master->tran_date = date('Y-m-d', strtotime($_POST['receiving_time']));
				//                $this->obj_gwis_master->status_id = $this->input->post('status_id');
				//                $this->obj_gwis_master->tran_ref = $this->input->post('refernce_number');
				//                $this->obj_gwis_master->wh_id_from = $this->input->post('receive_from');
				//                $this->obj_gwis_master->wh_id_from_supplier = $this->input->post('receive_from_supplier');
				//                $this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//                $this->obj_gwis_master->created_by = $_SESSION['id'];
				//                $this->obj_gwis_master->created_on = date("Y-m-d");
				//                $this->obj_gwis_master->user_from = 1;
				//                $this->obj_gwis_master->user_to = 1;
				//                $this->obj_gwis_master->temp = 1;
				//                $this->obj_gwis_master->mcc_year = $this->input->post('mcc_year');
				//                $this->obj_gwis_master->received_remarks = $this->input->post('remarks');
				//                $this->obj_gwis_master->issuance_to = 'centers';
				////                echo '<pre>';
				////            print_r($_REQUEST);
				////            print_r($this->obj_gwis_master);
				////            echo '</pre>';
				////            exit;
				//                $stock_master_id = $this->obj_gwis_master->save();
			} else {
				$stock_master_id = $_POST['stock_master_id'];
			}
			//            $this->obj_stock_batch->batch_no = $this->input->post('batch_number');
			//            $this->obj_stock_batch->batch_expiry = date('Y-m-d', strtotime($_POST['expiry_date']));
			//            $this->obj_stock_batch->production_date = date('Y-m-d', strtotime($_POST['manufacturing_date']));
			//            $this->obj_stock_batch->item_id = $this->input->post('product');
			//            $this->obj_stock_batch->wh_id = $this->session->userdata('warehouse_id');
			//            $this->obj_stock_batch->Qty = $this->input->post('quantity');
			//            $this->obj_stock_batch->funding_source = $this->input->post('receive_from');
			////            $this->obj_stock_batch->phy_inspection = $this->input->post('physical_inspection');
			////            $this->obj_stock_batch->dtl = $this->input->post('dtl');
			//            $stock_batch_id = $this->obj_stock_batch->save();
			//
			//
			//            $this->obj_gwis_detail->fk_stock_id = $stock_master_id;              //check id name
			//            $this->obj_gwis_detail->batch_id = $stock_batch_id;
			//            $this->obj_gwis_detail->dc_quantity = $_POST['quantity'];
			//            $this->obj_gwis_detail->temp = 1;
			//            $this->obj_gwis_detail->save();
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();

			if (isset($_REQUEST['issue_no'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = 1;
				$this->obj_gwis_master->tran_no = $issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if (isset($stockReceive) && !empty($stockReceive)) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}
			$this->obj_gwis_master->status_id = 1;
			$qry_vouchers = $this->obj_gwis_master->get_issue_vouchers();
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}
			//
			//                //chech if record exists
			//             $issueVoucher = '';
			//             $a='';
			//                if ($getStockIssues) {
			//
			//                    //fetch results
			//                    foreach ($getStockIssues AS $row)
			//                    {
			//                        $a= " <a href=\"new_receive_wh.php?issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
			//                        $issueVoucher[ $row['tran_no']] = $a;
			//                    }
			//
			//                }


			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_by_idsupplier();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();

			//            $stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			//            if ($stock_master_record)
			//                $data['stock_master_records'] = $stock_master_record->result_array();
			//            $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($stock_master_id);
			//            echo '<pre>';
			//            echo $stock_master_id;
			//            $a=array();
			//                foreach ($data['temp_records']->result_array() as $row) {
			//                    $a[]=$row;
			//                }
			//            print_r($a);
			//            echo '</pre>';
			//            exit;
			//            $data['master_id'] = $stock_master_id;
			$data['page_title'] = 'Physical Inspection Form';

			$data['main_content'] = $this->load->view('inventory_management/technical_inspection_form', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();
			$this->obj_gwis_master->status_id = 1;
			$qry_vouchers = $this->obj_gwis_master->get_issue_vouchers();
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}


			$stockReceive = '';
			if (isset($_REQUEST['issue_no'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = 1;
				$this->obj_gwis_master->tran_no = $issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if ($stockReceive) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}

			//            $qry_vouchers = $this->obj_gwis_master->get_issue_vouchers();
			//            $getStockIssues = $qry_vouchers->result_array();
			//
			//
			//                //chech if record exists
			//             $issueVoucher = '';
			//             $a='';
			//                if ($getStockIssues) {
			//
			//                    //fetch results
			//                    foreach ($getStockIssues AS $row)
			//                    {
			//                        $a= " <a href=\"new_receive_wh.php?issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
			//                        $issueVoucher[ $row['tran_no']] = $a;
			//                    }
			//
			//                }
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_by_idsupplier();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();
			//            $data['temp_records'] = $this->obj_gwis_master->get_temp_master_records(1);
			//            $master_id_arr = $this->obj_gwis_master->get_temp_master_records(1);
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['transaction_reference'];
				}
			}
			$data['page_title'] = 'Physical Inspection Form';
			$data['main_content'] = $this->load->view('inventory_management/technical_inspection_form', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function gwis_technical_inspection()
	{
		$masterloop = 1;
		if (!empty($_POST) && empty($_REQUEST['issue_no'])) {

			if (isset($_POST['pk_id'])) {
				$this->obj->pk_id = $_POST['pk_id'];
			}

			if (isset($_REQUEST['stockid']) && !empty($_REQUEST['stockid'])) {
				$masterstock_id = '';
				if (isset($_REQUEST['stock_id']) && !empty($_REQUEST['stock_id'])) {
					$masterstock_id = $_REQUEST['stock_id'];
				}

				// if (isset($_POST['pk_id'])) {
				// 	$this->obj->pk_id = $_POST['pk_id'];
				// }



				if (isset($_REQUEST['stockid']) && !empty($_REQUEST['stockid'])) {

					if (isset($_REQUEST['approve_or_rej']) && !empty($_REQUEST['approve_or_rej'])) {
						$electronic_approval = $_REQUEST['approve_or_rej'];
					}
					$uploadedFile = '';
					$masterloop = 1;
					$rvoucher = 1;



					//$dc_quantityy = $_REQUEST['dc_quantityy'];
					$actual_rec_qty = $_REQUEST['actual_rec_qty'];
					$pi_quantity = $_REQUEST['pi_quantity'];
					$missing = $_REQUEST['missing'];
					$comment = $_REQUEST['comment'];

					$dc_quantity = $_REQUEST['dc_quantity'];
					$ti_quantity = $_REQUEST['ti_quantity'];

					foreach ($_REQUEST['approvalcode'] as $indx => $detail_ida) {

						$approvefrom = $_REQUEST['approve_from'];
						$approveto = $_REQUEST['approve_to'];
						$processtatus = $_REQUEST['process_status'];
						$finalstatus = $_REQUEST['final_status'];

						$uploadedFile = '';
						$uploadDir = 'uploads/';
						if (!empty($_FILES["fileToUpload"]["name"])) {
							//                    $uploadedFile = 'test';
							// File path config 
							$fileName = basename($_FILES["fileToUpload"]["name"]);
							$targetFilePath = $uploadDir . $fileName;
							$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

							// Allow certain file formats 
							$allowTypes = array('pdf', 'doc', 'docx', 'jpg', 'png', 'jpeg');
							if (in_array($fileType, $allowTypes)) {
								// Upload file to the server 
								if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFilePath)) {
									$uploadedFile = $fileName;
								}
							}
						}

						if (!empty($uploadedFile)) {
							$fileto = $uploadedFile;
						} else if (isset($_REQUEST['file']) && !empty($_REQUEST['file'])) {
							$fileto = $this->input->post('file');
						}

						$masterstock_id = $this->obj_gwis_master->clone_record($masterstock_id, $approvefrom[$indx], $approveto[$indx], $processtatus[$indx], $finalstatus[$indx], $fileto, $_SESSION['id'], 2, 3);



						//        print_r($stock_ids);exit;
						foreach ($_REQUEST['stockid'] as $index => $detail_id) {


							if ($electronic_approval[$index] == '1') {

								$adj_type = 3;

								$this->obj_gwis_detail->update_batch_dtl_status($detail_id);
								$new_detail_id = $this->obj_gwis_detail->clone_record($detail_id, $masterstock_id, $missing[$index], $comment[$index], $adj_type);


								if ($processtatus[$indx] == '10') {
									//Start SMS Code
									//                        $this->sms($mobileno,$message);
									// End SMS Code
									// Start Email Code
									if ($_REQUEST['rejected_voucher'] == '2') {
										$stock_master_id_email = $_REQUEST['stkmasterid'];
									} else if (isset($_REQUEST['pkmasterid']) && !empty($_REQUEST['pkmasterid'])) {
										$stock_master_id_email = $_REQUEST['pkmasterid']; //
									} else {
										$stock_master_id_email = $masterstock_id;
									}
									$message = "New voucher no " . $_REQUEST['refernce_number'] . " created by " . $_SESSION['name'] . " Please Approve.";
									$this->email_printissue('muhammadsabir@ntp.gov.pk', $message, $stock_master_id_email);
									//End Email Code
								}

								//                $this->obj_gwis_master->status_id = '3';
								//                $this->obj_gwis_master->updategwisstatus('3',$_REQUEST['masterid']);
								//            }
							}
						}
					}
					// $this->obj_gwis_master->updatemasterpkid($_REQUEST['masterpkid']);
				}
			}














			if (!isset($_POST['stock_master_id'])) {
				//                $this->obj_gwis_master->tran_date = date('Y-m-d', strtotime($_POST['receiving_time']));
				//                $this->obj_gwis_master->status_id = $this->input->post('status_id');
				//                $this->obj_gwis_master->tran_ref = $this->input->post('refernce_number');
				//                $this->obj_gwis_master->wh_id_from = $this->input->post('receive_from');
				//                $this->obj_gwis_master->wh_id_from_supplier = $this->input->post('receive_from_supplier');
				//                $this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//                $this->obj_gwis_master->created_by = $_SESSION['id'];
				//                $this->obj_gwis_master->created_on = date("Y-m-d");
				//                $this->obj_gwis_master->user_from = 1;
				//                $this->obj_gwis_master->user_to = 1;
				//                $this->obj_gwis_master->temp = 1;
				//                $this->obj_gwis_master->mcc_year = $this->input->post('mcc_year');
				//                $this->obj_gwis_master->received_remarks = $this->input->post('remarks');
				//                $this->obj_gwis_master->issuance_to = 'centers';
				////                echo '<pre>';
				////            print_r($_REQUEST);
				////            print_r($this->obj_gwis_master);
				////            echo '</pre>';
				////            exit;
				//                $stock_master_id = $this->obj_gwis_master->save();
			} else {
				$stock_master_id = $_POST['stock_master_id'];
			}
			//            $this->obj_stock_batch->batch_no = $this->input->post('batch_number');
			//            $this->obj_stock_batch->batch_expiry = date('Y-m-d', strtotime($_POST['expiry_date']));
			//            $this->obj_stock_batch->production_date = date('Y-m-d', strtotime($_POST['manufacturing_date']));
			//            $this->obj_stock_batch->item_id = $this->input->post('product');
			//            $this->obj_stock_batch->wh_id = $this->session->userdata('warehouse_id');
			//            $this->obj_stock_batch->Qty = $this->input->post('quantity');
			//            $this->obj_stock_batch->funding_source = $this->input->post('receive_from');
			////            $this->obj_stock_batch->phy_inspection = $this->input->post('physical_inspection');
			////            $this->obj_stock_batch->dtl = $this->input->post('dtl');
			//            $stock_batch_id = $this->obj_stock_batch->save();
			//
			//
			//            $this->obj_gwis_detail->fk_stock_id = $stock_master_id;              //check id name
			//            $this->obj_gwis_detail->batch_id = $stock_batch_id;
			//            $this->obj_gwis_detail->dc_quantity = $_POST['quantity'];
			//            $this->obj_gwis_detail->temp = 1;
			//            $this->obj_gwis_detail->save();
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$code_arr = $this->obj_gwis_master->get_assign_approvalcode(2);
			if ($code_arr) {
				$data['approval_code'] = $code_arr->result_array();
				$approvalcodes = $code_arr->result_array();
			}
			$process_status_ids = array();
			if ($approvalcodes) {
				foreach ($approvalcodes as $row) {
					$approver_designation = preg_split("/\,/", $row['approver_designation']);
					$approver_desg_id = preg_split("/\,/", $row['approver_desg_id']);
					$process_statuss = preg_split("/\,/", $row['process_status']);
					$approval_codess = preg_split("/\,/", $row['approval_code']);
					for ($i = 0; $i < count($approval_codess); $i++) {
						$process_status_ids[] = $process_statuss[$i] - 1;
					}
					$process_status_nmbr = implode(",", $process_status_ids);
				}
			}

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();
			if (in_array("69", $approver_desg_id)) {
				//                        $this->obj_gwis_master->process_status = $process_status_nmbr.','.$process_status_nmbrr;
				$dtlschk = "";
			} else {
				//                        $this->obj_gwis_master->process_status = $process_status_nmbr;
				$dtlschk = "AND stock_batch.dtl_status = 'completed'";
			}

			if (isset($_REQUEST['issue_no'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = '1,2';
				$this->obj_gwis_master->tran_no = $issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No

				$stockReceive = $this->obj_gwis_master->GetTacWHStockByIssueNo($dtlschk);
				//                }
			}

			if (isset($_REQUEST['rej_issue_no'])) {
				$data['rej_issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['rej_issue_no']) && !empty($_REQUEST['rej_issue_no'])) {
					//get issue number
					$rej_issue_no = $_REQUEST['rej_issue_no'];
					$data['issue_no'] = $_REQUEST['rej_issue_no'];
					$rejected_real_masterids = $this->obj_gwis_master->rejected_real_masterid($_REQUEST['rej_issue_no']);
					$data['rejected_real_masterid'] = $rejected_real_masterids->result_array();
				}
				//set issue number
				$this->obj_gwis_master->status_id = 2;
				$this->obj_gwis_master->tran_no = $rej_issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByRejIssueNo();
				//                }
			}

			if (isset($_REQUEST['dtl_issue_no'])) {
				$data['dtl_issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['dtl_issue_no']) && !empty($_REQUEST['dtl_issue_no'])) {
					//get issue number
					$rej_issue_no = $_REQUEST['dtl_issue_no'];
					$data['issue_no'] = $_REQUEST['dtl_issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = 2;
				$this->obj_gwis_master->tran_no = $rej_issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByDtlIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if (isset($stockReceive) && !empty($stockReceive)) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}


			//            $process_status_nmbr = '';
			$process_status_nmbrr = '';
			//            $qry_getprocess_status = $this->obj_gwis_master->getprocess_status(2);
			//            if($qry_getprocess_status)
			//            {
			//                $dataprocessstatus = $qry_getprocess_status->result_array();
			//            }
			//            foreach ($dataprocessstatus AS $row)
			//            {
			//                $process_status_nmbr = $row['process_status'];  
			//            }

			$qry_getprocess_statuss = $this->obj_gwis_master->getprocess_statusmax(1);
			if ($qry_getprocess_statuss) {
				$dataprocessstatuss = $qry_getprocess_statuss->result_array();
			}
			foreach ($dataprocessstatuss as $row) {
				$process_status_nmbrr = $row['process_status'];
			}
			$dtlchk = '';
			$this->obj_gwis_master->status_id = '1,2';
			if (in_array("69", $approver_desg_id)) {
				$this->obj_gwis_master->process_status = $process_status_nmbr . ',' . $process_status_nmbrr;
				//                $dtlchk = "AND stock_batch.dtl_status = 'completed'";
			} else {
				$this->obj_gwis_master->process_status = $process_status_nmbr;
				$dtlchk = "";
			}

			$qry_vouchers = $this->obj_gwis_master->get_tac_issue_vouchers($dtlchk);
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}

			$process_status_dtlnmbr = '';
			$qry_getprocess_dtlstatus = $this->obj_gwis_master->get_dtl_process_status(2);
			if ($qry_getprocess_dtlstatus) {
				$dataprocessdtlstatus = $qry_getprocess_dtlstatus->result_array();
			}
			foreach ($dataprocessdtlstatus as $row) {
				$process_status_dtlnmbr = $row['process_status'];
			}

			$qry_dtl_vouchers = $this->obj_gwis_master->get_dtlafter_vouchers($process_status_dtlnmbr);
			if ($qry_dtl_vouchers) {
				$data['getDtlVoucher'] = $qry_dtl_vouchers->result_array();
			} else {
				$data['getDtlVoucher'] = '';
			}


			$rejqry_getprocess_status = $this->obj_gwis_master->getprocess_status(2);
			if ($rejqry_getprocess_status) {
				$rejdataprocessstatus = $rejqry_getprocess_status->result_array();
			}
			foreach ($rejdataprocessstatus as $row) {
				$rejprocess_status_nmbr = $row['process_status'];
			}

			$this->obj_gwis_master->status_id = '2';
			$this->obj_gwis_master->process_status = $rejprocess_status_nmbr;
			$qry_rej_vouchers = $this->obj_gwis_master->get_rejected_vouchers();
			if ($qry_rej_vouchers) {
				$data['getRejectedVoucher'] = $qry_rej_vouchers->result_array();
			} else {
				$data['getRejectedVoucher'] = '';
			}
			//
			//                //chech if record exists
			//             $issueVoucher = '';
			//             $a='';
			//                if ($getStockIssues) {
			//
			//                    //fetch results
			//                    foreach ($getStockIssues AS $row)
			//                    {
			//                        $a= " <a href=\"new_receive_wh.php?issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
			//                        $issueVoucher[ $row['tran_no']] = $a;
			//                    }
			//
			//                }


			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_by_idsupplier();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();

			//            $stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			//            if ($stock_master_record)
			//                $data['stock_master_records'] = $stock_master_record->result_array();
			//            $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($stock_master_id);
			//            echo '<pre>';
			//            echo $stock_master_id;
			//            $a=array();
			//                foreach ($data['temp_records']->result_array() as $row) {
			//                    $a[]=$row;
			//                }
			//            print_r($a);
			//            echo '</pre>';
			//            exit;
			//            $data['master_id'] = $stock_master_id;
			$data['page_title'] = 'GWIS – TAC';

			$data['main_content'] = $this->load->view('inventory_management/gwis_technical_inspection', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();

			$code_arr = $this->obj_gwis_master->get_assign_approvalcode(2);
			if ($code_arr) {
				$data['approval_code'] = $code_arr->result_array();
				$approvalcodes = $code_arr->result_array();
			}
			$process_status_ids = array();
			if ($approvalcodes) {
				foreach ($approvalcodes as $row) {
					$approver_designation = preg_split("/\,/", $row['approver_designation']);
					$approver_desg_id = preg_split("/\,/", $row['approver_desg_id']);
					$process_statuss = preg_split("/\,/", $row['process_status']);
					$approval_codess = preg_split("/\,/", $row['approval_code']);
					for ($i = 0; $i < count($approval_codess); $i++) {
						$process_status_ids[] = $process_statuss[$i] - 1;
					}
					$process_status_nmbr = implode(",", $process_status_ids);
				}
			}

			//            $process_status_nmbr = '';
			$process_status_nmbrr = '';
			//            $qry_getprocess_status = $this->obj_gwis_master->getprocess_status(2);
			//            if($qry_getprocess_status)
			//            {
			//                $dataprocessstatus = $qry_getprocess_status->result_array();
			//            }
			//            foreach ($dataprocessstatus AS $row)
			//            {
			//                $process_status_nmbr = $row['process_status'];  
			//            }

			$qry_getprocess_statuss = $this->obj_gwis_master->getprocess_statusmax(1);
			if ($qry_getprocess_statuss) {
				$dataprocessstatuss = $qry_getprocess_statuss->result_array();
			}
			foreach ($dataprocessstatuss as $row) {
				$process_status_nmbrr = $row['process_status'];
			}

			$dtlchk = '';
			$this->obj_gwis_master->status_id = '1,2';
			if (in_array("69", $approver_desg_id)) {
				$this->obj_gwis_master->process_status = $process_status_nmbr . ',' . $process_status_nmbrr;
				//                $dtlchk = "AND stock_batch.dtl_status = 'completed'";
			} else {
				$this->obj_gwis_master->process_status = $process_status_nmbr;
				$dtlchk = "";
			}
			$qry_vouchers = $this->obj_gwis_master->get_tac_issue_vouchers($dtlchk);
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}



			$process_status_dtlnmbr = '';
			$qry_getprocess_dtlstatus = $this->obj_gwis_master->get_dtl_process_status(2);
			if ($qry_getprocess_dtlstatus) {
				$dataprocessdtlstatus = $qry_getprocess_dtlstatus->result_array();
			}
			foreach ($dataprocessdtlstatus as $row) {
				$process_status_dtlnmbr = $row['process_status'];
			}

			$qry_dtl_vouchers = $this->obj_gwis_master->get_dtlafter_vouchers($process_status_dtlnmbr);
			if ($qry_dtl_vouchers) {
				$data['getDtlVoucher'] = $qry_dtl_vouchers->result_array();
			} else {
				$data['getDtlVoucher'] = '';
			}


			$rejqry_getprocess_status = $this->obj_gwis_master->getprocess_status(2);
			if ($rejqry_getprocess_status) {
				$rejdataprocessstatus = $rejqry_getprocess_status->result_array();
			}
			foreach ($rejdataprocessstatus as $row) {
				$rejprocess_status_nmbr = $row['process_status'];
			}

			$this->obj_gwis_master->status_id = '2';
			$this->obj_gwis_master->process_status = $rejprocess_status_nmbr;
			$qry_rej_vouchers = $this->obj_gwis_master->get_rejected_vouchers();
			if ($qry_rej_vouchers) {
				$data['getRejectedVoucher'] = $qry_rej_vouchers->result_array();
			} else {
				$data['getRejectedVoucher'] = '';
			}

			if (in_array("69", $approver_desg_id)) {
				//                        $this->obj_gwis_master->process_status = $process_status_nmbr.','.$process_status_nmbrr;
				$dtlschk = "";
			} else {
				//                        $this->obj_gwis_master->process_status = $process_status_nmbr;
				$dtlschk = "AND stock_batch.dtl_status = 'completed'";
			}

			$stockReceive = '';

			if ($this->input->get("tranno")) {
				$data['tranno'] = $this->input->get("tranno");
				$data['whidto'] = $this->input->get("whidto");
				//                $res = $this->obj_gwis_detail->GetBatchDetail($this->input->get("pkdetailid"),$this->input->get("batchid"));
				//            $row = $res->row();
				//                if ($res)
				//                {
				//                    $data['gwis_data'] = $res->result_array();
				//                }
				//                $data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				$issue_no = $this->input->get("tranno");
				$data['issue_no'] = $issue_no;
				//set issue number
				$this->obj_gwis_master->status_id = 2;
				$this->obj_gwis_master->tran_no = $this->input->get("tranno");
				$this->obj_gwis_master->wh_id_to = $this->input->get("whidto");
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetTacWHStockByIssueNo($dtlschk);
				//                }
			}

			if (isset($_REQUEST['issue_no']) && empty($_REQUEST['tranno'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = '1,2';
				$this->obj_gwis_master->tran_no = $issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetTacWHStockByIssueNo($dtlschk);
				//                }
			}

			if (isset($_REQUEST['rej_issue_no'])) {
				$data['rej_issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['rej_issue_no']) && !empty($_REQUEST['rej_issue_no'])) {
					//get issue number
					$rej_issue_no = $_REQUEST['rej_issue_no'];
					$data['issue_no'] = $_REQUEST['rej_issue_no'];
					$rejected_real_masterids = $this->obj_gwis_master->rejected_real_masterid($_REQUEST['rej_issue_no']);
					$data['rejected_real_masterid'] = $rejected_real_masterids->result_array();
				}
				//set issue number
				$this->obj_gwis_master->status_id = 2;
				$this->obj_gwis_master->tran_no = $rej_issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByRejIssueNo();
				//                }
			}

			if (isset($_REQUEST['dtl_issue_no'])) {
				$data['dtl_issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['dtl_issue_no']) && !empty($_REQUEST['dtl_issue_no'])) {
					//get issue number
					$rej_issue_no = $_REQUEST['dtl_issue_no'];
					$data['issue_no'] = $_REQUEST['dtl_issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = 2;
				$this->obj_gwis_master->tran_no = $rej_issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByDtlIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if ($stockReceive) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}

			//            $qry_vouchers = $this->obj_gwis_master->get_issue_vouchers();
			//            $getStockIssues = $qry_vouchers->result_array();
			//
			//
			//                //chech if record exists
			//             $issueVoucher = '';
			//             $a='';
			//                if ($getStockIssues) {
			//
			//                    //fetch results
			//                    foreach ($getStockIssues AS $row)
			//                    {
			//                        $a= " <a href=\"new_receive_wh.php?issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
			//                        $issueVoucher[ $row['tran_no']] = $a;
			//                    }
			//
			//                }
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_by_idsupplier();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();
			//            $data['temp_records'] = $this->obj_gwis_master->get_temp_master_records(1);
			//            $master_id_arr = $this->obj_gwis_master->get_temp_master_records(1);
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['transaction_reference'];
				}
			}
			$data['page_title'] = 'GWIS – TAC';
			$data['main_content'] = $this->load->view('inventory_management/gwis_technical_inspection', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function dtl_process()
	{
		$masterloop = 1;
		if (!empty($_POST) && empty($_REQUEST['issue_no'])) {

			if (isset($_POST['pk_id'])) {
				$this->obj->pk_id = $_POST['pk_id'];
			}











			//check stock id
			if (isset($_REQUEST['stock_id']) && !empty($_REQUEST['stock_id'])) {
				//get stock id
				$stock_id = $_REQUEST['stock_id'];

				$type_id = 1;
				//find by stock id
				//        $stockDetail = $objStockDetail->find_by_stock_id($stock_id);
				//check remarks
				if (isset($_REQUEST['remarks']) && !empty($_REQUEST['remarks'])) {
					//get remarks
					$remarks = $_REQUEST['remarks'];
				} else {
					$remarks = "";
				}
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
				}
				if (isset($_REQUEST['count']) && !empty($_REQUEST['count'])) {
					$count_o = $_REQUEST['count'];
				}
				//check receive date 
				if (isset($_REQUEST['rec_date']) && !empty($_REQUEST['rec_date'])) {
					//get receive date
					$rec_date = $_REQUEST['rec_date'];
				}
				//check receive reference
				if (isset($_REQUEST['rec_ref']) && !empty($_REQUEST['rec_ref'])) {
					//get receive reference
					$rec_ref = $_REQUEST['rec_ref'];
				}
				//check vvm
				if (isset($_REQUEST['vvmstage']) && !empty($_REQUEST['vvmstage'])) {
					//get vvm
					$vvmstage = $_REQUEST['vvmstage'];
				}
				//check cold chain
				if (isset($_REQUEST['cold_chain']) && !empty($_REQUEST['cold_chain'])) {
					//get cold chain
					$cold_chain = $_REQUEST['cold_chain'];
				}
			}
			//            
			//            
			//            
			//            
			//            
			//            
			//            
			if (isset($_REQUEST['stockid']) && !empty($_REQUEST['stockid'])) {

				if (in_array(3, $_REQUEST['dtl_result']) || in_array(4, $_REQUEST['dtl_result'])) {
					$approvefrom = $_REQUEST['approve_from'];
					$approveto = $_REQUEST['approve_to'];
					$processtatus = $_REQUEST['process_status'];
					$finalstatus = $_REQUEST['final_status'];
					//               $electronic_approval = $_REQUEST['approve_or_rej'];
					//get stock id
					$stock_ids = $_REQUEST['stockid'];
					$count = count($stock_ids);

					foreach ($stock_ids as $index => $detail_id) {
						if (isset($_REQUEST['itm_id']) && !empty($_REQUEST['itm_id'])) {
							//get cold chain
							$itmid = $_REQUEST['itm_id'];
							//                    $item_id = $itmid[$index];
							$item_id = '1';
						}
					}


					//        print_r($stock_ids);exit;
					//        $masterloop=1;
					//        foreach ($_REQUEST['approvalcode'] as $indx => $detail_ida) {



					foreach ($stock_ids as $index => $detail_id) {

						$rejectno = 1;


						//            if($electronic_approval[$index] == '1')
						//            {
						//Stock Received
						//            $this->obj_gwis_detail->StockReceived($detail_id);
						//Get Batch Detail

						$dtlbatch_id = $_POST['dtlbatch_id'];

						//            $dtl = $_POST['dtl'];
						$missing = $_REQUEST['missing'];

						$dtl_result = $_POST['dtl_result'];
						$dtl_comment = $_POST['dtl_comment'];
						$dtl_remarks = $_POST['dtl_remarks'];
						$dtl_received_date = $_POST['dtl_received_date'];
						$uprice = $_REQUEST['unit_price'];
						$currency = $_REQUEST['currency'];
						$conversion_rate = $_POST['conversion_rate'];

						$delivery_challan_type = $_POST['delivery_challan_type'];
						$challan_type_detail = $_POST['challan_type_detail'];
						$driver_name = $_POST['driver_name'];
						$driver_contract = $_POST['driver_contract'];
						$vehicle_reg = $_POST['vehicle_reg'];
						$dc_no = $_POST['dc_no'];
						$dc_date = $_POST['dc_date'];
						$invoice = $_POST['invoice'];

						//Stock Detail
						$field1 = $_POST['field1'];
						$field2 = $_POST['field2'];
						$field3 = $_POST['field3'];
						$field4 = $_POST['field4'];
						$field5 = $_POST['field5'];
						$field6 = $_POST['field6'];
						$field7 = $_POST['field7'];
						$field8 = $_POST['field8'];
						$field9 = $_POST['field9'];
						$field10 = $_POST['field10'];

						$stockBatch = $this->obj_stock_batch->GetBatchDetail($detail_id);
						if ($stockBatch) {
							$stockBatch1 = $stockBatch->result_array();
						}
						if (isset($stockBatch1)) {
							$row = $stockBatch1[0];
							$Qty = $row['quantity'];
							$item_id = $row['item_id'];
							$batch_no = $row['batch_no'];
							$batch_expiry = $row['batch_expiry'];
							$funding_source = $row['funding_source'];
							$manufacturer = $row['manufacturer'];
							$unit_price = $row['unit_price'];
							$production_date = $row['production_date'];
						}

						//get missing
						//            $array_missing = $_REQUEST['missing'];
						//            if (isset($array_missing[$index]) && !empty($array_missing[$index])) {
						//quantity
						$quantity = str_replace("-", "", $Qty);
						//product id
						$product_id = $item_id;

						//            $this->obj_stock_batch->fk_stock_id = $stock_ids[$index];
						//batch number
						if (isset($dtlbatch_id[$index]) && !empty($dtlbatch_id[$index])) {
							$this->obj_stock_batch->batch_id = $dtlbatch_id[$index];
						}
						$this->obj_stock_batch->batch_no = $batch_no;
						//batch expiry
						$this->obj_stock_batch->batch_expiry = $batch_expiry;
						//            $this->obj_stock_batch->dtl = $dtl[$index];
						$this->obj_stock_batch->dtl_result = $dtl_result[$index];
						$this->obj_stock_batch->dtl_comment = $dtl_comment[$index];
						$this->obj_stock_batch->dtl_remarks = $dtl_remarks;
						//            $this->obj_stock_batch->dtl_received_date = date('Y-m-d', strtotime($dtl_received_date));
						date_default_timezone_set('Asia/Karachi');
						$receivedatetime = date('Y-m-d h:i:s', time());
						$this->obj_stock_batch->dtl_received_date = $receivedatetime;

						$this->obj_stock_batch->funding_source = $funding_source;
						$this->obj_stock_batch->manufacturer = $manufacturer;
						//quantity
						//            $this->obj_stock_batch->Qty = $quantity;
						$this->obj_stock_batch->Qty = $missing[$index];
						//item id
						$this->obj_stock_batch->item_id = $product_id;
						//status
						$this->obj_stock_batch->status = 'Stacked';
						//unit price
						$this->obj_stock_batch->unit_price = $uprice[$index];
						//unit currency
						$this->obj_stock_batch->currency = $currency[$index];
						//unit conversion_rate
						$this->obj_stock_batch->conversion_rate = $conversion_rate[$index];
						//production date
						$this->obj_stock_batch->production_date = $production_date;
						//warehouse id
						$this->obj_stock_batch->wh_id = $_SESSION['warehouse_id'];
						//save stock batch
						//            echo '<pre>';
						//            print_r($stockBatch);
						//            print_r($objStockBatch);
						//            exit;
						if (isset($dtlbatch_id[$index]) && !empty($dtlbatch_id[$index])) {
							$this->obj_stock_batch->batch_id = $dtlbatch_id[$index];
							$this->obj_stock_batch->save();
							$batch_id1 = $dtlbatch_id[$index];
						} else {
							$batch_id1 = $this->obj_stock_batch->save();
						}
					}

					//        }
					//            } // End foreach
					//            $this->obj_gwis_master->updatemasterpkid($_REQUEST['masterpkid']);
				}
			}














			if (!isset($_POST['stock_master_id'])) {
			} else {
				$stock_master_id = $_POST['stock_master_id'];
			}



			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();

			if (isset($_REQUEST['issue_no'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = 2;
				$this->obj_gwis_master->tran_no = $issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetDTLWHStockByIssueNo();
				//                }
			}

			if (isset($_REQUEST['rej_issue_no'])) {
				$data['rej_issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['rej_issue_no']) && !empty($_REQUEST['rej_issue_no'])) {
					//get issue number
					$rej_issue_no = $_REQUEST['rej_issue_no'];
					$data['issue_no'] = $_REQUEST['rej_issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = 2;
				$this->obj_gwis_master->tran_no = $rej_issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByRejIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if (isset($stockReceive) && !empty($stockReceive)) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}

			$process_status_nmbr = '';
			$qry_getprocess_status = $this->obj_gwis_master->get_dtl_process_status(2);
			if ($qry_getprocess_status) {
				$dataprocessstatus = $qry_getprocess_status->result_array();
			}
			foreach ($dataprocessstatus as $row) {
				$process_status_nmbr = $row['process_status'];
			}


			$this->obj_gwis_master->status_id = '2';
			$this->obj_gwis_master->process_status = $process_status_nmbr;

			$qry_vouchers = $this->obj_gwis_master->get_dtl_vouchers();
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}

			$qry_rej_vouchers = $this->obj_gwis_master->get_rejected_vouchers();
			if ($qry_rej_vouchers) {
				$data['getRejectedVoucher'] = $qry_rej_vouchers->result_array();
			} else {
				$data['getRejectedVoucher'] = '';
			}
			//
			//                //chech if record exists
			//             $issueVoucher = '';
			//             $a='';
			//                if ($getStockIssues) {
			//
			//                    //fetch results
			//                    foreach ($getStockIssues AS $row)
			//                    {
			//                        $a= " <a href=\"new_receive_wh.php?issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
			//                        $issueVoucher[ $row['tran_no']] = $a;
			//                    }
			//
			//                }
			$code_arr = $this->obj_gwis_master->get_assign_approvalcode(2);
			if ($code_arr)
				$data['approval_code'] = $code_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_by_idsupplier();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();

			//            $stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			//            if ($stock_master_record)
			//                $data['stock_master_records'] = $stock_master_record->result_array();
			//            $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($stock_master_id);
			//            echo '<pre>';
			//            echo $stock_master_id;
			//            $a=array();
			//                foreach ($data['temp_records']->result_array() as $row) {
			//                    $a[]=$row;
			//                }
			//            print_r($a);
			//            echo '</pre>';
			//            exit;
			//            $data['master_id'] = $stock_master_id;
			$data['page_title'] = 'DTL Process';

			$data['main_content'] = $this->load->view('inventory_management/dtl_process', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();

			$process_status_nmbr = '';
			$qry_getprocess_status = $this->obj_gwis_master->get_dtl_process_status(2);
			if ($qry_getprocess_status) {
				$dataprocessstatus = $qry_getprocess_status->result_array();
			}
			foreach ($dataprocessstatus as $row) {
				$process_status_nmbr = $row['process_status'];
			}


			$this->obj_gwis_master->status_id = '2';
			$this->obj_gwis_master->process_status = $process_status_nmbr;

			$qry_vouchers = $this->obj_gwis_master->get_dtl_vouchers();
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}

			$qry_rej_vouchers = $this->obj_gwis_master->get_rejected_vouchers();
			if ($qry_rej_vouchers) {
				$data['getRejectedVoucher'] = $qry_rej_vouchers->result_array();
			} else {
				$data['getRejectedVoucher'] = '';
			}

			$stockReceive = '';

			if ($this->input->get("tranno")) {
				$data['tranno'] = $this->input->get("tranno");
				$data['whidto'] = $this->input->get("whidto");
				//                $res = $this->obj_gwis_detail->GetBatchDetail($this->input->get("pkdetailid"),$this->input->get("batchid"));
				//            $row = $res->row();
				//                if ($res)
				//                {
				//                    $data['gwis_data'] = $res->result_array();
				//                }
				//                $data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				$issue_no = $this->input->get("tranno");
				$data['issue_no'] = $issue_no;
				//set issue number
				$this->obj_gwis_master->status_id = 2;
				$this->obj_gwis_master->tran_no = $this->input->get("tranno");
				$this->obj_gwis_master->wh_id_to = $this->input->get("whidto");
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetDTLWHStockByIssueNo();
				//                }
			}

			if (isset($_REQUEST['issue_no']) && empty($_REQUEST['tranno'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = 2;
				$this->obj_gwis_master->tran_no = $issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetDTLWHStockByIssueNo();
				//                }
			}

			if (isset($_REQUEST['rej_issue_no'])) {
				$data['rej_issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['rej_issue_no']) && !empty($_REQUEST['rej_issue_no'])) {
					//get issue number
					$rej_issue_no = $_REQUEST['rej_issue_no'];
					$data['issue_no'] = $_REQUEST['rej_issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = 2;
				$this->obj_gwis_master->tran_no = $rej_issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByRejIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if ($stockReceive) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}

			//            $qry_vouchers = $this->obj_gwis_master->get_issue_vouchers();
			//            $getStockIssues = $qry_vouchers->result_array();
			//
			//
			//                //chech if record exists
			//             $issueVoucher = '';
			//             $a='';
			//                if ($getStockIssues) {
			//
			//                    //fetch results
			//                    foreach ($getStockIssues AS $row)
			//                    {
			//                        $a= " <a href=\"new_receive_wh.php?issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
			//                        $issueVoucher[ $row['tran_no']] = $a;
			//                    }
			//
			//                }
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$code_arr = $this->obj_gwis_master->get_assign_approvalcode(2);
			if ($code_arr)
				$data['approval_code'] = $code_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_by_idsupplier();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();
			//            $data['temp_records'] = $this->obj_gwis_master->get_temp_master_records(1);
			//            $master_id_arr = $this->obj_gwis_master->get_temp_master_records(1);
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['transaction_reference'];
				}
			}
			$data['page_title'] = 'DTL Process';
			$data['main_content'] = $this->load->view('inventory_management/dtl_process', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function gwis_initiator_submit()
	{

		//echo "<pre>";
		//print_r($_POST);
		//exit;
		//exit("HEllo");
		if (!empty($_POST)) {

			if (isset($_POST['pk_id'])) {
				$this->obj->pk_id = $_POST['pk_id'];
			}

			if (isset($_REQUEST['stockid']) && !empty($_REQUEST['stockid'])) {
				$masterstock_id = '';
				if (isset($_REQUEST['stock_id']) && !empty($_REQUEST['stock_id'])) {
					$masterstock_id = $_REQUEST['stock_id'];
				}

				// if (isset($_POST['pk_id'])) {
				// 	$this->obj->pk_id = $_POST['pk_id'];
				// }



				if (isset($_REQUEST['stockid']) && !empty($_REQUEST['stockid'])) {

					if (isset($_REQUEST['approve_or_rej']) && !empty($_REQUEST['approve_or_rej'])) {
						$electronic_approval = $_REQUEST['approve_or_rej'];
					}
					$uploadedFile = '';
					$masterloop = 1;
					$rvoucher = 1;



					//$dc_quantityy = $_REQUEST['dc_quantityy'];
					$actual_rec_qty = $_REQUEST['actual_rec_qty'];
					$pi_quantity = $_REQUEST['pi_quantity'];
					//            $missing = $_REQUEST['missing'];
					$comment = $_REQUEST['comment'];

					$dc_quantity = $_REQUEST['dc_quantity'];
					$ti_quantity = $_REQUEST['ti_quantity'];

					foreach ($_REQUEST['approvalcode'] as $indx => $detail_ida) {

						$approvefrom = $_REQUEST['approve_from'];
						$approveto = $_REQUEST['approve_to'];
						$processtatus = $_REQUEST['process_status'];
						$finalstatus = $_REQUEST['final_status'];

						$uploadedFile = '';
						$uploadDir = 'uploads/';
						if (!empty($_FILES["fileToUpload"]["name"])) {
							//                    $uploadedFile = 'test';
							// File path config 
							$fileName = basename($_FILES["fileToUpload"]["name"]);
							$targetFilePath = $uploadDir . $fileName;
							$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

							// Allow certain file formats 
							$allowTypes = array('pdf', 'doc', 'docx', 'jpg', 'png', 'jpeg');
							if (in_array($fileType, $allowTypes)) {
								// Upload file to the server 
								if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFilePath)) {
									$uploadedFile = $fileName;
								}
							}
						}

						if (!empty($uploadedFile)) {
							$fileto = $uploadedFile;
						} else if (isset($_REQUEST['file']) && !empty($_REQUEST['file'])) {
							$fileto = $this->input->post('file');
						}

						$masterstock_id = $this->obj_gwis_master->clone_record($masterstock_id, $approvefrom[$indx], $approveto[$indx], $processtatus[$indx], $finalstatus[$indx], $fileto, $_SESSION['id'], 1, 3);



						//        print_r($stock_ids);exit;
						foreach ($_REQUEST['stockid'] as $index => $detail_id) {


							if ($electronic_approval[$index] == '1') {

								if ($processtatus[$indx] == 12) {
									$adj_type = 4;
								} else {
									$adj_type = 'gwis_detail.adjustment_type';
								}

								$new_detail_id = $this->obj_gwis_detail->clone_record($detail_id, $masterstock_id, $actual_rec_qty[$index], $comment[$index], $adj_type);


								if ($processtatus[$indx] == '10') {
									//Start SMS Code
									//                        $this->sms($mobileno,$message);
									// End SMS Code
									// Start Email Code
									if ($_REQUEST['rejected_voucher'] == '2') {
										$stock_master_id_email = $_REQUEST['stkmasterid'];
									} else if (isset($_REQUEST['pkmasterid']) && !empty($_REQUEST['pkmasterid'])) {
										$stock_master_id_email = $_REQUEST['pkmasterid']; //
									} else {
										$stock_master_id_email = $masterstock_id;
									}
									$message = "New voucher no " . $_REQUEST['refernce_number'] . " created by " . $_SESSION['name'] . " Please Approve.";
									$this->email_printissue('muhammadsabir@ntp.gov.pk', $message, $stock_master_id_email);
									//End Email Code
								}

								//                $this->obj_gwis_master->status_id = '3';
								//                $this->obj_gwis_master->updategwisstatus('3',$_REQUEST['masterid']);
								//            }
							}
						}
					}
					// $this->obj_gwis_master->updatemasterpkid($_REQUEST['masterpkid']);
				}
			}


			if (!isset($_POST['stock_master_id'])) {
			} else {
				$stock_master_id = $_POST['stock_master_id'];
			}

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();

			if (isset($_REQUEST['issue_no'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = 1;
				$this->obj_gwis_master->tran_no = $issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByIssueNo();
				//                }
			}

			if (isset($_REQUEST['rej_issue_no'])) {
				$data['rej_issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['rej_issue_no']) && !empty($_REQUEST['rej_issue_no'])) {
					//get issue number
					$rej_issue_no = $_REQUEST['rej_issue_no'];
					$data['issue_no'] = $_REQUEST['rej_issue_no'];
					$rejected_real_masterids = $this->obj_gwis_master->rejected_real_masterid($_REQUEST['rej_issue_no']);
					$data['rejected_real_masterid'] = $rejected_real_masterids->result_array();
				}
				//set issue number
				$this->obj_gwis_master->status_id = 1;
				$this->obj_gwis_master->tran_no = $rej_issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByRejIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if (isset($stockReceive) && !empty($stockReceive)) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}
			//            $process_status_nmbr = '';
			//            $qry_getprocess_status = $this->obj_gwis_master->getprocess_status(1);
			//            if($qry_getprocess_status)
			//            {
			//                $dataprocessstatus = $qry_getprocess_status->result_array();
			//            }
			//            foreach ($dataprocessstatus AS $row)
			//            {
			//                $process_status_nmbr = $row['process_status'];  
			//            }
			$code_arr = $this->obj_gwis_master->get_assign_approvalcode(1);
			if ($code_arr) {
				$data['approval_code'] = $code_arr->result_array();
				$approvalcodes = $code_arr->result_array();
			}
			$process_status_ids = array();
			if ($approvalcodes) {
				foreach ($approvalcodes as $row) {
					$process_statuss = preg_split("/\,/", $row['process_status']);
					$approval_codess = preg_split("/\,/", $row['approval_code']);
					$approver_desg_id = preg_split("/\,/", $row['approver_desg_id']);
					for ($i = 0; $i < count($approval_codess); $i++) {

						if ($process_statuss[0] != '1') {
							$approvefrom = '!=';
						}
						if ($process_statuss[0] == '1') {
							$approvefrom = '=';
						}

						if ($process_statuss[$i] == '1') {
							$process_status_ids[] = $process_statuss[$i];
							//                                          print_r($process_status_ids);exit;
						} else {
							$process_status_ids[] .= $process_statuss[$i] - 1;
						}
					}
					$process_status_nmbr = implode(",", $process_status_ids);
				}
			}

			$this->obj_gwis_master->status_id = 1;

			$this->obj_gwis_master->process_status = $process_status_nmbr;

			if (in_array("69", $approver_desg_id)) {
				$this->obj_gwis_master->parent_id = '0';
			}

			$qry_vouchers = $this->obj_gwis_master->getgwis_issue_vouchers($approvefrom);
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}


			$rejqry_getprocess_status = $this->obj_gwis_master->getprocess_status(1);
			if ($rejqry_getprocess_status) {
				$rejdataprocessstatus = $rejqry_getprocess_status->result_array();
			}
			foreach ($rejdataprocessstatus as $row) {
				$rejprocess_status_nmbr = $row['process_status'];
			}

			$this->obj_gwis_master->status_id = '1';
			$this->obj_gwis_master->process_status = $rejprocess_status_nmbr;
			if (in_array("69", $approver_desg_id)) {
				$this->obj_gwis_master->parent_id = '0';
			}

			$qry_rej_vouchers = $this->obj_gwis_master->get_rejected_vouchers();
			if ($qry_rej_vouchers) {
				$data['getRejectedVoucher'] = $qry_rej_vouchers->result_array();
			} else {
				$data['getRejectedVoucher'] = '';
			}

			//
			//                //chech if record exists
			//             $issueVoucher = '';
			//             $a='';
			//                if ($getStockIssues) {
			//
			//                    //fetch results
			//                    foreach ($getStockIssues AS $row)
			//                    {
			//                        $a= " <a href=\"new_receive_wh.php?issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
			//                        $issueVoucher[ $row['tran_no']] = $a;
			//                    }
			//
			//                }
			$po_no_cmu_arr = $this->obj_po_infos->find_all_po_cmu();
			if ($po_no_cmu_arr)
				$data['po_no_cmu_arr'] = $po_no_cmu_arr->result_array();

			$po_no_gf_arr = $this->obj_po_infos->find_all_po_gf();
			if ($po_no_gf_arr)
				$data['po_no_gf_arr'] = $po_no_gf_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$warehouse_arr = $this->obj_stakeholder->find_warehouseinfo();
			if ($warehouse_arr)
				$data['warehouses'] = $warehouse_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();

			//            $stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			//            if ($stock_master_record)
			//                $data['stock_master_records'] = $stock_master_record->result_array();
			//            $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($stock_master_id);
			//            echo '<pre>';
			//            echo $stock_master_id;
			//            $a=array();
			//                foreach ($data['temp_records']->result_array() as $row) {
			//                    $a[]=$row;
			//                }
			//            print_r($a);
			//            echo '</pre>';
			//            exit;
			//            $data['master_id'] = $stock_master_id;
			$data['page_title'] = 'GIWS – TAC';

			$data['main_content'] = $this->load->view('inventory_management/gwis_initiator', $data, TRUE);
			$this->load->view('layout/main', $data);

			//end of ( submit action )
		}

		redirect('inventory_management/gwis_initiator');
	} //// end gwis_initiator_submit(

	public function gwis_initiator()
	{
		$data = array();
		$code_arr = $this->obj_gwis_master->get_assign_approvalcode(1);
		if ($code_arr) {
			$data['approval_code'] = $code_arr->result_array();
			$approvalcodes = $code_arr->result_array();
		}
		$process_status_ids = array();
		if ($approvalcodes) {
			foreach ($approvalcodes as $row) {
				$process_statuss = preg_split("/\,/", $row['process_status']);
				$approval_codess = preg_split("/\,/", $row['approval_code']);
				$approver_desg_id = preg_split("/\,/", $row['approver_desg_id']);
				for ($i = 0; $i < count($approval_codess); $i++) {

					if ($process_statuss[0] != '1') {
						$approvefrom = '!=';
					}
					if ($process_statuss[0] == '1') {
						$approvefrom = '=';
					}

					if ($process_statuss[$i] == '1') {
						$process_status_ids[] = $process_statuss[$i];
						//                                          print_r($process_status_ids);exit;
					} else {
						$process_status_ids[] .= $process_statuss[$i] - 1;
					}
				}
				$process_status_nmbr = implode(",", $process_status_ids);
			}
		}

		$this->obj_gwis_master->status_id = 1;
		$this->obj_gwis_master->process_status = $process_status_nmbr;
		if (in_array("69", $approver_desg_id)) {
			$this->obj_gwis_master->parent_id = '0';
		}

		$qry_vouchers = $this->obj_gwis_master->getgwis_issue_vouchers($approvefrom);
		if ($qry_vouchers) {
			$data['getStockIssues'] = $qry_vouchers->result_array();
		} else {
			$data['getStockIssues'] = '';
		}

		$rejqry_getprocess_status = $this->obj_gwis_master->getprocess_status(1);
		if ($rejqry_getprocess_status) {
			$rejdataprocessstatus = $rejqry_getprocess_status->result_array();
		}
		foreach ($rejdataprocessstatus as $row) {
			$rejprocess_status_nmbr = $row['process_status'];
		}

		$this->obj_gwis_master->status_id = '1';
		$this->obj_gwis_master->process_status = $rejprocess_status_nmbr;
		if (in_array("69", $approver_desg_id)) {
			$this->obj_gwis_master->parent_id = '0';
		}

		$qry_rej_vouchers = $this->obj_gwis_master->get_rejected_vouchers();
		if ($qry_rej_vouchers) {
			$data['getRejectedVoucher'] = $qry_rej_vouchers->result_array();
		} else {
			$data['getRejectedVoucher'] = '';
		}

		$stockReceive = '';

		if ($this->input->get("tranno")) {
			$data['tranno'] = $this->input->get("tranno");
			$data['whidto'] = $this->input->get("whidto");
			$issue_no = $this->input->get("tranno");
			$data['issue_no'] = $issue_no;
			$this->obj_gwis_master->status_id = 2;
			$this->obj_gwis_master->tran_no = $this->input->get("tranno");
			$this->obj_gwis_master->wh_id_to = $this->input->get("whidto");
			$stockReceive = $this->obj_gwis_master->GetWHStockByIssueNo();
		}
		if (isset($_REQUEST['issue_no']) && empty($_REQUEST['tranno'])) {
			$data['issue_no'] = '';
			if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
				$issue_no = $_REQUEST['issue_no'];
				$data['issue_no'] = $_REQUEST['issue_no'];
			}
			$this->obj_gwis_master->status_id = 1;
			$this->obj_gwis_master->tran_no = $issue_no;
			$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
			$stockReceive = $this->obj_gwis_master->GetWHStockByIssueNo();
		}

		if (isset($_REQUEST['rej_issue_no'])) {
			$data['rej_issue_no'] = '';
			if (isset($_REQUEST['rej_issue_no']) && !empty($_REQUEST['rej_issue_no'])) {
				$rej_issue_no = $_REQUEST['rej_issue_no'];
				$data['issue_no'] = $_REQUEST['rej_issue_no'];
				$rejected_real_masterids = $this->obj_gwis_master->rejected_real_masterid($_REQUEST['rej_issue_no']);
				$data['rejected_real_masterid'] = $rejected_real_masterids->result_array();
			}
			$this->obj_gwis_master->status_id = 1;
			$this->obj_gwis_master->tran_no = $rej_issue_no;
			$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
			//Get WH Stock By Issue No
			$stockReceive = $this->obj_gwis_master->GetWHStockByRejIssueNo();
		}

		$count = 0;
		if ($stockReceive) {
			$data['stockReceive'] = $stockReceive->result_array();
		}

		$po_no_cmu_arr = $this->obj_po_infos->find_all_po_cmu();
		if ($po_no_cmu_arr)
			$data['po_no_cmu_arr'] = $po_no_cmu_arr->result_array();

		$po_no_gf_arr = $this->obj_po_infos->find_all_po_gf();
		if ($po_no_gf_arr)
			$data['po_no_gf_arr'] = $po_no_gf_arr->result_array();

		$product_arr = $this->obj_itminfo->find_all_products();
		if ($product_arr)
			$data['product'] = $product_arr->result_array();

		$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
		if ($funding_source_arr)
			$data['funding_source'] = $funding_source_arr->result_array();

		$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		if ($suppliers_arr)
			$data['suppliers'] = $suppliers_arr->result_array();

		$warehouse_arr = $this->obj_stakeholder->find_warehouseinfo();
		if ($warehouse_arr)
			$data['warehouses'] = $warehouse_arr->result_array();

		$doc_type_arr = $this->obj_document_type->find_active();
		if ($doc_type_arr)
			$data['document_type'] = $doc_type_arr->result_array();

		if (!empty($master_id_arr)) {
			if ($master_id_arr)
				$master_result = $master_id_arr->result_array();
			foreach ($master_result as $row) {
				$data['master_id'] = $row['stock_master_id'];
				$data['tran_reference_number'] = $row['transaction_reference'];
			}
		}

		$data['page_title'] = 'GIWS – Initiator';
		$data['main_content'] = $this->load->view('inventory_management/gwis_initiator', $data, TRUE);
		$this->load->view('layout/main', $data);
	} //// end gwis_initiator(



	public function stock_issue()
	{
		////////////// This function of stock issue , is to be only used for CMU. 
		////////////// For other users/depts use the im_new/stock_issue function

		if (!empty($_POST)) {
			//echo '<pre>';print_r($_POST);exit;
			if (isset($_POST['pk_id'])) {
				$this->obj->pk_id = $_POST['pk_id'];
			}
			if (!isset($_POST['stock_master_id'])) {

				$current_year = date("Y");
				//current month
				$current_month = date("m");
				if ($current_month < 7) {
					//from date
					$from_date = ($current_year - 1) . "-06-30";
					//to date
					$to_date = $current_year . "-07-30";
				} else {
					//from date
					$from_date = $current_year . "-06-30";
					//to date
					$to_date = ($current_year + 1) . "-07-30";
				}

				$last_id = $this->obj_gwis_master->getLastID($from_date, $to_date, 4);

				if (!empty($last_id)) {
					if ($last_id)
						$last_idd = $last_id->result_array();
					foreach ($last_idd as $row) {
						$lastid = $row['Maxtr'];
					}
				}

				if ($lastid == NULL) {
					$lastid = 0;
				}

				$prefix = '';
				$itmname = '';
				if (isset($_REQUEST['tran_no']) && !empty($_REQUEST['tran_no'])) {
					$itmname = $_REQUEST['tran_no'];
				}
				if (isset($itmname) && !empty($itmname)) {
					$charc = substr($itmname, 0, 1);
					if ($charc == 'A') {
						$prefix = $charc;
					} else if ($charc == 'M') {
						$prefix = $charc;
					} else if ($charc == 'TB') {
						$prefix = $charc;
					} else {
						$prefix = '';
					}
				}

				$trans_no = "SIV" . date('ym') . str_pad(($lastid + 1), 4, "0", STR_PAD_LEFT);
				$data['message'] = 'Voucher no is ' . $trans_no;
				$this->obj_gwis_master->tran_no = $trans_no;
				$this->obj_gwis_master->tr_no = ($lastid + 1);

				$this->obj_gwis_master->tran_date = date('Y-m-d', strtotime($_POST['receiving_time']));
				//                $this->obj_gwis_master->tran_type_id = 2;
				$this->obj_gwis_master->status_id = 4;
				$this->obj_gwis_master->tran_ref = $_POST['refernce_number'];

				if (isset($_POST['batch'])) {
					$this->obj_gwis_master->wh_id_from = $_POST['wh_id_from'];
					$this->obj_gwis_master->wh_id_from_supplier = $_POST['wh_id_from_supplier'];

					$this->obj_gwis_master->stk_id = $_REQUEST['stk_id'];

					$this->obj_gwis_master->inspection_date = date('Y-m-d', strtotime($_REQUEST['inspection_date']));
					$this->obj_gwis_master->delivery_location = $_REQUEST['delivery_location'];
					$this->obj_gwis_master->po_cmu_no = $_REQUEST['po_cmu_no'];
					$this->obj_gwis_master->po_cmu_date = $_REQUEST['po_cmu_date'];
					$this->obj_gwis_master->po_gf_no = $_REQUEST['po_gf_no'];
					$this->obj_gwis_master->po_gf_date = $_REQUEST['po_gf_date'];
					$this->obj_gwis_master->date_of_receiving = date('Y-m-d', strtotime($_REQUEST['date_of_receiving']));
					$this->obj_gwis_master->air_bill_no = $_REQUEST['air_bill_no'];
					$this->obj_gwis_master->shipment_no = $_REQUEST['shipment_no'];
					$this->obj_gwis_master->origin_of_country = $_REQUEST['origin_of_country'];
					$this->obj_gwis_master->vehicle_type_and_plate = $_REQUEST['vehicle_type_and_plate'];
					$this->obj_gwis_master->consignment_weight = $_REQUEST['consignment_weight'];
				} else if (isset($_REQUEST['produstbatchid'])) {
					$this->obj_gwis_master->wh_id_from = $_POST['p_wh_id_from'];
					$this->obj_gwis_master->wh_id_from_supplier = $_POST['p_wh_id_from_supplier'];

					$this->obj_gwis_master->stk_id = $_REQUEST['p_stk_id'];

					$this->obj_gwis_master->inspection_date = date('Y-m-d', strtotime($_REQUEST['p_inspection_date']));
					$this->obj_gwis_master->delivery_location = $_REQUEST['p_delivery_location'];
					$this->obj_gwis_master->po_cmu_no = $_REQUEST['p_po_cmu_no'];
					$this->obj_gwis_master->po_cmu_date = $_REQUEST['p_po_cmu_date'];
					$this->obj_gwis_master->po_gf_no = $_REQUEST['p_po_gf_no'];
					$this->obj_gwis_master->po_gf_date = $_REQUEST['p_po_gf_date'];
					$this->obj_gwis_master->date_of_receiving = date('Y-m-d', strtotime($_REQUEST['p_date_of_receiving']));
					$this->obj_gwis_master->air_bill_no = $_REQUEST['p_air_bill_no'];
					$this->obj_gwis_master->shipment_no = $_REQUEST['p_shipment_no'];
					$this->obj_gwis_master->origin_of_country = $_REQUEST['p_origin_of_country'];
					$this->obj_gwis_master->vehicle_type_and_plate = $_REQUEST['p_vehicle_type_and_plate'];
					$this->obj_gwis_master->consignment_weight = $_REQUEST['p_consignment_weight'];
				}

				$this->obj_gwis_master->issue_to_info = $_POST['issue_to_info'];
				if (isset($_POST['center_patient']) && !empty($_POST['center_patient'])) {
					$this->obj_gwis_master->wh_id_to = $_POST['center_patient'];
				}
				$this->obj_gwis_master->source_type = $_POST['source_type'];
				$this->obj_gwis_master->created_by = $_SESSION['id'];
				$this->obj_gwis_master->created_on = date("Y-m-d");
				$this->obj_gwis_master->temp = 1;
				$this->obj_gwis_master->approve_code = 'D0';
				$this->obj_gwis_master->received_remarks = $_POST['remarks'];
				$this->obj_gwis_master->issuance_to = 'centers';

				$this->obj_gwis_master->approve_from = 'D0';
				$this->obj_gwis_master->approve_to = 'D1';
				$this->obj_gwis_master->active_process = '1';

				$this->obj_gwis_master->province_id = $_POST['province'];

				//file upload
				$uploadedFile = '';
				$uploadDir = 'uploads/';
				if (!empty($_FILES["fileToUpload"]["name"])) {
					//                    $uploadedFile = 'test';
					// File path config 
					$fileName = basename($_FILES["fileToUpload"]["name"]);
					$targetFilePath = $uploadDir . $fileName;
					$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

					// Allow certain file formats 
					$allowTypes = array('pdf', 'doc', 'docx', 'jpg', 'png', 'jpeg');
					if (in_array($fileType, $allowTypes)) {
						// Upload file to the server 
						if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFilePath)) {
							$uploadedFile = $fileName;
						}
					}
				}

				$this->obj_gwis_master->file = $uploadedFile;


				if ($this->input->post('pkmasterid')) {
					$this->obj_gwis_master->pk_id = $this->input->post('pkmasterid');
					//                    $this->obj_gwis_master->updateissuebatchmaster();
					$this->obj_gwis_master->save();
					$stock_master_id = $this->input->post('pkmasterid');
				} else {
					$stock_master_id = $this->obj_gwis_master->save();
				}
			} else {
				$stock_master_id = $_POST['stock_master_id'];
			}

			//changed the followign func
			//$stock_batch_id = $this->obj_stock_batch->update_batch_quantity($_POST['batch'], $_POST['quantity']);

			$this->obj_gwis_detail->fk_stock_id = $stock_master_id;
			if (isset($_POST['batch'])) {
				$this->obj_gwis_detail->batch_id = $_POST['batch'];
				$prodbid = $_POST['batch'];

				$this->obj_gwis_detail->siv_driver_name = $_POST['driver_names'];
				$this->obj_gwis_detail->siv_contatc_number = $_POST['driver_contact'];
				$this->obj_gwis_detail->siv_cnic = $_POST['driver_cnic'];
				$this->obj_gwis_detail->siv_weight = $_POST['weight'];
				$this->obj_gwis_detail->siv_no_of_cartons = $_POST['no_of_cartons'];
				$this->obj_gwis_detail->siv_transportation_po = $_POST['transportation_po'];
				$this->obj_gwis_detail->siv_tracking_no = $_POST['siv_tracking_no'];

				if (isset($_POST['actual_rec_qty']) && !empty($_POST['actual_rec_qty'])) {
					$this->obj_gwis_detail->actual_rec_qty = $_POST['actual_rec_qty'];
				}

				$this->obj_gwis_detail->quantity = '-' . $_POST['quantity'];

				$this->obj_gwis_detail->giv_quantity = '-' . $_POST['quantity'];

				$this->obj_gwis_detail->dc_quantity = $_POST['dc_quantity'];
				$this->obj_gwis_detail->pi_quantity = $_POST['pi_quantity'];
				$this->obj_gwis_detail->ti_quantity = $_POST['ti_quantity'];
				$this->obj_gwis_detail->delivery_challan_type = $_POST['delivery_challan_type'];
				$this->obj_gwis_detail->challan_type_detail = $_POST['challan_type_detail'];
				$this->obj_gwis_detail->invoice = $_POST['invoice'];
				$this->obj_gwis_detail->dc_date = $_POST['dc_date'];
				$this->obj_gwis_detail->dc_no = $_POST['dc_no'];
				$this->obj_gwis_detail->vehicle_reg = $_POST['vehicle_reg'];
				$this->obj_gwis_detail->driver_name = $_POST['driver_names'];
				$this->obj_gwis_detail->driver_contract = $_POST['driver_contract'];
				$this->obj_gwis_detail->po_quantity = $_POST['po_quantity'];

				if (isset($_POST['siv_mode_of_transport']) && !empty($_POST['siv_mode_of_transport'])) {
					$this->obj_gwis_detail->siv_mode_of_transport = $_POST['siv_mode_of_transport'];
				}

				$this->obj_gwis_detail->siv_name_of_transporter = $_POST['siv_name_of_transporter'];

				if (isset($_POST['siv_vehicle_type']) && !empty($_POST['siv_vehicle_type'])) {
					$this->obj_gwis_detail->siv_vehicle_type = $_POST['siv_vehicle_type'];
				}

				$this->obj_gwis_detail->siv_vehicle_plate_no = $_POST['siv_vehicle_plate_no'];

				$this->obj_gwis_detail->electronic_approval = '1';

				$this->obj_gwis_detail->grn_quantity = $_POST['grn_quantity'];

				//                if(isset($_REQUEST['wh_location']) && !empty($_REQUEST['wh_location']))
				//                {
				//                    $this->obj_gwis_detail->wh_location = $_REQUEST['wh_location'];
				//                }
				if (isset($_REQUEST['storage_id']) && !empty($_REQUEST['storage_id'])) {
					$this->obj_gwis_detail->storage = $_REQUEST['storage_id'];
				}

				$get_issue_batchno = $this->obj_stock_batch->get_issue_batchno($prodbid);
				if (!empty($get_issue_batchno)) {
					if ($get_issue_batchno)
						$issue_batchno = $get_issue_batchno->result_array();
					foreach ($issue_batchno as $row) {
						$ibatch_no = $row['batch_no'];
					}
				}

				//                $this->obj_gwis_detail->field1 = $_POST['field1'];
				$this->obj_gwis_detail->field1 = $ibatch_no;
				$this->obj_gwis_detail->field2 = $_POST['field2'];
				$this->obj_gwis_detail->field3 = $_POST['field3'];
				$this->obj_gwis_detail->field4 = $_POST['field4'];
				$this->obj_gwis_detail->field5 = $_POST['field5'];
				$this->obj_gwis_detail->field6 = $_POST['field6'];
				$this->obj_gwis_detail->field7 = $_POST['field7'];
				$this->obj_gwis_detail->field8 = $_POST['field8'];
				$this->obj_gwis_detail->field9 = $_POST['field9'];
				$this->obj_gwis_detail->field10 = $_POST['field10'];
			} else if (isset($_REQUEST['produstbatchid'])) {
				$this->obj_gwis_detail->batch_id = $_REQUEST['produstbatchid'];
				$prodbid = $_REQUEST['produstbatchid'];

				$this->obj_gwis_detail->siv_driver_name = $_POST['driver_names'];
				$this->obj_gwis_detail->siv_contatc_number = $_POST['driver_contact'];
				$this->obj_gwis_detail->siv_cnic = $_POST['driver_cnic'];
				$this->obj_gwis_detail->siv_weight = $_POST['weight'];
				$this->obj_gwis_detail->siv_no_of_cartons = $_POST['no_of_cartons'];
				$this->obj_gwis_detail->siv_transportation_po = $_POST['transportation_po'];
				$this->obj_gwis_detail->siv_tracking_no = $_POST['siv_tracking_no'];
				$this->obj_gwis_detail->actual_rec_qty = $_POST['actual_rec_qty'];
				$this->obj_gwis_detail->quantity = '-' . $_POST['quantity'];

				$this->obj_gwis_detail->giv_quantity = '-' . $_POST['quantity'];

				$this->obj_gwis_detail->dc_quantity = $_POST['p_dc_quantity'];
				$this->obj_gwis_detail->pi_quantity = $_POST['p_pi_quantity'];
				$this->obj_gwis_detail->ti_quantity = $_POST['p_ti_quantity'];
				$this->obj_gwis_detail->delivery_challan_type = $_POST['p_delivery_challan_type'];
				$this->obj_gwis_detail->challan_type_detail = $_POST['p_challan_type_detail'];
				$this->obj_gwis_detail->invoice = $_POST['p_invoice'];
				$this->obj_gwis_detail->dc_date = $_POST['p_dc_date'];
				$this->obj_gwis_detail->dc_no = $_POST['p_dc_no'];
				$this->obj_gwis_detail->vehicle_reg = $_POST['p_vehicle_reg'];
				$this->obj_gwis_detail->driver_name = $_POST['p_driver_name'];
				$this->obj_gwis_detail->driver_contract = $_POST['p_driver_contract'];
				$this->obj_gwis_detail->po_quantity = $_POST['p_po_quantity'];

				if (isset($_POST['siv_mode_of_transport']) && !empty($_POST['siv_mode_of_transport'])) {
					$this->obj_gwis_detail->siv_mode_of_transport = $_POST['siv_mode_of_transport'];
				}

				$this->obj_gwis_detail->siv_name_of_transporter = $_POST['siv_name_of_transporter'];

				if (isset($_POST['siv_vehicle_type']) && !empty($_POST['siv_vehicle_type'])) {
					$this->obj_gwis_detail->siv_vehicle_type = $_POST['siv_vehicle_type'];
				}

				$this->obj_gwis_detail->siv_vehicle_plate_no = $_POST['siv_vehicle_plate_no'];

				$this->obj_gwis_detail->electronic_approval = '1';

				$this->obj_gwis_detail->grn_quantity = $_POST['p_grn_quantity'];

				//                if(isset($_REQUEST['wh_location']) && !empty($_REQUEST['wh_location']))
				//                {
				//                    $this->obj_gwis_detail->wh_location = $_REQUEST['wh_location'];
				//                }
				if (isset($_REQUEST['storage_id']) && !empty($_REQUEST['storage_id'])) {
					$this->obj_gwis_detail->storage = $_REQUEST['storage_id'];
				}

				$this->obj_gwis_detail->field1 = $_POST['prod_field1'];
				$this->obj_gwis_detail->field2 = $_POST['prod_field2'];
				$this->obj_gwis_detail->field3 = $_POST['prod_field3'];
				$this->obj_gwis_detail->field4 = $_POST['prod_field4'];
				$this->obj_gwis_detail->field5 = $_POST['prod_field5'];
				$this->obj_gwis_detail->field6 = $_POST['prod_field6'];
				$this->obj_gwis_detail->field7 = $_POST['prod_field7'];
				$this->obj_gwis_detail->field8 = $_POST['prod_field8'];
				$this->obj_gwis_detail->field9 = $_POST['prod_field9'];
				$this->obj_gwis_detail->field10 = $_POST['prod_field10'];
			}

			$this->obj_gwis_detail->temp = 1;

			if ($this->input->post('pkdetailid')) {
				$this->obj_gwis_detail->pk_id = $this->input->post('pkdetailid');
			}

			$this->obj_gwis_detail->save();

			//            $this->obj_stock_batch->recalculate_batch_qty($prodbid);

			$this->obj_gwis_detail->recalculate_stockdetail_qty($prodbid);

			$data['form'] = $_POST;

			//            $product_arr = $this->obj_product->get_warehouse_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$storage_arr = $this->obj_lists->get_list(16);
			if ($storage_arr) {
				$data['storage'] = $storage_arr->result_array();
			}

			$wh_arr = $this->obj_warehouse->find_all();
			if ($wh_arr)
				$data['warehouse'] = $wh_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();

			$prov_arr = $this->obj_reports_model->get_province();
			if ($prov_arr)
				$data['province'] = $prov_arr->result_array();

			$vehicle_type_arr = $this->obj_lists->get_list(13);
			$data['vehicle_type'] = $vehicle_type_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$currency_arr = $this->obj_itminfo->find_currency_type();
			if ($currency_arr)
				$data['currency_type'] = $currency_arr->result_array();

			$stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			if ($stock_master_record)
				$data['stock_master_records'] = $stock_master_record->result_array();


			if (isset($_REQUEST['vouchertno']) && !empty($_REQUEST['vouchertno'])) {
				$data['pkmasteridedit'] = $_REQUEST['pkmasteridedit'];
				$data['vouchertno'] = $_REQUEST['vouchertno'];
				$data['edit'] = $_REQUEST['edit'];
				$data['temp_records'] = $this->obj_gwis_detail->get_temp_records_edit_issue($_REQUEST['pkmasteridedit']);
			} else {
				$data['temp_records'] = $this->obj_gwis_detail->get_temp_records($stock_master_id);
			}

			$data['master_id'] = $stock_master_id;
			$data['page_title'] = 'Stock Issue';

			$data['main_content'] = $this->load->view('inventory_management/stock_issue', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();

			if ($this->input->get("pkdetailid")) {
				$data['pkdetailid'] = $this->input->get("pkdetailid");
				$data['batchid'] = $this->input->get("batchid");
				$data['fkstockid'] = $this->input->get("fkstockid");
				$res = $this->obj_gwis_master->GetBatchDetail($this->input->get("pkdetailid"), $this->input->get("batchid"));
				//            $row = $res->row();
				if ($res) {
					$data['issue_data'] = $res->result_array();
				}
			}

			if (isset($_REQUEST['pkmasteridedit']) && !empty($_REQUEST['pkmasteridedit'])) {

				$res = $this->obj_gwis_master->GetBatchDetailForEditIssue($_REQUEST['pkmasteridedit']);
				if ($res) {
					$data['issue_data'] = $res->result_array();
				}
			}
			//            $product_arr = $this->obj_product->get_warehouse_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$storage_arr = $this->obj_lists->get_list(16);
			if ($storage_arr) {
				$data['storage'] = $storage_arr->result_array();
			}

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$wh_arr = $this->obj_warehouse->find_all();
			if ($wh_arr)
				$data['warehouse'] = $wh_arr->result_array();

			$currency_arr = $this->obj_itminfo->find_currency_type();
			if ($currency_arr)
				$data['currency_type'] = $currency_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();

			$vehicle_type_arr = $this->obj_lists->get_list(13);
			$data['vehicle_type'] = $vehicle_type_arr->result_array();

			$prov_arr = $this->obj_reports_model->get_province();
			if ($prov_arr)
				$data['province'] = $prov_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$data['temp_records'] = $this->obj_gwis_master->get_temp_master_records(4);
			$master_id_arr = $this->obj_gwis_master->get_temp_master_records(4);
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					//                    $data['tran_reference_number'] = $row['transaction_reference'];
					//                    $data['transaction_date'] = $row['transaction_date'];
					//Get Saved info in readonly fields
					$readonlyinfo = $this->obj_gwis_master->GetBatchDetailForEditIssue($row['stock_master_id']);
					//            $row = $res->row();
					if ($readonlyinfo) {
						$data['issue_data'] = $readonlyinfo->result_array();
					}
				}
			}
			if (isset($_REQUEST['vouchertno']) && !empty($_REQUEST['vouchertno'])) {
				$data['master_id'] = $_REQUEST['pkmasteridedit'];
				$data['temp_records'] = $this->obj_gwis_detail->get_temp_records_edit_issue($_REQUEST['pkmasteridedit']);
			}
			$data['page_title'] = 'Stock Issue';
			$data['main_content'] = $this->load->view('inventory_management/stock_issue', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
		// end of stock_issue
	}

	public function admin_transfers()
	{
		if (!empty($_POST)) {
			//            echo '<pre>';
			//            print_r($_POST);
			//            echo '</pre>';
			//            exit;
			if (isset($_POST['pk_id'])) {
				$this->obj->pk_id = $_POST['pk_id'];
			}
			if (!isset($_POST['stock_master_id'])) {
				$this->obj_stock_master->transaction_date = convert_date($_POST['receiving_time']);
				$this->obj_stock_master->transaction_type_id = 2;
				$this->obj_stock_master->transaction_reference = $_POST['refernce_number'];
				$this->obj_stock_master->warehouse_from = $_POST['center_from'];
				$this->obj_stock_master->warehouse_to = $_POST['center_patient'];
				$this->obj_stock_master->created_by = $_SESSION['id'];
				$this->obj_stock_master->created_on = date("Y-m-d");
				$this->obj_stock_master->temp = 1;
				$this->obj_stock_master->remarks = $_POST['remarks'];
				$this->obj_stock_master->issuance_to = 'centers';
				$stock_master_id = $this->obj_stock_master->save();
			} else {
				$stock_master_id = $_POST['stock_master_id'];
			}

			//changed the following func
			//$stock_batch_id = $this->obj_stock_batch->update_batch_quantity($_POST['batch'], $_POST['quantity']);

			$this->obj_stock_detail->stock_master_id = $stock_master_id;
			$this->obj_stock_detail->batch_id = $_POST['batch'];
			$this->obj_stock_detail->quantity = '-' . $_POST['quantity'];
			$this->obj_stock_detail->temp = 1;
			$this->obj_stock_detail->save();
			$this->obj_stock_batch->recalculate_batch_qty($_POST['batch']);


			$product_arr = $this->obj_stock_batch->get_available_prods_of_wh($this->input->post('center_from'));
			if ($product_arr)
				$data['product'] = $product_arr->result_array();



			$stock_master_record = $this->obj_stock_master->find_by_id($stock_master_id);
			print_r($stock_master_record);
			exit;
			if ($stock_master_record)
				$data['stock_master_records'] = $stock_master_record->result_array();
			$data['wh_from'] = $data['stock_master_records'][0]['warehouse_from'];
			$data['temp_records'] = $this->obj_stock_detail->get_temp_records($stock_master_id);
			$data['master_id'] = $stock_master_id;
			$data['page_title'] = 'Stock Issue';
			//            echo '<pre>';
			//            print_r($data);
			//            echo '</pre>';
			//            exit;
			$data['main_content'] = $this->load->view('inventory_management/admin_transfers', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();

			$product_arr = $this->obj_stock_batch->get_available_prods_of_wh();
			if ($product_arr)
				if (!empty($product_arr))
					$data['product'] = $product_arr->result_array();
				else
					$data['product'] = array();

			$wh_arr = $this->obj_warehouse->find_all();
			if ($wh_arr)
				$data['warehouse'] = $wh_arr->result_array();

			$data['temp_records'] = $this->obj_stock_master->get_temp_master_records(2, "centers");
			$master_id_arr = $this->obj_stock_master->get_temp_master_records(2, "centers");
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['transaction_reference'];
				}
			}
			$data['page_title'] = 'Stock Issue';
			$data['main_content'] = $this->load->view('inventory_management/admin_transfers', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function stock_adjustment()
	{
		if (!empty($_POST)) {

			if (isset($_POST['pk_id'])) {
				$this->obj->pk_id = $_POST['pk_id'];
			}
			if (!isset($_POST['stock_master_id'])) {

				$current_year = date("Y");
				//current month
				$current_month = date("m");
				if ($current_month < 7) {
					//from date
					$from_date = ($current_year - 1) . "-06-30";
					//to date
					$to_date = $current_year . "-07-30";
				} else {
					//from date
					$from_date = $current_year . "-06-30";
					//to date
					$to_date = ($current_year + 1) . "-07-30";
				}

				$last_id = $this->obj_gwis_master->getLastID($from_date, $to_date, 0);

				if (!empty($last_id)) {
					if ($last_id)
						$last_idd = $last_id->result_array();
					foreach ($last_idd as $row) {
						$lastid = $row['Maxtr'];
					}
				}

				if ($lastid == NULL) {
					$lastid = 0;
				}
				$trans_no = "A" . date('ym') . str_pad(($lastid + 1), 4, "0", STR_PAD_LEFT);
				$this->obj_gwis_master->tran_no = $trans_no;
				$this->obj_gwis_master->tr_no = ($lastid + 1);

				$this->obj_gwis_master->tran_ref = 'I ' . date("Y-m-d");
				$this->obj_gwis_master->tran_date = date('Y-m-d', strtotime($_POST['receiving_time']));
				$this->obj_gwis_master->tran_type_id = $this->input->post('tran_type');

				$this->obj_gwis_master->stk_id = $this->input->post('stakeholder');

				if ($this->input->post('other_batch')) {
					$this->obj_gwis_master->process_status = '99';
					$this->obj_gwis_master->status_id = '3';
				} else {
					$this->obj_gwis_master->process_status = '99';
					$this->obj_gwis_master->status_id = '13';
				}
				$this->obj_gwis_master->wh_id_from = $this->session->userdata('warehouse_id');
				$this->obj_gwis_master->wh_id_to = $this->session->userdata('warehouse_id');
				$this->obj_gwis_master->created_by = $this->session->userdata('id');
				$this->obj_gwis_master->created_on = date("Y-m-d");
				$this->obj_gwis_master->temp = 1;

				$this->obj_gwis_master->received_remarks = $this->input->post('remarks');
				$this->obj_gwis_master->issuance_to = 'centers';
				$stock_master_id = $this->obj_gwis_master->save();
			} else {
				$stock_master_id = $_POST['stock_master_id'];
			}

			//changed the following func.
			//$stock_batch_id = $this->obj_stock_batch->update_batch_quantity($_POST['batch'], $_POST['quantity']);

			$result3 = $this->obj_stock_batch->get_tran_nature($this->input->post('tran_type'));
			$res3 = $result3->result_object();

			$tran_nature = $res3[0]->trans_nature;


			if ($this->input->post('other_batch')) {
				//                if(isset($_REQUEST['batchid']) && !empty($_REQUEST['batchid']))
				//                {
				//                    $this->obj_stock_batch->batch_id = $_REQUEST['batchid'];
				//                }
				$this->obj_stock_batch->batch_no = $_REQUEST['other_batch'];
				//batch expiry
				$this->obj_stock_batch->batch_expiry = date('Y-m-d', strtotime($_REQUEST['other_expiry_date']));
				//            $this->obj_stock_batch->dtl = $dtl[$index];
				//            $this->obj_stock_batch->dtl_result = $dtl_result[$index];
				//                $this->obj_stock_batch->funding_source = $funding_source;
				//                $this->obj_stock_batch->manufacturer = $manufacturer_id[$index];
				//                $this->obj_stock_batch->manufacturer_name = $manufacturer_name[$index];
				//quantity
				//            $this->obj_stock_batch->Qty = $quantity;
				$this->obj_stock_batch->Qty = $_REQUEST['other_quantity'];
				//item id
				$this->obj_stock_batch->item_id = $_REQUEST['product'];
				//production date
				$this->obj_stock_batch->production_date = date('Y-m-d', strtotime($_REQUEST['other_prod_date']));
				//warehouse id
				$this->obj_stock_batch->wh_id = $_SESSION['warehouse_id'];

				$this->obj_stock_batch->unit_price = $_REQUEST['unit_price'];

				$this->obj_stock_batch->currency = $_REQUEST['currency'];
				//Status
				//                $this->obj_stock_batch->status = 'Running';
				//save stock batch
				//            echo '<pre>';
				//            print_r($stockBatch);
				//            print_r($objStockBatch);
				//            exit;
				//                if(isset($_REQUEST['batchid']) && !empty($_REQUEST['batchid']))
				//                {
				//                    $this->obj_stock_batch->batch_id = $_REQUEST['batchid'];
				//                    $this->obj_stock_batch->save();
				//                    $batch_id1 = $_REQUEST['batchid'];
				//                }
				//                else{
				$batch_id1 = $this->obj_stock_batch->save();
				//                }
			}




			$this->obj_gwis_detail->fk_stock_id = $stock_master_id;

			if ($this->input->post('other_batch')) {
				$this->obj_gwis_detail->batch_id = $batch_id1;

				$this->obj_gwis_detail->field1 = $_REQUEST['other_batch'];
				$this->obj_gwis_detail->field2 = date('Y-m-d', strtotime($_REQUEST['other_prod_date']));
				$this->obj_gwis_detail->field3 = date('Y-m-d', strtotime($_REQUEST['other_expiry_date']));
				//                $this->obj_gwis_detail->field4 = $_POST['field4'];
				//                $this->obj_gwis_detail->field5 = $_POST['field5'];
				//                $this->obj_gwis_detail->field6 = $_POST['field6'];
				//                $this->obj_gwis_detail->field7 = $_POST['field7'];
				//                $this->obj_gwis_detail->field8 = $_POST['field8'];
				//                $this->obj_gwis_detail->field9 = $_POST['field9'];
				//                $this->obj_gwis_detail->field10 = $_POST['field10'];
				//                $this->obj_gwis_detail->delivery_challan_type = $delivery_challan_type[$index];
				//                $this->obj_gwis_detail->challan_type_detail = $challan_type_detail[$index];
				//                $this->obj_gwis_detail->driver_name = $driver_name[$index];
				//                $this->obj_gwis_detail->driver_contract = $driver_contract[$index];
				//                $this->obj_gwis_detail->vehicle_reg = $vehicle_reg[$index];
				//                $this->obj_gwis_detail->dc_no = $dc_no[$index];
				//                $this->obj_gwis_detail->dc_date = $dc_date[$index];
				//                $this->obj_gwis_detail->invoice = $invoice[$index];
				//                
				//                $this->obj_gwis_detail->date_vehicle_req = date('Y-m-d', strtotime($date_vehicle_req));
				//                $this->obj_gwis_detail->no_of_vehicle = $no_of_vehicle;
				//                $this->obj_gwis_detail->type_of_vehicle = $type_of_vehicle;
				//                
				//                
				//                $this->obj_gwis_detail->product_type_id = $product_type[$index];
				//                $this->obj_gwis_detail->temperature_requirement = $cold_chain_temp[$index];
				//                $this->obj_gwis_detail->no_of_cartons = $no_of_cartons[$index];
				//                $this->obj_gwis_detail->value_of_product = $value_of_product[$index];
				//                $this->obj_gwis_detail->transport_req_remarks = $transport_req_remarks[$index];
			} else if ($this->input->post('batch')) {
				$this->obj_gwis_detail->batch_id = $this->input->post('batch');

				if (isset($_POST['field1'])) {
					$this->obj_gwis_detail->field1 = $_POST['field1'];
				}
				if (isset($_POST['field2'])) {
					$this->obj_gwis_detail->field2 = date('Y-m-d', strtotime($_POST['field2']));
				}
				if (isset($_POST['field3'])) {
					$this->obj_gwis_detail->field3 = date('Y-m-d', strtotime($_POST['field3']));
				}
				if (isset($_POST['field4'])) {
					$this->obj_gwis_detail->field4 = $_POST['field4'];
				}
				if (isset($_POST['field5'])) {
					$this->obj_gwis_detail->field5 = $_POST['field5'];
				}
				if (isset($_POST['field6'])) {
					$this->obj_gwis_detail->field6 = $_POST['field6'];
				}
				if (isset($_POST['field7'])) {
					$this->obj_gwis_detail->field7 = $_POST['field7'];
				}
				if (isset($_POST['field8'])) {
					$this->obj_gwis_detail->field8 = $_POST['field8'];
				}
				if (isset($_POST['field9'])) {
					$this->obj_gwis_detail->field9 = $_POST['field9'];
				}
				if (isset($_POST['field10'])) {
					$this->obj_gwis_detail->field10 = $_POST['field10'];
				}

				//                $this->obj_gwis_detail->delivery_challan_type = $delivery_challan_type[$index];
				//                $this->obj_gwis_detail->challan_type_detail = $challan_type_detail[$index];
				//                $this->obj_gwis_detail->driver_name = $driver_name[$index];
				//                $this->obj_gwis_detail->driver_contract = $driver_contract[$index];
				//                $this->obj_gwis_detail->vehicle_reg = $vehicle_reg[$index];
				//                $this->obj_gwis_detail->dc_no = $dc_no[$index];
				//                $this->obj_gwis_detail->dc_date = $dc_date[$index];
				//                $this->obj_gwis_detail->invoice = $invoice[$index];
				//                
				//                $this->obj_gwis_detail->date_vehicle_req = date('Y-m-d', strtotime($date_vehicle_req));
				//                $this->obj_gwis_detail->no_of_vehicle = $no_of_vehicle;
				//                $this->obj_gwis_detail->type_of_vehicle = $type_of_vehicle;
				//                
				//                
				//                $this->obj_gwis_detail->product_type_id = $product_type[$index];
				//                $this->obj_gwis_detail->temperature_requirement = $cold_chain_temp[$index];
				//                $this->obj_gwis_detail->no_of_cartons = $no_of_cartons[$index];
				//                $this->obj_gwis_detail->value_of_product = $value_of_product[$index];
				//                $this->obj_gwis_detail->transport_req_remarks = $transport_req_remarks[$index];
			} else {
				$this->obj_gwis_detail->batch_id = $this->input->post('otherproduct_batch');

				if (isset($_POST['field1'])) {
					$this->obj_gwis_detail->field1 = $_POST['field1'];
				}
				if (isset($_POST['field2'])) {
					$this->obj_gwis_detail->field2 = date('Y-m-d', strtotime($_POST['field2']));
				}
				if (isset($_POST['field3'])) {
					$this->obj_gwis_detail->field3 = date('Y-m-d', strtotime($_POST['field3']));
				}
				if (isset($_POST['field4'])) {
					$this->obj_gwis_detail->field4 = $_POST['field4'];
				}
				if (isset($_POST['field5'])) {
					$this->obj_gwis_detail->field5 = $_POST['field5'];
				}
				if (isset($_POST['field6'])) {
					$this->obj_gwis_detail->field6 = $_POST['field6'];
				}
				if (isset($_POST['field7'])) {
					$this->obj_gwis_detail->field7 = $_POST['field7'];
				}
				if (isset($_POST['field8'])) {
					$this->obj_gwis_detail->field8 = $_POST['field8'];
				}
				if (isset($_POST['field9'])) {
					$this->obj_gwis_detail->field9 = $_POST['field9'];
				}
				if (isset($_POST['field10'])) {
					$this->obj_gwis_detail->field10 = $_POST['field10'];
				}

				//                $this->obj_gwis_detail->delivery_challan_type = $delivery_challan_type[$index];
				//                $this->obj_gwis_detail->challan_type_detail = $challan_type_detail[$index];
				//                $this->obj_gwis_detail->driver_name = $driver_name[$index];
				//                $this->obj_gwis_detail->driver_contract = $driver_contract[$index];
				//                $this->obj_gwis_detail->vehicle_reg = $vehicle_reg[$index];
				//                $this->obj_gwis_detail->dc_no = $dc_no[$index];
				//                $this->obj_gwis_detail->dc_date = $dc_date[$index];
				//                $this->obj_gwis_detail->invoice = $invoice[$index];
				//                
				//                $this->obj_gwis_detail->date_vehicle_req = date('Y-m-d', strtotime($date_vehicle_req));
				//                $this->obj_gwis_detail->no_of_vehicle = $no_of_vehicle;
				//                $this->obj_gwis_detail->type_of_vehicle = $type_of_vehicle;
				//                
				//                
				//                $this->obj_gwis_detail->product_type_id = $product_type[$index];
				//                $this->obj_gwis_detail->temperature_requirement = $cold_chain_temp[$index];
				//                $this->obj_gwis_detail->no_of_cartons = $no_of_cartons[$index];
				//                $this->obj_gwis_detail->value_of_product = $value_of_product[$index];
				//                $this->obj_gwis_detail->transport_req_remarks = $transport_req_remarks[$index];
			}

			if ($this->input->post('other_batch')) {
				$this->obj_gwis_detail->quantity = (($tran_nature == '-') ? '-' : '') . $this->input->post('other_quantity');
			} else {
				$this->obj_gwis_detail->quantity = (($tran_nature == '-') ? '-' : '') . $this->input->post('quantity');
			}
			$this->obj_gwis_detail->electronic_approval = '1';
			$this->obj_gwis_detail->temp = 1;
			$detail_ide = $this->obj_gwis_detail->save();


			if ($this->input->post('other_batch')) {
				//if transaction type others then this
			} else if ($this->input->post('batch')) {
				$this->obj_stock_batch->stock_adjs_recalculate_batch_qty($this->input->post('batch'), $detail_ide);
			} else {
				$this->obj_stock_batch->stock_adjs_recalculate_batch_qty($this->input->post('otherproduct_batch'), $detail_ide);
			}


			//            $product_arr = $this->obj_product->get_warehouse_products();
			//            $product_arr = $this->obj_itminfo->find_all_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();


			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();
			$data['tran'] = $this->input->post('tran_type');


			$currency_arr = $this->obj_itminfo->find_currency_type();
			if ($currency_arr)
				$data['currency_type'] = $currency_arr->result_array();


			$stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			if ($stock_master_record)
				$data['stock_master_records'] = $stock_master_record->result_array();
			$data['temp_records'] = $this->obj_gwis_detail->get_temp_records($stock_master_id);
			$data['master_id'] = $stock_master_id;
			$data['this_tran'] = $tran_nature;
			$data['this_stk'] = $this->obj_gwis_master->stk_id = $this->input->post('stakeholder');
			$data['page_title'] = 'Stock Issue';

                        redirect(base_url('inventory_management/stock_adjustment'), FALSE);
			//$data['main_content'] = $this->load->view('inventory_management/stock_adj', $data, TRUE);
			//$this->load->view('layout/main', $data);
		} else {
			$data = array();

			//            $product_arr = $this->obj_itminfo->find_all_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();


			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();


			//            $product_arr = $this->obj_product->get_warehouse_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();

			$currency_arr = $this->obj_itminfo->find_currency_type();
			if ($currency_arr)
				$data['currency_type'] = $currency_arr->result_array();

			$wh_arr = $this->obj_warehouse->find_all();
			if ($wh_arr)
				$data['warehouse'] = $wh_arr->result_array();

			$data['temp_records'] = $this->obj_gwis_master->get_temp_master_records_adj(3, "centers");

			$master_id_arr = $this->obj_gwis_master->get_temp_master_records_adj(3, "centers");
			if (!empty($master_id_arr)) {
				if ($master_id_arr) {
					$master_result = $master_id_arr->result_array();
					foreach ($master_result as $row) {

						@$data['this_tran'] = $row['trans_type'];
						@$data['this_stk'] = $row['stkname'];
						@$data['master_id'] = $row['stock_master_id'];
						@$data['tran_reference_number'] = $row['transaction_reference'];
					}
				}
			}
			$data['page_title'] = 'Stock Issue';
			$data['main_content'] = $this->load->view('inventory_management/stock_adj', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function transport_req_form_new()
	{
		if (!empty($_POST)) {
			if (isset($_POST['pk_id'])) {
				$this->obj_transport_req_master->pk_id = $_POST['pk_id'];
			}
			if (!isset($_POST['stock_master_id'])) {

				$current_year = date("Y");
				//current month
				$current_month = date("m");
				if ($current_month < 7) {
					//from date
					$from_date = ($current_year - 1) . "-06-30";
					//to date
					$to_date = $current_year . "-07-30";
				} else {
					//from date
					$from_date = $current_year . "-06-30";
					//to date
					$to_date = ($current_year + 1) . "-07-30";
				}

				$last_id = $this->obj_transport_req_master->getLastID($from_date, $to_date, 0);

				if (!empty($last_id)) {
					if ($last_id)
						$last_idd = $last_id->result_array();
					foreach ($last_idd as $row) {
						$lastid = $row['Maxtr'];
					}
				}

				if ($lastid == NULL) {
					$lastid = 0;
				}
				$trans_no = "TRF" . date('ym') . str_pad(($lastid + 1), 4, "0", STR_PAD_LEFT);
				$this->obj_transport_req_master->tran_no = $trans_no;
				$this->obj_transport_req_master->tr_no = ($lastid + 1);
				//                
				$this->obj_transport_req_master->demand_req_date = date('Y-m-d', strtotime($this->input->post('demand_req_date')));
				$this->obj_transport_req_master->location_from = $this->input->post('location_from');
				$this->obj_transport_req_master->location_to = $this->input->post('location_to');
				$this->obj_transport_req_master->demand_requisition = $this->input->post('demand_requisition');
				$this->obj_transport_req_master->temp = '1';
				$this->obj_transport_req_master->status = '1';
				$this->obj_transport_req_master->approver_status = '1';

				//file upload
				$uploadedFile = '';
				$uploadDir = 'uploads/';
				if (!empty($_FILES["fileToUpload"]["name"])) {
					//                    $uploadedFile = 'test';
					// File path config 
					$fileName = basename($_FILES["fileToUpload"]["name"]);
					$targetFilePath = $uploadDir . $fileName;
					$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

					// Allow certain file formats 
					$allowTypes = array('pdf', 'doc', 'docx', 'jpg', 'png', 'jpeg');
					if (in_array($fileType, $allowTypes)) {
						// Upload file to the server 
						if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFilePath)) {
							$uploadedFile = $fileName;
						}
					}
				}

				$this->obj_transport_req_master->file = $uploadedFile;
				//file upload end

				$stock_master_id = $this->obj_transport_req_master->save();
			} else {
				$stock_master_id = $_POST['stock_master_id'];
			}

			//changed the following func.
			//$stock_batch_id = $this->obj_stock_batch->update_batch_quantity($_POST['batch'], $_POST['quantity']);
			//            $result3 = $this->obj_stock_batch->get_tran_nature($this->input->post('tran_type'));
			//            $res3 = $result3->result_object();
			//
			//            $tran_nature = $res3[0]->trans_nature;


			if (isset($_REQUEST['vehicle_req']) && !empty($_REQUEST['vehicle_req'])) {
				$this->obj_transport_req_detail->tr_master_id = $stock_master_id;

				$this->obj_transport_req_detail->no_of_vehicle = $this->input->post('no_of_vehicle');
				$this->obj_transport_req_detail->vehicle_type = $this->input->post('vehicle_type');
				$this->obj_transport_req_detail->vehicle_rent = $this->input->post('vehicle_rent');
				$this->obj_transport_req_detail->amount = $this->input->post('vehicle_amount');
				$this->obj_transport_req_detail->vehicle_req_date = date('Y-m-d', strtotime($this->input->post('vehicle_req_date')));
				$this->obj_transport_req_detail->temp = 1;
				$this->obj_transport_req_detail->is_active = 1;
				$this->obj_transport_req_detail->save();
			}

			if (isset($_REQUEST['prod_req']) && !empty($_REQUEST['prod_req'])) {
				$this->obj_transport_product_info->tr_master_id = $stock_master_id;

				$this->obj_transport_product_info->product = $this->input->post('product');
				$this->obj_transport_product_info->quantity = $this->input->post('product_quantity');
				$this->obj_transport_product_info->cartons = $this->input->post('no_of_cartons');
				$this->obj_transport_product_info->manufacturer = $this->input->post('manufacturer');
				$this->obj_transport_product_info->temp = 1;
				$this->obj_transport_product_info->is_active = 1;
				$this->obj_transport_product_info->save();
			}

			$data['form'] = $_POST;

			//            $product_arr = $this->obj_product->get_warehouse_products();
			//            $product_arr = $this->obj_itminfo->find_all_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();

			$vehicle_type_arr = $this->obj_lists->get_list(13);
			$data['vehicle_type'] = $vehicle_type_arr->result_array();

			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();
			$data['tran'] = $this->input->post('tran_type');

			$manuf_arr = $this->obj_stakeholder->get_all_info();
			$data['manufacturer'] = $manuf_arr->result_array();

			//            if (isset($_REQUEST['pkmasteridedit']) && !empty($_REQUEST['pkmasteridedit'])) {
			//                
			//                $stock_master_record = $this->obj_transport_req_master->find_by_id($_REQUEST['pkmasteridedit']);
			//                if ($stock_master_record)
			//                    $data['stock_master_records'] = $stock_master_record->result_array();
			//                
			//            }
			//            else{

			$stock_master_record = $this->obj_transport_req_master->find_by_id($stock_master_id);
			if ($stock_master_record)
				$data['stock_master_records'] = $stock_master_record->result_array();

			//            }


			if (isset($_REQUEST['vouchertno']) && !empty($_REQUEST['vouchertno'])) {
				$data['pkmasteridedit'] = $_REQUEST['pkmasteridedit'];
				$data['vouchertno'] = $_REQUEST['vouchertno'];
				$data['edit'] = $_REQUEST['edit'];
				$data['temp_records_vehicle'] = $this->obj_transport_req_detail->get_temp_records_edit($_REQUEST['pkmasteridedit']);
				$data['temp_records_prod'] = $this->obj_transport_product_info->get_temp_records_edit($_REQUEST['pkmasteridedit']);
			} else {
				$data['temp_records_vehicle'] = $this->obj_transport_req_detail->get_temp_records($stock_master_id);
				$data['temp_records_prod'] = $this->obj_transport_product_info->get_temp_records($stock_master_id);
			}

			$data['master_id'] = $stock_master_id;
			$data['page_title'] = 'Transport Req Form';

			$data['main_content'] = $this->load->view('inventory_management/transport_req_form_new', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();

			//            $product_arr = $this->obj_itminfo->find_all_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();

			if (isset($_REQUEST['pkmasteridedit']) && !empty($_REQUEST['pkmasteridedit'])) {

				$stock_master_record = $this->obj_transport_req_master->find_by_id($_REQUEST['pkmasteridedit']);
				if ($stock_master_record)
					$data['stock_master_records'] = $stock_master_record->result_array();
			}
			//            else{
			//                
			//                $stock_master_record = $this->obj_transport_req_master->find_by_id($stock_master_id);
			//                if ($stock_master_record)
			//                    $data['stock_master_records'] = $stock_master_record->result_array();
			//                
			//            }

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();

			$vehicle_type_arr = $this->obj_lists->get_list(13);
			$data['vehicle_type'] = $vehicle_type_arr->result_array();

			$manuf_arr = $this->obj_stakeholder->get_all_info();
			$data['manufacturer'] = $manuf_arr->result_array();
			//            $product_arr = $this->obj_product->get_warehouse_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();

			$wh_arr = $this->obj_warehouse->find_all();
			if ($wh_arr)
				$data['warehouse'] = $wh_arr->result_array();

			//            $data['temp_records'] = $this->obj_transport_req_master->get_temp_master_records_transportreq(3, "centers");
			$master_id_arr = $this->obj_transport_req_master->get_temp_master_records_transportreq(3, "centers");
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					//                    $data['master_id'] = $row['tr_master_id'];
					//                    $data['tran_reference_number'] = $row['transaction_reference'];
				}
			}

			if (isset($_REQUEST['vouchertno']) && !empty($_REQUEST['vouchertno'])) {
				$data['master_id'] = $_REQUEST['pkmasteridedit'];
				$data['temp_records_vehicle'] = $this->obj_transport_req_detail->get_temp_records_edit($_REQUEST['pkmasteridedit']);
				$data['temp_records_prod'] = $this->obj_transport_product_info->get_temp_records_edit($_REQUEST['pkmasteridedit']);
			} else {
				//                $data['temp_records_vehicle'] = $this->obj_transport_req_detail->get_temp_records_edit($_REQUEST['pkmasteridedit']);
				//                $data['temp_records_prod'] = $this->obj_transport_product_info->get_temp_records_edit($_REQUEST['pkmasteridedit']);
			}

			$data['page_title'] = 'Transport Req Form';
			$data['main_content'] = $this->load->view('inventory_management/transport_req_form_new', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function transport_req_approve_form()
	{
		if (!empty($_POST)) {
			//            if (isset($_POST['pk_id'])) {
			//                $this->obj_transport_req_master->pk_id = $_POST['pk_id'];
			//            }
			if (isset($_REQUEST['update_approve'])) {

				$this->obj_transport_req_master->pk_id = $_POST['trmasterid'];
				if (date('Y-m-d', strtotime($this->input->post('date_vehicle_req'))) == '1970-01-01') {
					$this->obj_transport_req_master->date_vehicle_req = date("Y-m-d");
				} else {
					$this->obj_transport_req_master->date_vehicle_req = date('Y-m-d', strtotime($this->input->post('date_vehicle_req')));
				}

				$this->obj_transport_req_master->demand_requisition = $this->input->post('demand_requisition');
				$this->obj_transport_req_master->location_from = $this->input->post('location_from');
				$this->obj_transport_req_master->location_to = $this->input->post('location_to');
				$this->obj_transport_req_master->temp = '0';
				$this->obj_transport_req_master->status = '0';
				$this->obj_transport_req_master->approver_status = '1';

				//file upload
				$uploadedFile = '';
				$uploadDir = 'uploads/';
				if (!empty($_FILES["fileToUpload"]["name"])) {
					//                    $uploadedFile = 'test';
					// File path config 
					$fileName = basename($_FILES["fileToUpload"]["name"]);
					$targetFilePath = $uploadDir . $fileName;
					$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

					// Allow certain file formats 
					$allowTypes = array('pdf', 'doc', 'docx', 'jpg', 'png', 'jpeg');
					if (in_array($fileType, $allowTypes)) {
						// Upload file to the server 
						if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFilePath)) {
							$uploadedFile = $fileName;
						}
					}
				}

				$this->obj_transport_req_master->file = $uploadedFile;
				//file upload end

				$stock_master_id = $this->obj_transport_req_master->update_status_form();
			}
			//            else {
			//                $stock_master_id = $_POST['stock_master_id'];
			//            }
			//changed the following func.
			//$stock_batch_id = $this->obj_stock_batch->update_batch_quantity($_POST['batch'], $_POST['quantity']);
			//            $result3 = $this->obj_stock_batch->get_tran_nature($this->input->post('tran_type'));
			//            $res3 = $result3->result_object();
			//
			//            $tran_nature = $res3[0]->trans_nature;


			$data['form'] = $_POST;

			//            $product_arr = $this->obj_product->get_warehouse_products();

			$qry_vouchers = $this->obj_transport_req_master->gettransport_issue_vouchers();
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}


			$qry_rej_vouchers = $this->obj_transport_req_master->gettransport_rejected_vouchers();
			if ($qry_rej_vouchers) {
				$data['getRejectedVoucher'] = $qry_rej_vouchers->result_array();
			} else {
				$data['getRejectedVoucher'] = '';
			}


			if (isset($_REQUEST['issue_no'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_transport_req_master->tran_no = $issue_no;
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_transport_req_master->GetWHStockByIssueNo();
				$stockReceiveprod = $this->obj_transport_req_master->GetWHStockByIssueNoprod();
				//                }
			}

			if (isset($_REQUEST['rej_issue_no'])) {
				$data['rej_issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['rej_issue_no']) && !empty($_REQUEST['rej_issue_no'])) {
					//get issue number
					$rej_issue_no = $_REQUEST['rej_issue_no'];
					$data['issue_no'] = $_REQUEST['rej_issue_no'];
					$this->obj_transport_req_master->tran_no = $rej_issue_no;
					$stockReceive = $this->obj_transport_req_master->GetWHStockByIssueNo_rejvouchers();
					$stockReceiveprod = $this->obj_transport_req_master->GetWHStockByIssueNoprod_rejvouchers();
				}
				//set issue number
				//                    $this->obj_transport_req_master->status_id = 1;
				//                    $this->obj_transport_req_master->tran_no = $rej_issue_no;
				//                    $this->obj_transport_req_master->wh_id_to = $_SESSION['warehouse_id'];
				//                    //Get WH Stock By Issue No
				//                    $stockReceive = $this->obj_transport_req_master->GetWHStockByRejIssueNo();
				//                }
			}


			if (isset($stockReceive)) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
				$data['stockReceiveprod'] = $stockReceiveprod->result_array();
			}


			//            $product_arr = $this->obj_itminfo->find_all_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();

			$vehicle_type_arr = $this->obj_lists->get_list(13);
			$data['vehicle_type'] = $vehicle_type_arr->result_array();

			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();
			$data['tran'] = $this->input->post('tran_type');


			if (isset($stock_master_id)) {
				$stock_master_record = $this->obj_transport_req_master->find_by_id($stock_master_id);
				if ($stock_master_record)
					$data['stock_master_records'] = $stock_master_record->result_array();

				$data['temp_records_vehicle'] = $this->obj_transport_req_detail->get_temp_records($stock_master_id);
				$data['temp_records_prod'] = $this->obj_transport_product_info->get_temp_records($stock_master_id);
				$data['master_id'] = $stock_master_id;
			}
			$data['page_title'] = 'Transport Req Form';

			$data['main_content'] = $this->load->view('inventory_management/transport_req_approve_form', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();

			//            $product_arr = $this->obj_itminfo->find_all_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();


			$qry_vouchers = $this->obj_transport_req_master->gettransport_issue_vouchers();
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}


			$qry_rej_vouchers = $this->obj_transport_req_master->gettransport_rejected_vouchers();
			if ($qry_rej_vouchers) {
				$data['getRejectedVoucher'] = $qry_rej_vouchers->result_array();
			} else {
				$data['getRejectedVoucher'] = '';
			}


			if (isset($_REQUEST['issue_no'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_transport_req_master->tran_no = $issue_no;
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_transport_req_master->GetWHStockByIssueNo();
				$stockReceiveprod = $this->obj_transport_req_master->GetWHStockByIssueNoprod();
				//                }
			}

			if (isset($_REQUEST['rej_issue_no'])) {
				$data['rej_issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['rej_issue_no']) && !empty($_REQUEST['rej_issue_no'])) {
					//get issue number
					$rej_issue_no = $_REQUEST['rej_issue_no'];
					$data['issue_no'] = $_REQUEST['rej_issue_no'];
					$this->obj_transport_req_master->tran_no = $rej_issue_no;
					$stockReceive = $this->obj_transport_req_master->GetWHStockByIssueNo_rejvouchers();
					$stockReceiveprod = $this->obj_transport_req_master->GetWHStockByIssueNoprod_rejvouchers();
				}
				//set issue number
				//                    $this->obj_transport_req_master->status_id = 1;
				//                    $this->obj_transport_req_master->tran_no = $rej_issue_no;
				//                    $this->obj_transport_req_master->wh_id_to = $_SESSION['warehouse_id'];
				//                    //Get WH Stock By Issue No
				//                    $stockReceive = $this->obj_transport_req_master->GetWHStockByRejIssueNo();
				//                }
			}


			if (isset($stockReceive)) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
				$data['stockReceiveprod'] = $stockReceiveprod->result_array();
			}


			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();

			$vehicle_type_arr = $this->obj_lists->get_list(13);
			$data['vehicle_type'] = $vehicle_type_arr->result_array();

			//            $product_arr = $this->obj_product->get_warehouse_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();

			$wh_arr = $this->obj_warehouse->find_all();
			if ($wh_arr)
				$data['warehouse'] = $wh_arr->result_array();

			$data['temp_records'] = $this->obj_transport_req_master->get_temp_master_records_transportreq(3, "centers");
			$master_id_arr = $this->obj_transport_req_master->get_temp_master_records_transportreq(3, "centers");
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['tr_master_id'];
					//                    $data['tran_reference_number'] = $row['transaction_reference'];
				}
			}

			$data['page_title'] = 'Transport Req Form';
			$data['main_content'] = $this->load->view('inventory_management/transport_req_approve_form', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function transport_req_approver()
	{
		if (!empty($_POST)) {
			//            if (isset($_POST['pk_id'])) {
			//                $this->obj_transport_req_master->pk_id = $_POST['pk_id'];
			//            }
			if (isset($_POST['form_approv_or_rej'])) {

				if (isset($_REQUEST['trmasterid'])) {
					$this->obj_transport_req_master->pk_id = $_REQUEST['trmasterid'];
				}

				//                $this->obj_transport_req_master->tran_no = $trans_no;
				//                $this->obj_transport_req_master->tr_no = ($lastid + 1);
				////                
				//                $this->obj_transport_req_master->date_vehicle_req = $this->input->post('date_vehicle_req');
				//                $this->obj_transport_req_master->location_from = $this->input->post('location_from');
				//                $this->obj_transport_req_master->location_to = $this->input->post('location_to');
				//                $this->obj_transport_req_master->temp = '0';

				if ($_REQUEST['form_approv_or_rej'] == '0') {
					$this->obj_transport_req_master->status = '0';
					$this->obj_transport_req_master->approver_status = '0';
				} else {
					$this->obj_transport_req_master->status = '1';
					$this->obj_transport_req_master->approver_status = '0';
				}

				$stock_master_id = $this->obj_transport_req_master->update_status();
			} else {
				$stock_master_id = $_POST['stock_master_id'];
			}

			//changed the following func.
			//$stock_batch_id = $this->obj_stock_batch->update_batch_quantity($_POST['batch'], $_POST['quantity']);
			//            $result3 = $this->obj_stock_batch->get_tran_nature($this->input->post('tran_type'));
			//            $res3 = $result3->result_object();
			//
			//            $tran_nature = $res3[0]->trans_nature;


			$data['form'] = $_POST;

			//            $product_arr = $this->obj_product->get_warehouse_products();

			$qry_vouchers = $this->obj_transport_req_master->gettransport_approver_vouchers();
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}


			if (isset($_REQUEST['issue_no'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_transport_req_master->tran_no = $issue_no;
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_transport_req_master->GetWHStockByIssueNo_approver();
				$stockReceiveprod = $this->obj_transport_req_master->GetWHStockByIssueNoprod_approver();
				//                }
			}


			if (isset($stockReceive)) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
				$data['stockReceiveprod'] = $stockReceiveprod->result_array();
			}


			//            $product_arr = $this->obj_itminfo->find_all_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();

			$vehicle_type_arr = $this->obj_lists->get_list(13);
			$data['vehicle_type'] = $vehicle_type_arr->result_array();

			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();
			$data['tran'] = $this->input->post('tran_type');



			$stock_master_record = $this->obj_transport_req_master->find_by_id($stock_master_id);
			if ($stock_master_record)
				$data['stock_master_records'] = $stock_master_record->result_array();

			$data['temp_records_vehicle'] = $this->obj_transport_req_detail->get_temp_records($stock_master_id);
			$data['temp_records_prod'] = $this->obj_transport_product_info->get_temp_records($stock_master_id);
			$data['master_id'] = $stock_master_id;
			$data['page_title'] = 'Transport Req Approver';

			$data['main_content'] = $this->load->view('inventory_management/transport_req_approver', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();

			//            $product_arr = $this->obj_itminfo->find_all_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();


			$qry_vouchers = $this->obj_transport_req_master->gettransport_approver_vouchers();
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}



			if (isset($_REQUEST['issue_no'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_transport_req_master->tran_no = $issue_no;
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_transport_req_master->GetWHStockByIssueNo_approver();
				$stockReceiveprod = $this->obj_transport_req_master->GetWHStockByIssueNoprod_approver();
				//                }
			}



			if (isset($stockReceive)) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
				$data['stockReceiveprod'] = $stockReceiveprod->result_array();
			}


			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();

			$vehicle_type_arr = $this->obj_lists->get_list(13);
			$data['vehicle_type'] = $vehicle_type_arr->result_array();

			//            $product_arr = $this->obj_product->get_warehouse_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();

			$wh_arr = $this->obj_warehouse->find_all();
			if ($wh_arr)
				$data['warehouse'] = $wh_arr->result_array();

			$data['temp_records'] = $this->obj_transport_req_master->get_temp_master_records_transportreq(3, "centers");
			$master_id_arr = $this->obj_transport_req_master->get_temp_master_records_transportreq(3, "centers");
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['tr_master_id'];
					//                    $data['tran_reference_number'] = $row['transaction_reference'];
				}
			}

			$data['page_title'] = 'Transport Req Approver';
			$data['main_content'] = $this->load->view('inventory_management/transport_req_approver', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function product_location()
	{
		if (!empty($_POST)) {

			if (isset($_REQUEST['change_product_batch'])) {
				$ides = explode("_", $_REQUEST['change_product_batch']);
				//                echo $ides[1];exit;
				$this->obj_gwis_detail->pk_id = $ides[1];
			} else if (isset($_REQUEST['detailpk_id'])) {
				//                echo $_REQUEST['detailpk_id'];exit;
				$this->obj_gwis_detail->pk_id = $_REQUEST['detailpk_id'];
			}

			$this->obj_gwis_detail->wh_location = $_REQUEST['wh_location'];

			$this->obj_gwis_detail->update_location();


			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();


			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();
			$data['tran'] = $this->input->post('tran_type');



			//            $stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			//            if ($stock_master_record)
			//                $data['stock_master_records'] = $stock_master_record->result_array();
			//            $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($stock_master_id);
			//            $data['master_id'] = $stock_master_id;
			$data['page_title'] = 'Product Location';

			$data['main_content'] = $this->load->view('inventory_management/product_location', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();

			//            $product_arr = $this->obj_itminfo->find_all_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();


			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();


			//            $product_arr = $this->obj_product->get_warehouse_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();

			$wh_arr = $this->obj_warehouse->find_all();
			if ($wh_arr)
				$data['warehouse'] = $wh_arr->result_array();

			$data['temp_records'] = $this->obj_gwis_master->get_temp_master_records_adj(3, "centers");
			$master_id_arr = $this->obj_gwis_master->get_temp_master_records_adj(3, "centers");
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['transaction_reference'];
				}
			}
			$data['page_title'] = 'Product Location';
			$data['main_content'] = $this->load->view('inventory_management/product_location', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function stock_issue_patients()
	{
		if (!empty($_POST)) {
			if (isset($_POST['pk_id'])) {
				$this->obj->pk_id = $_POST['pk_id'];
			}
			if (!isset($_POST['stock_master_id'])) {
				$this->obj_stock_master->transaction_date = convert_date($_POST['receiving_time']);
				$this->obj_stock_master->transaction_type_id = 2;
				$this->obj_stock_master->transaction_reference = "Issuance to patients";
				$this->obj_stock_master->warehouse_from = $_SESSION['warehouse_id'];
				$this->obj_stock_master->warehouse_to = $_POST['center_patient'];
				$this->obj_stock_master->created_by = $_SESSION['id'];
				$this->obj_stock_master->created_on = date("Y-m-d");
				$this->obj_stock_master->temp = 1;
				$this->obj_stock_master->remarks = $_POST['remarks'];
				$this->obj_stock_master->issuance_to = 'patients';
				$this->obj_stock_master->vials_returned = $_POST['vials_returned'];
				$stock_master_id = $this->obj_stock_master->save();
			} else {
				$stock_master_id = $_POST['stock_master_id'];
			}

			//changed the following func
			//$stock_batch_id = $this->obj_stock_batch->update_batch_quantity($_POST['batch'], $_POST['quantity']);

			$this->obj_stock_detail->stock_master_id = $stock_master_id;
			$this->obj_stock_detail->batch_id = $_POST['batch'];
			$this->obj_stock_detail->quantity = '-' . $_POST['quantity'];
			$this->obj_stock_detail->temp = 1;
			$this->obj_stock_detail->save();
			$this->obj_stock_batch->recalculate_batch_qty($_POST['batch']);


			$product_arr = $this->obj_product->get_warehouse_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();



			$stock_master_record = $this->obj_stock_master->find_by_id($stock_master_id);
			if ($stock_master_record)
				$data['stock_master_records'] = $stock_master_record->result_array();
			//            echo '<pre>';
			//            print_r($data['stock_master_records']);
			//            echo '</pre>';
			//            exit;
			$data['warehouse_to'] = $data['stock_master_records'][0]['warehouse_to'];

			$patient_arr = $this->obj_patient->find_by_id($data['warehouse_to']);
			if ($patient_arr)
				$data['patient'] = $patient_arr->result_array();

			$data['temp_records'] = $this->obj_stock_detail->get_temp_records($stock_master_id);
			$data['master_id'] = $stock_master_id;
			$data['page_title'] = 'Stock Issue';

			$data['main_content'] = $this->load->view('inventory_management/stock_issue_patients', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();

			$product_arr = $this->obj_product->get_warehouse_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$patient_arr = $this->obj_patient->find_all();
			if ($patient_arr)
				$data['patient'] = $patient_arr->result_array();

			$data['temp_records'] = $this->obj_stock_master->get_temp_master_records(2, "patients");
			$master_id_arr = $data['temp_records'];

			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['transaction_reference'];
				}
			}
			$data['page_title'] = 'Stock Issue';
			$data['main_content'] = $this->load->view('inventory_management/stock_issue_patients', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function recalculate_batch_qty($batch_id)
	{
		echo $this->obj_stock_batch->recalculate_batch_qty($batch_id);
	}

	public function stock_issue_patients_tabular()
	{
		if (!empty($_POST)) {
			//            echo '<pre>';
			//            print_r($_REQUEST);
			//            echo '</pre>';
			//            exit;


			$this->obj_stock_master->transaction_date = date('Y-m-d', strtotime($this->input->post('receiving_time')));
			$this->obj_stock_master->transaction_type_id = 2;
			$this->obj_stock_master->transaction_reference = "Issuance to patients";
			$this->obj_stock_master->warehouse_from = $_SESSION['warehouse_id'];
			$this->obj_stock_master->warehouse_to = $this->input->post('center_patient');
			$this->obj_stock_master->created_by = $_SESSION['id'];
			$this->obj_stock_master->created_on = date("Y-m-d");
			$this->obj_stock_master->temp = 0;
			$this->obj_stock_master->remarks = $this->input->post('remarks');
			$this->obj_stock_master->issuance_to = 'patients';
			$this->obj_stock_master->vials_returned = $this->input->post('vials_returned');
			$stock_master_id = $this->obj_stock_master->save();


			$batches = $this->input->post('batch');
			$quantities = $this->input->post('quantity');
			$next_issuance_date = $this->input->post('next_issuance_date');
			if (!empty($batches) && count($batches) > 0 && $stock_master_id > 0) {
				foreach ($batches as $k => $batch_id) {
					if (!empty($quantities[$k]) && $quantities[$k] > 0) {
						$qty = $quantities[$k];

						$nxt_date = '';
						if (!empty($next_issuance_date[$k]) && $next_issuance_date[$k] > 0) {
							$d = str_replace('/', '-', $next_issuance_date[$k]);
							$nxt_date = date('Y-m-d', strtotime($d));
						}

						$this->obj_stock_detail->stock_master_id = $stock_master_id;
						$this->obj_stock_detail->next_issuance_date = $nxt_date;
						$this->obj_stock_detail->batch_id = $batch_id;
						$this->obj_stock_detail->quantity = '-' . $qty;
						$this->obj_stock_detail->temp = 0;
						//                        echo '<pre>';
						//                        print_r($this->obj_stock_detail);
						//                        print_r($_REQUEST);
						//                        echo '</pre>';
						//                        exit;
						$this->obj_stock_detail->save();


						$this->obj_stock_batch->recalculate_batch_qty($batch_id);
					}
				}
			}


			redirect(base_url() . 'patients/history/' . $this->input->post('center_patient'), 'refresh');
		} else {
			$data = array();

			$product_arr = $this->obj_product->get_warehouse_stock();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$this_pat_id = $this->input->get_post('patient_id');
			$patient_arr = $this->obj_patient->find_by_id($this_pat_id);
			if ($patient_arr) {
				$data['patient'] = $patient_arr->result_array();
			}
			//echo '<pre>';
			//print_r($data['patient'][$_REQUEST['patient_id']]);
			//echo '</pre>';
			//exit;

			$data['temp_records'] = $this->obj_stock_master->get_temp_master_records(2, "patients");
			$master_id_arr = $data['temp_records'];

			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['transaction_reference'];
				}
			}

			$data['lists_oral_drugs'] = (array) $this->obj_lists->get_list(1);
			$hist = $this->obj_patient->find_medicine_history($this_pat_id);
			if (!empty($hist)) {
				$data['medicine_history'] = $hist->result_object();
			}
			$tem = $this->obj_patient->find_diabetic_data($this_pat_id);
			@$data['oral_drugs'] = $tem['oral_drugs'];
			//             echo '<pre>';
			//            print_r($data['medicine_history']);
			//            print_r($data['oral_drugs']);
			//            print_r($data['lists_oral_drugs']);
			//            print_r($data['patient']);
			////            print_r($_REQUEST);
			//            echo '</pre>';
			//            exit;
			$data['page_title'] = 'Stock Issue';
			$data['main_content'] = $this->load->view('inventory_management/stock_issue_patients_tabular', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	function get_product_batches_stock_issue()
	{
		$product_category = '1';
		$item_id = $_POST['item_id'];
		$wh_id = $this->session->userdata('warehouse_id');
		$result = $this->obj_stock_batch->get_product_batches($item_id, $wh_id, $product_category);

		echo "<option value=>Select</option>";
		foreach ($result->result_object() as $row) {
			echo "<option value=" . $row->batch_id . ">" . $row->batch_number . "</option>";
		}
	}

	function getmanufacturerfield()
	{
		//        $product_category = '1';
		$item_id = $_POST['item_id'];
		//        $wh_id = $this->session->userdata('warehouse_id');
		$result = $this->obj_stock_batch->get_manufacturer_field($item_id);
		if ($result) {
			foreach ($result->result_object() as $row) {
				echo $row->stkname . '_' . $row->manufacturer_id . '_' . $row->method_type;
			}
		}
	}

	function getmanufacturerld()
	{
		//        $product_category = '1';
		$item_id = $_POST['item_id'];
		//        $wh_id = $this->session->userdata('warehouse_id');
		$result = $this->obj_stock_batch->get_manufacturerld($item_id);
		if ($result) {
			foreach ($result->result_object() as $row) {
				echo $row->stkid;
			}
		}
	}

	function get_batches_of_wh()
	{
		$sel = '';
		$product_category = $this->input->post('product_type');
		$item_id = $this->input->post('item_id');
		$wh_id = $this->input->post('wh_id');
		$editbatchid = $this->input->post('editbatchid');
		$stk_id = $this->input->post('stk_id');
		$stock_type = $this->input->post('stock_type');

		$process_status_nmbr = '';
		$qry_getprocess_status = $this->obj_gwis_master->getprocess_statusmax(3);
		if ($qry_getprocess_status) {
			$dataprocessstatus = $qry_getprocess_status->result_array();
		}
		foreach ($dataprocessstatus as $row) {
			$process_status_nmbr = $row['process_status'];
		}
		if($stock_type == 'stock_issue'){
	    	$result = $this->obj_stock_batch->get_product_batches($item_id, $wh_id, $product_category, $process_status_nmbr, $stk_id,0);
     	}else{
     		$result = $this->obj_stock_batch->get_product_batches($item_id, $wh_id, $product_category, $process_status_nmbr, $stk_id);
     	}
		if ($result) {
			$getbatch = $result->result_array();

			echo "<option value=''>Select</option>";
			foreach ($getbatch as $row) {
				if (isset($editbatchid) && $editbatchid == $row['batch_id']) {
					$sel = 'selected="selected"';
				} else {
					$sel = '';
				}
				echo "<option value=" . $row['batch_id'] . " " . $sel . "  >" . $row['batch_no'] . ' (' . $row['batch_expiry'] . ')' . "</option>";
			}
		}
	}

	function get_batches_of_wh_details()
	{
		$sel = '';
		$product_category = $this->input->post('product_type');
		$item_id = $this->input->post('item_id');
		$wh_id = $this->input->post('wh_id');
		$editbatchid = $this->input->post('editbatchid');
		$stk_id = $this->input->post('stk_id');
		$batch_type = $this->input->post('batch_type');

		$process_status_nmbr = '';
		$qry_getprocess_status = $this->obj_gwis_master->getprocess_statusmax(3);
		if ($qry_getprocess_status) {
			$dataprocessstatus = $qry_getprocess_status->result_array();
		}
		foreach ($dataprocessstatus as $row) {
			$process_status_nmbr = $row['process_status'];
		}
		if($batch_type == 'stock'){
		   $result = $this->obj_stock_batch->get_product_batches($item_id, $wh_id, $product_category, $process_status_nmbr, $stk_id,1);
	    }else{
	    	$result = $this->obj_stock_batch->get_product_batches($item_id, $wh_id, $product_category, $process_status_nmbr, $stk_id,0);
	    }
		if ($result) {
			$getbatch = $result->result_array();

			foreach ($getbatch as $row) {
				echo "<input type='hidden' name='field1' id='field1' value='" . $row['field1'] . "'>";
				echo "<input type='hidden' name='field2' id='field2' value='" . $row['field2'] . "'>";
				echo "<input type='hidden' name='field3' id='field3' value='" . $row['field3'] . "'>";
				echo "<input type='hidden' name='field4' id='field4' value='" . $row['field4'] . "'>";
				echo "<input type='hidden' name='field5' id='field5' value='" . $row['field5'] . "'>";
				echo "<input type='hidden' name='field6' id='field6' value='" . $row['field6'] . "'>";
				echo "<input type='hidden' name='field7' id='field7' value='" . $row['field7'] . "'>";
				echo "<input type='hidden' name='field8' id='field8' value='" . $row['field8'] . "'>";
				echo "<input type='hidden' name='field9' id='field9' value='" . $row['field9'] . "'>";
				echo "<input type='hidden' name='field10' id='field10' value='" . $row['field10'] . "'>";
				echo "<input type='hidden' name='wh_id_from_supplier' id='wh_id_from_supplier' value='" . $row['wh_id_from_supplier'] . "'>";
				echo "<input type='hidden' name='wh_id_from' id='wh_id_from' value='" . $row['wh_id_from'] . "'>";
				echo "<input type='hidden' name='driver_contract' id='driver_contract' value='" . $row['driver_contract'] . "'>";
				echo "<input type='hidden' name='driver_name' id='driver_name' value='" . $row['driver_name'] . "'>";
				echo "<input type='hidden' name='vehicle_reg' id='vehicle_reg' value='" . $row['vehicle_reg'] . "'>";
				echo "<input type='hidden' name='dc_no' id='dc_no' value='" . $row['dc_no'] . "'>";
				echo "<input type='hidden' name='dc_date' id='dc_date' value='" . $row['dc_date'] . "'>";
				echo "<input type='hidden' name='invoice' id='invoice' value='" . $row['invoice'] . "'>";
				echo "<input type='hidden' name='challan_type_detail' id='challan_type_detail' value='" . $row['challan_type_detail'] . "'>";
				echo "<input type='hidden' name='delivery_challan_type' id='delivery_challan_type' value='" . $row['delivery_challan_type'] . "'>";
				echo "<input type='hidden' name='ti_quantity' id='ti_quantity' value='" . $row['ti_quantity'] . "'>";
				echo "<input type='hidden' name='pi_quantity' id='pi_quantity' value='" . $row['pi_quantity'] . "'>";
				echo "<input type='hidden' name='dc_quantity' id='dc_quantity' value='" . $row['dc_quantity'] . "'>";
				echo "<input type='hidden' name='po_quantity' id='po_quantity' value='" . $row['po_quantity'] . "'>";
				echo "<input type='hidden' name='grn_quantity' id='grn_quantity' value='" . $row['grn_quantity'] . "'>";

				echo "<input type='hidden' name='stk_id' id='stk_id' value='" . $row['stk_id'] . "'>";

				echo "<input type='hidden' name='inspection_date' id='inspection_date' value='" . $row['inspection_date'] . "'>";
				echo "<input type='hidden' name='delivery_location' id='delivery_location' value='" . $row['delivery_location'] . "'>";
				echo "<input type='hidden' name='po_cmu_no' id='po_cmu_no' value='" . $row['po_cmu_no'] . "'>";
				echo "<input type='hidden' name='po_cmu_date' id='po_cmu_date' value='" . $row['po_cmu_date'] . "'>";
				echo "<input type='hidden' name='po_gf_no' id='po_gf_no' value='" . $row['po_gf_no'] . "'>";
				echo "<input type='hidden' name='po_gf_date' id='po_gf_date' value='" . $row['po_gf_date'] . "'>";
				echo "<input type='hidden' name='date_of_receiving' id='date_of_receiving' value='" . $row['date_of_receiving'] . "'>";
				echo "<input type='hidden' name='air_bill_no' id='air_bill_no' value='" . $row['air_bill_no'] . "'>";
				echo "<input type='hidden' name='shipment_no' id='shipment_no' value='" . $row['shipment_no'] . "'>";
				echo "<input type='hidden' name='origin_of_country' id='origin_of_country' value='" . $row['origin_of_country'] . "'>";
				echo "<input type='hidden' name='vehicle_type_and_plate' id='vehicle_type_and_plate' value='" . $row['vehicle_type_and_plate'] . "'>";
				echo "<input type='hidden' name='consignment_weight' id='consignment_weight' value='" . $row['consignment_weight'] . "'>";
			}
		}
	}

	function get_batches_of_wh_details_chng_prod()
	{
		$sel = '';
		$product_category = $this->input->post('product_type');
		$item_id = $this->input->post('item_id');
		$wh_id = $this->input->post('wh_id');
		$editbatchid = $this->input->post('editbatchid');
		$stk_id = $this->input->post('stk_id');

		$process_status_nmbr = '';
		$qry_getprocess_status = $this->obj_gwis_master->getprocess_statusmax(3);
		if ($qry_getprocess_status) {
			$dataprocessstatus = $qry_getprocess_status->result_array();
		}
		foreach ($dataprocessstatus as $row) {
			$process_status_nmbr = $row['process_status'];
		}

		$result = $this->obj_stock_batch->get_product_batches_adj($item_id, $wh_id, $product_category, $process_status_nmbr, $stk_id);
		$getbatch = $result->result_array();

		foreach ($getbatch as $row) {
			echo "<input type='hidden' name='field1' id='field1' value='" . $row['field1'] . "'>";
			echo "<input type='hidden' name='field2' id='field2' value='" . $row['field2'] . "'>";
			echo "<input type='hidden' name='field3' id='field3' value='" . $row['field3'] . "'>";
			echo "<input type='hidden' name='field4' id='field4' value='" . $row['field4'] . "'>";
			echo "<input type='hidden' name='field5' id='field5' value='" . $row['field5'] . "'>";
			echo "<input type='hidden' name='field6' id='field6' value='" . $row['field6'] . "'>";
			echo "<input type='hidden' name='field7' id='field7' value='" . $row['field7'] . "'>";
			echo "<input type='hidden' name='field8' id='field8' value='" . $row['field8'] . "'>";
			echo "<input type='hidden' name='field9' id='field9' value='" . $row['field9'] . "'>";
			echo "<input type='hidden' name='field10' id='field10' value='" . $row['field10'] . "'>";
			echo "<input type='hidden' name='wh_id_from_supplier' id='wh_id_from_supplier' value='" . $row['wh_id_from_supplier'] . "'>";
			echo "<input type='hidden' name='wh_id_from' id='wh_id_from' value='" . $row['wh_id_from'] . "'>";
			echo "<input type='hidden' name='driver_contract' id='driver_contract' value='" . $row['driver_contract'] . "'>";
			echo "<input type='hidden' name='driver_name' id='driver_name' value='" . $row['driver_name'] . "'>";
			echo "<input type='hidden' name='vehicle_reg' id='vehicle_reg' value='" . $row['vehicle_reg'] . "'>";
			echo "<input type='hidden' name='dc_no' id='dc_no' value='" . $row['dc_no'] . "'>";
			echo "<input type='hidden' name='dc_date' id='dc_date' value='" . $row['dc_date'] . "'>";
			echo "<input type='hidden' name='invoice' id='invoice' value='" . $row['invoice'] . "'>";
			echo "<input type='hidden' name='challan_type_detail' id='challan_type_detail' value='" . $row['challan_type_detail'] . "'>";
			echo "<input type='hidden' name='delivery_challan_type' id='delivery_challan_type' value='" . $row['delivery_challan_type'] . "'>";
			echo "<input type='hidden' name='ti_quantity' id='ti_quantity' value='" . $row['ti_quantity'] . "'>";
			echo "<input type='hidden' name='pi_quantity' id='pi_quantity' value='" . $row['pi_quantity'] . "'>";
			echo "<input type='hidden' name='dc_quantity' id='dc_quantity' value='" . $row['dc_quantity'] . "'>";
			echo "<input type='hidden' name='po_quantity' id='po_quantity' value='" . $row['po_quantity'] . "'>";
			echo "<input type='hidden' name='grn_quantity' id='grn_quantity' value='" . $row['grn_quantity'] . "'>";
		}
	}

	function get_batches_of_wh_details_adj()
	{
		$sel = '';
		$product_category = $this->input->post('product_type');
		$item_id = $this->input->post('item_id');
		$wh_id = $this->input->post('wh_id');
		$editbatchid = $this->input->post('editbatchid');
		$stk_id = $this->input->post('stk_id');

		$process_status_nmbr = '';
		$qry_getprocess_status = $this->obj_gwis_master->getprocess_statusmax(3);
		if ($qry_getprocess_status) {
			$dataprocessstatus = $qry_getprocess_status->result_array();
		}
		foreach ($dataprocessstatus as $row) {
			$process_status_nmbr = $row['process_status'];
		}

		$result = $this->obj_stock_batch->get_product_batches_adj($item_id, $wh_id, $product_category, $process_status_nmbr, $stk_id);
		if (isset($result) && !empty($result)) {
			$getbatch = $result->result_array();



			foreach ($getbatch as $row) {
				echo "<input type='hidden' name='field1' id='field1' value='" . $row['field1'] . "'>";
				echo "<input type='hidden' name='field2' id='field2' value='" . $row['field2'] . "'>";
				echo "<input type='hidden' name='field3' id='field3' value='" . $row['field3'] . "'>";
				echo "<input type='hidden' name='field4' id='field4' value='" . $row['field4'] . "'>";
				echo "<input type='hidden' name='field5' id='field5' value='" . $row['field5'] . "'>";
				echo "<input type='hidden' name='field6' id='field6' value='" . $row['field6'] . "'>";
				echo "<input type='hidden' name='field7' id='field7' value='" . $row['field7'] . "'>";
				echo "<input type='hidden' name='field8' id='field8' value='" . $row['field8'] . "'>";
				echo "<input type='hidden' name='field9' id='field9' value='" . $row['field9'] . "'>";
				echo "<input type='hidden' name='field10' id='field10' value='" . $row['field10'] . "'>";
				echo "<input type='hidden' name='wh_id_from_supplier' id='wh_id_from_supplier' value='" . $row['wh_id_from_supplier'] . "'>";
				echo "<input type='hidden' name='wh_id_from' id='wh_id_from' value='" . $row['wh_id_from'] . "'>";
				echo "<input type='hidden' name='driver_contract' id='driver_contract' value='" . $row['driver_contract'] . "'>";
				echo "<input type='hidden' name='driver_name' id='driver_name' value='" . $row['driver_name'] . "'>";
				echo "<input type='hidden' name='vehicle_reg' id='vehicle_reg' value='" . $row['vehicle_reg'] . "'>";
				echo "<input type='hidden' name='dc_no' id='dc_no' value='" . $row['dc_no'] . "'>";
				echo "<input type='hidden' name='dc_date' id='dc_date' value='" . $row['dc_date'] . "'>";
				echo "<input type='hidden' name='invoice' id='invoice' value='" . $row['invoice'] . "'>";
				echo "<input type='hidden' name='challan_type_detail' id='challan_type_detail' value='" . $row['challan_type_detail'] . "'>";
				echo "<input type='hidden' name='delivery_challan_type' id='delivery_challan_type' value='" . $row['delivery_challan_type'] . "'>";
				echo "<input type='hidden' name='ti_quantity' id='ti_quantity' value='" . $row['ti_quantity'] . "'>";
				echo "<input type='hidden' name='pi_quantity' id='pi_quantity' value='" . $row['pi_quantity'] . "'>";
				echo "<input type='hidden' name='dc_quantity' id='dc_quantity' value='" . $row['dc_quantity'] . "'>";
				echo "<input type='hidden' name='po_quantity' id='po_quantity' value='" . $row['po_quantity'] . "'>";
				echo "<input type='hidden' name='grn_quantity' id='grn_quantity' value='" . $row['grn_quantity'] . "'>";
			}
		}
	}

	function get_batches_of_wh_ledger()
	{
		$sel = '';
		$stk_id = '';
		$product_category = $this->input->post('product_type');
		$item_id = $this->input->post('item_id');
		$wh_id = $this->input->post('wh_id');
		$editbatchid = $this->input->post('editbatchid');
		if (isset($_REQUEST['stk_id'])) {
			$stk_id = $this->input->post('stk_id');
		}
		$process_status_nmbr = '';
		$qry_getprocess_status = $this->obj_gwis_master->getprocess_statusmax(3);
		if ($qry_getprocess_status) {
			$dataprocessstatus = $qry_getprocess_status->result_array();
		}
		foreach ($dataprocessstatus as $row) {
			$process_status_nmbr = $row['process_status'];
		}

		$result = $this->obj_stock_batch->get_product_batches($item_id, $wh_id, $product_category, $process_status_nmbr, $stk_id);
		$getbatch = $result->result_array();

		echo "<option value=''>Select</option>";
		foreach ($getbatch as $row) {
			if (isset($editbatchid) && $editbatchid == $row['batch_id']) {
				$sel = 'selected="selected"';
			} else {
				$sel = '';
			}
			echo "<option value=" . $row['batch_no'] . " " . $sel . "  >" . $row['batch_no'] . "</option>";
		}
	}

	function get_batches_of_wh_adj()
	{
		$sel = '';
		$product_category = $this->input->post('product_type');
		$item_id = $this->input->post('item_id');
		$wh_id = $this->input->post('wh_id');
		$editbatchid = $this->input->post('editbatchid');
		$stk_id = $this->input->post('stk_id');

		$process_status_nmbr = '';
		$qry_getprocess_status = $this->obj_gwis_master->getprocess_statusmax(3);
		if ($qry_getprocess_status) {
			$dataprocessstatus = $qry_getprocess_status->result_array();
		}
		foreach ($dataprocessstatus as $row) {
			$process_status_nmbr = $row['process_status'];
		}

		$result = $this->obj_stock_batch->get_product_batches_adj($item_id, $wh_id, $product_category, $process_status_nmbr, $stk_id);
		if ($result) {
			$getbatch = $result->result_array();
			echo "<option value=''>Select</option>";
			foreach ($getbatch as $row) {
				if (isset($editbatchid) && $editbatchid == $row['batch_id']) {
					$sel = 'selected="selected"';
				} else {
					$sel = '';
				}
				echo "<option value=" . $row['batch_id'] . " " . $sel . "  >" . $row['batch_no'] . "</option>";
			}
		}
		echo "<option value='others'>Others</option>";
	}

	function get_batches_of_wh_chng_prod()
	{
		$sel = '';
		$product_category = $this->input->post('product_type');
		$item_id = $this->input->post('item_id');
		$wh_id = $this->input->post('wh_id');
		$editbatchid = $this->input->post('editbatchid');
		$stk_id = $this->input->post('stk_id');

		$process_status_nmbr = '';
		$qry_getprocess_status = $this->obj_gwis_master->getprocess_statusmax(3);
		if ($qry_getprocess_status) {
			$dataprocessstatus = $qry_getprocess_status->result_array();
		}
		foreach ($dataprocessstatus as $row) {
			$process_status_nmbr = $row['process_status'];
		}

		$result = $this->obj_stock_batch->get_product_batches_chng_prod($item_id, $wh_id, $product_category, $process_status_nmbr, $stk_id);
		if ($result) {
			$getbatch = $result->result_array();
			echo "<option value=''>Select</option>";
			foreach ($getbatch as $row) {
				if (isset($editbatchid) && $editbatchid == $row['batch_id']) {
					$sel = 'selected="selected"';
				} else {
					$sel = '';
				}
				echo "<option value=" . $row['batch_id'] . "_" . $row['pk_id'] . " " . $sel . "  >" . $row['batch_no'] . "</option>";
			}
		}
	}

	function getproductfields()
	{
		$sel = '';
		$product_type = $this->input->post('product_type');
		$item_id = $this->input->post('item_id');
		//        $wh_id = $this->input->post('wh_id');
		//        $editbatchid = $this->input->post('editbatchid');
		$result = $this->obj_stock_batch->getproductfields($item_id, $product_type);
		$getproductfields = $result->result_array();

		$list_arr = $this->field_list->find_active_by_rank();
		if ($list_arr)
			$field_list = $list_arr->result_array();

		$unit_arr = $this->obj_lists->get_list(7);
		if ($unit_arr)
			$unit = $unit_arr->result_array();

		$doseform_arr = $this->obj_lists->get_list(8);
		if ($doseform_arr)
			$dose_form = $doseform_arr->result_array();
		//        foreach ($getproductfields as $row) {
		//            echo  $row['field_id'];
		//        }
		//        foreach ($getproductfields as $row) {
		//            $json_array['field_id'] = $row['field_id'];
		//            $json_array['fid'] = $row['fid'];
		//            $json_array['field_name'] = $row['field_name'];
		//            $json_array['is_mandatory'] = $row['is_mandatory'];
		//        }

		foreach ($getproductfields as $row) {
			foreach ($field_list as $row1) {
				$arr = explode(',', $row['field_id']);
				$arr2 = explode(',', $row['is_mandatory']);

				if (in_array($row1['pk_id'], $arr) && $row1['type'] == '1') {
					echo '<div class="col-md-3">
        <div class="control-group">
            <label class="example-text-input" for="wh_detail_info" >' . $row1['field_name'] . ' ';
					if (in_array($row1['pk_id'], $arr2)) {
						echo '<span style="color: red">*</span>';
					}
					echo '</label>
            <div class="controls">
                <input class="form-control" name="' . $row1['field_id'] . '" type="text" ';
					if (in_array($row1['pk_id'], $arr2)) {
						echo 'required';
					}
					echo '  />
            </div>
            </div>
        </div>';
				}

				if (in_array($row1['pk_id'], $arr) && $row1['type'] == '2') {

					echo '<div class="col-md-3">
        <div class="control-group">
            <label  class="example-text-input" for="wh_detail_info" >' . $row1['field_name'] . ' ';
					if (in_array($row1['pk_id'], $arr2)) {
						echo '<span style="color: red">*</span>';
					}
					echo '</label>
            <div class="controls">
                <input class="form-control datepick" name="' . $row1['field_id'] . '" id="productfielddate' . $row1['field_id'] . '" type="text" ';
					if (in_array($row1['pk_id'], $arr2)) {
						echo 'required';
					}
					echo ' value=' . date("m/d/Y") . ' />
            </div>
            </div>
        </div>';
				}

				if (in_array($row1['pk_id'], $arr) && $row1['type'] == '3') {

					echo '<div class="col-md-3">
        <div class="control-group">
            <label  class="example-text-input" for="wh_detail_info" >' . $row1['field_name'] . ' ';
					if (in_array($row1['pk_id'], $arr2)) {
						echo '<span style="color: red">*</span>';
					}
					echo '</label>
            <div class="controls">
                <input class="form-control" name="' . $row1['field_id'] . '" type="number" ';
					if (in_array($row1['pk_id'], $arr2)) {
						echo 'required';
					}
					echo ' value="" />
            </div>
            </div>
        </div>';
				}

				if (in_array($row1['pk_id'], $arr) && $row1['type'] == '4') {

					if ($row1['field_id'] == 'field7') {
						$combo = $unit;
					} else if ($row1['field_id'] == 'field11') {
						$combo = $dose_form;
					}

					echo '
        <div class="col-md-3">
            <label class="example-text-input" required >' . $row1['field_name'] . ' ';
					if (in_array($row1['pk_id'], $arr2)) {
						echo '<span style="color: red">*</span>';
					}
					echo ' </label>
            <div class="controls">
                <select class="dynamicselect2me input-medium"  name="' . $row1['field_id'] . '" id="' . $row1['field_id'] . '" ';
					if (in_array($row1['pk_id'], $arr2)) {
						echo 'required';
					}
					echo ' style="width:100%;padding:10%;">';
					echo '<option value="">Select</option>';
					foreach ($combo as $comborow) {
						echo '<option id=' . $comborow['pk_id'] . ' value=' . $comborow['pk_id'] . '  > ' . $comborow['name'] . ' </option>';
					}
					echo '</select>  
            </div>
        </div>';

					//         echo '<script language="javascript">
					//       if (Array.prototype.forEach) {
					//         var elems = Array.prototype.slice.call(document.querySelectorAll(".js-switch"));
					//
					//         elems.forEach(function(html) {
					//           var switchery = new Switchery(html);
					//         });
					//        } else {
					//               var elems = document.querySelectorAll(".js-switch");
					//
					//               for (var i = 0; i < elems.length; i++) {
					//                   var switchery = new Switchery(elems[i]);
					//                }
					//               }
					//          </script>';
				}
			}
		}

		//        echo json_encode($infos);
	}

	function get_available_prods_of_wh()
	{
		$id = $this->input->post('wh_id');
		$result = $this->obj_stock_batch->get_available_prods_of_wh($id);


		if (!empty($result)) {
			echo "<option value=\"\" >Select</option>";
			foreach ($result->result_object() as $row) {
				echo "<option value=" . $row->item_id . ">" . $row->product_name . "</option>";
			}
		}
	}

	function get_batch_info()
	{
		$batch_id = $_POST['batch_id'];
		$result = $this->obj_stock_batch->get_batch_info($batch_id);
		$json_array = array();
		foreach ($result->result_object() as $row) {
			$json_array['available_qty'] = $row->Qty;
			$json_array['expiry_date'] = $row->batch_expiry;
			$json_array['unit_price'] = $row->unit_price;
			$json_array['currency'] = $row->currency;
			$json_array['conversion_rate'] = $row->conversion_rate;
			$json_array['actual_rec_qty'] = $row->actual_rec_qty;
			//            $json_array['wh_location'] = $row->wh_location;
			$json_array['storage'] = $row->storage;
			$json_array['storage_id'] = $row->storage_id;
		}
		echo json_encode($json_array);
	}

	function get_batch_info_new()
	{
		$batch_id = $_POST['batch_id'];
		$chktemp = $this->obj_stock_batch->get_batch_tempinfos($batch_id);
		if ($chktemp) {
			$result = $this->obj_stock_batch->get_batch_info_new($batch_id);
		} else {
			$result = $this->obj_stock_batch->get_batch_info($batch_id);
		}
		$json_array = array();
		foreach ($result->result_object() as $row) {
			//            old code
			//            $json_array['available_qty'] = $row->Qty;
			//            new code
			if (isset($row->tempissue) && !empty($row->tempissue)) {
				$json_array['available_qty'] = ($row->Qty) + ($row->tempissue);
			} else {
				$json_array['available_qty'] = $row->Qty;
			}
			$json_array['reorder_date'] = $row->field10;
			$json_array['expiry_date'] = $row->batch_expiry;
			$json_array['unit_price'] = $row->unit_price;
			$json_array['currency'] = $row->currency;
			$json_array['conversion_rate'] = $row->conversion_rate;
			$json_array['actual_rec_qty'] = $row->actual_rec_qty;
			//            $json_array['wh_location'] = $row->wh_location;
			$json_array['storage'] = $row->storage;
			$json_array['storage_id'] = $row->storage_id;
		}
		echo json_encode($json_array);
	}

	function get_batch_info_chng_prod()
	{
		$ides = explode("_", $_POST['batch_id']);
		$batch_id = $ides[0];
		$result = $this->obj_stock_batch->get_batch_info($batch_id);
		$json_array = array();
		foreach ($result->result_object() as $row) {
			$json_array['available_qty'] = $row->Qty;
			$json_array['expiry_date'] = $row->batch_expiry;
			$json_array['unit_price'] = $row->unit_price;
			$json_array['currency'] = $row->currency;
			$json_array['conversion_rate'] = $row->conversion_rate;
			$json_array['actual_rec_qty'] = $row->actual_rec_qty;
			//            $json_array['wh_location'] = $row->wh_location;
			$json_array['storage'] = $row->storage;
			$json_array['storage_id'] = $row->storage_id;
		}
		echo json_encode($json_array);
	}

	function getprodinfo()
	{
		$prod_id = $_POST['item_id'];
		$stk_id = $this->input->post('stk_id');

		$process_status_nmbr = '';
		$qry_getprocess_status = $this->obj_gwis_master->getprocess_statusmax(3);
		if ($qry_getprocess_status) {
			$dataprocessstatus = $qry_getprocess_status->result_array();
		}
		foreach ($dataprocessstatus as $row) {
			$process_status_nmbr = $row['process_status'];
		}

		$result = $this->obj_stock_batch->getprodinfo($prod_id, $process_status_nmbr, $stk_id);
		$json_array = array();
		if ($result) {
			foreach ($result->result_object() as $row) {
				$json_array['available_qty'] = $row->Qty;
				$json_array['batchid'] = $row->batch_id;
				//            $json_array['expiry_date'] = $row->batch_expiry;
				$json_array['unit_price'] = $row->unit_price;
				$json_array['currency'] = $row->currency;
				$json_array['conversion_rate'] = $row->conversion_rate;
				$json_array['actual_rec_qty'] = $row->actual_rec_qty;
				$json_array['field1'] = $row->field1;
				$json_array['field2'] = $row->field2;
				$json_array['field3'] = $row->field3;
				$json_array['field4'] = $row->field4;
				$json_array['field5'] = $row->field5;
				$json_array['field6'] = $row->field6;
				$json_array['field7'] = $row->field7;
				$json_array['field8'] = $row->field8;
				$json_array['field9'] = $row->field9;
				$json_array['field10'] = $row->field10;
				$json_array['quantity'] = $row->quantity;
				$json_array['comments'] = $row->comments;
				$json_array['dc_quantity'] = $row->dc_quantity;
				$json_array['pi_quantity'] = $row->pi_quantity;
				$json_array['pi_comment'] = $row->pi_comment;
				$json_array['ti_comment'] = $row->ti_comment;
				$json_array['ti_quantity'] = $row->ti_quantity;
				$json_array['delivery_challan_type'] = $row->delivery_challan_type;
				$json_array['challan_type_detail'] = $row->challan_type_detail;
				$json_array['driver_name'] = $row->driver_name;
				$json_array['driver_contract'] = $row->driver_contract;
				$json_array['vehicle_reg'] = $row->vehicle_reg;
				$json_array['dc_no'] = $row->dc_no;
				$json_array['dc_date'] = $row->dc_date;
				$json_array['invoice'] = $row->invoice;
				$json_array['po_quantity'] = $row->po_quantity;
				$json_array['gwis_adj_status'] = $row->gwis_adj_status;
				$json_array['grn_quantity'] = $row->grn_quantity;
				$json_array['giv_quantity'] = $row->giv_quantity;
				$json_array['temperature_requirement'] = $row->temperature_requirement;
				$json_array['wh_id_from_supplier'] = $row->wh_id_from_supplier;
				$json_array['wh_id_from'] = $row->wh_id_from;

				$json_array['stk_id'] = $row->stk_id;

				$json_array['inspection_date'] = $row->inspection_date;
				$json_array['delivery_location'] = $row->delivery_location;
				$json_array['po_cmu_no'] = $row->po_cmu_no;
				$json_array['po_cmu_date'] = $row->po_cmu_date;
				$json_array['po_gf_no'] = $row->po_gf_no;
				$json_array['po_gf_date'] = $row->po_gf_date;
				$json_array['date_of_receiving'] = $row->date_of_receiving;
				$json_array['air_bill_no'] = $row->air_bill_no;
				$json_array['shipment_no'] = $row->shipment_no;
				$json_array['origin_of_country'] = $row->origin_of_country;
				$json_array['vehicle_type_and_plate'] = $row->vehicle_type_and_plate;
				$json_array['consignment_weight'] = $row->consignment_weight;

				//            $json_array['wh_location'] = $row->wh_location;
				$json_array['storage_id'] = $row->storage_id;
			}
		}
		echo json_encode($json_array);
	}

	function getprodinfo_chng_prod()
	{
		$prod_id = $_POST['item_id'];
		$stk_id = $this->input->post('stk_id');

		$sel = '';
		$product_category = $this->input->post('product_type');
		$wh_id = $this->input->post('wh_id');
		$editbatchid = $this->input->post('editbatchid');

		$process_status_nmbr = '';
		$qry_getprocess_status = $this->obj_gwis_master->getprocess_statusmax(3);
		if ($qry_getprocess_status) {
			$dataprocessstatus = $qry_getprocess_status->result_array();
		}
		foreach ($dataprocessstatus as $row) {
			$process_status_nmbr = $row['process_status'];
		}

		$result = $this->obj_stock_batch->getprodinfo_chng_prod($prod_id, $wh_id, $product_category, $process_status_nmbr, $stk_id);
		$json_array = array();
		foreach ($result->result_object() as $row) {
			$json_array['available_qty'] = $row->Qty;
			$json_array['batchid'] = $row->batch_id;
			$json_array['expiry_date'] = $row->batch_expiry;
			$json_array['unit_price'] = $row->unit_price;
			$json_array['currency'] = $row->currency;
			$json_array['conversion_rate'] = $row->conversion_rate;
			$json_array['actual_rec_qty'] = $row->actual_rec_qty;
			$json_array['field1'] = $row->field1;
			$json_array['field2'] = $row->field2;
			$json_array['field3'] = $row->field3;
			$json_array['field4'] = $row->field4;
			$json_array['field5'] = $row->field5;
			$json_array['field6'] = $row->field6;
			$json_array['field7'] = $row->field7;
			$json_array['field8'] = $row->field8;
			$json_array['field9'] = $row->field9;
			$json_array['field10'] = $row->field10;

			$json_array['detailpk_id'] = $row->pk_id;

			$json_array['wh_location'] = $row->wh_location;
			$json_array['storage'] = $row->storage;
		}
		echo json_encode($json_array);
	}

	function getprodinfo_adj()
	{
		$prod_id = $_POST['item_id'];
		$stk_id = $this->input->post('stk_id');

		$sel = '';
		$product_category = $this->input->post('product_type');
		$wh_id = $this->input->post('wh_id');
		$editbatchid = $this->input->post('editbatchid');

		$process_status_nmbr = '';
		$qry_getprocess_status = $this->obj_gwis_master->getprocess_statusmax(3);
		if ($qry_getprocess_status) {
			$dataprocessstatus = $qry_getprocess_status->result_array();
		}
		foreach ($dataprocessstatus as $row) {
			$process_status_nmbr = $row['process_status'];
		}

		$result = $this->obj_stock_batch->getprodinfo_adj($prod_id, $wh_id, $product_category, $process_status_nmbr, $stk_id);
		$json_array = array();
		foreach ($result->result_object() as $row) {
			$json_array['available_qty'] = $row->Qty;
			$json_array['batchid'] = $row->batch_id;
			$json_array['expiry_date'] = $row->batch_expiry;
			$json_array['unit_price'] = $row->unit_price;
			$json_array['currency'] = $row->currency;
			$json_array['conversion_rate'] = $row->conversion_rate;
			$json_array['actual_rec_qty'] = $row->actual_rec_qty;
			$json_array['field1'] = $row->field1;
			$json_array['field2'] = $row->field2;
			$json_array['field3'] = $row->field3;
			$json_array['field4'] = $row->field4;
			$json_array['field5'] = $row->field5;
			$json_array['field6'] = $row->field6;
			$json_array['field7'] = $row->field7;
			$json_array['field8'] = $row->field8;
			$json_array['field9'] = $row->field9;
			$json_array['field10'] = $row->field10;
		}
		echo json_encode($json_array);
	}

	function get_po_infos()
	{
		$pk_id = $_REQUEST['pk_id'];

		$result = $this->obj_po_infos->find_by_id($pk_id);
		$json_array = array();
		foreach ($result->result_object() as $row) {
			$json_array['date'] = $row->date;
		}
		echo json_encode($json_array);
	}

	function get_center_patients()
	{
		$type = $_POST['issue_type'];
		if ($type == 'centers') {
			$result = $this->obj_warehouse->find_all();

			echo "<option value=>Select</option>";
			foreach ($result->result_object() as $row) {
				echo "<option value=" . $row->pk_id . ">" . $row->warehouse_name . "</option>";
			}
		} else if ($type == 'patients') {
			$result = $this->obj_patient->find_all();
			echo "<option value=>Select</option>";
			foreach ($result->result_object() as $row) {
				echo "<option value=" . $row->pk_id . ">" . $row->full_name . "-" . $row->nic_no . "</option>";
			}
		}
	}

	function stock_receive_search()
	{

		if (isset($_REQUEST['submit'])) {
			$date1 = str_replace('/', '-', $_REQUEST['start_date']);
			$date2 = str_replace('/', '-', $_REQUEST['end_date']);
			//            print_r($date2);
			$date_from = date('Y-m-d', strtotime($date1));
			$date_to = date('Y-m-d', strtotime($date2));
			if (isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers'])) {
				$supplier_id = $_REQUEST['receive_from_suppliers'];
			} else {
				$supplier_id = '';
			}
			$data['result'] = $this->obj_stock_master->stock_search($date_from, $date_to, $supplier_id, 1);
		}
		//        $data['result'] = $this->obj_stock_master->stock_search(1);
		$data['page_title'] = 'Stock Receive Search';

		$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		if ($suppliers_arr)
			$data['suppliers'] = $suppliers_arr->result_array();

		$data['main_content'] = $this->load->view('inventory_management/stock_receive_search', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	function delivery_challan_form_search()
	{

		if (isset($_REQUEST['submit'])) {
			$date1 = str_replace('/', '-', $_REQUEST['start_date']);
			$date2 = str_replace('/', '-', $_REQUEST['end_date']);
			//            print_r($date2);
			$date_from = date('Y-m-d', strtotime($date1));
			$date_to = date('Y-m-d', strtotime($date2));
			if (isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers'])) {
				$supplier_id = $_REQUEST['receive_from_suppliers'];
			} else {
				$supplier_id = '';
			}
			$data['result'] = $this->obj_gwis_master->stock_search($date_from, $date_to, $supplier_id, 'gwis');
		}
		$data['page_title'] = 'GIWS Search';


		$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		if ($suppliers_arr)
			$data['suppliers'] = $suppliers_arr->result_array();


		$data['main_content'] = $this->load->view('inventory_management/delivery_challan_form_search', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	function tac_search()
	{

		if (isset($_REQUEST['submit'])) {
			$date1 = str_replace('/', '-', $_REQUEST['start_date']);
			$date2 = str_replace('/', '-', $_REQUEST['end_date']);
			//            print_r($date2);
			$date_from = date('Y-m-d', strtotime($date1));
			$date_to = date('Y-m-d', strtotime($date2));
			if (isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers'])) {
				$supplier_id = $_REQUEST['receive_from_suppliers'];
			} else {
				$supplier_id = '';
			}
			$data['result'] = $this->obj_gwis_master->stock_search($date_from, $date_to, $supplier_id, 'tac');
		}
		$data['page_title'] = 'GWIS Search';


		$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		if ($suppliers_arr)
			$data['suppliers'] = $suppliers_arr->result_array();


		$data['main_content'] = $this->load->view('inventory_management/tac_search', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	function document_approver()
	{

		if (isset($_REQUEST['submit'])) {
			$date1 = str_replace('/', '-', $_REQUEST['start_date']);
			$date2 = str_replace('/', '-', $_REQUEST['end_date']);
			//            print_r($date2);
			$date_from = date('Y-m-d', strtotime($date1));
			$date_to = date('Y-m-d', strtotime($date2));
			if (isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers'])) {
				$supplier_id = $_REQUEST['receive_from_suppliers'];
			} else {
				$supplier_id = '';
			}
			$data['result'] = $this->obj_gwis_master->stock_search($date_from, $date_to, $supplier_id, 0);
		}
		$data['page_title'] = 'GWIS Search';


		$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		if ($suppliers_arr)
			$data['suppliers'] = $suppliers_arr->result_array();


		$data['main_content'] = $this->load->view('inventory_management/delivery_challan_form_search', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	function gwis_search()
	{

		if (isset($_REQUEST['submit'])) {
			$date1 = str_replace('/', '-', $_REQUEST['start_date']);
			$date2 = str_replace('/', '-', $_REQUEST['end_date']);
			//            print_r($date2);
			$supplier_id = '';
			$date_from = date('Y-m-d', strtotime($date1));
			$date_to = date('Y-m-d', strtotime($date2));
			//            $supplier_id = $_REQUEST['receive_from_suppliers'];
			$data['result'] = $this->obj_gwis_master->stock_search($date_from, $date_to, $supplier_id, 0);
		}
		$data['page_title'] = 'GWIS Search';


		$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		if ($suppliers_arr)
			$data['suppliers'] = $suppliers_arr->result_array();


		$data['main_content'] = $this->load->view('inventory_management/gwis_search', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	function transport_req_form_search()
	{

		if (isset($_REQUEST['submit'])) {
			$date1 = str_replace('/', '-', $_REQUEST['start_date']);
			$date2 = str_replace('/', '-', $_REQUEST['end_date']);
			//            print_r($date2);
			$supplier_id = '';
			$date_from = date('Y-m-d', strtotime($date1));
			$date_to = date('Y-m-d', strtotime($date2));
			//            $supplier_id = $_REQUEST['receive_from_suppliers'];
			$data['result'] = $this->obj_gwis_master->transport_req_form_search($date_from, $date_to, $supplier_id, 5);
		}
		$data['page_title'] = 'Transport Reqest Search';


		$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		if ($suppliers_arr)
			$data['suppliers'] = $suppliers_arr->result_array();


		$data['main_content'] = $this->load->view('inventory_management/transport_req_form_search', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	function transport_req_form_search_new()
	{

		if (isset($_REQUEST['submit'])) {
			$date1 = str_replace('/', '-', $_REQUEST['start_date']);
			$date2 = str_replace('/', '-', $_REQUEST['end_date']);
			//            print_r($date2);
			$supplier_id = '';
			$date_from = date('Y-m-d', strtotime($date1));
			$date_to = date('Y-m-d', strtotime($date2));
			//            $supplier_id = $_REQUEST['receive_from_suppliers'];
			$data['result'] = $this->obj_transport_req_master->transport_req_form_search($date_from, $date_to, $supplier_id, 5);
		}
		$data['page_title'] = 'Transport Reqest Search';


		$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		if ($suppliers_arr)
			$data['suppliers'] = $suppliers_arr->result_array();


		$data['main_content'] = $this->load->view('inventory_management/transport_req_form_search_new', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	function gwis_stock_receive_search()
	{

		if (isset($_REQUEST['submit'])) {
			$date1 = str_replace('/', '-', $_REQUEST['start_date']);
			$date2 = str_replace('/', '-', $_REQUEST['end_date']);
			//            print_r($date2);
			$supplier_id = '';
			$date_from = date('Y-m-d', strtotime($date1));
			$date_to = date('Y-m-d', strtotime($date2));
			//            $supplier_id = $_REQUEST['receive_from_suppliers'];
			$data['result'] = $this->obj_gwis_master->stock_search($date_from, $date_to, $supplier_id, 3);
		}
		$data['page_title'] = 'Stock Receive Search';


		$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		if ($suppliers_arr)
			$data['suppliers'] = $suppliers_arr->result_array();


		$data['main_content'] = $this->load->view('inventory_management/gwis_stock_receive_search', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	function stock_issue_search()
	{

		if (isset($_REQUEST['submit'])) {
			$date1 = str_replace('/', '-', $_REQUEST['start_date']);
			$date2 = str_replace('/', '-', $_REQUEST['end_date']);
			//            print_r($date2);
			$date_from = date('Y-m-d', strtotime($date1));
			$date_to = date('Y-m-d', strtotime($date2));
			if (isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers'])) {
				$supplier_id = $_REQUEST['receive_from_suppliers'];
			} else {
				$supplier_id = '';
			}
			if (isset($_REQUEST['stakeholder']) && !empty($_REQUEST['stakeholder'])) {
				$stakeholder = $_REQUEST['stakeholder'];
			} else {
				$stakeholder = '';
			}
			if (isset($_REQUEST['warehouse']) && !empty($_REQUEST['warehouse'])) {
				$warehouse = $_REQUEST['warehouse'];
			} else {
				$warehouse = '';
			}
			$data['result'] = $this->obj_gwis_master->stock_search_by_stk_wh($date_from, $date_to, $supplier_id, 4, $stakeholder, $warehouse);
			$data['form'] = $_POST;
		}

		$stk_arr = $this->obj_reports_model->get_stakeholder();
		if ($stk_arr)
			$data['stakeholder'] = $stk_arr->result_array();

		$wh_arr = $this->obj_warehouse->find_all();
		if ($wh_arr)
			$data['warehouse'] = $wh_arr->result_array();

		$suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		if ($suppliers_arr)
			$data['suppliers'] = $suppliers_arr->result_array();

		$data['page_title'] = 'Stock Receive Search';

		$data['main_content'] = $this->load->view('inventory_management/stock_issue_search', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	function printIssue()
	{

		if (isset($_REQUEST['id'])) {

			//            $this->obj_stock_master->TranTypeID = 2;
			////            $this->obj_stock_master->TranNo = $receiveno;
			//            $this->obj_stock_master->WHIDTo = $_SESSION['warehouse_id'];
			//            //Get WH Stock By Issue No
			//            $stockReceive = $this->obj_stock_master->GetWHStockByIssueNo();
			//            
			//            if(isset($stockReceive) && !empty($stockReceive)){
			////                $count = mysql_num_rows($stockReceive);
			//                $data['stockReceive'] = $stockReceive->result_array();
			//            }

			$stockId = $_GET['id'];

			$getwhanduid = $this->obj_gwis_master->Getwhanduid($stockId);
			if (isset($getwhanduid) && !empty($getwhanduid)) {
				foreach ($getwhanduid->result_array() as $row1) {
					$wh_id = $row1['wh_id_from'];
					$userid = $row1['created_by'];
				}
			}
			//Get Stocks Issue List
			$stocks = $this->obj_gwis_master->GetStocksIssueList($userid, $wh_id, 2, $stockId);
			if (isset($stocks) && !empty($stocks)) {
				$data['stocks'] = $stocks->result_array();
				foreach ($stocks->result_array() as $row22) {
					$process_id1 = $row22['process_status'];
					$parent_id1 = $row22['parent_id'];
					if (!empty($parent_id1)) {
						$fcreator = $this->obj_gwis_master->GetUsercreatedID($process_id1, $parent_id1);
						$data['fcreator'] = $fcreator->result_array();
						$data['process_status_id'] = $row22['process_status'];
					} else {
						$data['fcreator'] = '';
						$data['process_status_id'] = '';
					}
				}
			}
			$stkId = '';
			//Get Header Info
			$info1 = $this->obj_gwis_master->Getheaderinfofir();
			if (isset($info1) && !empty($info1)) {
				foreach ($info1->result_array() as $row2) {
					$stkId = $row2['stkid'];
				}
				$data['whName'] = $info1->result_array();
			}

			$info2 = $this->obj_gwis_master->Getheaderinfosec($stkId);
			if (isset($info2) && !empty($info2)) {
				$data['logo'] = $info2->result_array();
			} else {
				$data['logo'] = '';
			}


			//            $date1 = str_replace('/', '-', $_REQUEST['start_date']);  
			//            $date2 = str_replace('/', '-', $_REQUEST['end_date']);  
			////            print_r($date2);
			//            $date_from = date('Y-m-d', strtotime($date1));
			//            $date_to   = date('Y-m-d', strtotime($date2));
			//            if(isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers']))
			//            {
			//                $supplier_id = $_REQUEST['receive_from_suppliers'];
			//            }
			//            else{
			//                $supplier_id = '';
			//            }
			//            $data['result'] = $this->obj_stock_master->stock_search($date_from,$date_to,$supplier_id,2);
		}


		//        $suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		//            if ($suppliers_arr)
		//                $data['suppliers'] = $suppliers_arr->result_array();

		$data['page_title'] = 'Print Issue';

		//        redirect(base_url() . 'inventory_management/printIssue', 'refresh');
		$data['main_content'] = $this->load->view('inventory_management/printIssue', $data, TRUE);
		$this->load->view('layout/print', $data);
	}

	function print_receive()
	{

		if (isset($_REQUEST['id'])) {

			//            $this->obj_stock_master->TranTypeID = 2;
			////            $this->obj_stock_master->TranNo = $receiveno;
			//            $this->obj_stock_master->WHIDTo = $_SESSION['warehouse_id'];
			//            //Get WH Stock By Issue No
			//            $stockReceive = $this->obj_stock_master->GetWHStockByIssueNo();
			//            
			//            if(isset($stockReceive) && !empty($stockReceive)){
			////                $count = mysql_num_rows($stockReceive);
			//                $data['stockReceive'] = $stockReceive->result_array();
			//            }

			$stockId = $_GET['id'];

			$getwhanduid = $this->obj_gwis_master->Getwhanduid($stockId);
			if (isset($getwhanduid) && !empty($getwhanduid)) {
				foreach ($getwhanduid->result_array() as $row1) {
					$wh_id = $row1['wh_id_from'];
					$userid = $row1['created_by'];
				}
			}
			//Get Stocks Issue List
			$stocks = $this->obj_gwis_master->GetStocksReceiveList($userid, $wh_id, 1, $stockId);
			if (isset($stocks) && !empty($stocks)) {
				$data['stocks'] = $stocks->result_array();
			}
			$stkId = '';
			//Get Header Info
			$info1 = $this->obj_gwis_master->Getheaderinfofir();
			if (isset($info1) && !empty($info1)) {
				foreach ($info1->result_array() as $row2) {
					$stkId = $row2['stkid'];
				}
				$data['whName'] = $info1->result_array();
			}

			$info2 = $this->obj_gwis_master->Getheaderinfosec($stkId);
			if (isset($info2) && !empty($info2)) {
				$data['logo'] = $info2->result_array();
			} else {
				$data['logo'] = '';
			}


			//            $date1 = str_replace('/', '-', $_REQUEST['start_date']);  
			//            $date2 = str_replace('/', '-', $_REQUEST['end_date']);  
			////            print_r($date2);
			//            $date_from = date('Y-m-d', strtotime($date1));
			//            $date_to   = date('Y-m-d', strtotime($date2));
			//            if(isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers']))
			//            {
			//                $supplier_id = $_REQUEST['receive_from_suppliers'];
			//            }
			//            else{
			//                $supplier_id = '';
			//            }
			//            $data['result'] = $this->obj_stock_master->stock_search($date_from,$date_to,$supplier_id,2);
		}


		//        $suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		//            if ($suppliers_arr)
		//                $data['suppliers'] = $suppliers_arr->result_array();

		$data['page_title'] = 'Print Receive';

		//        redirect(base_url() . 'inventory_management/printIssue', 'refresh');
		$data['main_content'] = $this->load->view('inventory_management/print_receive', $data, TRUE);
		$this->load->view('layout/print', $data);
	}

	function print_adjst()
	{

		if (isset($_REQUEST['id'])) {

			$stockId = $_GET['id'];

			$getwhanduid = $this->obj_gwis_master->Getwhanduid($stockId);
			if (isset($getwhanduid) && !empty($getwhanduid)) {
				foreach ($getwhanduid->result_array() as $row1) {
					$wh_id = $row1['wh_id_from'];
					$userid = $row1['created_by'];
				}
			}
			//Get Stocks Issue List
			$stocks = $this->obj_gwis_master->GetStocksReceiveList($userid, $wh_id, 1, $stockId);
			if (isset($stocks) && !empty($stocks)) {
				$data['stocks'] = $stocks->result_array();
			}
			$stkId = '';
			//Get Header Info
			$info1 = $this->obj_gwis_master->Getheaderinfofir();
			if (isset($info1) && !empty($info1)) {
				foreach ($info1->result_array() as $row2) {
					$stkId = $row2['stkid'];
				}
				$data['whName'] = $info1->result_array();
			}

			$info2 = $this->obj_gwis_master->Getheaderinfosec($stkId);
			if (isset($info2) && !empty($info2)) {
				$data['logo'] = $info2->result_array();
			} else {
				$data['logo'] = '';
			}
		}
		$data['page_title'] = 'Print Adjustment';
		$data['main_content'] = $this->load->view('inventory_management/print_adjst', $data, TRUE);
		$this->load->view('layout/print', $data);
	}

	function print_gwis()
	{

		if (isset($_REQUEST['id'])) {

			//            $this->obj_stock_master->TranTypeID = 2;
			////            $this->obj_stock_master->TranNo = $receiveno;
			//            $this->obj_stock_master->WHIDTo = $_SESSION['warehouse_id'];
			//            //Get WH Stock By Issue No
			//            $stockReceive = $this->obj_stock_master->GetWHStockByIssueNo();
			//            
			//            if(isset($stockReceive) && !empty($stockReceive)){
			////                $count = mysql_num_rows($stockReceive);
			//                $data['stockReceive'] = $stockReceive->result_array();
			//            }

			$stockId = $_GET['id'];

			$getwhanduid = $this->obj_gwis_master->Getwhanduid($stockId);
			if (isset($getwhanduid) && !empty($getwhanduid)) {
				foreach ($getwhanduid->result_array() as $row1) {
					$wh_id = $row1['wh_id_from'];
					$userid = $row1['created_by'];
				}
			}
			//Get Stocks Issue List
			$stocks = $this->obj_gwis_master->GetStocksGwisList($userid, $wh_id, 1, $stockId);
			if (isset($stocks) && !empty($stocks)) {
				$data['stocks'] = $stocks->result_array();
				foreach ($stocks->result_array() as $row22) {
					$process_id1 = $row22['process_status'];
					$parent_id1 = $row22['parent_id'];
					if (!empty($parent_id1)) {
						$fcreator = $this->obj_gwis_master->GetUsercreatedID($process_id1, $parent_id1);
						$data['fcreator'] = $fcreator->result_array();
						$data['process_status_id'] = $row22['process_status'];
					} else {
						$data['fcreator'] = '';
						$data['process_status_id'] = '';
					}
				}
			}
			$stkId = '';
			//Get Header Info
			$info1 = $this->obj_gwis_master->Getheaderinfofir();
			if (isset($info1) && !empty($info1)) {
				foreach ($info1->result_array() as $row2) {
					$stkId = $row2['stkid'];
				}
				$data['whName'] = $info1->result_array();
			}

			$info2 = $this->obj_gwis_master->Getheaderinfosec($stkId);
			if (isset($info2) && !empty($info2)) {
				$data['logo'] = $info2->result_array();
			} else {
				$data['logo'] = '';
			}


			//            $date1 = str_replace('/', '-', $_REQUEST['start_date']);  
			//            $date2 = str_replace('/', '-', $_REQUEST['end_date']);  
			////            print_r($date2);
			//            $date_from = date('Y-m-d', strtotime($date1));
			//            $date_to   = date('Y-m-d', strtotime($date2));
			//            if(isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers']))
			//            {
			//                $supplier_id = $_REQUEST['receive_from_suppliers'];
			//            }
			//            else{
			//                $supplier_id = '';
			//            }
			//            $data['result'] = $this->obj_stock_master->stock_search($date_from,$date_to,$supplier_id,2);
		}


		//        $suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		//            if ($suppliers_arr)
		//                $data['suppliers'] = $suppliers_arr->result_array();

		$data['page_title'] = 'Print GWIS';

		//        echo '<pre>';
		//        print_r($data);
		//        echo '</pre>';
		//        exit;

		$data['main_content'] = $this->load->view('inventory_management/print_gwis', $data, TRUE);
		$this->load->view('layout/print', $data);
	}

	function print_tac()
	{

		if (isset($_REQUEST['id'])) {

			//            $this->obj_stock_master->TranTypeID = 2;
			////            $this->obj_stock_master->TranNo = $receiveno;
			//            $this->obj_stock_master->WHIDTo = $_SESSION['warehouse_id'];
			//            //Get WH Stock By Issue No
			//            $stockReceive = $this->obj_stock_master->GetWHStockByIssueNo();
			//            
			//            if(isset($stockReceive) && !empty($stockReceive)){
			////                $count = mysql_num_rows($stockReceive);
			//                $data['stockReceive'] = $stockReceive->result_array();
			//            }

			$stockId = $_GET['id'];

			$getwhanduid = $this->obj_gwis_master->Getwhanduid($stockId);
			if (isset($getwhanduid) && !empty($getwhanduid)) {
				foreach ($getwhanduid->result_array() as $row1) {
					$wh_id = $row1['wh_id_from'];
					$userid = $row1['created_by'];
				}
			}
			//Get Stocks Issue List
			$stocks = $this->obj_gwis_master->GetStocksTacList($userid, $wh_id, 1, $stockId);
			if (isset($stocks) && !empty($stocks)) {
				$data['stocks'] = $stocks->result_array();
			}
			$stkId = '';
			//Get Header Info
			$info1 = $this->obj_gwis_master->Getheaderinfofir();
			if (isset($info1) && !empty($info1)) {
				foreach ($info1->result_array() as $row2) {
					$stkId = $row2['stkid'];
				}
				$data['whName'] = $info1->result_array();
			}

			$info2 = $this->obj_gwis_master->Getheaderinfosec($stkId);
			if (isset($info2) && !empty($info2)) {
				$data['logo'] = $info2->result_array();
			} else {
				$data['logo'] = '';
			}


			//            $date1 = str_replace('/', '-', $_REQUEST['start_date']);  
			//            $date2 = str_replace('/', '-', $_REQUEST['end_date']);  
			////            print_r($date2);
			//            $date_from = date('Y-m-d', strtotime($date1));
			//            $date_to   = date('Y-m-d', strtotime($date2));
			//            if(isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers']))
			//            {
			//                $supplier_id = $_REQUEST['receive_from_suppliers'];
			//            }
			//            else{
			//                $supplier_id = '';
			//            }
			//            $data['result'] = $this->obj_stock_master->stock_search($date_from,$date_to,$supplier_id,2);
		}


		//        $suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		//            if ($suppliers_arr)
		//                $data['suppliers'] = $suppliers_arr->result_array();

		$data['page_title'] = 'Print TAC';

		//        redirect(base_url() . 'inventory_management/printIssue', 'refresh');
		$data['main_content'] = $this->load->view('inventory_management/print_tac', $data, TRUE);
		$this->load->view('layout/print', $data);
	}

	function transport_req_form_print()
	{

		if (isset($_REQUEST['id'])) {

			//            $this->obj_stock_master->TranTypeID = 2;
			////            $this->obj_stock_master->TranNo = $receiveno;
			//            $this->obj_stock_master->WHIDTo = $_SESSION['warehouse_id'];
			//            //Get WH Stock By Issue No
			//            $stockReceive = $this->obj_stock_master->GetWHStockByIssueNo();
			//            
			//            if(isset($stockReceive) && !empty($stockReceive)){
			////                $count = mysql_num_rows($stockReceive);
			//                $data['stockReceive'] = $stockReceive->result_array();
			//            }

			$stockId = $_GET['id'];

			$getwhanduid = $this->obj_gwis_master->Getwhanduid($stockId);
			if (isset($getwhanduid) && !empty($getwhanduid)) {
				foreach ($getwhanduid->result_array() as $row1) {
					$wh_id = $row1['wh_id_from'];
					$userid = $row1['created_by'];
				}
			}
			//Get Stocks Issue List
			$stocks = $this->obj_gwis_master->GetStocksIssueList($userid, $wh_id, 1, $stockId);
			if (isset($stocks) && !empty($stocks)) {
				$data['stocks'] = $stocks->result_array();
			}
			$stkId = '';
			//Get Header Info
			$info1 = $this->obj_gwis_master->Getheaderinfofir();
			if (isset($info1) && !empty($info1)) {
				foreach ($info1->result_array() as $row2) {
					$stkId = $row2['stkid'];
				}
				$data['whName'] = $info1->result_array();
			}

			$info2 = $this->obj_gwis_master->Getheaderinfosec($stkId);
			if (isset($info2) && !empty($info2)) {
				$data['logo'] = $info2->result_array();
			} else {
				$data['logo'] = '';
			}


			//            $date1 = str_replace('/', '-', $_REQUEST['start_date']);  
			//            $date2 = str_replace('/', '-', $_REQUEST['end_date']);  
			////            print_r($date2);
			//            $date_from = date('Y-m-d', strtotime($date1));
			//            $date_to   = date('Y-m-d', strtotime($date2));
			//            if(isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers']))
			//            {
			//                $supplier_id = $_REQUEST['receive_from_suppliers'];
			//            }
			//            else{
			//                $supplier_id = '';
			//            }
			//            $data['result'] = $this->obj_stock_master->stock_search($date_from,$date_to,$supplier_id,2);
		}


		//        $suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		//            if ($suppliers_arr)
		//                $data['suppliers'] = $suppliers_arr->result_array();

		$data['page_title'] = 'Print Transport Request';

		//        redirect(base_url() . 'inventory_management/printIssue', 'refresh');
		$data['main_content'] = $this->load->view('inventory_management/transport_req_form_print', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	function transport_req_form_print_new()
	{

		if (isset($_REQUEST['id'])) {

			//            $this->obj_stock_master->TranTypeID = 2;
			////            $this->obj_stock_master->TranNo = $receiveno;
			//            $this->obj_stock_master->WHIDTo = $_SESSION['warehouse_id'];
			//            //Get WH Stock By Issue No
			//            $stockReceive = $this->obj_stock_master->GetWHStockByIssueNo();
			//            
			//            if(isset($stockReceive) && !empty($stockReceive)){
			////                $count = mysql_num_rows($stockReceive);
			//                $data['stockReceive'] = $stockReceive->result_array();
			//            }

			$stockId = $_GET['id'];
			$userid = '';
			$wh_id = '';
			//            $getwhanduid = $this->obj_gwis_master->Getwhanduid($stockId);
			//            if(isset($getwhanduid) && !empty($getwhanduid)){
			//                foreach ($getwhanduid->result_array() as $row1)
			//                {
			//                    $wh_id = $row1['wh_id_from'];
			//                    $userid = $row1['created_by'];
			//                }
			//            }
			//Get Stocks Issue List
			$stocks_vehicle = $this->obj_transport_req_master->GetStocksIssueList_transport_req_vehicle($userid, $wh_id, 1, $stockId);
			if (isset($stocks_vehicle) && !empty($stocks_vehicle)) {
				$data['stocks_vehicle'] = $stocks_vehicle->result_array();
			}

			$stocks_prod = $this->obj_transport_req_master->GetStocksIssueList_transport_req_prod($userid, $wh_id, 1, $stockId);
			if (isset($stocks_prod) && !empty($stocks_prod)) {
				$data['stocks_prod'] = $stocks_prod->result_array();
			}

			$stkId = '';
			//Get Header Info
			//            $info1 = $this->obj_gwis_master->Getheaderinfofir();
			//            if(isset($info1) && !empty($info1)){
			//                foreach ($info1->result_array() as $row2)
			//                {
			//                    $stkId = $row2['stkid'];
			//                }
			//                $data['whName'] = $info1->result_array();
			//            }
			//            $info2 = $this->obj_gwis_master->Getheaderinfosec($stkId);
			//            if(isset($info2) && !empty($info2)){
			//                $data['logo'] = $info2->result_array();
			//            }
			//            else{
			$data['logo'] = '';
			//            }
			//            $date1 = str_replace('/', '-', $_REQUEST['start_date']);  
			//            $date2 = str_replace('/', '-', $_REQUEST['end_date']);  
			////            print_r($date2);
			//            $date_from = date('Y-m-d', strtotime($date1));
			//            $date_to   = date('Y-m-d', strtotime($date2));
			//            if(isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers']))
			//            {
			//                $supplier_id = $_REQUEST['receive_from_suppliers'];
			//            }
			//            else{
			//                $supplier_id = '';
			//            }
			//            $data['result'] = $this->obj_stock_master->stock_search($date_from,$date_to,$supplier_id,2);
		}


		//        $suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		//            if ($suppliers_arr)
		//                $data['suppliers'] = $suppliers_arr->result_array();

		$data['page_title'] = 'Print Transport Request';

		//        redirect(base_url() . 'inventory_management/printIssue', 'refresh');
		$data['main_content'] = $this->load->view('inventory_management/transport_req_form_print_new', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	function save_temporary_records()
	{
		$stock_master_id = $_POST['stock_master_id'];
		$this->obj_gwis_master->save_master_temp($stock_master_id);
		$this->obj_gwis_detail->save_details_temp($stock_master_id);
	}

	function save_temporary_records_transportreq()
	{
		$stock_master_id = $_POST['stock_master_id'];
		$this->obj_transport_req_master->save_master_temp($stock_master_id);
		$this->obj_transport_req_detail->save_details_temp($stock_master_id);
		$this->obj_transport_product_info->save_transport_product_temp($stock_master_id);
	}

	function acknowledge_records()
	{
		$data['result'] = $this->obj_stock_master->get_issued_records();
		$data['page_title'] = 'Acknowledge Issue';
		$data['main_content'] = $this->load->view('inventory_management/acknowledge_records', $data, TRUE);
		$this->load->view('layout/main', $data);
	}

	function issue_to_receive()
	{
		//submit data for the Acknowledgement of stock receipt
		$stock_master_array = array_unique($_REQUEST['approved']);
		$stock_master_id = '';
		foreach ($stock_master_array as $key => $value) {
			$result = $this->obj_stock_master->find_by_id($value);
			foreach ($result->result_array() as $row) {

				$this->obj_stock_master->transaction_date = $row['transaction_date'];
				$this->obj_stock_master->transaction_type_id = 1;
				$this->obj_stock_master->transaction_reference = $row['transaction_reference'];
				$this->obj_stock_master->warehouse_from = $row['warehouse_from'];
				$this->obj_stock_master->warehouse_to = $row['warehouse_to'];
				$this->obj_stock_master->created_by = $_SESSION['id'];
				$this->obj_stock_master->created_on = date("Y-m-d");
				$this->obj_stock_master->temp = 0;
				$this->obj_stock_master->issuance_to = 'centers';
				$this->obj_stock_master->remarks = $row['remarks'];
				$this->obj_stock_master->pk_id = NULL;

				$stock_master_id = $this->obj_stock_master->save();
				$wh_to = $row['warehouse_to'];
				//               
				$result_details = $this->obj_stock_detail->find_by_master_id($value);
				//                echo 'A:<pre>';
				//                print_r($stock_master_array);
				//                print_r($this->obj_stock_master);
				//                print_r($result_details->result_array());
				//                echo '</pre>';
				//                exit;
				foreach ($result_details->result_array() as $row_1) {
					unset($this->obj_stock_batch->batch_id);
					$res_batch = $this->obj_stock_batch->find_by_id($row_1['batch_id']);

					$this->obj_stock_batch->batch_number = $res_batch['batch_number'];
					$this->obj_stock_batch->batch_expiry = date('Y-m-d', strtotime($res_batch['batch_expiry']));
					$this->obj_stock_batch->manufacturing_date = date('Y-m-d', strtotime($res_batch['manufacturing_date']));
					$this->obj_stock_batch->item_id = $res_batch['item_id'];
					$this->obj_stock_batch->wh_id = $wh_to;
					$this->obj_stock_batch->quantity = (abs($row_1['quantity']));
					$this->obj_stock_batch->funding_source = $res_batch['funding_source'];
					$this->obj_stock_batch->manufacturer = $res_batch['manufacturer'];
					//                    echo 'BC:<pre>';
					//                    print_r($res_batch);
					//                    print_r($this->obj_stock_batch);
					//                    echo '</pre>';
					//                    exit;
					$stock_batch_id = $this->obj_stock_batch->save();

					$this->obj_stock_detail->stock_master_id = $stock_master_id;
					$this->obj_stock_detail->batch_id = $stock_batch_id;
					$this->obj_stock_detail->quantity = ltrim($row_1['quantity'], '-');
					$this->obj_stock_detail->temp = 0;
					$this->obj_stock_detail->save();
				}
				//                 echo 'A:<pre>';
				//                print_r($stock_master_array);
				//                print_r($this->obj_stock_master);
				//                print_r($result_details->result_array());
				//                echo '</pre>';
				//                exit;
				$this->obj_stock_master->pk_id = $stock_master_id;
				$this->obj_stock_master->linked_transaction = $value;
				$this->obj_stock_master->link_trans();

				$this->obj_stock_master->pk_id = $value;
				$this->obj_stock_master->mark_received();
			}
			//             echo 'D:';print_r($stock_master_id);
		}
		//        echo 'final exit';
		//        exit;
		redirect(base_url() . 'inventory_management/stock_receive_search', 'refresh');
	}

 

	

	public function ajax_delgsi()
	{
		//		$lab_master = new patient_lab_master_model();
		//		$lab_master->pk_id = $_POST['pk_id'];
		//		$pk_id = $lab_master->delete();
		//
		//		$lab_master->patient_id = $_POST['p_id'];
		//		$data['patient_labtest'] = $lab_master->find_by_id();
		$this->obj_gwis_detail->pk_id = $_REQUEST['pk_id'];
		$this->obj_gwis_detail->fk_stock_id = $_REQUEST['fk_stock_id'];
		$this->obj_stock_batch->Qty = $_REQUEST['quantity'];
		//        $status = $_REQUEST['itm_status'];
		//        $this->obj_stock_detail->deactivate($id, $status);
		//            $this->obj_stock_batch->updateQty($_REQUEST['batch_id']);

		$this->obj_gwis_detail->delete();
		//                $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($_REQUEST['fk_stock_id']);
		$this->load->view('inventory_management/stock_issue', $data);
	}

	public function ajax_deltvreq()
	{
		//		$lab_master = new patient_lab_master_model();
		//		$lab_master->pk_id = $_POST['pk_id'];
		//		$pk_id = $lab_master->delete();
		//
		//		$lab_master->patient_id = $_POST['p_id'];
		//		$data['patient_labtest'] = $lab_master->find_by_id();
		$this->obj_transport_req_detail->pk_id = $_REQUEST['pk_id'];
		//        $status = $_REQUEST['itm_status'];
		//        $this->obj_stock_detail->deactivate($id, $status);
		$this->obj_transport_req_detail->delete();
		//                $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($_REQUEST['fk_stock_id']);
		$this->load->view('inventory_management/transport_req_form_new', $data);
	}

	public function ajax_deltpreq()
	{
		//		$lab_master = new patient_lab_master_model();
		//		$lab_master->pk_id = $_POST['pk_id'];
		//		$pk_id = $lab_master->delete();
		//
		//		$lab_master->patient_id = $_POST['p_id'];
		//		$data['patient_labtest'] = $lab_master->find_by_id();
		$this->obj_transport_product_info->pk_id = $_REQUEST['pk_id'];
		//        $status = $_REQUEST['itm_status'];
		//        $this->obj_stock_detail->deactivate($id, $status);
		$this->obj_transport_product_info->delete();
		//                $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($_REQUEST['fk_stock_id']);
		$this->load->view('inventory_management/transport_req_form_new', $data);
	}

	public function ajax_delsr()
	{
		//		$lab_master = new patient_lab_master_model();
		//		$lab_master->pk_id = $_POST['pk_id'];
		//		$pk_id = $lab_master->delete();
		//
		//		$lab_master->patient_id = $_POST['p_id'];
		//		$data['patient_labtest'] = $lab_master->find_by_id();
		$this->obj_stock_detail->PkDetailID = $_REQUEST['pk_id'];
		//        $status = $_REQUEST['itm_status'];
		//        $this->obj_stock_detail->deactivate($id, $status);
		$this->obj_stock_detail->deletesr();
		//                $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($_REQUEST['fk_stock_id']);
		$this->load->view('inventory_management/stock_receive', $data);
	}

	public function deletes()
	{ // you arent supplying any arguments in url of ajax call 
		$this->obj_gwis_detail->pk_id = $this->input->post('pk_id'); // get the post data
		$hapus = $this->obj_gwis_detail->delete();
		if ($hapus) {
			echo $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($_REQUEST['fk_stock_id']);
			//                echo $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($this->input->post('fk_stock_id'));
			//                echo $this->load->view('inventory_management/delivery_challan_form', $data);
			//                echo true;
		} else {
			echo false;
		}
	}

	public function transport_req_from()
	{

		//        if (!empty($_POST) && empty($_REQUEST['issue_no'])) {
		if (!empty($_POST)) {
			//            print_r($_REQUEST['stockid']);exit;
			if (isset($_POST['pk_id'])) {
				$this->obj->pk_id = $_POST['pk_id'];
			}





			//            if(count($_REQUEST['stockid']) == $_REQUEST['totalrows'])
			//            {
			//            }
			//check stock id
			if (isset($_REQUEST['stockid']) && !empty($_REQUEST['stockid'])) {
				//get stock id
				$stock_id = $_REQUEST['stockid'];

				$type_id = 1;
				//find by stock id
				//        $stockDetail = $objStockDetail->find_by_stock_id($stock_id);
				//check remarks
				if (isset($_REQUEST['remarks']) && !empty($_REQUEST['remarks'])) {
					//get remarks
					$remarks = $_REQUEST['remarks'];
				} else {
					$remarks = "";
				}
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
				}
				if (isset($_REQUEST['count']) && !empty($_REQUEST['count'])) {
					$count_o = $_REQUEST['count'];
				}
				//check receive date 
				if (isset($_REQUEST['rec_date']) && !empty($_REQUEST['rec_date'])) {
					//get receive date
					$rec_date = $_REQUEST['rec_date'];
				}
				//check receive reference
				if (isset($_REQUEST['rec_ref']) && !empty($_REQUEST['rec_ref'])) {
					//get receive reference
					$rec_ref = $_REQUEST['rec_ref'];
				} else {
					$rec_ref = $_REQUEST['issue_no'];
				}
				//check vvm
				if (isset($_REQUEST['vvmstage']) && !empty($_REQUEST['vvmstage'])) {
					//get vvm
					$vvmstage = $_REQUEST['vvmstage'];
				}
				//check cold chain
				if (isset($_REQUEST['cold_chain']) && !empty($_REQUEST['cold_chain'])) {
					//get cold chain
					$cold_chain = $_REQUEST['cold_chain'];
				}
			}
			//            
			//            
			//            
			//            
			//            
			//            
			//            
			if (isset($_REQUEST['stockid']) && !empty($_REQUEST['stockid'])) {
				$StockID = '';

				$approvefrom = $_REQUEST['approve_from'];
				$approveto = $_REQUEST['approve_to'];
				$processtatus = $_REQUEST['process_status'];
				$finalstatus = $_REQUEST['final_status'];
				//               $electronic_approval = $_REQUEST['approve_or_rej'];
				//               $comment = $_REQUEST['comment'];
				//get stock id
				$stock_ids = $_REQUEST['stockid'];
				$count = count($stock_ids);

				$array_keymax = max(array_keys($stock_ids));

				foreach ($stock_ids as $index => $detail_id) {
					if (isset($_REQUEST['itm_id']) && !empty($_REQUEST['itm_id'])) {
						//get cold chain
						$itmid = $_REQUEST['itm_id'];
						//                    $item_id = $itmid[$index];
						$item_id = '1';
					}
				}


				//        print_r($stock_ids);exit;
				$masterloop = 1;
				$rvoucher = 1;
				//        foreach ($_REQUEST['approvalcode'] as $indx => $detail_ida) {
				//$electronic_approval[$index] == '1' && $electronic_approval[$index] == '2'
				//difference is fk_stock_id now i have changed this due to some reasons 



				foreach ($stock_ids as $index => $detail_id) {


					//            if(count($_REQUEST['approvalcode']) >= $masterloop && $_REQUEST['rejected_voucher'] != '2')
					//            {
					//                $missing = $_REQUEST['missing'];
					//get type
					//                $type = $_REQUEST['types'];
					//find by detail id
					//                print_r($detail_id);exit;
					$stockDetail = $this->obj_gwis_detail->find_by_detail_id($detail_id);
					$find_master_exist = $this->obj_gwis_detail->find_master_exist($issue_no);

					if ($find_master_exist) {
						$find_master_exist_id = $find_master_exist->result_array();

						foreach ($find_master_exist_id as $rowes) {
							$StockID = $rowes['pk_id'];
						}
					}
					//                $count_find_master_exist = mysql_num_rows($find_master_exist);
					//                echo $count_find_master_exist;exit;
					//
					if ($stockDetail && empty($find_master_exist)) {
						//fetch results
						//                    $data = mysql_fetch_object($stockDetail);
						//                    $this->obj_gwis_master->pk_id = $stock_ids[$index];
						//                    if(isset($_REQUEST['pkmasterid']) && !empty($_REQUEST['pkmasterid']))
						//                    {
						//                        $this->obj_gwis_master->pk_id = $_REQUEST['pkmasterid'];
						//                    }
						//                    else{
						//                        $this->obj_gwis_master->pk_id = $_REQUEST['stock_id'];
						//                    }
						$this->obj_gwis_master->status_id = 5;
						if (count($_REQUEST['approvalcode']) == $masterloop) {
							$this->obj_gwis_master->active_process = 1;
						}
						//                    $this->obj_gwis_master->process_status = $processtatus[$indx];
						//                    $this->obj_gwis_master->approve_from = $approvefrom[$indx];
						//                    $this->obj_gwis_master->approve_to = $approveto[$indx];
						//                    $this->obj_gwis_master->final_status = $finalstatus[$indx];
						//User From
						$this->obj_gwis_master->user_from = 1;
						//User To
						$this->obj_gwis_master->user_to = 1;
						//transaction type
						//                    $this->obj_gwis_master->TranTypeID = $type[$index];
						//transaction date
						date_default_timezone_set('Asia/Karachi');
						$receivedatetime = date('Y-m-d h:i:s', time());
						$this->obj_gwis_master->tran_date = $receivedatetime;
						//transaction reference
						$this->obj_gwis_master->tran_ref = $rec_ref;
						//from warehouse
						$this->obj_gwis_master->wh_id_from = $_REQUEST['wh_from'];
						$this->obj_gwis_master->wh_id_from_supplier = $_REQUEST['wh_from_supplier'];
						//                    //to warehouse
						$this->obj_gwis_master->wh_id_to = $_REQUEST['wh_id_to'];
						//created by
						$this->obj_gwis_master->created_by = $_SESSION['id'];
						//created on
						$this->obj_gwis_master->created_on = date("Y-m-d");
						//received remarks
						$this->obj_gwis_master->received_remarks = $remarks;
						$this->obj_gwis_master->parent_id = $_REQUEST['masterpkid'];
						//                    if($electronic_approval == '1')
						//                    {
						//                    }
						//temp
						$this->obj_gwis_master->temp = 0;
						//linked Tr
						//                    $this->obj_gwis_master->linked_tr = $fk_stock_id;
						//get fiscal year
						//                    $fy_dates = $objFiscalYear->getFiscalYear();
						//get Adj Last ID
						//                    $last_id = $this->obj_gwis_master->getAdjLastID($fy_dates['from_date'], $fy_dates['to_date']);
						//get PI Last ID

						$current_year = date("Y");
						//current month
						$current_month = date("m");
						if ($current_month < 7) {
							//from date
							$from_date = ($current_year - 1) . "-06-30";
							//to date
							$to_date = $current_year . "-07-30";
						} else {
							//from date
							$from_date = $current_year . "-06-30";
							//to date
							$to_date = ($current_year + 1) . "-07-30";
						}

						$last_id = $this->obj_gwis_master->getLastID($from_date, $to_date, 5);
						//if last id null set it to zero
						if (!empty($last_id)) {
							if ($last_id)
								$last_idd = $last_id->result_array();
							foreach ($last_idd as $row) {
								$lastid = $row['Maxtr'];
							}
						}

						if ($lastid == NULL) {
							$lastid = 0;
						}

						//                    $itmnamea = $this->obj_itminfo->find_by_id($item_id);
						//                    $itmnameb = $itmnamea->result_array();
						//                    foreach ($itmnameb as $row) {
						//                            $itmname = $row['itmrec_id'];
						//                        }
						$itmname = '';
						if (isset($_REQUEST['tran_no']) && !empty($_REQUEST['tran_no'])) {
							$itmname = $_REQUEST['tran_no'];
						}
						if (isset($itmname) && !empty($itmname)) {
							$charc = substr($itmname, 0, 1);
							if ($charc == 'A') {
								$prefix = $charc;
							} else if ($charc == 'M') {
								$prefix = $charc;
							} else if ($charc == 'TB') {
								$prefix = $charc;
							} else {
								$prefix = '';
							}
						}
						//transaction number
						$trans_no = $prefix . "TR" . date('ym') . str_pad(($lastid + 1), 4, "0", STR_PAD_LEFT);
						//transaction number
						$this->obj_gwis_master->tran_no = $trans_no;
						$this->obj_gwis_master->tr_no = ($lastid + 1);
						//save stock master
						//                    $StockID = $this->obj_gwis_master->update_master_using_id();
						$StockID = $this->obj_gwis_master->save();
					}

					$adjustment = true;
					$masterloop++;
					//            }


					$rejectno = 1;


					//            if($electronic_approval[$index] == '1')
					//            {
					//Stock Received
					//            $this->obj_gwis_detail->StockReceived($detail_id);
					$detailpkid = $_REQUEST['detailpkid'];
					$pi_quantity = $_REQUEST['pi_quantity'];
					$dc_quantityy = $_REQUEST['dc_quantityy'];
					$actual_rec_qty = $_REQUEST['actual_rec_qty'];

					$date_vehicle_req = $_REQUEST['date_vehicle_req'];
					$no_of_vehicle = $_REQUEST['no_of_vehicle'];
					$type_of_vehicle = $_REQUEST['vehicle_type'];

					$product_type = $_REQUEST['product_type'];
					$cold_chain_temp = $_REQUEST['cold_chain_temp'];
					$no_of_cartons = $_REQUEST['no_of_cartons'];
					$value_of_product = $_REQUEST['value_of_product'];
					$transport_req_remarks = $_REQUEST['transport_req_remarks'];
					//Get Batch Detail
					//            $dtl = $_POST['dtl'];
					//            $dtl_result = $_POST['dtl_result'];
					$uprice = $_REQUEST['unit_price'];
					$currency = $_REQUEST['currency'];
					$conversion_rate = $_POST['conversion_rate'];

					$delivery_challan_type = $_POST['delivery_challan_type'];
					$challan_type_detail = $_POST['challan_type_detail'];
					$driver_name = $_POST['driver_name'];
					$driver_contract = $_POST['driver_contract'];
					$vehicle_reg = $_POST['vehicle_reg'];
					$dc_no = $_POST['dc_no'];
					$dc_date = $_POST['dc_date'];
					$invoice = $_POST['invoice'];

					//Stock Detail
					$field1 = $_POST['field1'];
					$field2 = $_POST['field2'];
					$field3 = $_POST['field3'];
					$field4 = $_POST['field4'];
					$field5 = $_POST['field5'];
					$field6 = $_POST['field6'];
					$field7 = $_POST['field7'];
					$field8 = $_POST['field8'];
					$field9 = $_POST['field9'];
					$field10 = $_POST['field10'];

					$stockBatch = $this->obj_stock_batch->GetBatchDetail($detail_id);

					if ($stockBatch) {
						$stockBatch1 = $stockBatch->result_array();
					}
					//            print_r($stockBatch1);exit;
					if (isset($stockBatch1)) {
						$row = $stockBatch1[0];
						$Qty = $row['quantity'];
						$item_id = $row['item_id'];
						$batch_no = $row['batch_no'];
						$batch_expiry = $row['batch_expiry'];
						$funding_source = $row['funding_source'];
						$manufacturer = $row['manufacturer'];
						$unit_price = $row['unit_price'];
						$production_date = $row['production_date'];
					}

					//get missing
					//            $array_missing = $_REQUEST['missing'];
					//            if (isset($array_missing[$index]) && !empty($array_missing[$index])) {
					//get missing
					//quantity
					$quantity = str_replace("-", "", $Qty);
					//product id
					$product_id = $item_id;

					//            $this->obj_stock_batch->fk_stock_id = $stock_ids[$index];
					//batch number
					if (isset($_REQUEST['batchid']) && !empty($_REQUEST['batchid'])) {
						$this->obj_stock_batch->batch_id = $_REQUEST['batchid'];
					}
					$this->obj_stock_batch->batch_no = $batch_no;
					//batch expiry
					$this->obj_stock_batch->batch_expiry = $batch_expiry;
					//            $this->obj_stock_batch->dtl = $dtl[$index];
					//            $this->obj_stock_batch->dtl_result = $dtl_result[$index];
					$this->obj_stock_batch->funding_source = $funding_source;
					$this->obj_stock_batch->manufacturer = $manufacturer;
					//quantity
					//            $this->obj_stock_batch->Qty = $quantity;
					$this->obj_stock_batch->Qty = $pi_quantity[$index];
					//item id
					$this->obj_stock_batch->item_id = $product_id;
					//status
					$this->obj_stock_batch->status = 'Stacked';
					//unit price
					$this->obj_stock_batch->unit_price = $uprice[$index];
					//unit currency
					$this->obj_stock_batch->currency = $currency[$index];
					//unit conversion_rate
					$this->obj_stock_batch->conversion_rate = $conversion_rate[$index];
					//production date
					$this->obj_stock_batch->production_date = $production_date;
					//warehouse id
					$this->obj_stock_batch->wh_id = $_SESSION['warehouse_id'];
					//save stock batch
					//            echo '<pre>';
					//            print_r($stockBatch);
					//            print_r($objStockBatch);
					//            exit;
					if (isset($_REQUEST['batchid']) && !empty($_REQUEST['batchid'])) {
						$this->obj_stock_batch->batch_id = $_REQUEST['batchid'];
						$this->obj_stock_batch->save();
						$batch_id1 = $_REQUEST['batchid'];
					} else {
						$batch_id1 = $this->obj_stock_batch->save();
					}

					//            if ($adjustment) {
					// Detail Entry for Adjustment
					//fk stock id

					if ($_REQUEST['rejected_voucher'] == '2') {
						$this->obj_gwis_detail->update_electronic_approval_status($detailpkid[$index]);
						$this->obj_gwis_detail->fk_stock_id = $_REQUEST['stkmasterid'];
					} else {
						$this->obj_gwis_detail->fk_stock_id = $StockID;
					}
					$this->obj_gwis_detail->electronic_approval_status = '0';
					//                $this->obj_gwis_detail->pk_id =  $stock_ids[$index];
					//batch id
					$this->obj_gwis_detail->batch_id = $batch_id1;
					//fk unit id
					//                $this->obj_gwis_detail->fk_unit_id = $data->fkUnitID;
					//quantity
					//                $this->obj_gwis_detail->quantity = $array_types[$type[$index]] . $missing[$index];
					$this->obj_gwis_detail->quantity = $pi_quantity[$index];
					// PI Quantity
					$this->obj_gwis_detail->pi_quantity = $pi_quantity[$index];
					$this->obj_gwis_detail->dc_quantity = $dc_quantityy[$index];
					$this->obj_gwis_detail->actual_rec_qty = $actual_rec_qty[$index];
					// PI Comments
					//                $this->obj_gwis_detail->pi_comment = $comment[$index];
					//                $this->obj_gwis_detail->electronic_approval = $electronic_approval[$index];

					$this->obj_gwis_detail->field1 = $field1[$index];
					$this->obj_gwis_detail->field2 = $field2[$index];
					$this->obj_gwis_detail->field3 = $field3[$index];
					$this->obj_gwis_detail->field4 = $field4[$index];
					$this->obj_gwis_detail->field5 = $field5[$index];
					$this->obj_gwis_detail->field6 = $field6[$index];
					$this->obj_gwis_detail->field7 = $field7[$index];
					$this->obj_gwis_detail->field8 = $field8[$index];
					$this->obj_gwis_detail->field9 = $field9[$index];
					$this->obj_gwis_detail->field10 = $field10[$index];

					$this->obj_gwis_detail->delivery_challan_type = $delivery_challan_type[$index];
					$this->obj_gwis_detail->challan_type_detail = $challan_type_detail[$index];
					$this->obj_gwis_detail->driver_name = $driver_name[$index];
					$this->obj_gwis_detail->driver_contract = $driver_contract[$index];
					$this->obj_gwis_detail->vehicle_reg = $vehicle_reg[$index];
					$this->obj_gwis_detail->dc_no = $dc_no[$index];
					$this->obj_gwis_detail->dc_date = $dc_date[$index];
					$this->obj_gwis_detail->invoice = $invoice[$index];

					$this->obj_gwis_detail->date_vehicle_req = date('Y-m-d', strtotime($date_vehicle_req));
					$this->obj_gwis_detail->no_of_vehicle = $no_of_vehicle;
					$this->obj_gwis_detail->type_of_vehicle = $type_of_vehicle;


					$this->obj_gwis_detail->product_type_id = $product_type[$index];
					$this->obj_gwis_detail->temperature_requirement = $cold_chain_temp[$index];
					$this->obj_gwis_detail->no_of_cartons = $no_of_cartons[$index];
					$this->obj_gwis_detail->value_of_product = $value_of_product[$index];
					$this->obj_gwis_detail->transport_req_remarks = $transport_req_remarks[$index];
					//temp
					//                $this->obj_gwis_detail->temp = 0;
					$this->obj_gwis_detail->temp = 0;
					//is received
					$this->obj_gwis_master->updatedetailpkid($_REQUEST['stockid'][$index]);
					//                $this->obj_gwis_detail->is_received = 0;
					//adjustment type
					//                $this->obj_gwis_detail->adjustment_type = $type[$index];
					//save stock detail
					//                $this->obj_gwis_detail->update_stock_using_id();
					//                $this->obj_gwis_detail->update_pistock_using_id();
					$this->obj_gwis_detail->save();
					//            }
					//fk stock id
					//            $this->obj_gwis_detail->fk_stock_id = $fkStockID;
					//            //batch id
					//            $this->obj_gwis_detail->batch_id = $batch_id1;
					//            //fk unit id
					//            $this->obj_gwis_detail->fk_unit_id = $data->fkUnitID;
					//            //quantity
					////            $this->obj_gwis_detail->quantity = $array_types[$type_id] . $quantity;
					//            $this->obj_gwis_detail->pi_quantity = $quantity;
					//            //temp
					//            $this->obj_gwis_detail->temp = 0;
					//            //is received
					//            $this->obj_gwis_detail->is_received = 1;
					//            //adjustment type
					//            $this->obj_gwis_detail->adjustment_type = $type_id;
					//            //save stock detail
					//            $this->obj_gwis_detail->save();
					// Adjust Batch Quantity
					//            $this->obj_stock_batch->adjustQtyByWh($batch_id1, $_SESSION['warehouse_id']);
					//            //auto Running LEFO Batch
					//            $this->obj_stock_batch->autoRunningLEFOBatch($product_id, $_SESSION['warehouse_id']);
					//            } // End foreach
					if (count($_REQUEST['stockid']) == $_REQUEST['totalrows']) {
						$this->obj_gwis_master->updatedetailpkidtozero($_REQUEST['stockid'][$index]);
					}
				}

				//            }
				//   print_r(count($_REQUEST['stockid']));
				//                echo $_REQUEST['totalrows'];
				//                exit;
				if (count($_REQUEST['stockid']) == $_REQUEST['totalrows']) {
					$this->obj_gwis_master->updatemasterpkid($_REQUEST['masterpkid']);
				}
			}














			if (!isset($_POST['stock_master_id'])) {
			} else {
				$stock_master_id = $_POST['stock_master_id'];
			}

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();

			if (isset($_REQUEST['issue_no'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = 3;
				$this->obj_gwis_master->tran_no = $issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetTransportReqByIssueNo();
				//                }
			}

			if (isset($_REQUEST['rej_issue_no'])) {
				$data['rej_issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['rej_issue_no']) && !empty($_REQUEST['rej_issue_no'])) {
					//get issue number
					$rej_issue_no = $_REQUEST['rej_issue_no'];
					$data['issue_no'] = $_REQUEST['rej_issue_no'];
					$rejected_real_masterids = $this->obj_gwis_master->rejected_real_masterid($_REQUEST['rej_issue_no']);
					$data['rejected_real_masterid'] = $rejected_real_masterids->result_array();
				}
				//set issue number
				$this->obj_gwis_master->status_id = 1;
				$this->obj_gwis_master->tran_no = $rej_issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByRejIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if (isset($stockReceive) && !empty($stockReceive)) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}
			//            $process_status_nmbr = '';
			//            $qry_getprocess_status = $this->obj_gwis_master->getprocess_status(1);
			//            if($qry_getprocess_status)
			//            {
			//                $dataprocessstatus = $qry_getprocess_status->result_array();
			//            }
			//            foreach ($dataprocessstatus AS $row)
			//            {
			//                $process_status_nmbr = $row['process_status'];  
			//            }
			$code_arr = $this->obj_gwis_master->get_assign_approvalcode(3);
			if ($code_arr) {
				$data['approval_code'] = $code_arr->result_array();
				$approvalcodes = $code_arr->result_array();
			}
			$process_status_ids = array();
			if ($approvalcodes) {
				foreach ($approvalcodes as $row) {
					$approver_designation = preg_split("/\,/", $row['approver_designation']);
					$approver_desg_id = preg_split("/\,/", $row['approver_desg_id']);
					$process_statuss = preg_split("/\,/", $row['process_status']);
					$approval_codess = preg_split("/\,/", $row['approval_code']);
					for ($i = 0; $i < count($approval_codess); $i++) {
						$process_status_ids[] = $process_statuss[$i] - 1;
					}
					$process_status_nmbr = implode(",", $process_status_ids);
				}
			}

			//            $process_status_nmbr = '';
			$process_status_nmbrr = '';
			//            $qry_getprocess_status = $this->obj_gwis_master->getprocess_status(3);
			//            if($qry_getprocess_status)
			//            {
			//                $dataprocessstatus = $qry_getprocess_status->result_array();
			//            }
			//            foreach ($dataprocessstatus AS $row)
			//            {
			//                $process_status_nmbr = $row['process_status'];  
			//            }

			$qry_getprocess_statuss = $this->obj_gwis_master->getprocess_statusmax(4);
			if ($qry_getprocess_statuss) {
				$dataprocessstatuss = $qry_getprocess_statuss->result_array();
			}
			foreach ($dataprocessstatuss as $row) {
				$process_status_nmbrr = $row['process_status'];
			}

			$this->obj_gwis_master->status_id = '3';
			//            $this->obj_gwis_master->process_status = $process_status_nmbr.','.$process_status_nmbrr;
			$this->obj_gwis_master->process_status = $process_status_nmbrr;
			$qry_vouchers = $this->obj_gwis_master->get_transport_req_from_vouchers();
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}

			//
			//                //chech if record exists
			//             $issueVoucher = '';
			//             $a='';
			//                if ($getStockIssues) {
			//
			//                    //fetch results
			//                    foreach ($getStockIssues AS $row)
			//                    {
			//                        $a= " <a href=\"new_receive_wh.php?issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
			//                        $issueVoucher[ $row['tran_no']] = $a;
			//                    }
			//
			//                }
			$vehicle_type_arr = $this->obj_lists->get_list(13);
			$data['vehicle_type'] = $vehicle_type_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_by_idsupplier();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();

			//            $stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			//            if ($stock_master_record)
			//                $data['stock_master_records'] = $stock_master_record->result_array();
			//            $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($stock_master_id);
			//            echo '<pre>';
			//            echo $stock_master_id;
			//            $a=array();
			//                foreach ($data['temp_records']->result_array() as $row) {
			//                    $a[]=$row;
			//                }
			//            print_r($a);
			//            echo '</pre>';
			//            exit;
			//            $data['master_id'] = $stock_master_id;
			$data['page_title'] = 'Transport Req Form';
			$data['main_content'] = $this->load->view('inventory_management/transport_req_from', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();

			//            $process_status_nmbr = '';
			//            $qry_getprocess_status = $this->obj_gwis_master->getprocess_status(1);
			//            if($qry_getprocess_status)
			//            {
			//                $dataprocessstatus = $qry_getprocess_status->result_array();
			//            }
			//            foreach ($dataprocessstatus AS $row)
			//            {
			//                $process_status_nmbr = $row['process_status'];  
			//            }

			$code_arr = $this->obj_gwis_master->get_assign_approvalcode(3);
			if ($code_arr) {
				$data['approval_code'] = $code_arr->result_array();
				$approvalcodes = $code_arr->result_array();
			}
			$process_status_ids = array();
			if ($approvalcodes) {
				foreach ($approvalcodes as $row) {
					$approver_designation = preg_split("/\,/", $row['approver_designation']);
					$approver_desg_id = preg_split("/\,/", $row['approver_desg_id']);
					$process_statuss = preg_split("/\,/", $row['process_status']);
					$approval_codess = preg_split("/\,/", $row['approval_code']);
					for ($i = 0; $i < count($approval_codess); $i++) {
						$process_status_ids[] = $process_statuss[$i] - 1;
					}
					$process_status_nmbr = implode(",", $process_status_ids);
				}
			}

			//            $process_status_nmbr = '';
			$process_status_nmbrr = '';
			//            $qry_getprocess_status = $this->obj_gwis_master->getprocess_status(3);
			//            if($qry_getprocess_status)
			//            {
			//                $dataprocessstatus = $qry_getprocess_status->result_array();
			//            }
			//            foreach ($dataprocessstatus AS $row)
			//            {
			//                $process_status_nmbr = $row['process_status'];  
			//            }

			$qry_getprocess_statuss = $this->obj_gwis_master->getprocess_statusmax(3);
			if ($qry_getprocess_statuss) {
				$dataprocessstatuss = $qry_getprocess_statuss->result_array();
			}
			foreach ($dataprocessstatuss as $row) {
				$process_status_nmbrr = $row['process_status'];
			}

			$this->obj_gwis_master->status_id = '3';
			//            $this->obj_gwis_master->process_status = $process_status_nmbr.','.$process_status_nmbrr;
			$this->obj_gwis_master->process_status = $process_status_nmbrr;
			$qry_vouchers = $this->obj_gwis_master->get_transport_req_from_vouchers();
			if ($qry_vouchers) {
				$data['getStockIssues'] = $qry_vouchers->result_array();
			} else {
				$data['getStockIssues'] = '';
			}


			$stockReceive = '';

			if ($this->input->get("tranno")) {
				$data['tranno'] = $this->input->get("tranno");
				$data['whidto'] = $this->input->get("whidto");
				//                $res = $this->obj_gwis_detail->GetBatchDetail($this->input->get("pkdetailid"),$this->input->get("batchid"));
				//            $row = $res->row();
				//                if ($res)
				//                {
				//                    $data['gwis_data'] = $res->result_array();
				//                }
				//                $data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				$issue_no = $this->input->get("tranno");
				$data['issue_no'] = $issue_no;
				//set issue number
				$this->obj_gwis_master->status_id = 3;
				$this->obj_gwis_master->tran_no = $this->input->get("tranno");
				$this->obj_gwis_master->wh_id_to = $this->input->get("whidto");
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetTransportReqByIssueNo();
				//                }
			}

			if (isset($_REQUEST['issue_no']) && empty($_REQUEST['tranno'])) {
				$data['issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['issue_no']) && !empty($_REQUEST['issue_no'])) {
					//get issue number
					$issue_no = $_REQUEST['issue_no'];
					$data['issue_no'] = $_REQUEST['issue_no'];
				}
				//set issue number
				$this->obj_gwis_master->status_id = 3;
				$this->obj_gwis_master->tran_no = $issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetTransportReqByIssueNo();
				//                }
			}

			if (isset($_REQUEST['rej_issue_no'])) {
				$data['rej_issue_no'] = '';
				//                if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
				//check issue number
				if (isset($_REQUEST['rej_issue_no']) && !empty($_REQUEST['rej_issue_no'])) {
					//get issue number
					$rej_issue_no = $_REQUEST['rej_issue_no'];
					$data['issue_no'] = $_REQUEST['rej_issue_no'];
					$rejected_real_masterids = $this->obj_gwis_master->rejected_real_masterid($_REQUEST['rej_issue_no']);
					$data['rejected_real_masterid'] = $rejected_real_masterids->result_array();
				}
				//set issue number
				$this->obj_gwis_master->status_id = 1;
				$this->obj_gwis_master->tran_no = $rej_issue_no;
				$this->obj_gwis_master->wh_id_to = $_SESSION['warehouse_id'];
				//Get WH Stock By Issue No
				$stockReceive = $this->obj_gwis_master->GetWHStockByRejIssueNo();
				//                }
			}

			//            $types = $objTransType->find_all();

			$count = 0;
			if ($stockReceive) {
				//                $count = mysql_num_rows($stockReceive);
				$data['stockReceive'] = $stockReceive->result_array();
			}

			//            $qry_vouchers = $this->obj_gwis_master->get_issue_vouchers();
			//            $getStockIssues = $qry_vouchers->result_array();
			//
			//
			//                //chech if record exists
			//             $issueVoucher = '';
			//             $a='';
			//                if ($getStockIssues) {
			//
			//                    //fetch results
			//                    foreach ($getStockIssues AS $row)
			//                    {
			//                        $a= " <a href=\"new_receive_wh.php?issue_no=" . $row['tran_no'] . "&search=true\">" . $row['tran_no'] . "</a>";
			//                        $issueVoucher[ $row['tran_no']] = $a;
			//                    }
			//
			//                }
			//            $product_arr = $this->obj_product->find_active();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$vehicle_type_arr = $this->obj_lists->get_list(13);
			$data['vehicle_type'] = $vehicle_type_arr->result_array();

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			//            $suppliers_arr = $this->obj_gwis_master->fetch_suppliers();
			//            if ($suppliers_arr)
			//                $data['suppliers'] = $suppliers_arr->result_array();

			$funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
			if ($funding_source_arr)
				$data['funding_source'] = $funding_source_arr->result_array();

			$suppliers_arr = $this->obj_stakeholder->find_by_idsupplier();
			if ($suppliers_arr)
				$data['suppliers'] = $suppliers_arr->result_array();

			$doc_type_arr = $this->obj_document_type->find_active();
			if ($doc_type_arr)
				$data['document_type'] = $doc_type_arr->result_array();
			//            $data['temp_records'] = $this->obj_gwis_master->get_temp_master_records(1);
			//            $master_id_arr = $this->obj_gwis_master->get_temp_master_records(1);
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['transaction_reference'];
				}
			}

			$data['page_title'] = 'Transport Req Form';
			$data['main_content'] = $this->load->view('inventory_management/transport_req_from', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function consumption_form()
	{
		if (isset($_POST['wh_btn']) && !empty($_POST['wh_btn'])) {

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();

			$wh_arr = $this->obj_warehouse->find_assign_warehouse();
			if ($wh_arr)
				$data['warehouse'] = $wh_arr->result_array();

			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();
			$data['tran'] = $this->input->post('tran_type');

			$whid = '';
			if (isset($_POST['warehouse']) && !empty($_POST['warehouse'])) {
				$whid = $_POST['warehouse'];
			}
			$year = '';
			if (isset($_POST['year']) && !empty($_POST['year'])) {
				$year = $_POST['year'];
			}
			$month = '';
			if (isset($_POST['month']) && !empty($_POST['month'])) {
				$month = $_POST['month'];
			}

			$rsRow5_arr = $this->obj_reports_model->check_this_month($whid, $year, $month);
			if ($rsRow5_arr) {
				//                $data['rsRow55'] = $rsRow5_arr->result_array();
			} else {
				$rsRow6_arr = $this->obj_reports_model->get_last_month($whid, $year, $month);
				if ($rsRow6_arr)
					$data['rsRow66'] = $rsRow6_arr->result_array();
			}

			$rsRow1_arr = $this->obj_reports_model->get_c1q();
			if ($rsRow1_arr)
				$data['rsRow11'] = $rsRow1_arr->result_array();

			$rsRow2_arr = $this->obj_reports_model->get_c2q($whid, $year, $month);
			if ($rsRow2_arr)
				$data['rsRow22'] = $rsRow2_arr->result_array();
			//                $data['rsRow22'] = $rsRow2_arr->row_array();  
			//          $rsRow3_arr = $this->obj_reports_model->get_c3q();
			//            if ($rsRow3_arr)
			//                $data['rsRow33'] = $rsRow3_arr->result_array();  

			$rsRow4_arr = $this->obj_reports_model->get_c4q($whid, $year, $month);
			if ($rsRow4_arr)
				$data['rsRow44'] = $rsRow4_arr->result_array();

			$data['form'] = $_POST;



			//            $stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			//            if ($stock_master_record)
			//                $data['stock_master_records'] = $stock_master_record->result_array();
			//            $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($stock_master_id);
			//            $data['master_id'] = $stock_master_id;
			$data['page_title'] = 'Consumption Form';

			$data['main_content'] = $this->load->view('inventory_management/consumption_form', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else if (isset($_POST['saveBtn']) && !empty($_POST['saveBtn'])) {
			$wh_arr = $this->obj_warehouse->find_assign_warehouse();
			if ($wh_arr)
				$data['warehouse'] = $wh_arr->result_array();
			if ($_POST['ActionType'] == 'Add') {
				$this->obj_reports_model->delete_old_hf_wh_data($_POST['wh_id'], $_POST['mm'], $_POST['yy']);

				if (isset($_POST['isNewRpt']) && $_POST['isNewRpt'] == 0) {
					//Getting add_date
					$addDate = $_POST['add_date'];
				} else {
					$addDate = date('Y-m-d H:i:s');
				}

				$lastUpdate = date('Y-m-d H:i:s');
				// Client IP
				//                $clientIp = getClientIp();
				$clientIp = '';
				//Checking itmrec_id
				if (isset($_POST['itmrec_id']) && !empty($_POST['itmrec_id']) && is_array($_POST['itmrec_id'])) {
					//Getting itmrec_id
					$postedArray = $_POST['itmrec_id'];
				} else {
					//Getting flitmrec_id
					$postedArray = $_POST['flitmrec_id'];
				}
				$FLDOBLA = $_POST['FLDOBLA'];
				$FLDRecv = $_POST['FLDRecv'];
				$FLDIsuueUP = $_POST['FLDIsuueUP'];
				$FLDCBLA = $_POST['FLDCBLA'];
				$FLDReturnTo = $_POST['FLDReturnTo'];
				$FLDUnusable = $_POST['FLDUnusable'];
				//                $FLDnew = $_POST['FLDnew'];
				//                $FLDold = $_POST['FLDold'];
				//                $Removals = $_POST['Removals'];
				$Demand = $_POST['Demand'];
				$patient_arv = $_POST['patient_arv'];
				$total_stock_dcurperiod = $_POST['total_stock_dcurperiod'];
				$quarterly_demand = $_POST['quarterly_demand'];


				//Exploding data from postedArray
				foreach ($postedArray as $val => $detailval) {

					//                foreach ($postedArray as $val) {
					//                    $itemid = explode('-', $val);
					//                    print_r($postedArray);exit;
					//                    $FLDOBLA = "0" . $_POST['FLDOBLA' . $itemid[1]];
					////                    $FLDOBLC = "0" . $_POST['FLDOBLC' . $itemid[1]];
					//                    $FLDRecv = "0" . $_POST['FLDRecv' . $itemid[1]];
					//                    $FLDIsuueUP = "0" . $_POST['FLDIsuueUP' . $itemid[1]];
					//                    $FLDCBLA = "0" . $_POST['FLDCBLA' . $itemid[1]];
					////                    $FLDCBLC = "0" . $_POST['FLDCBLC' . $itemid[1]];
					//                    $FLDReturnTo = "0" . $_POST['FLDReturnTo' . $itemid[1]];
					//                    $FLDUnusable = "0" . $_POST['FLDUnusable' . $itemid[1]];
					//                    
					//                    $FLDnew = "0" . $_POST['FLDnew' . $itemid[1]];
					//                    $FLDold = "0" . $_POST['FLDold' . $itemid[1]];
					//                    $Removals = "0" . $_POST['Removals' . $itemid[1]];
					//                    $Demand = "0" . $_POST['Demand' . $itemid[1]];


					$itemid = explode('-', $detailval);
					//                    print_r($postedArray);
					//                    $FLDOBLA = "0" . $_POST['FLDOBLA' . $itemid[$val]];
					//                    $FLDOBLC = "0" . $_POST['FLDOBLC' . $itemid[1]];
					//                    $FLDRecv = "0" . $_POST['FLDRecv' . $itemid[$val]];
					//                    $FLDIsuueUP = "0" . $_POST['FLDIsuueUP' . $itemid[$val]];
					//                    $FLDCBLA = "0" . $_POST['FLDCBLA' . $itemid[$val]];
					////                    $FLDCBLC = "0" . $_POST['FLDCBLC' . $itemid[1]];
					//                    $FLDReturnTo = "0" . $_POST['FLDReturnTo' . $itemid[$val]];
					//                    $FLDUnusable = "0" . $_POST['FLDUnusable' . $itemid[$val]];
					//                    
					//                    $FLDnew = "0" . $_POST['FLDnew' . $itemid[$val]];
					//                    $FLDold = "0" . $_POST['FLDold' . $itemid[$val]];
					//                    $Removals = "0" . $_POST['Removals' . $itemid[$val]];
					//                    $Demand = "0" . $_POST['Demand' . $itemid[$val]];
					//                    


					$this->obj_tbl_hf_data->warehouse_id = $_POST['wh_id'];
					$this->obj_tbl_hf_data->item_id = $detailval;
					$this->obj_tbl_hf_data->opening_balance = $FLDOBLA[$detailval];
					$this->obj_tbl_hf_data->received_balance = $FLDRecv[$detailval];
					$this->obj_tbl_hf_data->issue_balance = $FLDIsuueUP[$detailval];
					$this->obj_tbl_hf_data->closing_balance = $FLDCBLA[$detailval];
					$this->obj_tbl_hf_data->adjustment_positive = $FLDReturnTo[$detailval];
					$this->obj_tbl_hf_data->adjustment_negative = $FLDUnusable[$detailval];
					//                    $this->obj_tbl_hf_data->avg_consumption = $_POST['itmrec_id'];
					//                    $this->obj_tbl_hf_data->new = $FLDnew[$detailval];
					//                    $this->obj_tbl_hf_data->old = $FLDold[$detailval];
					$this->obj_tbl_hf_data->reporting_date = $_POST['yy'] . '-' . $_POST['mm'] . '-00';
					$this->obj_tbl_hf_data->ip_address = $clientIp;
					$this->obj_tbl_hf_data->created_by = $_SESSION['id'];
					//                    $this->obj_tbl_hf_data->removals = $Removals[$detailval];
					//                    $this->obj_tbl_hf_data->dropouts = $_POST['itmrec_id'];
					$this->obj_tbl_hf_data->demand = $Demand[$detailval];

					$this->obj_tbl_hf_data->arv_patients = $patient_arv[$detailval];
					$this->obj_tbl_hf_data->total_stock_dcurperiod = $total_stock_dcurperiod[$detailval];
					$this->obj_tbl_hf_data->quarterly_demand = $quarterly_demand[$detailval];
					//                    $this->obj_tbl_hf_data->change_pos = $_POST['itmrec_id'];
					//                    $this->obj_tbl_hf_data->change_neg = $_POST['itmrec_id'];
					//                    $this->obj_tbl_hf_data->retrieved = $_POST['itmrec_id'];

					$this->obj_tbl_hf_data->save();
				}
			}

			$data['page_title'] = 'Consumption Form';

			$data['main_content'] = $this->load->view('inventory_management/consumption_form', $data, TRUE);
			$this->load->view('layout/main', $data);
		} else {
			$data = array();

			//            $product_arr = $this->obj_itminfo->find_all_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();


			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();


			//            $product_arr = $this->obj_product->get_warehouse_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();

			$wh_arr = $this->obj_warehouse->find_assign_warehouse();
			if ($wh_arr)
				$data['warehouse'] = $wh_arr->result_array();

			$data['temp_records'] = $this->obj_gwis_master->get_temp_master_records_adj(3, "centers");
			$master_id_arr = $this->obj_gwis_master->get_temp_master_records_adj(3, "centers");
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['transaction_reference'];
				}
			}
			$data['page_title'] = 'Consumption Form';
			$data['main_content'] = $this->load->view('inventory_management/consumption_form', $data, TRUE);
			$this->load->view('layout/main', $data);
		}
	}

	public function print_consumption_form()
	{
		if (isset($_REQUEST['warehouse']) && !empty($_REQUEST['warehouse'])) {

			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();

			$wh_arr = $this->obj_warehouse->find_assign_warehouse();
			if ($wh_arr)
				$data['warehouse'] = $wh_arr->result_array();

			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();
			$data['tran'] = $this->input->post('tran_type');

			$whid = '';
			if (isset($_REQUEST['warehouse']) && !empty($_REQUEST['warehouse'])) {
				$whid = $_REQUEST['warehouse'];
			}
			$year = '';
			if (isset($_REQUEST['year']) && !empty($_REQUEST['year'])) {
				$year = $_REQUEST['year'];
			}
			$month = '';
			if (isset($_REQUEST['month']) && !empty($_REQUEST['month'])) {
				$month = $_REQUEST['month'];
			}


			$rsRow1_arr = $this->obj_reports_model->get_c1q();
			if ($rsRow1_arr)
				$data['rsRow11'] = $rsRow1_arr->result_array();

			$rsRow2_arr = $this->obj_reports_model->get_print_c2q($whid, $year, $month);
			if ($rsRow2_arr)
				$data['rsRow22'] = $rsRow2_arr->result_array();
			//                $data['rsRow22'] = $rsRow2_arr->row_array();  
			//          $rsRow3_arr = $this->obj_reports_model->get_c3q();
			//            if ($rsRow3_arr)
			//                $data['rsRow33'] = $rsRow3_arr->result_array();  

			$rsRow4_arr = $this->obj_reports_model->get_c4q($whid, $year, $month);
			if ($rsRow4_arr)
				$data['rsRow44'] = $rsRow4_arr->result_array();

			$data['form'] = $_POST;



			//            $stock_master_record = $this->obj_gwis_master->find_by_id($stock_master_id);
			//            if ($stock_master_record)
			//                $data['stock_master_records'] = $stock_master_record->result_array();
			//            $data['temp_records'] = $this->obj_gwis_detail->get_temp_records($stock_master_id);
			//            $data['master_id'] = $stock_master_id;
			$data['page_title'] = 'Print Consumption Form';

			$data['main_content'] = $this->load->view('inventory_management/print_consumption_form', $data, TRUE);
			$this->load->view('layout/print', $data);
			//            redirect(base_url("inventory_management/print_consumption_form?warehouse=".$_REQUEST['warehouse']."&year=".$_REQUEST['year']."&month=".$_REQUEST['month'].""),"refresh");exit;
		} else {
			$data = array();

			//            $product_arr = $this->obj_itminfo->find_all_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();


			$product_arr = $this->obj_itminfo->find_all_products();
			if ($product_arr)
				$data['product'] = $product_arr->result_array();

			$stk_arr = $this->obj_reports_model->get_stakeholder();
			if ($stk_arr)
				$data['stakeholder'] = $stk_arr->result_array();


			//            $product_arr = $this->obj_product->get_warehouse_products();
			//            if ($product_arr)
			//                $data['product'] = $product_arr->result_array();
			$tran_arr = $this->obj_product->get_tran_types();
			if ($tran_arr)
				$data['trans'] = $tran_arr->result_array();

			$wh_arr = $this->obj_warehouse->find_assign_warehouse();
			if ($wh_arr)
				$data['warehouse'] = $wh_arr->result_array();

			$data['temp_records'] = $this->obj_gwis_master->get_temp_master_records_adj(3, "centers");
			$master_id_arr = $this->obj_gwis_master->get_temp_master_records_adj(3, "centers");
			if (!empty($master_id_arr)) {
				if ($master_id_arr)
					$master_result = $master_id_arr->result_array();
				foreach ($master_result as $row) {
					$data['master_id'] = $row['stock_master_id'];
					$data['tran_reference_number'] = $row['transaction_reference'];
				}
			}
			$data['page_title'] = 'Print Consumption Form';
			$data['main_content'] = $this->load->view('inventory_management/print_consumption_form', $data, TRUE);
			$this->load->view('layout/print', $data);
		}
	}

	function sms($to, $message)
	{
		$target_url = "https://connect.jazzcmt.com/sendsms_url.html";
		$post = array(
			'Username' => '03085325085',
			'Password' => 'U4j@HHfYaR8',
			'From' => 'LMIS Alert',
			'To' => $to,
			'Message' => $message
		);

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $target_url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible;)");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: multipart/form-data'));
		curl_setopt($ch, CURLOPT_FRESH_CONNECT, 1);
		curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
		curl_setopt($ch, CURLOPT_TIMEOUT, 100);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		$result = curl_exec($ch);
		curl_close($ch);
		$response = $result;
	}

	function email($email, $message, $masterid)
	{
		//        $errorMSG = "";
		//
		//        $EmailTo = $email;
		//        $Subject = "Password Reset";
		// prepare email body text
		//        $Body = "";
		//        $Body .= "Name: ";
		//        $Body .= '';
		//        $Body .= "\n";
		//        $Body .= "Email: ";
		//        $Body .= $email;
		//$Body .= "\n";
		//$Body .= "guest: ";
		//$Body .= $guest;
		//$Body .= "\n";
		//$Body .= "event: ";
		//$Body .= $event;
		//        $Body .= "\n";
		//        $Body .= "Message: ";
		//        $Body .= $message;
		//        $Body .= "\n";
		// send email
		//        $success = mail($EmailTo, $Subject, $message);
		$info = $this->print_gwis_email($masterid);
		//        print_r($info);exit;
		$to = "$email";
		$subject = "Please Approve Voucher";
		$txt = $message . "\r\n";
		$txt .= $info;
		$headers = "From: support@lmis.gov.pk" . "\r\n" .
			"CC: saadisuleman100@gmail.com";

		mail($to, $subject, $txt, $headers);
		//                exit;
		// redirect to success page
		//        if ($success && $errorMSG == ""){
		////           echo "success";
		//           echo "<script>alert('success!');</script>" ;
		//        }
		//        else{
		//            echo "<script>alert('error!');</script>" ;
		//        }
		//        else{
		//            if($errorMSG == ""){
		//                echo "Something went wrong :(";
		//            } else {
		//                echo $errorMSG;
		//            }
		//        }
	}

	function print_gwis_email($masterid)
	{
		if (isset($masterid)) {

			//            $this->obj_stock_master->TranTypeID = 2;
			////            $this->obj_stock_master->TranNo = $receiveno;
			//            $this->obj_stock_master->WHIDTo = $_SESSION['warehouse_id'];
			//            //Get WH Stock By Issue No
			//            $stockReceive = $this->obj_stock_master->GetWHStockByIssueNo();
			//            
			//            if(isset($stockReceive) && !empty($stockReceive)){
			////                $count = mysql_num_rows($stockReceive);
			//                $data['stockReceive'] = $stockReceive->result_array();
			//            }

			$stockId = $masterid;

			$getwhanduid = $this->obj_gwis_master->Getwhanduid($stockId);
			if (isset($getwhanduid) && !empty($getwhanduid)) {
				foreach ($getwhanduid->result_array() as $row1) {
					$wh_id = $row1['wh_id_from'];
					$userid = $row1['created_by'];
				}
			}
			//Get Stocks Issue List
			$stocks = $this->obj_gwis_master->GetStocksGwisList($userid, $wh_id, 1, $stockId);
			if (isset($stocks) && !empty($stocks)) {
				$data['stocks'] = $stocks->result_array();
				foreach ($stocks->result_array() as $row22) {
					$process_id1 = $row22['process_status'];
					$parent_id1 = $row22['parent_id'];
					if (!empty($parent_id1)) {
						$fcreator = $this->obj_gwis_master->GetUsercreatedID($process_id1, $parent_id1);
						$data['fcreator'] = $fcreator->result_array();
						$data['process_status_id'] = $row22['process_status'];
					} else {
						$data['fcreator'] = '';
						$data['process_status_id'] = '';
					}
				}
			}
			$stkId = '';
			//Get Header Info
			$info1 = $this->obj_gwis_master->Getheaderinfofir();
			if (isset($info1) && !empty($info1)) {
				foreach ($info1->result_array() as $row2) {
					$stkId = $row2['stkid'];
				}
				$data['whName'] = $info1->result_array();
			}

			$info2 = $this->obj_gwis_master->Getheaderinfosec($stkId);
			if (isset($info2) && !empty($info2)) {
				$data['logo'] = $info2->result_array();
			} else {
				$data['logo'] = '';
			}


			//            $date1 = str_replace('/', '-', $_REQUEST['start_date']);  
			//            $date2 = str_replace('/', '-', $_REQUEST['end_date']);  
			////            print_r($date2);
			//            $date_from = date('Y-m-d', strtotime($date1));
			//            $date_to   = date('Y-m-d', strtotime($date2));
			//            if(isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers']))
			//            {
			//                $supplier_id = $_REQUEST['receive_from_suppliers'];
			//            }
			//            else{
			//                $supplier_id = '';
			//            }
			//            $data['result'] = $this->obj_stock_master->stock_search($date_from,$date_to,$supplier_id,2);
		}


		//        $suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		//            if ($suppliers_arr)
		//                $data['suppliers'] = $suppliers_arr->result_array();

		$data['page_title'] = 'Print GWIS';

		//        redirect(base_url() . 'inventory_management/printIssue', 'refresh');
		return $data['main_content'] = $this->load->view('inventory_management/print_gwis', $data, TRUE);
		$this->load->view('layout/print', $data);
	}

	function email_printissue($email, $message, $masterid)
	{
		//        $errorMSG = "";
		//
		//        $EmailTo = $email;
		//        $Subject = "Password Reset";
		// prepare email body text
		//        $Body = "";
		//        $Body .= "Name: ";
		//        $Body .= '';
		//        $Body .= "\n";
		//        $Body .= "Email: ";
		//        $Body .= $email;
		//$Body .= "\n";
		//$Body .= "guest: ";
		//$Body .= $guest;
		//$Body .= "\n";
		//$Body .= "event: ";
		//$Body .= $event;
		//        $Body .= "\n";
		//        $Body .= "Message: ";
		//        $Body .= $message;
		//        $Body .= "\n";
		// send email
		//        $success = mail($EmailTo, $Subject, $message);
		$info = $this->printIssue_email($masterid);
		//        print_r($info);exit;
		$to = "$email";
		$subject = "Please Approve Voucher";
		$txt = $message . "\r\n";
		$txt .= $info;
		$headers = "From: support@lmis.gov.pk" . "\r\n" .
			"CC: saadisuleman100@gmail.com";

		mail($to, $subject, $txt, $headers);
		//                exit;
		// redirect to success page
		//        if ($success && $errorMSG == ""){
		////           echo "success";
		//           echo "<script>alert('success!');</script>" ;
		//        }
		//        else{
		//            echo "<script>alert('error!');</script>" ;
		//        }
		//        else{
		//            if($errorMSG == ""){
		//                echo "Something went wrong :(";
		//            } else {
		//                echo $errorMSG;
		//            }
		//        }
	}

	function printIssue_email($masterid)
	{

		if (isset($masterid)) {

			//            $this->obj_stock_master->TranTypeID = 2;
			////            $this->obj_stock_master->TranNo = $receiveno;
			//            $this->obj_stock_master->WHIDTo = $_SESSION['warehouse_id'];
			//            //Get WH Stock By Issue No
			//            $stockReceive = $this->obj_stock_master->GetWHStockByIssueNo();
			//            
			//            if(isset($stockReceive) && !empty($stockReceive)){
			////                $count = mysql_num_rows($stockReceive);
			//                $data['stockReceive'] = $stockReceive->result_array();
			//            }

			$stockId = $masterid;

			$getwhanduid = $this->obj_gwis_master->Getwhanduid($stockId);
			if (isset($getwhanduid) && !empty($getwhanduid)) {
				foreach ($getwhanduid->result_array() as $row1) {
					$wh_id = $row1['wh_id_from'];
					$userid = $row1['created_by'];
				}
			}
			//Get Stocks Issue List
			$stocks = $this->obj_gwis_master->GetStocksIssueList($userid, $wh_id, 2, $stockId);
			if (isset($stocks) && !empty($stocks)) {
				$data['stocks'] = $stocks->result_array();
				foreach ($stocks->result_array() as $row22) {
					$process_id1 = $row22['process_status'];
					$parent_id1 = $row22['parent_id'];
					if (!empty($parent_id1)) {
						$fcreator = $this->obj_gwis_master->GetUsercreatedID($process_id1, $parent_id1);
						$data['fcreator'] = $fcreator->result_array();
						$data['process_status_id'] = $row22['process_status'];
					} else {
						$data['fcreator'] = '';
						$data['process_status_id'] = '';
					}
				}
			}
			$stkId = '';
			//Get Header Info
			$info1 = $this->obj_gwis_master->Getheaderinfofir();
			if (isset($info1) && !empty($info1)) {
				foreach ($info1->result_array() as $row2) {
					$stkId = $row2['stkid'];
				}
				$data['whName'] = $info1->result_array();
			}

			$info2 = $this->obj_gwis_master->Getheaderinfosec($stkId);
			if (isset($info2) && !empty($info2)) {
				$data['logo'] = $info2->result_array();
			} else {
				$data['logo'] = '';
			}


			//            $date1 = str_replace('/', '-', $_REQUEST['start_date']);  
			//            $date2 = str_replace('/', '-', $_REQUEST['end_date']);  
			////            print_r($date2);
			//            $date_from = date('Y-m-d', strtotime($date1));
			//            $date_to   = date('Y-m-d', strtotime($date2));
			//            if(isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers']))
			//            {
			//                $supplier_id = $_REQUEST['receive_from_suppliers'];
			//            }
			//            else{
			//                $supplier_id = '';
			//            }
			//            $data['result'] = $this->obj_stock_master->stock_search($date_from,$date_to,$supplier_id,2);
		}


		//        $suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
		//            if ($suppliers_arr)
		//                $data['suppliers'] = $suppliers_arr->result_array();

		$data['page_title'] = 'Print Issue';

		//        redirect(base_url() . 'inventory_management/printIssue', 'refresh');
		return $data['main_content'] = $this->load->view('inventory_management/printIssue', $data, TRUE);
		$this->load->view('layout/print', $data);
	}
}
