<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('login_model');
        $this->load->model('mobile_detect');
        
    }

    public function index() {
        $data = array();
        $data['breadcrumb'] = 'Login';
        $data['page_title'] = 'Login';
        /* $data['main_content'] = $this->load->view('auth/index', $data, TRUE); */
        $this->load->view('login', $data);
    }

    public function login() {
        $username = $this->input->post('username');
        $password = md5($this->input->post('password'));
        $result = $this->login_model->validate_user($username, $password);
        if (!empty($result[0]->pk_id)) {
            
            if($this->mobile_detect->isMobile()){
                $url = base_url('dataentry/index');
            }
            if ($role_id == 8) {
                redirect(base_url().'Common/landing', 'refresh');
            }else{
                redirect(base_url().'dashboard/index', 'refresh');
            }
        } else {
            redirect(base_url() . '/', 'refresh');
        }
    }// end login function

    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url().'welcome/login');
    }// end logout function

}
