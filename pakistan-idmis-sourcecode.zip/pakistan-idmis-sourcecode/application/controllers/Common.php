<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Common extends CI_Controller {
    public function __construct(){
        parent::__construct();
        // check_login_user();
        $this->load->model('Common_model');
    }// end __construct function

   	public function login(){
        $data['page_title'] = 'Common Login';
        $stakeholder_id = $this->uri->segment(3);
        if ($stakeholder_id != '') {
            $data['stakeholder_data'] = $this->Common_model->getDataByAbbreviation($stakeholder_id);
            $this->load->view('common/login', $data);
        }else{
            $this->load->view('common/404');
        }
    }// end login function

    public function submit_login(){
        $username = $this->input->post('username');
        $password = md5($this->input->post('password'));
        $abbreviation = $this->input->post('abbreviation');
        $user = $this->Common_model->login($username, $password);
        // var_dump($user[0]['stkname']);die;
        if (!empty($user[0]['stkname'])) {
            $this->session->set_userdata($user[0]);
            // echo "working";die;
            redirect(base_url().'Common/landing');
        }else{
            redirect(base_url().'Common/login/'.$abbreviation);
        }
    }// end submit_login function

    public function landing(){
        $data['page_title'] = 'Common Landing';
        $data['main_content'] = $this->load->view('common/landing_page', $data, TRUE);
        $this->load->view('layout/main', $data);
    }// end submit_login function
}// end Common class
?>