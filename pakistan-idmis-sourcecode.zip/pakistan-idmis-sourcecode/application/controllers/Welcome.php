<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    public function index(){
        $data = array(); 
        $data['page_title'] = 'Sample';
        $data['main_content'] = $this->load->view('empty_format', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function in_progress(){
        $data = array(); 
        $data['page_title'] = 'In Progress';
        $data['main_content'] = $this->load->view('in_progress', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

	public function view($page = 'login'){
		if ( ! file_exists(APPPATH.'views/'.$page.'.php')){
			// Whoops, we don't have a page for that!
			show_404();
		}
		$data['title'] = ucfirst($page); // Capitalize the first letter
		$this->load->view($page, $data);
	}// end view function

	public function login(){
		$data['title'] = 'Login'; // Capitalize the first letter
		$this->load->view('login', $data);
	}//end login function
}// end Welcome function