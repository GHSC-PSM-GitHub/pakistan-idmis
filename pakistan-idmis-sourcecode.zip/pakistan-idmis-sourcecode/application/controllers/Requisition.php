<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Requisition extends CI_Controller {

    public function __construct() {
//load database in autoload libraries 
        parent::__construct();
        $this->load->model('Requisition_model');
    }

    function add() {
//        var_dump($_SESSION);die;
        $year = $this->input->get('year');
        $month = $this->input->get('month');
        $data['data'] = $this->Requisition_model->get_products();
        $data['durationFrom'] = date('Y-m-d', strtotime("+1 month", strtotime($year . '-' . $month . '-01')));
        $prod = $this->Requisition_model->get_data();
        if(!empty($prod[0]['item_id'])){
            foreach ($prod as $itm){
                $data['data1'][(int)$itm['item_id']]['wh_obl_a'] = $itm['wh_obl_a'];
                $data['data1'][(int)$itm['item_id']]['wh_obl_c'] = $itm['wh_obl_c'];
                $data['data1'][(int)$itm['item_id']]['wh_received'] = $itm['wh_received'];
                $data['data1'][(int)$itm['item_id']]['wh_issue_up'] = $itm['wh_issue_up'];
                $data['data1'][(int)$itm['item_id']]['wh_cbl_c'] = $itm['wh_cbl_c'];
                $data['data1'][(int)$itm['item_id']]['wh_cbl_a'] = $itm['wh_cbl_a'];
            }
        }
        
//        echo '<pre>';
//        var_dump($data['data1'][583]);die;
        $data['Title'] = 'Requisition';
        $data['main_content'] = $this->load->view('requisition/add', $data, TRUE);
	$this->load->view('layout/main', $data);
//        print_r($data);exit;
    }
    function register()
    {
        $requisition_num = $this->Requisition_model->check_requisition_num();
        if (empty($requisition_num[0]['requisition_num'])) {
            $requisitionNum = 'RQ' . date('ym') . str_pad(1, 4, 0, STR_PAD_LEFT);
        } else {
            $requisitionNum = 'RQ' . date('ym') . str_pad((substr($requisition_num[0]['requisition_num'], 6) + 1), 4, 0, STR_PAD_LEFT);
        }
         $checked_items = implode(',',$_POST['chk']);
        $formData = array(
            'requisition_num' => $requisitionNum,
            'requisition_to' => $this->input->post('requisition_to'),
            'wh_id' => $this->input->post('wh_id'),
            'stk_id' => 1705,
            'date_from' => date('Y-m-d', strtotime($this->input->post('date_from'))),
            'date_to' => date('Y-m-d', strtotime($this->input->post('date_to'))),
            'requested_by' => $this->input->post('requested_by'),
            'approval_status' => 'pending',
            'requested_on' => date('Y-m-d', time()),
        );
        $master_id = $this->Requisition_model->insert($formData, $checked_items);
//        echo $master_id;die;
        if($master_id != ''){
               $formData_log = array(
                'master_id' => $master_id,
                'requisition_to' => $this->input->post('requisition_to'),
                'wh_id' => $this->input->post('wh_id'),
                'log_timestamp' => date('Y-m-d', time()),
                'requested_by' => $this->input->post('requested_by'),
                'approval_status' => 'pending',
                'user_id' => $this->input->post('requested_by'),
                'approval_level' => 'dist_lvl1',
            );

            $this->Requisition_model->insert_master_log($formData_log);
            $formData_details = array(
                'pk_master_id' => $master_id,
            );
            
            for ($i = 0; $i < count($_POST['itm_id']); $i++) {
                if(in_array($_POST['itm_id'][$i], $_POST['chk'])){
                    $formData_details['pk_master_id'] = $master_id;
                    $formData_details['itm_id'] = $_POST['itm_id'][$i];
                    $formData_details['avg_consumption'] = ((!empty($_POST['avg_consumption'][$i]))?$_POST['avg_consumption'][$i]:'0');
                    $formData_details['soh_dist'] = ((!empty($_POST['soh_dist'][$i])?$_POST['soh_dist'][$i]:'0'));
                    $formData_details['soh_field'] = ((!empty($_POST['soh_field'][$i])?$_POST['soh_field'][$i]:'0'));
                    $formData_details['total_stock'] = ((!empty($_POST['total_stock'][$i])?$_POST['total_stock'][$i]:'0'));
                    $formData_details['desired_stock'] = ((!empty($_POST['desired_stock'][$i])?$_POST['desired_stock'][$i]:'0'));
                    $formData_details['replenishment'] = ((!empty($_POST['replenishment'][$i])?$_POST['replenishment'][$i]:'0'));
                    $formData_details['qty_req_dist_lvl1'] = str_replace(',','',((!empty($_POST['quantity_requested'][$i])?$_POST['quantity_requested'][$i]:'0')));
                    $formData_details['sale_of_last_3_months'] = str_replace(',','',((!empty($_POST['sale_of_last_3_months'][$i])?$_POST['sale_of_last_3_months'][$i]:'0')));
                    $formData_details['sale_of_last_month'] = str_replace(',','',((!empty($_POST['sale_of_last_month'][$i]))?$_POST['sale_of_last_month'][$i]:'0'));
                    $formData_details['remarks_dist_lvl1'] = ((!empty($_POST['remarks'][$i]))?$_POST['remarks'][$i]:'');
                    $formData_details['qty_req_prov'] = str_replace(',','',((!empty($_POST['quantity_requested'][$i])?$_POST['quantity_requested'][$i]:'0')));
                    $this->Requisition_model->insert_stock_details($formData_details);
                }
            }
        }
        redirect(base_url().'Requisition/requisition_list');
    }
    
    function requisition_list()
    {
        $data = array();
        $data['provinces'] = $this->Requisition_model->get_provinces();
        $data['districts'] = $this->Requisition_model->get_districts();
        $data['search'] = $this->Requisition_model->search_requisition();
        $data['main_content'] = $this->load->view('requisition/requisition_list', $data, TRUE);
	$this->load->view('layout/main', $data);
    }
    function requisition_view()
    {
        $data = array();
        $data['main_content'] = $this->load->view('requisition/view', $data, TRUE);
	$this->load->view('layout/main', $data);
    }
       function distribution_plan_prov()
    {
        $data = array();
        $data['distribution_plan'] = $this->Requisition_model->search_distribution_plan_provincial();
        $data['main_content'] = $this->load->view('requisition/distribution_plan_provincial', $data, TRUE);
	$this->load->view('layout/main', $data);
    }
    

}

?>