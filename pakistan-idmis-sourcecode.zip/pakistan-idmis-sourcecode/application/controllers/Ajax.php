<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('locations');
        $this->load->model('warehouse');
        $this->load->model('user');
        $this->load->model('role_resources');
        $this->load->model('field_list_model');
//        $this->load->model('patients_model');
        $this->load->model('warehouse_population');
        $this->load->model('places');
//        $this->load->model('hr_info_model');
//        $this->load->model('malaria_medicines');
//        $this->load->model('village_model');
        $this->load->model('product_model');
        $this->load->model('Stakeholder');
        $this->load->model('Assign_approval_to_user');
        $this->load->model('warehouse');
        $this->load->model('wh_user');
        $this->load->model('Assign_resources_model');
    }

    public function combo(){
        $id = $_POST["id"];
        $lvl = $_POST['lvl'];
        $location = new locations();

        $result = $location->find_by_parent_id($id,$lvl);

        echo "<option value=>Select</option>";
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->location_name."</option>";
        }
    }
    
    public function combo_village(){
        $id = $this->input->post("id");
        $lvl = 3;
        $location = new locations();
        
        $result = $location->find_by_parent_id($id,$lvl);

        echo "<option value=>Select</option>";
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->PkLocID.">".$row->LocName."</option>";
        }
    }
    
      public function combo_village_facilities(){
        $id = $_POST["id"];
        $lvl = 3;
        $location = new locations();

        $result = $location->find_by_dist_id($id,$lvl);

        echo "<option value=>Select</option>";
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->wh_id.">".$row->wh_name."</option>";
        }
    }
    
    public function training_combo(){
//        if(isset($_POST["id"]));
//        {
            $id = $_POST["id"];
//        }
//        $lvl = $_POST['lvl'];
        $hr_info = new Hr_info_model();

        $hr_result = $hr_info->find_by_name($id);
        
        $hr_results = array();
        if($hr_result)
        {
            foreach ($hr_result->result_object() as $row){
                $hr_results = $row;
            }
        }
//        $response = array();
//        if(mysqli_num_rows($hr_result) > 0) {
//            while ($row = $hr_result->result_object()) {
//                $response = $row;
//            }
//        }
        // display JSON data
        echo json_encode($hr_results);
        
        
//        echo json_encode($hr_result);
//        echo "<option value=>Select</option>";
//        foreach ($result->result_object() as $row){
//            echo "<option value=".$row->pk_id.">".$row->location_name."</option>";
//        }
    }
    
    public function supplier_combo(){
//        if(isset($_POST["id"]));
//        {
            $whid = $_POST["id"];
//        }
//        $lvl = $_POST['lvl'];
        
        $hr_info = new Stakeholder();
        
        $getid = array();
        $getid = $hr_info->get_supplier_id($whid);
        
        if($getid)
        {
            foreach ($getid->result_array() as $row){
                $id = $row['stkid'];
            }
        }
        
        $hr_result = $hr_info->find_by_name($id);
        
        $hr_results = array();
        if($hr_result)
        {
            foreach ($hr_result->result_object() as $row){
                $hr_results = $row;
            }
        }
//        $response = array();
//        if(mysqli_num_rows($hr_result) > 0) {
//            while ($row = $hr_result->result_object()) {
//                $response = $row;
//            }
//        }
        // display JSON data
        echo json_encode($hr_results);
        
        
//        echo json_encode($hr_result);
//        echo "<option value=>Select</option>";
//        foreach ($result->result_object() as $row){
//            echo "<option value=".$row->pk_id.">".$row->location_name."</option>";
//        }
    }
    
    
    public function getproduct_bystkid(){

// 		header('Access-Control-Allow-Origin: *');  
// header('Access-Control-Allow-Headers: x-requested-with');  
// header('Content-Type: application/json');

//        if(isset($_POST["id"]));
//        {
          $stkid = $_REQUEST["id"];
          $stock_type = $_REQUEST["stock_type"];
//        }
//        $lvl = $_POST['lvl'];
        
        $hr_info = new Stakeholder();
        
        $getid = array();
        $getid = $hr_info->getproducts_bystkid($stkid,$stock_type);
        
        if($getid)
        {
//            foreach ($getid->result_array() as $row){
//                $id = $row['stkid'];
//            }
            $info = $getid->result_array();
        }
//        $infos = '
//        <div class="col-md-3">
//            <label class="example-text-input" required >Product<span style="color: red">*</span> </label>
//            <div class="controls">
//                <select class="select2me input-medium" name="product" id="product" required   style="width:100%;padding:10%;">
                 $infos =   '<option value="">Select</option>';
                       foreach ($info as $row) {
                 $infos .= '<option id='.$row['itm_id'].'_'.$row['product_type'].'_'.$stkid.' value='.$row['itm_id'] .'  > '. $row['itm_name'].' </option>';

                    }
//        $infos .=        '</select>  
//            </div>
//        </div>';
//        
//        $hr_result = $hr_info->find_by_name($id);
//        
//        $hr_results = array();
//        if($hr_result)
//        {
//            foreach ($hr_result->result_object() as $row){
//                $hr_results = $row;
//            }
//        }
//        $response = array();
//        if(mysqli_num_rows($hr_result) > 0) {
//            while ($row = $hr_result->result_object()) {
//                $response = $row;
//            }
//        }
        // display JSON data
        echo json_encode($infos);
        
        
//        echo json_encode($hr_result);
//        echo "<option value=>Select</option>";
//        foreach ($result->result_object() as $row){
//            echo "<option value=".$row->pk_id.">".$row->location_name."</option>";
//        }
    }
    
    public function stkresource_info(){
//        if(isset($_POST["id"]));
//        {
            $whid = $_POST["id"];
//        }
//        $lvl = $_POST['lvl'];
        
        $role_info = new Role_resources();
        
        $getid = array();
        $getid = $role_info->get_resources_info($whid);
        
        if($getid)
        {
            foreach ($getid->result_array() as $row){
                $id[] = $row['product_id'];
            }
        }
        
//        $hr_result = $hr_info->find_by_name($id);
//        
//        $hr_results = array();
//        if($hr_result)
//        {
//            foreach ($hr_result->result_object() as $row){
//                $hr_results = $row;
//            }
//        }
//        $response = array();
//        if(mysqli_num_rows($hr_result) > 0) {
//            while ($row = $hr_result->result_object()) {
//                $response = $row;
//            }
//        }
        // display JSON data
        echo json_encode($id);
        
        
//        echo json_encode($hr_result);
//        echo "<option value=>Select</option>";
//        foreach ($result->result_object() as $row){
//            echo "<option value=".$row->pk_id.">".$row->location_name."</option>";
//        }
    }
    
    public function resource_info(){
//        if(isset($_POST["id"]));
//        {
            $whid = $_POST["id"];
//        }
//        $lvl = $_POST['lvl'];
        
        $role_info = new Assign_resources_model();
        
        $getid = array();
        $getid = $role_info->get_resources_info($whid);
        
        if($getid)
        {
            foreach ($getid->result_array() as $row){
                $id['id'] = $row['resource_id'];
                $id['role_id'] = $row['role_id'];
                $id['view'] = $row['view'];
                $id['add'] = $row['add'];
                $id['rank'] = $row['rank'];
            }
        }
        
//        $hr_result = $hr_info->find_by_name($id);
//        
//        $hr_results = array();
//        if($hr_result)
//        {
//            foreach ($hr_result->result_object() as $row){
//                $hr_results = $row;
//            }
//        }
//        $response = array();
//        if(mysqli_num_rows($hr_result) > 0) {
//            while ($row = $hr_result->result_object()) {
//                $response = $row;
//            }
//        }
        // display JSON data
        echo json_encode($id);
        
        
//        echo json_encode($hr_result);
//        echo "<option value=>Select</option>";
//        foreach ($result->result_object() as $row){
//            echo "<option value=".$row->pk_id.">".$row->location_name."</option>";
//        }
    }
    
    
    public function assign_wh_info(){
        $whid = $_POST["id"];
        $role_info = new Wh_user();
        
        $getid = array();
        $getid = $role_info->get_assign_wh_info($whid);
        
        if($getid)
        {
            foreach ($getid->result_array() as $row){
                $id[] = $row['wh_id'];
            }
        }
        echo json_encode($id);
    }
    
    public function assign_approval_code_info(){
        $whid = $_POST["id"];
        $role_info = new Assign_approval_to_user();
        
        $getid = array();
        $getid = $role_info->get_assign_infos($whid);
        
//        if($getid)
//        {
//            foreach ($getid->result_array() as $row){
//                $arrovedid[] = $row['approval_code_id'];
//            }
//            $id['approval_code_id'] = $arrovedid;
//        }
        
        if($getid)
        {
            foreach ($getid->result_array() as $row){
                $id[] = $row['approval_code_id'];
            }
        }
        
        echo json_encode($id);
    }
    
     public function category_field_info(){
         
            $whid = $_POST["id"];
        $role_info = new Field_list_model();
        
        $getid = array();
        $id = array();
        $getid = $role_info->get_field_info($whid);
        
        if($getid)
        {
            foreach ($getid->result_array() as $row){
                $fid[] = $row['field_id'];
                $mid[] = $row['is_mandatory'];
            }
            $id['field_id'] = $fid;
            $id['is_mandatory'] = $mid;
        }
        
        echo json_encode($id);
    }
    
    public function assign_document_approver(){
         
            $whid = $_POST["id"];
        $role_info = new Assign_approval_to_user();
        
        $getid = array();
        $id = array();
        $getid = $role_info->get_assign_infos($whid);
        
        if($getid)
        {
            foreach ($getid->result_array() as $row){
                $arrovedid[] = $row['approval_code_id'];
            }
            $id['approval_code_id'] = $arrovedid;
        }
        
        echo json_encode($id);
    }
    
//    public function category_mandatory_info(){
//         
//            $whid = $_POST["id"];
//        $role_info = new Field_list_model();
//        
//        $getid = array();
//        $getid = $role_info->get_field_info($whid);
//        
//        if($getid)
//        {
//            foreach ($getid->result_array() as $row){
//                $idd[] = $row['is_mandatory'];
//            }
//        }
//        
//        echo json_encode($idd);
//    }
    
    public function get_species_pv(){
        
        $species_id = $_POST["species_id"];
        $gender_id = $_POST["gender_id"];
        $age_id = $_POST["age_id"];
        $dose_kg = '';
//        if(isset($pregnant_id))
//        {
        $pregnant_id = $_POST["pregnant_id"];
//        }
//        else{
//            $pregnant_id = '';
//        }
//        if(isset($patient_month_id))
//        {
        $patient_month_id = $_POST["patient_month_id"];
//        }
//        else{
//            $patient_month_id = '';
//        }
        $weight_id = $_POST["weight_id"];
//        $month_id = '';
        $fs_line_id = $_POST["type_id"];
//        }
//        $lvl = $_POST['lvl'];
        $hr_info = new Product_model();

//        if(!empty($pregnant_id) && $fs_line_id == '1')
//        {
//            $type_id = 1;
//            $hr_result = $hr_info->get_species_pv_one($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
//        }
//       else if(!empty($pregnant_id) && $fs_line_id == '2')
//        {
//            $type_id = 2;
//            $hr_result = $hr_info->get_species_pv_two($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
//        }
//        else 
            if(empty($pregnant_id) && $fs_line_id == '1' && $age_id =='0' && $patient_month_id >= '0' && $patient_month_id <= '11'  &&  $weight_id >= '5' && $weight_id <= '10' )
        {
            $type_id = 3;
            $hr_result = $hr_info->get_species_pv_one($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '1' && $age_id >='1' && $age_id <='4'  &&  $weight_id >= '11' && $weight_id<='18' )
        {
            $type_id = 4;
            $hr_result = $hr_info->get_species_pv_two($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '1' &&  $age_id >='5' && $age_id <='7'  &&  $weight_id >= '19' && $weight_id<='24' )
        {
            $type_id = 5;
            $hr_result = $hr_info->get_species_pv_three($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '1' &&  $age_id >='8' && $age_id <='13'  &&  $weight_id >= '25' && $weight_id<='50' )
        {
            $type_id = 6;
            $hr_result = $hr_info->get_species_pv_four($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '1' &&  $age_id >='14' &&  $weight_id >= '51' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pv_five($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' && $age_id < '3'  &&  $weight_id >= '5' && $weight_id <= '14' )
        {
            $type_id = 6;
            $hr_result = $hr_info->get_species_pv_six($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' &&  $age_id >='3' && $age_id <='8'  &&  $weight_id >= '15' && $weight_id<='24' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pv_seven($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' &&  $age_id >='8' && $age_id <='12'  &&  $weight_id >= '25' && $weight_id<='34' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pv_eight($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' &&  $age_id >='12'  &&  $weight_id >= '35' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pv_nine($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(!empty($pregnant_id) && $fs_line_id == '1')
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pv_ten($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$dose_kg);
        }
        else if(!empty($pregnant_id) && $fs_line_id == '2')
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pv_eleven($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$dose_kg);
        }
        
        
        
//        $species_pv = array();
//        if($hr_result)
//        {
//            foreach ($hr_result->result_object() as $row){
//                $species_pv = $row;
//            }
//        }
        ?>
        <h3>Medicines</h3>
    <table  class="table table-striped" id="species_pv_medicine_id" style="width : 100%;">
        
        <?php if(empty($pregnant_id) )
                {
           ?>
        
        <thead>
            <tr style="background: #FCB614;font-weight: bold;">
                <td>Sr.No</td>
                <td>Medicines</td>
                <!--<td>Days to Use</td>-->
                <td>Method</td>
                <td>Strength</td>
                <!--<td>Use</td>-->
                <td>Quantity</td>
                <td>Comments</td>
            </tr>
        </thead>
    <?php
//    echo start_table("datatable-buttons", array("S.No", "Checkup date","Disease Name", "Additional Notes","Action")); 
    ?>
    <?php
//    if(isset($_POST['user']))
//    {
//        $malaria_species_pv = $_POST['user'];
//    }
    if(isset($hr_result))
    {
    $count = 1; foreach ($hr_result->result_object() as $row) {
        $unit = floatval($row->dose_a_day);
        ?>
        <?php
            if($row->formula_or_hardcode == '1')
            {
        ?>
    <tr>
        <td><?php echo $count; ?></td>
        <td><input type="hidden"  id="species_pv_names" name="species_pv_names[]" value="<?php echo $row->product_name; ?>" /><?php echo $row->product_name; ?></td>
        <td><input type="hidden"  id="species_pv_unit" name="species_pv_unit[]" value="<?php echo $row->method_type; ?>" /><?php echo $row->method_type; ?></td>
        <td style="display: none"><input type="hidden"  id="species_pv_days" name="species_pv_days[]" value="<?php echo $row->no_of_days; ?>" /><?php echo $row->no_of_days; ?></td>
        <td style="display: none"><input type="hidden"  id="pv" name="pv" value="<?php echo '1'; ?>" /><?php echo '1'; ?></td>
        <td><input type="hidden"  id="species_pv_strength" name="species_pv_strength[]" value="<?php echo $row->strength; ?>" /><?php echo $row->strength; ?></td>
        
        <!--<td><?php echo $row->use; ?></td>-->
<!--         <td class="center" style="border: none;">
             <select name="medicine_usee[]" id="medicine_usee">        
                 <option value="(Daily 1 - Any Time)">(Daily 1 - Any Time)</option>
                 <option value="(Daily 2 - Any Time)">(Daily 2 - Any Time)</option>
                 <option value="1+0+0+0">1+0+0+0</option>
                 <option value="1+1+0+0">1+1+0+0</option>
                 <option value="1+1+1+0">1+1+1+0</option>
                 <option value="1+1+1+1">1+1+1+1</option>
                 <option value="0+1+0+0">0+1+0+0</option>
                 <option value="0+1+1+0">0+1+1+0</option>
                 <option value="0+1+1+1">0+1+1+1</option>
                 <option value="0+1+0+1">0+1+0+1</option>
                 <option value="0+0+1+0">0+0+1+0</option>
                 <option value="0+0+0+1">0+0+0+1</option>
                 <option value="0+0+1+1">0+0+1+1</option>
            </select>
        </td>   -->
        <td ><input type="hidden" name="species_pv_quantity[]" id="species_pv_quantity" value="<?php echo $row->no_of_days*($unit*$row->times_a_day); ?>" /><?php echo $row->no_of_days*($unit*$row->times_a_day); ?></td>
        <td >
            <textarea readonly style="width: 100%; height: 100%;border: 1px solid black;" name="species_pv_comments[]" id="species_pv_comments" value="<?php echo $row->no_of_days.' Days ( '.$row->dose_a_day.' x '.$row->times_a_day.' time / day )' ?>"><?php echo $row->no_of_days.' Days ( '.$row->dose_a_day.' x '.$row->times_a_day.' time / day )' ?>
            </textarea>
        </td>

<!--        <td>
            <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-deletecnote">
                <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
            </button>
            <button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>
        </td>-->
    </tr>
    <?php
            }
            if($row->formula_or_hardcode == '2')
            {
    ?>
    
    <tr>
        <td><?php echo $count; ?></td>
        <td><input type="hidden"  id="species_pv_names" name="species_pv_names[]" value="<?php echo $row->product_name; ?>" /><?php echo $row->product_name; ?></td>
        <td><input type="hidden"  id="species_pv_unit" name="species_pv_unit[]" value="<?php echo $row->method_type; ?>" /><?php echo $row->method_type; ?></td>
        <td style="display: none"><input type="hidden"  id="species_pv_days" name="species_pv_days[]" value="<?php echo $row->no_of_days; ?>" /><?php echo $row->no_of_days; ?></td>
        <td style="display: none"><input type="hidden"  id="pv" name="pv" value="<?php echo '1'; ?>" /><?php echo '1'; ?></td>
        <td><input type="hidden"  id="species_pv_strength" name="species_pv_strength[]" value="<?php echo $row->strength; ?>" /><?php echo $row->strength; ?></td>
        
        <!--<td><?php echo $row->use; ?></td>-->
<!--         <td class="center" style="border: none;">
             <select name="medicine_usee[]" id="medicine_usee">        
                 <option value="(Daily 1 - Any Time)">(Daily 1 - Any Time)</option>
                 <option value="(Daily 2 - Any Time)">(Daily 2 - Any Time)</option>
                 <option value="1+0+0+0">1+0+0+0</option>
                 <option value="1+1+0+0">1+1+0+0</option>
                 <option value="1+1+1+0">1+1+1+0</option>
                 <option value="1+1+1+1">1+1+1+1</option>
                 <option value="0+1+0+0">0+1+0+0</option>
                 <option value="0+1+1+0">0+1+1+0</option>
                 <option value="0+1+1+1">0+1+1+1</option>
                 <option value="0+1+0+1">0+1+0+1</option>
                 <option value="0+0+1+0">0+0+1+0</option>
                 <option value="0+0+0+1">0+0+0+1</option>
                 <option value="0+0+1+1">0+0+1+1</option>
            </select>
        </td>   -->
        <td ><input type="hidden" name="species_pv_quantity[]" id="species_pv_quantity" value="<?php echo $row->quantity; ?>" /><?php echo $row->quantity; ?></td>
        <td >
            <textarea readonly style="width: 100%; height: 100%;border: 1px solid black;" name="species_pv_comments[]" id="species_pv_comments" value="<?php echo $row->comments; ?>"><?php echo $row->comments; ?>
            </textarea>
        </td>

<!--        <td>
            <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-deletecnote">
                <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
            </button>
            <button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>
        </td>-->
    </tr>
    
    <?php
            }
    ?>
    <?php $count++; } 
    }else{
//       echo '<td colspan="6" class="text-center">No Record Found</td>';
    }?>
    <?php // echo end_table(); 
    
                } else if(!empty($pregnant_id)){
                    
                    ?>
        
        <thead>
            <tr style="background: #FCB614;font-weight: bold;">
                <td>Sr.No</td>
                <td>Weight</td>
                <td>Medicines</td>
                <td>Dose / KG</td>
                <td>Dose as per Weight</td>
                <!--<td>Days to Use</td>-->
                <td>Method</td>
                <td>Strength</td>
                <!--<td>Use</td>-->
                <td>Quantity</td>
                <td>Comments</td>
            </tr>
        </thead>
    <?php
//    echo start_table("datatable-buttons", array("S.No", "Checkup date","Disease Name", "Additional Notes","Action")); 
    ?>
    <?php
//    if(isset($_POST['user']))
//    {
//        $malaria_species_pv = $_POST['user'];
//    }
    if(isset($hr_result))
    {
    $count = 1; foreach ($hr_result->result_object() as $row) {
        $unit = floatval($row->dose_a_day);
        $strength = floatval($row->strength);
        $dose_as_per_weight = $row->dose_id*$weight_id;
        $dose_per_day = round($dose_as_per_weight / $strength,3);
        ?>
    <tr>
        <td><?php echo $count; ?></td>
        <td><input type="hidden"  id="species_pv_weight_id" name="species_pv_weight_id[]" value="<?php echo $weight_id; ?>" /><?php echo $weight_id; ?></td>
        <td><input type="hidden"  id="species_pv_names" name="species_pv_names[]" value="<?php echo $row->product_name; ?>" /><?php echo $row->product_name; ?></td>
        <td><input type="hidden"  id="species_pv_dose_kg" name="species_pv_dose_kg[]" value="<?php echo $row->dose_id; ?>" /><?php echo $row->dose_id; ?></td>
        <td><input type="hidden"  id="species_pv_dose_per_weight" name="species_pv_dose_per_weight[]" value="<?php echo $dose_as_per_weight; ?>" /><?php echo $dose_as_per_weight; ?></td>
        <td><input type="hidden"  id="species_pv_unit" name="species_pv_unit[]" value="<?php echo $row->method_type; ?>" /><?php echo $row->method_type; ?></td>
        <td style="display: none"><input type="hidden"  id="species_pv_days" name="species_pv_days[]" value="<?php echo $row->no_of_days; ?>" /><?php echo $row->no_of_days; ?></td>
        <td><input type="hidden"  id="species_pv_strength" name="species_pv_strength[]" value="<?php echo $row->strength; ?>" /><?php echo $row->strength; ?></td>
        
        <!--<td><?php echo $row->use; ?></td>-->
<!--         <td class="center" style="border: none;">
             <select name="medicine_usee[]" id="medicine_usee">        
                 <option value="(Daily 1 - Any Time)">(Daily 1 - Any Time)</option>
                 <option value="(Daily 2 - Any Time)">(Daily 2 - Any Time)</option>
                 <option value="1+0+0+0">1+0+0+0</option>
                 <option value="1+1+0+0">1+1+0+0</option>
                 <option value="1+1+1+0">1+1+1+0</option>
                 <option value="1+1+1+1">1+1+1+1</option>
                 <option value="0+1+0+0">0+1+0+0</option>
                 <option value="0+1+1+0">0+1+1+0</option>
                 <option value="0+1+1+1">0+1+1+1</option>
                 <option value="0+1+0+1">0+1+0+1</option>
                 <option value="0+0+1+0">0+0+1+0</option>
                 <option value="0+0+0+1">0+0+0+1</option>
                 <option value="0+0+1+1">0+0+1+1</option>
            </select>
        </td>   -->
        <td ><input type="hidden" name="species_pv_quantity[]" id="species_pv_quantity" value="<?php echo ceil($row->no_of_days*($dose_per_day*$row->times_a_day)); ?>" /><?php echo ceil($row->no_of_days*($dose_per_day*$row->times_a_day)); ?></td>
        <td >
            <textarea readonly style="width: 100%; height: 100%;border: 1px solid black;" name="species_pv_comments[]" id="species_pv_comments" value="<?php echo $row->no_of_days.' Days ( '.$dose_per_day.' x '.$row->times_a_day.' time / day )' ?>"><?php echo $row->no_of_days.' Days ( '.$dose_per_day.' x '.$row->times_a_day.' time / day )' ?>
            </textarea>
        </td>

<!--        <td>
            <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-deletecnote">
                <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
            </button>
            <button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>
        </td>-->
    </tr>
    <?php $count++; } 
    }else{
//       echo '<td colspan="9" class="text-center">No Record Found</td>';
    }?>
    <?php // echo end_table(); 
    
                }?>
    </table>
        
         <?php
        
        
//        $response = array();
//        if(mysqli_num_rows($hr_result) > 0) {
//            while ($row = $hr_result->result_object()) {
//                $response = $row;
//            }
//        }
        // display JSON data
//        echo json_encode($species_pv);
    }
    
    
    
    
    public function get_species_pf(){
        
        $species_id = $_POST["species_id"];
        $gender_id = $_POST["gender_id"];
        $age_id = $_POST["age_id"];
        $pregnant_stage = $_POST["pregnant_stage"];
//        if(isset($pregnant_id))
//        {
        $pregnant_id = $_POST["pregnant_id"];
//        }
//        else{
//            $pregnant_id = '';
//        }
//        if(isset($patient_month_id))
//        {
        $patient_month_id = $_POST["patient_month_id"];
//        }
//        else{
//            $patient_month_id = '';
//        }
        $weight_id = $_POST["weight_id"];
//        $month_id = '';
        $fs_line_id = $_POST["type_id"];
//        }
//        $lvl = $_POST['lvl'];
        $hr_info = new Product_model();

//        if(!empty($pregnant_id) && $fs_line_id == '1')
//        {
//            $type_id = 1;
//            $hr_result = $hr_info->get_species_pf_one($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
//        }
//       else if(!empty($pregnant_id) && $fs_line_id == '2')
//        {
//            $type_id = 2;
//            $hr_result = $hr_info->get_species_pf_two($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
//        }
//        else 
        if(empty($pregnant_id) && $fs_line_id == '1' && $age_id < '3' &&  $weight_id >= '5' && $weight_id <= '14' )
        {
            $type_id = 3;
            $hr_result = $hr_info->get_species_pf_one($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '1' && $age_id >='3' && $age_id <='8'  &&  $weight_id >= '15' && $weight_id<='24' )
        {
            $type_id = 4;
            $hr_result = $hr_info->get_species_pf_two($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '1' &&  $age_id >='8' && $age_id <='12'  &&  $weight_id >= '25' && $weight_id<='34' )
        {
            $type_id = 5;
            $hr_result = $hr_info->get_species_pf_three($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '1' &&  $age_id >='12'  &&  $weight_id >= '35' )
        {
            $type_id = 6;
            $hr_result = $hr_info->get_species_pf_four($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' &&  $weight_id >='5' &&  $weight_id <= '8' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pf_five($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' &&  $weight_id >='9' &&  $weight_id <= '16' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pf_six($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' &&  $weight_id >='17' &&  $weight_id <= '24' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pf_seven($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' &&  $weight_id >='25' &&  $weight_id <= '35' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pf_eight($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' &&  $weight_id >='36' &&  $weight_id <= '74' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pf_nine($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' &&  $weight_id >='75' &&  $weight_id <= '100' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pf_ten($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        
        
        
        
        else if(!empty($pregnant_id) && $fs_line_id == '1' && $pregnant_stage == '1')
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pf_eleven($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage);
        }
        else if(!empty($pregnant_id) && $fs_line_id == '2' && $pregnant_stage == '1')
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pf_twelve($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage);
        }
        else if(!empty($pregnant_id) && $fs_line_id == '1' && $pregnant_stage == '2')
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pf_thirteen($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage);
        }
        else if(!empty($pregnant_id) && $fs_line_id == '2' && $pregnant_stage == '2')
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_pf_fourteen($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage);
        }
        
//        $species_pv = array();
//        if($hr_result)
//        {
//            foreach ($hr_result->result_object() as $row){
//                $species_pv = $row;
//            }
//        }
        ?>
        <h3>Medicines</h3>
    <table  class="table table-striped" id="species_pf_medicine_id" style="width : 100%;">
        
        <?php if(empty($pregnant_id) )
                {
           ?>
        
        <thead>
            <tr style="background: #FCB614;font-weight: bold;">
                <td>Sr.No</td>
                <td>Medicines</td>
                <!--<td>Days to Use</td>-->
                <td>Method</td>
                <td>Strength</td>
                <!--<td>Use</td>-->
                <td>Quantity</td>
                <td>Comments</td>
            </tr>
        </thead>
    <?php
//    echo start_table("datatable-buttons", array("S.No", "Checkup date","Disease Name", "Additional Notes","Action")); 
    ?>
    <?php
//    if(isset($_POST['user']))
//    {
//        $malaria_species_pv = $_POST['user'];
//    }
    if(isset($hr_result))
    {
    $count = 1; foreach ($hr_result->result_object() as $row) { 
        $unit = floatval($row->dose_a_day);
        ?>
    <tr>
        <td><?php echo $count; ?></td>
        <td><input type="hidden"  id="species_pf_names" name="species_pf_names[]" value="<?php echo $row->product_name; ?>" /><?php echo $row->product_name; ?></td>
        <td><input type="hidden"  id="species_pf_unit" name="species_pf_unit[]" value="<?php echo $row->method_type; ?>" /><?php echo $row->method_type; ?></td>
        <td style="display: none"><input type="hidden"  id="species_pf_days" name="species_pf_days[]" value="<?php echo $row->no_of_days; ?>" /><?php echo $row->no_of_days; ?></td>
        <td style="display: none"><input type="hidden"  id="pf" name="pf" value="<?php echo '1'; ?>" /><?php echo '1'; ?></td>
        <td><input type="hidden"  id="species_pf_strength" name="species_pf_strength[]" value="<?php echo $row->strength; ?>" /><?php echo $row->strength; ?></td>
        
        <!--<td><?php echo $row->use; ?></td>-->
<!--         <td class="center" style="border: none;">
             <select name="medicine_usee[]" id="medicine_usee">        
                 <option value="(Daily 1 - Any Time)">(Daily 1 - Any Time)</option>
                 <option value="(Daily 2 - Any Time)">(Daily 2 - Any Time)</option>
                 <option value="1+0+0+0">1+0+0+0</option>
                 <option value="1+1+0+0">1+1+0+0</option>
                 <option value="1+1+1+0">1+1+1+0</option>
                 <option value="1+1+1+1">1+1+1+1</option>
                 <option value="0+1+0+0">0+1+0+0</option>
                 <option value="0+1+1+0">0+1+1+0</option>
                 <option value="0+1+1+1">0+1+1+1</option>
                 <option value="0+1+0+1">0+1+0+1</option>
                 <option value="0+0+1+0">0+0+1+0</option>
                 <option value="0+0+0+1">0+0+0+1</option>
                 <option value="0+0+1+1">0+0+1+1</option>
            </select>
        </td>   -->
        <td ><input type="hidden" name="species_pf_quantity[]" id="species_pf_quantity" value="<?php echo $row->no_of_days*($unit*$row->times_a_day); ?>" /><?php echo $row->no_of_days*($unit*$row->times_a_day); ?></td>
        <td >
            <textarea readonly style="width: 100%; height: 100%;border: 1px solid black;" name="species_pf_comments[]" id="species_pf_comments" value="<?php echo $row->no_of_days.' Days ( '.$row->dose_a_day.' x '.$row->times_a_day.' time / day )' ?>"><?php echo $row->no_of_days.' Days ( '.$row->dose_a_day.' x '.$row->times_a_day.' time / day )' ?>
            </textarea>
        </td>

<!--        <td>
            <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-deletecnote">
                <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
            </button>
            <button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>
        </td>-->
    </tr>
    <?php $count++; } 
    }else{
//       echo '<td colspan="6" class="text-center">No Record Found</td>';
    }?>
    <?php // echo end_table(); 
    
                } else if(!empty($pregnant_id)){
                    
                    ?>
        
        <thead>
            <tr style="background: #FCB614;font-weight: bold;">
                <td>Sr.No</td>
                <td>Weight</td>
                <td>Medicines</td>
                <td>Dose / KG</td>
                <td>Dose as per Weight</td>
                <!--<td>Days to Use</td>-->
                <td>Method</td>
                <td>Strength</td>
                <!--<td>Use</td>-->
                <td>Quantity</td>
                <td>Comments</td>
            </tr>
        </thead>
    <?php
//    echo start_table("datatable-buttons", array("S.No", "Checkup date","Disease Name", "Additional Notes","Action")); 
    ?>
    <?php
//    if(isset($_POST['user']))
//    {
//        $malaria_species_pv = $_POST['user'];
//    }
    if(isset($hr_result))
    {
    $count = 1; foreach ($hr_result->result_object() as $row) {
        $unit = floatval($row->dose_a_day);
        $strength = floatval($row->strength);
        $dose_as_per_weight = $row->dose_id*$weight_id;
        $dose_per_day = round($dose_as_per_weight / $strength,3);
        ?>
    <tr>
        <td><?php echo $count; ?></td>
        <td><input type="hidden"  id="species_pf_weight_id" name="species_pf_weight_id[]" value="<?php echo $weight_id; ?>" /><?php echo $weight_id; ?></td>
        <td><input type="hidden"  id="species_pf_names" name="species_pf_names[]" value="<?php echo $row->product_name; ?>" /><?php echo $row->product_name; ?></td>
        <td><input type="hidden"  id="species_pf_dose_kg" name="species_pf_dose_kg[]" value="<?php echo $row->dose_id; ?>" /><?php echo $row->dose_id; ?></td>
        <td><input type="hidden"  id="species_pf_dose_per_weight" name="species_pf_dose_per_weight[]" value="<?php echo $dose_as_per_weight; ?>" /><?php echo $dose_as_per_weight; ?></td>
        <td><input type="hidden"  id="species_pf_unit" name="species_pf_unit[]" value="<?php echo $row->method_type; ?>" /><?php echo $row->method_type; ?></td>
        <td style="display: none"><input type="hidden"  id="species_pf_days" name="species_pf_days[]" value="<?php echo $row->no_of_days; ?>" /><?php echo $row->no_of_days; ?></td>
        <td><input type="hidden"  id="species_pf_strength" name="species_pf_strength[]" value="<?php echo $row->strength; ?>" /><?php echo $row->strength; ?></td>
        
        <!--<td><?php echo $row->use; ?></td>-->
<!--         <td class="center" style="border: none;">
             <select name="medicine_usee[]" id="medicine_usee">        
                 <option value="(Daily 1 - Any Time)">(Daily 1 - Any Time)</option>
                 <option value="(Daily 2 - Any Time)">(Daily 2 - Any Time)</option>
                 <option value="1+0+0+0">1+0+0+0</option>
                 <option value="1+1+0+0">1+1+0+0</option>
                 <option value="1+1+1+0">1+1+1+0</option>
                 <option value="1+1+1+1">1+1+1+1</option>
                 <option value="0+1+0+0">0+1+0+0</option>
                 <option value="0+1+1+0">0+1+1+0</option>
                 <option value="0+1+1+1">0+1+1+1</option>
                 <option value="0+1+0+1">0+1+0+1</option>
                 <option value="0+0+1+0">0+0+1+0</option>
                 <option value="0+0+0+1">0+0+0+1</option>
                 <option value="0+0+1+1">0+0+1+1</option>
            </select>
        </td>   -->
        <td ><input type="hidden" name="species_pf_quantity[]" id="species_pf_quantity" value="<?php if($fs_line_id == '1' && $pregnant_stage == '1') {echo ceil($row->no_of_days*($row->times_a_day));} else {echo ceil($row->no_of_days*($dose_per_day*$row->times_a_day));} ?>" /><?php if($fs_line_id == '1' && $pregnant_stage == '1') {echo ceil($row->no_of_days*($row->times_a_day));} else {echo ceil($row->no_of_days*($dose_per_day*$row->times_a_day));} ?></td>
        <td >
            <textarea readonly style="width: 100%; height: 100%;border: 1px solid black;" name="species_pf_comments[]" id="species_pf_comments" value="<?php echo $row->no_of_days.' Days ( '.$dose_per_day.' x '.$row->times_a_day.' time / day )' ?>"><?php echo $row->no_of_days.' Days ( '.$dose_per_day.' x '.$row->times_a_day.' time / day )' ?>
            </textarea>
        </td>

<!--        <td>
            <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-deletecnote">
                <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
            </button>
            <button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>
        </td>-->
    </tr>
    <?php $count++; } 
    }else{
//       echo '<td colspan="9" class="text-center">No Record Found</td>';
    }?>
    <?php // echo end_table(); 
    
                }?>
    </table>
        
         <?php
        
        
//        $response = array();
//        if(mysqli_num_rows($hr_result) > 0) {
//            while ($row = $hr_result->result_object()) {
//                $response = $row;
//            }
//        }
        // display JSON data
//        echo json_encode($species_pv);
    }
    
    
    
    
    
    public function get_species_mix(){
        
        $pregnant_stage = $_POST["pregnant_stage"];
        $species_id = $_POST["species_id"];
        $gender_id = $_POST["gender_id"];
        $age_id = $_POST["age_id"];
//        if(isset($pregnant_id))
//        {
        $pregnant_id = $_POST["pregnant_id"];
//        }
//        else{
//            $pregnant_id = '';
//        }
//        if(isset($patient_month_id))
//        {
        $patient_month_id = $_POST["patient_month_id"];
//        }
//        else{
//            $patient_month_id = '';
//        }
        $weight_id = $_POST["weight_id"];
//        $month_id = '';
        $fs_line_id = $_POST["type_id"];
//        }
//        $lvl = $_POST['lvl'];
        $hr_info = new Product_model();

        if(empty($pregnant_id) && $fs_line_id == '1' && $age_id < '3' &&  $weight_id >= '5' && $weight_id <= '14' )
        {
            $type_id = 3;
            $hr_result = $hr_info->get_species_mix_one($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '1' && $age_id >='3' && $age_id <='5'  &&  $weight_id >= '15' && $weight_id<='18' )
        {
            $type_id = 4;
            $hr_result = $hr_info->get_species_mix_two($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '1' &&  $age_id >='6' && $age_id <='8'  &&  $weight_id >= '19' && $weight_id<='24' )
        {
            $type_id = 5;
            $hr_result = $hr_info->get_species_mix_three($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '1' &&  $age_id >= '9' && $age_id <='12'  &&  $weight_id >= '25' && $weight_id<='34' )
        {
            $type_id = 6;
            $hr_result = $hr_info->get_species_mix_four($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '1' &&  $age_id >= '13' &&  $weight_id >= '35' )
        {
            $type_id = 6;
            $hr_result = $hr_info->get_species_mix_five($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' &&  $weight_id >='5' &&  $weight_id <= '8' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_mix_six($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' &&  $weight_id >='9' &&  $weight_id <= '16' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_mix_seven($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' &&  $weight_id >='17' &&  $weight_id <= '24' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_mix_eight($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' &&  $weight_id >='25' &&  $weight_id <= '35' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_mix_nine($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' &&  $weight_id >='36' &&  $weight_id <= '74' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_mix_ten($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '2' &&  $weight_id >='75' &&  $weight_id <= '100' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_mix_eleven($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
        }
        
        
        else if(!empty($pregnant_id) && $fs_line_id == '1' && $pregnant_stage == '1')
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_mix_twelve($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage);
        }
        else if(!empty($pregnant_id) && $fs_line_id == '2' && $pregnant_stage == '1')
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_mix_thirteen($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage);
        }
        else if(!empty($pregnant_id) && $fs_line_id == '1' && $pregnant_stage == '2')
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_mix_fourteen($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage);
        }
        else if(!empty($pregnant_id) && $fs_line_id == '2' && $pregnant_stage == '2')
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_mix_fifteen($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage);
        }
        
//        $species_pv = array();
//        if($hr_result)
//        {
//            foreach ($hr_result->result_object() as $row){
//                $species_pv = $row;
//            }
//        }
        ?>
        <h3>Medicines</h3>
    <table  class="table table-striped" id="species_mix_medicine_id" style="width : 100%;">
        <?php if(empty($pregnant_id) && $fs_line_id != '3')
                {
           ?>
        <thead>
            <tr style="background: #FCB614;font-weight: bold;">
                <td>Sr.No</td>
                <td>Medicines</td>
                <!--<td>Days to Use</td>-->
                <td>Method</td>
                <td>Strength</td>
                <!--<td>Use</td>-->
                <td>Quantity</td>
                <td>Comments</td>
            </tr>
        </thead>
    <?php
//    echo start_table("datatable-buttons", array("S.No", "Checkup date","Disease Name", "Additional Notes","Action")); 
    ?>
    <?php
//    if(isset($_POST['user']))
//    {
//        $malaria_species_pv = $_POST['user'];
//    }
    if(isset($hr_result))
    {
    $count = 1; foreach ($hr_result->result_object() as $row) { 
        $unit = floatval($row->dose_a_day);
        ?>
    <tr>
        <td><?php echo $count; ?></td>
        <td><input type="hidden"  id="species_mix_names" name="species_mix_names[]" value="<?php echo $row->product_name; ?>" /><?php echo $row->product_name; ?></td>
        <td><input type="hidden"  id="species_mix_unit" name="species_mix_unit[]" value="<?php echo $row->method_type; ?>" /><?php echo $row->method_type; ?></td>
        <td style="display: none"><input type="hidden"  id="species_mix_days" name="species_mix_days[]" value="<?php echo $row->no_of_days; ?>" /><?php echo $row->no_of_days; ?></td>
        <td style="display: none"><input type="hidden"  id="mix" name="mix" value="<?php echo '1'; ?>" /><?php echo '1'; ?></td>
        <td><input type="hidden"  id="species_mix_strength" name="species_mix_strength[]" value="<?php echo $row->strength; ?>" /><?php echo $row->strength; ?></td>
        
        <!--<td><?php echo $row->use; ?></td>-->
<!--         <td class="center" style="border: none;">
             <select name="medicine_usee[]" id="medicine_usee">        
                 <option value="(Daily 1 - Any Time)">(Daily 1 - Any Time)</option>
                 <option value="(Daily 2 - Any Time)">(Daily 2 - Any Time)</option>
                 <option value="1+0+0+0">1+0+0+0</option>
                 <option value="1+1+0+0">1+1+0+0</option>
                 <option value="1+1+1+0">1+1+1+0</option>
                 <option value="1+1+1+1">1+1+1+1</option>
                 <option value="0+1+0+0">0+1+0+0</option>
                 <option value="0+1+1+0">0+1+1+0</option>
                 <option value="0+1+1+1">0+1+1+1</option>
                 <option value="0+1+0+1">0+1+0+1</option>
                 <option value="0+0+1+0">0+0+1+0</option>
                 <option value="0+0+0+1">0+0+0+1</option>
                 <option value="0+0+1+1">0+0+1+1</option>
            </select>
        </td>   -->
        <td ><input type="hidden" name="species_mix_quantity[]" id="species_mix_quantity" value="<?php echo $row->no_of_days*($unit*$row->times_a_day); ?>" /><?php echo $row->no_of_days*($unit*$row->times_a_day); ?></td>
        <td >
            <textarea readonly style="width: 100%; height: 100%;border: 1px solid black;" name="species_mix_comments[]" id="species_mix_comments" value="<?php echo $row->no_of_days.' Days ( '.$row->dose_a_day.' x '.$row->times_a_day.' time / day )' ?>"><?php echo $row->no_of_days.' Days ( '.$row->dose_a_day.' x '.$row->times_a_day.' time / day )' ?>
            </textarea>
        </td>

<!--        <td>
            <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-deletecnote">
                <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
            </button>
            <button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>
        </td>-->
    </tr>
    <?php $count++; } 
    }else{
//       echo '<td colspan="6" class="text-center">No Record Found</td>';
    }?>
    <?php // echo end_table(); 
     } else if(!empty($pregnant_id) && $fs_line_id != '3'){
                    
                    ?>
        
        <thead>
            <tr style="background: #FCB614;font-weight: bold;">
                <td>Sr.No</td>
                <td>Weight</td>
                <td>Medicines</td>
                <td>Dose / KG</td>
                <td>Dose as per Weight</td>
                <!--<td>Days to Use</td>-->
                <td>Method</td>
                <td>Strength</td>
                <!--<td>Use</td>-->
                <td>Quantity</td>
                <td>Comments</td>
            </tr>
        </thead>
    <?php
//    echo start_table("datatable-buttons", array("S.No", "Checkup date","Disease Name", "Additional Notes","Action")); 
    ?>
    <?php
//    if(isset($_POST['user']))
//    {
//        $malaria_species_pv = $_POST['user'];
//    }
    if(isset($hr_result))
    {
    $count = 1; foreach ($hr_result->result_object() as $row) {
        $unit = floatval($row->dose_a_day);
        $strength = floatval($row->strength);
        $dose_as_per_weight = $row->dose_id*$weight_id;
        $dose_per_day = round($dose_as_per_weight / $strength,3);
        ?>
    <tr>
        <td><?php echo $count; ?></td>
        <td><input type="hidden"  id="species_mix_weight_id" name="species_mix_weight_id[]" value="<?php echo $weight_id; ?>" /><?php echo $weight_id; ?></td>
        <td><input type="hidden"  id="species_mix_names" name="species_mix_names[]" value="<?php echo $row->product_name; ?>" /><?php echo $row->product_name; ?></td>
        <td><input type="hidden"  id="species_mix_dose_kg" name="species_mix_dose_kg[]" value="<?php echo $row->dose_id; ?>" /><?php echo $row->dose_id; ?></td>
        <td><input type="hidden"  id="species_mix_dose_per_weight" name="species_mix_dose_per_weight[]" value="<?php echo $dose_as_per_weight; ?>" /><?php echo $dose_as_per_weight; ?></td>
        <td><input type="hidden"  id="species_mix_unit" name="species_mix_unit[]" value="<?php echo $row->method_type; ?>" /><?php echo $row->method_type; ?></td>
        <td style="display: none"><input type="hidden"  id="species_mix_days" name="species_mix_days[]" value="<?php echo $row->no_of_days; ?>" /><?php echo $row->no_of_days; ?></td>
        <td><input type="hidden"  id="species_mix_strength" name="species_mix_strength[]" value="<?php echo $row->strength; ?>" /><?php echo $row->strength; ?></td>
        
        <!--<td><?php echo $row->use; ?></td>-->
<!--         <td class="center" style="border: none;">
             <select name="medicine_usee[]" id="medicine_usee">        
                 <option value="(Daily 1 - Any Time)">(Daily 1 - Any Time)</option>
                 <option value="(Daily 2 - Any Time)">(Daily 2 - Any Time)</option>
                 <option value="1+0+0+0">1+0+0+0</option>
                 <option value="1+1+0+0">1+1+0+0</option>
                 <option value="1+1+1+0">1+1+1+0</option>
                 <option value="1+1+1+1">1+1+1+1</option>
                 <option value="0+1+0+0">0+1+0+0</option>
                 <option value="0+1+1+0">0+1+1+0</option>
                 <option value="0+1+1+1">0+1+1+1</option>
                 <option value="0+1+0+1">0+1+0+1</option>
                 <option value="0+0+1+0">0+0+1+0</option>
                 <option value="0+0+0+1">0+0+0+1</option>
                 <option value="0+0+1+1">0+0+1+1</option>
            </select>
        </td>   -->
        <td ><input type="hidden" name="species_mix_quantity[]" id="species_mix_quantity" value="<?php if($fs_line_id == '1' && $pregnant_stage == '1') { echo ceil($row->no_of_days*($row->times_a_day)); } else { echo ceil($row->no_of_days*($dose_per_day*$row->times_a_day)); }?>" /><?php if($fs_line_id == '1' && $pregnant_stage == '1') { echo ceil($row->no_of_days*($row->times_a_day)); } else { echo ceil($row->no_of_days*($dose_per_day*$row->times_a_day)); }?></td>
        <td >
            <textarea readonly style="width: 100%; height: 100%;border: 1px solid black;" name="species_mix_comments[]" id="species_mix_comments" value="<?php echo $row->no_of_days.' Days ( '.$dose_per_day.' x '.$row->times_a_day.' time / day )' ?>"><?php echo $row->no_of_days.' Days ( '.$dose_per_day.' x '.$row->times_a_day.' time / day )' ?>
            </textarea>
        </td>

<!--        <td>
            <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-deletecnote">
                <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
            </button>
            <button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>
        </td>-->
    </tr>
    <?php $count++; } 
    }else{
//       echo '<td colspan="9" class="text-center">No Record Found</td>';
    }?>
    <?php // echo end_table(); 
    
                }?>
    </table>
        
         <?php
        
        
//        $response = array();
//        if(mysqli_num_rows($hr_result) > 0) {
//            while ($row = $hr_result->result_object()) {
//                $response = $row;
//            }
//        }
        // display JSON data
//        echo json_encode($species_pv);
    }
    
    
    
    
    
    
    public function get_species_normal(){
        
        $species_id = $_POST["species_id"];
        $gender_id = $_POST["gender_id"];
        $age_id = $_POST["age_id"];
//        if(isset($pregnant_id))
//        {
        $pregnant_id = $_POST["pregnant_id"];
//        }
//        else{
//            $pregnant_id = '';
//        }
//        if(isset($patient_month_id))
//        {
        $patient_month_id = $_POST["patient_month_id"];
//        }
//        else{
//            $patient_month_id = '';
//        }
        $weight_id = $_POST["weight_id"];
//        $month_id = '';
        $fs_line_id = $_POST["type_id"];
//        }
//        $lvl = $_POST['lvl'];
//        $hr_info = new Malaria_medicines();
        $hr_info = new Product_model();

//        if(!empty($pregnant_id) && $fs_line_id == '1')
//        {
//            $type_id = 1;
//            $hr_result = $hr_info->get_species_normal_one($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
//        }
//        else if(!empty($pregnant_id) && $fs_line_id == '1')
//        {
//            $type_id = 2;
//            $hr_result = $hr_info->get_species_normal_two($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
//        }
//      else
        if(empty($pregnant_id) && $fs_line_id == '1' && $age_id =='0' && $patient_month_id >= '0' && $patient_month_id <= '11'  &&  $weight_id >= '5' && $weight_id <= '10' )
        {
            $type_id = 3;
            $hr_result = $hr_info->get_species_normal_one($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$weight_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '1' && $age_id >='1' && $age_id <='4'  &&  $weight_id >= '11' && $weight_id<='18' )
        {
            $type_id = 4;
            $hr_result = $hr_info->get_species_normal_two($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$weight_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '1' &&  $age_id >='5' && $age_id <='7'  &&  $weight_id >= '19' && $weight_id<='24' )
        {
            $type_id = 5;
            $hr_result = $hr_info->get_species_normal_three($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$weight_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '1' &&  $age_id >='8' && $age_id <='13'  &&  $weight_id >= '25' && $weight_id<='50' )
        {
            $type_id = 6;
            $hr_result = $hr_info->get_species_normal_four($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$weight_id);
        }
        else if(empty($pregnant_id) && $fs_line_id == '1' &&  $age_id >='14' &&  $weight_id >= '50' )
        {
            $type_id = 7;
            $hr_result = $hr_info->get_species_normal_five($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$weight_id);
        }
        
//        $species_pv = array();
//        if($hr_result)
//        {
//            foreach ($hr_result->result_object() as $row){
//                $species_pv = $row;
//            }
//        }
        ?>
        <h3>Medicines</h3>
    <table  class="table table-striped" id="species_normal_medicine_id" style="width : 100%;">
        <thead>
            <tr style="background: #FCB614;font-weight: bold;">
                <td>Sr.No</td>
                <td>Medicines</td>
                <!--<td>Days to Use</td>-->
                <td>Method</td>
                <td>Strength</td>
                <!--<td>Use</td>-->
                <td>Quantity</td>
                <td>Comments</td>
            </tr>
        </thead>
    <?php
//    echo start_table("datatable-buttons", array("S.No", "Checkup date","Disease Name", "Additional Notes","Action")); 
    ?>
    <?php
//    if(isset($_POST['user']))
//    {
//        $malaria_species_pv = $_POST['user'];
//    }
    if(isset($hr_result) && isset($fs_line_id) && $fs_line_id == '1')
    {
    $count = 1; foreach ($hr_result->result_object() as $row) { 
//        $unit = preg_replace("[^a-zA-Z]", '', $row->dose_a_day);
        $unit = floatval($row->dose_a_day);
//        echo $unit;
        ?>
        <?php
            if($row->formula_or_hardcode == '1')
            {
        ?>
    <tr>
        <td><?php echo $count; ?></td>
        <td><input type="hidden"  id="species_normal_names" name="species_normal_names[]" value="<?php echo $row->product_name; ?>" /><?php echo $row->product_name; ?></td>
        <td><input type="hidden"  id="species_normal_unit" name="species_normal_unit[]" value="<?php echo $row->method_type; ?>" /><?php echo $row->method_type; ?></td>
        <td style="display: none"><input type="hidden"  id="species_normal_days" name="species_normal_days[]" value="<?php echo $row->no_of_days; ?>" /><?php echo $row->no_of_days; ?></td>
        <td><input type="hidden"  id="species_normal_strength" name="species_normal_strength[]" value="<?php echo $row->strength; ?>" /><?php echo $row->strength; ?></td>
        
        <!--<td><?php echo $row->use; ?></td>-->
<!--         <td class="center" style="border: none;">
             <select name="medicine_usee[]" id="medicine_usee">        
                 <option value="(Daily 1 - Any Time)">(Daily 1 - Any Time)</option>
                 <option value="(Daily 2 - Any Time)">(Daily 2 - Any Time)</option>
                 <option value="1+0+0+0">1+0+0+0</option>
                 <option value="1+1+0+0">1+1+0+0</option>
                 <option value="1+1+1+0">1+1+1+0</option>
                 <option value="1+1+1+1">1+1+1+1</option>
                 <option value="0+1+0+0">0+1+0+0</option>
                 <option value="0+1+1+0">0+1+1+0</option>
                 <option value="0+1+1+1">0+1+1+1</option>
                 <option value="0+1+0+1">0+1+0+1</option>
                 <option value="0+0+1+0">0+0+1+0</option>
                 <option value="0+0+0+1">0+0+0+1</option>
                 <option value="0+0+1+1">0+0+1+1</option>
            </select>
        </td>   -->
        <td ><input type="hidden" name="species_normal_quantity[]" id="species_normal_quantity" value="<?php echo $row->no_of_days*($unit*$row->times_a_day); ?>" /><?php echo $row->no_of_days*($unit*$row->times_a_day); ?></td>
        <td >
            <textarea readonly style="width: 100%; height: 100%;border: 1px solid black;" name="species_normal_comments[]" id="species_normal_comments" value="<?php echo $row->no_of_days.' Days ( '.$row->dose_a_day.' x '.$row->times_a_day.' time / day )' ?>"><?php echo $row->no_of_days.' Days ( '.$row->dose_a_day.' x '.$row->times_a_day.' time / day )' ?>
            </textarea>
        </td>

<!--        <td>
            <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-deletecnote">
                <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
            </button>
            <button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>
        </td>-->
    </tr>
    
    <?php 
            }
            if($row->formula_or_hardcode == '2')
            {
    ?>
    
    <tr>
        <td><?php echo $count; ?></td>
        <td><input type="hidden"  id="species_normal_names" name="species_normal_names[]" value="<?php echo $row->product_name; ?>" /><?php echo $row->product_name; ?></td>
        <td><input type="hidden"  id="species_normal_unit" name="species_normal_unit[]" value="<?php echo $row->method_type; ?>" /><?php echo $row->method_type; ?></td>
        <td style="display: none"><input type="hidden"  id="species_normal_days" name="species_normal_days[]" value="<?php echo $row->no_of_days; ?>" /><?php echo $row->no_of_days; ?></td>
        <td><input type="hidden"  id="species_normal_strength" name="species_normal_strength[]" value="<?php echo $row->strength; ?>" /><?php echo $row->strength; ?></td>
        
        <!--<td><?php echo $row->use; ?></td>-->
<!--         <td class="center" style="border: none;">
             <select name="medicine_usee[]" id="medicine_usee">        
                 <option value="(Daily 1 - Any Time)">(Daily 1 - Any Time)</option>
                 <option value="(Daily 2 - Any Time)">(Daily 2 - Any Time)</option>
                 <option value="1+0+0+0">1+0+0+0</option>
                 <option value="1+1+0+0">1+1+0+0</option>
                 <option value="1+1+1+0">1+1+1+0</option>
                 <option value="1+1+1+1">1+1+1+1</option>
                 <option value="0+1+0+0">0+1+0+0</option>
                 <option value="0+1+1+0">0+1+1+0</option>
                 <option value="0+1+1+1">0+1+1+1</option>
                 <option value="0+1+0+1">0+1+0+1</option>
                 <option value="0+0+1+0">0+0+1+0</option>
                 <option value="0+0+0+1">0+0+0+1</option>
                 <option value="0+0+1+1">0+0+1+1</option>
            </select>
        </td>   -->
        <td ><input type="hidden" name="species_normal_quantity[]" id="species_normal_quantity" value="<?php echo $row->quantity; ?>" /><?php echo $row->quantity; ?></td>
        <td >
            <textarea readonly style="width: 100%; height: 100%;border: 1px solid black;" name="species_normal_comments[]" id="species_normal_comments" value="<?php echo $row->comments; ?>"><?php echo $row->comments; ?>
            </textarea>
        </td>

<!--        <td>
            <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-deletecnote">
                <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
            </button>
            <button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>
        </td>-->
    </tr>
    
            <?php } ?>
    
    <?php $count++; } 
    }else{
//       echo '<td colspan="6" class="text-center">No Record Found</td>';
    }?>
    </table>
        
         <?php
        
        
//        $response = array();
//        if(mysqli_num_rows($hr_result) > 0) {
//            while ($row = $hr_result->result_object()) {
//                $response = $row;
//            }
//        }
        // display JSON data
//        echo json_encode($species_pv);
    }
    
    
    
    
    
    
    
    
    
    public function get_species_complicated(){
        
        $species_id = $_POST["species_id"];
        $gender_id = $_POST["gender_id"];
        $age_id = $_POST["age_id"];
//        if(isset($pregnant_id))
//        {
        $pregnant_id = $_POST["pregnant_id"];
//        }
//        else{
//            $pregnant_id = '';
//        }
//        if(isset($patient_month_id))
//        {
        $patient_month_id = $_POST["patient_month_id"];
//        }
//        else{
//            $patient_month_id = '';
//        }
        $weight_id = $_POST["weight_id"];
//        $month_id = '';
        $fs_line_id = $_POST["type_id"];
//        }
//        $lvl = $_POST['lvl'];
//        $hr_info = new Malaria_medicines();
        $hr_info = new Product_model();

//        if(!empty($pregnant_id) && $fs_line_id == '1')
//        {
//            $type_id = 1;
//            $hr_result = $hr_info->get_species_normal_one($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
//        }
//        else if(!empty($pregnant_id) && $fs_line_id == '1')
//        {
//            $type_id = 2;
//            $hr_result = $hr_info->get_species_normal_two($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id);
//        }
//      else
        if(empty($pregnant_id) &&  $weight_id <= '20' )
        {
            $type_id = 3;
            $hr_result = $hr_info->get_species_complicated_one($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$weight_id);
        }
        else if(empty($pregnant_id) && $weight_id >='21' )
        {
            $type_id = 4;
            $hr_result = $hr_info->get_species_complicated_two($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$weight_id);
        }
       
        
//        $species_pv = array();
//        if($hr_result)
//        {
//            foreach ($hr_result->result_object() as $row){
//                $species_pv = $row;
//            }
//        }
        ?>
        <h3>Medicines</h3>
    <table  class="table table-striped" id="species_complicated_medicine_id" style="width : 100%;">
        
    <?php // if(!empty($pregnant_id)){
                    
                    ?>
        
        <thead>
            <tr style="background: #FCB614;font-weight: bold;">
                <td>Sr.No</td>
                <td>Weight</td>
                <td>Medicines</td>
                <td>Dose / KG</td>
                <td>Dose as per Weight</td>
                <!--<td>Days to Use</td>-->
                <td>Method</td>
                <td>Strength</td>
                <!--<td>Use</td>-->
                <td>Quantity</td>
                <td>Comments</td>
            </tr>
        </thead>
    <?php
//    echo start_table("datatable-buttons", array("S.No", "Checkup date","Disease Name", "Additional Notes","Action")); 
    ?>
    <?php
//    if(isset($_POST['user']))
//    {
//        $malaria_species_pv = $_POST['user'];
//    }
    if(isset($hr_result))
    {
    $count = 1; foreach ($hr_result->result_object() as $row) {
        $unit = floatval($row->dose_a_day);
        $strength = floatval($row->strength);
        $dose_as_per_weight = $row->dose_id*$weight_id;
        $dose_per_day = round($dose_as_per_weight / $strength,3);
        ?>
        
        <?php
            if($row->formula_or_hardcode == '1')
            {
        ?> 
        
    <tr>
        <td><?php echo $count; ?></td>
        <td><input type="hidden"  id="species_complicated_weight_id" name="species_complicated_weight_id[]" value="<?php echo $weight_id; ?>" /><?php echo $weight_id; ?></td>
        <td><input type="hidden"  id="species_complicated_names" name="species_complicated_names[]" value="<?php echo $row->product_name; ?>" /><?php echo $row->product_name; ?></td>
        <td><input type="hidden"  id="species_complicated_dose_kg" name="species_complicated_dose_kg[]" value="<?php echo $row->dose_id; ?>" /><?php echo $row->dose_id; ?></td>
        <td><input type="hidden"  id="species_complicated_dose_per_weight" name="species_complicated_dose_per_weight[]" value="<?php echo $dose_as_per_weight; ?>" /><?php echo $dose_as_per_weight; ?></td>
        <td style="display: none;"><input type="hidden"  id="species_complicated_days" name="species_complicated_days[]" value="<?php echo $row->no_of_days; ?>" /><?php echo $row->no_of_days; ?></td>
        <td><input type="hidden"  id="species_complicated_unit" name="species_complicated_unit[]" value="<?php echo $row->method_type; ?>" /><?php echo $row->method_type; ?></td>
        <td><input type="hidden"  id="species_complicated_strength" name="species_complicated_strength[]" value="<?php echo $row->strength; ?>" /><?php echo $row->strength; ?></td>
        
        <!--<td><?php echo $row->use; ?></td>-->
<!--         <td class="center" style="border: none;">
             <select name="medicine_usee[]" id="medicine_usee">        
                 <option value="(Daily 1 - Any Time)">(Daily 1 - Any Time)</option>
                 <option value="(Daily 2 - Any Time)">(Daily 2 - Any Time)</option>
                 <option value="1+0+0+0">1+0+0+0</option>
                 <option value="1+1+0+0">1+1+0+0</option>
                 <option value="1+1+1+0">1+1+1+0</option>
                 <option value="1+1+1+1">1+1+1+1</option>
                 <option value="0+1+0+0">0+1+0+0</option>
                 <option value="0+1+1+0">0+1+1+0</option>
                 <option value="0+1+1+1">0+1+1+1</option>
                 <option value="0+1+0+1">0+1+0+1</option>
                 <option value="0+0+1+0">0+0+1+0</option>
                 <option value="0+0+0+1">0+0+0+1</option>
                 <option value="0+0+1+1">0+0+1+1</option>
            </select>
        </td>   -->
        <td ><input type="hidden" name="species_complicated_quantity[]" id="species_complicated_quantity" value="<?php echo ceil($row->no_of_days*($dose_per_day*$row->times_a_day)); ?>" /><?php echo ceil($row->no_of_days*($dose_per_day*$row->times_a_day)); ?></td>
        <td >
            <textarea readonly style="width: 100%; height: 100%;border: 1px solid black;" name="species_complicated_comments[]" id="species_complicated_comments" value="<?php echo $row->no_of_days.' Days ( '.$dose_per_day.' x '.$row->times_a_day.' time / day )' ?>"><?php echo $row->no_of_days.' Days ( '.$dose_per_day.' x '.$row->times_a_day.' time / day )' ?>
            </textarea>
        </td>

<!--        <td>
            <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-deletecnote">
                <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
            </button>
            <button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>
        </td>-->
    </tr>
    <?php 
            }
            else if($row->formula_or_hardcode == '2')
        {
    ?>
    
    <tr>
        <td><?php echo $count; ?></td>
        <td><input type="hidden"  id="species_complicated_weight_id" name="species_complicated_weight_id[]" value="<?php echo $weight_id; ?>" /><?php echo $weight_id; ?></td>
        <td><input type="hidden"  id="species_complicated_names" name="species_complicated_names[]" value="<?php echo $row->product_name; ?>" /><?php echo $row->product_name; ?></td>
        <td><input type="hidden"  id="species_complicated_dose_kg" name="species_complicated_dose_kg[]" value="<?php echo $row->dose_id; ?>" /><?php echo $row->dose_id; ?></td>
        <td><input type="hidden"  id="species_complicated_dose_per_weight" name="species_complicated_dose_per_weight[]" value="<?php echo $dose_as_per_weight; ?>" /><?php echo $dose_as_per_weight; ?></td>
        <td style="display: none;"><input type="hidden"  id="species_complicated_days" name="species_complicated_days[]" value="<?php echo $row->no_of_days; ?>" /><?php echo $row->no_of_days; ?></td>
        <td><input type="hidden"  id="species_complicated_unit" name="species_complicated_unit[]" value="<?php echo $row->method_type; ?>" /><?php echo $row->method_type; ?></td>
        <td><input type="hidden"  id="species_complicated_strength" name="species_complicated_strength[]" value="<?php echo $row->strength; ?>" /><?php echo $row->strength; ?></td>
        
        <!--<td><?php echo $row->use; ?></td>-->
<!--         <td class="center" style="border: none;">
             <select name="medicine_usee[]" id="medicine_usee">        
                 <option value="(Daily 1 - Any Time)">(Daily 1 - Any Time)</option>
                 <option value="(Daily 2 - Any Time)">(Daily 2 - Any Time)</option>
                 <option value="1+0+0+0">1+0+0+0</option>
                 <option value="1+1+0+0">1+1+0+0</option>
                 <option value="1+1+1+0">1+1+1+0</option>
                 <option value="1+1+1+1">1+1+1+1</option>
                 <option value="0+1+0+0">0+1+0+0</option>
                 <option value="0+1+1+0">0+1+1+0</option>
                 <option value="0+1+1+1">0+1+1+1</option>
                 <option value="0+1+0+1">0+1+0+1</option>
                 <option value="0+0+1+0">0+0+1+0</option>
                 <option value="0+0+0+1">0+0+0+1</option>
                 <option value="0+0+1+1">0+0+1+1</option>
            </select>
        </td>   -->
        <td ><input type="hidden" name="species_complicated_quantity[]" id="species_complicated_quantity" value="<?php echo $row->quantity; ?>" /><?php echo $row->quantity; ?></td>
        <td >
            <textarea readonly style="width: 100%; height: 100%;border: 1px solid black;" name="species_complicated_comments[]" id="species_complicated_comments" value="<?php echo $row->comments; ?>"><?php echo $row->comments; ?>
            </textarea>
        </td>

<!--        <td>
            <button class="btn btn-danger btn-sm" type="button" id="<?php echo $row->pk_id."_".$row->patient_id; ?>-deletecnote">
                <span class="mdi mdi-delete-sweep-outline" role="status" aria-hidden="true"></span> Remove
            </button>
            <button type="button" class="btn btn-info btn-sm waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg">View Detail</button>
        </td>-->
    </tr>
    <?php 
    
        }
    
    ?>
    <?php $count++; } 
    }else{
//       echo '<td colspan="9" class="text-center">No Record Found</td>';
    }?>
    <?php // echo end_table(); 
//                }
                ?>
    </table>
        
         <?php
        
        
//        $response = array();
//        if(mysqli_num_rows($hr_result) > 0) {
//            while ($row = $hr_result->result_object()) {
//                $response = $row;
//            }
//        }
        // display JSON data
//        echo json_encode($species_pv);
    }
    
    
    
    
    
    
    
    
    
    
    
    
     public function combo_locations(){ 
        $lvl = $_POST['lvl'];
        $location = new locations();

        $result = $location->find_by_location_level($lvl);

        echo "<option value=>Select</option>";
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->location_name."</option>";
        }
    }

     
    public function village_uc(){
        $id = $_POST["id"];
//        $lvl = $_POST['lvl'];
//        $location = new locations();
        $location = new places();
        $result = $location->village_uc($id);
        
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->loc_name."</option>";
        }
    }
     public function village_tehsil(){
        $id = $_POST["id"];
//        $lvl = $_POST['lvl'];
//        $location = new locations();
        $location = new places();

        $result = $location->village_tehsil($id);
        
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->loc_name."</option>";
        }
    }
     public function village_district(){
        $id = $_POST["id"];
//        $lvl = $_POST['lvl'];
//        $location = new locations();
        $location = new places();

        $result = $location->village_district($id);
        
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->loc_name."</option>";
        }
    }
     public function village_province(){
        $id = $_POST["id"];
//        $lvl = $_POST['lvl'];
//        $location = new locations();
        $location = new places();

        $result = $location->village_province($id);
        
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->loc_name."</option>";
        }
    }
    public function facilities(){
        $id = $_POST["id"];
        $wh = new warehouse();

        $result = $wh->find_by_location_id($id);

        echo "<option value=>Select</option>";
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->warehouse_name."</option>";
        }
    }
    public function facilities_by_category(){
        $category_id = $_POST["category"];
        $wh = new warehouse();

        $result = $wh->find_by_category(2);

        echo "<option value=>Select</option>";
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->warehouse_name."</option>";
        }
    }
    public function cities(){
        $id = $_POST["province_id"];
        $city = new Cities();

        $result = $city->find_by_province_id($id);

        echo "<option value=>Select</option>";
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->city_name."</option>";
        }
    }
    public function find_user_hf(){
        $id = $_POST["user_id"];
        $user = new User();

        $result = $user->find_by_user_id($id);
        foreach ($result->result_object() as $row){
            $wh_id=$row->warehouse_id;
        }
        $warehouse=new Warehouse();
        $result_2=$warehouse->find_by_id($wh_id);
        echo "<option value=>Select</option>";
        foreach ($result_2->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->warehouse_name."</option>";
        }
    }
    public function mdm_entities(){
         $id = $_POST["id"];
         $type=$_POST['type'];
         if($type=='warehouse'){
             $wh=new Warehouse();
             $result = $wh->find_by_id($id);
             foreach ($result->result_object() as $row){
                 echo $row->warehouse_name;
             }
         }
         else if($type=='location'){
             $loc= new Locations();
             $result = $loc->find_by_id($id);
             foreach ($result->result_object() as $row){
                 echo $row->location_name;
             }
         }
         else if($type=='patient'){
                $patient= new Patients_model();
             $result = $patient->find_by_id($id);
             foreach ($result->result_object() as $row){
                 echo $row->full_name;
             }
         }
     }
    public function population(){
        $id = $_POST["id"];
        $wh_pop = new warehouse_population();

        $result = $wh_pop->find_by_wh_id($id,date("Y"));
        foreach($result->result_object() as $row) {
            $population = $row->facility_total_pouplation;
            $years1217 = $population*70/100;
            $years18 = $population*23/100;
            $total = $years1217+$years18;
        }
        
        echo '<div class="col-3">
        <div class="form-group">
            <label for="example-text-input-sm" class="col-form-label">Total Population</label>
            <div>
                '.number_format($population).'
            </div>
        </div>
    </div>
    <div class="col-3">
        <div class="form-group">
            <label for="example-text-input-sm" class="col-form-label">Target 12-17 Yrs</label>
            <div>
            '.number_format($years1217).'
            </div>
        </div>
    </div>
    <div class="col-3">
        <div class="form-group">
            <label for="example-text-input-sm" class="col-form-label">Target >=18 Yrs</label>
            <div>
            '.number_format($years18).'
            </div>
        </div>
    </div>
    <div class="col-3">
        <div class="form-group">
            <label for="example-text-input-sm" class="col-form-label">Target Population</label>
            <div>
            '.number_format($total).'
            </div>
        </div>
    </div>';
    }
}
