<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Announcements extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('announcements_model');
        $this->obj = new Announcements_model();
    }

    public function index() {
         
        $data = array();
        $data['result_all'] = $this->obj->find_all();
        
        //--------Cols to display in View -----------
        $cols_to_display=array();   //key is Display text, value is the actual field name in db
        $cols_to_display['Announcements']='text';
//        $cols_to_display['Status']='is_active';
        //$cols_to_display['Province']='prov_name';
        $data['cols_to_display']=$cols_to_display;

        $data['result']=array();
        foreach($data['result_all'] as $k=>$arr_val){
            $data['result'][$k]['pk_id']=$arr_val['pk_id'];
            foreach ($arr_val as $key => $val) {
                if(in_array($key, $cols_to_display)){
                $data['result'][$k][$key]=$val;
                }
            }
        } 
        //--------Cols to display in View -----END------

        $data['page_title'] = 'Manage Announcements';
        $data['main_content'] = $this->load->view('announcements/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        if ( !empty($_POST)) {
             
            if(!empty($this->input->post('edit_id'))) {
                $this->obj->pk_id=$this->input->post('edit_id');
            }
            $this->obj->text = $this->input->post('text');   
            $this->obj->sent_by = $this->session->userdata('id');   
            $file = $this->obj->save();
            redirect(base_url() . 'announcements/index', 'refresh');
        } else {  
            $data['page_title'] = 'Add New'; 
            $data['main_content'] = $this->load->view('announcements/add', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }

    public function edit() {  
        if ( !empty($_POST)) {
//            echo '<pre>';
//            print_r($_POST);
//            echo '</pre>';
//            exit;
            if(!empty($this->input->post('edit_id'))) {
                $this->obj->pk_id=$this->input->post('edit_id');
            }
            $this->obj->sent_by = $this->session->userdata('id');  
            $this->obj->text = $this->input->post('text');   
            $file = $this->obj->save();
        }
        $edit_id = $this->input->get_post('id');
        $file = $this->obj->find_by_id($edit_id);  
        $data['result'] = $file->result_array();
        $data['edit_id'] = $edit_id; 
        $data['page_title'] = 'Edit announcements';
        $data['main_content'] = $this->load->view('announcements/edit', $data,TRUE);
        $this->load->view('layout/main', $data);
    }

    public function change_status() {
 
        $this->obj->pk_id = $_REQUEST['id'];
        $this->obj->is_active = $_REQUEST['status'];
        $file = $this->obj->change_status();
        $data = array();
        
        redirect(base_url() . 'announcements/index', 'refresh');
    }

}
