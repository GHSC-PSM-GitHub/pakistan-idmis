<?php

class Resource_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('Resource_model');
        $this->obj = new Resource_model();
        // $this->obj = new Resource_model();
    }

    public function index() { 
        $data = array();
        $data['page_title'] = "Resource";
        $data['top_menus'] = $this->obj->top_menu($this->session->userdata('id'));
        // echo "<pre>";
        // var_dump($data['top_menus']);die;
        $data['result'] = $this->obj->find_all();
        $data['main_content'] = $this->load->view('resource_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            if(isset($_POST['id'])){
                $this->obj->pk_id = $_POST['id'];
            }
             
            $this->obj->resource_name = $_POST['resource_name'];
            $this->obj->description = $_POST['description'];
            $this->obj->page_title = $_POST['page_title'];
            $this->obj->parent_id = $_POST['parent_id'];
            $this->obj->resource_type_id = $_POST['resource_type_id'];
            $this->obj->icon_class = $_POST['icon_class'];
//            $this->obj->rank = $_POST['rank'];
            $this->obj->level = $_POST['level'];
//            $this->obj->status = 1;
            $this->obj->save(); 
            redirect(base_url() . 'resource_management/index', 'refresh');
            echo base_url();exit;
        }
        
        $res_arr = $this->obj->find_allmain_resources();
//                $res_arr = $this->obj->find_all_resources();

        if ($res_arr)
            $data['parentids'] = $res_arr->result_array();
//        exit;
        $data['page_title'] = "Resource";
        $data['main_content'] = $this->load->view('resource_management/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $data = array(); 
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $res_arr = $this->obj->find_allmain_resources();
//        $res_arr = $this->obj->find_all_resources();
        if ($res_arr)
            $data['parentids'] = $res_arr->result_array();
        $data['main_content'] = $this->load->view('resource_management/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'resource_management/index', 'refresh');
    }

}
