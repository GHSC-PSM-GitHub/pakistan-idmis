<?php

class Wh_categories_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('warehouse_categories');
        $this->obj=new Warehouse_categories();
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = "HF Categories";
        $data['main_content'] = $this->load->view('wh_categories_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add_wh_category() {
        
        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            if(isset($_POST['id'])){
                $this->obj->pk_id = $_POST['id'];
            }
             
            $this->obj->category_name = $_POST['category_name'];
            $this->obj->is_active = 1;
            $this->obj->save(); 
            redirect(base_url() . 'wh_categories_management/index', 'refresh');
        }
//        exit;
        $data['page_title'] = "HF Categories";
        $data['main_content'] = $this->load->view('wh_categories_management/add_wh_categories', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit_wh_category() { 
        $data = array(); 
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('wh_categories_management/add_wh_categories', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate_wh_category() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'wh_categories_management/index', 'refresh');
    }

}
