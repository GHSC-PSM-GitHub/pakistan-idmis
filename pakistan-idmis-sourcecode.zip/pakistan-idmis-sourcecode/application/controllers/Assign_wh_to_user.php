<?php

class Assign_wh_to_user extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('role_resources');
        $this->load->model('role_model');
        $this->load->model('Stakeholder');
        $this->load->model('itminfo_tab_model');
        $this->load->model('reports_model');
        $this->load->model('user');
        $this->load->model('warehouse');
        $this->load->model('Wh_user');
        $this->obj=new Role_resources();
        $this->obj_itminfo =new Itminfo_tab_model();
        $this->obj_role =new Role_model();
        $this->obj_stakeholder =new Stakeholder();
        $this->obj_reports_model= new Reports_model();
        $this->obj_user = new User();
        $this->obj_warehouse = new Warehouse();
        $this->obj_wh_user = new Wh_user();
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all();
        
        $list_arr = $this->obj_user->find_active();
            $data['user_list'] = $list_arr->result_array();
        
//        $wh_arr = $this->obj_warehouse->find_by_idwarehouse();
        $wh_arr = $this->obj_warehouse->find_all();
            if ($wh_arr)
                $data['warehouse'] = $wh_arr->result_array();    
         
        $data['page_title'] = "Role";
        $data['main_content'] = $this->load->view('assign_wh_to_user/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $data = array();
//        if (isset($_POST) && !empty($_POST)) {
//            if(isset($_POST['id'])){
//                $this->obj->pk_id = $_POST['id'];
//            }
//             
//            $this->obj->role_name = $_POST['role_name'];
//            $this->obj->status = 1;
//            $this->obj->save(); 
//            redirect(base_url() . 'assign_resources/index', 'refresh');
//        }
        
        
        if (isset($_POST) && !empty($_POST)) {
            
            if(isset($_POST['id'])){
                $this->obj_wh_user->wh_user_id = $_POST['id'];
            }
            
            $stkid = $_REQUEST['user'];
            
            //if Assign Resources to Stakeholder exist then delete from database before insert
            
            $stkidyid = $this->obj_wh_user->getuserid($stkid); 
            if ($stkidyid) {
                        $stkidyid_arr = $stkidyid->result_array();
                    foreach ($stkidyid_arr as $row) {
                            $stkidyids = $row['sysusrrec_id'];
                        }
            }
            if($stkid == $stkidyids)
            {
                $this->obj_wh_user->deleteuseridy($stkid); 
            }
            
            $userids = $_REQUEST['user'];
            $warehouselist = $_REQUEST['warehouse'];
            $count = count($userids);
            foreach ($warehouselist as $index => $detail_id) {
                //Stock Received
    //            $this->obj_gwis_detail->StockReceived($detail_id);
                //Get Batch Detail
//                $stkid = $_REQUEST['stkid'];
                
//                $this->obj_wh_user->role_id = $_POST['role'];
                $this->obj_wh_user->sysusrrec_id = $_POST['user'];
                $this->obj_wh_user->wh_id = $warehouselist[$index];
//                $this->obj_wh_user->status = 1;
                $this->obj_wh_user->save(); 
            }
//        exit;
            redirect(base_url() . 'assign_wh_to_user/add', 'refresh');
        }
        
        $product_arr = $this->obj_itminfo->find_all_productsinfo();
        if ($product_arr)
            $data['product'] = $product_arr->result_array();
        
        $role_arr = $this->obj_role->find_active();
        if ($role_arr)
            $data['roles'] = $role_arr->result_array();
        
        $list_arr = $this->obj_user->find_active();
            $data['user_list'] = $list_arr->result_array();
        
//        $wh_arr = $this->obj_warehouse->find_by_idwarehouse();
        $wh_arr = $this->obj_warehouse->find_all();
            if ($wh_arr)
                $data['warehouse'] = $wh_arr->result_array();
            
        $stakeholder_arr = $this->obj_reports_model->get_stakeholder();
//        $stakeholder_arr = $this->obj_stakeholder->get_all_stk();
        if ($stakeholder_arr)
            $data['stakeholder'] = $stakeholder_arr->result_array();
//        exit;
        $data['page_title'] = "Assign Warehouse";
        $data['main_content'] = $this->load->view('assign_wh_to_user/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $data = array(); 
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('assign_wh_to_user/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'assign_wh_to_user/index', 'refresh');
    }

}
