<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Product_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('Product_model');
        $this->load->model('Product_category');
        $this->load->model('Product_subcategory');
        $this->load->model('Product_generic');
        $this->load->model('Product_manufacturer');
        $this->load->model('Product_methodtype');
        $this->load->model('Product_strength');
        $this->load->model('Product_contradicts');
        $this->load->model('Stakeholder');
        $this->load->model('Itminfo_tab_model');
        $this->load->model('Lists');
        $this->obj = new Product_model();
        $this->obj_itminfo = new Itminfo_tab_model();
        $this->obj_category = new Product_category();
        $this->obj_subcategory = new Product_subcategory();
        $this->obj_manufacturer = new Product_manufacturer();
        $this->obj_methodtype = new Product_methodtype();
        $this->obj_strength = new Product_strength();
        $this->obj_generic = new Product_generic();
        $this->obj_contradict = new Product_contradicts();
        $this->obj_stakeholder = new Stakeholder();
        $this->obj_lists = new Lists();
    }

    public function index() {
        $data = array();
        $data['result'] = $this->obj_itminfo->find_all_products();
        $data['page_title'] = 'Manage Items';
        $data['main_content'] = $this->load->view('product_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        $pk_id = $this->input->post('pk_id');
        $product_name = $this->input->post('product_name');
        if (!empty($product_name)) {
            if ($pk_id != '') {
                $this->obj_itminfo->itm_id = $pk_id;
            }
            $this->obj_itminfo->product_code = $_POST['product_code'];
            $this->obj_itminfo->min_quantity = $_POST['min_quantity'];
            $this->obj_itminfo->max_quantity = $_POST['max_quantity'];
            $this->obj_itminfo->reorder_quantity = $_POST['reorder_quantity'];
            $this->obj_itminfo->itm_name = $_POST['product_name'];
            $this->obj_itminfo->generic_name = $_POST['generic_name_id'];
            $this->obj_itminfo->strength_id = $_POST['strength_id'];
            $this->obj_itminfo->method_type = $_POST['method_type_id'];
            if(isset($_POST['manufacturer_id']) && !empty($_POST['manufacturer_id']))
            {
                $this->obj_itminfo->manufacturer_id = $_POST['manufacturer_id'];
            }
            $this->obj_itminfo->product_type = $_POST['product_type'];
            if(!empty($_POST['category_id']))
            {
                $this->obj_itminfo->itm_category = $_POST['category_id'];
            }
            $this->obj_itminfo->barcode = $_POST['barcode_no'];
            $this->obj_itminfo->itm_des = $_POST['description'];
            $this->obj_itminfo->itm_status = 1;
            $this->obj_itminfo->pack_size = $_POST['pack_size'];
            $this->obj_itminfo->unit = $_POST['unit'];
            $itmid = $this->obj_itminfo->save();
            if ($pk_id == '') {
                $formArray = array(
                    'stk_id'     => $_SESSION['stakeholder_id'],
                    'product_id' => $itmid,
                    'status' => 1,
                );
                $this->Product_model->create_stakeholder_item($formArray);
                $this->obj_itminfo->itm_id = $itmid;
                if(!empty($_POST['category_id']) && $_POST['category_id'] == '1'){
                    $last_id = $this->obj_itminfo->getLastID(1);
                    if (!empty($last_id)) {
                        if ($last_id)
                            $last_idd = $last_id->result_array();
                        foreach ($last_idd as $row) {
                            $lastid = $row['Maxtr'];
                        }
                    }
                
                    if ($lastid == NULL) {
                        $lastid = 0;
                    }
                    $string = 'P-';
                }
                
                $string.=str_pad(($lastid+1), 3, '0', STR_PAD_LEFT);
                $this->obj_itminfo->itmrec_id = $string;
                $this->obj_itminfo->save();
            }
            redirect(base_url() . 'product_management/index', 'refresh');
        }else{
            $cat_arr = $this->obj_category->find_active();
            $data['category'] = $cat_arr->result_array();
            $list_arr = $this->obj_lists->get_list(6);
            $data['product_type'] = $list_arr->result_array();
            $subcat_arr = $this->obj_subcategory->find_active();
            $data['sub_category'] = $subcat_arr->result_array();
            $generic_arr = $this->obj_generic->find_active();
            $data['generic'] = $generic_arr->result_array();
            $supplier_arr = $this->obj_stakeholder->find_active();
            $data['supplier'] = $supplier_arr->result_array();
            $manuf_arr = $this->obj_stakeholder->get_all_info();
            $data['manufacturer'] = $manuf_arr->result_array();
            $strength_arr = $this->obj_strength->find_active();
            $data['strength'] = $strength_arr->result_array();
            $methodtype_arr = $this->obj_methodtype->find_active();
            $data['method_type'] = $methodtype_arr->result_array();
            $data['page_title'] = 'Add New Product';
            $data['main_content'] = $this->load->view('product_management/add_product', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }

    public function edit() {
        $data = array();
        $cat_arr = $this->obj_category->find_active();
        $data['category'] = $cat_arr->result_array();

        $list_arr = $this->obj_lists->get_list(6);
        $data['product_type'] = $list_arr->result_array();
        
        $subcat_arr = $this->obj_subcategory->find_active();
        $data['sub_category'] = $subcat_arr->result_array();

        $generic_arr = $this->obj_generic->find_active();
        $data['generic'] = $generic_arr->result_array();

        $manuf_arr = $this->obj_stakeholder->get_all_info();
        $data['manufacturer'] = $manuf_arr->result_array();

        $strength_arr = $this->obj_strength->find_active();
        $data['strength'] = $strength_arr->result_array();
        
        
        $supplier_arr = $this->obj_stakeholder->find_active();
        $data['supplier'] = $supplier_arr->result_array();
        
        $methodtype_arr = $this->obj_methodtype->find_active();
        $data['method_type'] = $methodtype_arr->result_array();
        $data['js'] = array("product_management/add");
        $data['page_title'] = 'Edit Product';
        $data['result_edit'] = $this->obj_itminfo->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('product_management/add_product', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() {
        $id = $_REQUEST['id'];
        $status = $_REQUEST['itm_status'];
        $this->obj_itminfo->deactivate($id, $status);
        redirect(base_url() . 'product_management/index', 'refresh');
    }

    public function contradictory_products() {

        if (isset($_POST) && !empty($_POST)) {
//            print_r($_POST);exit;
            foreach ($_POST['generic_contradictory_id'] as $key => $value) {
                $this->obj_contradict->generic_name = $_POST['generic_name'];
                $this->obj_contradict->generic_name_id = $_POST['generic_name_id'];
                $this->obj_contradict->contrast_product_id = $value;
                $this->obj_contradict->save();
                redirect(base_url() . 'product_management/list_contradicts', 'refresh');
            }
        }
        $data = array();
        $generic_arr = $this->obj_generic->find_active();
        $data['generic'] = $generic_arr->result_array(); 
        $data['page_title'] = 'Contradictory';
         $data['js'] = array("product_management/add");
        $data['main_content'] = $this->load->view('product_management/contradictory_products', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    public function list_contradicts() { 
        $data = array();
        $data['result'] = $this->obj_contradict->find_all();
        $data['page_title'] = 'Contradictory';
        $data['main_content'] = $this->load->view('product_management/list_contradictory_products', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
}
