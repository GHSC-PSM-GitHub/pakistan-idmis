<?php

class Fundingsource_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('stakeholder');
        $this->obj=new Stakeholder();
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->get_all_info_fs();
        $data['page_title'] = "Funding Source";
        $data['main_content'] = $this->load->view('fundingsource_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            if(isset($_POST['id'])){
                $this->obj->stkid = $_POST['id'];
            }
            
            $this->obj->stkname = $_POST['txtStkName'];
            $this->obj->stk_type_id = $_POST['lstStktype'];
//            $this->obj->lvl = $_POST['lstLvl'];
            $GetMaxRank = $this->obj->GetMaxRank();
            $GetMaxRanks = $GetMaxRank->result_array();
            foreach ($GetMaxRanks as $row) {
                $maxvalue = $row['MaxOrder'];
            }
            $this->obj->stkorder = $maxvalue+1;
//            $this->obj->manufacturer = $_POST['manufacturer'];
            $this->obj->is_reporting = 1;
            $id = $this->obj->save(); 
            
            if ($id > 0) {
                if ($this->obj->MainStakeholder == 'NULL' || $this->obj->MainStakeholder == '') {
                    $Update_in_whid = $this->obj->Update_in_mainstk($id);
//                    $strSql1 = "Update stakeholder SET MainStakeholder=" . $id . " where stkid=" . $id;
//                    $rsSql = mysql_query($strSql1) or die($strSql1 . mysql_error());
                }
                
                if(isset($_POST['id'])){
                    if ($this->obj->stk_type_id == 2)
                    {
                        $Update_in_whid = $this->obj->Update_in_wh($this->obj->stkname,$id,$this->obj->stk_type_id,$_POST['id']);
                    }

                    //Check it not confirm for supplier

                    if ($this->obj->stk_type_id == 6)
                    {
                        $Update_in_whid = $this->obj->Update_in_wh($this->obj->stkname,$id,$this->obj->stk_type_id,$_POST['id']);
                    }
                }
                else{
                    if ($this->obj->stk_type_id == 2)
                    {
                        $Insert_in_whid = $this->obj->Insert_in_wh($this->obj->stkname,$id,$this->obj->stk_type_id);
                    }

                    //Check it not confirm for supplier

                    if ($this->obj->stk_type_id == 6)
                    {
                        $Insert_in_whid = $this->obj->Insert_in_wh($this->obj->stkname,$id,$this->obj->stk_type_id);
                    }
                }
                
//                return $id;
            } else {
                return 0;
            }
            
            redirect(base_url() . 'fundingsource_management/index', 'refresh');
        }
        
        $rslvls = $this->obj->GetAlllevels();
        $data['rslvl'] = $rslvls->result_array();
        
        $rsstktypes = $this->obj->Getfundingsource_types();
        $data['rsstktype'] = $rsstktypes->result_array();
//        exit;
        $data['page_title'] = "Funding Source";
        $data['main_content'] = $this->load->view('fundingsource_management/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $data = array(); 
        
        $rslvls = $this->obj->GetAlllevels();
        $data['rslvl'] = $rslvls->result_array();
        
        $rsstktypes = $this->obj->Getfundingsource_types();
        $data['rsstktype'] = $rsstktypes->result_array();
        
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('fundingsource_management/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'fundingsource_management/index', 'refresh');
    }

}
