<?php

class Medicine_lab_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('medicine_lab_model');
        $this->obj=new Medicine_lab_model();
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = "Lab";
        $data['main_content'] = $this->load->view('medicine_lab_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            if(isset($_POST['id'])){
                $this->obj->pk_id = $_POST['id'];
            }
             
            $this->obj->lab_name = $_POST['lab_name'];
            $this->obj->is_active = 1;
            $this->obj->save(); 
            redirect(base_url() . 'medicine_lab_management/index', 'refresh');
        }
//        exit;
        $data['page_title'] = "Lab";
        $data['main_content'] = $this->load->view('medicine_lab_management/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $data = array(); 
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('medicine_lab_management/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'medicine_lab_management/index', 'refresh');
    }

}

