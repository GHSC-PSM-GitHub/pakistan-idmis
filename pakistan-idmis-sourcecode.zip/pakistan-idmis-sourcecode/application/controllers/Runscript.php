<?php

class Runscript extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('assign_resources_model');
        $this->load->model('role_model');
//        $this->load->model('Stakeholder');
        $this->load->model('resource_model');
        $this->load->model('reports_model');
        $this->load->model('Itminfo_tab_model');
        $this->obj_itminfo = new Itminfo_tab_model();
        $this->obj=new assign_resources_model();
        $this->obj_resources =new Resource_model();
        $this->obj_role =new Role_model();
//        $this->obj_stakeholder =new Stakeholder();
        $this->obj_reports_model= new Reports_model();
    }

    public function process_script() {
        exit;
        $data = array();
        $scriptinfo = $this->obj_reports_model->get_all_script_table_info();
        
        
        if ($scriptinfo) {
            $scriptinfo_arr = $scriptinfo->result_array();
            foreach ($scriptinfo_arr as $row) {
//                $pk_id = $row['master_id'];
//                $detail_id = $row['detail_id'];
                
                //Created On
                date_default_timezone_set('Asia/Karachi');
                $created_on_time = date('Y-m-d h:i:s', time());
                
                //Tran Date
//                $tran_dates = $row['tran_date'];
//                $tran_date = date("Y-m-d", strtotime($tran_dates));
                
                $tran_dates = str_replace('/', '-', $row['tran_date']);
                $tran_dates_day   = date('d',strtotime($tran_dates));
                $tran_dates_month   = date('m',strtotime($tran_dates));
                $tran_dates_year   = date('Y',strtotime($tran_dates));
                $tran_date = $tran_dates_year.'-'.$tran_dates_month.'-'.$tran_dates_day;
  
//                $tran_no = $row['tran_no'];
                
                //Source Type
                $source_type = $row['source_type'];
                if(!empty($source_type))
                {
                    $get_source_type_scriptinfo = $this->obj_reports_model->get_source_type_info($source_type);
                    if ($get_source_type_scriptinfo) 
                    {
                        $get_source_type_scriptinfo_arr = $get_source_type_scriptinfo->result_array();
                        foreach ($get_source_type_scriptinfo_arr as $row1) {
                            $source_type = $row1['stkid'];
                        }
                    }
                    else
                    {
                        $source_type = $this->obj_reports_model->insert_source_type_info($source_type);
                    }
                }
                
                //Stakeholder Name
                $stkname = $row['stkname'];
                if(!empty($stkname))
                {
                    $get_stkname_scriptinfo = $this->obj_reports_model->get_stkname_info($stkname);
                    if ($get_stkname_scriptinfo) 
                    {
                        $get_stkname_scriptinfo_arr = $get_stkname_scriptinfo->result_array();
                        foreach ($get_stkname_scriptinfo_arr as $row2) {
                            $stkname = $row2['stkid'];
                        }
                    }
                    else
                    {
                        $stkname = $this->obj_reports_model->insert_stkname_info($stkname);
                    }
                }
                
                //Status
                $Status = $row['Status'];
                if($Status == '13')
                {
                    $Status = '3';
                }
                else {
                    $Status = $row['Status'];
                }
                
                //Process to get Tran No
                
                
                
                
                $current_year = date("Y");
                //current month
                $current_month = date("m");
                if ($current_month < 7) {
                    //from date
                    $from_date = ($current_year - 1) . "-06-30";
                    //to date
                    $to_date = $current_year . "-07-30";
                } else {
                    //from date
                    $from_date = $current_year . "-06-30";
                    //to date
                    $to_date = ($current_year + 1) . "-07-30";
                }
            
                //get last id
                $last_id = $this->obj_reports_model->getLastIDy($from_date, $to_date, '');
                
                if (!empty($last_id)) {
                    if ($last_id)
                        $last_idd = $last_id->result_array();
                    foreach ($last_idd as $row3) {
                            $lastid = $row3['Maxtr'];
                        }
                }
                
                if ($lastid == NULL) {
                    $lastid = 0;
                }
                
                if(isset($row['itm_name']) && !empty($row['itm_name']))
                {
//                    $charc = substr($row['itm_name'], 0, 1);
                    if($row['Status'] == '13')
                    {
                        $prefix = 'R';
                    }
                    else if($row['Status'] == '3')
                    {
                        $prefix = 'R';
                    }
                    else if($row['Status'] == '4')
                    {
                        $prefix = 'I';
                    }
                    else{
                        $prefix = 'A';
                    }
                }
                
                $issue_tran_dates = $row['tran_date'];
                $issue_tran_date = date("ym", strtotime($issue_tran_dates));
                
                $trans_no = $prefix . "" . $issue_tran_date.str_pad(($lastid + 1), 4, "0", STR_PAD_LEFT);
                $tr_no = $lastid + 1;
                
                //From Warehouse 
                $from_warehouse = $row['from_warehouse'];
                if(!empty($from_warehouse))
                {
                    $get_warehouse_scriptinfo = $this->obj_reports_model->get_from_warehouse_info($from_warehouse);
                    if ($get_warehouse_scriptinfo) 
                    {
                        $get_warehouse_scriptinfo_arr = $get_warehouse_scriptinfo->result_array();
                        foreach ($get_warehouse_scriptinfo_arr as $row4) {
                            $from_warehouse = $row4['wh_id'];
                        }
                    }
                    else
                    {
                        $from_warehouse = $this->obj_reports_model->insert_from_warehouse_info($from_warehouse);
                    }
                }
                
                //To Warehouse
                $to_warehouse = $row['to_warehouse'];
                if(!empty($to_warehouse))
                {
                    $get_to_warehouse_scriptinfo = $this->obj_reports_model->get_to_warehouse_info($to_warehouse);
                    if ($get_to_warehouse_scriptinfo) 
                    {
                        $get_to_warehouse_scriptinfo_arr = $get_to_warehouse_scriptinfo->result_array();
                        foreach ($get_to_warehouse_scriptinfo_arr as $row5) {
                            $to_warehouse = $row5['wh_id'];
                        }
                    }
                    else
                    {
                        $to_warehouse = $this->obj_reports_model->insert_to_warehouse_info($to_warehouse);
                    }
                }
                
                
                //PO CMU
                $PO_CMU = $row['PO_CMU'];
                if(!empty($PO_CMU))
                {
                    $get_PO_CMU_scriptinfo = $this->obj_reports_model->get_PO_CMU_info($PO_CMU);
                    if ($get_PO_CMU_scriptinfo) 
                    {
                        $get_PO_CMU_scriptinfo_arr = $get_PO_CMU_scriptinfo->result_array();
                        foreach ($get_PO_CMU_scriptinfo_arr as $row55) {
                            $PO_CMU = $row55['pk_id'];
                        }
                    }
                    else
                    {
                        $PO_CMU = $this->obj_reports_model->insert_PO_CMU_info($PO_CMU);
                    }
                }
                
                
                //GWIS MASTER Data Entry
                
                
                
                //Login to enter master data using conditions
                
                
//                $get_existing_master_scriptinfo = $this->obj_reports_model->get_gwis_master_info($tran_date,$from_warehouse,$to_warehouse,$source_type);
//                if($get_existing_master_scriptinfo)
//                {
//                    $get_existing_master_arr = $get_existing_master_scriptinfo->result_array();
//                    foreach ($get_existing_master_arr as $row56) {
//                        $master_id = $row56['pk_id'];
//                    }
//                }
                
                
                
                //Logic For master and detail id if use then must add new field in gwis_master ( script_master_id )
                
                $get_r_existing_master_scriptinfo = $this->obj_reports_model->get_last_cmu_data_info($row['detail_id']);
                if($get_r_existing_master_scriptinfo)
                {
                    $get_r_existing_master_arr = $get_r_existing_master_scriptinfo->result_array();
                    foreach ($get_r_existing_master_arr as $row57) {
                        $scriptmaster_id = $row57['script_master_id'];
                        $master_idy = $row57['pk_id'];
                    }
                }
                
                if(isset($scriptmaster_id) && $scriptmaster_id == $row['master_id'])
                {
                    $master_id = $master_idy;
                }
                else
                {
                    $master_id = $this->obj_reports_model->insert_gwis_master_info($tran_date,$trans_no,$Status,$from_warehouse,
                                                                            $to_warehouse,$created_on_time,$tr_no,$source_type,
                                                                                $stkname,$PO_CMU,$row['master_id']);
                }
//                echo $master_id;exit;
                
                
                //End of Master Data entery
                
                
                
                //Manufacturer
                $manufacturer = $row['manufacturer'];
                if(!empty($manufacturer))
                {
                    $get_manufacturer_scriptinfo = $this->obj_reports_model->get_manufacturer_info($manufacturer);
                    if ($get_manufacturer_scriptinfo) 
                    {
                        $get_manufacturer_scriptinfo_arr = $get_manufacturer_scriptinfo->result_array();
                        foreach ($get_manufacturer_scriptinfo_arr as $row6) {
                            $manufacturer = $row6['stkid'];
                        }
                    }
                    else
                    {
                        $manufacturer = $this->obj_reports_model->insert_manufacturer_info($manufacturer);
                    }
                }
                
                //Generic Name
                $generic_name = $row['itm_name'];
                if(!empty($generic_name))
                {
                    $get_generic_name_scriptinfo = $this->obj_reports_model->get_generic_name_info($generic_name);
                    if ($get_generic_name_scriptinfo) 
                    {
                        $get_generic_name_scriptinfo_arr = $get_generic_name_scriptinfo->result_array();
                        foreach ($get_generic_name_scriptinfo_arr as $row7) {
                            $generic_name = $row7['pk_id'];
                        }
                    }
                    else
                    {
                        $generic_name = $this->obj_reports_model->insert_generic_name_info($generic_name);
                    }
                }
                
                //Strength
                $Strength = $row['Strength'];
                if(!empty($Strength))
                {
                    $get_Strength_scriptinfo = $this->obj_reports_model->get_Strength_info($Strength);
                    if ($get_Strength_scriptinfo) 
                    {
                        $get_Strength_scriptinfo_arr = $get_Strength_scriptinfo->result_array();
                        foreach ($get_Strength_scriptinfo_arr as $row8) {
                            $Strength = $row8['pk_id'];
                        }
                    }
                    else
                    {
                        $Strength = $this->obj_reports_model->insert_Strength_info($Strength);
                    }
                }
                
                //Method
                $Method = $row['Method'];
                if(!empty($Method))
                {
                    $get_Method_scriptinfo = $this->obj_reports_model->get_Method_info($Method);
                    if ($get_Method_scriptinfo) 
                    {
                        $get_Method_scriptinfo_arr = $get_Method_scriptinfo->result_array();
                        foreach ($get_Method_scriptinfo_arr as $row9) {
                            $Method = $row9['pk_id'];
                        }
                    }
                    else
                    {
                        $Method = $this->obj_reports_model->insert_Method_info($Method);
                    }
                }
                
                
                //Itmrec ID
                $itmlastid = '0';
                $itmlast_id = $this->obj_itminfo->getLastID(1);
                    
                if (!empty($itmlast_id)) {
                    if ($itmlast_id)
                        $itmlast_idd = $itmlast_id->result_array();
                    foreach ($itmlast_idd as $row10) {
                            $itmlastid = $row10['Maxtr'];
                        }
                }

                if ($itmlastid == NULL || empty($itmlastid)) {
                    $itmlastid = 0;
                }

                $string = 'P-';
                
                $string.=str_pad(($itmlastid+1), 3, '0', STR_PAD_LEFT);
                $itmrec_id = $string;
                
                
                //Qty Per Pack
                $Qty_per_Pack = $row['Qty_per_Pack'];
                
                //Pack Per Carton
                $Pack_per_Carton = $row['Pack_per_Carton'];
                
                //Product Type
                $product_type = $row['product_type'];
                if(!empty($product_type))
                {
                    $get_product_type_scriptinfo = $this->obj_reports_model->get_product_type_info($product_type);
                    if ($get_product_type_scriptinfo) 
                    {
                        $get_product_type_scriptinfo_arr = $get_product_type_scriptinfo->result_array();
                        foreach ($get_product_type_scriptinfo_arr as $row99) {
                            $product_type = $row99['pk_id'];
                        }
                    }
                    else
                    {
                        $product_type = $this->obj_reports_model->insert_product_type_info($product_type);
                    }
                }
                
                //Product Name
                $itm_name = $row['itm_name'];
                if(!empty($itm_name))
                {
                    $get_itm_name_scriptinfo = $this->obj_reports_model->get_itm_name_info($itm_name,$Strength);
                    if ($get_itm_name_scriptinfo) 
                    {
                        $get_itm_name_scriptinfo_arr = $get_itm_name_scriptinfo->result_array();
                        foreach ($get_itm_name_scriptinfo_arr as $row11) {
                            $itm_name = $row11['itm_id'];
                        }
                    }
                    else
                    {
                        $itm_name = $this->obj_reports_model->insert_itm_name_info($itm_name,$generic_name,$Method,$Strength,$manufacturer,$itmrec_id,$Qty_per_Pack,$Pack_per_Carton,$product_type);
                    }
                }
                
                
                //Batch Expiry
                $batch_expirys = $row['batch_expiry'];
                $batch_expiry = date("Y-m-d", strtotime($batch_expirys));  
                
                //Production Date
                $production_datess = $row['production_date'];
                $production_date = date("Y-m-d", strtotime($production_datess));
                
                //Quantity
                $quantity = $row['quantity'];
                
                //Unit Price
                $unit_price = $row['unit_price'];
                
                //Conversion Rate
                $conversion_rate = $row['conversion_rate'];
                
                //Currency
                $currency = $row['currency'];
                if(!empty($currency))
                {
                    $get_currency_scriptinfo = $this->obj_reports_model->get_currency_info($currency);
                    if ($get_currency_scriptinfo) 
                    {
                        $get_currency_scriptinfo_arr = $get_currency_scriptinfo->result_array();
                        foreach ($get_currency_scriptinfo_arr as $row12) {
                            $currency = $row12['pk_id'];
                        }
                    }
                    else
                    {
                        $currency = $this->obj_reports_model->insert_currency_info($currency);
                    }
                }
                
                
                
                
                //Stock Batch Data Entry
                //Using Batch No
                
                
                
                $batch_number = $row['batch_no'];
                $batch_no = $row['batch_no'];
                if(!empty($batch_no))
                {
                    $get_batch_no_scriptinfo = $this->obj_reports_model->get_batch_no_info($batch_no,$itm_name);
                    if ($get_batch_no_scriptinfo) 
                    {
                        $get_batch_no_scriptinfo_arr = $get_batch_no_scriptinfo->result_array();
                        foreach ($get_batch_no_scriptinfo_arr as $row13) {
                            $batch_no = $row13['batch_id'];
                        }
                    }
                    else
                    {
                        $batch_no = $this->obj_reports_model->insert_batch_no_info($batch_no,$batch_expiry,$itm_name,$quantity,
                                                                                    $unit_price,'97800',$currency,
                                                                                    $conversion_rate,$production_date,$manufacturer,
                                                                                    $source_type);
                    }
                }
                
                
                
//                echo $batch_no;exit;
                
                
                
                
                //Driver Name
                $driver_name = $row['driver_name'];
                
                //Driver Contact
                $driver_contract = $row['driver_contract'];
                
                //Siv Cnic
                $siv_cnic = $row['siv_cnic'];
                
                //Vehicle Reg
                $vehicle_reg = $row['vehicle_reg'];
                
                //Dc No
                $dc_no = $row['dc_no'];
                
                //Dc Date
//                $dc_dates = $row['dc_date'];
//                $dc_date = date("Y-m-d", strtotime($dc_dates)); 
                
                $dc_dates = str_replace('/', '-', $row['dc_date']);
                $dc_dates_day   = date('d',strtotime($dc_dates));
                $dc_dates_month   = date('m',strtotime($dc_dates));
                $dc_dates_year   = date('Y',strtotime($dc_dates));
                $dc_date = $dc_dates_year.'-'.$dc_dates_month.'-'.$dc_dates_day;
 
                
                //Invoice
                $invoice = $row['invoice'];
                
                //Siv Mode Of Transport
                $siv_mode_of_transport = $row['siv_mode_of_transport'];
                
                //Siv Name Of Transporter
                $siv_name_of_transporter = $row['siv_name_of_transporter'];
                
                //Siv Vehicle Plate No
                $siv_vehicle_plate_no = $row['siv_vehicle_plate_no'];
                
                //Shipment Temprature
                $Shipment_Temprature = $row['Shipment_Temprature'];
                 
                //Siv Vehicle Type
                $siv_vehicle_type = $row['siv_vehicle_type'];
                if(!empty($siv_vehicle_type))
                {
                    $get_siv_vehicle_type_scriptinfo = $this->obj_reports_model->get_siv_vehicle_type_info($siv_vehicle_type);
                    if ($get_siv_vehicle_type_scriptinfo) 
                    {
                        $get_siv_vehicle_type_scriptinfo_arr = $get_siv_vehicle_type_scriptinfo->result_array();
                        foreach ($get_siv_vehicle_type_scriptinfo_arr as $row14) {
                            $siv_vehicle_type = $row14['pk_id'];
                        }
                    }
                    else
                    {
                        $siv_vehicle_type = $this->obj_reports_model->insert_siv_vehicle_type_info($siv_vehicle_type);
                    }
                }
                
                
                //GWIS DETAIL Data Entry
                
                $detail_id = $this->obj_reports_model->insert_gwis_detail_info($master_id,$batch_no,$quantity,$batch_number,$manufacturer,
                                                                                $batch_expiry,$driver_name,$driver_contract,
                                                                                $siv_cnic,$vehicle_reg,$dc_no,$dc_date,$invoice,
                                                                                $siv_mode_of_transport,$siv_name_of_transporter,
                                                                                $siv_vehicle_plate_no,$Shipment_Temprature,$Status,
                                                                                $siv_vehicle_type,$production_date);
                
                
                
//                echo $detail_id;exit;
                
                
                //Tran Ref
//                $tran_ref = $row['tran_ref'];
                
                //Twenty_ft_Container_truck
//                $twenty_ft_Container_truck = $row['20_ft_Container_truck'];
                
                //TAC No
                $TAC_No = $row['TAC_No'];
                
                //TAC DT
                $TAC_dt = $row['TAC_dt'];
                
                //GRN No
                $GRN_no = $row['GRN_no'];
                
                //GRN DT
                $GRN_dt = $row['GRN_dt'];
            }
        }
        
        
        $data['page_title'] = "Process Script";
        $data['main_content'] = $this->load->view('Runscript/process_script', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    
    public function process_script_malaria() {
        exit;
        $data = array();
        $scriptinfo = $this->obj_reports_model->m_get_all_script_table_info();
        
        
        if ($scriptinfo) {
            $scriptinfo_arr = $scriptinfo->result_array();
            foreach ($scriptinfo_arr as $row) {
//                $pk_id = $row['master_id'];
//                $detail_id = $row['detail_id'];
                
                //Created On
                date_default_timezone_set('Asia/Karachi');
                $created_on_time = date('Y-m-d h:i:s', time());
                
                //Tran Date
                $tran_dates = $row['tran_date'];
                $tran_date = date("Y-m-d", strtotime($tran_dates));
                
//                $tran_dates = str_replace('/', '-', $row['tran_date']);
//                $tran_dates_day   = date('d',strtotime($tran_dates));
//                $tran_dates_month   = date('m',strtotime($tran_dates));
//                $tran_dates_year   = date('Y',strtotime($tran_dates));
//                $tran_date = $tran_dates_year.'-'.$tran_dates_month.'-'.$tran_dates_day;
  
//                $tran_no = $row['tran_no'];
                
                //Source Type
                $source_type = $row['source_type'];
                if(!empty($source_type))
                {
                    $get_source_type_scriptinfo = $this->obj_reports_model->get_source_type_info($source_type);
                    if ($get_source_type_scriptinfo) 
                    {
                        $get_source_type_scriptinfo_arr = $get_source_type_scriptinfo->result_array();
                        foreach ($get_source_type_scriptinfo_arr as $row1) {
                            $source_type = $row1['stkid'];
                        }
                    }
                    else
                    {
                        $source_type = $this->obj_reports_model->insert_source_type_info($source_type);
                    }
                }
                
                //Stakeholder Name
                $stkname = $row['stkname'];
                if(!empty($stkname))
                {
                    $get_stkname_scriptinfo = $this->obj_reports_model->get_stkname_info($stkname);
                    if ($get_stkname_scriptinfo) 
                    {
                        $get_stkname_scriptinfo_arr = $get_stkname_scriptinfo->result_array();
                        foreach ($get_stkname_scriptinfo_arr as $row2) {
                            $stkname = $row2['stkid'];
                        }
                    }
                    else
                    {
                        $stkname = $this->obj_reports_model->insert_stkname_info($stkname);
                    }
                }
                
                //Status
                $Status = $row['Status'];
                if($Status == '13')
                {
                    $Status = '3';
                }
                else {
                    $Status = $row['Status'];
                }
                
                //Process to get Tran No
                
                
                
                
                $current_year = date("Y");
                //current month
                $current_month = date("m");
                if ($current_month < 7) {
                    //from date
                    $from_date = ($current_year - 1) . "-06-30";
                    //to date
                    $to_date = $current_year . "-07-30";
                } else {
                    //from date
                    $from_date = $current_year . "-06-30";
                    //to date
                    $to_date = ($current_year + 1) . "-07-30";
                }
            
                //get last id
                $last_id = $this->obj_reports_model->getLastIDy($from_date, $to_date, '');
                
                if (!empty($last_id)) {
                    if ($last_id)
                        $last_idd = $last_id->result_array();
                    foreach ($last_idd as $row3) {
                            $lastid = $row3['Maxtr'];
                        }
                }
                
                if ($lastid == NULL) {
                    $lastid = 0;
                }
                
                if(isset($row['itm_name']) && !empty($row['itm_name']))
                {
//                    $charc = substr($row['itm_name'], 0, 1);
                    if($row['Status'] == '13')
                    {
                        $prefix = 'R';
                    }
                    else if($row['Status'] == '3')
                    {
                        $prefix = 'R';
                    }
                    else if($row['Status'] == '4')
                    {
                        $prefix = 'I';
                    }
                    else{
                        $prefix = 'A';
                    }
                }
                
                $issue_tran_dates = $row['tran_date'];
                $issue_tran_date = date("ym", strtotime($issue_tran_dates));
                
                $trans_no = $prefix . "" . $issue_tran_date.str_pad(($lastid + 1), 4, "0", STR_PAD_LEFT);
                $tr_no = $lastid + 1;
                
                //From Warehouse 
                $from_warehouse = $row['from_warehouse'];
                if(!empty($from_warehouse))
                {
                    $get_warehouse_scriptinfo = $this->obj_reports_model->get_from_warehouse_info($from_warehouse);
                    if ($get_warehouse_scriptinfo) 
                    {
                        $get_warehouse_scriptinfo_arr = $get_warehouse_scriptinfo->result_array();
                        foreach ($get_warehouse_scriptinfo_arr as $row4) {
                            $from_warehouse = $row4['wh_id'];
                        }
                    }
                    else
                    {
                        $from_warehouse = $this->obj_reports_model->insert_from_warehouse_info($from_warehouse);
                    }
                }
                
                //To Warehouse
                $to_warehouse = $row['to_warehouse'];
                if(!empty($to_warehouse))
                {
                    $get_to_warehouse_scriptinfo = $this->obj_reports_model->get_to_warehouse_info($to_warehouse);
                    if ($get_to_warehouse_scriptinfo) 
                    {
                        $get_to_warehouse_scriptinfo_arr = $get_to_warehouse_scriptinfo->result_array();
                        foreach ($get_to_warehouse_scriptinfo_arr as $row5) {
                            $to_warehouse = $row5['wh_id'];
                        }
                    }
                    else
                    {
                        $to_warehouse = $this->obj_reports_model->insert_to_warehouse_info($to_warehouse);
                    }
                }
                
                
                //PO CMU
                $PO_CMU = $row['PO_CMU'];
                if(!empty($PO_CMU))
                {
                    $get_PO_CMU_scriptinfo = $this->obj_reports_model->get_PO_CMU_info($PO_CMU);
                    if ($get_PO_CMU_scriptinfo) 
                    {
                        $get_PO_CMU_scriptinfo_arr = $get_PO_CMU_scriptinfo->result_array();
                        foreach ($get_PO_CMU_scriptinfo_arr as $row55) {
                            $PO_CMU = $row55['pk_id'];
                        }
                    }
                    else
                    {
                        $PO_CMU = $this->obj_reports_model->insert_PO_CMU_info($PO_CMU);
                    }
                }
                
                
                //GWIS MASTER Data Entry
                
                
                
                //Login to enter master data using conditions
                
                
//                $get_existing_master_scriptinfo = $this->obj_reports_model->get_gwis_master_info($tran_date,$from_warehouse,$to_warehouse,$source_type);
//                if($get_existing_master_scriptinfo)
//                {
//                    $get_existing_master_arr = $get_existing_master_scriptinfo->result_array();
//                    foreach ($get_existing_master_arr as $row56) {
//                        $master_id = $row56['pk_id'];
//                    }
//                }
                
                
                
                //Logic For master and detail id if use then must add new field in gwis_master ( script_master_id )
                
                $get_r_existing_master_scriptinfo = $this->obj_reports_model->get_last_cmu_data_info($row['detail_id']);
                if($get_r_existing_master_scriptinfo)
                {
                    $get_r_existing_master_arr = $get_r_existing_master_scriptinfo->result_array();
                    foreach ($get_r_existing_master_arr as $row57) {
                        $scriptmaster_id = $row57['script_master_id'];
                        $master_idy = $row57['pk_id'];
                    }
                }
                
                if(isset($scriptmaster_id) && $scriptmaster_id == $row['master_id'])
                {
                    $master_id = $master_idy;
                }
                else
                {
                    $master_id = $this->obj_reports_model->insert_gwis_master_info($tran_date,$trans_no,$Status,$from_warehouse,
                                                                            $to_warehouse,$created_on_time,$tr_no,$source_type,
                                                                                $stkname,$PO_CMU,$row['master_id']);
                }
//                echo $master_id;exit;
                
                
                //End of Master Data entery
                
                
                
                //Manufacturer
                $manufacturer = $row['manufacturer'];
                if(!empty($manufacturer))
                {
                    $get_manufacturer_scriptinfo = $this->obj_reports_model->get_manufacturer_info($manufacturer);
                    if ($get_manufacturer_scriptinfo) 
                    {
                        $get_manufacturer_scriptinfo_arr = $get_manufacturer_scriptinfo->result_array();
                        foreach ($get_manufacturer_scriptinfo_arr as $row6) {
                            $manufacturer = $row6['stkid'];
                        }
                    }
                    else
                    {
                        $manufacturer = $this->obj_reports_model->insert_manufacturer_info($manufacturer);
                    }
                }
                
                //Generic Name
                $generic_name = $row['itm_name'];
                if(!empty($generic_name))
                {
                    $get_generic_name_scriptinfo = $this->obj_reports_model->get_generic_name_info($generic_name);
                    if ($get_generic_name_scriptinfo) 
                    {
                        $get_generic_name_scriptinfo_arr = $get_generic_name_scriptinfo->result_array();
                        foreach ($get_generic_name_scriptinfo_arr as $row7) {
                            $generic_name = $row7['pk_id'];
                        }
                    }
                    else
                    {
                        $generic_name = $this->obj_reports_model->insert_generic_name_info($generic_name);
                    }
                }
                
                //Strength
                $Strength = $row['Strength'];
                if(!empty($Strength))
                {
                    $get_Strength_scriptinfo = $this->obj_reports_model->get_Strength_info($Strength);
                    if ($get_Strength_scriptinfo) 
                    {
                        $get_Strength_scriptinfo_arr = $get_Strength_scriptinfo->result_array();
                        foreach ($get_Strength_scriptinfo_arr as $row8) {
                            $Strength = $row8['pk_id'];
                        }
                    }
                    else
                    {
                        $Strength = $this->obj_reports_model->insert_Strength_info($Strength);
                    }
                }
                
                //Method
                $Method = $row['Method'];
                if(!empty($Method))
                {
                    $get_Method_scriptinfo = $this->obj_reports_model->get_Method_info($Method);
                    if ($get_Method_scriptinfo) 
                    {
                        $get_Method_scriptinfo_arr = $get_Method_scriptinfo->result_array();
                        foreach ($get_Method_scriptinfo_arr as $row9) {
                            $Method = $row9['pk_id'];
                        }
                    }
                    else
                    {
                        $Method = $this->obj_reports_model->insert_Method_info($Method);
                    }
                }
                
                
                //Itmrec ID
                $itmlastid = '0';
                $itmlast_id = $this->obj_itminfo->getLastID(1);
                    
                if (!empty($itmlast_id)) {
                    if ($itmlast_id)
                        $itmlast_idd = $itmlast_id->result_array();
                    foreach ($itmlast_idd as $row10) {
                            $itmlastid = $row10['Maxtr'];
                        }
                }

                if ($itmlastid == NULL || empty($itmlastid)) {
                    $itmlastid = 0;
                }

                $string = 'P-';
                
                $string.=str_pad(($itmlastid+1), 3, '0', STR_PAD_LEFT);
                $itmrec_id = $string;
                
                
                //Qty Per Pack
                $Qty_per_Pack = $row['Qty_per_Pack'];
                
                //Pack Per Carton
                $Pack_per_Carton = $row['Pack_per_Carton'];
                
                //Product Type
                $product_type = $row['product_type'];
                if(!empty($product_type))
                {
                    $get_product_type_scriptinfo = $this->obj_reports_model->get_product_type_info($product_type);
                    if ($get_product_type_scriptinfo) 
                    {
                        $get_product_type_scriptinfo_arr = $get_product_type_scriptinfo->result_array();
                        foreach ($get_product_type_scriptinfo_arr as $row99) {
                            $product_type = $row99['pk_id'];
                        }
                    }
                    else
                    {
                        $product_type = $this->obj_reports_model->insert_product_type_info($product_type);
                    }
                }
                
                //Product Name
                $itm_name = $row['itm_name'];
                if(!empty($itm_name))
                {
                    $get_itm_name_scriptinfo = $this->obj_reports_model->get_itm_name_info($itm_name,$Strength);
                    if ($get_itm_name_scriptinfo) 
                    {
                        $get_itm_name_scriptinfo_arr = $get_itm_name_scriptinfo->result_array();
                        foreach ($get_itm_name_scriptinfo_arr as $row11) {
                            $itm_name = $row11['itm_id'];
                        }
                    }
                    else
                    {
                        $itm_name = $this->obj_reports_model->insert_itm_name_info($itm_name,$generic_name,$Method,$Strength,$manufacturer,$itmrec_id,$Qty_per_Pack,$Pack_per_Carton,$product_type);
                    }
                }
                
                
                //Batch Expiry
                $batch_expirys = $row['batch_expiry'];
                $batch_expiry = date("Y-m-d", strtotime($batch_expirys));  
                
                //Production Date
                $production_datess = $row['production_date'];
                $production_date = date("Y-m-d", strtotime($production_datess));
                
                //Quantity
                $quantity = $row['quantity'];
                
                //Unit Price
                $unit_price = $row['unit_price'];
                
                //Conversion Rate
                $conversion_rate = $row['conversion_rate'];
                
                //Currency
                $currency = $row['currency'];
                if(!empty($currency))
                {
                    $get_currency_scriptinfo = $this->obj_reports_model->get_currency_info($currency);
                    if ($get_currency_scriptinfo) 
                    {
                        $get_currency_scriptinfo_arr = $get_currency_scriptinfo->result_array();
                        foreach ($get_currency_scriptinfo_arr as $row12) {
                            $currency = $row12['pk_id'];
                        }
                    }
                    else
                    {
                        $currency = $this->obj_reports_model->insert_currency_info($currency);
                    }
                }
                
                
                
                
                //Stock Batch Data Entry
                //Using Batch No
                
                
                
                $batch_number = $row['batch_no'];
                $batch_no = $row['batch_no'];
                if(!empty($batch_no))
                {
                    $get_batch_no_scriptinfo = $this->obj_reports_model->m_get_batch_no_info($batch_no,$itm_name);
                    if ($get_batch_no_scriptinfo) 
                    {
                        $get_batch_no_scriptinfo_arr = $get_batch_no_scriptinfo->result_array();
                        foreach ($get_batch_no_scriptinfo_arr as $row13) {
                            $batch_no = $row13['batch_id'];
                        }
                    }
                    else
                    {
                        $batch_no = $this->obj_reports_model->insert_batch_no_info($batch_no,$batch_expiry,$itm_name,$quantity,
                                                                                    $unit_price,'97800',$currency,
                                                                                    $conversion_rate,$production_date,$manufacturer,
                                                                                    $source_type);
                    }
                }
                
                
                
//                echo $batch_no;exit;
                
                
                
                
                //Driver Name
                $driver_name = $row['driver_name'];
                
                //Driver Contact
                $driver_contract = $row['driver_contract'];
                
                //Siv Cnic
                $siv_cnic = $row['siv_cnic'];
                
                //Vehicle Reg
                $vehicle_reg = $row['vehicle_reg'];
                
                //Dc No
                $dc_no = $row['dc_no'];
                
                //Dc Date
                $dc_dates = $row['dc_date'];
                $dc_date = date("Y-m-d", strtotime($dc_dates)); 
                
//                $dc_dates = str_replace('/', '-', $row['dc_date']);
//                $dc_dates_day   = date('d',strtotime($dc_dates));
//                $dc_dates_month   = date('m',strtotime($dc_dates));
//                $dc_dates_year   = date('Y',strtotime($dc_dates));
//                $dc_date = $dc_dates_year.'-'.$dc_dates_month.'-'.$dc_dates_day;
 
                
                //Invoice
                $invoice = $row['invoice'];
                
                //Siv Mode Of Transport
                $siv_mode_of_transport = $row['siv_mode_of_transport'];
                
                //Siv Name Of Transporter
                $siv_name_of_transporter = $row['siv_name_of_transporter'];
                
                //Siv Vehicle Plate No
                $siv_vehicle_plate_no = $row['siv_vehicle_plate_no'];
                
                //Shipment Temprature
                $Shipment_Temprature = $row['Shipment_Temprature'];
                 
                //Siv Vehicle Type
                $siv_vehicle_type = $row['siv_vehicle_type'];
                if(!empty($siv_vehicle_type))
                {
                    $get_siv_vehicle_type_scriptinfo = $this->obj_reports_model->get_siv_vehicle_type_info($siv_vehicle_type);
                    if ($get_siv_vehicle_type_scriptinfo) 
                    {
                        $get_siv_vehicle_type_scriptinfo_arr = $get_siv_vehicle_type_scriptinfo->result_array();
                        foreach ($get_siv_vehicle_type_scriptinfo_arr as $row14) {
                            $siv_vehicle_type = $row14['pk_id'];
                        }
                    }
                    else
                    {
                        $siv_vehicle_type = $this->obj_reports_model->insert_siv_vehicle_type_info($siv_vehicle_type);
                    }
                }
                
                //Serial No
                $serial_no = $row['Serial_No'];
                
                
                
                //GWIS DETAIL Data Entry
                
                $detail_id = $this->obj_reports_model->m_insert_gwis_detail_info($master_id,$batch_no,$quantity,$batch_number,$manufacturer,
                                                                                $batch_expiry,$driver_name,$driver_contract,
                                                                                $siv_cnic,$vehicle_reg,$dc_no,$dc_date,$invoice,
                                                                                $siv_mode_of_transport,$siv_name_of_transporter,
                                                                                $siv_vehicle_plate_no,$Shipment_Temprature,$Status,
                                                                                $siv_vehicle_type,$production_date,$serial_no);
                
                
                
//                echo $detail_id;exit;
                
                
                //Tran Ref
//                $tran_ref = $row['tran_ref'];
                
                //Twenty_ft_Container_truck
//                $twenty_ft_Container_truck = $row['20_ft_Container_truck'];
                
                //TAC No
                $TAC_No = $row['TAC_No'];
                
                //TAC DT
                $TAC_dt = $row['TAC_dt'];
                
                //GRN No
                $GRN_no = $row['GRN_no'];
                
                //GRN DT
                $GRN_dt = $row['GRN_dt'];
            }
        }
        
        
        $data['page_title'] = "Process Script";
        $data['main_content'] = $this->load->view('Runscript/process_script', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    
    public function process_script_tbfline() { 
        $data = array();
        $scriptinfo = $this->obj_reports_model->tbfline_get_all_script_table_info();
        
        
        if ($scriptinfo) {
            $scriptinfo_arr = $scriptinfo->result_array();
            foreach ($scriptinfo_arr as $row) {
//                $pk_id = $row['master_id'];
//                $detail_id = $row['detail_id'];
                
                //Created On
                date_default_timezone_set('Asia/Karachi');
                $created_on_time = date('Y-m-d h:i:s', time());
                
                //Tran Date
                $tran_dates = $row['tran_date'];
                $tran_date = date("Y-m-d", strtotime($tran_dates));
                
//                $tran_dates = str_replace('/', '-', $row['tran_date']);
//                $tran_dates_day   = date('d',strtotime($tran_dates));
//                $tran_dates_month   = date('m',strtotime($tran_dates));
//                $tran_dates_year   = date('Y',strtotime($tran_dates));
//                $tran_date = $tran_dates_year.'-'.$tran_dates_month.'-'.$tran_dates_day;
  
//                $tran_no = $row['tran_no'];
                
                //Source Type
                $source_type = $row['source_type'];
                if(!empty($source_type))
                {
                    $get_source_type_scriptinfo = $this->obj_reports_model->get_source_type_info($source_type);
                    if ($get_source_type_scriptinfo) 
                    {
                        $get_source_type_scriptinfo_arr = $get_source_type_scriptinfo->result_array();
                        foreach ($get_source_type_scriptinfo_arr as $row1) {
                            $source_type = $row1['stkid'];
                        }
                    }
                    else
                    {
                        $source_type = $this->obj_reports_model->insert_source_type_info($source_type);
                    }
                }
                
                //Stakeholder Name
                $stkname = $row['stkname'];
                if(!empty($stkname))
                {
                    $get_stkname_scriptinfo = $this->obj_reports_model->get_stkname_info($stkname);
                    if ($get_stkname_scriptinfo) 
                    {
                        $get_stkname_scriptinfo_arr = $get_stkname_scriptinfo->result_array();
                        foreach ($get_stkname_scriptinfo_arr as $row2) {
                            $stkname = $row2['stkid'];
                        }
                    }
                    else
                    {
                        $stkname = $this->obj_reports_model->insert_stkname_info($stkname);
                    }
                }
                
                //Status
                $Status = $row['Status'];
                if($Status == '13')
                {
                    $Status = '3';
                }
                else {
                    $Status = $row['Status'];
                }
                
                //Process to get Tran No
                
                
                
                
                $current_year = date("Y");
                //current month
                $current_month = date("m");
                if ($current_month < 7) {
                    //from date
                    $from_date = ($current_year - 1) . "-06-30";
                    //to date
                    $to_date = $current_year . "-07-30";
                } else {
                    //from date
                    $from_date = $current_year . "-06-30";
                    //to date
                    $to_date = ($current_year + 1) . "-07-30";
                }
            
                //get last id
                $last_id = $this->obj_reports_model->getLastIDy($from_date, $to_date, '');
                
                if (!empty($last_id)) {
                    if ($last_id)
                        $last_idd = $last_id->result_array();
                    foreach ($last_idd as $row3) {
                            $lastid = $row3['Maxtr'];
                        }
                }
                
                if ($lastid == NULL) {
                    $lastid = 0;
                }
                
                if(isset($row['itm_name']) && !empty($row['itm_name']))
                {
//                    $charc = substr($row['itm_name'], 0, 1);
                    if($row['Status'] == '13')
                    {
                        $prefix = 'R';
                    }
                    else if($row['Status'] == '3')
                    {
                        $prefix = 'R';
                    }
                    else if($row['Status'] == '4')
                    {
                        $prefix = 'I';
                    }
                    else{
                        $prefix = 'A';
                    }
                }
                
                $issue_tran_dates = $row['tran_date'];
                $issue_tran_date = date("ym", strtotime($issue_tran_dates));
                
                $trans_no = $prefix . "" . $issue_tran_date.str_pad(($lastid + 1), 4, "0", STR_PAD_LEFT);
                $tr_no = $lastid + 1;
                
                //From Warehouse 
                $from_warehouse = $row['from_warehouse'];
                if(!empty($from_warehouse))
                {
                    $get_warehouse_scriptinfo = $this->obj_reports_model->get_from_warehouse_info($from_warehouse);
                    if ($get_warehouse_scriptinfo) 
                    {
                        $get_warehouse_scriptinfo_arr = $get_warehouse_scriptinfo->result_array();
                        foreach ($get_warehouse_scriptinfo_arr as $row4) {
                            $from_warehouse = $row4['wh_id'];
                        }
                    }
                    else
                    {
                        $from_warehouse = $this->obj_reports_model->insert_from_warehouse_info($from_warehouse);
                    }
                }
                
                //To Warehouse
                $to_warehouse = $row['to_warehouse'];
                if(!empty($to_warehouse))
                {
                    $get_to_warehouse_scriptinfo = $this->obj_reports_model->get_to_warehouse_info($to_warehouse);
                    if ($get_to_warehouse_scriptinfo) 
                    {
                        $get_to_warehouse_scriptinfo_arr = $get_to_warehouse_scriptinfo->result_array();
                        foreach ($get_to_warehouse_scriptinfo_arr as $row5) {
                            $to_warehouse = $row5['wh_id'];
                        }
                    }
                    else
                    {
                        $to_warehouse = $this->obj_reports_model->insert_to_warehouse_info($to_warehouse);
                    }
                }
                
                
                //PO CMU
                $PO_CMU = $row['PO_CMU'];
                if(!empty($PO_CMU))
                {
                    $get_PO_CMU_scriptinfo = $this->obj_reports_model->get_PO_CMU_info($PO_CMU);
                    if ($get_PO_CMU_scriptinfo) 
                    {
                        $get_PO_CMU_scriptinfo_arr = $get_PO_CMU_scriptinfo->result_array();
                        foreach ($get_PO_CMU_scriptinfo_arr as $row55) {
                            $PO_CMU = $row55['pk_id'];
                        }
                    }
                    else
                    {
                        $PO_CMU = $this->obj_reports_model->insert_PO_CMU_info($PO_CMU);
                    }
                }
                
                
                //GWIS MASTER Data Entry
                
                
                
                //Login to enter master data using conditions
                
                
//                $get_existing_master_scriptinfo = $this->obj_reports_model->get_gwis_master_info($tran_date,$from_warehouse,$to_warehouse,$source_type);
//                if($get_existing_master_scriptinfo)
//                {
//                    $get_existing_master_arr = $get_existing_master_scriptinfo->result_array();
//                    foreach ($get_existing_master_arr as $row56) {
//                        $master_id = $row56['pk_id'];
//                    }
//                }
                
                
                
                //Logic For master and detail id if use then must add new field in gwis_master ( script_master_id )
                
                $get_r_existing_master_scriptinfo = $this->obj_reports_model->get_last_cmu_data_info($row['detail_id']);
                if($get_r_existing_master_scriptinfo)
                {
                    $get_r_existing_master_arr = $get_r_existing_master_scriptinfo->result_array();
                    foreach ($get_r_existing_master_arr as $row57) {
                        $scriptmaster_id = $row57['script_master_id'];
                        $master_idy = $row57['pk_id'];
                    }
                }
                
                if(isset($scriptmaster_id) && $scriptmaster_id == $row['master_id'])
                {
                    $master_id = $master_idy;
                }
                else
                {
                    $master_id = $this->obj_reports_model->insert_gwis_master_info($tran_date,$trans_no,$Status,$from_warehouse,
                                                                            $to_warehouse,$created_on_time,$tr_no,$source_type,
                                                                                $stkname,$PO_CMU,$row['master_id']);
                }
//                echo $master_id;exit;
                
                
                //End of Master Data entery
                
                
                
                //Manufacturer
                $manufacturer = $row['manufacturer'];
                if(!empty($manufacturer))
                {
                    $get_manufacturer_scriptinfo = $this->obj_reports_model->get_manufacturer_info($manufacturer);
                    if ($get_manufacturer_scriptinfo) 
                    {
                        $get_manufacturer_scriptinfo_arr = $get_manufacturer_scriptinfo->result_array();
                        foreach ($get_manufacturer_scriptinfo_arr as $row6) {
                            $manufacturer = $row6['stkid'];
                        }
                    }
                    else
                    {
                        $manufacturer = $this->obj_reports_model->insert_manufacturer_info($manufacturer);
                    }
                }
                
                //Generic Name
                $generic_name = $row['itm_name'];
                if(!empty($generic_name))
                {
                    $get_generic_name_scriptinfo = $this->obj_reports_model->get_generic_name_info($generic_name);
                    if ($get_generic_name_scriptinfo) 
                    {
                        $get_generic_name_scriptinfo_arr = $get_generic_name_scriptinfo->result_array();
                        foreach ($get_generic_name_scriptinfo_arr as $row7) {
                            $generic_name = $row7['pk_id'];
                        }
                    }
                    else
                    {
                        $generic_name = $this->obj_reports_model->insert_generic_name_info($generic_name);
                    }
                }
                
                //Strength
                $Strength = $row['Strength'];
                if(!empty($Strength))
                {
                    $get_Strength_scriptinfo = $this->obj_reports_model->get_Strength_info($Strength);
                    if ($get_Strength_scriptinfo) 
                    {
                        $get_Strength_scriptinfo_arr = $get_Strength_scriptinfo->result_array();
                        foreach ($get_Strength_scriptinfo_arr as $row8) {
                            $Strength = $row8['pk_id'];
                        }
                    }
                    else
                    {
                        $Strength = $this->obj_reports_model->insert_Strength_info($Strength);
                    }
                }
                
                //Method
                $Method = $row['Method'];
                if(!empty($Method))
                {
                    $get_Method_scriptinfo = $this->obj_reports_model->get_Method_info($Method);
                    if ($get_Method_scriptinfo) 
                    {
                        $get_Method_scriptinfo_arr = $get_Method_scriptinfo->result_array();
                        foreach ($get_Method_scriptinfo_arr as $row9) {
                            $Method = $row9['pk_id'];
                        }
                    }
                    else
                    {
                        $Method = $this->obj_reports_model->insert_Method_info($Method);
                    }
                }
                
                
                //Itmrec ID
                $itmlastid = '0';
                $itmlast_id = $this->obj_itminfo->getLastID(1);
                    
                if (!empty($itmlast_id)) {
                    if ($itmlast_id)
                        $itmlast_idd = $itmlast_id->result_array();
                    foreach ($itmlast_idd as $row10) {
                            $itmlastid = $row10['Maxtr'];
                        }
                }

                if ($itmlastid == NULL || empty($itmlastid)) {
                    $itmlastid = 0;
                }

                $string = 'P-';
                
                $string.=str_pad(($itmlastid+1), 3, '0', STR_PAD_LEFT);
                $itmrec_id = $string;
                
                
                //Qty Per Pack
                $Qty_per_Pack = $row['Qty_per_Pack'];
                
                //Pack Per Carton
                $Pack_per_Carton = $row['Pack_per_Carton'];
                
                //Product Type
                $product_type = $row['product_type'];
                if(!empty($product_type))
                {
                    $get_product_type_scriptinfo = $this->obj_reports_model->get_product_type_info($product_type);
                    if ($get_product_type_scriptinfo) 
                    {
                        $get_product_type_scriptinfo_arr = $get_product_type_scriptinfo->result_array();
                        foreach ($get_product_type_scriptinfo_arr as $row99) {
                            $product_type = $row99['pk_id'];
                        }
                    }
                    else
                    {
                        $product_type = $this->obj_reports_model->insert_product_type_info($product_type);
                    }
                }
                
                //Product Name
                $itm_name = $row['itm_name'];
                if(!empty($itm_name))
                {
                    $get_itm_name_scriptinfo = $this->obj_reports_model->get_itm_name_info($itm_name,$Strength);
                    if ($get_itm_name_scriptinfo) 
                    {
                        $get_itm_name_scriptinfo_arr = $get_itm_name_scriptinfo->result_array();
                        foreach ($get_itm_name_scriptinfo_arr as $row11) {
                            $itm_name = $row11['itm_id'];
                        }
                    }
                    else
                    {
                        $itm_name = $this->obj_reports_model->insert_itm_name_info($itm_name,$generic_name,$Method,$Strength,$manufacturer,$itmrec_id,$Qty_per_Pack,$Pack_per_Carton,$product_type);
                    }
                }
                
                
                //Batch Expiry
                $batch_expirys = $row['batch_expiry'];
                $batch_expiry = date("Y-m-d", strtotime($batch_expirys));  
                
                //Production Date
                $production_datess = $row['production_date'];
                $production_date = date("Y-m-d", strtotime($production_datess));
                
                //Quantity
                $quantity = $row['quantity'];
                
                //Unit Price
                $unit_price = $row['unit_price'];
                
                //Conversion Rate
                $conversion_rate = $row['conversion_rate'];
                
                //Currency
                $currency = $row['currency'];
                if(!empty($currency))
                {
                    $get_currency_scriptinfo = $this->obj_reports_model->get_currency_info($currency);
                    if ($get_currency_scriptinfo) 
                    {
                        $get_currency_scriptinfo_arr = $get_currency_scriptinfo->result_array();
                        foreach ($get_currency_scriptinfo_arr as $row12) {
                            $currency = $row12['pk_id'];
                        }
                    }
                    else
                    {
                        $currency = $this->obj_reports_model->insert_currency_info($currency);
                    }
                }
                
                
                
                
                //Stock Batch Data Entry
                //Using Batch No
                
                
                
                $batch_number = $row['batch_no'];
                $batch_no = $row['batch_no'];
                if(!empty($batch_no))
                {
                    $get_batch_no_scriptinfo = $this->obj_reports_model->get_batch_no_info($batch_no,$itm_name);
                    if ($get_batch_no_scriptinfo) 
                    {
                        $get_batch_no_scriptinfo_arr = $get_batch_no_scriptinfo->result_array();
                        foreach ($get_batch_no_scriptinfo_arr as $row13) {
                            $batch_no = $row13['batch_id'];
                        }
                    }
                    else
                    {
                        $batch_no = $this->obj_reports_model->insert_batch_no_info($batch_no,$batch_expiry,$itm_name,$quantity,
                                                                                    $unit_price,'97800',$currency,
                                                                                    $conversion_rate,$production_date,$manufacturer,
                                                                                    $source_type);
                    }
                }
                
                
                
//                echo $batch_no;exit;
                
                
                
                
                //Driver Name
                $driver_name = $row['driver_name'];
                
                //Driver Contact
                $driver_contract = $row['driver_contract'];
                
                //Siv Cnic
                $siv_cnic = $row['siv_cnic'];
                
                //Vehicle Reg
                $vehicle_reg = $row['vehicle_reg'];
                
                //Dc No
                $dc_no = $row['dc_no'];
                
                //Dc Date
                $dc_dates = $row['dc_date'];
                $dc_date = date("Y-m-d", strtotime($dc_dates)); 
                
//                $dc_dates = str_replace('/', '-', $row['dc_date']);
//                $dc_dates_day   = date('d',strtotime($dc_dates));
//                $dc_dates_month   = date('m',strtotime($dc_dates));
//                $dc_dates_year   = date('Y',strtotime($dc_dates));
//                $dc_date = $dc_dates_year.'-'.$dc_dates_month.'-'.$dc_dates_day;
 
                
                //Invoice
                $invoice = $row['invoice'];
                
                //Siv Mode Of Transport
                $siv_mode_of_transport = $row['siv_mode_of_transport'];
                
                //Siv Name Of Transporter
                $siv_name_of_transporter = $row['siv_name_of_transporter'];
                
                //Siv Vehicle Plate No
                $siv_vehicle_plate_no = $row['siv_vehicle_plate_no'];
                
                //Shipment Temprature
                $Shipment_Temprature = $row['Shipment_Temprature'];
                 
                //Siv Vehicle Type
                $siv_vehicle_type = $row['siv_vehicle_type'];
                if(!empty($siv_vehicle_type))
                {
                    $get_siv_vehicle_type_scriptinfo = $this->obj_reports_model->get_siv_vehicle_type_info($siv_vehicle_type);
                    if ($get_siv_vehicle_type_scriptinfo) 
                    {
                        $get_siv_vehicle_type_scriptinfo_arr = $get_siv_vehicle_type_scriptinfo->result_array();
                        foreach ($get_siv_vehicle_type_scriptinfo_arr as $row14) {
                            $siv_vehicle_type = $row14['pk_id'];
                        }
                    }
                    else
                    {
                        $siv_vehicle_type = $this->obj_reports_model->insert_siv_vehicle_type_info($siv_vehicle_type);
                    }
                }
                
                
                //GWIS DETAIL Data Entry
                
                $detail_id = $this->obj_reports_model->insert_gwis_detail_info($master_id,$batch_no,$quantity,$batch_number,$manufacturer,
                                                                                $batch_expiry,$driver_name,$driver_contract,
                                                                                $siv_cnic,$vehicle_reg,$dc_no,$dc_date,$invoice,
                                                                                $siv_mode_of_transport,$siv_name_of_transporter,
                                                                                $siv_vehicle_plate_no,$Shipment_Temprature,$Status,
                                                                                $siv_vehicle_type,$production_date);
                
                
                
//                echo $detail_id;exit;
                
                
                //Tran Ref
//                $tran_ref = $row['tran_ref'];
                
                //Twenty_ft_Container_truck
//                $twenty_ft_Container_truck = $row['20_ft_Container_truck'];
                
                //TAC No
                $TAC_No = $row['TAC_No'];
                
                //TAC DT
                $TAC_dt = $row['TAC_dt'];
                
                //GRN No
                $GRN_no = $row['GRN_no'];
                
                //GRN DT
                $GRN_dt = $row['GRN_dt'];
            }
        }
        
        
        $data['page_title'] = "Process Script";
        $data['main_content'] = $this->load->view('Runscript/process_script', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
}
