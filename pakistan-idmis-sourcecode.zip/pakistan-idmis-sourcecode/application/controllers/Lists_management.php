<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Lists_management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('lists');
        $this->obj = new Lists();
    }

    public function index($master_id) {
        $master_lists =array('NONE','Oral Drugs','Diabetic Patient Complications','Diabetic Since','Consuming Insulin Since','Currency','Product Type','Product Unit','Approver Designation','Approver Level','Approver Final','Document Level','Document True/False','Vehicle Type','PI','PO Types','Storage'); 
        
        $data = array();
//        $data['result_all'] = $this->obj->find_all();
        $data['result_all'] = $this->obj->find_by_master($master_id);
        
        //--------Cols to display in View -----------
        $cols_to_display=array();   //key is Display text, value is the actual field name in db
        $cols_to_display['Master List Name']='master_name';
        $cols_to_display['Display Value']='name';
        $cols_to_display['Description']='description';
        $data['cols_to_display']=$cols_to_display;

        $data['result']=array();
        foreach($data['result_all'] as $k=>$arr_val){
            $data['result'][$k]['pk_id']=$arr_val['pk_id'];
            foreach ($arr_val as $key => $val) {
                if(in_array($key, $cols_to_display)){
                $data['result'][$k][$key]=$val;
                }
            }
        } 
        //--------Cols to display in View -----END------

        $data['page_title'] = 'Manage Lists';
        $data['page_heading'] = $master_lists[$master_id];
        $data['master_id'] = $master_id ; 
        $data['main_content'] = $this->load->view('lists_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add($master_id='') {
        
        $master_lists =array('NONE','Oral Drugs','Diabetic Patient Complications','Diabetic Since','Consuming Insulin Since','Currency','Product Type','Product Unit','Approver Designation','Approver Level','Approver Final','Document Level','Document True/False','Vehicle Type','PI','PO Types','Storage'); 
//        print_r($_POST);exit;
        if ( !empty($_POST)) {
             
            if(!empty($this->input->post('edit_id'))) {
                $this->obj->pk_id=$this->input->post('edit_id');
            }
            if(!empty($this->input->post('master_id'))) {
                $this->obj->master_id=$this->input->post('master_id');
                $master_id = $this->input->post('master_id');
            }
            $this->obj->name = $this->input->post('name');   
            $file = $this->obj->save();
            redirect(base_url() . 'lists_management/index/'.$master_id, 'refresh');
        } else {  
            $data['page_title'] = 'Add New'; 
            $data['page_heading'] = $master_lists[$master_id];
            $data['master_id'] = $master_id ; 
            $master_id = (!empty($master_id)?$master_id:1);
            $data['main_content'] = $this->load->view('lists_management/add', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }

    public function edit() {  
        if ( !empty($_POST)) {
        
            if(!empty($this->input->post('edit_id'))) {
                $this->obj->pk_id=$this->input->post('edit_id');
            }
            $this->obj->name = $this->input->post('name');   

            $file = $this->obj->save();
        }
        $edit_id = $_REQUEST['id'];
        $file = $this->obj->find_by_id($edit_id);  
        $data['result'] = $file->result_array();
        $data['edit_id'] = $edit_id; 
        $data['page_title'] = 'Edit';
        $data['main_content'] = $this->load->view('lists_management/edit', $data,TRUE);
        $this->load->view('layout/main', $data);
    }

    public function change_status() {
 
        $this->obj->pk_id = $_REQUEST['id'];
        $this->obj->is_active = $_REQUEST['status'];
        $file = $this->obj->is_active();
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = 'Manage Users';
        $data['main_content'] = $this->load->view('lists_management/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

}
