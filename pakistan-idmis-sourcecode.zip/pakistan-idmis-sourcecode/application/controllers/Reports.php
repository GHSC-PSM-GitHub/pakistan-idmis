<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('reports_model');
        $this->load->model('places');
        $this->load->model('itminfo_tab_model');
        $this->load->model('stakeholder');
        $this->load->model('Stock_batch_tbl_model');
        $this->load->model('Stock_master_tbl_model');
        $this->load->model('Gwis_stock_master_model');
        $this->load->model('reports_model');
        $this->load->model('lists');
        $this->load->model('Product_model');
        $this->load->model('locations');
        $this->load->model('warehouse');
        $this->load->model('field_list_model');
        $this->field_list = new field_list_model();
        $this->obj_lists = new Lists();
        $this->obj_gwis_master = new Gwis_stock_master_model();
        $this->obj_stakeholder = new Stakeholder();
        $this->obj_itminfo = new Itminfo_tab_model();
        $this->obj_stock_batch = new Stock_batch_tbl_model();
        $this->obj_stock_master = new Stock_master_tbl_model();
//            $this->load->model('village_model');
        $this->obj = new Reports_model();
        $this->places = new Places();
        $this->obj_reports_model = new Reports_model();
        $this->obj_product = new Product_model();
        $this->obj_location = new Locations();
        $this->obj_warehouse = new Warehouse();
//            $this->village = new Village_model();
//            $this->load->model('Community_form_model');
//            $this->objs = new Community_form_model();
    }

    public function index() {
        $this->load->view("reports/index", "");
    }

    public function issuance() {
        $result = $this->obj->fetch_issuance();
        if (!empty($result)) {
            $data['list'] = $result;
        }
        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/issuance', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function issuance_list() {

        $params = array();
        if (!empty($this->input->get('btn_submit'))) {
//                echo '<pre>';
//                print_r($_REQUEST);
//                echo '</pre>';
//                exit;
            $params['date_from'] = $this->input->get('date_from');
            $params['date_to'] = $this->input->get('date_to');

            $data['date_from'] = $params['date_from'];
            $data['date_to'] = $params['date_to'];
        }
        $result = $this->obj->fetch_issuance_list($params);
        if (!empty($result)) {
            $data['list'] = $result;
        }
//                echo '<pre>';
//                print_r($_SESSION);
//                print_r($data['list']);
//                echo '</pre>';
//                exit;
        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/issuance_list', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function receive() {
        $result = $this->obj->fetch_receive();
        if (!empty($result)) {
            $data['list'] = $result;
        }
        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/receive', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function receive_list() {

        $params = array();
        if (!empty($this->input->get('btn_submit'))) {
//                echo '<pre>';
//                print_r($_REQUEST);
//                echo '</pre>';
//                exit;
            $params['date_from'] = $this->input->get('date_from');
            $params['date_to'] = $this->input->get('date_to');

            $data['date_from'] = $params['date_from'];
            $data['date_to'] = $params['date_to'];
        }
        $result = $this->obj->fetch_receive_list($params);
        if (!empty($result)) {
            $data['list'] = $result;
        }
        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/receive_list', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function trans_list() {
        $result = $this->obj->fetch_all_trans();
        if (!empty($result)) {
            $data['list'] = $result;
        }
        $data['page_title'] = 'Transactions List';
        $data['main_content'] = $this->load->view('reports/trans_list', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function soh() {
//            echo '<pre>';
//            print_r($_SESSION);
//            echo '</pre>';
//            exit;
        $result = $this->obj->fetch_soh();
        if (!empty($result)) {
            $data['list'] = $result;
        }
        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/soh', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function batch_history($batch_id) {

        $result = $this->obj->fetch_batch_history($batch_id);
        if (!empty($result)) {
            $data['list'] = $result;
        }
        $data['page_title'] = 'Batch Details';
        $data['main_content'] = $this->load->view('reports/batch_history', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function transaction_detail($id) {

        $result = $this->obj->fetch_transaction_detail($id);
        if (!empty($result)) {
            $data['list'] = $result;
        }
        $data['page_title'] = 'Transaction= Details';
        $data['main_content'] = $this->load->view('reports/transaction_detail', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

//        ************************************************************************************************

    public function update_data($sid = 0) {

        $data = array();
        $data['page_title'] = 'Edit Transaction';
        $data["fetch_data"] = $this->reports_model->fetch_single_data($sid);
        //  $data['district'] = $this->Admin_model->fetch_districts();
        // $data['display'] = $this->Admin_model->displaydata();
        $data['main_content'] = $this->load->view('reports/edit_transaction', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit_report() {
        $this->load->model("Reports_model");
        $data = array(
            "transaction_date" => $this->input->post("transaction_date"),
            "transaction_reference" => $this->input->post("transaction_reference"),
        );

        if ($this->input->post("hidden_id")) {
            $this->Reports_model->edit_data($data, $this->input->post("hidden_id"));
            redirect("reports/issuance_list");
            die();
        }
    }

    public function stock_ledger() {
//            echo '<pre>';
//            print_r($_SESSION);
//            echo '</pre>';
//            exit;
        $product = '';
        $sourcetype = '';
        $batch = '';
        if (isset($_POST['start_date'])) {
            if (isset($_POST['product']) && !empty($_POST['product'])) {
                $product = $_POST['product'];
            }
            if (isset($_POST['batch']) && !empty($_POST['batch'])) {
                $batch = $_POST['batch'];
            }
            if (isset($_POST['source_type']) && !empty($_POST['source_type'])) {
                $sourcetype = $_POST['source_type'];
            }
            $date1 = str_replace('/', '-', $_REQUEST['start_date']);
            $date2 = str_replace('/', '-', $_REQUEST['end_date']);
            //            print_r($date2);
            $startdate = date('Y-m-d', strtotime($date1));
            $enddate = date('Y-m-d', strtotime($date2));

            $process_status_nmbr_s3 = '';
            $qry_getprocess_status_s3 = $this->obj_gwis_master->getprocess_statusmax(3);
            if ($qry_getprocess_status_s3) {
                $dataprocessstatus_s3 = $qry_getprocess_status_s3->result_array();
            }
            foreach ($dataprocessstatus_s3 AS $row_s3) {
                $process_status_nmbr_s3 = $row_s3['process_status'];
            }
            $info1 = $this->obj_gwis_master->Getheaderinfofir();
            if (isset($info1) && !empty($info1)) {
                foreach ($info1->result_array() as $row2) {
                    $stkId = $row2['stkid'];
                }
                $data['whName'] = $info1->result_array();
            }
            $process_status_nmbr_s4 = '';
            $qry_getprocess_status_s4 = $this->obj_gwis_master->getprocess_statusmax(4);
            if ($qry_getprocess_status_s4) {
                $dataprocessstatus_s4 = $qry_getprocess_status_s4->result_array();
            }
            foreach ($dataprocessstatus_s4 AS $row_s4) {
                $process_status_nmbr_s4 = $row_s4['process_status'];
            }

            $pr = $this->obj->GetProduct($product);
            $result = $this->obj->GetStockLedger($startdate, $enddate, $product, $batch, $sourcetype, $process_status_nmbr_s3, $process_status_nmbr_s4);

            $batch_ob = $this->obj->getBatchOBCB('OB', $product, $startdate, $batch, $sourcetype, $process_status_nmbr_s3, $process_status_nmbr_s4);
            $batch_cb = $this->obj->getBatchOBCB('CB', $product, $enddate, $batch, $sourcetype, $process_status_nmbr_s3, $process_status_nmbr_s4);
            $batch_cb1 = $this->obj->getBatchOBCB('CB', $product, $enddate, $batch, $sourcetype, $process_status_nmbr_s3, $process_status_nmbr_s4);

            if (!empty($result)) {
                $data['list'] = $result;
            }

            if (!empty($batch_ob)) {
                $data['batch_ob'] = $batch_ob;
            }

            if (!empty($batch_cb)) {
                $data['batch_cb'] = $batch_cb;
            }

            if (!empty($batch_cb1)) {
                $data['batch_cb1'] = $batch_cb1;
            }

            if (!empty($pr)) {
                $data['pr'] = $pr;
            }

            $data['form'] = $_POST;
        }

        $product_arr = $this->obj_itminfo->find_all_products();
        if ($product_arr)
            $data['product'] = $product_arr->result_array();

        $stk_arr = $this->obj_reports_model->get_stakeholder();
        if ($stk_arr)
            $data['stakeholder'] = $stk_arr->result_array();

        $funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
        if ($funding_source_arr)
            $data['funding_source'] = $funding_source_arr->result_array();

        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/stock_ledger', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function stock_summary() {
//            //            echo '<pre>';
//            print_r($_SESSION);
//            echo '</pre>';
//            exit;
        $stakeholder = '';
        $province = '';
        if (isset($_POST['start_date'])) {
            if (isset($_POST['stakeholder']) && !empty($_POST['stakeholder'])) {
                $stakeholder = $_POST['stakeholder'];
            }
            if (isset($_POST['province']) && !empty($_POST['province'])) {
                $province = $_POST['province'];
            }
            $date1 = str_replace('/', '-', $_REQUEST['start_date']);
            $date2 = str_replace('/', '-', $_REQUEST['end_date']);
            //            print_r($date2);
            $startdate = date('Y-m-d', strtotime($date1));
            $enddate = date('Y-m-d', strtotime($date2));

            $process_status_nmbr_s3 = '';
            $qry_getprocess_status_s3 = $this->obj_gwis_master->getprocess_statusmax(3);
            if ($qry_getprocess_status_s3) {
                $dataprocessstatus_s3 = $qry_getprocess_status_s3->result_array();
            }
            foreach ($dataprocessstatus_s3 AS $row_s3) {
                $process_status_nmbr_s3 = $row_s3['process_status'];
            }

            $process_status_nmbr_s4 = '';
            $qry_getprocess_status_s4 = $this->obj_gwis_master->getprocess_statusmax(4);
            if ($qry_getprocess_status_s4) {
                $dataprocessstatus_s4 = $qry_getprocess_status_s4->result_array();
            }
            foreach ($dataprocessstatus_s4 AS $row_s4) {
                $process_status_nmbr_s4 = $row_s4['process_status'];
            }

            $result = $this->obj->getstocksummaryinfo($startdate, $enddate, $stakeholder, $province, $process_status_nmbr_s3, $process_status_nmbr_s4);
            if (!empty($result)) {
                $data['summaryinfo'] = $result;
            }

            $data['form'] = $_POST;
        }

        $stk_arr = $this->obj_stakeholder->get_all_stk();
        if ($stk_arr)
            $data['stakeholder'] = $stk_arr->result_array();
        $info1 = $this->obj_gwis_master->Getheaderinfofir();
        if (isset($info1) && !empty($info1)) {
            foreach ($info1->result_array() as $row2) {
                $stkId = $row2['stkid'];
            }
            $data['whName'] = $info1->result_array();
        }
        $prov_arr = $this->obj->get_province();
        if ($prov_arr)
            $data['province'] = $prov_arr->result_array();

        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/stock_summary', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function soh_product_wise() {
//            //            echo '<pre>';
//            print_r($_SESSION);
//            echo '</pre>';
//            exit;
        $prod_category = '';
        $process_status_nmbr = '';
        $qry_getprocess_status = $this->obj_gwis_master->getprocess_statusmax(3);
        if ($qry_getprocess_status) {
            $dataprocessstatus = $qry_getprocess_status->result_array();
        }
        foreach ($dataprocessstatus AS $row) {
            $process_status_nmbr = $row['process_status'];
        }

        $process_status_nmbr_s4 = '';
        $qry_getprocess_status_s4 = $this->obj_gwis_master->getprocess_statusmax(4);
        if ($qry_getprocess_status_s4) {
            $dataprocessstatus_s4 = $qry_getprocess_status_s4->result_array();
        }
        foreach ($dataprocessstatus_s4 AS $row_s4) {
            $process_status_nmbr_s4 = $row_s4['process_status'];
        }

        if (isset($_REQUEST['prod_category']) && !empty($_REQUEST['prod_category'])) {

            $prod_category = trim($_REQUEST['prod_category']);
        }
        $info1 = $this->obj_gwis_master->Getheaderinfofir();
        if (isset($info1) && !empty($info1)) {
            foreach ($info1->result_array() as $row2) {
                $stkId = $row2['stkid'];
            }
            $data['whName'] = $info1->result_array();
        }
        $result = $this->obj->getstockproductinfo_soh($process_status_nmbr, $process_status_nmbr_s4, $prod_category);
        if (!empty($result)) {
            $data['summaryinfo'] = $result;
        }
        $data['form'] = $_POST;
        $list_arr = $this->obj_lists->get_list(6);
        $data['product_type'] = $list_arr->result_array();

        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/soh_product_wise', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function soh_product_wise_print() {
//            //            echo '<pre>';
//            print_r($_SESSION);
//            echo '</pre>';
//            exit;
        $prod_category = '';
        $process_status_nmbr = '';
        $qry_getprocess_status = $this->obj_gwis_master->getprocess_statusmax(3);
        if ($qry_getprocess_status) {
            $dataprocessstatus = $qry_getprocess_status->result_array();
        }
        foreach ($dataprocessstatus AS $row) {
            $process_status_nmbr = $row['process_status'];
        }

        $process_status_nmbr_s4 = '';
        $qry_getprocess_status_s4 = $this->obj_gwis_master->getprocess_statusmax(4);
        if ($qry_getprocess_status_s4) {
            $dataprocessstatus_s4 = $qry_getprocess_status_s4->result_array();
        }
        foreach ($dataprocessstatus_s4 AS $row_s4) {
            $process_status_nmbr_s4 = $row_s4['process_status'];
        }

        if (isset($_REQUEST['prod_category']) && !empty($_REQUEST['prod_category'])) {

            $prod_category = trim($_REQUEST['prod_category']);
        }

        $result = $this->obj->getstockproductinfo_soh($process_status_nmbr, $process_status_nmbr_s4, $prod_category);
        if (!empty($result)) {
            $data['summaryinfo'] = $result;
        }
        $data['form'] = $_POST;
        $list_arr = $this->obj_lists->get_list(6);
        $data['product_type'] = $list_arr->result_array();

        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/soh_product_wise_print', $data, TRUE);
        $this->load->view('layout/print', $data);
    }

    public function soh_batch_wise() {
//            //            echo '<pre>';
//            print_r($_SESSION);
//            echo '</pre>';
//            exit;
        $prod_category = '';
        $process_status_nmbr = '';
        $qry_getprocess_status = $this->obj_gwis_master->getprocess_statusmax(3);
        if ($qry_getprocess_status) {
            $dataprocessstatus = $qry_getprocess_status->result_array();
        }
        foreach ($dataprocessstatus AS $row) {
            $process_status_nmbr = $row['process_status'];
        }

        if (isset($_REQUEST['prod_category']) && !empty($_REQUEST['prod_category'])) {

            $prod_category = trim($_REQUEST['prod_category']);
        }
        $info1 = $this->obj_gwis_master->Getheaderinfofir();
        if (isset($info1) && !empty($info1)) {
            foreach ($info1->result_array() as $row2) {
                $stkId = $row2['stkid'];
            }
            $data['whName'] = $info1->result_array();
        }
        $result = $this->obj->getstockbatchinfo($process_status_nmbr, $prod_category);
        if (!empty($result)) {
            $data['summaryinfo'] = $result;
        }

        $data['form'] = $_POST;
        $list_arr = $this->obj_lists->get_list(6);
        $data['product_type'] = $list_arr->result_array();
        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/soh_batch_wise', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function soh_batch_wise_print() {
//            //            echo '<pre>';
//            print_r($_SESSION);
//            echo '</pre>';
//            exit;
        $prod_category = '';
        $process_status_nmbr = '';
        $qry_getprocess_status = $this->obj_gwis_master->getprocess_statusmax(3);
        if ($qry_getprocess_status) {
            $dataprocessstatus = $qry_getprocess_status->result_array();
        }
        foreach ($dataprocessstatus AS $row) {
            $process_status_nmbr = $row['process_status'];
        }

        if (isset($_REQUEST['prod_category']) && !empty($_REQUEST['prod_category'])) {

            $prod_category = trim($_REQUEST['prod_category']);
        }

        $result = $this->obj->getstockbatchinfo($process_status_nmbr, $prod_category);
        if (!empty($result)) {
            $data['summaryinfo'] = $result;
        }

        $data['form'] = $_POST;
        $list_arr = $this->obj_lists->get_list(6);
        $data['product_type'] = $list_arr->result_array();
        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/soh_batch_wise_print', $data, TRUE);
        $this->load->view('layout/print', $data);
    }

    public function patient_threshold() {
//            echo '<pre>';
//            print_r($_SESSION);
//            echo '</pre>';
//            exit;
        $result = $this->obj->fetch_threshold();
        if (!empty($result)) {
            $data['list'] = $result;
        }
        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/patient_threshold', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function desk_review_report() {
        $result = $this->places->get_places_info();
        if (!empty($result)) {
            $data['list'] = $result;
        }
        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/desk_review_report', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    function print_ledger_history() {

        if (isset($_REQUEST['id'])) {
            $batchid = $_GET['id'];

            $getwhanduid = $this->obj_stock_batch->getfledgerbatchinfo($batchid);
            if (isset($getwhanduid) && !empty($getwhanduid)) {
                $data['fbatchinfo'] = $getwhanduid->result_array();
            }
            //Get Stocks Issue List
            $stocks = $this->obj_stock_batch->getfledgerbatchsec($batchid);
            if (isset($stocks) && !empty($stocks)) {
                $data['sbatchinfo'] = $stocks->result_array();
            }
        }
        $data['page_title'] = 'Print Ledger History';

//        redirect(base_url() . 'inventory_management/printIssue', 'refresh');
        $data['main_content'] = $this->load->view('reports/print_ledger_history', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    function printIssue() {

        if (isset($_REQUEST['id'])) {

//            $this->obj_stock_master->TranTypeID = 2;
////            $this->obj_stock_master->TranNo = $receiveno;
//            $this->obj_stock_master->WHIDTo = $_SESSION['warehouse_id'];
//            //Get WH Stock By Issue No
//            $stockReceive = $this->obj_stock_master->GetWHStockByIssueNo();
//            
//            if(isset($stockReceive) && !empty($stockReceive)){
////                $count = mysql_num_rows($stockReceive);
//                $data['stockReceive'] = $stockReceive->result_array();
//            }

            $stockId = $_GET['id'];

            $getwhanduid = $this->obj_gwis_master->Getwhanduid($stockId);
            if (isset($getwhanduid) && !empty($getwhanduid)) {
                foreach ($getwhanduid->result_array() as $row1) {
                    $wh_id = $row1['wh_id_from'];
                    $userid = $row1['created_by'];
                }
            }
            //Get Stocks Issue List
            $stocks = $this->obj_gwis_master->GetStocksIssueList($userid, $wh_id, 2, $stockId);
            if (isset($stocks) && !empty($stocks)) {
                $data['stocks'] = $stocks->result_array();
            }
            $stkId = '';
            //Get Header Info
            $info1 = $this->obj_gwis_master->Getheaderinfofir();
            if (isset($info1) && !empty($info1)) {
                foreach ($info1->result_array() as $row2) {
                    $stkId = $row2['stkid'];
                }
                $data['whName'] = $info1->result_array();
            }

            $info2 = $this->obj_gwis_master->Getheaderinfosec($stkId);
            if (isset($info2) && !empty($info2)) {
                $data['logo'] = $info2->result_array();
            } else {
                $data['logo'] = '';
            }


//            $date1 = str_replace('/', '-', $_REQUEST['start_date']);  
//            $date2 = str_replace('/', '-', $_REQUEST['end_date']);  
////            print_r($date2);
//            $date_from = date('Y-m-d', strtotime($date1));
//            $date_to   = date('Y-m-d', strtotime($date2));
//            if(isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers']))
//            {
//                $supplier_id = $_REQUEST['receive_from_suppliers'];
//            }
//            else{
//                $supplier_id = '';
//            }
//            $data['result'] = $this->obj_stock_master->stock_search($date_from,$date_to,$supplier_id,2);
        }


//        $suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
//            if ($suppliers_arr)
//                $data['suppliers'] = $suppliers_arr->result_array();

        $data['page_title'] = 'Print Issue';

//        redirect(base_url() . 'inventory_management/printIssue', 'refresh');
        $data['main_content'] = $this->load->view('reports/printIssue', $data, TRUE);
        $this->load->view('layout/print', $data);
    }

    function get_batches_of_wh() {
        $item_id = $this->input->post('item_id');
        $wh_id = $this->input->post('wh_id');
        $result = $this->obj_stock_batch->get_product_batches($item_id, $wh_id);
        $getbatch = $result->result_array();
        echo "<option value=>Select</option>";
        foreach ($getbatch as $row) {
            echo "<option value=" . $row['batch_no'] . ">" . $row['batch_no'] . "</option>";
        }
    }

    function print_receive() {

        if (isset($_REQUEST['id'])) {

//            $this->obj_stock_master->TranTypeID = 2;
////            $this->obj_stock_master->TranNo = $receiveno;
//            $this->obj_stock_master->WHIDTo = $_SESSION['warehouse_id'];
//            //Get WH Stock By Issue No
//            $stockReceive = $this->obj_stock_master->GetWHStockByIssueNo();
//            
//            if(isset($stockReceive) && !empty($stockReceive)){
////                $count = mysql_num_rows($stockReceive);
//                $data['stockReceive'] = $stockReceive->result_array();
//            }

            $stockId = $_GET['id'];

            $getwhanduid = $this->obj_gwis_master->Getwhanduid($stockId);
            if (isset($getwhanduid) && !empty($getwhanduid)) {
                foreach ($getwhanduid->result_array() as $row1) {
                    $wh_id = $row1['wh_id_from'];
                    $userid = $row1['created_by'];
                }
            }
            //Get Stocks Issue List
            $stocks = $this->obj_gwis_master->GetStocksReceiveList($userid, $wh_id, 1, $stockId);
            if (isset($stocks) && !empty($stocks)) {
                $data['stocks'] = $stocks->result_array();
            }
            $stkId = '';
            //Get Header Info
            $info1 = $this->obj_gwis_master->Getheaderinfofir();
            if (isset($info1) && !empty($info1)) {
                foreach ($info1->result_array() as $row2) {
                    $stkId = $row2['stkid'];
                }
                $data['whName'] = $info1->result_array();
            }

            $info2 = $this->obj_gwis_master->Getheaderinfosec($stkId);
            if (isset($info2) && !empty($info2)) {
                $data['logo'] = $info2->result_array();
            } else {
                $data['logo'] = '';
            }


//            $date1 = str_replace('/', '-', $_REQUEST['start_date']);  
//            $date2 = str_replace('/', '-', $_REQUEST['end_date']);  
////            print_r($date2);
//            $date_from = date('Y-m-d', strtotime($date1));
//            $date_to   = date('Y-m-d', strtotime($date2));
//            if(isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers']))
//            {
//                $supplier_id = $_REQUEST['receive_from_suppliers'];
//            }
//            else{
//                $supplier_id = '';
//            }
//            $data['result'] = $this->obj_stock_master->stock_search($date_from,$date_to,$supplier_id,2);
        }


//        $suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
//            if ($suppliers_arr)
//                $data['suppliers'] = $suppliers_arr->result_array();

        $data['page_title'] = 'Print Receive';

//        redirect(base_url() . 'inventory_management/printIssue', 'refresh');
        $data['main_content'] = $this->load->view('reports/print_receive', $data, TRUE);
        $this->load->view('layout/print', $data);
    }

    function printAdjustment() {

        if (isset($_REQUEST['id'])) {

//            $this->obj_stock_master->TranTypeID = 2;
////            $this->obj_stock_master->TranNo = $receiveno;
//            $this->obj_stock_master->WHIDTo = $_SESSION['warehouse_id'];
//            //Get WH Stock By Issue No
//            $stockReceive = $this->obj_stock_master->GetWHStockByIssueNo();
//            
//            if(isset($stockReceive) && !empty($stockReceive)){
////                $count = mysql_num_rows($stockReceive);
//                $data['stockReceive'] = $stockReceive->result_array();
//            }

            $stockId = $_GET['id'];

            $getwhanduid = $this->obj_gwis_master->Getwhanduid($stockId);
            if (isset($getwhanduid) && !empty($getwhanduid)) {
                foreach ($getwhanduid->result_array() as $row1) {
                    $wh_id = $row1['wh_id_from'];
                    $userid = $row1['created_by'];
                }
            }
            //Get Stocks Issue List
            $stocks = $this->obj_gwis_master->GetStocksAdjList($userid, $wh_id, 1, $stockId);
            if (isset($stocks) && !empty($stocks)) {
                $data['stocks'] = $stocks->result_array();
            }
            $stkId = '';
            //Get Header Info
            $info1 = $this->obj_gwis_master->Getheaderinfofir();
            if (isset($info1) && !empty($info1)) {
                foreach ($info1->result_array() as $row2) {
                    $stkId = $row2['stkid'];
                }
                $data['whName'] = $info1->result_array();
            }

            $info2 = $this->obj_gwis_master->Getheaderinfosec($stkId);
            if (isset($info2) && !empty($info2)) {
                $data['logo'] = $info2->result_array();
            } else {
                $data['logo'] = '';
            }


//            $date1 = str_replace('/', '-', $_REQUEST['start_date']);  
//            $date2 = str_replace('/', '-', $_REQUEST['end_date']);  
////            print_r($date2);
//            $date_from = date('Y-m-d', strtotime($date1));
//            $date_to   = date('Y-m-d', strtotime($date2));
//            if(isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers']))
//            {
//                $supplier_id = $_REQUEST['receive_from_suppliers'];
//            }
//            else{
//                $supplier_id = '';
//            }
//            $data['result'] = $this->obj_stock_master->stock_search($date_from,$date_to,$supplier_id,2);
        }


//        $suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
//            if ($suppliers_arr)
//                $data['suppliers'] = $suppliers_arr->result_array();

        $data['page_title'] = 'Print Receive';

//        redirect(base_url() . 'inventory_management/printIssue', 'refresh');
        $data['main_content'] = $this->load->view('reports/printAdjustment', $data, TRUE);
        $this->load->view('layout/print', $data);
    }

    function batch_management() {

        if (isset($_REQUEST['submit'])) {
            $flag = false;
            $product = '';
            $status = '';
            $batch_no = '';
            $ref_no = '';
            $funding_source = '';
            //check product
            if (!empty($_REQUEST['batch_mang_product'])) {
                //get product
                $product = trim($_REQUEST['batch_mang_product']);
                //set product
//                $qryString .= '&product=' . $product;
                $flag = true;
            }
            //check status
            if (isset($status) || (isset($_REQUEST['status']) && !empty($_REQUEST['status']))) {
                //get status
                $status = !empty($_REQUEST['status']) ? trim($_REQUEST['status']) : $status;
                //set status
//                $qryString .= '&status=' . $status;
            }
            //check batch number
            if (!empty($_REQUEST['batch_no'])) {
                //get batch number
                $batch_no = trim($_REQUEST['batch_no']);
                //set batch number
//                $qryString .= '&batch_no=' . $batch_no;
            }
            //check ref number
            if (!empty($_REQUEST['ref_no'])) {
                //get ref number
                $ref_no = trim($_REQUEST['ref_no']);
                //set ref number
//                $qryString .= '&ref_no=' . $ref_no;
            }
            //check funding_source
            if (!empty($_REQUEST['source_type'])) {
                //get funding_source
                $funding_source = trim($_REQUEST['source_type']);
                //set funding_source
//                $objStockBatch->funding_source = $funding_source;
//                $qryString .= '&funding_source=' . $funding_source;
            }

            $batchmangsearchinfo = $this->obj_stock_batch->batch_mangsearch($product, $batch_no, $ref_no, $status, $funding_source);
            if ($batchmangsearchinfo)
                $data['batchsearch'] = $batchmangsearchinfo->result_array();
        }

        $data['page_title'] = 'Batch Management';


        $suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
        // var_dump($suppliers_arr->result_array());die;
        if (is_object($suppliers_arr))
            $data['suppliers'] = $suppliers_arr->result_array();

        $product_arr = $this->obj_itminfo->find_all_products();
        // var_dump($product_arr->result_array());die;
        if (is_object($product_arr))
            $data['product'] = $product_arr->result_array();
        $funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
        if ($funding_source_arr)
            $data['funding_source'] = $funding_source_arr->result_array();

        $data['main_content'] = $this->load->view('reports/batch_management', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    function ajaxbatch() {
//        exit();
        $item_id = $this->input->post('id');
//        $wh_id = $this->input->post('wh_id');
        if ($item_id) {

            $result = $this->obj_stock_batch->getbatchmang_batchinfo($item_id);
            $data['result'] = $result->result_array();
            $data['main_content'] = $this->load->view('reports/ajaxbatch', $data, TRUE);
            $this->load->view('layout/batch_print', $data);
        }

        if ($this->input->post('batch_id')) {
            $batch_id = $this->input->post('batch_id');
            $buttons = $this->input->post('batch_status');

            if ($buttons == 'Running' || $buttons == 'Finished') {
                $button = 'Stacked';
            } else {
                $button = 'Running';
            }

            $results = $this->obj_stock_batch->updatebatchstatus($batch_id, $button);
//            $data['sresult'] = $results;
            $json_array = array();
            if ($results) {
//                foreach ($results->result_object() as $row) {
//                    $json_array['available_qty'] = $row->Qty;
//                    $json_array['batchid'] = $row->batch_id;
//
//        //            $json_array['wh_location'] = $row->wh_location;
//                    $json_array['storage_id'] = $row->storage_id;
//                }

                $batch_id = $_POST['batch_id'];
                //Getting status
                $status = $_POST['batch_status'];
                //Check status
                if ($status == 'Running' || $status == 'Finished') {
                    $button = 'Stacked';
                } else {
                    $button = 'Running';
                }
                //    change Status
                //    $result = $objStockBatch->changeStatus($batch_id, $button);
                if ($results) {
                    $json_array = array(
                        'status' => $button,
                        'button' => $status
                    );
                } else {
                    $json_array = array(
                        'status' => $status,
                        'button' => $button
                    );
                }
            }
            echo json_encode($json_array);
        }
    }

    function print_batch_management() {

        if (isset($_REQUEST['type'])) {
            $result = $this->obj_stock_batch->getbatchmang_batchsummary($_REQUEST['type']);
            $data['result'] = $result->result_array();
        }
        $info1 = $this->obj_gwis_master->Getheaderinfofir();
        if (isset($info1) && !empty($info1)) {
            foreach ($info1->result_array() as $row2) {
                $stkId = $row2['stkid'];
            }
            $data['whName'] = $info1->result_array();
        }
//        echo '<pre>';
//        print_r($_REQUEST);
//        echo '</pre>';
//        exit;
        $data['page_title'] = 'Print Batch Management';

//        redirect(base_url() . 'inventory_management/printIssue', 'refresh');
        $data['main_content'] = $this->load->view('reports/print_batch_management', $data, TRUE);
        $this->load->view('layout/print', $data);
    }

    function storage_report() {

        if (isset($_REQUEST['submit'])) {
            $flag = false;
            $product = '';
            $status = '';
            $batch_no = '';
            $ref_no = '';
            $funding_source = '';
            $storage = '';
            //check product
            if (isset($_REQUEST['batch_mang_product']) && !empty($_REQUEST['batch_mang_product'])) {
                //get product
                $product = trim($_REQUEST['batch_mang_product']);
                //set product
//                $qryString .= '&product=' . $product;
                $flag = true;
            }
            //check funding_source
            if (isset($_REQUEST['storage']) && !empty($_REQUEST['storage'])) {
                //get funding_source
                $storage = $_REQUEST['storage'];
                //set funding_source
//                $objStockBatch->funding_source = $funding_source;
//                $qryString .= '&funding_source=' . $funding_source;
            }

            if (isset($_REQUEST['product_category']) && !empty($_REQUEST['product_category'])) {
                $product_category = $_REQUEST['product_category'];
            }

            $date1 = str_replace('/', '-', $_REQUEST['start_date']);
            $date2 = str_replace('/', '-', $_REQUEST['end_date']);
//            print_r($date2);
            $startdate = date('Y-m-d', strtotime($date1));
            $enddate = date('Y-m-d', strtotime($date2));

            $process_status_nmbr_s3 = '';
            $qry_getprocess_status_s3 = $this->obj_gwis_master->getprocess_statusmax(3);
            if ($qry_getprocess_status_s3) {
                $dataprocessstatus_s3 = $qry_getprocess_status_s3->result_array();
            }
            foreach ($dataprocessstatus_s3 AS $row_s3) {
                $process_status_nmbr_s3 = $row_s3['process_status'];
            }

            $process_status_nmbr_s4 = '';
            $qry_getprocess_status_s4 = $this->obj_gwis_master->getprocess_statusmax(4);
            if ($qry_getprocess_status_s4) {
                $dataprocessstatus_s4 = $qry_getprocess_status_s4->result_array();
            }
            foreach ($dataprocessstatus_s4 AS $row_s4) {
                $process_status_nmbr_s4 = $row_s4['process_status'];
            }

            $result = $this->obj_stock_batch->storage_search($startdate, $enddate, $product, $storage, $process_status_nmbr_s3, $process_status_nmbr_s4, $product_category);
            if (!empty($result)) {
                $data['storageinfo'] = $result->result_array();
            }

            $data['form'] = $_POST;
        }

        $data['page_title'] = 'Storage Report';

        $product_arr = $this->obj_itminfo->find_all_products();
        if ($product_arr)
            $data['product'] = $product_arr->result_array();

        $product_cat = $this->obj_lists->get_list(6);
        $data['product_cat'] = $product_cat->result_array();

        $storage_arr = $this->obj_lists->get_list(16);
        $data['storage'] = $storage_arr->result_array();

        $data['main_content'] = $this->load->view('reports/storage_report', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    function detail_distribution() {
        $userid = '';
        $wh_id = '';
        $stockId = '';
        $stakeholder = '';
        if (isset($_REQUEST['stakeholder'])) {
            $stakeholder = $_REQUEST['stakeholder'];
        }

//            $this->obj_stock_master->TranTypeID = 2;
////            $this->obj_stock_master->TranNo = $receiveno;
//            $this->obj_stock_master->WHIDTo = $_SESSION['warehouse_id'];
//            //Get WH Stock By Issue No
//            $stockReceive = $this->obj_stock_master->GetWHStockByIssueNo();
//            
//            if(isset($stockReceive) && !empty($stockReceive)){
////                $count = mysql_num_rows($stockReceive);
//                $data['stockReceive'] = $stockReceive->result_array();
//            }
//            $stockId = $_GET['id'];
//            
//            $getwhanduid = $this->obj_gwis_master->Getwhanduid($stockId);
//            if(isset($getwhanduid) && !empty($getwhanduid)){
//                foreach ($getwhanduid->result_array() as $row1)
//                {
//                    $wh_id = $row1['wh_id_from'];
//                    $userid = $row1['created_by'];
//                }
//            }
        //Get Stocks Issue List

        $process_status_nmbr_s3 = '';
        $qry_getprocess_status_s3 = $this->obj_gwis_master->getprocess_statusmax(3);
        if ($qry_getprocess_status_s3) {
            $dataprocessstatus_s3 = $qry_getprocess_status_s3->result_array();
        }
        foreach ($dataprocessstatus_s3 AS $row_s3) {
            $process_status_nmbr_s3 = $row_s3['process_status'];
        }

        $process_status_nmbr_s4 = '';
        $qry_getprocess_status_s4 = $this->obj_gwis_master->getprocess_statusmax(4);
        if ($qry_getprocess_status_s4) {
            $dataprocessstatus_s4 = $qry_getprocess_status_s4->result_array();
        }
        foreach ($dataprocessstatus_s4 AS $row_s4) {
            $process_status_nmbr_s4 = $row_s4['process_status'];
        }

        $stocks = $this->obj_gwis_master->Getdetail_distribution($userid, $wh_id, 2, $stockId, $process_status_nmbr_s3, $process_status_nmbr_s4, $stakeholder);
        if (isset($stocks) && !empty($stocks)) {
            $data['stocks'] = $stocks->result_array();
        }
        $stkId = '';
        //Get Header Info
        $info1 = $this->obj_gwis_master->Getheaderinfofir();
        if (isset($info1) && !empty($info1)) {
            foreach ($info1->result_array() as $row2) {
                $stkId = $row2['stkid'];
            }
            $data['whName'] = $info1->result_array();
        }

        $info2 = $this->obj_gwis_master->Getheaderinfosec($stkId);
        if (isset($info2) && !empty($info2)) {
            $data['logo'] = $info2->result_array();
        } else {
            $data['logo'] = '';
        }


//            $date1 = str_replace('/', '-', $_REQUEST['start_date']);  
//            $date2 = str_replace('/', '-', $_REQUEST['end_date']);  
////            print_r($date2);
//            $date_from = date('Y-m-d', strtotime($date1));
//            $date_to   = date('Y-m-d', strtotime($date2));
//            if(isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers']))
//            {
//                $supplier_id = $_REQUEST['receive_from_suppliers'];
//            }
//            else{
//                $supplier_id = '';
//            }
//            $data['result'] = $this->obj_stock_master->stock_search($date_from,$date_to,$supplier_id,2);
//        }
//        $suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
//            if ($suppliers_arr)
//                $data['suppliers'] = $suppliers_arr->result_array();

        $stk_arr = $this->obj_reports_model->get_stakeholder();
        if ($stk_arr)
            $data['stakeholder'] = $stk_arr->result_array();

        $data['page_title'] = 'Detail Distribution';

//        redirect(base_url() . 'inventory_management/printIssue', 'refresh');
        $data['main_content'] = $this->load->view('reports/detail_distribution', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    function detail_distribution_print() {
        $userid = '';
        $wh_id = '';
        $stockId = '';
        $stakeholder = '';
        if (isset($_REQUEST['stakeholder'])) {
            $stakeholder = $_REQUEST['stakeholder'];
        }
//        if(isset($_REQUEST['id']))
//        {
//            $this->obj_stock_master->TranTypeID = 2;
////            $this->obj_stock_master->TranNo = $receiveno;
//            $this->obj_stock_master->WHIDTo = $_SESSION['warehouse_id'];
//            //Get WH Stock By Issue No
//            $stockReceive = $this->obj_stock_master->GetWHStockByIssueNo();
//            
//            if(isset($stockReceive) && !empty($stockReceive)){
////                $count = mysql_num_rows($stockReceive);
//                $data['stockReceive'] = $stockReceive->result_array();
//            }
//            $stockId = $_GET['id'];
//            
//            $getwhanduid = $this->obj_gwis_master->Getwhanduid($stockId);
//            if(isset($getwhanduid) && !empty($getwhanduid)){
//                foreach ($getwhanduid->result_array() as $row1)
//                {
//                    $wh_id = $row1['wh_id_from'];
//                    $userid = $row1['created_by'];
//                }
//            }
        //Get Stocks Issue List


        $process_status_nmbr_s3 = '';
        $qry_getprocess_status_s3 = $this->obj_gwis_master->getprocess_statusmax(3);
        if ($qry_getprocess_status_s3) {
            $dataprocessstatus_s3 = $qry_getprocess_status_s3->result_array();
        }
        foreach ($dataprocessstatus_s3 AS $row_s3) {
            $process_status_nmbr_s3 = $row_s3['process_status'];
        }

        $process_status_nmbr_s4 = '';
        $qry_getprocess_status_s4 = $this->obj_gwis_master->getprocess_statusmax(4);
        if ($qry_getprocess_status_s4) {
            $dataprocessstatus_s4 = $qry_getprocess_status_s4->result_array();
        }
        foreach ($dataprocessstatus_s4 AS $row_s4) {
            $process_status_nmbr_s4 = $row_s4['process_status'];
        }

        $stocks = $this->obj_gwis_master->Getdetail_distribution($userid, $wh_id, 2, $stockId, $process_status_nmbr_s3, $process_status_nmbr_s4, $stakeholder);
        if (isset($stocks) && !empty($stocks)) {
            $data['stocks'] = $stocks->result_array();
        }
        $stkId = '';
        //Get Header Info
        $info1 = $this->obj_gwis_master->Getheaderinfofir();
        if (isset($info1) && !empty($info1)) {
            foreach ($info1->result_array() as $row2) {
                $stkId = $row2['stkid'];
            }
            $data['whName'] = $info1->result_array();
        }

        $info2 = $this->obj_gwis_master->Getheaderinfosec($stkId);
        if (isset($info2) && !empty($info2)) {
            $data['logo'] = $info2->result_array();
        } else {
            $data['logo'] = '';
        }


//            $date1 = str_replace('/', '-', $_REQUEST['start_date']);  
//            $date2 = str_replace('/', '-', $_REQUEST['end_date']);  
////            print_r($date2);
//            $date_from = date('Y-m-d', strtotime($date1));
//            $date_to   = date('Y-m-d', strtotime($date2));
//            if(isset($_REQUEST['receive_from_suppliers']) && !empty($_REQUEST['receive_from_suppliers']))
//            {
//                $supplier_id = $_REQUEST['receive_from_suppliers'];
//            }
//            else{
//                $supplier_id = '';
//            }
//            $data['result'] = $this->obj_stock_master->stock_search($date_from,$date_to,$supplier_id,2);
//        }
//        $suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
//            if ($suppliers_arr)
//                $data['suppliers'] = $suppliers_arr->result_array();

        $data['page_title'] = 'Detail Distribution';

//        redirect(base_url() . 'inventory_management/printIssue', 'refresh');
        $data['main_content'] = $this->load->view('reports/detail_distribution_print', $data, TRUE);
        $this->load->view('layout/print', $data);
    }

    public function distribution_detail() {
//            //            echo '<pre>';
//            print_r($_SESSION);
//            echo '</pre>';
//            exit;
        $stakeholder = '';
        $province = '';
//                if(isset($_POST['start_date']))
//                {
//                    if(isset($_POST['stakeholder']) && !empty($_POST['stakeholder']))
//                    {
//                        $stakeholder = $_POST['stakeholder'];
//                    }
//                    if(isset($_POST['province']) && !empty($_POST['province']))
//                    {
//                        $province = $_POST['province'];
//                    }
//                    $date1 = str_replace('/', '-', $_REQUEST['start_date']);  
//                    $date2 = str_replace('/', '-', $_REQUEST['end_date']);  
//        //            print_r($date2);
//                    $startdate = date('Y-m-d', strtotime($date1));
//                    $enddate   = date('Y-m-d', strtotime($date2));

        $process_status_nmbr_s3 = '';
        $qry_getprocess_status_s3 = $this->obj_gwis_master->getprocess_statusmax(3);
        if ($qry_getprocess_status_s3) {
            $dataprocessstatus_s3 = $qry_getprocess_status_s3->result_array();
        }
        foreach ($dataprocessstatus_s3 AS $row_s3) {
            $process_status_nmbr_s3 = $row_s3['process_status'];
        }
        $info1 = $this->obj_gwis_master->Getheaderinfofir();
        if (isset($info1) && !empty($info1)) {
            foreach ($info1->result_array() as $row2) {
                $stkId = $row2['stkid'];
            }
            $data['whName'] = $info1->result_array();
        }
        $process_status_nmbr_s4 = '';
        $qry_getprocess_status_s4 = $this->obj_gwis_master->getprocess_statusmax(4);
        if ($qry_getprocess_status_s4) {
            $dataprocessstatus_s4 = $qry_getprocess_status_s4->result_array();
        }
        foreach ($dataprocessstatus_s4 AS $row_s4) {
            $process_status_nmbr_s4 = $row_s4['process_status'];
        }

//                        $result = $this->obj->getstocksummaryinfo($startdate,$enddate,$stakeholder,$province,$process_status_nmbr_s3,$process_status_nmbr_s4);
        $result = $this->obj->getdistribution_detail_info($process_status_nmbr_s3, $process_status_nmbr_s4);
        if (!empty($result)) {
            $data['summaryinfo'] = $result;
        }

        $data['form'] = $_POST;
//                }

        $stk_arr = $this->obj_stakeholder->get_all_stk();
        if ($stk_arr)
            $data['stakeholder'] = $stk_arr->result_array();

        $prov_arr = $this->obj->get_province();
        if ($prov_arr)
            $data['province'] = $prov_arr->result_array();

        $data['page_title'] = 'Distribution Detail';
        $data['main_content'] = $this->load->view('reports/distribution_detail', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function distribution_detail_print() {
//            //            echo '<pre>';
//            print_r($_SESSION);
//            echo '</pre>';
//            exit;
        $stakeholder = '';
        $province = '';
//                if(isset($_POST['start_date']))
//                {
//                    if(isset($_POST['stakeholder']) && !empty($_POST['stakeholder']))
//                    {
//                        $stakeholder = $_POST['stakeholder'];
//                    }
//                    if(isset($_POST['province']) && !empty($_POST['province']))
//                    {
//                        $province = $_POST['province'];
//                    }
//                    $date1 = str_replace('/', '-', $_REQUEST['start_date']);  
//                    $date2 = str_replace('/', '-', $_REQUEST['end_date']);  
//        //            print_r($date2);
//                    $startdate = date('Y-m-d', strtotime($date1));
//                    $enddate   = date('Y-m-d', strtotime($date2));

        $process_status_nmbr_s3 = '';
        $qry_getprocess_status_s3 = $this->obj_gwis_master->getprocess_statusmax(3);
        if ($qry_getprocess_status_s3) {
            $dataprocessstatus_s3 = $qry_getprocess_status_s3->result_array();
        }
        foreach ($dataprocessstatus_s3 AS $row_s3) {
            $process_status_nmbr_s3 = $row_s3['process_status'];
        }

        $process_status_nmbr_s4 = '';
        $qry_getprocess_status_s4 = $this->obj_gwis_master->getprocess_statusmax(4);
        if ($qry_getprocess_status_s4) {
            $dataprocessstatus_s4 = $qry_getprocess_status_s4->result_array();
        }
        foreach ($dataprocessstatus_s4 AS $row_s4) {
            $process_status_nmbr_s4 = $row_s4['process_status'];
        }

//                        $result = $this->obj->getstocksummaryinfo($startdate,$enddate,$stakeholder,$province,$process_status_nmbr_s3,$process_status_nmbr_s4);
        $result = $this->obj->getdistribution_detail_info($process_status_nmbr_s3, $process_status_nmbr_s4);
        if (!empty($result)) {
            $data['summaryinfo'] = $result;
        }

        $data['form'] = $_POST;
//                }

        $stk_arr = $this->obj_stakeholder->get_all_stk();
        if ($stk_arr)
            $data['stakeholder'] = $stk_arr->result_array();

        $prov_arr = $this->obj->get_province();
        if ($prov_arr)
            $data['province'] = $prov_arr->result_array();

        $data['page_title'] = 'Distribution Detail Print';
        $data['main_content'] = $this->load->view('reports/distribution_detail_print', $data, TRUE);
        $this->load->view('layout/print', $data);
    }

    function adjustment_report() {

        if (isset($_REQUEST['submit'])) {
            $flag = false;
            $product = '';
            $status = '';
            $batch_no = '';
            $ref_no = '';
            $funding_source = '';

            $date1 = str_replace('/', '-', $_REQUEST['start_date']);
            $date2 = str_replace('/', '-', $_REQUEST['end_date']);
//            print_r($date2);
            $startdate = date('Y-m-d', strtotime($date1));
            $enddate = date('Y-m-d', strtotime($date2));
            //check product
            if (isset($_REQUEST['batch_mang_product']) && !empty($_REQUEST['batch_mang_product'])) {
                //get product
                $product = trim($_REQUEST['batch_mang_product']);
                //set product
//                $qryString .= '&product=' . $product;
                $flag = true;
            }
            //check funding_source
            if (isset($_REQUEST['tran_type']) && !empty($_REQUEST['tran_type'])) {
                //get funding_source
                $tran_type = trim($_REQUEST['tran_type']);
                //set funding_source
//                $objStockBatch->funding_source = $funding_source;
//                $qryString .= '&funding_source=' . $funding_source;
            }

            if (isset($_REQUEST['product_category']) && !empty($_REQUEST['product_category'])) {
                $product_category = $_REQUEST['product_category'];
            }

            $process_status_nmbr_s3 = '';
            $qry_getprocess_status_s3 = $this->obj_gwis_master->getprocess_statusmax(3);
            if ($qry_getprocess_status_s3) {
                $dataprocessstatus_s3 = $qry_getprocess_status_s3->result_array();
            }
            foreach ($dataprocessstatus_s3 AS $row_s3) {
                $process_status_nmbr_s3 = $row_s3['process_status'];
            }
            $info1 = $this->obj_gwis_master->Getheaderinfofir();
            if (isset($info1) && !empty($info1)) {
                foreach ($info1->result_array() as $row2) {
                    $stkId = $row2['stkid'];
                }
                $data['whName'] = $info1->result_array();
            }
            $process_status_nmbr_s4 = '';
            $qry_getprocess_status_s4 = $this->obj_gwis_master->getprocess_statusmax(4);
            if ($qry_getprocess_status_s4) {
                $dataprocessstatus_s4 = $qry_getprocess_status_s4->result_array();
            }
            foreach ($dataprocessstatus_s4 AS $row_s4) {
                $process_status_nmbr_s4 = $row_s4['process_status'];
            }

            $batchmangsearchinfo = $this->obj_stock_batch->adjustmenttypesearch($startdate, $enddate, $product, $tran_type, $process_status_nmbr_s3, $process_status_nmbr_s4, $product_category);
            if ($batchmangsearchinfo)
                $data['batchsearch'] = $batchmangsearchinfo->result_array();
            $data['form'] = $_POST;
        }

        $data['page_title'] = 'Adjustment Report';


        $suppliers_arr = $this->obj_stakeholder->find_supplierinfo();
        if ($suppliers_arr)
            $data['suppliers'] = $suppliers_arr->result_array();

        $product_arr = $this->obj_itminfo->find_all_products();
        if ($product_arr)
            $data['product'] = $product_arr->result_array();
        $funding_source_arr = $this->obj_stakeholder->get_all_info_fs();
        if ($funding_source_arr)
            $data['funding_source'] = $funding_source_arr->result_array();

        $product_cat = $this->obj_lists->get_list(6);
        $data['product_cat'] = $product_cat->result_array();

        $tran_arr = $this->obj_product->get_tran_types();
//        $tran_arr = $this->obj_product->get_specific_tran_types();
        if ($tran_arr)
            $data['trans'] = $tran_arr->result_array();

        $data['main_content'] = $this->load->view('reports/adjustment_report', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    function consumption_report() {

        if (isset($_REQUEST['submit'])) {
            $flag = false;
            $product = '';
            $status = '';
            $batch_no = '';
            $ref_no = '';
            $funding_source = '';

            $whid = '';
            if (isset($_POST['warehouse']) && !empty($_POST['warehouse'])) {
                $whid = $_POST['warehouse'];
            }
            $year = '';
            if (isset($_POST['year']) && !empty($_POST['year'])) {
                $year = $_POST['year'];
            }
            $month = '';
            if (isset($_POST['month']) && !empty($_POST['month'])) {
                $month = $_POST['month'];
            }
            $province = '';
            //check product
            if (isset($_REQUEST['province']) && !empty($_REQUEST['province'])) {
                //get product
                $province = $_REQUEST['province'];
            }
            $district = '';
            //check funding_source
            if (isset($_REQUEST['district']) && !empty($_REQUEST['district'])) {
                //get funding_source
                $district = trim($_REQUEST['district']);
            }
            $stakeholder = '';
            if (isset($_REQUEST['stakeholder']) && !empty($_REQUEST['stakeholder'])) {
                //get funding_source
                $stakeholder = trim($_REQUEST['stakeholder']);
            }

//            $process_status_nmbr_s3 = '';
//            $qry_getprocess_status_s3 = $this->obj_gwis_master->getprocess_statusmax(3);
//            if($qry_getprocess_status_s3)
//            {
//                $dataprocessstatus_s3 = $qry_getprocess_status_s3->result_array();
//            }
//            foreach ($dataprocessstatus_s3 AS $row_s3)
//            {
//                $process_status_nmbr_s3 = $row_s3['process_status'];  
//            }
//
//            $process_status_nmbr_s4 = '';
//            $qry_getprocess_status_s4 = $this->obj_gwis_master->getprocess_statusmax(4);
//            if($qry_getprocess_status_s4)
//            {
//                $dataprocessstatus_s4 = $qry_getprocess_status_s4->result_array();
//            }
//            foreach ($dataprocessstatus_s4 AS $row_s4)
//            {
//                $process_status_nmbr_s4 = $row_s4['process_status'];  
//            }
//            
            $batchmangsearchinfo = $this->obj_stock_batch->consumption_report_search($whid, $year, $month, $province, $district, $stakeholder);
            if ($batchmangsearchinfo)
                $data['batchsearch'] = $batchmangsearchinfo->result_array();
            $data['form'] = $_POST;
        }

        $data['page_title'] = 'Consumption Report';


        $stk_arr = $this->obj_reports_model->get_stakeholder();
        if ($stk_arr)
            $data['stakeholder'] = $stk_arr->result_array();

        $prov_arr = $this->obj_location->find_by_parent_id(10, 2);
        if ($prov_arr)
            $data['provinces'] = $prov_arr->result_array();

        $wh_arr = $this->obj_warehouse->find_assign_warehouse();
//        $wh_arr = $this->obj_warehouse->find_by_user_idwarehouse();
        if ($wh_arr)
            $data['warehouse'] = $wh_arr->result_array();

        $data['main_content'] = $this->load->view('reports/consumption_report', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function stock_movement_report() {
//            //            echo '<pre>';
//            print_r($_SESSION);
//            echo '</pre>';
//            exit;
        $stakeholder = '';
        $province = '';
        if (isset($_POST['start_date'])) {
            if (isset($_POST['stakeholder']) && !empty($_POST['stakeholder'])) {
                $stakeholder = $_POST['stakeholder'];
            }
            if (isset($_POST['province']) && !empty($_POST['province'])) {
                $province = $_POST['province'];
            }
            $date1 = str_replace('/', '-', $_REQUEST['start_date']);
            $date2 = str_replace('/', '-', $_REQUEST['end_date']);
            //            print_r($date2);
            $startdate = date('Y-m-d', strtotime($date1));
            $enddate = date('Y-m-d', strtotime($date2));

            $process_status_nmbr_s3 = '';
            $qry_getprocess_status_s3 = $this->obj_gwis_master->getprocess_statusmax(3);
            if ($qry_getprocess_status_s3) {
                $dataprocessstatus_s3 = $qry_getprocess_status_s3->result_array();
            }
            foreach ($dataprocessstatus_s3 AS $row_s3) {
                $process_status_nmbr_s3 = $row_s3['process_status'];
            }

            $process_status_nmbr_s4 = '';
            $qry_getprocess_status_s4 = $this->obj_gwis_master->getprocess_statusmax(4);
            if ($qry_getprocess_status_s4) {
                $dataprocessstatus_s4 = $qry_getprocess_status_s4->result_array();
            }
            foreach ($dataprocessstatus_s4 AS $row_s4) {
                $process_status_nmbr_s4 = $row_s4['process_status'];
            }

            $result = $this->obj->getstockmovementsummaryinfo($startdate, $enddate, $stakeholder, $province, $process_status_nmbr_s3, $process_status_nmbr_s4);
            if (!empty($result)) {
                $data['summaryinfo'] = $result;
            }

            $data['form'] = $_POST;
        }

        $stk_arr = $this->obj_stakeholder->get_all_stk();
        if ($stk_arr)
            $data['stakeholder'] = $stk_arr->result_array();

        $prov_arr = $this->obj->get_province();
        if ($prov_arr)
            $data['province'] = $prov_arr->result_array();

        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/stock_movement_report', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function stock_movement_report_print() {
//            //            echo '<pre>';
//            print_r($_SESSION);
//            echo '</pre>';
//            exit;
        $stakeholder = '';
        $province = '';
        if (isset($_REQUEST['start_date'])) {
            if (isset($_REQUEST['stakeholder']) && !empty($_REQUEST['stakeholder'])) {
                $stakeholder = $_REQUEST['stakeholder'];
            }
            if (isset($_REQUEST['province']) && !empty($_REQUEST['province'])) {
                $province = $_REQUEST['province'];
            }
            $date1 = str_replace('/', '-', $_REQUEST['start_date']);
            $date2 = str_replace('/', '-', $_REQUEST['end_date']);
            //            print_r($date2);
            $startdate = date('Y-m-d', strtotime($date1));
            $enddate = date('Y-m-d', strtotime($date2));

            $process_status_nmbr_s3 = '';
            $qry_getprocess_status_s3 = $this->obj_gwis_master->getprocess_statusmax(3);
            if ($qry_getprocess_status_s3) {
                $dataprocessstatus_s3 = $qry_getprocess_status_s3->result_array();
            }
            foreach ($dataprocessstatus_s3 AS $row_s3) {
                $process_status_nmbr_s3 = $row_s3['process_status'];
            }

            $process_status_nmbr_s4 = '';
            $qry_getprocess_status_s4 = $this->obj_gwis_master->getprocess_statusmax(4);
            if ($qry_getprocess_status_s4) {
                $dataprocessstatus_s4 = $qry_getprocess_status_s4->result_array();
            }
            foreach ($dataprocessstatus_s4 AS $row_s4) {
                $process_status_nmbr_s4 = $row_s4['process_status'];
            }

            $result = $this->obj->getstockmovementsummaryinfo($startdate, $enddate, $stakeholder, $province, $process_status_nmbr_s3, $process_status_nmbr_s4);
            if (!empty($result)) {
                $data['summaryinfo'] = $result;
            }

            $data['form'] = $_POST;
        }

        $stk_arr = $this->obj_stakeholder->get_all_stk();
        if ($stk_arr)
            $data['stakeholder'] = $stk_arr->result_array();

        $prov_arr = $this->obj->get_province();
        if ($prov_arr)
            $data['province'] = $prov_arr->result_array();

        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/stock_movement_report_print', $data, TRUE);
        $this->load->view('layout/print', $data);
    }

    public function stock_reconciliation_report() {
//            //            echo '<pre>';
//            print_r($_SESSION);
//            echo '</pre>';
//            exit;
        $stakeholder = '';
        $province = '';
        if (isset($_POST['start_date'])) {
            if (isset($_POST['stakeholder']) && !empty($_POST['stakeholder'])) {
                $stakeholder = $_POST['stakeholder'];
            }
            if (isset($_POST['province']) && !empty($_POST['province'])) {
                $province = $_POST['province'];
            }
            $date1 = str_replace('/', '-', $_REQUEST['start_date']);
            $date2 = str_replace('/', '-', $_REQUEST['end_date']);
            //            print_r($date2);
            $startdate = date('Y-m-d', strtotime($date1));
            $enddate = date('Y-m-d', strtotime($date2));

            $process_status_nmbr_s3 = '';
            $qry_getprocess_status_s3 = $this->obj_gwis_master->getprocess_statusmax(3);
            if ($qry_getprocess_status_s3) {
                $dataprocessstatus_s3 = $qry_getprocess_status_s3->result_array();
            }
            foreach ($dataprocessstatus_s3 AS $row_s3) {
                $process_status_nmbr_s3 = $row_s3['process_status'];
            }

            $process_status_nmbr_s4 = '';
            $qry_getprocess_status_s4 = $this->obj_gwis_master->getprocess_statusmax(4);
            if ($qry_getprocess_status_s4) {
                $dataprocessstatus_s4 = $qry_getprocess_status_s4->result_array();
            }
            foreach ($dataprocessstatus_s4 AS $row_s4) {
                $process_status_nmbr_s4 = $row_s4['process_status'];
            }

            $result = $this->obj->getstockmovementsummaryinfo($startdate, $enddate, $stakeholder, $province, $process_status_nmbr_s3, $process_status_nmbr_s4);
            if (!empty($result)) {
                $data['summaryinfo'] = $result;
            }

            $data['form'] = $_POST;
        }

        $stk_arr = $this->obj_stakeholder->get_all_stk();
        if ($stk_arr)
            $data['stakeholder'] = $stk_arr->result_array();

        $prov_arr = $this->obj->get_province();
        if ($prov_arr)
            $data['province'] = $prov_arr->result_array();

        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/stock_reconciliation_report', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function reported_non_reported() {
        if (isset($_POST['submit'])) {
            $month = $this->input->post('month');
            $year = $this->input->post('year');
            $rpt_type = $this->input->post('rpt_type');
            $lvl = $this->input->post('lvl');
            $stakeholder = $this->input->post('stakeholder');
            $province = $this->input->post('province');
            $district = $this->input->post('district');
            $reportingDate = $year . '-' . str_pad($month, 2, 0, STR_PAD_LEFT) . '-01';
            $rpt_non = $this->obj_reports_model->reported_non_reported($month, $year, $stakeholder, $province, $district, $reportingDate,$rpt_type,$lvl);
            $data['rpt'] = $rpt_non->result_array();
            $data['main_content'] = $this->load->view('reports/reported_non_reported', $data, TRUE);
        }
        $prov_arr = $this->obj_location->find_by_parent_id(10, 2);
        $data['provinces'] = $prov_arr->result_array();
        $stakeholder = $this->obj_reports_model->get_stk();
        $data['stakeholder'] = $stakeholder->result_array();
        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/reported_non_reported', $data, TRUE);
        $this->load->view('layout/main', $data);
    }
    
    
    public function shipment_rpt()
    {
         if (isset($_POST['submit'])) {
            $month = $this->input->post('month');
            $year = $this->input->post('year');
            $shp_rpt = $this->obj_reports_model->shipment_rpt($month, $year);
            $data['year'] = $this->input->post('year');
            $data['month'] = $this->input->post('month');
            $data['shp'] = $shp_rpt->result_array();
//            print_r($data['shp']);exit;
            $data['main_content'] = $this->load->view('reports/shipment_rpt', $data, TRUE);
        }
        $data['page_title'] = 'Report Title';
        $data['main_content'] = $this->load->view('reports/shipment_rpt', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

}
