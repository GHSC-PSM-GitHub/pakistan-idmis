<?php

class Assign_resources extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('role_resources');
        $this->load->model('role_model');
        $this->load->model('Stakeholder');
        $this->load->model('itminfo_tab_model');
        $this->load->model('reports_model');
        $this->obj=new Role_resources();
        $this->obj_itminfo =new Itminfo_tab_model();
        $this->obj_role =new Role_model();
        $this->obj_stakeholder =new Stakeholder();
        $this->obj_reports_model= new Reports_model();
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = "Role";
        $data['main_content'] = $this->load->view('assign_resources/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $data = array();
//        if (isset($_POST) && !empty($_POST)) {
//            if(isset($_POST['id'])){
//                $this->obj->pk_id = $_POST['id'];
//            }
//             
//            $this->obj->role_name = $_POST['role_name'];
//            $this->obj->status = 1;
//            $this->obj->save(); 
//            redirect(base_url() . 'assign_resources/index', 'refresh');
//        }
        
        
        if (isset($_POST) && !empty($_POST)) {
            
            if(isset($_POST['id'])){
                $this->obj->pk_id = $_POST['id'];
            }
            
            $stkid = $_REQUEST['stkid'];
            
            //if Assign Resources to Stakeholder exist then delete from database before insert
            
            $stkidyid = $this->obj->getstkid($stkid); 
            if ($stkidyid) {
                        $stkidyid_arr = $stkidyid->result_array();
                    foreach ($stkidyid_arr as $row) {
                            $stkidyids = $row['stk_id'];
                        }
            }
            if($stkid == $stkidyids)
            {
                $this->obj->deletestkidy($stkid); 
            }
            
            $stkids = $_REQUEST['stkid'];
            $productlist = $_REQUEST['products'];
            $count = count($stkids);
            foreach ($productlist as $index => $detail_id) {
                //Stock Received
    //            $this->obj_gwis_detail->StockReceived($detail_id);
                //Get Batch Detail
//                $stkid = $_REQUEST['stkid'];
                
//                $this->obj->role_id = $_POST['role'];
                $this->obj->stk_id = $_POST['stkid'];
                $this->obj->product_id = $productlist[$index];
                $this->obj->status = 1;
                $this->obj->save(); 
            }
//        exit;
            redirect(base_url() . 'assign_resources/add', 'refresh');
        }
        
        $product_arr = $this->obj_itminfo->find_all_productsinfo();
        if ($product_arr)
            $data['product'] = $product_arr->result_array();
        
        $role_arr = $this->obj_role->find_active();
        if ($role_arr)
            $data['roles'] = $role_arr->result_array();
        
        $stakeholder_arr = $this->obj_reports_model->get_stakeholder();
//        $stakeholder_arr = $this->obj_stakeholder->get_all_stk();
        if ($stakeholder_arr)
            $data['stakeholder'] = $stakeholder_arr->result_array();
//        exit;
        $data['page_title'] = "Stakeholder";
        $data['main_content'] = $this->load->view('assign_resources/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $data = array(); 
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('assign_resources/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'assign_resources/index', 'refresh');
    }

}
