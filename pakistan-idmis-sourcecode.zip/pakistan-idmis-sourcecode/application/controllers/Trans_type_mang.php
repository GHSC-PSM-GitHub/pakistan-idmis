<?php

class Trans_type_mang extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('Trans_type');
        $this->obj=new Trans_type();
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_all();
        $data['page_title'] = "Transaction Type";
        $data['main_content'] = $this->load->view('trans_type_mang/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            if(isset($_POST['id'])){
                $this->obj->trans_id = $_POST['id'];
            }
             
            $this->obj->trans_type = $_POST['trans_type'];
            $this->obj->trans_nature = $_POST['trans_nature'];
            $this->obj->is_adjustment = '1';
            $this->obj->save(); 
            redirect(base_url() . 'trans_type_mang/index', 'refresh');
        }
//        exit;
        $data['page_title'] = "Transaction Type";
        $data['main_content'] = $this->load->view('trans_type_mang/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $data = array(); 
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        $data['main_content'] = $this->load->view('trans_type_mang/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'trans_type_mang/index', 'refresh');
    }

}
