<?php

class approver_configuration extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('approver_configuration_model');
        $this->load->model('lists');
        $this->obj = new Approver_configuration_model();
        $this->obj_lists = new Lists();
    }

    public function index() { 
        $data = array();
        $data['result'] = $this->obj->find_active();
        $data['page_title'] = "Approver Code";
        $data['main_content'] = $this->load->view('approver_configuration/index', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add() {
        
        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            if(isset($_POST['id'])){
                $this->obj->pk_id = $_POST['id'];
            }
             
            $this->obj->approval_code = $_POST['approver_configuration'];
            $this->obj->document_id = $_POST['document'];
            $this->obj->approver_designation = $_POST['approver_designation'];
            $this->obj->level = $_POST['level'];
            $this->obj->final = $_POST['final'];
            
            $qry_getprocess_status = $this->obj->getprocess_statusmax();
            if($qry_getprocess_status)
            {
                $dataprocessstatus = $qry_getprocess_status->result_array();
            }
            foreach ($dataprocessstatus AS $row)
            {
                $process_status = $row['process_status'];  
            }
            $this->obj->process_status = $process_status+1;
            
            if(isset($_POST['document']))
            {
                if($_POST['document'] == '65')
                {
                    $this->obj->processid = '1';
                }
                if($_POST['document'] == '66')
                {
                    $this->obj->processid = '2';
                }
                if($_POST['document'] == '67')
                {
                    $this->obj->processid = '3';
                }
                if($_POST['document'] == '68')
                {
                    $this->obj->processid = '4';
                }
            }
            $this->obj->is_active = 1;
            $this->obj->save(); 
            redirect(base_url() . 'approver_configuration/index', 'refresh');
        }
        
        $document_arr = $this->obj_lists->get_list(9);
            $data['document'] = $document_arr->result_array();
           
        $approver_designation_arr = $this->obj_lists->get_list(10);
            $data['approver_designation'] = $approver_designation_arr->result_array();
            
        $level_arr = $this->obj_lists->get_list(11);
            $data['level'] = $level_arr->result_array();
            
        $final_arr = $this->obj_lists->get_list(12);
            $data['final'] = $final_arr->result_array();
//        exit;
        $data['page_title'] = "Challan Type";
        $data['main_content'] = $this->load->view('approver_configuration/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function edit() { 
        $data = array(); 
        $data['result_edit'] = $this->obj->find_by_id($_REQUEST['id']);
        
        $document_arr = $this->obj_lists->get_list(9);
            $data['document'] = $document_arr->result_array();
           
        $approver_designation_arr = $this->obj_lists->get_list(10);
            $data['approver_designation'] = $approver_designation_arr->result_array();
            
        $level_arr = $this->obj_lists->get_list(11);
            $data['level'] = $level_arr->result_array();
            
        $final_arr = $this->obj_lists->get_list(12);
            $data['final'] = $final_arr->result_array();
        
        $data['main_content'] = $this->load->view('approver_configuration/add', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function deactivate() { 
        $id = $_REQUEST['id'];
        $status = $_REQUEST['status'];
        $this->obj->deactivate($id, $status);
        redirect(base_url() . 'approver_configuration/index', 'refresh');
    }

}
