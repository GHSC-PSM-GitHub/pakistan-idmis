<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Dataentry2_model extends Base_model {

    function get_districtstore() {
        $qry = "SELECT * FROM(SELECT
								wh_user.sysusrrec_id,
								users.username,
								tbl_warehouse.wh_id,
								tbl_warehouse.wh_name,
								users.login_id,
								stakeholder.lvl
							FROM
								users
							INNER JOIN wh_user ON wh_user.sysusrrec_id = users.pk_id
							INNER JOIN tbl_warehouse ON wh_user.wh_id = tbl_warehouse.wh_id
							INNER JOIN stakeholder ON stakeholder.stkid = tbl_warehouse.stkofficeid
							WHERE
								wh_user.sysusrrec_id = " . $_SESSION['id'] . "
							AND stakeholder.lvl <= 4
                                                        AND tbl_warehouse.wh_id NOT IN (97677,97798,97990)
						) A
					GROUP BY
						A.wh_id
					ORDER BY
						A.lvl ASC,
						A.wh_name ASC";
        $query = $this->db->query($qry);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
    function check_month($wh_id, $rdate){
        //select query
		$query = "SELECT pk_id FROM tbl_hf_data WHERE warehouse_id=" . $wh_id. " AND reporting_date = '".$rdate."' LIMIT 1";
		//print_r($query);
		//query result
		$rs = $this->query($query);
                if(!empty($rs)){
			return true;
		} else {
			return false;
		}
    }

    function get_hfstore() {
        $qry = "SELECT
	* 
FROM
	(
	SELECT
		wh_user.sysusrrec_id,
		users.username,
		tbl_warehouse.wh_id,
		tbl_warehouse.wh_name,
		users.login_id,
		stakeholder.lvl,
		tbl_warehouse.wh_rank 
	FROM
		users
		INNER JOIN wh_user ON wh_user.sysusrrec_id = users.pk_id
		INNER JOIN tbl_warehouse ON wh_user.wh_id = tbl_warehouse.wh_id
		INNER JOIN stakeholder ON stakeholder.stkid = tbl_warehouse.stkofficeid
	WHERE
		wh_user.sysusrrec_id = " . $_SESSION['id'] . "
		AND stakeholder.lvl >= 4 
		AND tbl_warehouse.is_active = 1 
	) A 
GROUP BY
	A.wh_id ";
        $query = $this->db->query($qry);
//                 echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function GetLast3MonthsHF($wh_ids) {
        $qry = "SELECT DATE_FORMAT(reporting_date,'%Y-%m-%d') as MaxDate, warehouse_id FROM tbl_hf_data WHERE warehouse_id=$wh_ids GROUP BY MaxDate ORDER BY MaxDate DESC LIMIT 3";
        $query = $this->db->query($qry);
//                 echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function delete_existing($wh_id,$rdate) {
        $this->db->delete('tbl_hf_data', array('warehouse_id'=>$wh_id, 'reporting_date'=>$rdate));
    }
    
    function insert($formarray) {         
//                 echo $this->db->last_query(); exit;
        $this->db->insert('tbl_hf_data', $formarray);
//         echo $this->db->last_query(); exit;
    }

    function insert_dist_store_data($formarray) {
        $this->db->insert('tbl_wh_data', $formarray);
//         echo $this->db->last_query(); exit;
    }

    function get_products() {
        $this->db->select('itminfo_tab.itm_name,stakeholder_item.stk_id,itminfo_tab.method_type,itminfo_tab.itm_id,itminfo_tab.itmrec_id');
        $this->db->from('stakeholder_item');
        $this->db->join('itminfo_tab', 'product_id = itminfo_tab.itm_id', 'INNER');
        $this->db->where('stk_id', 1610);
        $query = $this->db->get();
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function getReportingStartMonth($wh_id) {
        //select query
        //gets
        //reporting start month
        $qry = "SELECT
					ADDDATE(tbl_warehouse.reporting_start_month,INTERVAL -1 MONTH) AS reporting_start_month
				FROM
					tbl_warehouse
				WHERE
					tbl_warehouse.wh_id = " . $wh_id;
        $query = $this->query($qry);
              // echo $this->db->last_query(); exit;
        //query result
        $firstMonth = $query->result_array();
        
//        print_r($firstMonth);exit;
        if (!empty($firstMonth[0]['reporting_start_month'])) {
            $NewDate = $firstMonth[0]['reporting_start_month'];
        }
        return $NewDate;
    }
    
    
    function getwarehouseinfo($wh_id)
    {
        $qry = "SELECT
				tbl_warehouse.stkid,
				tbl_warehouse.prov_id,
				tbl_warehouse.is_lock_data_entry,
                                tbl_warehouse.editable_data_entry_months,
                                tbl_warehouse.ecr_start_month,
				CONCAT(DATE_FORMAT(MAX(tbl_hf_data.last_update),'%d/%m/%Y'),' ',TIME_FORMAT(MAX(tbl_hf_data.last_update),'%r')) AS last_update
			FROM
				tbl_warehouse
			LEFT JOIN tbl_hf_data ON tbl_warehouse.wh_id = tbl_hf_data.warehouse_id
			WHERE
				tbl_warehouse.wh_id = $wh_id
			ORDER BY
				tbl_hf_data.pk_id DESC
			LIMIT 1";
            //echo $qry;exit;
             $query = $this->query($qry);
             
             return $query->result_array();
    }

    function get_reporting_data($wh_id, $date){
        $qry = "SELECT
				tbl_hf_data.opening_balance,
				tbl_hf_data.received_balance,
				tbl_hf_data.issue_balance,
                                tbl_hf_data.adjustment_positive,
                                tbl_hf_data.adjustment_negative,
                                tbl_hf_data.closing_balance,
                                tbl_hf_data.item_id
                                
				FROM
				tbl_hf_data
			WHERE
				tbl_hf_data.warehouse_id =  ". $wh_id ."
                                AND tbl_hf_data.reporting_date =  '". $date ."'";
		//query result
        
		$qryRes = $this->query($qry);
                $arr = array();
                if(isset($qryRes) && !empty($qryRes)){
                    $qryRes = $qryRes->result_array();
                
                foreach($qryRes as $row){
                    $arr[$row['item_id']] = $row;
                }
                }
		
                
                return $arr;
    }
    
	function get_last_update()
	{
		$qry = "SELECT
				tbl_warehouse.stkid,
				tbl_warehouse.prov_id,
				tbl_warehouse.is_lock_data_entry,
				CONCAT(DATE_FORMAT(MAX(tbl_wh_data.last_update),'%d/%m/%Y'),' ',TIME_FORMAT(MAX(tbl_wh_data.last_update),'%r')) AS last_update
			FROM
				tbl_warehouse
			LEFT JOIN tbl_wh_data ON tbl_warehouse.wh_id = tbl_wh_data.wh_id
			WHERE
				tbl_warehouse.wh_id =  ". $_SESSION['warehouse_id'] ."
			ORDER BY
				tbl_wh_data.w_id DESC
			LIMIT 1";
		//query result
		$qryRes = $this->query($qry);
		$qryRes = $qryRes->result_array();
//		print_r($qryRes);exit();
		$mainStk = $qryRes[0]['stkid'];
		$lastUpdate = (!empty($qryRes[0]['last_update'])) ? $qryRes[0]['last_update'] : 'Not yet reported';

//		if ($qryRes[0]['prov_id'] == 2 && $mainStk == 1 && !isset($_SESSION['enable_entry'])) {
//			if ($qryRes[0]['is_lock_data_entry'] == 1 && $_SERVER['SERVER_NAME'] == 'localhost') {
				$temp = '<span class="help-block">Last Update: ' . $lastUpdate . '</span>';
//				echo '<span class="help-block" style="color:#E04545">Data entry date for this facility has passed. Please contact administrator to enter data.</span>';
				return $temp;
//			}
//		}
	}

	public function getlast3months($wh_id){
		$LastReportDate = $this->GetLastReportDate();
		$data = array();
		if ($LastReportDate != "") {
			$LRD_dt = new DateTime($LastReportDate);
			//Get Pending Report Month
			$NewReportDate = $this->GetPendingReportMonth();

			if ($NewReportDate != "") {
				$NRD_dt = new DateTime($NewReportDate);
				$data['last_update'] = '<span class="help-block">Last Update: ' . $this->get_last_update() . '</span>';
				//$do = urlencode("Z" . ($_SESSION['warehouse_id'] + 77000) . '|' . $NRD_dt->format('Y-m-') . '01|1');
                                $do = "wh_id=".$wh_id."&date=".$NRD_dt->format('Y-m-') . '01';

				// Show last three months for which date is entered
				$allMonths = '';
				//Get Last 3 Months
				$last3Months = $this->getlast3months_helper();
				for ($i = 0; $i < sizeof($last3Months); $i++) {
					$L3M_dt = new DateTime($last3Months[$i]['MaxDate']);
					$draftYear = $L3M_dt->format('Y');
					$draftMonth = $L3M_dt->format('m');
					//check draft
					$draft = $this->checkDraft($draftMonth, $draftYear, $_SESSION['warehouse_id']);
					$do3Months = urlencode("Z" . ($_SESSION['warehouse_id'] + 77000) . '|' . $L3M_dt->format('Y-m-') . '01|0');

					$date_temp = $L3M_dt->format('Y-m-') . '01';
					if ((!isset($_REQUEST['request_from']) || $_REQUEST['request_from'] != 'admin') && !empty($_SESSION['is_allowed_im']) && $_SESSION['is_allowed_im'] == '1' && $date_temp >= $_SESSION['im_start_month']) {
						//dont show months after enabling of IM module
						$allMonths[] = '<span class="help-block">IM is enabled at this warehouse , from ' . date('M-Y', strtotime($_SESSION['im_start_month'])) . '. Therefore data entry screen will be locked from ' . date('M-Y', strtotime($_SESSION['im_start_month'])) . ' and onwards. </span>';
					} else {
						$url = base_url()."add_cons?Do=" . $do3Months;
//                                                echo $url;exit;
						$data['do3months'] = $do3Months;
						$allMonths = "<a href=\"$url;\" onclick=\"openPopUp('$url')\" class=\"btn btn-xs red\">" . $L3M_dt->format('M-Y') . "$draft" . " <i class=\"fa fa-edit\"></i></a>";
						$data['all_months'] = $allMonths;
					}
				}
				//draft year
				$draftYear = $NRD_dt->format('Y');
				//draft month
				$draftMonth = $NRD_dt->format('m');
				//check draft
				$draft = $this->checkDraft($draftMonth, $draftYear, $_SESSION['warehouse_id']);
				//url
				$url = base_url()."dataentry2/add_cons_hf?" . $do;
				$data['do'] = $do;
//				print_r($do);exit();

				$date_temp2 = $NRD_dt->format('Y-m-') . '01';

					$new_report_month = " <a href=\"$url\" onclick=\"openPopUp('$url')\" class=\"btn btn-xs green\"> Add " . $NRD_dt->format('M-y') . " Report$draft <i class=\"fa fa-plus\"></i></a> ";
					$data['new_report_month'] = $new_report_month;

				$allMonths;
				//flag
				$flag1 = TRUE;
			}
		}
		return $data;
	}

	function GetLastReportDate($wh_id) {
		$d = "2014-12-01";
		//select query
		$query = "SELECT max(reporting_date) as MaxDate FROM tbl_hf_data WHERE warehouse_id=" . $wh_id ;
		//print_r($query);exit();
		//query result
		$rs = $this->query($query);
		$rs = $rs->result();
		if (!empty($rs->MaxDate)) {
			$d = $rs->MaxDate;
		} else if (empty($rs->MaxDate)) {
			//getReportingStartMonth
			$d = $this->getReportingStartMonth($wh_id);
		}
		return $d;
	}

	function GetPendingReportMonth($wh_id) {
		//GetLastReportDate
		$LRM = $this->GetLastReportDate($wh_id);

		$NewDatetemp = $this->add($LRM, 2);
		$NewDate = $NewDatetemp->format('Y-m-d');
		$NewDatetemp2 = date('Y-m-d', strtotime('-1 day', strtotime($NewDatetemp->format('Y-m-d'))));
		$NewMonth_dt = new DateTime($NewDatetemp2);

		$today = date("Y-m-d");
		$today_dt = new DateTime($today);

		if ($NewMonth_dt < $today_dt) {
			return $this->add($LRM, 1)->format('Y-m-d');
		} else {
			return "";
		}
	}

	function add($date_str, $months) {
		$date = new DateTime($date_str);
		$start_day = $date->format('j');

		$date->modify("+{$months} month");
		$end_day = $date->format('j');

		if ($start_day != $end_day) {
			$date->modify('last day of last month');
		}

		return $date;
	}

	function getlast3months_helper($wh_id) {
		$limit = $this->editableMonths($wh_id);
		$last3Months = array();
		if ($limit > 0) {
                    
			//select query
			$query = "SELECT DATE_FORMAT(reporting_date,'%Y-%m-%d') as MaxDate FROM tbl_hf_data WHERE warehouse_id=" .$wh_id . " GROUP BY MaxDate ORDER BY MaxDate DESC LIMIT " . $limit;
//echo $query;
//query result
			$rs = $this->query($query);
                        if(!empty($rs)){
                            $last3Months = $rs->result_array();
                        } else {
                            $last3Months = array();
                        }
			
//			while ($r = $rs->result_array()) {
//				$last3Months[] = $r->MaxDate;
//			}

		} else {
			//select query
			$query = "SELECT DATE_FORMAT(reporting_date,'%Y-%m-%d') as CurrentDate FROM tbl_hf_data WHERE warehouse_id=" .$wh_id  . " GROUP BY CurrentDate ORDER BY CurrentDate DESC LIMIT 1";
			//query result
			$rs = $this->query($query);
			$curr_dates[0] = date("Y-m-01");
			$curr_dates[1] = date('Y-m-01', strtotime($curr_dates[0] . "-1month"));

			$last3Months = $rs->result_array();
//			while ($r = $rs->result()) {
//				if (in_array($r->CurrentDate, $curr_dates)) {
//					$last3Months[] = $r->CurrentDate;
//				}
//			}
		}
		return $last3Months;
	}

	function editableMonths($wh_id) {
		//select query
		//gets
		//editable data entry months
		$qry = "SELECT
					tbl_warehouse.editable_data_entry_months
				FROM
					tbl_warehouse
				WHERE
					tbl_warehouse.wh_id = " . $wh_id;
		//query result
		$qryRes = $this->query($qry);
		$qryRes = $qryRes->result_array()[0];
		if (!empty($qryRes['editable_data_entry_months'])) {
			$months = $qryRes['editable_data_entry_months'];
		}

		return (isset($months) ? $months : 1);
	}

	function checkDraft($draftMonth, $draftYear, $wh_Id) {
		// See if this month data exists in drafts
		$qry = "SELECT
				COUNT(tbl_wh_data_draft.w_id) AS num
			FROM
				tbl_wh_data_draft
			WHERE
				tbl_wh_data_draft.report_month = $draftMonth
			AND tbl_wh_data_draft.report_year = $draftYear
			AND tbl_wh_data_draft.wh_id = $wh_Id";
		//query result
		$qryRes = $this->query($qry);
		$qryRes = $qryRes->result_array()[0];
//		print_r($qryRes);exit();
		if ($qryRes['num'] > 0) {
			$draft = ' (Draft)';
		} else {
			$draft = '';
		}
		return $draft;
	}
        
        function get_last_month_ob($wh_id,$PrevMonthDate)
        {
             $qry = "SELECT * FROM tbl_hf_data WHERE `warehouse_id`='" . $wh_id . "' AND reporting_date=('" . $PrevMonthDate . "' - INTERVAL 1 MONTH)";
                    //result
            //echo  $qry;
             //exit;
                    $qryRes = $this->query($qry);
                    if(!empty($qryRes)){
                        return $qryRes->result_array();
                    } else {
                        return array();
                    }
                    
//                    $rsRow2 = mysql_fetch_array($rsTemp3);
        }
        
        function get_this_month_rcv($wh_id, $rdate){
             $qry = "SELECT
	stock_batch.item_id,
	FLOOR(
		ABS(
		IFNULL( SUM( gwis_detail.quantity ), 0 ))) Qty 
FROM
	gwis_master
	INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
	INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id 
WHERE
	gwis_master.wh_id_to = $wh_id 
	AND gwis_master.tran_type_id = 4 
	AND DATE_FORMAT( gwis_master.tran_date, '%Y-%m-01' ) = '$rdate' 
GROUP BY
	stock_batch.item_id";
                    //result
            //echo  $qry;
             //exit;
                    $qryRes = $this->query($qry);
                    if(!empty($qryRes)){
                        return $qryRes->result_array();
                    } else {
                        return array();
                    }
        }
}

?>
