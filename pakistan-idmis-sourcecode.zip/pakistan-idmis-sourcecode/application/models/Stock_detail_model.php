<?php

/**
 * clsStockDetail
 * @package includes/class
 *
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 *
 * @version    2.2
 *
 */
// If it's going to need the database, then it's
// probably smart to require it before we start.
class Stock_detail_model extends Base_model {
    //table name
    protected static $table_name = "stock_detail";
    //db fields
    protected static $db_fields = array('pk_id', 'batch_id', 'stock_master_id', 'quantity', 'temp','next_issuance_date');
    //pk detail id
    public $PkDetailID;
    //fk stock id
    public $stock_master_id;
    //batch id
    public $batch_id; 
    //qty
    public $quantity;
    //temp
    public $temp;  
    public $next_issuance_date;  

    
    public function clonerecord($fk_stock_id,$stock_batch_id,$batch_number,$quantity, $is_rcvd, $clone_row_id){
        
        $qry = "INSERT INTO gwis_detail ( fk_stock_id, batch_id,field1,field3,field4,field5,field6, quantity, is_received, manufacturer, driver_name, driver_contract, invoice, electronic_approval_status,temp,electronic_approval ) SELECT
'$fk_stock_id',
'$stock_batch_id',
    '$batch_number',
        field3,
        field4,
        field5,
        field6,
'$quantity',
'$is_rcvd',
manufacturer,
driver_name,
driver_contract,
invoice ,
'1',
'0',
'1'
FROM
	gwis_detail 
WHERE
	pk_id = '$clone_row_id'";
//        echo $qry; exit;
         $this->query($qry);
        return true;
    }
    
           function update_status($clone_row_id) {
        $qry = "UPDATE gwis_detail SET is_received='1' WHERE pk_id= '$clone_row_id'	 ";
//        echo $qry; exit;
         $query = $this->db->query($qry);
//        echo $this->db->last_query(); exit;
//        return $query->result_array();
    } 
    
           function get_nature($trans_id) {
        $qry = "SELECT
	transaction_types.trans_nature 
FROM
	transaction_types 
WHERE
	transaction_types.trans_id = '$trans_id'";
//        echo $qry; exit;
  $query = $this->db->query($qry);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    } 
    
     public function clonerecord_adjt($fk_stock_id,$stock_batch_id,$batch_number,$nature,$quantity,$adjt_type, $is_rcvd, $clone_row_id){
        
        $qry = "INSERT INTO gwis_detail ( fk_stock_id, batch_id,field1, quantity, is_received,adjustment_type, manufacturer, driver_name, driver_contract, invoice,field3,field4,field5,field6,electronic_approval_status,temp,electronic_approval) SELECT
'$fk_stock_id',
'$stock_batch_id',
    '$batch_number',
'$nature$quantity',
'$is_rcvd',
'$adjt_type',
manufacturer,
driver_name,
driver_contract,
invoice ,field3,field4,field5,field6,'1','0','1'
FROM
	gwis_detail 
WHERE
	pk_id = '$clone_row_id'";
//        echo $qry; exit;
         $this->query($qry);
        return true;
    }
    
    // Common Database Methods
    /**
     * find_all
     * @return type
     */
    public static
            function find_all() {
        return static::find_by_sql("SELECT * FROM " . static::$table_name);
    }

    /**
     * find_by_id
     * @param type $id
     * @return type
     */
    public static
            function find_by_id($id = 0) {
        $result_array = static::find_by_sql("SELECT * FROM " . static::$table_name . " WHERE pk_id={$id} LIMIT 1");
        return !empty($result_array) ? array_shift($result_array) : false;
    }
   
     
    /**
     * find_by_sql
     * @param type $sql
     * @return type
     */
    public static
            function find_by_sql($sql = "") {
        $result_set = mysql_query($sql);
        $object_array = array();
        while ($row = mysql_fetch_array($result_set)) {
            $object_array[] = static::instantiate($row);
        }
        return $object_array;
    }

    /**
     * count_all
     * @global type $database
     * @return type
     */
    public static
            function count_all() { 
        $sql = "SELECT COUNT(*) FROM " . static::$table_name;
        //query result
        $result_set = $this->query($sql);
        $row = $this->fetch_array($result_set);
        return array_shift($row);
    }

    /**
     * instantiate
     * @param type $record
     * @return \self
     */
    private static
            function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * has_attribute
     * @param type $attribute
     * @return type
     */
    private
            function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * attributes
     * @return type
     */
    protected
            function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if (!empty($this->$field) || $this->$field == 0) {
                    $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * sanitized_attributes
     * @global type $database
     * @return type
     */
    protected
            function sanitized_attributes() { 
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * save
     * @return type
     */
    public
            function save() {
        // A new record won't have an id yet.
        //echo isset($this->PkDetailID) ? 'UPD.' :'Ins.';
        return isset($this->PkDetailID) ? $this->update() : $this->create();
    }

    /**
     * create
     * @global type $database
     * @return boolean
     */
    public
            function create() { 
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
//        print_r($sql);exit;


        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    /**
     * update
     * @global type $database
     * @return type
     */
    public
            function update() { 
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
//        print_r($sql);exit;
        $this->query($sql);
        return ($this->affected_rows() == 1) ? true : false;
    }
    /**
     * delete
     * @global type $database
     * @return type
     */
    public
            function delete() { 
        // Don't forget your SQL syntax and good habits:
        // - DELETE FROM table WHERE condition LIMIT 1
        // - escape all values to prevent SQL injection
        // - use LIMIT 1
        $sql = "DELETE FROM " . static::$table_name;
        $sql .= " WHERE pk_id=" . $this->escape_value($this->PkDetailID);
        $sql .= " LIMIT 1";
        $this->query($sql);
        return ($this->affected_rows() == 1) ? true : false;

        // NB: After deleting, the instance of User still
        // exists, even though the database entry does not.
        // This can be useful, as in:
        // but, for example, we can't call $user->update()
        // after calling $user->delete().
    } 
    function get_temp_records($stock_master_id){
        $qry="SELECT
                stock_batch.batch_number,
                stock_batch.batch_expiry,
                ABS(stock_detail.quantity) as quantity,
                product.product_name,
                product.manufacturer,
                stock_detail.pk_id,
                stock_detail.stock_master_id,
                tbl_warehouse.warehouse_name,
                patients.full_name,
                patients.nic_no,
                stock_master.issuance_to,
                transaction_types.trans_type,
                ww.warehouse_name AS wh_from,
                stock_master.warehouse_to
            FROM
            stock_detail
            INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
            INNER JOIN product ON stock_batch.item_id = product.pk_id
            LEFT JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
            LEFT JOIN tbl_warehouse ON stock_master.warehouse_to = tbl_warehouse.pk_id
            LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
            LEFT JOIN transaction_types ON stock_master.transaction_type_id = transaction_types.trans_id
            LEFT JOIN tbl_warehouse AS ww ON stock_master.warehouse_from = ww.pk_id
            WHERE 
            stock_detail.stock_master_id= $stock_master_id
                AND stock_detail.temp=1
        ";
//        print_r($qry);
         return $this->query($qry);
    }
    function save_details_temp($stock_master_id){
        $qry="UPDATE stock_detail set temp=0 where stock_master_id=$stock_master_id";
        $this->query($qry);
        return true;
    }
    function find_by_master_id($stock_master_id)
    {
        $qry="select * from stock_detail where stock_master_id=$stock_master_id";
//        print_r($qry);exit;
        return $this->query($qry);
    }
}

?>