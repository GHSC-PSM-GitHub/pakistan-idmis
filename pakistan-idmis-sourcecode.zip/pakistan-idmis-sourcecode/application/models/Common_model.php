<?php
class Common_model extends CI_model{
	
	public function getDataByAbbreviation($abbreviation){
		$this->db->select('stakeholder.abbreviation, stakeholder.stkname, users.designation, stakeholder.report_logo, stakeholder.login_background');
		$this->db->from('stakeholder');
		$this->db->join('users', 'users.stakeholder_id = stakeholder.stkid');
		$this->db->where('stakeholder.abbreviation', $abbreviation);
		$this->db->where('stakeholder.is_reporting', 1);
		$data = $this->db->get();
		return $data->result_array();
	}// end getDataByAbbreviation function

	public function login($username, $password){
		$this->db->select('stakeholder.*, users.designation');
		$this->db->from('stakeholder');
		$this->db->join('users', 'users.stakeholder_id = stakeholder.stkid');
		$this->db->where('users.username', $username);
		$this->db->where('users.password', $password);
		$this->db->where('users.is_active', 1);
		$data = $this->db->get();
		// echo $this->db->last_query();die;
		return $data->result_array();
	}// end login function
}// end Common_model class
?>