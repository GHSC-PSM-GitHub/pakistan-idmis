<?php

class Reports_model extends Base_model {

    private $conn;

    public function fetch_soh() {

        $qry = "SELECT
                        stock_batch.batch_id,
                        stock_batch.batch_no,
                        stock_batch.batch_expiry,
                        stock_batch.item_id,
                        stock_batch.Qty,
                        tbl_warehouse.wh_name,
                        itminfo_tab.itm_id,
                        itminfo_tab.itm_name
                FROM
                        stock_batch
                INNER JOIN tbl_warehouse ON stock_batch.wh_id = tbl_warehouse.wh_id
                INNER JOIN itminfo_tab ON itminfo_tab.itm_id = stock_batch.item_id
                ";
        if ($this->session->userdata('id') != 1) {
            $qry .= "  WHERE
                stock_batch.wh_id = " . $this->session->userdata('warehouse_id') . " ";
        }
        $qry .= "
            WHERE itminfo_tab.itm_id = 2323
               ORDER BY
                        itminfo_tab.itm_name ASC,
                        stock_batch.batch_no ASC
        ";
//        print_r($qry);exit;
        $result = $this->query($qry);

        if (!empty($result))
            return $result->result_array();
    }

    public function get_product_batch_id_info($info, $prod) {
        $qry = "SELECT
                        * 
                FROM
                        stock_batch WHERE batch_no = '$info' AND item_id='$prod'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function get_stakeholder($stock_type = '') {

        $stklimit = '';
        $join = '';
        $stkidarray = array();
        $stkid = $this->get_user_stakeholders();

         if($stock_type == 'stock_issue'){
             if ($_SESSION['id'] == '1' || $_SESSION['role'] == '8') {
                    $stklimit = '';
                    $join = '';
                } else {
                   $stklimit = "AND stakeholder.stkid IN (SELECT DISTINCT
                            stakeholder_item.stk_id
                            FROM
                                itminfo_tab as itminfo_tab
                                INNER JOIN stakeholder_item ON stakeholder_item.product_id = itminfo_tab.itm_id
                                INNER JOIN stock_batch ON stock_batch.item_id = itminfo_tab.itm_id 
                            WHERE
                                stock_batch.wh_id = '".$_SESSION['warehouse_id']."' 
                                AND stock_batch.STATUS = 'Running' 
                                AND stock_batch.Qty > 0 )";
                 }
                 $qry =  "SELECT DISTINCT
                            stakeholder.stkid,
                            stakeholder.stkname,
                            stakeholder.stkorder
                    FROM
                    stakeholder
                    WHERE
                            stakeholder.ParentID IS NULL
                    AND stakeholder.stk_type_id IN (0)
                    $stklimit
                    ORDER BY
                            stakeholder.stkorder ASC
                    ";

         }else{
              //  echo $stkid;exit;
             /*  for ($i = 0; $i < $_SESSION['count']; $i++) {
                  array_push($stkidarray, "'" . $_SESSION['stakeholder_id_'.$i]. "'");
               }*/
               //$stkid = implode(', ', $stkidarray);
             if ($_SESSION['id'] == '1' || $_SESSION['role'] == '8') {
                    $stklimit = '';
                    $join = '';
                } else {
                    $stklimit = "AND stakeholder_item.stk_id IN (" . $stkid . ")";
                    $join = "INNER JOIN stakeholder_item ON stakeholder_item.stk_id = stakeholder.stkid";
                }
                $qry = "SELECT DISTINCT
                stakeholder.stkid,
                stakeholder.stkname,
                stakeholder.stkorder
                FROM
                        stakeholder
                $join
                WHERE
                        stakeholder.ParentID IS NULL
                AND stakeholder.stk_type_id IN (0)
                $stklimit
                ORDER BY
                        stakeholder.stkorder ASC
                ";
        }

        //print_r($qry);exit;
        return $this->query($qry);
    }

    public function get_province() {

        $provlimit = '';
//        if($_SESSION['id'] == '1')
//        {
//            $provlimit = '';
//        }
//        else{
//            $provlimit = "AND tbl_locations.PkLocID IN (".$_SESSION['province_id'].")";
//        }


        $qry = "SELECT
                        tbl_locations.PkLocID,
                        tbl_locations.LocName
                FROM
                        tbl_locations
                WHERE
                        tbl_locations.LocLvl = 2
                        $provlimit
                AND tbl_locations.ParentID IS NOT NULL";
//        print_r($qry);exit;
        return $this->query($qry);
    }

    function GetStockLedger($startdate, $enddate, $product, $batch, $sourcetype, $process_status_nmbr_s3, $process_status_nmbr_s4) {
        $whId = $_SESSION['warehouse_id'];

        $fs = '';
        $createdby = '';
        $productid = '';
        $groupby = '';
        $batchinfo = '';
        $sumqty = '';

//        if($_SESSION['id'] == '1')
//        {
//            $createdby = '';
//        }
//        else{
//            $createdby = " AND s1_.created_by = '".$_SESSION['id']."'";
//        }

        if (!empty($sourcetype) && $sourcetype != 'all') {
            $fs = " AND s3_.funding_source = $sourcetype ";
        }

        if (!empty($product)) {
            $productid = " AND s3_.item_id = '$product'";
        }

        if (!empty($batch)) {
//            $batchinfo = " AND s3_.batch_no = '$batch'";
            $sumqty = 's0_.quantity AS quantity,';
//            $groupby = "GROUP BY
//                            s3_.batch_no";
        } else {
            $sumqty = 's0_.quantity AS quantity,';
//            $sumqty = 'SUM(s0_.quantity) AS quantity,';
//            $groupby = "GROUP BY
//                            s3_.batch_id";
        }

        $wh_id = $_SESSION['warehouse_id'];

//select query
        $strSql = "SELECT
                s0_.pk_id AS detail_id,
                $sumqty
                s0_.is_received AS is_received,
                s0_.adjustment_type AS adjustment_type,
                s0_.fk_stock_id AS stock_master_id,
                s0_.batch_id AS stock_batch_warehouse_id,
                s0_.fk_unit_id AS item_unit_id,
                s1_.created_on,
                users.username AS created_by,
                s1_.tran_date,
                s1_.tran_no,
                s1_.tran_ref,
                s1_.status_id,
                `from`.wh_name fromWh,
                `to`.wh_name toWh,
                s3_.batch_no,
                s3_.batch_id,
                s3_.batch_expiry,
                s3_.funding_source,
                '' AS funding_source_name,
                transaction_types.trans_nature,
                transaction_types.trans_type,
                stakeholder.stkname AS received_from_fs,
                product_strength.strength 
        FROM
                gwis_detail AS s0_
        INNER JOIN gwis_master AS s1_ ON s0_.fk_stock_id = s1_.pk_id
        INNER JOIN stock_batch AS s3_ ON s0_.batch_id = s3_.batch_id
        LEFT JOIN tbl_warehouse AS `from` ON s1_.wh_id_from = `from`.wh_id
        LEFT JOIN tbl_warehouse AS `to` ON s1_.wh_id_to = `to`.wh_id
        /*LEFT JOIN tbl_warehouse AS fs ON s3_.funding_source = fs.stkid*/
        LEFT JOIN transaction_types ON s1_.tran_type_id = transaction_types.trans_id
        LEFT JOIN stakeholder ON s1_.source_type = stakeholder.stkid 
        LEFT JOIN users ON s1_.created_by = users.pk_id
        LEFT JOIN itminfo_tab ON itminfo_tab.itm_id = s3_.item_id
	LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
        WHERE
                
         (
                DATE_FORMAT(s1_.tran_date, '%Y-%m-%d') BETWEEN '" . $startdate . "' AND '" . $enddate . "'
        )
        AND s1_.process_status IN ($process_status_nmbr_s3,$process_status_nmbr_s4,99)
	AND s3_.wh_id = $wh_id
        $fs
        $productid
        $batchinfo
        $createdby
        $groupby
        ORDER BY
        DATE_FORMAT( s1_.tran_date, '%Y-%m-%d' ) ASC,
        s1_.pk_id ASC,
	adjustment_type ASC,
	quantity ASC";
//        echo print_r($strSql);exit;
//        echo $strSql;exit;
//query result
        $result = $this->query($strSql);

        if (!empty($result))
            return $result->result_array();
    }

    public function getBatchOBCB($type, $item, $trDate, $batch, $funding_source = '', $process_status_nmbr_s3, $process_status_nmbr_s4) {
        $wh_id = $_SESSION['warehouse_id'];
        $groupby = '';
        $batchinfo = '';
        $fs = '';
        $sumqty = '';

        if (!empty($funding_source) && $funding_source != '' && $funding_source != 'all') {
            $fs = " AND s1_.funding_source = $funding_source ";
        }

//        $operator = '<';

        if ($type == 'CB') {
            $operator = '<='; //todate
        } else {
            $operator = '<'; //fromdate
        }

        if (!empty($batch)) {
            $sumqty = "s0_.quantity AS Qty,";
//            $batchinfo = " AND s1_.batch_no = '$batch'";
//            $groupby = "GROUP BY
//                            s1_.batch_id";
        } else {
            $sumqty = "SUM(s0_.quantity) AS Qty,";
            $groupby = "GROUP BY
                            s1_.batch_id ";
        }

        $wh_id = $_SESSION['warehouse_id'];

        $strSql = "SELECT
                        $sumqty
                        s1_.batch_no,
                        s1_.batch_id,
                        tbl_warehouse.wh_name as funding_source_name

                    FROM
                        gwis_detail s0_
                    INNER JOIN gwis_master s3_ ON s0_.fk_stock_id = s3_.pk_id
                    INNER JOIN stock_batch s1_ ON s0_.batch_id = s1_.batch_id
                    INNER JOIN itminfo_tab i2_ ON s1_.item_id = i2_.itm_id
                    LEFT JOIN tbl_warehouse ON s1_.funding_source = tbl_warehouse.wh_id
                    WHERE
                        i2_.itm_id = '$item'
                
                        AND DATE(s3_.tran_date) $operator '" . $trDate . "'
                        AND s3_.process_status IN ($process_status_nmbr_s3,$process_status_nmbr_s4,99)
			AND s1_.wh_id = $wh_id
                        $fs
                        $batchinfo
                    $groupby
                    HAVING
                        Qty <> 0";
//        echo $strSql;exit;
//query result
        $result = $this->query($strSql);

        if (!empty($result))
            return $result->result_array();
    }

    public function GetProduct($product) {

        $strSql = "SELECT
                        itminfo_tab.itm_name,
                        product_strength.strength
                 FROM
                      itminfo_tab 
                    LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                 WHERE
                         itminfo_tab.itm_id = '$product'";
//        echo $strSql;exit;
//query result
        $result = $this->query($strSql);

        if (!empty($result))
            return $result->result_array();
    }

    public function fetch_batch_history($batch_id) {

        $qry = "SELECT
                stock_batch.batch_id,
                stock_batch.batch_number,
                stock_batch.batch_expiry,
                stock_batch.item_id,
                stock_batch.quantity as soh,
                product.product_name,
                product_generic_name.generic_name,
                tbl_warehouse.warehouse_name,
                stock_detail.quantity,
                stock_master.pk_id,
                stock_master.transaction_date,
                stock_master.transaction_type_id,
                stock_master.transaction_reference,
                stock_master.warehouse_from,
                stock_master.warehouse_to,
                stock_master.issuance_to,
                transaction_types.trans_type,
                transaction_types.trans_nature,
                w_from.warehouse_name AS wname_from,
                w_to.warehouse_name AS wname_to,
                patients.full_name as patient_name,
                patients.nic_no
                FROM
                stock_batch
                INNER JOIN product ON stock_batch.item_id = product.pk_id
                LEFT JOIN product_generic_name ON product.generic_name_id = product_generic_name.pk_id
                LEFT JOIN tbl_warehouse ON stock_batch.wh_id = tbl_warehouse.pk_id
                INNER JOIN stock_detail ON stock_batch.batch_id = stock_detail.batch_id
                INNER JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
                INNER JOIN transaction_types ON stock_master.transaction_type_id = transaction_types.trans_id
                LEFT JOIN tbl_warehouse AS w_from ON stock_master.warehouse_from = w_from.pk_id
                LEFT JOIN tbl_warehouse AS w_to ON stock_master.warehouse_to = w_to.pk_id
                LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
                WHERE
                stock_batch.batch_id = '" . $batch_id . "'
                ORDER BY
                stock_master.transaction_date asc

        ";
//        print_r($qry);exit;
        $result = $this->query($qry);

        if (!empty($result))
            return $result->result_array();
    }

    public function fetch_transaction_detail($batch_id) {

        $qry = " SELECT
transaction_types.trans_type,
stock_master.pk_id AS trans_no,
stock_master.transaction_date,
stock_master.transaction_reference,
w_from.warehouse_name AS wh_from,
w_to.warehouse_name AS wh_to,
patients.full_name AS patient_name,
users.username,
product.product_name,
stock_batch.batch_number,
stock_batch.batch_expiry,
stock_detail.quantity,
stock_master.remarks,
stock_master.issuance_to,
stock_master.vials_returned,
stock_master.transaction_type_id
FROM
stock_master
INNER JOIN stock_detail ON stock_master.pk_id = stock_detail.stock_master_id
INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
INNER JOIN transaction_types ON stock_master.transaction_type_id = transaction_types.trans_id
INNER JOIN product ON stock_batch.item_id = product.pk_id
LEFT JOIN tbl_warehouse AS w_from ON stock_master.warehouse_from = w_from.pk_id
LEFT JOIN tbl_warehouse AS w_to ON stock_master.warehouse_to = w_to.pk_id  
LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
INNER JOIN users ON stock_master.created_by = users.pk_id
WHERE
stock_master.pk_id =  '" . $batch_id . "' 

        ";
//        print_r($qry);exit;
        $result = $this->query($qry);

        if (!empty($result))
            return $result->result_array();
    }

    public function fetch_issuance() {
        $qry = "SELECT
                stock_master.pk_id,
                stock_master.transaction_date,
                stock_master.transaction_type_id,
                stock_master.transaction_reference,
                product.product_name,
                stock_batch.batch_number,
                stock_detail.quantity,
                stock_master.issuance_to,
                whf.warehouse_name AS wh_from,
                wht.warehouse_name AS wh_to,
                patients.full_name,
                patients.nic_no,
                stock_master.issuance_to
FROM
stock_master
INNER JOIN stock_detail ON stock_master.pk_id = stock_detail.stock_master_id
INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
INNER JOIN product ON stock_batch.item_id = product.pk_id
INNER JOIN tbl_warehouse AS whf ON stock_master.warehouse_from = whf.pk_id
LEFT JOIN tbl_warehouse AS wht ON stock_master.warehouse_to = wht.pk_id
LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
WHERE
stock_master.transaction_type_id = 2    ";
        if ($this->session->userdata('id') != 1) {
            $qry .= "  AND
        stock_master.warehouse_from = " . $this->session->userdata('warehouse_id') . " ";
        }
        $qry .= "
ORDER BY
stock_master.pk_id DESC



        ";
//        print_r($qry);exit;
        $result = $this->query($qry);
        if (!empty($result))
            return $result->result_array();
    }

    public function fetch_issuance_list($params = null) {
        $qry = "SELECT
                stock_master.pk_id,
                stock_master.transaction_date,
                stock_master.transaction_type_id,
                stock_master.transaction_reference, 
                stock_master.created_by, 
                stock_master.created_on, 
                stock_master.issuance_to,
                whf.warehouse_name AS wh_from,
                wht.warehouse_name AS wh_to,
                patients.full_name,
                patients.nic_no,
                stock_master.issuance_to
FROM
stock_master  
INNER JOIN tbl_warehouse AS whf ON stock_master.warehouse_from = whf.pk_id
LEFT JOIN tbl_warehouse AS wht ON stock_master.warehouse_to = wht.pk_id
LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
WHERE
stock_master.transaction_type_id = 2    ";
        if ($this->session->userdata('id') != 1) {
            $qry .= "  AND stock_master.warehouse_from = " . $this->session->userdata('warehouse_id') . " ";
        }

        if (!empty($params['date_from']) && !empty($params['date_to'])) {
            $qry .= "  AND stock_master.transaction_date BETWEEN '" . $params['date_from'] . "' AND  '" . $params['date_to'] . "' ";
        }
        $qry .= "
ORDER BY
stock_master.pk_id DESC



        ";
//        print_r($qry);exit;
        $result = $this->query($qry);
        if (!empty($result))
            return $result->result_array();
    }

    public function fetch_receive() {
        $qry = "SELECT
                stock_master.pk_id,
                stock_master.transaction_date,
                stock_master.transaction_type_id,
                stock_master.transaction_reference,
                product.product_name,
                stock_batch.batch_number,
                stock_detail.quantity,
                stock_master.issuance_to,
                whf.warehouse_name AS wh_from,
                wht.warehouse_name AS wh_to,
                patients.full_name,
                patients.nic_no,
                stock_master.issuance_to
FROM
stock_master
INNER JOIN stock_detail ON stock_master.pk_id = stock_detail.stock_master_id
INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
INNER JOIN product ON stock_batch.item_id = product.pk_id
INNER JOIN tbl_warehouse AS whf ON stock_master.warehouse_from = whf.pk_id
LEFT JOIN tbl_warehouse AS wht ON stock_master.warehouse_to = wht.pk_id
LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
WHERE
stock_master.transaction_type_id = 1    ";
        if ($this->session->userdata('id') != 1) {
            $qry .= "  AND
        stock_master.warehouse_to= " . $this->session->userdata('warehouse_id') . " ";
        }
        $qry .= "
ORDER BY
stock_master.pk_id DESC



        ";
//        print_r($qry);exit;
        $result = $this->query($qry);
        if (!empty($result))
            return $result->result_array();
    }

    public function fetch_receive_list($params = null) {
        $qry = "SELECT
                stock_master.pk_id,
                stock_master.transaction_date,
                stock_master.transaction_type_id,
                stock_master.transaction_reference, 
                stock_master.created_by, 
                stock_master.created_on, 
                stock_master.issuance_to,
                whf.warehouse_name AS wh_from,
                wht.warehouse_name AS wh_to,
                patients.full_name,
                patients.nic_no,
                stock_master.issuance_to
FROM
stock_master  
INNER JOIN tbl_warehouse AS whf ON stock_master.warehouse_from = whf.pk_id
LEFT JOIN tbl_warehouse AS wht ON stock_master.warehouse_to = wht.pk_id
LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
WHERE
stock_master.transaction_type_id = 1    ";
        if ($this->session->userdata('id') != 1) {
            $qry .= "  AND
        stock_master.warehouse_to = " . $this->session->userdata('warehouse_id') . " ";
        }
        if (!empty($params['date_from']) && !empty($params['date_to'])) {
            $qry .= "  AND stock_master.transaction_date BETWEEN '" . $params['date_from'] . "' AND  '" . $params['date_to'] . "' ";
        }
        $qry .= "
ORDER BY
stock_master.pk_id DESC



        ";
//        print_r($qry);exit;
        $result = $this->query($qry);
        if (!empty($result))
            return $result->result_array();
    }

    public function fetch_all_trans() {
        $qry = "SELECT
stock_master.pk_id,
stock_master.transaction_date,
stock_master.transaction_type_id,
stock_master.transaction_reference,
product.product_name,
stock_batch.batch_id,
stock_batch.batch_number,
stock_detail.quantity,
transaction_types.trans_type,
transaction_types.trans_nature,
wfrom.warehouse_name AS wh_from,
wto.warehouse_name AS wh_to,
patients.full_name,
patients.nic_no,
stock_master.issuance_to
FROM
stock_master
INNER JOIN stock_detail ON stock_master.pk_id = stock_detail.stock_master_id
INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
INNER JOIN product ON stock_batch.item_id = product.pk_id
LEFT JOIN transaction_types ON stock_master.transaction_type_id = transaction_types.trans_id
INNER JOIN tbl_warehouse AS wfrom ON stock_master.warehouse_from = wfrom.pk_id
LEFT JOIN tbl_warehouse AS wto ON stock_master.warehouse_to = wto.pk_id
LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
WHERE
    stock_master.warehouse_from =  " . $this->session->userdata('warehouse_id') . " OR 
    stock_master.warehouse_to =  " . $this->session->userdata('warehouse_id') . "
ORDER BY
stock_master.transaction_date DESC



        ";
//        print_r($qry);exit;
        $result = $this->query($qry);
        if (!empty($result))
            return $result->result_array();
    }

//    ****************************************************************************************
//          public function fetch_single_data($id)
//    {
//             $this->db->select('*');
//          $this->db->from('stock_master');
//          $this->db->where("pk_id", $id);
//          $query = $this->db->get();
//	return $query->result_array();    
//    }
//    
// $this->db->join('divisions di','d.iddivision = di.iddivision');

    public function fetch_single_data($id) {
        $this->db->select('stock_master.pk_id,
                stock_master.transaction_date,
                stock_master.transaction_type_id,
                stock_master.transaction_reference, 
                stock_master.issuance_to,
                whf.warehouse_name AS wh_from,
                wht.warehouse_name AS wh_to,
                patients.full_name,
                patients.nic_no,
                stock_master.issuance_to');
        $this->db->from('stock_master');
        $this->db->join("tbl_warehouse AS whf ", "stock_master.warehouse_from = whf.pk_id", "INNER");
        $this->db->join("tbl_warehouse AS wht ", "stock_master.warehouse_to = wht.pk_id", "left");
        $this->db->join("patients ", "stock_master.warehouse_to = patients.pk_id", "left");
        $this->db->where("stock_master.pk_id", $id);
        $query = $this->db->get();
        return $query->result_array();
    }

    function edit_data($data, $id) {
        $this->load->database();
        $this->db->select('*');
        $this->db->from("stock_master");
        $this->db->where("pk_id", $id);
        $query = $this->db->update("stock_master", $data);
//  echo $this->db->last_query(); exit;
        return $query;
    }

    public function fetch_threshold() {

        $qry = "SELECT
                    diseases.disease_name,
                    diseases.is_active,
                    diseases.threshold_district,
                    diseases.threshold_tehsil,
                    diseases.threshold_uc,
                    diseases.threshold_village,
                    COUNT(
                            patient_clinical_notes.patient_id
                    ) AS total_patients
            FROM
                    diseases
            LEFT JOIN patient_clinical_notes ON patient_clinical_notes.disease_name = diseases.pk_id
            GROUP BY
                    patient_clinical_notes.disease_name";
//        if($this->session->userdata('id') != 1){
//        $qry .= "  WHERE
//                stock_batch.wh_id = " . $this->session->userdata('warehouse_id') . " ";
//        }
//        $qry .= "
//               
//                ORDER BY
//                product_generic_name.generic_name ASC,
//                stock_batch.batch_number ASC
//        ";
//        print_r($qry);exit;
        $result = $this->query($qry);

        if (!empty($result))
            return $result->result_array();
    }

    public function getstocksummaryinfo($startdate, $enddate, $stakeholder, $prov, $process_status_nmbr_s3, $process_status_nmbr_s4) {

        $createdby = '';
//        if($_SESSION['id'] == '1')
//        {
//            $createdby = '';
//        }
//        else{
//            $createdby = " AND gwis_master.created_by = '".$_SESSION['id']."'";
//        }

        $stakeholderid = '';
//        $date = '';

        $stklimit = '';
        $join = '';
//        $stkidarray = array();
//        for ($i = 0; $i < $_SESSION['count']; $i++) {
//            array_push($stkidarray, "'" . $_SESSION['stakeholder_id_'.$i]. "'");
//        }
//        $stkid = implode(', ', $stkidarray);
        $stkid = $this->get_user_stakeholders();

        if ($_SESSION['id'] == '1') {
            $stklimit = '';
            $join = '';
        } else {
//New 
            $stklimit = " AND gwis_master.stk_id IN (" . $stkid . ")";
            $createdby = " AND gwis_master.created_by = '".$_SESSION['id']."'";
//Old
//            $stklimit = "AND stakeholder_item.stk_id IN (".$stkid.")";
//            $join = " LEFT JOIN stakeholder ON gwis_master.stk_id = stakeholder.stkid
//                    INNER JOIN stakeholder_item ON stakeholder_item.stk_id = stakeholder.stkid";
        }

        $date = "Date(gwis_master.tran_date) BETWEEN '$startdate' AND '$enddate'";
        if (!empty($stakeholder) && $stakeholder != 'all') {
            $stakeholderid = " AND stakeholder.stkid = '$stakeholder'";
        }

        $qry = "SELECT
                        A.*,
                        B.* 
                FROM
                        (
                        SELECT
                                itminfo_tab.itm_name,
                                itminfo_tab.qty_carton,
                                Sum( gwis_detail.quantity ) AS stock_receive,
                                Sum( stock_batch.Qty ) AS Vials,
                                tbl_itemunits.UnitType,
                                product_category.category,
                                product_strength.strength,
                                product_method_type.method_type,
                                stock_batch.batch_expiry,
                                stock_batch.batch_no,
                                stock_batch.batch_id,
                                stakeholder.stkname AS funding_source,
                                SUM( gwis_detail.actual_rec_qty ) AS actual_rec_qty,
                                itminfo_tab.itm_id,
                                itminfo_tab.unit,
                                stkn.stkname AS stk_name
                        FROM
                                stock_batch
                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
                                LEFT JOIN product_category ON itminfo_tab.itm_category = product_category.pk_id
                                LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
                                LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                                LEFT JOIN stakeholder ON stock_batch.funding_source = stakeholder.stkid
                                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                                LEFT JOIN stakeholder AS stkn ON gwis_master.stk_id = stkn.stkid
                                LEFT JOIN users ON gwis_master.created_by = users.pk_id
                        WHERE
                                $date 
                                AND gwis_master.status_id IN ( 3 )
                                AND gwis_master.process_status = '$process_status_nmbr_s3'
                                $stklimit
                                $createdby
                        GROUP BY
                                itminfo_tab.itm_id 
                        ORDER BY
                                stkn.stkname ASC
                        ) A
                        LEFT JOIN (
                        SELECT
                                SUM(gwis_detail.quantity) AS issue_quantity,
                                itminfo_tab.itm_id 
                        FROM
                                gwis_detail
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType 
                        WHERE
                                gwis_master.status_id IN ( 4 ) 
                                AND gwis_master.process_status = '$process_status_nmbr_s4'
                                $createdby
                        GROUP BY
                        itminfo_tab.itm_id 
                        ) B ON A.itm_id = B.itm_id";

//        print_r($qry);exit;
        $result = $this->query($qry);

        if (!empty($result))
            return $result->result_array();
    }

    public function getstockmovementsummaryinfo($startdate, $enddate, $stakeholder, $prov, $process_status_nmbr_s3, $process_status_nmbr_s4) {

        $createdby = '';
//        if($_SESSION['id'] == '1')
//        {
//            $createdby = '';
//        }
//        else{
//            $createdby = " AND gwis_master.created_by = '".$_SESSION['id']."'";
//        }

        $stakeholderid = '';
//        $date = '';

        $stklimit = '';
        $join = '';
//        $stkidarray = array();
//        for ($i = 0; $i < $_SESSION['count']; $i++) {
//            array_push($stkidarray, "'" . $_SESSION['stakeholder_id_'.$i]. "'");
//        }
//        $stkid = implode(', ', $stkidarray);
        $stkid = $this->get_user_stakeholders();

        if ($_SESSION['id'] == '1') {
            $stklimit = '';
            $join = '';
        } else {
//New 
            $stklimit = " AND gwis_master.stk_id IN (" . $stkid . ")";
//Old
//            $stklimit = "AND stakeholder_item.stk_id IN (".$stkid.")";
//            $join = " LEFT JOIN stakeholder ON gwis_master.stk_id = stakeholder.stkid
//                    INNER JOIN stakeholder_item ON stakeholder_item.stk_id = stakeholder.stkid";
        }

        $date = "Date(gwis_master.tran_date) BETWEEN '$startdate' AND '$enddate'";
        if (!empty($stakeholder) && $stakeholder != 'all') {
            $stakeholderid = " AND stakeholder.stkid = '$stakeholder'";
        }

//        $qry = "SELECT
//                        A.*,
//                        B.*,
//                        C.*,
//                        D.*
//                FROM
//                        (
//                        SELECT
//                                itminfo_tab.itm_name,
//                                itminfo_tab.qty_carton,
//                                Sum( gwis_detail.quantity ) AS stock_receive,
//                                Sum( stock_batch.Qty ) AS Vials,
//                                SUM(gwis_detail.grn_quantity) AS receive_qty,
//                                tbl_itemunits.UnitType,
//                                product_category.category,
//                                product_strength.strength,
//                                product_method_type.method_type,
//                                stock_batch.batch_expiry,
//                                stock_batch.batch_no,
//                                stock_batch.batch_id,
//                                stock_batch.unit_price,
//                                stakeholder.stkname AS funding_source,
//                                SUM( gwis_detail.actual_rec_qty ) AS actual_rec_qty,
//                                itminfo_tab.itm_id,
//                                stkn.stkname AS stk_name
//                        FROM
//                                stock_batch
//                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
//                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
//                                LEFT JOIN product_category ON itminfo_tab.itm_category = product_category.pk_id
//                                LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
//                                LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
//                                LEFT JOIN stakeholder ON stock_batch.funding_source = stakeholder.stkid
//                                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
//                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
//                                LEFT JOIN stakeholder AS stkn ON gwis_master.stk_id = stkn.stkid	
//                        WHERE
//                                $date 
//                                AND gwis_master.status_id IN ( 3 )
//                                AND gwis_master.process_status = '$process_status_nmbr_s3'
//                                $stklimit
//                        GROUP BY
//                                itminfo_tab.itm_id 
//                        ORDER BY
//                                stkn.stkname ASC
//                        ) A
//                        LEFT JOIN (
//                        SELECT
//                                GROUP_CONCAT(DISTINCT DATE_FORMAT(gwis_master.tran_date,'%Y%m') ) AS issuemonths,
//                                SUM(gwis_detail.quantity) AS issue_quantity,
//                                itminfo_tab.itm_id 
//                        FROM
//                                gwis_detail
//                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
//                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
//                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
//                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType 
//                        WHERE
//                                $date
//                                AND gwis_master.status_id IN ( 4 ) 
//                                AND gwis_master.process_status = '$process_status_nmbr_s4'
//                        GROUP BY
//                        itminfo_tab.itm_id 
//                        ) B ON A.itm_id = B.itm_id
//                        LEFT JOIN (
//                        SELECT
//                                SUM( stock_batch.Qty ) AS expiry_quantity,
//                                itminfo_tab.itm_id 
//                        FROM
//                                gwis_detail
//                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
//                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
//                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
//                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
//                        WHERE
//                                Date(stock_batch.batch_expiry) BETWEEN '$startdate' AND '$enddate' 
//                        GROUP BY
//                                itminfo_tab.itm_id 
//                        ) C ON C.itm_id = A.itm_id
//                        LEFT JOIN (
//                        SELECT
//                                SUM( gwis_detail.grn_quantity ) AS grn_quantity,
//                                itminfo_tab.itm_id 
//                        FROM
//                                gwis_detail
//                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
//                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
//                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
//                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType 
//                        WHERE
//                                Date( gwis_master.tran_date ) <= '$startdate' 
//                                AND gwis_master.status_id IN ( 3 ) 
//                                AND gwis_master.process_status = '$process_status_nmbr_s3' 
//                        GROUP BY
//                        itminfo_tab.itm_id 
//                        ) D ON D.itm_id = A.itm_id";


        $qry = "SELECT
                        A.*,
                        B.*,
                        C.*,
                        D.*,
                        E.*,
                        F.*
                FROM
                        (
                        SELECT
                                itminfo_tab.itm_name,
                                itminfo_tab.pack_size,
                                itminfo_tab.qty_carton,
                                Sum( gwis_detail.quantity ) AS stock_receive,
                                Sum( stock_batch.Qty ) AS Vials,
                                SUM(gwis_detail.grn_quantity) AS receive_qty,
                                tbl_itemunits.UnitType,
                                product_category.category,
                                product_strength.strength,
                                product_method_type.method_type,
                                stock_batch.batch_expiry,
                                stock_batch.batch_no,
                                stock_batch.batch_id,
                                stock_batch.unit_price,
                                stakeholder.stkname AS funding_source,
                                SUM( gwis_detail.actual_rec_qty ) AS actual_rec_qty,
                                itminfo_tab.itm_id,
                                stkn.stkname AS stk_name
                        FROM
                                stock_batch
                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
                                LEFT JOIN product_category ON itminfo_tab.itm_category = product_category.pk_id
                                LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
                                LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                                LEFT JOIN stakeholder ON stock_batch.funding_source = stakeholder.stkid
                                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                                LEFT JOIN stakeholder AS stkn ON gwis_master.stk_id = stkn.stkid
                                LEFT JOIN users ON gwis_master.created_by = users.pk_id
                        WHERE
                                $date 
                                AND gwis_master.status_id IN ( 3 )
                                AND gwis_master.process_status = '$process_status_nmbr_s3'
                                $stklimit
                                $createdby
                        GROUP BY
                                itminfo_tab.itm_id 
                        ORDER BY
                                stkn.stkname ASC
                        ) A
                        LEFT JOIN (
                        SELECT
                                GROUP_CONCAT(DISTINCT DATE_FORMAT(gwis_master.tran_date,'%Y%m') ) AS issuemonths,
                                SUM(gwis_detail.quantity) AS issue_quantity,
                                itminfo_tab.itm_id 
                        FROM
                                gwis_detail
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType 
                        WHERE
                                $date
                                AND gwis_master.status_id IN ( 4 ) 
                                AND gwis_master.process_status = '$process_status_nmbr_s4'
                        GROUP BY
                        itminfo_tab.itm_id 
                        ) B ON A.itm_id = B.itm_id
                        LEFT JOIN (
                        SELECT
                                SUM( stock_batch.Qty ) AS expiry_quantity,
                                itminfo_tab.itm_id 
                        FROM
                                gwis_detail
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
                        WHERE
                                Date(stock_batch.batch_expiry) BETWEEN '$startdate' AND '$enddate' 
                        GROUP BY
                                itminfo_tab.itm_id 
                        ) C ON C.itm_id = A.itm_id
                        LEFT JOIN (
                        SELECT
                                SUM( gwis_detail.grn_quantity ) AS grn_quantity,
                                itminfo_tab.itm_id 
                        FROM
                                gwis_detail
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType 
                        WHERE
                                Date( gwis_master.tran_date ) <= '$startdate' 
                                AND gwis_master.status_id IN ( 3 ) 
                                AND gwis_master.process_status = '$process_status_nmbr_s3' 
                        GROUP BY
                        itminfo_tab.itm_id 
                        ) D ON D.itm_id = A.itm_id
                        LEFT JOIN (
                        SELECT
                                itminfo_tab.itm_id,
                                Sum( gwis_detail.quantity ) AS tstock_receive
                        FROM
                                stock_batch
                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
                                LEFT JOIN product_category ON itminfo_tab.itm_category = product_category.pk_id
                                LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
                                LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
                                LEFT JOIN stakeholder ON stock_batch.funding_source = stakeholder.stkid
                                LEFT JOIN stakeholder AS stkn ON gwis_master.stk_id = stkn.stkid 
                        WHERE
                                gwis_master.process_status IN ( $process_status_nmbr_s3, 99 ) 

                        GROUP BY
                                itminfo_tab.itm_id 
                        ) E ON E.itm_id = A.itm_id
                        LEFT JOIN (
                        SELECT
                                SUM( gwis_detail.quantity ) AS tissue_quantity,
                                itminfo_tab.itm_id 
                        FROM
                                gwis_detail
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType 
                        WHERE
                                gwis_master.status_id IN ( 4 ) 
                                AND gwis_master.process_status = '$process_status_nmbr_s4' 
                        GROUP BY
                        itminfo_tab.itm_id
                        ) F ON F.itm_id = A.itm_id";


//        print_r($qry);exit;
        $result = $this->query($qry);

        if (!empty($result))
            return $result->result_array();
    }

    public function getstockproductinfo_soh($process_status_nmbr, $process_status_nmbr_s4, $prod_category) {
//        $stakeholderid = '';
////        $date = '';
//        $date = "AND Date(tbl_stock_master.TranDate) BETWEEN '$startdate' AND '$enddate'";
//         if (!empty($stakeholder) && $stakeholder != 'all') {
//            $stakeholderid = " AND stakeholder.stkid = '$stakeholder'";
//        }
//may use in future
//       WHERE stock_batch.`wh_id` = '".$_SESSION['warehouse_id']."' 
        $prod_category_type = '';
        $createdby = '';
//        if($_SESSION['id'] == '1')
//        {
//            $createdby = '';
//        }
//        else{
//            $createdby = " AND gwis_master.created_by = '".$_SESSION['id']."'";
//        }

        if (isset($prod_category) && !empty($prod_category)) {
            $prod_category_type = " AND itminfo_tab.product_type = '" . $prod_category . "'";
        } else {
            $prod_category_type = '';
        }

        $stklimit = '';
        $join = '';
//        $stkidarray = array();
//        for ($i = 0; $i < $_SESSION['count']; $i++) {
//            array_push($stkidarray, "'" . $_SESSION['stakeholder_id_'.$i]. "'");
//        }
//        $stkid = implode(', ', $stkidarray);
        $stkid = $this->get_user_stakeholders();

        if ($_SESSION['id'] == '1') {
            $stklimit = '';
            $join = '';
        } else {
//New 
            $stklimit = " AND gwis_master.stk_id IN (" . $stkid . ")";
//Old
//            $stklimit = "AND stakeholder_item.stk_id IN (".$stkid.")";
//            $join = " LEFT JOIN stakeholder ON gwis_master.stk_id = stakeholder.stkid
//                    INNER JOIN stakeholder_item ON stakeholder_item.stk_id = stakeholder.stkid";
        }

        $wh_id = $_SESSION['warehouse_id'];

        $qry = "SELECT
                        A.*,
                        B.* 
                FROM
                        (
                    SELECT
                    itminfo_tab.itm_name,
                    itminfo_tab.qty_carton,
                    itminfo_tab.itm_id,
                    Sum( gwis_detail.quantity ) AS stock_receive,
                    Sum(stock_batch.Qty) AS Vials,
                    tbl_itemunits.UnitType,
                    product_category.category,
                    product_strength.strength,
                    product_method_type.method_type,
                    stock_batch.batch_expiry,
                    stock_batch.batch_no,
                    stock_batch.unit_price,
                    stock_batch.conversion_rate,
                    stakeholder.stkname AS funding_source,
                    stkn.stkname AS stk_name,
                    itminfo_tab.pack_size,
                    gwis_detail.no_of_cartons,
                    gwis_detail.wh_location,
                    list_detail.`name` AS product_type,
                    DATE(gwis_master.tran_date) AS receiving_date,
                    gwis_detail.invoice,
                    manufacturer_name.stkname AS manufacturer_name,
                    po_info.number AS po_cmu_no
            FROM
                    stock_batch
            INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
            LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
            LEFT JOIN product_category ON itminfo_tab.itm_category = product_category.pk_id
            LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
            LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
            INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
            INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
            LEFT JOIN stakeholder ON stock_batch.funding_source = stakeholder.stkid 
            LEFT JOIN stakeholder AS stkn ON gwis_master.stk_id = stkn.stkid
            LEFT JOIN list_detail ON list_detail.pk_id = itminfo_tab.product_type
            LEFT JOIN users ON gwis_master.created_by = users.pk_id
            LEFT JOIN stakeholder AS manufacturer_name ON itminfo_tab.manufacturer_id = manufacturer_name.stkid
            LEFT JOIN po_info ON gwis_master.po_cmu_no = po_info.pk_id
            WHERE 
                gwis_master.process_status IN ($process_status_nmbr,99)
		AND stock_batch.wh_id = $wh_id
                $stklimit
                $createdby
                $prod_category_type
		
            GROUP BY
                    itminfo_tab.itm_id
            ORDER BY
                    stkn.stkname,list_detail.`name` ASC
                ) A
	LEFT JOIN (
	SELECT
		SUM( gwis_detail.quantity ) AS issue_quantity,
		itminfo_tab.itm_id 
	FROM
		gwis_detail
		INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
		INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
		INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
		LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType 
	WHERE
		gwis_master.status_id IN ( 4 ) 
		AND gwis_master.process_status = '$process_status_nmbr_s4' 
		AND stock_batch.wh_id = $wh_id
	GROUP BY
	itminfo_tab.itm_id 
	) B ON A.itm_id = B.itm_id";
//print_r($qry);exit;
        $result = $this->query($qry);

        if (!empty($result))
            return $result->result_array();
    }

    public function getstockproductinfo($process_status_nmbr) {
//        $stakeholderid = '';
////        $date = '';
//        $date = "AND Date(tbl_stock_master.TranDate) BETWEEN '$startdate' AND '$enddate'";
//         if (!empty($stakeholder) && $stakeholder != 'all') {
//            $stakeholderid = " AND stakeholder.stkid = '$stakeholder'";
//        }
//may use in future
//       WHERE stock_batch.`wh_id` = '".$_SESSION['warehouse_id']."' 


        $stklimit = '';
        $join = '';
//        $stkidarray = array();
//        for ($i = 0; $i < $_SESSION['count']; $i++) {
//            array_push($stkidarray, "'" . $_SESSION['stakeholder_id_'.$i]. "'");
//        }
//        $stkid = implode(', ', $stkidarray);
        $stkid = $this->get_user_stakeholders();

        if ($_SESSION['id'] == '1') {
            $stklimit = '';
            $join = '';
        } else {
//New 
            $stklimit = " AND gwis_master.stk_id IN (" . $stkid . ")";
//Old
//            $stklimit = "AND stakeholder_item.stk_id IN (".$stkid.")";
//            $join = " LEFT JOIN stakeholder ON gwis_master.stk_id = stakeholder.stkid
//                    INNER JOIN stakeholder_item ON stakeholder_item.stk_id = stakeholder.stkid";
        }


        $qry = "SELECT
                    itminfo_tab.itm_name,
                    itminfo_tab.qty_carton,
                    Sum( gwis_detail.quantity ) AS stock_receive,
                    Sum(stock_batch.Qty) AS Vials,
                    tbl_itemunits.UnitType,
                    product_category.category,
                    product_strength.strength,
                    product_method_type.method_type,
                    stock_batch.batch_expiry,
                    stock_batch.batch_no,
                    stock_batch.unit_price,
                    stock_batch.conversion_rate,
                    stakeholder.stkname AS funding_source,
                    stkn.stkname AS stk_name,
                    itminfo_tab.pack_size,
                    gwis_detail.no_of_cartons,
                    gwis_detail.wh_location
            FROM
                    stock_batch
            INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
            LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
            LEFT JOIN product_category ON itminfo_tab.itm_category = product_category.pk_id
            LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
            LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
            INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
            INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
            LEFT JOIN stakeholder ON stock_batch.funding_source = stakeholder.stkid 
            LEFT JOIN stakeholder AS stkn ON gwis_master.stk_id = stkn.stkid	
            WHERE 
                gwis_master.process_status IN ($process_status_nmbr,99)
                $stklimit
            GROUP BY
                    itminfo_tab.itm_id
            ORDER BY
                    stkn.stkname ASC";
//        print_r($qry);exit;
        $result = $this->query($qry);

        if (!empty($result))
            return $result->result_array();
    }

    public function getstockbatchinfo($process_status_nmbr, $prod_category) {
//        $stakeholderid = '';
////        $date = '';
//        $date = "AND Date(tbl_stock_master.TranDate) BETWEEN '$startdate' AND '$enddate'";
//         if (!empty($stakeholder) && $stakeholder != 'all') {
//            $stakeholderid = " AND stakeholder.stkid = '$stakeholder'";
//        }
//may use in future
//       WHERE stock_batch.`wh_id` = '".$_SESSION['warehouse_id']."' 
        $prod_category_type = '';
        $createdby = '';
//        if($_SESSION['id'] == '1')
//        {
//            $createdby = '';
//        }
//        else{
//            $createdby = " AND gwis_master.created_by = '".$_SESSION['id']."'";
//        }

        if (isset($prod_category) && !empty($prod_category)) {
            $prod_category_type = " AND itminfo_tab.product_type = '" . $prod_category . "'";
        } else {
            $prod_category_type = '';
        }

        $stklimit = '';
        $join = '';
//        $stkidarray = array();
//        for ($i = 0; $i < $_SESSION['count']; $i++) {
//            array_push($stkidarray, "'" . $_SESSION['stakeholder_id_'.$i]. "'");
//        }
//        $stkid = implode(', ', $stkidarray);
        $stkid = $this->get_user_stakeholders();

        if ($_SESSION['id'] == '1') {
            $stklimit = '';
            $join = '';
        } else {
//New 
            $stklimit = " AND gwis_master.stk_id IN (" . $stkid . ")";
//Old
//            $stklimit = "AND stakeholder_item.stk_id IN (".$stkid.")";
//            $join = " LEFT JOIN stakeholder ON gwis_master.stk_id = stakeholder.stkid
//                    INNER JOIN stakeholder_item ON stakeholder_item.stk_id = stakeholder.stkid";
        }

//        $qry = "SELECT
//                    itminfo_tab.itm_name,
//                    itminfo_tab.qty_carton,
//                    gwis_detail.quantity AS stock_receive,
//                    stock_batch.Qty AS Vials,
//                    tbl_itemunits.UnitType,
//                    product_category.category,
//                    product_strength.strength,
//                    product_method_type.method_type,
//                    stock_batch.batch_expiry,
//                    stock_batch.batch_no,
//                    stock_batch.unit_price,
//                    stock_batch.conversion_rate,
//                    stakeholder.stkname AS funding_source,
//                    gwis_detail.no_of_cartons,
//                    gwis_detail.wh_location,
//                    gwis_detail.field6 AS pack_size,
//                    stkn.stkname AS stk_name,
//                    itminfo_tab.unit 
//            FROM
//                    stock_batch
//            INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
//            LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
//            LEFT JOIN product_category ON itminfo_tab.itm_category = product_category.pk_id
//            LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
//            LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
//            INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
//            INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
//            LEFT JOIN stakeholder ON stock_batch.funding_source = stakeholder.stkid 
//            LEFT JOIN stakeholder AS stkn ON gwis_master.stk_id = stkn.stkid	
//            WHERE 
//                gwis_master.process_status IN ($process_status_nmbr,99)
//                $stklimit
//            GROUP BY
//                    stock_batch.batch_id
//            ORDER BY
//                    stkn.stkname,itminfo_tab.itm_name ASC";

        $wh_id = $_SESSION['warehouse_id'];

        $qry = "SELECT
                        A.*,
                        B.* 
                FROM
                        (
                        SELECT
                                itminfo_tab.itm_name,
                                itminfo_tab.qty_carton,
                                itminfo_tab.itm_id,
                                gwis_detail.quantity AS stock_receive,
                                stock_batch.Qty AS Vials,
                                tbl_itemunits.UnitType,
                                product_category.category,
                                product_strength.strength,
                                product_method_type.method_type,
                                stock_batch.batch_expiry,
                                stock_batch.batch_no,
                                stock_batch.unit_price,
                                stock_batch.batch_id,
                                stock_batch.conversion_rate,
                                stakeholder.stkname AS funding_source,
                                gwis_detail.no_of_cartons,
                                gwis_detail.wh_location,
                                gwis_detail.field6 AS pack_size,
                                stkn.stkname AS stk_name,
                                itminfo_tab.unit 
                        FROM
                                stock_batch
                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
                                LEFT JOIN product_category ON itminfo_tab.itm_category = product_category.pk_id
                                LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
                                LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
                                LEFT JOIN stakeholder ON stock_batch.funding_source = stakeholder.stkid
                                LEFT JOIN stakeholder AS stkn ON gwis_master.stk_id = stkn.stkid
                                LEFT JOIN users ON gwis_master.created_by = users.pk_id
                        WHERE
                                gwis_master.process_status IN ( $process_status_nmbr, 99 ) 
				AND stock_batch.wh_id =$wh_id
                                $stklimit
                                $createdby
                                $prod_category_type
                        GROUP BY
                                stock_batch.batch_id 
                        ORDER BY
                                itminfo_tab.itm_name,
                                stock_batch.batch_expiry ASC 
                        ) A
                        LEFT JOIN (
                        SELECT
                                SUM( gwis_detail.quantity ) AS issue_quantity,
                                itminfo_tab.itm_id,
                                stock_batch.batch_id  
                        FROM
                                gwis_detail
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType 
                        WHERE
                                gwis_master.status_id IN ( 4 ) 
                                AND gwis_master.process_status = '12' 
				AND stock_batch.wh_id =$wh_id
                                $stklimit
                        GROUP BY
                            stock_batch.batch_id 
                        ORDER BY
                            itminfo_tab.itm_name,
                            stock_batch.batch_expiry ASC 
                        ) B ON A.batch_id = B.batch_id";


//        print_r($qry);exit;
        $result = $this->query($qry);

        if (!empty($result))
            return $result->result_array();
    }

    public function getdistribution_detail_info($process_status_nmbr_s3, $process_status_nmbr_s4) {
        $stakeholderid = '';
        $date = '';
//        $date = "Date(gwis_master.tran_date) BETWEEN '$startdate' AND '$enddate'";
//         if (!empty($stakeholder) && $stakeholder != 'all') {
//            $stakeholderid = " AND stakeholder.stkid = '$stakeholder'";
//        }

        $createdby = '';
//        if($_SESSION['id'] == '1')
//        {
//            $createdby = '';
//        }
//        else{
//            $createdby = " AND gwis_master.created_by = '".$_SESSION['id']."'";
//        }

        $withoutsum = '';
        $stklimit = '';
        $join = '';
//        $stkidarray = array();
//        for ($i = 0; $i < $_SESSION['count']; $i++) {
//            array_push($stkidarray, "'" . $_SESSION['stakeholder_id_'.$i]. "'");
//        }
//        $stkid = implode(', ', $stkidarray);
        $stkid = $this->get_user_stakeholders();

        if ($_SESSION['id'] == '1') {
            $withoutsum = ' Sum( gwis_detail.quantity ) AS stock_receive,
                                Sum( stock_batch.Qty ) AS Vials,';
            $stklimit = '';
            $join = '';
        } else {
            $withoutsum = ' gwis_detail.quantity AS stock_receive,
                            stock_batch.Qty AS Vials,';
            $stklimit = "AND stakeholder_item.stk_id IN (" . $stkid . ")";
            $join = "INNER JOIN stakeholder_item ON stakeholder_item.stk_id = stkn.stkid";
        }

        $wh_id = $_SESSION['warehouse_id'];
        $qry = "SELECT
                        A.*,
                        B.* 
                FROM
                        (
                        SELECT
                                itminfo_tab.itm_name,
                                itminfo_tab.qty_carton,
                                $withoutsum
                                tbl_itemunits.UnitType,
                                product_category.category,
                                product_strength.strength,
                                product_method_type.method_type,
                                stock_batch.batch_expiry,
                                stock_batch.batch_no,
                                stock_batch.batch_id,
                                stakeholder.stkname AS funding_source,
                                SUM( gwis_detail.actual_rec_qty ) AS actual_rec_qty,
                                itminfo_tab.itm_id,
                                stkn.stkname AS stk_name,
                                stock_batch.unit_price,
                                stock_batch.conversion_rate
                        FROM
                                stock_batch
                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
                                LEFT JOIN product_category ON itminfo_tab.itm_category = product_category.pk_id
                                LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
                                LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                                LEFT JOIN stakeholder ON stock_batch.funding_source = stakeholder.stkid
                                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                                LEFT JOIN stakeholder AS stkn ON gwis_master.stk_id = stkn.stkid
                                LEFT JOIN users ON gwis_master.created_by = users.pk_id
                                $join
                        WHERE
                                gwis_master.status_id IN ( 3 )
                                AND gwis_master.process_status IN (9,99)
				AND stock_batch.wh_id = $wh_id
                                $createdby
                                $stklimit
                                $date
                        GROUP BY
                                itminfo_tab.itm_id 
                        ORDER BY
                                stkn.stkname ASC
                        ) A
                        LEFT JOIN (
                        SELECT
                                SUM(gwis_detail.quantity) AS issue_quantity,
                                itminfo_tab.itm_id 
                        FROM
                                gwis_detail
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType 
                        WHERE
                                gwis_master.status_id IN ( 4 ) 
				AND stock_batch.wh_id = $wh_id
                                AND gwis_master.process_status = '$process_status_nmbr_s4'
                        GROUP BY
                        itminfo_tab.itm_id 
                        ) B ON A.itm_id = B.itm_id";

//        print_r($qry);exit;
        $result = $this->query($qry);

        if (!empty($result))
            return $result->result_array();
    }

    public function get_c1q() {

        $stklimit = '';
//        $stkidarray = array();
//        for ($i = 0; $i < $_SESSION['count']; $i++) {
//            array_push($stkidarray, "'" . $_SESSION['stakeholder_id_'.$i]. "'");
//        }
//        $stkid = implode(', ', $stkidarray);
        $stkid = $this->get_user_stakeholders();

        if ($_SESSION['id'] == '1') {
            $stklimit = '';
        } else {
            $stklimit = " WHERE `stk_id` IN (" . $stkid . ")";
        }

        $qry = "SELECT * FROM `itminfo_tab` WHERE `itm_id` IN ( SELECT `product_id` FROM `stakeholder_item` $stklimit) ORDER BY `frmindex` ";
//        echo $qry;exit;
        return $this->query($qry);
    }

    public function get_c2q($whid, $year, $month) {
        if ($month < 10) {
            $fmonth = '0' . $month;
        } else if ($month >= 10) {
            $fmonth = $month;
        }
        $qry = "SELECT
                        tbl_hf_data.pk_id,
                        tbl_hf_data.item_id,
                        tbl_warehouse.wh_name AS warehouse_name,
                        tbl_locations.LocName AS province_name,
                        tbl_hf_data.warehouse_id,
                        tbl_hf_data.opening_balance,
                        tbl_hf_data.received_balance,
                        tbl_hf_data.issue_balance,
                        tbl_hf_data.closing_balance,
                        tbl_hf_data.adjustment_positive,
                        tbl_hf_data.adjustment_negative,
                        tbl_hf_data.avg_consumption,
                        tbl_hf_data.new,
                        tbl_hf_data.old,
                        tbl_hf_data.reporting_date,
                        tbl_hf_data.created_date,
                        tbl_hf_data.last_update,
                        tbl_hf_data.ip_address,
                        tbl_hf_data.created_by,
                        tbl_hf_data.is_amc_calculated,
                        tbl_hf_data.temp,
                        tbl_hf_data.removals,
                        tbl_hf_data.dropouts,
                        tbl_hf_data.demand,
                        tbl_hf_data.change_pos,
                        tbl_hf_data.change_neg,
                        tbl_hf_data.retrieved,
                        itminfo_tab.itm_name,
                        product_strength.strength,
                        gwis_detail.field6 AS pack_size,
                        tbl_hf_data.arv_patients,
                        tbl_hf_data.total_stock_dcurperiod,
                        tbl_hf_data.quarterly_demand 
                FROM
                        tbl_hf_data
                        INNER JOIN tbl_warehouse ON tbl_hf_data.warehouse_id = tbl_warehouse.wh_id
                        INNER JOIN tbl_locations ON tbl_warehouse.prov_id = tbl_locations.PkLocID
                        INNER JOIN itminfo_tab ON tbl_hf_data.item_id = itminfo_tab.itm_id
                        LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                        LEFT JOIN stock_batch ON tbl_hf_data.item_id = stock_batch.item_id
                        LEFT JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id 
                WHERE
                        `warehouse_id` = '" . $whid . "'
                        AND DATE_FORMAT( reporting_date, '%Y-%m' )='$year-$fmonth'
                GROUP BY
                        tbl_hf_data.item_id
                ORDER BY 
                        tbl_hf_data.item_id ASC";
//        echo $qry;exit;
//AND `item_id` = '11'
        return $this->query($qry);
    }

//    public function get_c3q() {
//        $qry = "SELECT * FROM `itminfo_tab` WHERE `itm_status`=1 AND `itm_id` IN (SELECT `Stk_item` FROM `stakeholder_item` WHERE `stkid` =$stkid) ORDER BY `frmindex`";
//        return $this->query($qry);
//    }

    public function get_c4q($whid, $year, $month) {
        if ($month < 10) {
            $fmonth = '0' . $month;
        } else if ($month >= 10) {
            $fmonth = $month;
        }
        $qry = "SELECT
                        stock_batch.wh_id,
                        stock_batch.batch_id,
                        stock_batch.batch_no,
                        stock_batch.`status`,
                        Sum( gwis_detail.quantity ) AS Qty,
                        gwis_detail.is_received,
                        gwis_master.tran_date,
                        stock_batch.item_id 
                FROM
                        stock_batch
                        INNER JOIN gwis_detail ON gwis_detail.batch_id = stock_batch.batch_id
                        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                WHERE
                        stock_batch.wh_id = '" . $whid . "' 
                        AND DATE_FORMAT( gwis_master.tran_date, '%Y-%m' ) = '$year-$fmonth' 
                GROUP BY
                        stock_batch.item_id";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function delete_old_hf_wh_data($wh_id, $month, $year) {
        if ($month < 10) {
            $fmonth = '0' . $month;
        } else if ($month >= 10) {
            $fmonth = $month;
        }
        $qry = "DELETE FROM tbl_hf_data WHERE `warehouse_id`=" . $wh_id . " AND DATE_FORMAT( reporting_date, '%Y-%m' ) = '$year-$fmonth'";
//        print_r($qry);exit;
        return $this->query($qry);
    }

    public function get_print_c2q($whid, $year, $month) {
        if ($month < 10) {
            $fmonth = '0' . $month;
        } else if ($month >= 10) {
            $fmonth = $month;
        }
        $qry = "SELECT
                        tbl_hf_data.pk_id,
                        tbl_hf_data.item_id,
                        tbl_warehouse.wh_name AS warehouse_name,
                        tbl_locations.LocName AS province_name,
                        tbl_hf_data.warehouse_id,
                        tbl_hf_data.opening_balance,
                        tbl_hf_data.received_balance,
                        tbl_hf_data.issue_balance,
                        tbl_hf_data.closing_balance,
                        tbl_hf_data.adjustment_positive,
                        tbl_hf_data.adjustment_negative,
                        tbl_hf_data.avg_consumption,
                        tbl_hf_data.new,
                        tbl_hf_data.old,
                        tbl_hf_data.reporting_date,
                        tbl_hf_data.created_date,
                        tbl_hf_data.last_update,
                        tbl_hf_data.ip_address,
                        tbl_hf_data.created_by,
                        tbl_hf_data.is_amc_calculated,
                        tbl_hf_data.temp,
                        tbl_hf_data.removals,
                        tbl_hf_data.dropouts,
                        tbl_hf_data.demand,
                        tbl_hf_data.change_pos,
                        tbl_hf_data.change_neg,
                        tbl_hf_data.retrieved,
                        itminfo_tab.itm_name,
                        product_strength.strength,
                        gwis_detail.field6 AS pack_size,
                        tbl_hf_data.arv_patients,
                        tbl_hf_data.total_stock_dcurperiod,
                        tbl_hf_data.quarterly_demand 
                FROM
                        tbl_hf_data
                        INNER JOIN tbl_warehouse ON tbl_hf_data.warehouse_id = tbl_warehouse.wh_id
                        INNER JOIN tbl_locations ON tbl_warehouse.prov_id = tbl_locations.PkLocID
                        INNER JOIN itminfo_tab ON tbl_hf_data.item_id = itminfo_tab.itm_id
                        LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                        LEFT JOIN stock_batch ON tbl_hf_data.item_id = stock_batch.item_id
                        LEFT JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id 
                WHERE
                        `warehouse_id` = '" . $whid . "'
                        AND DATE_FORMAT( reporting_date, '%Y-%m' )='$year-$fmonth'
                GROUP BY
                        tbl_hf_data.item_id
                ORDER BY 
                        tbl_hf_data.item_id ASC";
//        echo $qry;exit;
//AND `item_id` = '11'
        return $this->query($qry);
    }

    public function check_this_month($whid, $year, $month) {
        if ($month < 10) {
            $fmonth = '0' . $month;
        } else if ($month >= 10) {
            $fmonth = $month;
        }
        $qry = "SELECT
                        * 
                FROM
                        tbl_hf_data 
                WHERE
                        tbl_hf_data.warehouse_id = '" . $whid . "'
                        AND DATE_FORMAT( tbl_hf_data.reporting_date, '%Y-%m' ) = '$year-$fmonth'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function get_last_month($whid, $year, $month) {
        if ($month < 10) {
            $fmonth = '0' . ($month - 1);
        } else if ($month >= 10) {
            $fmonth = $month - 1;
        }
        $qry = "SELECT
                        tbl_hf_data.pk_id,
                        tbl_hf_data.item_id,
                        tbl_warehouse.wh_name AS warehouse_name,
                        tbl_locations.LocName AS province_name,
                        tbl_hf_data.warehouse_id,
                        tbl_hf_data.opening_balance,
                        tbl_hf_data.received_balance,
                        tbl_hf_data.issue_balance,
                        tbl_hf_data.closing_balance,
                        tbl_hf_data.adjustment_positive,
                        tbl_hf_data.adjustment_negative,
                        tbl_hf_data.avg_consumption,
                        tbl_hf_data.new,
                        tbl_hf_data.old,
                        tbl_hf_data.reporting_date,
                        tbl_hf_data.created_date,
                        tbl_hf_data.last_update,
                        tbl_hf_data.ip_address,
                        tbl_hf_data.created_by,
                        tbl_hf_data.is_amc_calculated,
                        tbl_hf_data.temp,
                        tbl_hf_data.removals,
                        tbl_hf_data.dropouts,
                        tbl_hf_data.demand,
                        tbl_hf_data.change_pos,
                        tbl_hf_data.change_neg,
                        tbl_hf_data.retrieved,
                        itminfo_tab.itm_name,
                        product_strength.strength,
                        gwis_detail.field6 AS pack_size,
                        tbl_hf_data.arv_patients,
                        tbl_hf_data.total_stock_dcurperiod,
                        tbl_hf_data.quarterly_demand 
                FROM
                        tbl_hf_data
                        INNER JOIN tbl_warehouse ON tbl_hf_data.warehouse_id = tbl_warehouse.wh_id
                        INNER JOIN tbl_locations ON tbl_warehouse.prov_id = tbl_locations.PkLocID
                        INNER JOIN itminfo_tab ON tbl_hf_data.item_id = itminfo_tab.itm_id
                        LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                        LEFT JOIN stock_batch ON tbl_hf_data.item_id = stock_batch.item_id
                        LEFT JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id 
                WHERE
                        `warehouse_id` = '" . $whid . "'
                        AND DATE_FORMAT( reporting_date, '%Y-%m' )='$year-$fmonth'
                GROUP BY
                        tbl_hf_data.item_id
                ORDER BY 
                        tbl_hf_data.item_id ASC";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

//Queries for Script



    public function get_all_script_table_info() {
        $qry = "SELECT
                        * 
                FROM
                        cmu_tb_data_awais 
                ORDER BY
                        master_id ASC";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function get_from_warehouse_info($whname) {
        $qry = "SELECT
                        * 
                FROM
                        tbl_warehouse WHERE wh_name = '$whname'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function insert_from_warehouse_info($whname) {
        $sql = "INSERT INTO tbl_warehouse (wh_name,stkid,stkofficeid,hf_type_id,hf_cat_id) VALUES ('" . $whname . "','','','','1')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function get_to_warehouse_info($whname) {
        $qry = "SELECT
                        * 
                FROM
                        tbl_warehouse WHERE wh_name = '$whname'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function insert_to_warehouse_info($whname) {
        $sql = "INSERT INTO tbl_warehouse (wh_name,stkid,stkofficeid,hf_type_id,hf_cat_id) VALUES ('" . $whname . "','','','','1')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function get_source_type_info($source_type) {
        $qry = "SELECT
                        * 
                FROM
                        stakeholder WHERE stkname = '$source_type' AND stk_type_id = '2'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function insert_source_type_info($source_type) {
        $sql = "INSERT INTO stakeholder (stkname,stk_type_id,is_reporting,MainStakeholder) VALUES ('" . $source_type . "','2','1','')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function get_stkname_info($stkname) {
        $qry = "SELECT
                        * 
                FROM
                        stakeholder WHERE stkname = '$stkname'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function insert_stkname_info($stkname) {
        $sql = "INSERT INTO stakeholder (stkname,stk_type_id,is_reporting,MainStakeholder) VALUES ('" . $stkname . "','0','1','')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function get_batch_no_info($info, $prod) {
        $qry = "SELECT
                        * 
                FROM
                        stock_batch WHERE batch_no = '$info' AND item_id='$prod'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function insert_batch_no_info($batch_no, $batch_expiry, $itm_name, $quantity, $unit_price, $from_warehouse, $currency, $conversion_rate, $production_date, $manufacturer, $source_type) {
        $sql = "INSERT INTO stock_batch 
                (stock_batch.batch_expiry,
                stock_batch.batch_no,
                stock_batch.item_id,
                stock_batch.Qty,
                stock_batch.`status`,
                stock_batch.unit_price,
                stock_batch.dollar_rate,
                stock_batch.production_date,
                stock_batch.wh_id,
                stock_batch.currency,
                stock_batch.conversion_rate,
                stock_batch.dtl_result,
                stock_batch.manufacturer,
                stock_batch.funding_source) 
            VALUES 
                ('" . $batch_expiry . "','" . $batch_no . "','" . $itm_name . "','" . $quantity . "','Running',
                '" . $unit_price . "','','" . $production_date . "','" . $from_warehouse . "','" . $currency . "',
                '" . $conversion_rate . "','','" . $manufacturer . "','" . $source_type . "')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function get_itm_name_info($info, $Strength) {
        $qry = "SELECT
                        * 
                FROM
                        itminfo_tab WHERE itm_name = '$info' AND strength_id = '$Strength'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function insert_itm_name_info($itm_name, $generic_name, $Method, $Strength, $manufacturer, $itmrec_id, $Qty_per_Pack, $Pack_per_Carton, $product_type) {
//        if(!empty($Strength))
//        {
//            $product_type = '36';
//        }
//        else
//        {
//            $product_type = '0';
//        }
        $sql = "INSERT INTO itminfo_tab 
                (itminfo_tab.itmrec_id,
                itminfo_tab.itm_name, 
                itminfo_tab.generic_name, 
                itminfo_tab.method_type, 
                itminfo_tab.manufacturer_id, 
                itminfo_tab.strength_id,
                itminfo_tab.product_type,
                itminfo_tab.pack_size,
                itminfo_tab.carton_size,
                itminfo_tab.itm_category ) 
            VALUES 
                ('" . $itmrec_id . "','" . $itm_name . "','" . $generic_name . "','" . $Method . "',
                '" . $manufacturer . "','" . $Strength . "','" . $product_type . "',
                 '" . $Qty_per_Pack . "','" . $Pack_per_Carton . "','1')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function get_Strength_info($info) {
        $qry = "SELECT
                        * 
                FROM
                        product_strength WHERE strength = '$info'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function insert_Strength_info($info) {
        $sql = "INSERT INTO product_strength (strength,is_active) VALUES ('" . $info . "','1')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function get_Method_info($info) {
        $qry = "SELECT
                        * 
                FROM
                        product_method_type WHERE method_type = '$info'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function insert_Method_info($info) {
        $sql = "INSERT INTO product_method_type (method_type,is_active) VALUES ('" . $info . "','1')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function get_currency_info($info) {
        $qry = "SELECT
                        * 
                FROM
                        list_detail WHERE name = '$info' AND master_id = '5'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function insert_currency_info($info) {
        $sql = "INSERT INTO list_detail (master_id,name) VALUES ('5','" . $info . "')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function get_generic_name_info($info) {
        $qry = "SELECT
                        * 
                FROM
                        product_generic_name WHERE generic_name = '$info'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function insert_generic_name_info($info) {
        $sql = "INSERT INTO product_generic_name (generic_name,is_active) VALUES ('" . $info . "','1')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function get_manufacturer_info($info) {
        $qry = "SELECT
                        * 
                FROM
                        stakeholder WHERE stkname = '$info' AND stk_type_id = '3'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function insert_manufacturer_info($info) {
        $sql = "INSERT INTO stakeholder (stkname,stk_type_id,is_reporting,MainStakeholder) VALUES ('" . $info . "','3','1','')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function get_siv_vehicle_type_info($info) {
        $qry = "SELECT
                        * 
                FROM
                        list_detail WHERE name = '$info' AND master_id = '13'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function insert_siv_vehicle_type_info($info) {
        $sql = "INSERT INTO list_detail (master_id,name) VALUES ('13','" . $info . "')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function get_PO_CMU_info($info) {
        $qry = "SELECT
                        * 
                FROM
                        po_info WHERE number = '$info'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function insert_PO_CMU_info($info) {
        date_default_timezone_set('Asia/Karachi');
        $created_on_time = date('Y-m-d', time());
        $sql = "INSERT INTO po_info (type,number,date,is_active) VALUES ('4','" . $info . "','" . $created_on_time . "','1')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    function getLastIDy($from, $to, $status_id) {
//        if ($tr_type == 1) {
//            $str = "AND wh_id_to='" . $_SESSION['warehouse_id'] . "'";
//        } else {
//            $str = "AND wh_id_from='" . $_SESSION['warehouse_id'] . "'";
//        }
//        if ($status_id == 0) {
//            $str = "where status_id='" . $status_id . "'";
//        } 
//        else if ($status_id == 1) {
//            $str = "where status_id='" . $status_id . "'";
//        } else{
//            $str = "where status_id='" . $status_id . "'";
//            $str .= "OR status_id = '3'";
//        }
        $str = '';
        if (isset($status_id) && !empty($status_id)) {
            $str = "where process_status='" . $status_id . "' AND approve_from != ''";
        }
//        if ($status_id == 1) {
//            $str = "where process_status='" . $status_id . "'";
//        } 
//        else if ($status_id == 2) {
//            $str = "where process_status='" . $status_id . "'";
//        } else if ($status_id == 3) {
//            $str = "where process_status='" . $status_id . "' AND active_process = 1";
//        } else if ($status_id == 4) {
//            $str = "where process_status='" . $status_id . "' AND active_process = 1";
//        } else{
//            $str = "where process_status='" . $status_id . "' AND active_process = 1";
//            $str .= "OR process_status = '3'";
//        }
//        $strSql = "SELECT MAX(tr_no) as Maxtr from " . static::$table_name . " where tran_date between '" . $from . "' and '" . $to . "' $str";
        $strSql = "SELECT MAX(tr_no) as Maxtr from gwis_master $str";

//        echo $strSql;exit;
        return $this->query($strSql);
    }

    public function get_gwis_master_info($tran_date, $from_warehouse, $to_warehouse, $source_type) {
        $qry = "SELECT
                        * 
                FROM
                        gwis_master WHERE tran_date = '$tran_date' AND wh_id_from = '$from_warehouse' AND wh_id_to = '$to_warehouse' AND source_type = '$source_type'";
//        echo $qry;
//        echo $this->query($qry);exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function insert_gwis_master_info($tran_date, $trans_no, $Status, $from_warehouse, $to_warehouse, $created_on_time, $tr_no, $source_type, $stkname, $PO_CMU, $script_master_id) {
        if ($Status == '13') {
            $process_status = '9';
            $final_status = '';
            $electronic_approval = '0';
            $tran_type_id = '';

//Only for now when warehouse increse remove this check
            $from_warehouse = '97800';
            $to_warehouse = '97800';
        } else if ($Status == '3') {
            $process_status = '9';
            $final_status = '78';
            $electronic_approval = '1';
            $tran_type_id = '';

//Only for now when warehouse increse remove this check
//            $from_warehouse = '';
            $to_warehouse = '97800';
        } else if ($Status == '4') {
            $process_status = '12';
            $final_status = '78';
            $electronic_approval = '1';
            $tran_type_id = '';

//Only for now when warehouse increse remove this check
            $from_warehouse = '97800';
//            $to_warehouse = '';
        } else {
            $process_status = '';
            $final_status = '';
            $electronic_approval = '';
            $tran_type_id = '';

//Only for now when warehouse increse remove this check
            $from_warehouse = '97800';
            $to_warehouse = '97800';
        }
        $sql = "INSERT INTO gwis_master 
                (gwis_master.tran_date, 
                gwis_master.tran_no, 
                gwis_master.status_id, 
                gwis_master.tran_ref, 
                gwis_master.wh_id_from, 
                gwis_master.wh_id_to, 
                gwis_master.created_by, 
                gwis_master.created_on, 
                gwis_master.temp, 
                gwis_master.tr_no, 
                gwis_master.source_type,  
                gwis_master.process_status, 
                gwis_master.active_process, 
                gwis_master.final_status, 
                gwis_master.electronic_approval, 
                gwis_master.tran_type_id, 
                gwis_master.stk_id, 
                gwis_master.po_cmu_no,
                gwis_master.script_master_id,
                gwis_master.date_of_receiving,
                gwis_master.wh_id_from_supplier ) 
            VALUES 
                ('" . $tran_date . "','" . $trans_no . "','" . $Status . "','" . $trans_no . "',
                '" . $from_warehouse . "','" . $to_warehouse . "','" . $_SESSION['id'] . "',
                '" . $created_on_time . "','0','" . $tr_no . "','" . $source_type . "','" . $process_status . "',
                '1','" . $final_status . "','" . $electronic_approval . "','" . $tran_type_id . "',
                '" . $stkname . "','" . $PO_CMU . "','" . $script_master_id . "','" . $tran_date . "','" . $source_type . "')";
//            echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function insert_gwis_detail_info($master_id, $batch_no, $quantity, $batch_number, $manufacturer, $batch_expiry, $driver_name, $driver_contract, $siv_cnic, $vehicle_reg, $dc_no, $dc_date, $invoice, $siv_mode_of_transport, $siv_name_of_transporter, $siv_vehicle_plate_no, $Shipment_Temprature, $Status, $siv_vehicle_type, $production_date) {
        if ($Status == '13') {
            $grn_qty = $quantity;
            $giv_qty = '0';
            $ti_qty = $quantity;
        } else if ($Status == '3') {
            $grn_qty = $quantity;
            $giv_qty = '0';
            $ti_qty = $quantity;
        } else if ($Status == '4') {
            $grn_qty = '0';
            $giv_qty = $quantity;
            $ti_qty = '0';
        } else {
            $grn_qty = $quantity;
            $giv_qty = '0';
            $ti_qty = '0';
        }
        $sql = "INSERT INTO gwis_detail 
                (gwis_detail.fk_stock_id,
                gwis_detail.batch_id,
                gwis_detail.quantity,
                gwis_detail.temp,
                gwis_detail.manufacturer,
                gwis_detail.is_received,
                gwis_detail.driver_name,
                gwis_detail.driver_contract,
                gwis_detail.vehicle_reg,
                gwis_detail.dc_no,
                gwis_detail.dc_date,
                gwis_detail.invoice,
                gwis_detail.field1,
                gwis_detail.field2,
                gwis_detail.field3,
                gwis_detail.siv_mode_of_transport,
                gwis_detail.siv_cnic,
                gwis_detail.grn_quantity,
                gwis_detail.giv_quantity,
                gwis_detail.shipment_temprature,
                gwis_detail.siv_vehicle_plate_no,
                gwis_detail.siv_name_of_transporter,
                gwis_detail.electronic_approval,
                gwis_detail.siv_vehicle_type,
                gwis_detail.ti_quantity ) 
            VALUES 
                ('" . $master_id . "','" . $batch_no . "','" . $quantity . "','0','" . $manufacturer . "','0',
                '" . $driver_name . "','" . $driver_contract . "','" . $vehicle_reg . "',
                '" . $dc_no . "','" . $dc_date . "','" . $invoice . "','" . $batch_number . "','" . $production_date . "','" . $batch_expiry . "',
                '" . $siv_mode_of_transport . "','" . $siv_cnic . "','" . $grn_qty . "','" . $giv_qty . "',
                '" . $Shipment_Temprature . "','" . $siv_vehicle_plate_no . "','" . $siv_name_of_transporter . "','1',
                '" . $siv_vehicle_type . "','" . $ti_qty . "')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function get_last_cmu_data_info($info) {
//        $qry = "SELECT
//                        MAX(pk_id),
//                        pk_id,
//                        script_master_id
//                FROM
//                        gwis_master ";
        $qry = "SELECT
                    * 
                FROM
                        gwis_master 
                ORDER BY
                        pk_id DESC 
                        LIMIT 1";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function get_product_type_info($info) {
        $qry = "SELECT
                        * 
                FROM
                        list_detail WHERE name = '$info' AND master_id = '6'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function insert_product_type_info($info) {
        $sql = "INSERT INTO list_detail (master_id,name) VALUES ('6','" . $info . "')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function m_insert_gwis_detail_info($master_id, $batch_no, $quantity, $batch_number, $manufacturer, $batch_expiry, $driver_name, $driver_contract, $siv_cnic, $vehicle_reg, $dc_no, $dc_date, $invoice, $siv_mode_of_transport, $siv_name_of_transporter, $siv_vehicle_plate_no, $Shipment_Temprature, $Status, $siv_vehicle_type, $production_date, $serial_no) {
        if ($Status == '13') {
            $grn_qty = $quantity;
            $giv_qty = '0';
            $ti_qty = $quantity;
        } else if ($Status == '3') {
            $grn_qty = $quantity;
            $giv_qty = '0';
            $ti_qty = $quantity;
        } else if ($Status == '4') {
            $grn_qty = '0';
            $giv_qty = $quantity;
            $ti_qty = '0';
        } else {
            $grn_qty = $quantity;
            $giv_qty = '0';
            $ti_qty = '0';
        }
        $sql = "INSERT INTO gwis_detail 
                (gwis_detail.fk_stock_id,
                gwis_detail.batch_id,
                gwis_detail.quantity,
                gwis_detail.temp,
                gwis_detail.manufacturer,
                gwis_detail.is_received,
                gwis_detail.driver_name,
                gwis_detail.driver_contract,
                gwis_detail.vehicle_reg,
                gwis_detail.dc_no,
                gwis_detail.dc_date,
                gwis_detail.invoice,
                gwis_detail.field1,
                gwis_detail.field2,
                gwis_detail.field3,
                gwis_detail.siv_mode_of_transport,
                gwis_detail.siv_cnic,
                gwis_detail.grn_quantity,
                gwis_detail.giv_quantity,
                gwis_detail.shipment_temprature,
                gwis_detail.siv_vehicle_plate_no,
                gwis_detail.siv_name_of_transporter,
                gwis_detail.electronic_approval,
                gwis_detail.siv_vehicle_type,
                gwis_detail.ti_quantity,
                gwis_detail.field4 ) 
            VALUES 
                ('" . $master_id . "','" . $batch_no . "','" . $quantity . "','0','" . $manufacturer . "','0',
                '" . $driver_name . "','" . $driver_contract . "','" . $vehicle_reg . "',
                '" . $dc_no . "','" . $dc_date . "','" . $invoice . "','" . $batch_number . "','" . $production_date . "','" . $batch_expiry . "',
                '" . $siv_mode_of_transport . "','" . $siv_cnic . "','" . $grn_qty . "','" . $giv_qty . "',
                '" . $Shipment_Temprature . "','" . $siv_vehicle_plate_no . "','" . $siv_name_of_transporter . "','1',
                '" . $siv_vehicle_type . "','" . $ti_qty . "','" . $serial_no . "')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function m_get_all_script_table_info() {
        $qry = "SELECT
                        * 
                FROM
                        cmu_malaria_data
                ORDER BY
                        master_id ASC";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function m_get_batch_no_info($info, $prod) {
        $qry = "SELECT
                        * 
                FROM
                        stock_batch WHERE batch_no = '$info' AND item_id='$prod'";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }

    public function tbfline_get_all_script_table_info() {
        $qry = "SELECT
                        * 
                FROM
                        printing_material_product_amir
                ORDER BY
                        master_id ASC";
//        echo $qry;exit;
//AND gwis_detail.is_received = 1 
        return $this->query($qry);
    }


    public function reported_non_reported($month, $year, $stakeholder, $province, $district, $reportingDate,$rpt_type,$lvl) {
    
    if($lvl == 1)
    {
        $lvl = "AND stakeholder.lvl = 3";
    }
 else 
 {
        $lvl = "AND stakeholder.lvl = 7";
    }
        $qry = "SELECT
			B.provinceId,
			B.province,
			B.districtId,
			B.district,
			B.stkMain,
			B.stkOffice,
			B.wh_id,
			B.wh_name,
			B.wh_rank,
			DATE_FORMAT(A.add_date, '%Y-%m-%d') AS add_date,
			CONCAT(DATE_FORMAT(A.last_update, '%d/%m/%Y'), ' ', TIME_FORMAT(A.last_update, '%h:%i:%s %p'))AS last_update,
			A.ip_address
		FROM
			(
				SELECT
					tbl_warehouse.wh_id,
					tbl_warehouse.wh_name,
					tbl_warehouse.dist_id,
					tbl_warehouse.prov_id,
					tbl_warehouse.stkid,
					tbl_warehouse.stkofficeid,
					tbl_warehouse.wh_rank,
					tbl_wh_data.add_date,
					tbl_wh_data.last_update,
					tbl_wh_data.ip_address
				FROM
					tbl_warehouse
				INNER JOIN wh_user ON tbl_warehouse.wh_id = wh_user.wh_id
				INNER JOIN tbl_wh_data ON tbl_warehouse.wh_id = tbl_wh_data.wh_id
				INNER JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid
				WHERE
					tbl_wh_data.report_month = $month
				AND tbl_wh_data.report_year = $year
				AND tbl_warehouse.stkid = $stakeholder
				AND tbl_warehouse.prov_id = $province
				AND tbl_warehouse.dist_id = $district
				$lvl
				GROUP BY
					tbl_warehouse.wh_id
				UNION
					SELECT
						tbl_warehouse.wh_id,
						tbl_warehouse.wh_name,
						tbl_warehouse.dist_id,
						tbl_warehouse.prov_id,
						tbl_warehouse.stkid,
						tbl_warehouse.stkofficeid,
						tbl_warehouse.wh_rank,
						tbl_hf_data.created_date AS add_date,
						tbl_hf_data.last_update,
						tbl_hf_data.ip_address
					FROM
						tbl_warehouse
					INNER JOIN wh_user ON tbl_warehouse.wh_id = wh_user.wh_id
					INNER JOIN tbl_hf_data ON tbl_warehouse.wh_id = tbl_hf_data.warehouse_id
					INNER JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid
					WHERE
						MONTH(tbl_hf_data.reporting_date) = $month
					AND YEAR(tbl_hf_data.reporting_date) = $year
					AND tbl_warehouse.stkid = $stakeholder
					AND tbl_warehouse.prov_id = $province
					AND tbl_warehouse.dist_id = $district
					$lvl
					GROUP BY
						tbl_warehouse.wh_id
			) A
		RIGHT JOIN (
			SELECT
				DISTINCT
				tbl_warehouse.wh_id,
				tbl_warehouse.wh_name,
				tbl_warehouse.dist_id,
				tbl_warehouse.prov_id,
				tbl_warehouse.stkid,
				tbl_warehouse.stkofficeid,
				tbl_warehouse.wh_rank,
				MainStk.stkorder,
				MainStk.stkname AS stkMain,
				stakeholder.stkname AS stkOffice,
				District.PkLocID AS districtId,
				District.LocName AS district,
				Province.PkLocID AS provinceId,
				Province.LocName AS province
			FROM
				tbl_warehouse
			INNER JOIN wh_user ON tbl_warehouse.wh_id = wh_user.wh_id
			INNER JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid
			INNER JOIN stakeholder AS MainStk ON tbl_warehouse.stkid = MainStk.stkid
			INNER JOIN tbl_locations AS District ON tbl_warehouse.dist_id = District.PkLocID
			INNER JOIN tbl_locations AS Province ON tbl_warehouse.prov_id = Province.PkLocID
			WHERE
				tbl_warehouse.wh_id NOT IN (
					SELECT
						warehouse_status_history.warehouse_id
					FROM
						warehouse_status_history
					INNER JOIN tbl_warehouse ON warehouse_status_history.warehouse_id = tbl_warehouse.wh_id
					WHERE
						warehouse_status_history.reporting_month = '$reportingDate'
					AND warehouse_status_history.`status` = 0
					AND tbl_warehouse.stkid = $stakeholder
				)
                                AND tbl_warehouse.reporting_start_month <= '$year-$month-01'
                                /*AND tbl_warehouse.is_active = 1*/
				AND tbl_warehouse.stkid = $stakeholder
				AND tbl_warehouse.prov_id = $province
				AND tbl_warehouse.dist_id = $district
				$lvl
		) B ON A.wh_id = B.wh_id
		AND A.prov_id = B.prov_id
		AND A.dist_id = B.dist_id
		AND A.stkid = B.stkid
		AND A.stkofficeid = B.stkofficeid
		ORDER BY
			B.provinceId ASC,
			B.district ASC,
			B.stkorder ASC,
                        B.wh_name,
			IF(A.wh_rank = '' OR A.wh_rank IS NULL, 1, 0),
			A.wh_rank,
			A.wh_name ASC";
      
//        echo $qry;
//        exit;
        return $this->query($qry);
    }
    public function get_stk()
    {
        $qry = "SELECT
	stakeholder.stkname,
        stakeholder.stkid
FROM
	stakeholder
	INNER JOIN
	users
	ON 
		stakeholder.stkid = users.stakeholder_id
WHERE
	users.pk_id = '".$_SESSION['id']."'";
//        echo $qry;exit;
        return $this->query($qry);
    }
    
    
      public function shipment_rpt($month, $year)
    {
        $qry = "SELECT
	wh_id,
	wh_name,
        month,
        year,
	SUM( stockIssue ) AS stockIssue,
	SUM( stockRcv ) AS stockRcv 
FROM
	(
	SELECT
		tbl_warehouse.wh_id,
		tbl_warehouse.wh_name,
                MONTH(gwis_master.tran_date) as month,
                YEAR(gwis_master.tran_date) as year,
		SUM(
		IF
		( gwis_master.wh_id_from = tbl_warehouse.wh_id && gwis_master.tran_type_id = 4, 1, 0 )) AS stockIssue,
		SUM(
		IF
		( gwis_master.wh_id_to = tbl_warehouse.wh_id && gwis_master.tran_type_id = 3, 1, 0 )) AS stockRcv,
		gwis_master.tran_no 
	FROM
		tbl_warehouse
		INNER JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid
		INNER JOIN gwis_master ON tbl_warehouse.wh_id = gwis_master.wh_id_from 
		OR tbl_warehouse.wh_id = gwis_master.wh_id_to 
	WHERE
		stakeholder.lvl = 3 
		AND stakeholder.ParentID = 1715 
		AND gwis_master.temp = 0 
		AND DATE_FORMAT( gwis_master.tran_date, '%Y-%m' ) = '".$year.'-'.date('d', mktime(0,0,0,0,$month))."' 
		AND tbl_warehouse.prov_id = 3 
	GROUP BY
		tbl_warehouse.wh_id,
		gwis_master.tran_no 
	) AS A 
GROUP BY
	wh_id 
ORDER BY
wh_name";
//        echo $qry;exit;
        return $this->query($qry);
    }

}
