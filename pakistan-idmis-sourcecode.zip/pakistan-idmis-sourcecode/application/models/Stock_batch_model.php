<?php

/**
 * clsStockBatch
 * @package includes/class
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
class Stock_batch_model extends Base_model {

    //batch id
    public $batch_id;
    //batch num
    public $batch_no;
    //batch expiry
    public $batch_expiry;
    //item id
    public $item_id;
    //Qty
    public $Qty;
    //funding source
    public $funding_source;
    //warehouse id
    public $wh_id;
    //manufacturer
    public $manufacturer;
//    public $manufacturing_date;
    protected static $table_name = "stock_batch";
    protected static $db_fields = array('batch_no', 'batch_expiry', 'item_id', 'Qty', 'wh_id', 'funding_source', 'manufacturer');

    // Common Database Methods
    /**
     * find_all
     * @return type
     */
    public static
    function find_all() {
        return static::find_by_sql("SELECT * FROM " . static::$table_name);
    }

    /**
     * find_by_id
     * @param type $id
     * @return type
     */
    public function find_by_id($id = 0) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE batch_id=" . $id;
        $result_array = $this->query($qry);
        $ret = $result_array->result_array();
        return !empty($ret[0]) ? ($ret[0]) : false;
    }

    public function find_by_batch_no($batch_no) {
        $qry = "SELECT
        stock_batch.batch_id,
        stock_batch.batch_no
        FROM
        stock_batch
        WHERE
        stock_batch.batch_no = '$batch_no'
        ";
//        print_r($qry);exit;
        $rsSql = mysql_query($qry) or die("Error: GetAllRunningBatches");
        if (mysql_num_rows($rsSql) > 0) {
            return $rsSql;
        } else {
            return FALSE;
        }
    }

    /**
     * find_by_sql
     * @param type $sql
     * @return type
     */
    public static
    function find_by_sql($sql = "") {
        $result_set = mysql_query($sql);
        $object_array = array();
        while ($row = mysql_fetch_array($result_set)) {
            $object_array[] = static::instantiate($row);
        }
        return $object_array;
    }

    /**
     * count_all
     * @global type $database
     * @return type
     */
    public static
    function count_all() {
        $sql = "SELECT COUNT(*) FROM " . static::$table_name;
        //query result
        $result_set = $this->query($sql);
        $row = $this->fetch_array($result_set);
        return array_shift($row);
    }

    /**
     * instantiate
     * @param type $record
     * @return \self
     */
    private static
    function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * has_attribute
     * @param type $attribute
     * @return type
     */
    private
    function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * attributes
     * @return type
     */
    protected
    function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if (isset($this->$field) && ($this->$field != '')) {
                    $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * sanitized_attributes
     * @global type $database
     * @return type
     */
    function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }

        return $clean_attributes;
    }

    /**
     * save
     * @return type
     */
    public
    function save() {
        // A new record won't have an id yet.
        if(isset($this->batch_id)){
//            echo 'F:';
            return $this->update();
        }
        else{
//            echo 'G:';
             $strSql = "SELECT * from " . static::$table_name." where batch_no = '".$this->batch_no."' AND item_id = '".$this->item_id."' AND wh_id='".$this->wh_id."' ";
//             echo $strSql;
             $b_ress =  $this->query($strSql);
             if(!empty($b_ress)){
                $b_res = $b_ress->result_array();
//                echo 'Q:<pre>';
//                print_r($b_res);
//                echo '</pre>';
                if(!empty($b_res[0]['batch_id']) && $b_res[0]['batch_id'] > 0){
                    $this->batch_id = $b_res[0]['batch_id'];
                    @$this->Qty = ($b_res[0]['Qty']+$this->Qty);
                    return $this->update();
                }else{
                     return $this->create();

                }  
             }
             else{
                return $this->create();
             }
            
        }
         
    }

    /**
     * create
     * @global type $database
     * @return boolean
     */
    public
    function create() {


        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection

        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
//            echo $sql; 
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    /**
     * update
     * @global type $database
     * @return type
     */
    public function update() {

        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
//        print_r($attribute_pairs);exit;
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE batch_id='" . $this->escape_value($this->batch_id)."' ";
//        print_r($sql); 
        $this->query($sql);
//        print_r($this->affected_rows());exit;
        return  true ;
    }

    /**
     * delete
     * @global type $database
     * @return type
     */
    public function delete() {
        // Don't forget your SQL syntax and good habits:
        // - DELETE FROM table WHERE condition LIMIT 1
        // - escape all values to prevent SQL injection
        // - use LIMIT 1
        $sql = "DELETE FROM " . static::$table_name;
        $sql .= " WHERE batch_id=" . $this->escape_value($this->batch_id);
        $sql .= " LIMIT 1";
        $this->query($sql);
        return ($this->affected_rows() == 1) ? true : false;

        // NB: After deleting, the instance of User still
        // exists, even though the database entry does not.
        // This can be useful, as in:
        // but, for example, we can't call $user->update()
        // after calling $user->delete().
    }

    function get_product_batches($item,$wh_id=0) {
        $strSql = "SELECT
	stock_batch.batch_no,
	stock_batch.batch_id,
	stock_batch.batch_expiry,
	stock_batch.item_id,
	SUM(tbl_stock_detail.Qty) AS Qty
        FROM
                stock_batch
        INNER JOIN tbl_stock_detail ON stock_batch.batch_id = tbl_stock_detail.BatchID
        INNER JOIN tbl_stock_master ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
        WHERE
                stock_batch.Qty > 0 
        AND stock_batch.item_id = $item
        AND stock_batch.wh_id = $wh_id
        AND tbl_stock_master.WHIDTo = $wh_id
        AND tbl_stock_detail.temp = 0
        GROUP BY
	stock_batch.batch_no";
        print_r($strSql);exit;
        return $this->query($strSql);
    }

    function get_available_prods_of_wh($id=0) {
        $strSql = "SELECT
                    distinct stock_batch.item_id,
                    product.product_name
                FROM
                    stock_batch
                INNER JOIN product ON stock_batch.item_id = product.pk_id
                WHERE
                    stock_batch.wh_id = '".$id."' and Qty > 0
                    order by product_name
                ";
//        print_r($strSql);exit;
        return $this->query($strSql);
    }

    function get_batch_info($batch_id) {
       
         $wh_id = $this->session->userdata('warehouse_id');
        $strSql = "SELECT
                stock_batch.batch_no,
                stock_batch.batch_id,
                stock_batch.batch_expiry,
                stock_batch.item_id,
                stock_batch.Qty as Qty,
                stock_batch.batch_totalprice,
                stock_batch.unit_price
        FROM
                stock_batch
                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
        WHERE
        stock_batch.batch_id = $batch_id 

        AND stock_batch.status = 'Running'
        GROUP BY
         stock_batch.batch_no";

        return $this->query($strSql);    
    }

    function update_batch_quantity($batch_id, $quanitity) {
        $qry = "UPDATE stock_batch set Qty=Qty-$quanitity where batch_id=$batch_id";
        //print_r($qry);exit;
        $this->query2($qry);
        return true;
    }
    function recalculate_batch_qty($batch_id) {
        
        $qry                = "SELECT * from tbl_stock_detail where BatchID=$batch_id";
        $res_arr            = $this->query($qry);
//        print_r($res_arr);exit;
        $data_arr           = $res_arr->result_array();
        
        $balance = 0;
        foreach($data_arr as $k=>$row){
            //echo ','.$row['quantity'];
            $balance += $row['Qty'];
        }
        //echo 'BALANCE:'.$balance;exit;
        $qry = "UPDATE stock_batch set Qty='".$balance."' where batch_id='".$batch_id."' ";
        //print_r($qry);exit;
        $this->query2($qry);
        return $balance;
    }

    
    function get_tran_nature($tran_id) {
        $wh_id = $this->session->userdata('warehouse_id');
        $strSql = "SELECT
transaction_types.trans_nature
FROM
transaction_types
WHERE

transaction_types.trans_id = '$tran_id' 
";
        return $this->query($strSql);
    }
    
//    xxxxxxxxxxxxxxxxxxxxxxxxxx  Receive From Warehouse START xxxxxxxxxxxxxxxxxxxxxxxxx
    
     function get_batch_id($product_name,$batch_number) {
        $session_wh_id = $_SESSION['warehouse_id'];
        $qry = "SELECT
	stock_batch.batch_id 
FROM
	stock_batch
	INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id 
WHERE
	stock_batch.batch_no = '$batch_number'
	AND itminfo_tab.itm_name = '$product_name'
	AND stock_batch.wh_id = '$session_wh_id'
";
         $query = $this->db->query($qry);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
    public function clone_batchrecord($quantity,$clone_batch_id){
        $session_wh_id = $_SESSION['warehouse_id'];
        $qry = "INSERT INTO stock_batch ( stock_batch.batch_no, 
	stock_batch.batch_expiry, 
	stock_batch.item_id, 
	stock_batch.Qty, 
	stock_batch.`status`, 
	stock_batch.unit_price, 
	stock_batch.dollar_rate, 
	stock_batch.production_date, 
	stock_batch.vvm_type, 
	stock_batch.wh_id, 
	stock_batch.funding_source, 
	stock_batch.manufacturer, 
	stock_batch.phy_inspection, 
	stock_batch.dtl, 
	stock_batch.dist_plan, 
	stock_batch.currency, 
	stock_batch.conversion_rate, 
	stock_batch.dtl_result, 
	stock_batch.batch_totalprice, 
	stock_batch.dtl_comment, 
	stock_batch.dtl_remarks, 
	stock_batch.dtl_received_date, 
	stock_batch.dtl_status, 
	stock_batch.manufacturer_name) 
        SELECT
stock_batch.batch_no, 
	stock_batch.batch_expiry, 
	stock_batch.item_id, 
	$quantity, 
	stock_batch.`status`, 
	stock_batch.unit_price, 
	stock_batch.dollar_rate, 
	stock_batch.production_date, 
	stock_batch.vvm_type, 
	$session_wh_id, 
	stock_batch.funding_source, 
	stock_batch.manufacturer, 
	stock_batch.phy_inspection, 
	stock_batch.dtl, 
	stock_batch.dist_plan, 
	stock_batch.currency, 
	stock_batch.conversion_rate, 
	stock_batch.dtl_result, 
	stock_batch.batch_totalprice, 
	stock_batch.dtl_comment, 
	stock_batch.dtl_remarks, 
	stock_batch.dtl_received_date, 
	stock_batch.dtl_status, 
	stock_batch.manufacturer_name 
FROM
	stock_batch 
WHERE
	batch_id = '$clone_batch_id'";
//        echo $qry; exit;
         $this->query($qry);
        return $this->insert_id();
    }
      function get_issue_batchno($batch_id){
        $strSql = "SELECT
                            *
                    FROM
                            stock_batch
                    WHERE
                            stock_batch.batch_id = '$batch_id'";
//        echo $strSql;exit;
        return $this->query($strSql);
    }
//    xxxxxxxxxxxxxxxxxxxxxxxxxxxx    Receive from Warehouse END   xxxxxxxxxxxxxxxxxxxxxx
    
}

?>
