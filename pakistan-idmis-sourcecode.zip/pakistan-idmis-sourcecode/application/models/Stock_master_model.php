<?php

/**
 * clsStockMaster
 * @package includes/class
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
// If it's going to need the database, then it's
// probably smart to require it before we start.
class Stock_master_model extends Base_model {

    // table name
    protected static $table_name = "gwis_master";
    //db fileds 
    protected static $db_fields = array('tran_date', 'tran_no','tran_type_id', 'tran_ref','linked_tr', 'wh_id_from', 'wh_id_to', 'created_by', 'created_on','stk_id','tr_no','status_id', 'received_remarks','temp', 'issuance_to', 'mcc_year','process_status');
    //pk stock id
//    public $pk_id;
    //transaction date
    public $tran_date;
    public $tran_no;
    public $linked_tr;
    //transaction type id
    public $tran_type_id;
    //transaction ref
    public $tran_ref;
    //from warehouse id
    public $wh_id_from;
    //to warehouse id
    public $wh_id_to;
    //created by
    public $created_by;
    //created on
    public $created_on;
    public $stk_id;
    public $tr_no;
    public $status_id;
    //Received Remarks
    public $received_remarks;
    public $temp;
      public $issuance_to;
    //temp
    public $mcc_year;
    public $process_status;
    //linked transaction
//    public $linked_transaction;

    // Common Database Methods
    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all() {
        return static::find_by_sql("SELECT * FROM " . static::$table_name);
    }

    /**
     * 
     * find_by_id
     * @param type $id
     * @return type
     * 
     * 
     */
    public function find_by_id($id = 0) {
        //select query
       $strSql = "SELECT * FROM " . static::$table_name . " WHERE pk_id={$id} LIMIT 1";
        //query result
        return $this->query($strSql);
    }

    /**
     * 
     * find_by_sql
     * @param type $sql
     * @return type
     * 
     * 
     */
    public function find_by_sql($sql = "") {
        $result_set = mysql_query($sql);
        //query result
        $object_array = array();
        while ($row = mysql_fetch_array($result_set)) {
            $object_array[] = static::instantiate($row);
        }
        return $object_array;
    }

    /**
     * 
     * count_all
     * @global type $this
     * @return type
     * 
     * 
     */
    public function count_all() {
        //select query
        $sql = "SELECT COUNT(*) FROM " . static::$table_name;
        //query result
        $result_set = $this->query($sql);
        $row = $this->fetch_array($result_set);
        return array_shift($row);
    }

    /**
     * 
     * instantiate
     * @param type $record
     * @return \self
     * 
     * 
     */
    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if (!empty($this->$field) || $this->$field == 0) {
                    $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $database
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.

        return isset($this->pk_id) ? $this->update() : $this->create();
    }

    /**
     *
     * create
     * @global type $database
     * @return boolean
     * 
     * 
     */
    public function create() {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        //insert query
        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
//        print_r($sql);exit;
//	echo 'Ins:::'.$sql;exit;
        if ($this->query2($sql)) {
//            print_r($this->insert_id());exit;
            return $this->insert_id();
        } else {
            return false;
        }
    }

    /**
     * 
     * update
     * @global type $database
     * @return type
     * 
     * 
     */
    public function update() {
        //update query
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
//        print_r($attribute_pairs);exit;
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
//echo 'upd:::'.$sql;exit;
        $this->query($sql);
        return true;
    }
    public function link_trans() {
        //update query
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= " linked_transaction='".$this->linked_transaction."'";
        $sql .= " WHERE pk_id='" . $this->escape_value($this->pk_id)."'";
//echo 'upd:::'.$sql;exit;
        $this->query($sql);
        return true;
    }
    public function mark_received() {
        //update query
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= " temp='1' ";
        $sql .= " WHERE PkStockID= '" . $this->escape_value($this->pk_id)."' ";
//echo 'upd:::'.$sql;exit;
        $this->query($sql);
        return true;
    }

    /**
     * 
     * delete
     * @global type $database
     * @return type
     * 
     * 
     */
    public function delete() {
        // Don't forget your SQL syntax and good habits:
        // - DELETE FROM table WHERE condition LIMIT 1
        // - escape all values to prevent SQL injection
        // - use LIMIT 1 
        //delete query
        $sql = "DELETE FROM " . static::$table_name;
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        $sql .= " LIMIT 1";
        $this->query($sql);
        return ($this->affected_rows() == 1) ? true : false;

        // NB: After deleting, the instance of User still
        // exists, even though the database entry does not.
        // This can be useful, as in:
        // but, for example, we can't call $user->update()
        // after calling $user->delete(). 
    }

    function stock_search($type_id) {
        $wh_id = $this->session->userdata('warehouse_id');
        if($type_id==1){
            $filter=" AND stock_master.warehouse_to = $wh_id";
        }
        else if($type_id==2){
            $filter=" AND stock_master.warehouse_from = $wh_id";
        }
        
        $qry = "SELECT
        stock_master.transaction_date,
        stock_master.transaction_reference,
        stock_batch.batch_number,
        stock_batch.batch_expiry,
        ABS(stock_detail.quantity) as quantity,
        stock_master.issuance_to,
        tbl_warehouse.warehouse_name,
        supp.warehouse_name as supplier_name,
        patients.full_name,
        patients.nic_no,
        stock_detail.stock_master_id,
        stock_detail.pk_id,
        stock_detail.batch_id,
        funding_sources.funding_source_name,
        product.product_name
        FROM
        stock_master
        INNER JOIN stock_detail ON stock_master.pk_id = stock_detail.stock_master_id
        INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
        INNER JOIN product ON stock_batch.item_id = product.pk_id
        LEFT JOIN tbl_warehouse supp ON stock_master.warehouse_from = supp.pk_id
        LEFT JOIN tbl_warehouse ON stock_master.warehouse_to = tbl_warehouse.pk_id
        LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
        LEFT JOIN funding_sources ON stock_batch.funding_source = funding_sources.pk_id
        WHERE
        stock_master.transaction_type_id = $type_id $filter AND
        stock_master.temp = 0
        ORDER BY 
        stock_master.pk_id DESC
        ";
//        print_r($qry);exit;
        return $this->query($qry);
    }

    function save_master_temp($stock_master_id) {
        $qry = "UPDATE stock_master set temp=0 where pk_id=$stock_master_id";
        $this->query($qry);
        return true;
    }

    function get_temp_master_records($transaction_type, $issuance_type = '') {
        $wh_id = $this->session->userdata('warehouse_id');
        $filter = '';
        if ($issuance_type != '') {
            $filter = "AND stock_master.issuance_to='$issuance_type'";
        }
        $qry = "SELECT
        stock_batch.batch_number,
        stock_batch.batch_expiry,
        ABS(stock_detail.quantity) as quantity,
        product.product_name,
        product.manufacturer,
        stock_detail.pk_id,
        stock_detail.stock_master_id,
        funding_sources.funding_source_name,
        tbl_warehouse.warehouse_name,
        patients.full_name,
        patients.nic_no,
        stock_master.issuance_to,
        stock_master.transaction_reference,
transaction_types.trans_type,
stock_master.warehouse_to,
wfrom.warehouse_name AS wh_from
        FROM
        stock_detail
        INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
        INNER JOIN product ON stock_batch.item_id = product.pk_id
        LEFT JOIN funding_sources ON stock_batch.funding_source = funding_sources.pk_id
        INNER JOIN stock_master ON stock_detail.stock_master_id = stock_master.pk_id
        INNER JOIN tbl_warehouse ON stock_master.warehouse_to = tbl_warehouse.pk_id
        LEFT JOIN patients ON stock_master.warehouse_to = patients.pk_id
        LEFT JOIN transaction_types ON stock_master.transaction_type_id = transaction_types.trans_id
INNER JOIN tbl_warehouse AS wfrom ON stock_master.warehouse_from = wfrom.pk_id
        WHERE 
        stock_master.warehouse_to = $wh_id
            AND stock_detail.temp=1";
        if($transaction_type > 2){
            $qry .= " AND stock_master.transaction_type_id > 2";
        }
        else{
            $qry .= " AND stock_master.transaction_type_id=$transaction_type";
        }
        $qry .= "
                $filter
        ";
//        print_r($qry);exit;
        return $this->query($qry);
    }

    function get_issued_records() {
        //for marking acknowledgement
        $wh_id = $this->session->userdata('warehouse_id');
        $qry = "SELECT 
                    stock_master.transaction_reference,
                    stock_master.transaction_date,
                    stock_master.pk_id,
                    tbl_warehouse.warehouse_name,
                    stock_batch.batch_number,
                    stock_detail.quantity,
        product.product_name
               from
               stock_master
                INNER JOIN tbl_warehouse ON stock_master.warehouse_from = tbl_warehouse.pk_id
                INNER JOIN stock_detail ON stock_master.pk_id = stock_detail.stock_master_id
                INNER JOIN stock_batch ON stock_detail.batch_id = stock_batch.batch_id
        inner join product ON stock_batch.item_id = product.pk_id
                 WHERE 
                stock_master.warehouse_to = $wh_id
                AND   stock_master.warehouse_from <> $wh_id
                AND stock_master.temp=0
                AND issuance_to = 'centers'
                AND stock_master.transaction_type_id=2
                AND stock_master.is_received = 0
        ORDER BY batch_number
               ";
//        echo $qry;exit;
        return $this->query($qry);
    } 
     
    function fetch_suppliers() {
        $qry = "SELECT
tbl_warehouse.*
FROM
tbl_warehouse
WHERE
tbl_warehouse.category_id = 3
               ";
        return $this->query($qry);
    } 
     

//    xxxxxxxxxxxxxxxxxxx   IM_NEW Controller Queries  START    xxxxxxxxxxxxxxxx
    
       function fetch_stock_rcv_wh() {
          $session_wh_id = $_SESSION['warehouse_id'];
        $qry = "SELECT DISTINCT
	gwis_master.tran_no,
	gwis_detail.is_received 
FROM
	gwis_master
	INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id 
WHERE
	gwis_master.tran_type_id = 4
	AND gwis_detail.is_received = 0 
	AND gwis_master.wh_id_to = '$session_wh_id' 
ORDER BY
	gwis_master.pk_id ASC";
	
//        echo $qry; exit;
         $query = $this->db->query($qry);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    } 
    
           function GetWHStockByIssueNo($voucher_no) {
          $session_wh_id = $_SESSION['warehouse_id'];
        $qry = "SELECT
	gwis_detail.quantity  AS Qty,
	stock_batch.batch_no,
	stock_batch.batch_id,
	itminfo_tab.itm_name,
	gwis_detail.fk_stock_id,
	gwis_detail.pk_id AS PkDetailID,
	gwis_master.tran_date 
FROM
	gwis_master
	INNER JOIN gwis_detail ON gwis_detail.fk_stock_id = gwis_master.pk_id
	INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
	INNER JOIN itminfo_tab ON itminfo_tab.itm_id = stock_batch.item_id 
WHERE
	gwis_master.tran_no = '$voucher_no' 
	AND gwis_master.temp = 0 
	AND gwis_master.wh_id_to = '$session_wh_id' 
	AND ( gwis_detail.is_received IS NULL OR gwis_detail.is_received = 0 ) 
	AND gwis_master.tran_type_id = 4
               ";
//        echo $qry; exit;
         $query = $this->db->query($qry);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    } 
    
        function trans_types() {
        $qry = "SELECT
	transaction_types.*
FROM
	transaction_types 
        WHERE is_adjustment = '1' ";
//        echo $qry; exit;
         $query = $this->db->query($qry);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    } 
    
            function master_details($voucher) {
        $qry = "SELECT
	gwis_master.tran_no,
	gwis_master.pk_id,
	gwis_master.wh_id_from ,
        gwis_master.stk_id
FROM
	gwis_master 
WHERE
	gwis_master.pk_id = '$voucher'
	 ";
//        echo $qry; exit;
         $query = $this->db->query($qry);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    } 
    
          function update_temp_status($master_id) {
        $qry = "UPDATE tbl_stock_master SET temp='1' WHERE PkStockID= '$master_id'	 ";
//        echo $qry; exit;
         $query = $this->db->query($qry);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    } 
//    xxxxxxxxxxxxxxxxxxx   IM_NEW Controller Queries  END    xxxxxxxxxxxxxxxx
    
    
}

?>
