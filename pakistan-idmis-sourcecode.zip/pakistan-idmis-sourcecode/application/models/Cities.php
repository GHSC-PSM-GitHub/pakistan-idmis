<?php

//require_once 'database.php';
class Cities extends Base_model {

    protected static $table_name = "cities";
    private $conn;
    protected static $db_fields = array("city_name");
    public $pk_id;
    public $city_name;
    public $province_id;

    public function get_combo() {
        $qry = "SELECT
        CONCAT(
            cities.city_name
        ) `key`,
        CONCAT(
            tbl_locations.LocName,
            ' - ',
            cities.city_name
        ) `value`
    FROM
        cities
    INNER JOIN tbl_locations ON cities.province_id = tbl_locations.PkLocID
    ORDER BY
        tbl_locations.PkLocID,
        cities.city_name";
        return $this->query($qry);
    }
    public function find_all() {
        $qry = "SELECT cities.pk_id as pk_id ,cities.city_name,locations.pk_id as prov_id,
                locations.location_name as prov_name
                FROM " . static::$table_name . " 
                LEFT JOIN locations ON cities.province_id = locations.pk_id ";
//        print_r($qry);exit;
        $result = $this->query($qry);
        return $result->result_array();
    }

    public function find_by_id($id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE pk_id=" . $id;
        return $this->query($qry);
    }

    public function find_by_province_id($id, $lvl) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE province_id=" . $id;
        $qry.=" ORDER BY city_name ASC";
        return $this->query($qry);
    }

    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                $attributes[$field] = $this->$field;
            }
        }
        return $attributes;
    }

    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    public function save() {
        // A new record won't have an id yet.
        return isset($this->pk_id) ? $this->update() : $this->create();
    }

    public function deactivate($id) {
        $qry = "UPDATE " . static::$table_name . " SET status=0 where pk_id=$id";
        $this->query($qry);
    }

    public function create() {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
        //echo $sql;exit;
        if ($this->query($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    public function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
//        print_r($sql);exit;
        $this->query($sql);
        return true;
    }

}
