<?php

/**
 * clsStockDetail
 * @package includes/class
 *
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 *
 * @version    2.2
 *
 */
// If it's going to need the database, then it's
// probably smart to require it before we start.
class Gwis_stock_detail_model extends Base_model {

    //table name
    protected static $table_name = "gwis_detail";
    //db fields
    protected static $db_fields = array('fk_stock_id', 'batch_id', 'fk_unit_id', 'quantity', 'temp', 'comments', 'is_received', 'adjustment_type', 'dc_quantity', 'pi_quantity', 'pi_comment', 'ti_quantity', 'ti_comment', 'delivery_challan_type', 'challan_type_detail', 'po_quantity', 'driver_name', 'driver_contract', 'vehicle_reg', 'dc_no', 'dc_date', 'invoice', 'actual_rec_qty', 'field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8', 'field9', 'field10', 'field11', 'field12', 'field13', 'field14', 'field15', 'field16', 'field17', 'field18', 'field19', 'field20', 'gwis_adj_status', 'siv_driver_name', 'siv_contatc_number', 'siv_cnic', 'siv_weight', 'siv_no_of_cartons', 'siv_transportation_po', 'siv_tracking_no', 'grn_quantity', 'giv_quantity', 'electronic_approval', 'electronic_approval_status', 'detail_active_process', 'date_vehicle_req', 'no_of_vehicle', 'type_of_vehicle', 'no_of_cartons', 'value_of_product', 'transport_req_remarks', 'product_type_id', 'temperature_requirement', 'pi_type', 'sbtr_dc_rec', 'siv_mode_of_transport', 'siv_name_of_transporter', 'siv_vehicle_type','agency_name','consignment_no','builty','service_name', 'siv_vehicle_plate_no', 'wh_location', 'shipment_temprature', 'storage');
    //pk detail id
    public $pk_id;
    //fk stock id
    public $fk_stock_id;
    //batch id
    public $batch_id;
    //fk unit id
    public $fk_unit_id;
    //qty
    public $quantity;
    //temp
    public $temp;
    //vvm stage
    public $vvmstage;
    //is received
    public $is_received;
    //adjustment type
    public $adjustment_type;
    public $dc_quantity;
    public $pi_quantity;
    public $pi_comment;
    public $ti_quantity;
    public $ti_comment;
    public $delivery_challan_type;
    public $challan_type_detail;
    public $po_quantity;
    public $driver_name;
    public $driver_contract;
    public $vehicle_reg;
    public $dc_no;
    public $dc_date;
    public $invoice;
    public $actual_rec_qty;
    public $field1;
    public $field2;
    public $field3;
    public $field4;
    public $field5;
    public $field6;
    public $field7;
    public $field8;
    public $field9;
    public $field10;
    public $field11;
    public $field12;
    public $field13;
    public $field14;
    public $field15;
    public $field16;
    public $field17;
    public $field18;
    public $field19;
    public $field20;
    public $gwis_adj_status;
    public $siv_driver_name;
    public $siv_contatc_number;
    public $siv_cnic;
    public $siv_weight;
    public $siv_no_of_cartons;
    public $siv_transportation_po;
    public $siv_tracking_no;
    public $grn_quantity;
    public $giv_quantity;
    public $electronic_approval;
    public $electronic_approval_status;
    public $detail_active_process;
    public $date_vehicle_req;
    public $no_of_vehicle;
    public $type_of_vehicle;
    public $no_of_cartons;
    public $value_of_product;
    public $transport_req_remarks;
    public $product_type_id;
    public $temperature_requirement;
    public $pi_type;
    public $sbtr_dc_rec;
    public $siv_mode_of_transport;
    public $siv_name_of_transporter;
    public $siv_vehicle_type;
    public $siv_vehicle_plate_no;
    public $wh_location;
    public $shipment_temprature;
    public $storage;

    // Common Database Methods

    /**
     * find_all
     * @return type
     */
    public static
            function find_all() {
        return static::find_by_sql("SELECT * FROM " . static::$table_name);
    }

    /**
     * find_by_id
     * @param type $id
     * @return type
     */
    public static
            function find_by_id($id = 0) {
        $result_array = static::find_by_sql("SELECT * FROM " . static::$table_name . " WHERE pk_id={$id} LIMIT 1");
        return !empty($result_array) ? array_shift($result_array) : false;
    }

    /**
     * find_by_stock_id
     * @param type $id
     * @return boolean
     */
    public
            function find_by_stock_id($id = 0) {
        //select query
        //gets
        //pk detail id
        //fk stock id
        //batch id
        //fk unit id
        //qty
        //vvm stage
        //is received
        //adjustment type
        //from warehouse id
        //issued by
        $strSql = "SELECT
            tbl_stock_detail.PkDetailID,
            tbl_stock_detail.fkStockID,
            tbl_stock_detail.BatchID,
            tbl_stock_detail.fkUnitID,
            tbl_stock_detail.Qty,
            tbl_stock_detail.temp,
            tbl_stock_detail.vvm_stage,
            tbl_stock_detail.IsReceived,
            tbl_stock_detail.adjustmentType,
            tbl_stock_master.WHIDTo,
            tbl_stock_master.TranDate,
            tbl_stock_master.TranRef,
            tbl_stock_master.TranNo,
            tbl_stock_master.CreatedBy,
            tbl_stock_master.WHIDFrom,
            tbl_stock_master.issued_by,
            tbl_stock_master.ReceivedRemarks
        FROM
        tbl_stock_detail
        INNER JOIN tbl_stock_master ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
        WHERE
        tbl_stock_master.PkStockID = $id";
        //query result
        return $this->query($strSql);
    }

    /**
     * find_by_detail_id
     * @param type $id
     * @return boolean
     */
    public
            function find_by_detail_id($id = 0) {
        $strSql = "SELECT
        gwis_detail.pk_id,
        gwis_detail.fk_stock_id,
        gwis_detail.batch_id,
        gwis_detail.fk_unit_id,
        gwis_detail.quantity,
        gwis_detail.temp,
        gwis_detail.vvm_stage,
        gwis_detail.is_received,
        gwis_detail.adjustment_type,
        gwis_master.wh_id_to,
		gwis_master.wh_id_from
        FROM
        gwis_detail
        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
        WHERE
        gwis_detail.pk_id = $id";
//        echo $strSql;exit;
        //query result
        return $this->query($strSql);
    }

    /**
     * StockReceived
     * @param type $id
     * @return boolean
     */
    public function StockReceived($id) {
        $strSql = "Update " . static::$table_name . " set is_received=1 where pk_id=$id";
        //query result
        $rsSql = mysql_query($strSql) or die("Error StockReceived");
        if (mysql_affected_rows() > 0) {
            return true;
        } else {
            return FALSE;
        }
    }

    public function update_location() {
        $sql = "Update " . static::$table_name . " set wh_location= '" . $this->escape_value($this->wh_location) . "' where pk_id=" . $this->escape_value($this->pk_id) . "";
        //query result
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    /**
     * updateDetail
     * @param type $oldid
     * @param type $new_batch_id
     * @param type $stk_detail_id
     * @return boolean
     */
    public function updateDetail($oldid, $new_batch_id, $stk_detail_id) {
        mysql_query("Update " . static::$table_name . " set BatchID=$new_batch_id where PkDetailID = " . $stk_detail_id . " ") or die("Error updateDetail");
        if (mysql_affected_rows() > 0) {
            $row = mysql_fetch_array(mysql_query("SELECT
                    SUM(tbl_stock_detail.Qty) as quantity
                    FROM
                    tbl_stock_detail
                    INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
                    WHERE
                    stock_batch.wh_id = " . $_SESSION['user_warehouse'] . " AND
                    tbl_stock_detail.BatchID = $new_batch_id"));
            mysql_query("Update stock_batch set Qty=" . $row['quantity'] . " where batch_id = '$new_batch_id'");
            return true;
        } else {
            return FALSE;
        }
    }

    /**
     * deleteReceive
     * @param type $id
     * @return boolean
     */
    public function deleteReceive($id) {
        $result = $this->getQtyById($id);
        $qty = $result['Qty'];
        $batch_id = $result['BatchID'];
        $stock_id = $result['fkStockID'];

        $objWarehouseData = new clsWarehouseData();
        $objWarehouseData->detail_id = $id;
        $params = $objWarehouseData->getStockReportParams();
        $bQty = $this->getBatchQtyById($batch_id);

        $objStockBatch = new clsStockBatch();
        if ($bQty == $qty) {

            $objStockBatch->adjustQty($batch_id, "Qty-$qty");
            $objStockBatch->changeWh($batch_id);
        } else if ($bQty > $qty) {
            $objStockBatch->adjustQty($batch_id, "Qty-$qty");
        }

        $this->PkDetailID = $id;
        $del = $this->delete($id);

        $objStockMaster = new clsStockMaster();
        $objStockMaster->PkStockID = $stock_id;
        $objStockMaster->delete();

        $objWarehouseData->report_month = $params['month'];
        $objWarehouseData->report_year = $params['year'];
        $objWarehouseData->item_id = $params['item_id'];
        $objWarehouseData->wh_id = $params['wh_id'];
        $objWarehouseData->created_by = $params['created_by'];
        $objWarehouseData->itmrec_id = $params['itmrec_id'];
        $objWarehouseData->adjustStockReport();

        // Delete Placement Entries
        $this->deletePlacement($id);

        if ($del) {
            return true;
        } else {
            return FALSE;
        }
    }

    /**
     * editReceive
     * @param type $id
     * @param type $uQty
     * @return boolean
     */
    public function editReceive($id, $uQty) {
        $result = $this->getQtyById($id);
        $dQty = $result['Qty'];
        $batch_id = $result['BatchID'];
        $bQty = $this->getBatchQtyById($batch_id);

        $objStockBatch = new clsStockBatch();
        if ($uQty == $dQty) {
            return true;
        } else if ($uQty < $dQty) {
            $resultQty = $dQty - $uQty;
            $objStockBatch->adjustQty($batch_id, "Qty-$resultQty");
            return $this->adjustQty($id, $uQty);
        } else if ($uQty > $dQty) {
            $resultQty = $uQty - $dQty;
            $objStockBatch->adjustQty($batch_id, "Qty+$resultQty");
            return $this->adjustQty($id, $uQty);
        }
    }

    /**
     * deleteIssue
     * @param type $id
     * @return boolean
     */
    public function deleteIssue($id) {
        $result = $this->getQtyById($id);
        $qty = abs($result['Qty']);
        $batch_id = $result['BatchID'];
        $stock_id = $result['fkStockID'];
        $master_stock_id = $result['fkStockID'];
        $item_id = $result['item_id'];
        //echo '<pre>';print_r($result);exit;
        $objWarehouseData = new clsWarehouseData();
        $objWarehouseData->detail_id = $id;
        $params = $objWarehouseData->getStockReportParams();

        $objStockBatch = new clsStockBatch();
        $objStockBatch->adjustQty($batch_id, "Qty+$qty");
        $objStockBatch->changeStatus($batch_id, 'Running');

        $this->PkDetailID = $id;
        $del = $this->delete($id);

        $objStockMaster = new clsStockMaster();
        $objStockMaster->PkStockID = $stock_id;
        $objStockMaster->delete();

        $objWarehouseData->report_month = $params['month'];
        $objWarehouseData->report_year = $params['year'];
        $objWarehouseData->item_id = $params['item_id'];
        $objWarehouseData->wh_id = $params['wh_id'];
        $objWarehouseData->created_by = $params['created_by'];
        $objWarehouseData->itmrec_id = $params['itmrec_id'];
        $objWarehouseData->adjustStockReport();

        //update status of CLR from issued to Approved
        // remove the stock_id from clr master table
        $this->update_clr_status($id, $master_stock_id, $item_id);


        // Delete Placement Entries
        $this->deletePlacement($id);

        if ($del) {
            return true;
        } else {
            return FALSE;
        }
    }

    public function delete_adjustment($id) {
        $result = $this->getQtyById($id);
        $qty = abs($result['Qty']);
        $batch_id = $result['BatchID'];
        $stock_id = $result['fkStockID'];
        $master_stock_id = $result['fkStockID'];
        $item_id = $result['item_id'];
        //echo '<pre>';print_r($result);exit;
        $objWarehouseData = new clsWarehouseData();
        $objWarehouseData->detail_id = $id;
        $params = $objWarehouseData->getStockReportParams();

        $objStockBatch = new clsStockBatch();
        $objStockBatch->changeStatus($batch_id, 'Running');

        $this->PkDetailID = $id;
        $del = $this->delete($id);

        $objStockMaster = new clsStockMaster();
        $objStockMaster->PkStockID = $stock_id;
        $objStockMaster->delete();

        $objWarehouseData->report_month = $params['month'];
        $objWarehouseData->report_year = $params['year'];
        $objWarehouseData->item_id = $params['item_id'];
        $objWarehouseData->wh_id = $params['wh_id'];
        $objWarehouseData->created_by = $params['created_by'];
        $objWarehouseData->itmrec_id = $params['itmrec_id'];
        $objWarehouseData->adjustStockReport();

        // Delete Placement Entries
        $this->deletePlacement($id);

        $objStockBatch->adjustQty_two($batch_id);
        if ($del) {
            return true;
        } else {
            return FALSE;
        }
    }

    public function update_clr_status($detailId, $stock_master_id, $item_id) {

        $qry = "SELECT pk_master_id from  clr_details
				WHERE
					stock_master_id = " . $stock_master_id;
        //echo $qry;
        $res = mysql_query($qry);
        $row = mysql_fetch_assoc($res);
        $master_id = $row['pk_master_id'];
        $itm_id = $item_id;

        $qry = "Update  clr_details SET approval_status='Approved'  WHERE pk_master_id = " . $master_id . " AND itm_id = " . $itm_id;
        $del = mysql_query($qry);
        //echo $qry;

        $qry = "Update  clr_master SET approval_status='Approved' WHERE pk_id = " . $master_id;
        $del = mysql_query($qry);
        //echo $qry;exit;
        if ($del) {
            return true;
        } else {
            return FALSE;
        }
    }

    /**
     * Delete Placements
     * @param type $StockDetailId
     * @param type Stock Detail Id for which Placement is to be deleted
     * @return boolean
     */
    public function deletePlacement($detailId) {
        $qry = "DELETE
				FROM
					placements
				WHERE
					placements.stock_detail_id = " . $detailId;
        $del = mysql_query($qry);
        if ($del) {
            return true;
        } else {
            return FALSE;
        }
    }

    /**
     * editIssue
     * @param type $id
     * @param type $uQty
     * @return boolean
     */
    public function editIssue($id, $uQty) {
        $result = $this->getQtyById($id);
        $dQty = abs($result['Qty']);
        $batch_id = $result['BatchID'];
        $bQty = $this->getBatchQtyById($batch_id);

        $objStockBatch = new clsStockBatch();
        if ($uQty == $dQty) {
            return true;
        } else if ($uQty < $dQty) {
            $resultQty = $dQty - $uQty;
            $objStockBatch->adjustQty($batch_id, "Qty+$resultQty");
            return $this->adjustQty($id, "-" . $uQty);
        } else if ($uQty > $dQty) {
            $resultQty = $uQty - $dQty;
            $objStockBatch->adjustQty($batch_id, "Qty-$resultQty");
            return $this->adjustQty($id, "-" . $uQty);
        }
    }

    /**
     * adjustQty
     * @param type $id
     * @param type $qty
     * @return boolean
     */
    function adjustQty($id, $qty) {
        $strSql = "UPDATE " . static::$table_name . " SET Qty=" . $qty;
        $strSql .= " WHERE PkDetailID='" . $id . "'";
        $rsSql = mysql_query($strSql) or die("Error adjustQty");
        if (mysql_affected_rows()) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    /**
     * getQtyById
     * @param type $id
     * @return boolean
     */
    public function getQtyById($id) {
        $strSql = "SELECT
                tbl_stock_detail.Qty,
                tbl_stock_detail.BatchID,
                tbl_stock_detail.fkStockID,
                stock_batch.item_id,
                stock_batch.funding_source,
                stock_batch.manufacturer,
                stock_batch.phy_inspection,
                stock_batch.unit_price
                FROM
                " . static::$table_name . "
                INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
                where PkDetailID=$id";
//        print_r($strSql);exit;
        //query result
        $rsSql = mysql_query($strSql) or die("Error getQtyById");
        if (!empty($rsSql) && mysql_num_rows($rsSql) > 0) {
            $row = mysql_fetch_object($rsSql);
            return array(
                'Qty' => $row->Qty,
                'BatchID' => $row->BatchID,
                'fkStockID' => $row->fkStockID,
                'item_id' => $row->item_id,
                'funding_source' => $row->funding_source,
                'manufacturer' => $row->manufacturer,
                'phy_inspection' => $row->phy_inspection,
                'unit_price' => $row->unit_price,
            );
        } else {
            return FALSE;
        }
    }

    /**
     * getBatchQtyById
     * @param type $id
     * @return boolean
     */
    public function getBatchQtyById($id) {
        $strSql = "Select Qty from stock_batch where batch_id=$id";
        //query result
        $rsSql = mysql_query($strSql) or die("Error getBatchQtyById");
        if (!empty($rsSql) && mysql_num_rows($rsSql) > 0) {
            $row = mysql_fetch_object($rsSql);
            return $row->Qty;
        } else {
            return FALSE;
        }
    }

    /**
     * GetBatchDetail
     * @param type $id
     * @return boolean
     */
    public function GetBatchDetail($id, $batchid) {
        $strSql = "SELECT
                        stock_batch.batch_no,
                        stock_batch.batch_expiry,
                        stock_batch.item_id,
                        stock_batch.unit_price,
                        stock_batch.production_date,
                        stock_batch.vvm_type,
                        gwis_detail.quantity,
                        gwis_detail.dc_quantity,
                        gwis_detail.pi_quantity,
                        gwis_detail.ti_quantity,
                        gwis_detail.pi_comment,
                        gwis_detail.ti_comment,
                        stock_batch.funding_source,
                        stock_batch.manufacturer,
                        gwis_detail.delivery_challan_type,
                        gwis_detail.challan_type_detail,
                        gwis_detail.dc_no,
                        gwis_detail.dc_date,
                        gwis_detail.invoice,
                        gwis_detail.po_quantity,
                        gwis_detail.actual_rec_qty,
                        gwis_detail.vehicle_reg,
                        gwis_detail.driver_contract,
                        gwis_detail.driver_name,
                        gwis_master.wh_id_from_supplier,
                        stock_batch.currency,
                        stock_batch.conversion_rate,
                        gwis_master.wh_id_from,
                        gwis_master.tran_ref,
                        gwis_detail.pk_id, 
                        gwis_detail.fk_stock_id, 
                        gwis_detail.batch_id
                FROM
                        gwis_detail
                        INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                WHERE
                            gwis_detail.pk_id = $id";
        //query result
//        echo $strSql;exit;

        return $this->query($strSql);
    }

    public function GetBatchDetailForEdit($masterid) {
        $strSql = "SELECT
                        stock_batch.batch_no,
                        stock_batch.batch_expiry,
                        stock_batch.item_id,
                        stock_batch.unit_price,
                        stock_batch.production_date,
                        stock_batch.vvm_type,
                        gwis_detail.quantity,
                        gwis_detail.dc_quantity,
                        gwis_detail.pi_quantity,
                        gwis_detail.ti_quantity,
                        gwis_detail.pi_comment,
                        gwis_detail.ti_comment,
                        stock_batch.funding_source,
                        stock_batch.manufacturer,
                        gwis_detail.delivery_challan_type,
                        gwis_detail.challan_type_detail,
                        gwis_detail.dc_no,
                        gwis_detail.dc_date,
                        gwis_detail.invoice,
                        gwis_detail.po_quantity,
                        gwis_detail.actual_rec_qty,
                        gwis_detail.vehicle_reg,
                        gwis_detail.driver_contract,
                        gwis_detail.driver_name,
                        gwis_master.wh_id_from_supplier,
                        stock_batch.currency,
                        stock_batch.conversion_rate,
                        gwis_master.wh_id_from,
                        gwis_master.tran_ref,
                        gwis_master.stk_id,
                        gwis_master.inspection_date,
                        gwis_master.delivery_location,
                        gwis_master.po_cmu_no,
                        gwis_master.po_cmu_date,
                        gwis_master.po_gf_no,
                        gwis_master.po_gf_date,
                        gwis_detail.sbtr_dc_rec,
                        gwis_master.date_of_receiving,
                        gwis_master.air_bill_no,
                        gwis_master.shipment_no,
                        gwis_master.origin_of_country,
                        gwis_master.vehicle_type_and_plate,
                        gwis_master.consignment_weight,
                        gwis_detail.pk_id,
                        gwis_detail.pi_type,
                        gwis_detail.fk_stock_id, 
                        gwis_detail.batch_id
                FROM
                        gwis_detail
                        INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                WHERE
                            gwis_master.pk_id = '$masterid'";
        //query result
//        echo $strSql;exit;

        return $this->query($strSql);
    }

    function recalculate_stockdetail_qty($batch_id) {

        $qry = "SELECT * from gwis_detail where batch_id=$batch_id ORDER By pk_id desc LIMIT 1";
        $res_arr = $this->query($qry);
        $data_arr = $res_arr->result_array();
        //print_R($data_arr);exit;
        $balance = 0;
       /* foreach ($data_arr as $k => $row) {
            $balance += $row['quantity'];
        }*/
        $sql_quantity = "SELECT quantity from gwis_detail where batch_id=$batch_id ORDER By pk_id asc LIMIT 1";
        $res_arr_quantity = $this->query($sql_quantity);
        $res_quantity = $res_arr_quantity->result_array();

        $actual_quantity = $res_quantity[0]['quantity'];
        $temp_quantity =  $data_arr[0]['quantity'];
        $balance = $actual_quantity + $temp_quantity;
       // echo $balance;exit;
        $qry1 = "SELECT
                                        MIN( pk_id ) AS pk_id
                                FROM
                                        gwis_detail 
                                WHERE
                                        gwis_detail.batch_id = $batch_id";
        $res_arr1 = $this->query($qry1);
        //print_r($res_arr);exit;
        $data_arr1 = $res_arr1->result_array();

        $ide = '';
        foreach ($data_arr1 as $k => $rows) {
            //echo ','.$row['quantity'];
            $ide = $rows['pk_id'];
        }
        //echo 'BALANCE:'.$balance;exit;
        $qry = "UPDATE gwis_detail set quantity='" . $balance . "' where batch_id='" . $batch_id . "' AND pk_id = '" . $ide . "' ";
//        print_r($qry);exit;
        $this->query2($qry);
        return $balance;
    }

    /**
     * find_by_sql
     * @param type $sql
     * @return type
     */
    public static
            function find_by_sql($sql = "") {
        $result_set = mysql_query($sql);
        $object_array = array();
        while ($row = mysql_fetch_array($result_set)) {
            $object_array[] = static::instantiate($row);
        }
        return $object_array;
    }

    /**
     * count_all
     * @global type $database
     * @return type
     */
    public static
            function count_all() {
        global $database;
        $sql = "SELECT COUNT(*) FROM " . static::$table_name;
        //query result
        $result_set = $database->query($sql);
        $row = $database->fetch_array($result_set);
        return array_shift($row);
    }

    /**
     * instantiate
     * @param type $record
     * @return \self
     */
    private static
            function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * has_attribute
     * @param type $attribute
     * @return type
     */
    private
            function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * attributes
     * @return type
     */
    protected
            function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if (!empty($this->$field) || $this->$field == 0) {
                    $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * sanitized_attributes
     * @global type $database
     * @return type
     */
    protected
            function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }

        return $clean_attributes;
    }

    /**
     * save
     * @return type
     */
    public
            function save() {
        // A new record won't have an id yet.
        //echo isset($this->PkDetailID) ? 'UPD.' :'Ins.';
        return isset($this->pk_id) ? $this->update() : $this->create();
    }

    /**
     * create
     * @global type $database
     * @return boolean
     */
    public
            function create() {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
//        print_r($sql);exit;


        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    /**
     * update
     * @global type $database
     * @return type
     */
    public
            function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
//        print_r($sql);exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    /**
     * updateTemp
     * @param type $id
     * @return boolean
     */
    function updateTemp($id) {
        $strSql = "Update tbl_stock_detail set temp=0 where fkStockID=$id";
        $rsSql = mysql_query($strSql) or die("Error updateTemp");
        if (mysql_affected_rows() > 0) {
            $strSql2 = "SELECT DISTINCT
                                itminfo_tab.itm_id,
                                tbl_stock_master.WHIDTo
                        FROM
                                tbl_stock_detail
                        INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
                        INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                        INNER JOIN tbl_stock_master ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
                        WHERE
                                tbl_stock_detail.fkStockID = $id";
            //query result
            $rsSql2 = mysql_query($strSql2);
            if (!empty($rsSql2) && mysql_num_rows($rsSql2) > 0) {
                while ($row = mysql_fetch_object($rsSql2)) {
                    $objStockBatch = new clsStockBatch();
                    $objStockBatch->autoRunningLEFOBatch($row->itm_id, $row->WHIDTo);
                }
            }
            return true;
        } else {
            return FALSE;
        }
    }

    function update_stock_using_id() {
//         $attributes = $this->sanitized_attributes();
//        $attribute_pairs = array();
//        foreach ($attributes as $key => $value) {
//            $attribute_pairs[] = "{$key}='{$value}'";
//        }
        $sql = "UPDATE " . static::$table_name . " SET batch_id= '" . $this->escape_value($this->batch_id) . "',quantity = '" . $this->escape_value($this->quantity) . "',pi_quantity = '" . $this->escape_value($this->pi_quantity) . "',pi_comment = '" . $this->escape_value($this->pi_comment) . "',temp = '" . $this->escape_value($this->temp) . "',is_received = '" . $this->escape_value($this->is_received) . "' WHERE pk_id = '" . $this->escape_value($this->pk_id) . "'";
//        print_r($sql);exit;
        $this->query2($sql);
        return true;
    }

    function update_electronic_approval_status($id) {
//         $attributes = $this->sanitized_attributes();
//        $attribute_pairs = array();
//        foreach ($attributes as $key => $value) {
//            $attribute_pairs[] = "{$key}='{$value}'";
//        }
        $sql = "UPDATE " . static::$table_name . " SET electronic_approval_status= '0' WHERE pk_id = '" . $id . "'";
//        print_r($sql);exit;
        $this->query2($sql);
        return true;
    }

    function update_pistock_using_id() {
//         $attributes = $this->sanitized_attributes();
//        $attribute_pairs = array();
//        foreach ($attributes as $key => $value) {
//            $attribute_pairs[] = "{$key}='{$value}'";
//        }
        $sql = "UPDATE " . static::$table_name . " SET batch_id= '" . $this->escape_value($this->batch_id) . "',quantity = '" . $this->escape_value($this->quantity) . "',ti_quantity = '" . $this->escape_value($this->ti_quantity) . "',ti_comment = '" . $this->escape_value($this->ti_comment) . "',temp = '" . $this->escape_value($this->temp) . "',is_received = '" . $this->escape_value($this->is_received) . "' WHERE pk_id = '" . $this->escape_value($this->pk_id) . "'";
//        print_r($sql);exit;
        $this->query2($sql);
        return true;
    }

    function update_gwis_stockadj($statusid) {
//         $attributes = $this->sanitized_attributes();
//        $attribute_pairs = array();
//        foreach ($attributes as $key => $value) {
//            $attribute_pairs[] = "{$key}='{$value}'";
//        }
        if (isset($statusid) && $statusid == '2') {
            $sql = "UPDATE " . static::$table_name . " SET quantity = '" . $this->escape_value($this->quantity) . "',ti_quantity = '" . $this->escape_value($this->ti_quantity) . "',ti_comment = '" . $this->escape_value($this->ti_comment) . "' WHERE pk_id = '" . $this->escape_value($this->pk_id) . "'";

//            $sql = "INSERT INTO " . static::$table_name . " (fk_stock_id,batch_id,quantity,temp,dc_quantity,pi_quantity,pi_comment,ti_quantity,ti_comment,gwis_adj_status) Select fk_stock_id,batch_id,quantity,temp,dc_quantity,pi_quantity,pi_comment,ti_quantity,ti_comment,8 FROM " . static::$table_name . " WHERE pk_id = '" .$this->escape_value($this->pk_id)."'";
        } else if (isset($statusid) && $statusid == '1') {
            $sql = "UPDATE " . static::$table_name . " SET quantity = '" . $this->escape_value($this->quantity) . "',pi_quantity = '" . $this->escape_value($this->pi_quantity) . "',pi_comment = '" . $this->escape_value($this->pi_comment) . "' WHERE pk_id = '" . $this->escape_value($this->pk_id) . "'";

//            $sql = "INSERT INTO " . static::$table_name . " (fk_stock_id,batch_id,quantity,temp,dc_quantity,pi_quantity,pi_comment,ti_quantity,ti_comment,gwis_adj_status) Select fk_stock_id,batch_id,quantity,temp,dc_quantity,pi_quantity,pi_comment,ti_quantity,ti_comment,8 FROM " . static::$table_name . "  WHERE pk_id = '" .$this->escape_value($this->pk_id)."'";
        }
//        print_r($sql);exit;
        $this->query2($sql);
        return true;
    }

    /**
     * updatefk
     * @global type $database
     * @return type
     */
    public
            function updatefk() {
        global $database;
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= "temp = 0";
        $sql .= " WHERE fkStockID=" . $database->escape_value($this->fkStockID);
        $database->query($sql);
        return ($database->affected_rows() == 1) ? true : false;
    }

    /**
     * delete
     * @global type $database
     * @return type
     */
    public function delete() {
        // Don't forget your SQL syntax and good habits:
        // - DELETE FROM table WHERE condition LIMIT 1
        // - escape all values to prevent SQL injection
        // - use LIMIT 1
        $sql = "DELETE FROM " . static::$table_name;
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        $sql .= " LIMIT 1";
        $this->query2($sql);
        return true;

        // NB: After deleting, the instance of User still
        // exists, even though the database entry does not.
        // This can be useful, as in:
        // but, for example, we can't call $user->update()
        // after calling $user->delete().
    }

    public function getEditableDetails($detailId) {
        $qry = "SELECT
            stock_batch.batch_id,
        stock_batch.batch_no,
        stock_batch.batch_expiry,
        stock_batch.item_id,
        stock_batch.unit_price,
        stock_batch.funding_source,
        stock_batch.manufacturer,
        gwis_detail.quantity,
        stock_batch.phy_inspection
        FROM
        gwis_detail
        INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
        WHERE
        gwis_detail.pk_id = $detailId
        ";
//        print_r($qry);exit;
        $result = mysql_query($qry);
        if (mysql_num_rows($result) > 0) {
            return $result;
        } else {
            return false;
        }
    }

    function get_temp_records($stock_master_id) {
        $qry = "SELECT
                    stock_batch.batch_no,
                    stock_batch.Qty,
                    stock_batch.batch_expiry,
                    ABS(gwis_detail.quantity) AS quantity,
                    itminfo_tab.itm_name AS product_name,
                    itminfo_tab.product_type,
                    itminfo_tab.pack_size,
                    itminfo_tab.unit,
                    product_manufacturer.manufacturer,
                    gwis_detail.pk_id,
                    gwis_detail.fk_stock_id,
                    tbl_warehouse.wh_name AS warehouse_name,
                    patients.full_name,
                    patients.nic_no,
                    gwis_master.issuance_to,
                    transaction_types.trans_type,
                    ww.wh_name AS wh_from,
                    gwis_master.wh_id_to,
                    ws.wh_name AS wh_from_supplier,
                    stock_batch.production_date,
                    gwis_master.tran_date,
                    gwis_master.tran_no,
                    gwis_detail.dc_quantity,
                    gwis_detail.pi_quantity,
                    gwis_detail.pi_comment,
                    gwis_master.received_remarks,
                    gwis_detail.batch_id,
                    gwis_detail.field1,
                    gwis_detail.field2,
                    gwis_detail.field3,
                    gwis_detail.field4,
                    gwis_detail.field5,
                    gwis_detail.field6,
                    gwis_detail.field7,
                    gwis_detail.field8,
                    gwis_detail.field9,
                    gwis_detail.field10,
                   	stakeholder.stkname,
	transaction_types.trans_id,
	transaction_types.trans_type,
	transaction_types.trans_nature,
	stakeholder.stkid 
            FROM
                    gwis_detail
            LEFT JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
            LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
            LEFT JOIN product_manufacturer ON product_manufacturer.pk_id = itminfo_tab.manufacturer_id
            LEFT JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
            LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
            LEFT JOIN patients ON gwis_master.wh_id_to = patients.pk_id
            LEFT JOIN transaction_types ON gwis_master.status_id = transaction_types.trans_id
            LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
            LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
            LEFT JOIN stakeholder ON gwis_master.stk_id = stakeholder.stkid 
            WHERE
            gwis_detail.fk_stock_id= $stock_master_id
                AND gwis_detail.temp=1
        ";
//        print_r($qry);
//        exit;
        return $this->query($qry);
    }

    function get_temp_records_edit($stock_master_id) {

        if ($_SESSION['id'] == '1') {
            $createdby = '';
        } else {
            $createdby = " AND gwis_master.created_by = '" . $_SESSION['id'] . "'";
        }

        $qry = "SELECT
                    stock_batch.batch_no,
                    stock_batch.Qty,
                    stock_batch.batch_expiry,
                    ABS(gwis_detail.quantity) AS quantity,
                    itminfo_tab.itm_name AS product_name,
                    itminfo_tab.product_type,
                    product_manufacturer.manufacturer,
                    gwis_detail.pk_id,
                    gwis_detail.fk_stock_id,
                    tbl_warehouse.wh_name AS warehouse_name,
                    patients.full_name,
                    patients.nic_no,
                    gwis_master.issuance_to,
                    transaction_types.trans_type,
                    ww.wh_name AS wh_from,
                    gwis_master.wh_id_to,
                    ws.wh_name AS wh_from_supplier,
                    stock_batch.production_date,
                    gwis_master.tran_date,
                    gwis_detail.dc_quantity,
                    gwis_detail.pi_quantity,
                    gwis_detail.pi_comment,
                    gwis_master.received_remarks,
                    gwis_detail.field1,
                    gwis_detail.field2,
                    gwis_detail.field3,
                    gwis_detail.field4,
                    gwis_detail.field5,
                    gwis_detail.field6,
                    gwis_detail.field7,
                    gwis_detail.field8,
                    gwis_detail.field9,
                    gwis_detail.field10,
                    stakeholder.stkname
            FROM
                    gwis_detail
            LEFT JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
            LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
            LEFT JOIN product_manufacturer ON product_manufacturer.pk_id = itminfo_tab.manufacturer_id
            LEFT JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
            LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
            LEFT JOIN patients ON gwis_master.wh_id_to = patients.pk_id
            LEFT JOIN transaction_types ON gwis_master.status_id = transaction_types.trans_id
            LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
            LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
            LEFT JOIN stakeholder ON stock_batch.funding_source = stakeholder.stkid
            LEFT JOIN users ON gwis_master.created_by = users.pk_id
            WHERE
                gwis_detail.fk_stock_id= '$stock_master_id'
                $createdby
        ";
//        print_r($qry);exit;
        return $this->query($qry);
    }

    function get_temp_records_edit_issue($stock_master_id) {

        if ($_SESSION['id'] == '1') {
            $createdby = '';
        } else {
            $createdby = " AND gwis_master.created_by = '" . $_SESSION['id'] . "'";
        }

        $qry = "SELECT
                    stock_batch.batch_no,
                    stock_batch.Qty,
                    stock_batch.batch_expiry,
                    ABS(gwis_detail.quantity) AS quantity,
                    itminfo_tab.itm_id,
                    itminfo_tab.itm_name AS product_name,
                    itminfo_tab.product_type,
                    itminfo_tab.pack_size,
                    itminfo_tab.unit,
                    product_manufacturer.manufacturer,
                    gwis_detail.pk_id,
                    gwis_detail.fk_stock_id,
                    tbl_warehouse.wh_name AS warehouse_name,
                    patients.full_name,
                    patients.nic_no,
                    gwis_master.issuance_to,
                    transaction_types.trans_type,
                    ww.wh_name AS wh_from,
                    gwis_master.wh_id_to,
                    ws.wh_name AS wh_from_supplier,
                    stock_batch.production_date,
                    gwis_master.tran_date,
                    gwis_detail.dc_quantity,
                    gwis_detail.pi_quantity,
                    gwis_detail.pi_comment,
                    gwis_master.received_remarks,
                    gwis_detail.field1,
                    gwis_detail.field2,
                    gwis_detail.field3,
                    gwis_detail.field4,
                    gwis_detail.field5,
                    gwis_detail.field6,
                    gwis_detail.field7,
                    gwis_detail.field8,
                    gwis_detail.field9,
                    gwis_detail.field10,
                    stakeholder.stkname,
                    gwis_master.tran_date,
                    gwis_master.tran_no,
                    gwis_detail.siv_tracking_no,
                    gwis_detail.siv_transportation_po,
                    gwis_detail.siv_no_of_cartons,
                    gwis_detail.siv_weight,
                    gwis_detail.siv_cnic,
                    gwis_detail.siv_contatc_number,
                    gwis_detail.siv_driver_name,
                    gwis_detail.field6 AS pack_size,
                    gwis_detail.siv_mode_of_transport,
                    gwis_detail.siv_name_of_transporter,
                    gwis_detail.siv_vehicle_type,
                    gwis_detail.siv_vehicle_plate_no,
                    gwis_detail.batch_id,
                    gwis_master.stk_id,
                    gwis_master.source_type,
                    gwis_master.province_id
            FROM
                    gwis_detail
            LEFT JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
            LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
            LEFT JOIN product_manufacturer ON product_manufacturer.pk_id = itminfo_tab.manufacturer_id
            LEFT JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
            LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
            LEFT JOIN patients ON gwis_master.wh_id_to = patients.pk_id
            LEFT JOIN transaction_types ON gwis_master.status_id = transaction_types.trans_id
            LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
            LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
            LEFT JOIN stakeholder ON stock_batch.funding_source = stakeholder.stkid
            LEFT JOIN users ON gwis_master.created_by = users.pk_id
            WHERE
                gwis_detail.fk_stock_id= '$stock_master_id'
                $createdby
        ";
//        print_r($qry);exit;
        return $this->query($qry);
    }

    function get_gwis_records($receiveno) {
        $qry = "SELECT
                    stock_batch.batch_no,
                    stock_batch.batch_expiry,
                    ABS(gwis_detail.quantity) AS quantity,
                    itminfo_tab.itm_name AS product_name,
                    product_manufacturer.manufacturer,
                    gwis_detail.pk_id,
                    gwis_detail.fk_stock_id,
                    tbl_warehouse.wh_name AS warehouse_name,
                    patients.full_name,
                    patients.nic_no,
                    gwis_master.pk_id AS pkmasterid,
                    gwis_master.issuance_to,
                    transaction_types.trans_type,
                    ww.wh_name AS wh_from,
                    gwis_master.wh_id_to,
                    ws.wh_name AS wh_from_supplier,
                    gwis_master.status_id,
                    gwis_master.tran_ref,
                    gwis_master.received_remarks,
                    stock_batch.item_id,
                    stock_batch.production_date,
                    gwis_detail.delivery_challan_type,
                    gwis_detail.challan_type_detail,
                    gwis_master.wh_id_from,
                    gwis_master.wh_id_from_supplier,
                    gwis_master.tran_no,
                    gwis_detail.dc_quantity,
                    gwis_detail.pi_quantity,
                    gwis_detail.ti_quantity,
                    gwis_master.source_type
            FROM
                    gwis_detail
            LEFT JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
            LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
            LEFT JOIN product_manufacturer ON product_manufacturer.pk_id = itminfo_tab.manufacturer_id
            LEFT JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
            LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
            LEFT JOIN patients ON gwis_master.wh_id_to = patients.pk_id
            LEFT JOIN transaction_types ON gwis_master.status_id = transaction_types.trans_id
            LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
            LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
            WHERE
                gwis_master.tran_no= '$receiveno'
                AND gwis_detail.temp=0
        ";
//        print_r($qry);exit;
        return $this->query($qry);
    }

    function getbatch_gwis_records($receiveno) {
        $qry = "SELECT
                    stock_batch.batch_no,
                    stock_batch.batch_expiry,
                    ABS(gwis_detail.quantity) AS quantity,
                    itminfo_tab.itm_name AS product_name,
                    product_manufacturer.manufacturer,
                    gwis_detail.pk_id,
                    gwis_detail.fk_stock_id,
                    tbl_warehouse.wh_name AS warehouse_name,
                    patients.full_name,
                    patients.nic_no,
                    gwis_master.pk_id AS pkmasterid,
                    gwis_master.issuance_to,
                    transaction_types.trans_type,
                    ww.wh_name AS wh_from,
                    gwis_master.wh_id_to,
                    ws.wh_name AS wh_from_supplier,
                    gwis_master.status_id,
                    gwis_master.tran_ref,
                    gwis_master.received_remarks,
                    stock_batch.item_id,
                    stock_batch.production_date,
                    gwis_detail.delivery_challan_type,
                    gwis_detail.challan_type_detail,
                    gwis_master.wh_id_from,
                    gwis_master.wh_id_from_supplier,
                    gwis_master.tran_no,
                    gwis_detail.dc_quantity,
                    gwis_detail.pi_quantity,
                    gwis_detail.ti_quantity,
                    stock_batch.Qty, 
                    stock_batch.dtl, 
                    stock_batch.dtl_result,
                    gwis_master.source_type
            FROM
                    gwis_detail
            LEFT JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
            LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
            LEFT JOIN product_manufacturer ON product_manufacturer.pk_id = itminfo_tab.manufacturer_id
            LEFT JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
            LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
            LEFT JOIN patients ON gwis_master.wh_id_to = patients.pk_id
            LEFT JOIN transaction_types ON gwis_master.status_id = transaction_types.trans_id
            LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
            LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
            WHERE
                gwis_master.tran_no= '$receiveno'
                AND gwis_detail.temp=0
        ";
//        print_r($qry);exit;
        return $this->query($qry);
    }

    function save_details_temp($stock_master_id) {
        $qry = "UPDATE gwis_detail set temp=0 where fk_stock_id=$stock_master_id";
        $this->query($qry);
        return true;
    }

    function receiveupdate_details_temp($pk_id) {
        $qry = "UPDATE gwis_detail set temp=0 where pk_id=$pk_id";
        $this->query($qry);
        return true;
    }

    function find_master_exist($issue_no) {
        $qry = "SELECT
                    gwis_master.pk_id,
                    gwis_master.tran_no, 
                    gwis_master.tran_ref
            FROM
                    gwis_master
            WHERE
                    gwis_master.tran_ref = '$issue_no'";
        $this->query($qry);
        if ($this->query($qry)) {
            return $this->query($qry);
        } else {
            return false;
        }
    }

	function clone_record($detail_id,$new_stk_id, $giv_qty, $comment, $adj_type){

		if($adj_type == 3){
			$tiqty = $giv_qty;
		} else {
			$tiqty = 'gwis_detail.ti_quantity';
		}
		$qry = "INSERT INTO gwis_detail(gwis_detail.fk_stock_id, 
		gwis_detail.batch_id, 
		gwis_detail.fk_unit_id, 
		gwis_detail.quantity, 
		gwis_detail.temp, 
		gwis_detail.vvm_stage, 
		gwis_detail.is_received, 
		gwis_detail.adjustment_type, 
		gwis_detail.comments, 
		gwis_detail.manufacturer, 
		gwis_detail.dc_quantity, 
		gwis_detail.pi_quantity, 
		gwis_detail.pi_comment, 
		gwis_detail.ti_quantity, 
		gwis_detail.ti_comment, 
		gwis_detail.delivery_challan_type, 
		gwis_detail.challan_type_detail, 
		gwis_detail.driver_name, 
		gwis_detail.driver_contract, 
		gwis_detail.vehicle_reg, 
		gwis_detail.dc_no, 
		gwis_detail.dc_date, 
		gwis_detail.invoice, 
		gwis_detail.po_quantity, 
		gwis_detail.actual_rec_qty, 
		gwis_detail.field1, 
		gwis_detail.field2, 
		gwis_detail.field3, 
		gwis_detail.field4, 
		gwis_detail.field5, 
		gwis_detail.field6, 
		gwis_detail.field7, 
		gwis_detail.field8, 
		gwis_detail.field9, 
		gwis_detail.field10, 
		gwis_detail.field11, 
		gwis_detail.field12, 
		gwis_detail.field13, 
		gwis_detail.field14, 
		gwis_detail.field15, 
		gwis_detail.field16, 
		gwis_detail.field17, 
		gwis_detail.field18, 
		gwis_detail.field19, 
		gwis_detail.field20, 
		gwis_detail.gwis_adj_status, 
		gwis_detail.siv_driver_name, 
		gwis_detail.siv_contatc_number, 
		gwis_detail.siv_cnic, 
		gwis_detail.siv_weight, 
		gwis_detail.siv_no_of_cartons, 
		gwis_detail.siv_transportation_po, 
		gwis_detail.siv_tracking_no, 
		gwis_detail.grn_quantity, 
		gwis_detail.giv_quantity, 
		gwis_detail.electronic_approval, 
		gwis_detail.electronic_approval_status, 
		gwis_detail.detail_active_process, 
		gwis_detail.date_vehicle_req, 
		gwis_detail.no_of_vehicle, 
		gwis_detail.type_of_vehicle, 
		gwis_detail.no_of_cartons, 
		gwis_detail.value_of_product, 
		gwis_detail.transport_req_remarks, 
		gwis_detail.product_type_id, 
		gwis_detail.temperature_requirement, 
		gwis_detail.pi_type, 
		gwis_detail.sbtr_dc_rec, 
		gwis_detail.siv_mode_of_transport, 
		gwis_detail.siv_name_of_transporter, 
		gwis_detail.siv_vehicle_type, 
		gwis_detail.siv_vehicle_plate_no, 
		gwis_detail.wh_location, 
		gwis_detail.shipment_temprature, 
		gwis_detail.`storage`) 
		SELECT $new_stk_id, 
		gwis_detail.batch_id, 
		gwis_detail.fk_unit_id, 
		gwis_detail.quantity, 
		gwis_detail.temp, 
		gwis_detail.vvm_stage, 
		gwis_detail.is_received, 
		$adj_type, 
		'$comment', 
		gwis_detail.manufacturer, 
		gwis_detail.dc_quantity, 
		gwis_detail.pi_quantity, 
		gwis_detail.pi_comment, 
		$tiqty, 
		gwis_detail.ti_comment, 
		gwis_detail.delivery_challan_type, 
		gwis_detail.challan_type_detail, 
		gwis_detail.driver_name, 
		gwis_detail.driver_contract, 
		gwis_detail.vehicle_reg, 
		gwis_detail.dc_no, 
		gwis_detail.dc_date, 
		gwis_detail.invoice, 
		gwis_detail.po_quantity, 
		gwis_detail.actual_rec_qty, 
		gwis_detail.field1, 
		gwis_detail.field2, 
		gwis_detail.field3, 
		gwis_detail.field4, 
		gwis_detail.field5, 
		gwis_detail.field6, 
		gwis_detail.field7, 
		gwis_detail.field8, 
		gwis_detail.field9, 
		gwis_detail.field10, 
		gwis_detail.field11, 
		gwis_detail.field12, 
		gwis_detail.field13, 
		gwis_detail.field14, 
		gwis_detail.field15, 
		gwis_detail.field16, 
		gwis_detail.field17, 
		gwis_detail.field18, 
		gwis_detail.field19, 
		gwis_detail.field20, 
		gwis_detail.gwis_adj_status, 
		gwis_detail.siv_driver_name, 
		gwis_detail.siv_contatc_number, 
		gwis_detail.siv_cnic, 
		gwis_detail.siv_weight, 
		gwis_detail.siv_no_of_cartons, 
		gwis_detail.siv_transportation_po, 
		gwis_detail.siv_tracking_no, 
		gwis_detail.grn_quantity, 
		$giv_qty, 
		gwis_detail.electronic_approval, 
		gwis_detail.electronic_approval_status, 
		gwis_detail.detail_active_process, 
		gwis_detail.date_vehicle_req, 
		gwis_detail.no_of_vehicle, 
		gwis_detail.type_of_vehicle, 
		gwis_detail.no_of_cartons, 
		gwis_detail.value_of_product, 
		gwis_detail.transport_req_remarks, 
		gwis_detail.product_type_id, 
		gwis_detail.temperature_requirement, 
		gwis_detail.pi_type, 
		gwis_detail.sbtr_dc_rec, 
		gwis_detail.siv_mode_of_transport, 
		gwis_detail.siv_name_of_transporter, 
		gwis_detail.siv_vehicle_type, 
		gwis_detail.siv_vehicle_plate_no, 
		gwis_detail.wh_location, 
		gwis_detail.shipment_temprature, 
		gwis_detail.`storage` FROM gwis_detail WHERE pk_id = $detail_id";
		//echo $qry;
		//exit;

		$this->query($qry);
		return $this->insert_id();
	}

	function update_batch_dtl_status($detail_id){
		$qry = "UPDATE stock_batch 
		SET dtl_status = 'completed'
		WHERE stock_batch.batch_id IN (SELECT A.batch_id FROM(SELECT stock_batch.batch_id FROM stock_batch
		INNER JOIN gwis_detail ON gwis_detail.batch_id = stock_batch.batch_id 
		WHERE
			gwis_detail.pk_id = $detail_id)A)";

		return $this->query($qry);
	}
}

?>
