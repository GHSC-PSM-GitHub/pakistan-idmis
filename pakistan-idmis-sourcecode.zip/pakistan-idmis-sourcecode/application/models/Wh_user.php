<?php

//require_once 'database.php';

/**
 * clsStockMaster
 * @package classes
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
// If it's going to need the database, then it's
// probably smart to require it before we start.
class Wh_user extends Base_model {

    // table name
    protected static $table_name = "wh_user";
    // db connection
    private $conn;
    //db fileds
    protected static $db_fields = array('sysusrrec_id', 'wh_id');
    public $wh_user_id;
    public $sysusrrec_id;
    public $wh_id;
    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all() {

        $qry = "SELECT
                    wh_user.wh_user_id,
                    wh_user.wh_name AS warehouse_name,
                    wh_user.dist_id,
                    wh_user.prov_id,
                    wh_user.stkid,
                    wh_user.hf_cat_id,
                    wh_user.hf_type_id,
                    warehouse_types.type_name AS facility_type_name,
                    p.LocName AS province_name,
                    d.LocName AS district_name
            FROM
                    wh_user
            LEFT JOIN warehouse_types ON wh_user.hf_type_id = warehouse_types.pk_id
            LEFT JOIN tbl_locations AS p ON wh_user.prov_id = p.PkLocID
            LEFT JOIN tbl_locations AS d ON wh_user.dist_id = d.PkLocID 
            WHERE
                    wh_user.hf_cat_id = 1
        ";
        return $this->query($qry);
    }
    
    public function getuserid($stkid) {
        $qry = "SELECT * FROM " . static::$table_name . " WHERE sysusrrec_id = '$stkid'";
//        print_r($qry);exit;
        return $this->query($qry);
    }
    
    public function get_assign_wh_info($id) {
        $qry = "SELECT
                        *
                FROM
                        wh_user
                WHERE
                        wh_user.sysusrrec_id = " . $id."";
        return $this->query($qry);
    } 
    
    public function deleteuseridy($stkid) {
        $qry = "DELETE FROM " . static::$table_name . " WHERE sysusrrec_id = '$stkid'";
//        print_r($qry);exit;
        return $this->query($qry);
    }
    
    public function gethf() {

        $qry = "SELECT
        * FROM
        wh_user WHERE prov_id = '8'
        ";
//        echo $qry;exit;
        return $this->query($qry);
    }
    
    public function get_max_id() {

        $qry = "SELECT
        MAX(wh_user_id) AS wh_user_id
        FROM
        wh_user 
        ";
//        echo $qry;exit;
        return $this->query($qry);
    }
    
    public function get_health_facility() {

        $qry = "SELECT
        *
        FROM
        wh_user WHERE prov_id = 3 
        ";
        return $this->query($qry);
    }
    
    public function get_district() {

        $qry = "SELECT
        *
        FROM
        locations WHERE parent_id = 3 AND location_level = 4 
        ";
        return $this->query($qry);
    }
    

    public function find_by_id($id = 0) {
        //select query
        $strSql = "SELECT * FROM " . static::$table_name . " WHERE wh_user_id={$id} LIMIT 1";
        //query result
        return $this->query($strSql);
    }
    
    public function find_by_idwarehouse() {
        $qry = "SELECT
                        tbl_locations.LocName AS province,
                        stakeholder.stkname AS stakeholder,
                        wh_user.wh_user_id,
                        wh_user.wh_name,
                        wh_user.dist_id,
                        wh_user.prov_id,
                        wh_user.stkid,
                        wh_user.created_by,
                        wh_user.modified_date,
                        wh_user.modified_by,
                        wh_user.created_date,
                        wh_user.is_default,
                        wh_user.hf_cat_id,
                        wh_user.hf_type_id,
                        wh_user.wh_type_id 
                FROM
                        wh_user
                        LEFT JOIN tbl_locations ON wh_user.prov_id = tbl_locations.PkLocID
                        LEFT JOIN stakeholder ON wh_user.stkid = stakeholder.stkid 
                WHERE
                        wh_user.hf_cat_id = 2 
                        AND wh_user.is_default = 1";
        return $this->query($qry);
    }
    
    public function find_by_idcenter() {
        $qry = "SELECT
                    *
                FROM 
                    wh_user
                WHERE wh_user.hf_cat_id = 1
                AND is_default = 1";
        return $this->query($qry);
    }
    
    public function find_edit_data($id = 0) {
        //select query
        $strSql = "SELECT
                    wh_user.wh_user_id,
                    wh_user.wh_name AS warehouse_name,
                    wh_user.dist_id,
                    wh_user.prov_id,
                    wh_user.stkid,
                    wh_user.hf_cat_id,
                    wh_user.hf_type_id,
                    hr_info.`name`,
                    hr_info.contact_no,
                    hr_info.email,
                    hr_info.cnic,
                    hr_info.gender,
                    hr_info.desg,
                    hr_info.hr_type
                FROM
                        wh_user
                LEFT JOIN hr_info ON hr_info.hr_id = wh_user.wh_user_id
                WHERE
                        wh_user.wh_user_id = '".$id."'";
        //query result
        return $this->query($strSql);
    }
    
    public function find_active() {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry.=" WHERE is_default=1";
//        print_r($qry);exit;
        return $this->query($qry);
    }
    
    public function find_by_category($id = 0) {
        //select query
        $strSql = "SELECT * FROM " . static::$table_name . " WHERE hf_cat_id={$id} ";
        //query result
        return $this->query($strSql);
    }

    public function find_by_location_id($id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE locid =" . $id;
        return $this->query($qry);
    }

    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if ($this->$field != '') {
                    $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.
        return isset($this->wh_user_id) ? $this->update() : $this->create();
    }

    public function deactivate($id, $status) {
        $qry = "UPDATE " . static::$table_name . " SET is_default=$status where wh_user_id=$id";
//        print_r($qry);exit;
        $this->query($qry);
    }
    
    public function deactivate_supplier($id, $status) {
        $qry = "UPDATE " . static::$table_name . " SET is_default=$status where wh_user_id=$id";
//        print_r($qry);exit;
        $this->query($qry);
    }
    
    public function deactivate_center($id, $status) {
        $qry = "UPDATE " . static::$table_name . " SET is_default=$status where wh_user_id=$id";
//        print_r($qry);exit;
        $this->query($qry);
    }

    public function deactivate_warehouse($id, $status) {
        $qry = "UPDATE " . static::$table_name . " SET is_default=$status where wh_user_id=$id";
//        print_r($qry);exit;
        $this->query($qry);
    }
    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create() {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
//        echo $sql;
        if ($this->query2($sql)) {
            return true;
        } else {
            return false;
        }
    }
    
    public function updatesupplier($stakeholder_id) {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE stkid=" . $stakeholder_id;
        $this->query2($sql);
        return true;
    }
    /**
     * update
     * @global type $this
     * @return type
     */
    public function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE wh_user_id=" . $this->escape_value($this->wh_user_id);
        $this->query2($sql);
        return true;
    }

    public function get_count() {
        $sql = "SELECT
        count(wh_user.wh_user_id) as total
        FROM
        wh_user
        ";
        return $this->query($sql);
    }

    public function find_suppliers() {
        $qry = "SELECT
wh_user.*
FROM
wh_user
WHERE
wh_user.hf_cat_id = 3
               ";
        return $this->query($qry);
    }
    
    public function get_all_hf($dist_id) {
        $qry = "SELECT * FROM " . static::$table_name . " WHERE province_id = '3' AND district_id='".$dist_id."' AND facility_type_id NOT IN ('3')"; 
//        $qry.=" WHERE status=1 AND parent_id IS NOT NULL ORDER BY location_level ASC";
//        print_r($qry);exit;
        $result = $this->query($qry);
        if (!empty($result))
            return $result->result_array();
    }
    
}
