<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Requisition_model extends CI_Model {

    function get_products() {
//        $prod = array('177', 'Todd', 'James');
        $this->db->select('itminfo_tab.itm_name,itminfo_tab.method_type,itminfo_tab.itm_id,itminfo_tab.itmrec_id');
        $this->db->from('itminfo_tab');
        $this->db->where_in('itm_id', array('177', '181', '184', '178', '50', '60', '182', '750', '183'));
        $query = $this->db->get();
//      echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function get_data() {
        $this->db->select('itminfo_tab.itm_id');
        $this->db->from('stakeholder_item');
        $this->db->join('itminfo_tab', 'product_id = itminfo_tab.itm_id', 'INNER');
        $this->db->where('stk_id', $_SESSION['stakeholder_id']);
        $query = $this->db->get();
//        echo $this->db->last_query(); exit;
        $result = $query->result_array();
//        var_dump($result);die;
        $itm_ids = implode(' ,', array_column($result, 'itm_id'));
//        echo $itm_ids;die;
        $this->db->select('tbl_wh_data.wh_obl_a,tbl_wh_data.wh_obl_c,tbl_wh_data.wh_received,tbl_wh_data.wh_issue_up,tbl_wh_data.wh_cbl_c,tbl_wh_data.wh_cbl_a, tbl_wh_data.item_id');
        $this->db->from('tbl_wh_data');
        $this->db->where('wh_id', $_SESSION['warehouse_id']);
//        $this->db->where_in('item_id', $itm_ids);
        $this->db->where('lvl', 1705);
        $this->db->where('report_month', 02);
        $this->db->where('report_year', 2022);
        $query = $this->db->get();
//                 echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function insert($formData, $checked_items) {
        $this->db->select('COUNT(clr_master.requisition_num) AS Num');
        $this->db->from('clr_master');
        $this->db->join('clr_details', 'clr_details.pk_master_id = clr_master.pk_id', 'INNER');
        $this->db->where('clr_master.wh_id', $formData['wh_id']);
        $this->db->where('clr_master.date_to', $formData['date_to']);
        $this->db->where('clr_master.approval_status', 'pending');
        $this->db->where_in('clr_details.itm_id', $checked_items);
        $query = $this->db->get()->result_array();
        $insert_id = '';
        if (empty($query[0]['Num'])) {
            $this->db->insert('clr_master', $formData);
            $insert_id = $this->db->insert_id();
//            echo $this->db->last_query(); exit;
        }
        return $insert_id;
    }

    function get_provinces() {
        $this->db->select('tbl_locations.PkLocID AS prov_id,tbl_locations.LocName AS prov_title');
        $this->db->from('tbl_locations');
        $this->db->where('LocLvl', 2);
        $this->db->where('tbl_locations.PkLocID', $_SESSION['province_id']);
        $this->db->where('parentid IS NOT NULL');
        $query = $this->db->get();
//                 echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function get_districts() {
        $this->db->select('tbl_locations.PkLocID,tbl_locations.LocName');
        $this->db->from('tbl_locations');
        if (empty($_SESSION['user_level']) || $_SESSION['user_level'] == 2) {
            $this->db->where('ParentID', $_SESSION['province_id']);
            $this->db->where('LocLvl', 3);
        } else if ($_SESSION['user_level'] == 3) {
            $this->db->where('PkLocID', $_SESSION['district_id']);
        } else if (isset($_SESSION['province_id'])) {
            $this->db->where('ParentID', $_SESSION['province_id']);
            $this->db->where('LocLvl', 3);
        } else {
            $this->db->where('LocLvl', 3);
        }
        $query = $this->db->get();
//                 echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function check_requisition_num() {
        $this->db->select('MAX(clr_master.requisition_num) AS requisition_num');
        $this->db->from('clr_master');
        $query = $this->db->get();
//                 echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function insert_master_log($formData_log) {
        $query = $this->db->insert('clr_master_log', $formData_log);
//        echo $this->db->last_query(); exit;
        return $query;
    }

    function insert_stock_details($formData_details) {

        $query = $this->db->insert('clr_details', $formData_details);
//        echo $this->db->last_query(); exit;
        return $query;
    }

    function search_requisition() {
        $this->db->select('stakeholder.stkname,DATE_FORMAT(clr_master.date_from, "%b-%Y") as date_from,DATE_FORMAT(clr_master.date_to, "%b-%Y") as date_to,clr_master.requested_on,clr_master.pk_id,clr_master.requisition_num,clr_master.wh_id,clr_master.fk_stock_id,clr_master.approval_status, MONTH (clr_master.date_to) AS clrMonth, YEAR (clr_master.date_to) AS clrYear, tbl_warehouse.wh_type_id, tbl_warehouse.wh_name, tbl_locations.LocName, users.login_id, users.username');
        $this->db->from('clr_master');
        $this->db->join('stakeholder', 'clr_master.stk_id = stakeholder.stkid', 'INNER');
        $this->db->join('tbl_warehouse', 'clr_master.wh_id = tbl_warehouse.wh_id', 'INNER');
        $this->db->join('tbl_locations', 'tbl_warehouse.dist_id = tbl_locations.PkLocID', 'INNER');
        $this->db->join('clr_details', 'clr_details.pk_master_id = clr_master.pk_id', 'INNER');
        $this->db->join('users', 'clr_master.requested_by = users.pk_id', 'INNER');
        $this->db->where('clr_master.wh_id', $_SESSION['warehouse_id']);
        $this->db->group_by('clr_master.requisition_num');
        $query = $this->db->get();
//                 echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function search_distribution_plan_provincial() {
        $this->db->select('clr_master.date_to,clr_master.date_from,YEAR(clr_master.date_to) as year,MONTH(clr_master.date_to) as month,count(DISTINCT tbl_warehouse.dist_id) as dist,count(*) as total');
        $this->db->from('clr_master');
        $this->db->join('tbl_warehouse', 'clr_master.wh_id = tbl_warehouse.wh_id', 'INNER');
        $this->db->where(' clr_master.stk_id', 1705);
        $this->db->group_by('YEAR (clr_master.date_to)');
        $this->db->group_by('MONTH(clr_master.date_to)');
        $query = $this->db->get();
//                 echo $this->db->last_query(); exit;
        return $query->result_array();
    }

    function get_view_requisition_data() {
        $qry = "SELECT
				clr_master.requisition_num,
				clr_master.date_from,
				clr_master.date_to,
				clr_master.approval_status as master_approval_status,
				clr_details.approval_status as detail_approval_status,
				clr_details.pk_id,
				clr_details.pk_master_id,
				clr_details.avg_consumption,
				clr_details.soh_dist,
				clr_details.soh_field,
				clr_details.total_stock,
				clr_details.desired_stock,
				clr_details.replenishment,
				clr_details.qty_req_dist_lvl1,
                                clr_details.qty_req_dist_lvl2,
                                clr_details.qty_req_prov,
                                clr_details.qty_req_central,
                                clr_details.remarks_dist_lvl1,
                                clr_details.remarks_dist_lvl2,
                                clr_details.remarks_prov,
                                clr_details.remarks_central,
                                clr_details.sale_of_last_month,
                                clr_details.sale_of_last_3_months,
				DATE_FORMAT(clr_master.requested_on, '%d/%m/%Y') AS requested_on,
				itminfo_tab.itm_name,
				itminfo_tab.itm_id,
				itminfo_tab.itmrec_id,
				itminfo_tab.itm_type,
				itminfo_tab.generic_name,
				itminfo_tab.method_type
			FROM
				clr_master
				INNER JOIN clr_details ON clr_details.pk_master_id = clr_master.pk_id
				INNER JOIN itminfo_tab ON clr_details.itm_id = itminfo_tab.itm_id
			WHERE
				clr_master.pk_id = " . $id;
        $query = $this->$qry->get();
//      echo $this->db->last_query(); exit;
        return $query->result_array();
    }

}

?>
