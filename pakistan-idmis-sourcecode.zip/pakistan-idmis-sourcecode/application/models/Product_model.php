<?php
class Product_model extends Base_model {

    protected static $table_name = "product";
    private $conn;
    protected static $db_fields = array('product_name','generic_name_id','generic_name','strength','strength_id','method_type','method_type_id','manufacturer','manufacturer_id','category','category_id','sub_category','sub_category_id','registration_number','barcode','gtin','description','products_in_packet','packet_in_cartons','status','issuance_limit','daily_units_in_single_item',"disease_id","from_weight","to_weight","from_year","to_year","comments","species_id","treatment_id","pregnant_id","pregnant_stage","method_type_name","dose_id","tablet_id","times_a_day","dose_a_day","no_of_days","formula_or_hardcode","quantity");
    public $pk_id;
    public $product_name;
    public $generic_name_id;
    public $generic_name;
    public $strength;
    public $strength_id;
    public $method_type;
    public $method_type_id;
    public $manufacturer;
    public $manufacturer_id;
    public $category;
    public $category_id;
    public $sub_category;
    public $sub_category_id;
    public $registration_number;
    public $barcode;
    public $gtin;
    public $description;
    public $products_in_packet;
    public $packet_in_cartons;
    public $status;
    public $issuance_limit;
    public $daily_units_in_single_item;
    public $disease_id;
    public $from_weight;
    public $to_weight;
    public $from_year;
    public $to_year;
    public $comments;
    public $species_id;
    public $treatment_id;
    public $pregnant_id;
    public $pregnant_stage;
    public $method_type_name;
    public $dose_id;
    public $tablet_id;
    public $times_a_day;
    public $dose_a_day;
    public $no_of_days;
    public $formula_or_hardcode;
    public $quantity;
    
    public function create_stakeholder_item($formArray){
        $this->db->insert('stakeholder_item', $formArray);
        $insert_id = $this->db->insert_id();
        return $insert_id;
    }//end create_stakeholder_item function

    public function find_all() {
        $qry = "SELECT * FROM " . static::$table_name;  
//        print_r($qry);exit;
        return $this->query($qry);
    }
    
    public function find_name_by_id($id) {
        $qry = "SELECT product_name FROM " . static::$table_name; 
        $qry .= " WHERE pk_id=" . $id;
        $data = $this->query($qry);
        if(!empty($data)){
            $result = $data->result_object();
            return $result[0]->product_name;
        }
    }

    
    public function get_combo() {
        $qry = "SELECT pk_id as `key`, product_name as `value` FROM " . static::$table_name." ORDER BY product_name";
        return $this->query($qry);
    }
    
    public function get_species_normal_one($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$weight_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 5 . "
                AND product.to_weight <= " . 10 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year <= " . $age_id . "";
//        echo $qry;exit;
        return $this->query($qry);
    }
    public function get_species_normal_two($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$weight_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 11 . "
                AND product.to_weight <= " . 18 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 1 . "
                AND product.to_year <= " . 4 . "";   
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_normal_three($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$weight_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 19 . "
                AND product.to_weight <= " . 24 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 5 . "
                AND product.to_year <= " . 7 . "";  
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_normal_four($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$weight_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 25 . "
                AND product.to_weight <= " . 50 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 8 . "
                AND product.to_year <= " . 13 . "";  
//        echo $qry;        exit();
        return $this->query($qry);
    }
    public function get_species_normal_five($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$weight_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 50 . "   
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 14 . "";
//        echo $qry;
        return $this->query($qry);
    }
        
    public function get_species_pv_one($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 5 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.to_weight <= " . 10 . "
                AND product.from_year <= " . $age_id . "";
//        echo $qry;exit;
        return $this->query($qry);
    }
    public function get_species_pv_two($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 11 . "
                AND product.to_weight <= " . 18 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 1 . "
                AND product.to_year <= " . 4 . "";   
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pv_three($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 19 . "
                AND product.to_weight <= " . 24 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 5 . "
                AND product.to_year <= " . 7 . "";  
//        echo $qry;exit;
        return $this->query($qry);
    }
    public function get_species_pv_four($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 25 . "
                AND product.to_weight <= " . 50 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 8 . "
                AND product.to_year <= " . 13 . "";  
//        echo $qry;        exit();
        return $this->query($qry);
    }
    public function get_species_pv_five($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 50 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 14 . "";
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pv_six($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 5 . "
                AND product.to_weight <= " . 14 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.to_year < " . 3 . "";  
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pv_seven($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 15 . "
                AND product.to_weight <= " . 24 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 3 . "
                AND product.to_year <= " . 8 . "";  
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pv_eight($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 25 . "
                AND product.to_weight <= " . 34 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 8 . "
                AND product.to_year <= " . 12 . "";  
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pv_nine($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 35 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 12 . "";
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pv_ten($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$dose_kg) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE  product.species_id = " . $species_id . "
                AND product.pregnant_id = " . $pregnant_id . "
                AND product.treatment_id = " . $fs_line_id . "";
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pv_eleven($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$dose_kg) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.species_id = " . $species_id . "
                AND product.pregnant_id = " . $pregnant_id . "
                AND product.treatment_id = " . $fs_line_id . "";
//        echo $qry;
        return $this->query($qry);
    }
    
    public function get_species_mix_one($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 5 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.to_weight <= " . 14 . "
                AND product.to_year < " . 3 . "";
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_mix_two($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 15 . "
                AND product.to_weight <= " . 18 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 3 . "
                AND product.to_year <= " . 5 . "";   
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_mix_three($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 19 . "
                AND product.to_weight <= " . 24 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 6 . "
                AND product.to_year <= " . 8 . "";  
//        echo $qry;exit;
        return $this->query($qry);
    }
    public function get_species_mix_four($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 25 . "
                AND product.to_weight <= " . 34 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 9 . "
                AND product.to_year <= " . 12 . ""; 
//        echo $qry;        exit();
        return $this->query($qry);
    }
    public function get_species_mix_five($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 35 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 13 . "";  
//        echo $qry;        exit();
        return $this->query($qry);
    }
    public function get_species_mix_six($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 5 . "
                AND product.to_weight <= " . 8 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 0 . ""; 
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_mix_seven($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 9 . "
                AND product.to_weight <= " . 16 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 0 . "";     
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_mix_eight($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 17 . "
                AND product.to_weight <= " . 24 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 0 . "";  
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_mix_nine($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 25 . "
                AND product.to_weight <= " . 35 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 0 . ""; 
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_mix_ten($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 36 . "
                AND product.to_weight <= " . 74 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 0 . ""; 
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_mix_eleven($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 75 . "
                AND product.to_weight <= " . 100 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 0 . ""; 
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_mix_twelve($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE  product.species_id = " . $species_id . "
                AND product.pregnant_id = " . $pregnant_id . "
                AND product.pregnant_stage = " . $pregnant_stage . "
                AND product.treatment_id = " . $fs_line_id . "";
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_mix_thirteen($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE  product.species_id = " . $species_id . "
                AND product.pregnant_id = " . $pregnant_id . "
                AND product.pregnant_stage = " . $pregnant_stage . "
                AND product.treatment_id = " . $fs_line_id . "";
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_mix_fourteen($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE  product.species_id = " . $species_id . "
                AND product.pregnant_id = " . $pregnant_id . "
                AND product.pregnant_stage = " . $pregnant_stage . "
                AND product.treatment_id = " . $fs_line_id . "";
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_mix_fifteen($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE  product.species_id = " . $species_id . "
                AND product.pregnant_id = " . $pregnant_id . "
                AND product.pregnant_stage = " . $pregnant_stage . "
                AND product.treatment_id = " . $fs_line_id . "";
//        echo $qry;
        return $this->query($qry);
    }
    
    
    
    
    
    
    public function get_species_pf_one($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 5 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.to_weight <= " . 14 . "
                AND product.to_year < " . 3 . "";
//        echo $qry;exit;
        return $this->query($qry);
    }
    public function get_species_pf_two($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 15 . "
                AND product.to_weight <= " . 24 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 3 . "
                AND product.to_year <= " . 8 . "";   
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pf_three($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 25 . "
                AND product.to_weight <= " . 34 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 8 . "
                AND product.to_year <= " . 12 . "";  
//        echo $qry;exit;
        return $this->query($qry);
    }
    public function get_species_pf_four($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 35 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 12 . "";  
//        echo $qry;        exit();
        return $this->query($qry);
    }
    public function get_species_pf_five($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 5 . "
                AND product.to_weight <= " . 8 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 0 . ""; 
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pf_six($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 9 . "
                AND product.to_weight <= " . 16 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 0 . "";     
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pf_seven($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 17 . "
                AND product.to_weight <= " . 24 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 0 . "";  
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pf_eight($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 25 . "
                AND product.to_weight <= " . 35 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 0 . ""; 
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pf_nine($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 36 . "
                AND product.to_weight <= " . 74 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 0 . ""; 
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pf_ten($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE product.from_weight >= " . 75 . "
                AND product.to_weight <= " . 100 . "
                AND product.species_id = " . $species_id . "
                AND product.treatment_id = " . $fs_line_id . "
                AND product.from_year >= " . 0 . ""; 
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pf_eleven($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE  product.species_id = " . $species_id . "
                AND product.pregnant_id = " . $pregnant_id . "
                AND product.pregnant_stage = " . $pregnant_stage . "
                AND product.treatment_id = " . $fs_line_id . "";
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pf_twelve($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE  product.species_id = " . $species_id . "
                AND product.pregnant_id = " . $pregnant_id . "
                AND product.pregnant_stage = " . $pregnant_stage . "
                AND product.treatment_id = " . $fs_line_id . "";
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pf_thirteen($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE  product.species_id = " . $species_id . "
                AND product.pregnant_id = " . $pregnant_id . "
                AND product.pregnant_stage = " . $pregnant_stage . "
                AND product.treatment_id = " . $fs_line_id . "";
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_pf_fourteen($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$pregnant_stage) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE  product.species_id = " . $species_id . "
                AND product.pregnant_id = " . $pregnant_id . "
                AND product.pregnant_stage = " . $pregnant_stage . "
                AND product.treatment_id = " . $fs_line_id . "";
//        echo $qry;
        return $this->query($qry);
    }
    
    
    
    
    public function get_species_complicated_one($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$weight_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE  product.species_id = " . $species_id . "
                AND product.from_weight >= " . 0 . "
                AND product.to_weight <= " . 20 . "";
//        echo $qry;
        return $this->query($qry);
    }
    public function get_species_complicated_two($species_id,$gender_id,$age_id,$pregnant_id,$type_id,$fs_line_id,$weight_id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE  product.species_id = " . $species_id . "
                AND product.from_weight >= " . 21 . "";
//        echo $qry;
        return $this->query($qry);
    }
    
    
    
    
     public function find_active() {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry.=" WHERE status=1";
//        print_r($qry);exit;
        return $this->query($qry);
    }

	public function get_stk_products(){
		$this->db->select(static::$table_name. '.*');
		$this->db->from(static::$table_name);
		$this->db->join('stakeholder_item', 'stakeholder_item.product_id = '. static::$table_name.'.pk_id', 'left');
		$this->db->where_in ('stakeholder_item.stk_id', $this->get_user_stakeholders());
		$this->db->where(static::$table_name. '.status', '1');
		$result = $this->db->get();
//                 echo $this->db->last_query(); exit;
		return $result->result_array();
	}

    public function find_by_id($id) {
        $qry = "SELECT * FROM " . static::$table_name; 
        $qry .= " WHERE pk_id=" . $id;
        return $this->query($qry);
    }
    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    public function get_list(){
        $qry = "SELECT * FROM " . static::$table_name; 
        $result =  $this->query($qry);
        if (!empty($result)) {
            foreach ($result->result_object() as $row) {
                $searched_list[$row->pk_id]=(array)$row;
            }
        }
        return $searched_list;
    }
    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if ($this->$field != '') {
                $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.
        return isset($this->pk_id) ? $this->update() : $this->create();
    }
    
    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create() {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
//        echo $sql;
        if ($this->query($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    /**
     * update
     * @global type $this
     * @return type
     */
    public function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        $this->query($sql);
        return true;
    }
    public function deactivate($id,$status){
        $qry="UPDATE ". static::$table_name. " SET status=$status where pk_id=$id";
        $this->query($qry);
    }
     public function get_warehouse_products() {
        $qry = "SELECT DISTINCT
        product.product_name,
        stock_batch.item_id,
        daily_units_in_single_item,
        issuance_limit
        FROM
        product
        INNER JOIN stock_batch ON product.pk_id = stock_batch.item_id
        WHERE
        stock_batch.wh_id = ".$this->session->userdata('warehouse_id')."
        AND stock_batch.Qty > 0
        ORDER BY
        product.product_name ASC"; 
        return $this->query($qry);
    }
     public function get_warehouse_stock() {
        $qry = "SELECT 
product.product_name,
product.daily_units_in_single_item,
product.issuance_limit,
stock_batch.batch_no,
stock_batch.batch_id,
stock_batch.batch_expiry,
stock_batch.Qty,
stock_batch.wh_id,
stock_batch.item_id
        FROM
        product
        INNER JOIN stock_batch ON product.pk_id = stock_batch.item_id
        WHERE
        stock_batch.wh_id = ".$this->session->userdata('warehouse_id')."
        AND stock_batch.Qty > 0
        ORDER BY
        product.product_name ASC,
        
stock_batch.batch_no";
        return $this->query($qry);
    }
    
     public function get_tran_types() {
        $qry = "SELECT
                    transaction_types.trans_id,
                    transaction_types.trans_type,
                    transaction_types.trans_nature
                    FROM
                    transaction_types
                    WHERE
                    transaction_types.is_adjustment = 1
                    "; 
        return $this->query($qry);
    }
    
    public function get_specific_tran_types() {
        $qry = "SELECT
                transaction_types.trans_id,
                transaction_types.trans_type,
                transaction_types.trans_nature
                FROM
                transaction_types
                WHERE
                transaction_types.is_adjustment = 1
                AND trans_id IN (7,10)"; 
        return $this->query($qry);
    }
}
