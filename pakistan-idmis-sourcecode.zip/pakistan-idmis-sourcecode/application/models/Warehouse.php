<?php

//require_once 'database.php';

/**
 * clsStockMaster
 * @package classes
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
// If it's going to need the database, then it's
// probably smart to require it before we start.
class Warehouse extends Base_model {

    // table name
    protected static $table_name = "tbl_warehouse";
    // db connection
    private $conn;
    //db fileds
    protected static $db_fields = array('wh_name', 'dist_id', 'prov_id',  'stkid','stkofficeid', 'hf_cat_id', 'hf_type_id', 'is_active', 'created_by', 'created_date', 'modified_by', 'modified_date', 'stakeholder_name','wh_type_id');
    public $wh_id;
    public $warehouse_name;
    public $district_id;
    public $province_id;
    public $stkid;
    public $stkofficeid;
    public $hf_cat_id;
    public $hf_type_id;
    public $is_active;
    public $created_by;
    public $created_date;
    public $modified_by;
    public $modified_date;
    public $wh_type_id;
    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all($stkid = '') {
        // echo $stkid;die;
        $this->db->select('tbl_warehouse.wh_id, tbl_warehouse.wh_name AS warehouse_name, tbl_warehouse.dist_id, tbl_warehouse.prov_id, tbl_warehouse.stkid, tbl_warehouse.hf_cat_id, tbl_warehouse.hf_type_id, tbl_warehouse.is_active, warehouse_types.type_name AS facility_type_name, p.LocName AS province_name, d.LocName AS district_name');
        $this->db->from('tbl_warehouse');
        $this->db->join('warehouse_types', 'tbl_warehouse.hf_type_id = warehouse_types.pk_id', 'left');
        $this->db->join('tbl_locations AS p', 'tbl_warehouse.prov_id = p.PkLocID', 'left');
        $this->db->join('tbl_locations AS d', 'tbl_warehouse.dist_id = d.PkLocID', 'left');
        if ($stkid != '') {
            $this->db->where('tbl_warehouse.stkid', $stkid);
        }
        $this->db->where_in('tbl_warehouse.hf_cat_id', [1, 2]);
        $this->db->get();
        $qry = $this->db->last_query();
        return $this->query($qry);
    }
    
    public function gethf() {

        $qry = "SELECT
        * FROM
        tbl_warehouse WHERE prov_id = '8'
        ";
//        echo $qry;exit;
        return $this->query($qry);
    }
    
    public function get_max_id() {

        $qry = "SELECT
        MAX(wh_id) AS wh_id
        FROM
        tbl_warehouse 
        ";
//        echo $qry;exit;
        return $this->query($qry);
    }
    
    public function get_health_facility() {

        $qry = "SELECT
        *
        FROM
        tbl_warehouse WHERE prov_id = 3 
        ";
        return $this->query($qry);
    }
    
    public function get_district() {

        $qry = "SELECT
        *
        FROM
        locations WHERE parent_id = 3 AND location_level = 4 
        ";
        return $this->query($qry);
    }
    

    public function find_by_id($id = 0) {
        //select query
        $strSql = "SELECT * FROM " . static::$table_name . " WHERE wh_id={$id} LIMIT 1";
        //query result
        return $this->query($strSql);
    }
    
    public function find_by_idwarehouse() {
        $qry = "SELECT
                        tbl_locations.LocName AS province,
                        stakeholder.stkname AS stakeholder,
                        tbl_warehouse.wh_id,
                        tbl_warehouse.wh_name,
                        tbl_warehouse.dist_id,
                        tbl_warehouse.prov_id,
                        tbl_warehouse.stkid,
                        tbl_warehouse.created_by,
                        tbl_warehouse.modified_date,
                        tbl_warehouse.modified_by,
                        tbl_warehouse.created_date,
                        tbl_warehouse.is_active,
                        tbl_warehouse.hf_cat_id,
                        tbl_warehouse.hf_type_id,
                        tbl_warehouse.wh_type_id 
                FROM
                        tbl_warehouse
                        LEFT JOIN tbl_locations ON tbl_warehouse.prov_id = tbl_locations.PkLocID
                        LEFT JOIN stakeholder ON tbl_warehouse.stkid = stakeholder.stkid 
                WHERE
                        tbl_warehouse.hf_cat_id = 2 
                        AND tbl_warehouse.is_active = 1";
        return $this->query($qry);
    }


    
    public function find_by_user_idwarehouse() {
        $qry = "SELECT
                DISTINCT
                        tbl_warehouse.wh_id,
                        tbl_warehouse.wh_name,
                        tbl_warehouse.dist_id,
                        tbl_warehouse.prov_id,
                        tbl_warehouse.stkid,
                        tbl_warehouse.created_by,
                        tbl_warehouse.modified_date,
                        tbl_warehouse.modified_by,
                        tbl_warehouse.created_date,
                        tbl_warehouse.is_active,
                        tbl_warehouse.hf_cat_id,
                        tbl_warehouse.hf_type_id,
                        tbl_warehouse.wh_type_id 
                FROM
                        tbl_warehouse
                        INNER JOIN wh_user ON tbl_warehouse.wh_id = wh_user.wh_id
                        INNER JOIN users ON wh_user.sysusrrec_id = users.pk_id 
                WHERE
                        tbl_warehouse.hf_cat_id = 2 
                        AND tbl_warehouse.is_active = 1";
        return $this->query($qry);
    }

    function find_district_warehouses_of_province($user_prov) {
                $strSql = "SELECT
                    tbl_warehouse.wh_name,
                    tbl_warehouse.wh_id,
                    stakeholder.lvl,
                    tbl_warehouse.dist_id 
                FROM
                    tbl_warehouse
                    INNER JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid 
                WHERE
                    tbl_warehouse.prov_id = $user_prov 
                    AND tbl_warehouse.stkid = " . $_SESSION['stakeholder_id'] . "
                    AND stakeholder.lvl = 3
                    AND tbl_warehouse.prov_id = ".$user_prov ."
                ORDER BY
                    tbl_warehouse.wh_rank";
                return $this->query($strSql);
    }

    function find_health_facility_warehouses_of_district($user_prov,$user_dist, $user_stk) {
      
                $strSql = "SELECT
            *
            FROM
                (
                    SELECT
                        tbl_warehouse.wh_id,
                        tbl_warehouse.wh_name,
                        stakeholder.lvl,
                        tbl_warehouse.wh_rank
                    FROM
                        tbl_warehouse 
                    INNER JOIN stakeholder ON stakeholder.stkid = tbl_warehouse.stkid
                    WHERE
                        tbl_warehouse.dist_id = '" . $user_dist . "'
                    AND tbl_warehouse.stkid = '" . $user_stk . "'
                    AND stakeholder.lvl = 7 AND
                    tbl_warehouse.is_active = 1
                ) A
            GROUP BY
                A.wh_id
            ORDER BY
                A.wh_name ASC";

               $strSql = "SELECT
                tbl_warehouse.wh_name,
                tbl_warehouse.wh_id,
                stakeholder.lvl,
                tbl_warehouse.dist_id 
            FROM
                tbl_warehouse
                INNER JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid 
            WHERE
                tbl_warehouse.prov_id = '" . $user_prov . "' 
                AND tbl_warehouse.stkid = '" . $user_stk . "' 
                AND stakeholder.lvl = 7 
                AND tbl_warehouse.dist_id = '" . $user_dist . "' 
            ORDER BY
                tbl_warehouse.wh_rank";                     
                return $this->query($strSql);
    }


    
    public function find_assign_warehouse() {
        $qry = "SELECT
                DISTINCT
                        tbl_warehouse.wh_id,
                        tbl_warehouse.wh_name,
                        tbl_warehouse.dist_id,
                        tbl_warehouse.prov_id,
                        tbl_warehouse.stkid,
                        tbl_warehouse.created_by,
                        tbl_warehouse.modified_date,
                        tbl_warehouse.modified_by,
                        tbl_warehouse.created_date,
                        tbl_warehouse.is_active,
                        tbl_warehouse.hf_cat_id,
                        tbl_warehouse.hf_type_id,
                        tbl_warehouse.wh_type_id 
                FROM
                        tbl_warehouse
                        INNER JOIN wh_user ON tbl_warehouse.wh_id = wh_user.wh_id
                        INNER JOIN users ON wh_user.sysusrrec_id = users.pk_id 
                WHERE
                        tbl_warehouse.hf_cat_id IN (1,2) 
                        AND tbl_warehouse.is_active = 1";
        return $this->query($qry);
    }
    
    public function find_by_idcenter() {
        $qry = "SELECT
                    *
                FROM 
                    tbl_warehouse
                WHERE tbl_warehouse.hf_cat_id = 1
                AND is_active = 1";
        return $this->query($qry);
    }
    
    public function find_edit_data($id = 0) {
        //select query
        $strSql = "SELECT
                    tbl_warehouse.wh_id,
                    tbl_warehouse.wh_name AS warehouse_name,
                    tbl_warehouse.dist_id,
                    tbl_warehouse.prov_id,
                    tbl_warehouse.stkid,
                    tbl_warehouse.hf_cat_id,
                    tbl_warehouse.hf_type_id,
                    hr_info.`name`,
                    hr_info.contact_no,
                    hr_info.email,
                    hr_info.cnic,
                    hr_info.gender,
                    hr_info.desg,
                    hr_info.hr_type
                FROM
                        tbl_warehouse
                LEFT JOIN hr_info ON hr_info.hr_id = tbl_warehouse.wh_id
                WHERE
                        tbl_warehouse.wh_id = '".$id."'";
        //query result
        return $this->query($strSql);
    }
    
    public function find_active() {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry.=" WHERE is_active=1";
//        print_r($qry);exit;
        return $this->query($qry);
    }
    
    public function find_by_category($id = 0) {
        //select query
        $strSql = "SELECT * FROM " . static::$table_name . " WHERE hf_cat_id={$id} ";
        //query result
        return $this->query($strSql);
    }

    public function find_by_location_id($id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE locid =" . $id;
        return $this->query($qry);
    }

    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if ($this->$field != '') {
                    $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.
        return isset($this->wh_id) ? $this->update() : $this->create();
    }

    public function deactivate($id, $status) {
        $qry = "UPDATE " . static::$table_name . " SET is_active=$status where wh_id=$id";
//        print_r($qry);exit;
        $this->query($qry);
    }
    
    public function deactivate_supplier($id, $status) {
        $qry = "UPDATE " . static::$table_name . " SET is_active=$status where wh_id=$id";
//        print_r($qry);exit;
        $this->query($qry);
    }
    
    public function deactivate_center($id, $status) {
        $qry = "UPDATE " . static::$table_name . " SET is_active=$status where wh_id=$id";
//        print_r($qry);exit;
        $this->query($qry);
    }

    public function deactivate_warehouse($id, $status) {
        $qry = "UPDATE " . static::$table_name . " SET is_active=$status where wh_id=$id";
//        print_r($qry);exit;
        $this->query($qry);
    }
    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create() {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
//        echo $sql;
        if ($this->query2($sql)) {
            return true;
        } else {
            return false;
        }
    }
    
    public function updatesupplier($stakeholder_id) {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE stkid=" . $stakeholder_id;
        $this->query2($sql);
        return true;
    }
    /**
     * update
     * @global type $this
     * @return type
     */
    public function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE wh_id=" . $this->escape_value($this->wh_id);
        $this->query2($sql);
        return true;
    }

    public function get_count() {
        $sql = "SELECT
        count(tbl_warehouse.wh_id) as total
        FROM
        tbl_warehouse
        ";
        return $this->query($sql);
    }

    public function find_suppliers() {
        $qry = "SELECT
tbl_warehouse.*
FROM
tbl_warehouse
WHERE
tbl_warehouse.hf_cat_id = 3
               ";
        return $this->query($qry);
    }
    
    public function get_all_hf($dist_id) {
        $qry = "SELECT * FROM " . static::$table_name . " WHERE province_id = '3' AND district_id='".$dist_id."' AND facility_type_id NOT IN ('3')"; 
//        $qry.=" WHERE status=1 AND parent_id IS NOT NULL ORDER BY location_level ASC";
//        print_r($qry);exit;
        $result = $this->query($qry);
        if (!empty($result))
            return $result->result_array();
    }

	public function find_all_by_fac_type_id($fac_type_id = '') {

//		$wrfac = "AND hf_type_id NOT IN (15)";
//		if(!empty($fac_type_id)){
//			$wrfac = "AND hf_type_id IN ($fac_type_id)";
//		}
		$qry = "SELECT
        tbl_warehouse.*, stakeholder.stkname
        FROM
        tbl_warehouse INNER JOIN stakeholder ON stakeholder.stkid = tbl_warehouse.stkid WHERE `is_active`=1 AND stakeholder.stkid IN (".$this->get_user_stakeholders(). ")";
//		print_r($qry);exit();
		return $this->query($qry);
	}
    
        
        
        public function get_labs() {
            /// in cmu / idsmis project , category id for labs is 25 . while in ihitc it was 5
            $qry = "SELECT
            tbl_warehouse.wh_id AS `key`,
            tbl_warehouse.wh_name AS `value` 
        FROM
            tbl_warehouse
            INNER JOIN warehouse_types ON warehouse_types.pk_id = tbl_warehouse.wh_type_id 
        WHERE
            warehouse_types.category_id = 25";
            return $this->query($qry);
        }

}
