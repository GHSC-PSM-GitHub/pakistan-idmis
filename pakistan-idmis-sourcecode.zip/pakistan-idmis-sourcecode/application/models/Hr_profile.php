<?php
class Hr_profile extends Base_model
{

    // table name
    protected static $table_name = "hr_profile";
    // db connection
    private $conn;
    //db fileds
    protected static $db_fields = array("full_name", "designation", "pmdc_number", "cnic_number", "is_active", "link_user", "warehouse_id", "hr_type_id", "hr_type", "hr_status_id","department","reg_number","pmc_expiry","pmc_category","blood_group","doj","job_band","address","pcn","email","em_contact","em_contact_no","experience","education","dob","gender","created_date");
    public $pk_id;
    public $full_name;
    public $designation;
    public $pmdc_number;
    public $cnic_number;
    public $is_active;
    public $link_user;
    public $hr_type_id;
    public $hr_type;
    public $warehouse_id;
    public $hr_status_id;
    public $department;
public $reg_number;
public $pmc_expiry;
public $pmc_category;
public $blood_group;
public $doj;
public $job_band;
public $address;
public $pcn;
public $email;
public $em_contact;
public $em_contact_no;
public $experience;
public $education;
public $dob;
public $gender;
public $created_date;
    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all() {
        $qry = "SELECT
        des.name AS designation,
        hr_profile.pk_id,
        hr_profile.full_name,
        hr_profile.pmdc_number,
        hr_profile.cnic_number,
        hr_profile.is_active,
        hr_profile.warehouse_id,
        hr_profile.hr_type_id,
        hr_profile.hr_type,
        hr_profile.link_user,
        hr_profile.hr_status_id,
        hr_profile.department,
        hr_profile.reg_number,
        hr_profile.pmc_expiry,
        hr_profile.pmc_category,
        hr_profile.blood_group,
        hr_profile.doj,
        hr_profile.job_band,
        hr_profile.address,
        hr_profile.pcn,
        hr_profile.email,
        hr_profile.em_contact,
        hr_profile.em_contact_no,
        hr_profile.experience,
        hr_profile.education,
        hr_profile.dob,
        hr_profile.gender,
        hr_profile.created_date
        FROM
        hr_profile
        INNER JOIN list_detail AS des ON hr_profile.designation = des.pk_id
        ORDER BY hr_profile.full_name ASC";
        return $this->query($qry);
    }

    public function get_combo($type = '') {
        $date = date("Y-m-d");
		
		$wr = '';
		if($type != ''){
			$wr = "WHERE
        hr_profile.hr_type_id = $type";
		}
        $qry = "SELECT
        hr_profile.pk_id AS `key`,
        CONCAT(
            hr_profile.full_name,
            ' (',
            (
                SELECT
                    COUNT(DISTINCT patient_status.patient_id) total
                FROM
                    patient_status
                WHERE
                    patient_status.consultant_id = hr_profile.pk_id
                AND DATE_FORMAT(
                    patient_status.visit_date,
                    '%Y-%m-%d'
                ) = '$date'
            ),
            ' assigned today',
            ')'
        ) AS `value`
    FROM
    " . static::$table_name . "
    $wr ";
        return $this->query($qry);
    }

    public function get_combo1($type = '') {
		$wr = '';
		if($type != ''){
			$wr = "WHERE
        hr_profile.hr_type_id = $type";
		}
        $date = date("Y-m-d");
        $qry = "SELECT
        hr_profile.pk_id AS `key`,
        hr_profile.full_name AS `value`
    FROM
    " . static::$table_name . "
    $wr";
        return $this->query($qry);
    }

    public function find_field_by_id($id, $field) {
        $this->db->select($field);
        $this->db->from(static::$table_name);
        $this->db->where('pk_id', $id);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $row = $query->row_array();
            return $row[$field];
        }
    }

    public function find_active()
    {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE is_active=1";
        //        print_r($qry);exit;
        return $this->query($qry);
    }
    public function find_by_id($id)
    {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE pk_id=" . $id;
        return $this->query($qry);
    }

    private function instantiate($record)
    {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute)
    {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes()
    {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if ($this->$field != '') {
                    $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes()
    {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save()
    {
        // A new record won't have an id yet.
        return isset($this->pk_id) ? $this->update() : $this->create();
    }

    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create()
    {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $this->db->insert(static::$table_name, $attributes);
        return ($this->db->affected_rows() != 1) ? false : $this->db->insert_id();
    }

    /**
     * update
     * @global type $this
     * @return type
     */
    public function update()
    {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        //        print_r($sql);exit;
        $this->query($sql);
        return true;
    }

    public function deactivate($id, $status)
    {
        $qry = "UPDATE " . static::$table_name . " SET is_active=$status where pk_id=$id";
        $this->query($qry);
    }
}
