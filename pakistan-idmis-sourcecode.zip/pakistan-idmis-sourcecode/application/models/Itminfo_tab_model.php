<?php
class Itminfo_tab_model extends Base_model {

    protected static $table_name = "itminfo_tab";
    private $conn;
    protected static $db_fields = array('itmrec_id','itm_name','generic_name','method_type','itm_type','qty_carton','itm_des','itm_status','frmindex','itm_category','item_unit_id','drug_reg_num','manufacturer_id','supplier_id','strength_id','product_code','min_quantity','max_quantity','reorder_quantity','cold_chain_temp','product_type','barcode','pack_size','unit','carton_size');
    public $itm_id;
    public $itmrec_id;
    public $itm_name;
    public $generic_name;
    public $method_type;
    public $itm_type;
    public $qty_carton;
    public $itm_des;
    public $itm_status;
    public $frmindex;
    public $itm_category;
    public $item_unit_id;
    public $drug_reg_num;
    public $manufacturer_id;
    public $supplier_id;
    public $strength_id;
    public $product_code;
    public $min_quantity;
    public $max_quantity;
    public $reorder_quantity;
    public $cold_chain_temp;
    public $product_type;
    public $barcode;
    public $pack_size;
    public $unit;
    public $carton_size;

    public function find_all() {
        $qry = "SELECT * FROM " . static::$table_name;  
//        print_r($qry);exit;
        return $this->query($qry);
   }
   
   function getLastID($status_id) {
       
//        $strSql = "SELECT MAX(tr_no) as Maxtr from " . static::$table_name . " where tran_date between '" . $from . "' and '" . $to . "' $str";
        $strSql = "SELECT MAX(RIGHT(itmrec_id,3)) AS Maxtr from " . static::$table_name . " WHERE itm_category = $status_id";

//        echo $strSql;exit;
        return $this->query($strSql);
    }
    
    function get_diseasetype($stkid) {
       
//        $strSql = "SELECT MAX(tr_no) as Maxtr from " . static::$table_name . " where tran_date between '" . $from . "' and '" . $to . "' $str";
        $strSql = "SELECT * from stakeholder WHERE stkid = $stkid";

//        echo $strSql;exit;
        return $this->query($strSql);
    }
    
   
    function find_currency_type() {
       
//        $strSql = "SELECT MAX(tr_no) as Maxtr from " . static::$table_name . " where tran_date between '" . $from . "' and '" . $to . "' $str";
        $strSql = "SELECT
                    list_detail.pk_id,
                    list_detail.`name` 
            FROM
                    list_detail
                    INNER JOIN list_master ON list_detail.master_id = list_master.pk_id 
            WHERE
                    list_detail.master_id = 5";

//        echo $strSql;exit;
        return $this->query($strSql);
    }
    
    public function find_all_products() {
        // $stklimit = '';
        // $join = '';
        // $prodlimit = '';
//        $stkidarray = array();
//        for ($i = 0; $i < $_SESSION['count']; $i++) {
//            array_push($stkidarray, "'" . $_SESSION['stakeholder_id_'.$i]. "'");
//        }
//        $stkid = implode(', ', $stkidarray);
//
//        $prodidarray = array();
//        for ($i = 0; $i < $_SESSION['count']; $i++) {
//            array_push($prodidarray,"'" .  $_SESSION['product_id_'.$i]. "'");
//        }
//        $prodid = implode(', ', $prodidarray);
		$stkid = $this->get_user_stakeholders();
		$prodid = $this->get_stakeholder_products();
        // echo "<pre>";
        // var_dump($_SESSION['stakeholder_id']);die;
        $this->db->distinct('itminfo_tab.itmrec_id, itminfo_tab.itm_name, itminfo_tab.itm_id, itminfo_tab.itm_status, itminfo_tab.product_code, itminfo_tab.min_quantity, itminfo_tab.max_quantity, itminfo_tab.reorder_quantity, itminfo_tab.cold_chain_temp, product_manufacturer.manufacturer, product_generic_name.generic_name, product_strength.strength, product_category.category, product_category.pk_id, product_method_type.method_type, list_detail.name AS product_type, itminfo_tab.itm_des');
        $this->db->from('itminfo_tab');
        $this->db->join('product_manufacturer', 'itminfo_tab.manufacturer_id = product_manufacturer.pk_id', 'LEFT');
        $this->db->join('product_generic_name', 'itminfo_tab.generic_name = product_generic_name.pk_id', 'LEFT');
        $this->db->join('product_strength', 'itminfo_tab.strength_id = product_strength.pk_id', 'LEFT');
        $this->db->join('product_category', 'itminfo_tab.itm_category = product_category.pk_id', 'LEFT');
        $this->db->join('product_method_type', 'itminfo_tab.method_type = product_method_type.pk_id', 'LEFT');
        $this->db->join('list_detail', 'itminfo_tab.product_type = list_detail.pk_id', 'LEFT');
        if($_SESSION['id'] != '1' && $_SESSION['role'] != 8){
            $this->db->join('stakeholder_item', 'itminfo_tab.itm_id = stakeholder_item.product_id', 'INNER');
            $this->db->where_in("stakeholder_item.stk_id in ($stkid)",NULL);
            $this->db->where_in("itminfo_tab.itm_id in ($prodid)",NULL);
        }if ($_SESSION['role'] == '8') {
            $this->db->join('stakeholder_item', 'itminfo_tab.itm_id = stakeholder_item.product_id', 'INNER');
            $this->db->where('stakeholder_item.stk_id', (int)$_SESSION['stakeholder_id']);
        }
        $this->db->group_by('itminfo_tab.itm_id');
        $this->db->order_by('itminfo_tab.itm_name');
        $this->db->get();
        $qry = $this->db->last_query();
//       print_r($qry);exit;
       //      echo "working";die;
        return $this->query($qry);
   }
   
   public function find_all_productsinfo() {
        $stklimit = '';
        $join = '';
        $prodlimit = '';
//        $stkid = $this->get_user_stakeholders();

	   $stkid = $this->get_user_stakeholders();

//        if($_SESSION['id'] == '1')
//        {
//            $stklimit = '';
//        }
//        else{
//            $join = "INNER JOIN stakeholder_item ON itminfo_tab.itm_id = stakeholder_item.product_id";
//            $stklimit = "WHERE stakeholder_item.stk_id IN (".$stkid.")";
//        }
        
//        $prodid = $this->get_stakeholder_products();

	   $prodid = $this->get_stakeholder_products();
        
        if($_SESSION['id'] == '1')
        {
            $prodlimit = '';
        }
        else{
            $prodlimit = "AND itminfo_tab.itm_id IN (".$prodid.")";
        }
        
        $qry = "SELECT
                        Concat(' (',itminfo_tab.itmrec_id,') ',itminfo_tab.itm_name) AS itm_name,
                        itminfo_tab.itm_id,
                        itminfo_tab.itm_status,
                        itminfo_tab.product_code,
                        itminfo_tab.min_quantity,
                        itminfo_tab.max_quantity,
                        itminfo_tab.reorder_quantity,
                        itminfo_tab.cold_chain_temp,
                        product_manufacturer.manufacturer,
                        product_generic_name.generic_name,
                        product_strength.strength,
                        product_category.category,
                        product_category.pk_id,
                        product_method_type.method_type
                FROM
                        itminfo_tab
                LEFT JOIN product_manufacturer ON itminfo_tab.manufacturer_id = product_manufacturer.pk_id
                LEFT JOIN product_generic_name ON itminfo_tab.generic_name = product_generic_name.pk_id
                LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                LEFT JOIN product_category ON itminfo_tab.itm_category = product_category.pk_id
                LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
                $join
                $stklimit
                $prodlimit
                ORDER BY
                    itm_name ASC";  
//        print_r($qry);exit;
        return $this->query($qry);
   }
   
   
     public function find_active() {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry.=" WHERE status=1";
//        print_r($qry);exit;
        return $this->query($qry);
    }
    public function find_by_id($id) {
        $qry = "SELECT * FROM " . static::$table_name; 
        $qry .= " WHERE itm_id=" . $id;
//        print_r($qry);exit;
        return $this->query($qry);
    }
    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    public function get_list(){
        $qry = "SELECT * FROM " . static::$table_name; 
        $result =  $this->query($qry);
        if (!empty($result)) {
            foreach ($result->result_object() as $row) {
                $searched_list[$row->pk_id]=(array)$row;
            }
        }
        return $searched_list;
    }
    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if ($this->$field != '') {
                $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.
        return ($this->itm_id != '') ? $this->update() : $this->create();
    }
    
    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create() {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
//        echo $sql;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    /**
     * update
     * @global type $this
     * @return type
     */
public function update() {
    // Don't forget your SQL syntax and good habits:
    // - UPDATE table SET key = 'value', key = 'value' WHERE condition
    // - single - quotes around all values
    // - escape all values to prevent SQL injection
    $attributes = $this->sanitized_attributes();
    $attribute_pairs = array();
    foreach ($attributes as $key => $value) {
        $attribute_pairs[] = "{$key}='{$value}'";
    }
    $sql = "UPDATE " . static::$table_name . " SET ";
    $sql .= join(", ", $attribute_pairs);
    $sql .= " WHERE itm_id=" . $this->escape_value($this->itm_id);
    $this->query2($sql);
    return true;
}
public function deactivate($id,$status){
        $qry="UPDATE ". static::$table_name. " SET itm_status=$status where itm_id=$id";
        $this->query($qry);
    }
     public function get_warehouse_products() {
        $qry = "SELECT DISTINCT
        itminfo_tab.itm_name,
        stock_batch.item_id,
        '' as daily_units_in_single_item,
        '' as issuance_limit
        FROM
        itminfo_tab
        INNER JOIN stock_batch ON itminfo_tab.itm_id = stock_batch.item_id
        WHERE
        stock_batch.wh_id = ".$this->session->userdata('warehouse_id')."
        AND stock_batch.qty > 0
        ORDER BY
        itminfo_tab.itm_name ASC"; 
//        exit;
        return $this->query($qry);
    }
     public function get_warehouse_stock() {
        $qry = "SELECT 
product.product_name,
product.daily_units_in_single_item,
product.issuance_limit,
stock_batch.batch_number,
stock_batch.batch_id,
stock_batch.batch_expiry,
stock_batch.quantity,
stock_batch.wh_id,
stock_batch.item_id
        FROM
        product
        INNER JOIN stock_batch ON product.pk_id = stock_batch.item_id
        WHERE
        stock_batch.wh_id = ".$this->session->userdata('warehouse_id')."
        AND stock_batch.quantity > 0
        ORDER BY
        product.product_name ASC,
        
stock_batch.batch_number"; 
        return $this->query($qry);
    }
    
     public function get_tran_types() {
        $qry = "SELECT
transaction_types.trans_id,
transaction_types.trans_type,
transaction_types.trans_nature
FROM
transaction_types
WHERE
transaction_types.is_adjustment = 1
"; 
        return $this->query($qry);
    }
    
    
    public function get_stk_products(){
            $this->db->select(static::$table_name. '.*');
            $this->db->from(static::$table_name);
            $this->db->join('stakeholder_item', 'stakeholder_item.product_id = '. static::$table_name.'.itm_id', 'left');
            $this->db->where_in ('stakeholder_item.stk_id', $this->get_user_stakeholders());
            $this->db->where(static::$table_name. '.itm_status', '1');
            $result = $this->db->get();
//                 echo $this->db->last_query(); exit;
            return $result->result_array();
    }
}
