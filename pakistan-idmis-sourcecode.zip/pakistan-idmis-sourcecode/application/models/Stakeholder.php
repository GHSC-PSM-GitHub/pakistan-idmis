<?php

//require_once 'database.php';

/**
 * clsStockMaster
 * @package classes
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
// If it's going to need the database, then it's
// probably smart to require it before we start.
class Stakeholder extends Base_model {

    // table name
    protected static $table_name = "stakeholder";
    // db connection
    private $conn;
    //db fileds
    protected static $db_fields = array( 'stkname','stkorder','ParentID','stk_type_id','lvl','MainStakeholder','is_reporting','contact_person','contact_numbers','contact_emails','contact_address','ntn','gstn');
    public $stkid;
    public $stkname; 
    public $stkorder; 
    public $ParentID;
    public $stk_type_id; 
    public $lvl;
    public $MainStakeholder; 
    public $is_reporting;
    public $contact_person; 
    public $contact_numbers;
    public $contact_emails; 
    public $contact_address;
    public $ntn; 
    public $gstn;

    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all() {
        $qry = "SELECT * FROM " . static::$table_name;
        return $this->query($qry);
    }
    
    public function get_all_stk() {
        
        $stklimit = '';
        $join = '';
//        $prodlimit = '';
//        $stkidarray = array();
//        for ($i = 0; $i < $_SESSION['count']; $i++) {
//            array_push($stkidarray, "'" . $_SESSION['stakeholder_id_'.$i]. "'");
//        }
//        $stkid = implode(', ', $stkidarray);
		$stkid = $this->get_user_stakeholders();
        
        if($_SESSION['id'] == '1')
        {
            $stklimit = '';
        }
        else{
//            $join = "INNER JOIN stakeholder_item ON itminfo_tab.itm_id = stakeholder_item.product_id";
            $stklimit = "AND stakeholder.stkid IN (".$stkid.")";
        }
        
        $qry = "SELECT * FROM " . static::$table_name ." WHERE stk_type_id = 0
                $stklimit
                AND is_reporting = 1";
//        print_r($qry);exit;
        return $this->query($qry);
    }
    
    public function get_manuf_arr_id_data($id) {
        $qry = "SELECT * FROM stakeholder WHERE stkid = $id";
//        print_r($qry);exit;
        return $this->query($qry);
    }
    
    public function get_all_stk_id() {
        
        $stklimit = '';
        $join = '';
//        $prodlimit = '';
//        $stkidarray = array();
//        for ($i = 0; $i < $_SESSION['count']; $i++) {
//            array_push($stkidarray, "'" . $_SESSION['stakeholder_id_'.$i]. "'");
//        }
//        $stkid = implode(', ', $stkidarray);
		$stkid = $this->get_user_stakeholders();
        
        if($_SESSION['id'] == '1' || $_SESSION['role'] == 8)
        {
            $stklimit = '';
        }
        else{
//            $join = "INNER JOIN stakeholder_item ON itminfo_tab.itm_id = stakeholder_item.product_id";
            $stklimit = "AND stakeholder.stkid IN (".$stkid.")";
        }
        
        $qry = "SELECT * FROM " . static::$table_name ." WHERE stk_type_id = 0
                $stklimit
                ";
//        print_r($qry);exit;
        return $this->query($qry);
    }
    
    public function getproducts_bystkid($stkid,$stock_type='') {
        
        $join = '';
        $prodlimit = '';

        $prodid = $this->get_stakeholder_products();
        if($stock_type == 'stock_issue'){
            $stklimit = '';
            $stklimit = "WHERE stakeholder_item.stk_id = '".$stkid."' AND stock_batch.STATUS = 'Running' 
             AND stock_batch.Qty > 0 ";
            $join = "INNER JOIN stakeholder_item ON itminfo_tab.itm_id = stakeholder_item.product_id
                INNER JOIN stock_batch ON stock_batch.item_id = itminfo_tab.itm_id 
            ";

            if($_SESSION['id'] == '1')
            {
                $prodlimit = '';
            }
            else{
                $prodid = rtrim($prodid,',');
                $prodlimit = "AND itminfo_tab.itm_id IN (".$prodid.")";
            }
        
        $qry = "SELECT DISTINCT
                        Concat(COALESCE(`itm_name`,''),' (',COALESCE(`strength`,''),')') AS itm_name,
                        itminfo_tab.itm_id,
                        itminfo_tab.itm_status,
                        itminfo_tab.product_code,
                        itminfo_tab.min_quantity,
                        itminfo_tab.max_quantity,
                        itminfo_tab.reorder_quantity,
                        itminfo_tab.cold_chain_temp,
                        product_manufacturer.manufacturer,
                        product_generic_name.generic_name,
                        product_strength.strength,
                        product_category.category,
                        product_category.pk_id,
                        product_method_type.method_type,
                        itminfo_tab.product_type
                FROM
                        itminfo_tab
                LEFT JOIN product_manufacturer ON itminfo_tab.manufacturer_id = product_manufacturer.pk_id
                LEFT JOIN product_generic_name ON itminfo_tab.generic_name = product_generic_name.pk_id
                LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                LEFT JOIN product_category ON itminfo_tab.itm_category = product_category.pk_id
                LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
                $join
                $stklimit
                $prodlimit
                ORDER BY
                    itm_name ASC";  
        
        }else{
             $stklimit = "WHERE stakeholder_item.stk_id = '".$stkid."'";
            $join = "LEFT JOIN stakeholder_item ON itminfo_tab.itm_id = stakeholder_item.product_id";
            if($_SESSION['id'] == '1')
            {
                $prodlimit = '';
            }
            else{
                $prodid = rtrim($prodid,',');
                $prodlimit = "AND itminfo_tab.itm_id IN (".$prodid.")";
            }
        
             $qry = "SELECT DISTINCT
                        Concat(COALESCE(`itm_name`,''),' (',COALESCE(`strength`,''),')') AS itm_name,
                        itminfo_tab.itm_id,
                        itminfo_tab.itm_status,
                        itminfo_tab.product_code,
                        itminfo_tab.min_quantity,
                        itminfo_tab.max_quantity,
                        itminfo_tab.reorder_quantity,
                        itminfo_tab.cold_chain_temp,
                        product_manufacturer.manufacturer,
                        product_generic_name.generic_name,
                        product_strength.strength,
                        product_category.category,
                        product_category.pk_id,
                        product_method_type.method_type,
                        itminfo_tab.product_type
                FROM
                        itminfo_tab
                LEFT JOIN product_manufacturer ON itminfo_tab.manufacturer_id = product_manufacturer.pk_id
                LEFT JOIN product_generic_name ON itminfo_tab.generic_name = product_generic_name.pk_id
                LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                LEFT JOIN product_category ON itminfo_tab.itm_category = product_category.pk_id
                LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
                $join
                $stklimit
                $prodlimit
                ORDER BY
                    itm_name ASC";  
        }
		
              //  print_r($qry);exit;
                return $this->query($qry);
    }
    
    public function get_all_info() {
        $qry = "SELECT
                        stakeholder.stkname,
                        stakeholder_type.stk_type_descr,
                        tbl_dist_levels.lvl_name,
                        stakeholder.stkid,
                        stakeholder.is_reporting
                FROM
                        stakeholder
                INNER JOIN stakeholder_type ON stakeholder.stk_type_id = stakeholder_type.stk_type_id
                LEFT JOIN tbl_dist_levels ON stakeholder.lvl = tbl_dist_levels.lvl_id
                WHERE stakeholder_type.stk_type_id = 3";
        return $this->query($qry);
    }
    
    public function get_all_info_fs() {
        $qry = "SELECT DISTINCT
                        stakeholder.stkname,
                        stakeholder_type.stk_type_descr,
                        tbl_dist_levels.lvl_name,
                        stakeholder.stkid,
                        stakeholder.is_reporting
                FROM
                        stakeholder
                INNER JOIN stakeholder_type ON stakeholder.stk_type_id = stakeholder_type.stk_type_id
                LEFT JOIN tbl_dist_levels ON stakeholder.lvl = tbl_dist_levels.lvl_id
                WHERE stakeholder_type.stk_type_id = 2
                GROUP BY
                    stakeholder.stkname";
        return $this->query($qry);
    }
    
    public function find_by_idsupplier() {
        $qry = "SELECT
                        stakeholder.stkname,
                        stakeholder_type.stk_type_descr,
                        tbl_dist_levels.lvl_name,
                        stakeholder.stkid,
                        stakeholder.is_reporting
                FROM
                        stakeholder
                INNER JOIN stakeholder_type ON stakeholder.stk_type_id = stakeholder_type.stk_type_id
                LEFT JOIN tbl_dist_levels ON stakeholder.lvl = tbl_dist_levels.lvl_id
                WHERE stakeholder_type.stk_type_id = 6";
        return $this->query($qry);
    }
    
    public function find_supplierinfo() {
        $qry = "SELECT
                        tbl_warehouse.wh_id,
                        tbl_warehouse.wh_name
                FROM
                        tbl_warehouse
                INNER JOIN stakeholder_type ON tbl_warehouse.wh_type_id = stakeholder_type.stk_type_id
                WHERE
                        stakeholder_type.stk_type_id = 6
                        AND tbl_warehouse.is_active = 1";
        return $this->query($qry);
    }
    
    public function find_warehouseinfo() {
        $qry = "SELECT
                        tbl_warehouse.wh_id,
                        tbl_warehouse.wh_name,
                        tbl_warehouse.dist_id,
                        tbl_warehouse.prov_id
                FROM
                        tbl_warehouse
                WHERE
                        tbl_warehouse.prov_id = 8
                AND tbl_warehouse.hf_cat_id = 2";
        return $this->query($qry);
    }
    
    public function find_activestk() {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry.=" WHERE is_reporting=1";
//        print_r($qry);exit;
        return $this->query($qry);
    }
    
    public function find_active() {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry.=" WHERE is_reporting=1 AND stk_type_id=6";
//        print_r($qry);exit;
        return $this->query($qry);
    }
    
    public function find_by_name($id) {
        $qry = "SELECT
                        *
                FROM
                        stakeholder
                WHERE
                        stakeholder.stkid = '" . $id ."'";
//        echo $qry;
//        exit;
        return $this->query($qry);
    } 
    
    public function get_supplier_id($id) {
        $qry = "SELECT
                        stkid
                FROM
                        tbl_warehouse
                WHERE
                        tbl_warehouse.wh_id = '" . $id ."'";
//        echo $qry;
//        exit;
        return $this->query($qry);
    } 
    
    public function find_by_id($id = 0) {
        //select query
        $strSql = "SELECT * FROM " . static::$table_name . " WHERE stkid={$id} LIMIT 1";
        //query result
        return $this->query($strSql);
    }
    public function find_suppliers() {
        $qry = "SELECT
                *
                FROM
                stakeholder
                WHERE
                stakeholder.stk_type_id = 6
               ";
        return $this->query($qry);
    }
    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if ($this->$field != '') {
                $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.
        return isset($this->stkid) ? $this->update() : $this->create();
    }
    public function deactivate($id,$status){
        $qry="UPDATE ". static::$table_name. " SET is_reporting=$status where stkid=$id";
        $this->query($qry);
    }
    
    public function deactivate_supplier($id,$status){
        $qry="UPDATE ". static::$table_name. " SET is_reporting=$status where stkid=$id";
        $this->query($qry);
    }
    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create() {
        
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    /**
     * update
     * @global type $this
     * @return type
     */
    public function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE stkid=" . $this->escape_value($this->stkid);
//        $this->query2($sql);
//        return true;
        if ($this->query2($sql)) {
            return $this->escape_value($this->stkid);
        } else {
            return false;
        }
    }
    
    function Getmanufacturer_types() {
        $strSql = "SELECT stk_type_id,stk_type_descr FROM  stakeholder_type WHERE stk_type_id = '3'";
        //result
        return $this->query($strSql);
    }
    
    function Getfundingsource_types() {
        $strSql = "SELECT stk_type_id,stk_type_descr FROM  stakeholder_type WHERE stk_type_id = '2'";
        //result
        return $this->query($strSql);
    }
    
    function GetAlllevels() {
        $strSql = "SELECT * FROM  tbl_dist_levels";
        //result
        return $this->query($strSql);
    }
    function GetMaxRank() {
        $strSql = "SELECT Max(stkorder) as MaxOrder FROM stakeholder ";
        //result
        return $this->query($strSql);
    }
    function Insert_in_wh($stkname,$id,$hf_type_id) {
        $strSql = "INSERT INTO tbl_warehouse SET wh_name='".$stkname."' , stkid='".$id."', stkofficeid='".$id."', hf_type_id='".$hf_type_id."' , reporting_start_month='".date('Y-m-01')."' ";
        //result
//        echo $strSql;exit;
        return $this->query($strSql);
    }
    
    function Update_in_wh($stkname,$id,$hf_type_id,$stkid) {
        $strSql = "Update tbl_warehouse SET wh_name='".$stkname."' , stkid='".$id."', stkofficeid='".$id."', hf_type_id='".$hf_type_id."' , reporting_start_month='".date('Y-m-01')."' WHERE stkid = '".$stkid."' ";
        //result
//        echo $strSql;exit;
        return $this->query($strSql);
    }
    
    function Update_in_mainstk($id) {
        $strSql = "Update stakeholder SET MainStakeholder=" . $id . " where stkid=" . $id;
        //result
//        echo $strSql;exit;
        return $this->query($strSql);
    }

}
