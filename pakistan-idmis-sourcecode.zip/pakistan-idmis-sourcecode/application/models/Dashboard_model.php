<?php

//require_once 'database.php';
class Dashboard_model extends Base_model {

    private $conn;

    public function fetch_announcements() {
        $qry = "SELECT
                announcements.pk_id,
                announcements.sent_by,
                announcements.text,
                announcements.created_at,
                users.username
                FROM
                announcements
                INNER JOIN users ON announcements.sent_by = users.pk_id
                WHERE announcements.is_active = 1
                ORDER BY
                announcements.pk_id DESC
                limit 5
 ";
//        print_r($qry);exit;
        $result = $this->query($qry);
        
        
//        $sql2 = "INSERT INTO  `announcements_seen` (`seen_by`) VALUES ('".$this->session->userdata('id')."'); ";
//        $this->query($sql2);
        if($result)
        return $result->result_array();
    }
    public function fetch_stock_fac_wise() {
        $qry = "SELECT
	tbl_warehouse.wh_name AS warehouse_name, 
	product.product_name, 
	sum(stock_batch.Qty) as qty
FROM
	stock_batch
	INNER JOIN
	product
	ON 
		stock_batch.item_id = product.pk_id
	INNER JOIN
	tbl_warehouse
	ON 
		stock_batch.wh_id = tbl_warehouse.wh_id
GROUP BY
	tbl_warehouse.wh_name, 
	product.product_name
	order BY
	tbl_warehouse.wh_name, 
	product.product_name
 ";
//        print_r($qry);exit;
        $result = $this->query($qry);
        if($result)
        return $result->result_array();
    }
    public function fetch_patients_type_wise() {
        $qry = " 
            SELECT
tbl_warehouse.wh_name AS warehouse_name, 
patients.diabetic_type,
Count(*) AS num
FROM
patients
INNER JOIN users ON patients.created_by = users.pk_id
INNER JOIN tbl_warehouse ON users.warehouse_id = tbl_warehouse.wh_id
GROUP BY
tbl_warehouse.wh_name,
patients.diabetic_type
ORDER BY
tbl_warehouse.wh_name ASC


 ";
//        print_r($qry);exit;
        $result = $this->query($qry);
        if($result)
        return $result->result_array();
    }
    
//    -------------------  LIVE DASHBOARD START   ------------------------------
      public function total_vouchers($from_date,$to_date) {
          $wh_id = $_SESSION['warehouse_id'];
		  $stkids = $this->get_user_stakeholders();
        $q = "SELECT
	stakeholder.stkname,
	COUNT( DISTINCT gwis_master.pk_id ) AS total 
FROM
	gwis_master
	INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
	INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
	INNER JOIN stakeholder_item ON stock_batch.item_id = stakeholder_item.product_id
	INNER JOIN stakeholder ON stakeholder_item.stk_id = stakeholder.stkid 
WHERE
	stock_batch.wh_id = '$wh_id'
        AND stakeholder.stkid IN ($stkids) 
        AND gwis_master.tran_date BETWEEN  '" . $from_date . "' AND '" . $to_date . "' 
	GROUP BY stakeholder.stkid";
//        print_r($qry);exit;
       $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
     public function monthly_transaction($from_date,$to_date) {
         $wh_id = $_SESSION['warehouse_id'];
         $stkids = $this->get_user_stakeholders();
        $q = "SELECT
	DATE_FORMAT( gwis_master.tran_date, '%M %Y' ) monthss,
	COUNT( DISTINCT gwis_master.pk_id ) AS total 
FROM
	gwis_master
	INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
	INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
	INNER JOIN stakeholder_item ON stock_batch.item_id = stakeholder_item.product_id
	INNER JOIN stakeholder ON stakeholder_item.stk_id = stakeholder.stkid 
WHERE
	stock_batch.wh_id = '$wh_id' 
        AND stakeholder.stkid IN ($stkids) 
	AND YEAR(gwis_master.tran_date) > '2000'
        AND gwis_master.tran_date BETWEEN  '" . $from_date . "' AND '" . $to_date . "' 
GROUP BY
	DATE_FORMAT(
	gwis_master.tran_date,
	'%m/%Y')
ORDER BY gwis_master.tran_date";
//        print_r($qry);exit;
       $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
     public function type_wise_transaction($from_date,$to_date) {
         $wh_id = $_SESSION['warehouse_id'];
          $stkids = $this->get_user_stakeholders();
        $q = "SELECT
	gwis_master.process_status name,
	COUNT( DISTINCT gwis_master.pk_id ) AS total 
FROM
	gwis_master
	INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
	INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
	INNER JOIN stakeholder_item ON stock_batch.item_id = stakeholder_item.product_id
	INNER JOIN stakeholder ON stakeholder_item.stk_id = stakeholder.stkid 
WHERE
	stock_batch.wh_id = '$wh_id'
        AND stakeholder.stkid IN ($stkids)
	AND gwis_master.process_status IN (3,6,9,12)
         AND gwis_master.tran_date BETWEEN  '" . $from_date . "' AND '" . $to_date . "' 
GROUP BY
	gwis_master.process_status";
//        print_r($qry);exit;
       $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
      public function product_wise_soh($from_date,$to_date) {
           $stk_id = $this->get_user_stakeholders();
           $wh_id = $_SESSION['warehouse_id'];
        $q = "SELECT
	itminfo_tab.itm_name,
	SUM( stock_batch.Qty ) total 
FROM
	stock_batch
	INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id 
         INNER JOIN stakeholder_item ON stakeholder_item.product_id = itminfo_tab.itm_id  
WHERE
	stock_batch.wh_id = '$wh_id' 
          AND stakeholder_item.stk_id IN ($stk_id)
GROUP BY
	itminfo_tab.itm_id 
ORDER BY
	total DESC
	LIMIT 10";
//        print_r($qry);exit;
       $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
     public function max_soh($from_date,$to_date) {
         $stk_id = $this->get_user_stakeholders();
         $wh_id = $_SESSION['warehouse_id'];
        $q = "SELECT
	itminfo_tab.itm_name,
	SUM( stock_batch.Qty ) total 
FROM
	stock_batch
	INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id 
        INNER JOIN stakeholder_item ON stakeholder_item.product_id = itminfo_tab.itm_id         
WHERE
	stock_batch.wh_id = '$wh_id'
        AND stakeholder_item.stk_id IN ($stk_id)
GROUP BY
	itminfo_tab.itm_id
HAVING
	total > 100000 
ORDER BY
	total DESC";
//        print_r($qry);exit;
       $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
       public function min_soh($from_date,$to_date) {
             $stk_id = $this->get_user_stakeholders();
             $wh_id = $_SESSION['warehouse_id'];
        $q = "SELECT
	itminfo_tab.itm_name,
	SUM( stock_batch.Qty ) total 
FROM
	stock_batch
	INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id 
         INNER JOIN stakeholder_item ON stakeholder_item.product_id = itminfo_tab.itm_id   
WHERE
	stock_batch.wh_id = '$wh_id' 
          AND stakeholder_item.stk_id IN ($stk_id)
GROUP BY
	itminfo_tab.itm_id 
HAVING
	total > 1000
ORDER BY
	total ASC 
	LIMIT 50";
//        print_r($qry);exit;
       $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
        public function expired_product($from_date,$to_date) {
             $stk_id = $this->get_user_stakeholders();
             $wh_id = $_SESSION['warehouse_id'];
        $q = "SELECT
	itminfo_tab.itm_name, 
	SUM(stock_batch.Qty) AS total
FROM
	stock_batch
	INNER JOIN
	itminfo_tab
	ON 
		stock_batch.item_id = itminfo_tab.itm_id
	INNER JOIN
	stakeholder_item AS stk_item
	ON 
		stk_item.product_id = itminfo_tab.itm_id
WHERE
	stock_batch.wh_id = '$wh_id' AND
	stock_batch.batch_expiry < CURDATE() AND
	stk_item.stk_id IN ($stk_id) AND
	stock_batch.Qty > 0 AND
	stock_batch.dtl_status = 'çompleted'
GROUP BY
	itminfo_tab.itm_name ORDER BY total DESC";
//        print_r($qry);exit;
       $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
     public function expire_stock($from_date,$to_date) {
          $stk_id = $this->get_user_stakeholders();    
          $wh_id = $_SESSION['warehouse_id'];
        $q = "SELECT
	stakeholder.stkname,
	'With in a month' duration,
	COUNT( DISTINCT itminfo_tab.itm_id ) total 
FROM
	stock_batch
	INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
        INNER JOIN stakeholder_item as stk_item ON stk_item.product_id = itminfo_tab.itm_id 
	INNER JOIN stakeholder_item ON itminfo_tab.itm_id = stakeholder_item.product_id
	INNER JOIN stakeholder ON stakeholder_item.stk_id = stakeholder.stkid
	INNER JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id 
WHERE
	stock_batch.wh_id = '$wh_id' 
	AND stock_batch.batch_expiry <= DATE_ADD( CURDATE(), INTERVAL 1 MONTH ) 
         AND stakeholder_item.stk_id IN ($stk_id)
GROUP BY
	stakeholder.stkname,
	stakeholder.stkid
	UNION 
	SELECT
	stakeholder.stkname,
	'With in 3 months' duration,
	COUNT( DISTINCT itminfo_tab.itm_id ) total 
FROM
	stock_batch
	INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
         INNER JOIN stakeholder_item as stk_item ON stk_item.product_id = itminfo_tab.itm_id
	INNER JOIN stakeholder_item ON itminfo_tab.itm_id = stakeholder_item.product_id
	INNER JOIN stakeholder ON stakeholder_item.stk_id = stakeholder.stkid
	INNER JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id 
WHERE
	stock_batch.wh_id = '$wh_id' 
	AND stock_batch.batch_expiry BETWEEN DATE_ADD( CURDATE(), INTERVAL 1 MONTH ) AND DATE_ADD( CURDATE(), INTERVAL 3 MONTH ) 
          AND stakeholder_item.stk_id IN ($stk_id)
GROUP BY
	stakeholder.stkname,
	stakeholder.stkid
	UNION
	SELECT
	stakeholder.stkname,
	'With in 6 months' duration,
	COUNT( DISTINCT itminfo_tab.itm_id ) total 
FROM
	stock_batch
	INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
        INNER JOIN stakeholder_item as stk_item ON stk_item.product_id = itminfo_tab.itm_id
	INNER JOIN stakeholder_item ON itminfo_tab.itm_id = stakeholder_item.product_id
	INNER JOIN stakeholder ON stakeholder_item.stk_id = stakeholder.stkid
	INNER JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id 
WHERE
	stock_batch.wh_id = '$wh_id' 
	AND stock_batch.batch_expiry BETWEEN DATE_ADD( CURDATE(), INTERVAL 3 MONTH ) AND DATE_ADD( CURDATE(), INTERVAL 12 MONTH ) 
          AND stakeholder_item.stk_id IN ($stk_id)
GROUP BY
	stakeholder.stkname,
	stakeholder.stkid";
//        print_r($qry);exit;
       $query = $this->db->query($q);
//        echo $this->db->last_query(); exit;
        return $query->result_array();
    }
    
//    -------------------  LIVE DASHBOARD END   ------------------------------    
    

}
