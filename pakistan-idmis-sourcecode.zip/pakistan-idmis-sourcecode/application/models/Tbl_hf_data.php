<?php

//require_once 'database.php';

/**
 * clsStockMaster
 * @package classes
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
// If it's going to need the database, then it's
// probably smart to require it before we start.
class Tbl_hf_data extends Base_model {

    // table name
    protected static $table_name = "tbl_hf_data";
    // db connection
    private $conn;
    //db fileds
    protected static $db_fields = array('warehouse_id', 'item_id','opening_balance','received_balance','issue_balance','closing_balance','adjustment_positive','adjustment_negative','avg_consumption','new','old','reporting_date','ip_address','created_by','removals','dropouts','demand','change_pos','change_neg','retrieved','arv_patients','total_stock_dcurperiod','quarterly_demand');
    public $pk_id;
    public $warehouse_id;
    public $item_id;
    public $opening_balance;
    public $received_balance;
    public $issue_balance;
    public $closing_balance;
    public $adjustment_positive;
    public $adjustment_negative;
    public $avg_consumption;
    public $new;
    public $old;
    public $reporting_date;
    public $ip_address;
    public $created_by;
    public $removals;
    public $dropouts;
    public $demand;
    public $change_pos;
    public $change_neg;
    public $retrieved;
    public $arv_patients;
    public $total_stock_dcurperiod;
    public $quarterly_demand;
    
    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all() {

        $qry = "SELECT
                    tbl_hf_data.pk_id,
                    tbl_hf_data.wh_name AS warehouse_name,
                    tbl_hf_data.dist_id,
                    tbl_hf_data.prov_id,
                    tbl_hf_data.stkid,
                    tbl_hf_data.hf_cat_id,
                    tbl_hf_data.hf_type_id,
                    warehouse_types.type_name AS facility_type_name,
                    p.LocName AS province_name,
                    d.LocName AS district_name
            FROM
                    tbl_hf_data
            LEFT JOIN warehouse_types ON tbl_hf_data.hf_type_id = warehouse_types.pk_id
            LEFT JOIN tbl_locations AS p ON tbl_hf_data.prov_id = p.PkLocID
            LEFT JOIN tbl_locations AS d ON tbl_hf_data.dist_id = d.PkLocID 
            WHERE
                    tbl_hf_data.hf_cat_id = 1
        ";
        return $this->query($qry);
    }
    
    public function getuserid($stkid) {
        $qry = "SELECT * FROM " . static::$table_name . " WHERE sysusrrec_id = '$stkid'";
//        print_r($qry);exit;
        return $this->query($qry);
    }
    
    public function get_assign_wh_info($id) {
        $qry = "SELECT
                        *
                FROM
                        tbl_hf_data
                WHERE
                        tbl_hf_data.sysusrrec_id = " . $id."";
        return $this->query($qry);
    } 
    
    public function deleteuseridy($stkid) {
        $qry = "DELETE FROM " . static::$table_name . " WHERE sysusrrec_id = '$stkid'";
//        print_r($qry);exit;
        return $this->query($qry);
    }
    
    public function gethf() {

        $qry = "SELECT
        * FROM
        tbl_hf_data WHERE prov_id = '8'
        ";
//        echo $qry;exit;
        return $this->query($qry);
    }
    
    public function get_max_id() {

        $qry = "SELECT
        MAX(pk_id) AS pk_id
        FROM
        tbl_hf_data 
        ";
//        echo $qry;exit;
        return $this->query($qry);
    }
    
    public function get_health_facility() {

        $qry = "SELECT
        *
        FROM
        tbl_hf_data WHERE prov_id = 3 
        ";
        return $this->query($qry);
    }
    
    public function get_district() {

        $qry = "SELECT
        *
        FROM
        locations WHERE parent_id = 3 AND location_level = 4 
        ";
        return $this->query($qry);
    }
    

    public function find_by_id($id = 0) {
        //select query
        $strSql = "SELECT * FROM " . static::$table_name . " WHERE pk_id={$id} LIMIT 1";
        //query result
        return $this->query($strSql);
    }
    
    public function find_by_idwarehouse() {
        $qry = "SELECT
                        tbl_locations.LocName AS province,
                        stakeholder.stkname AS stakeholder,
                        tbl_hf_data.pk_id,
                        tbl_hf_data.wh_name,
                        tbl_hf_data.dist_id,
                        tbl_hf_data.prov_id,
                        tbl_hf_data.stkid,
                        tbl_hf_data.created_by,
                        tbl_hf_data.modified_date,
                        tbl_hf_data.modified_by,
                        tbl_hf_data.created_date,
                        tbl_hf_data.is_default,
                        tbl_hf_data.hf_cat_id,
                        tbl_hf_data.hf_type_id,
                        tbl_hf_data.wh_type_id 
                FROM
                        tbl_hf_data
                        LEFT JOIN tbl_locations ON tbl_hf_data.prov_id = tbl_locations.PkLocID
                        LEFT JOIN stakeholder ON tbl_hf_data.stkid = stakeholder.stkid 
                WHERE
                        tbl_hf_data.hf_cat_id = 2 
                        AND tbl_hf_data.is_default = 1";
        return $this->query($qry);
    }
    
    public function find_by_idcenter() {
        $qry = "SELECT
                    *
                FROM 
                    tbl_hf_data
                WHERE tbl_hf_data.hf_cat_id = 1
                AND is_default = 1";
        return $this->query($qry);
    }
    
    public function find_edit_data($id = 0) {
        //select query
        $strSql = "SELECT
                    tbl_hf_data.pk_id,
                    tbl_hf_data.wh_name AS warehouse_name,
                    tbl_hf_data.dist_id,
                    tbl_hf_data.prov_id,
                    tbl_hf_data.stkid,
                    tbl_hf_data.hf_cat_id,
                    tbl_hf_data.hf_type_id,
                    hr_info.`name`,
                    hr_info.contact_no,
                    hr_info.email,
                    hr_info.cnic,
                    hr_info.gender,
                    hr_info.desg,
                    hr_info.hr_type
                FROM
                        tbl_hf_data
                LEFT JOIN hr_info ON hr_info.hr_id = tbl_hf_data.pk_id
                WHERE
                        tbl_hf_data.pk_id = '".$id."'";
        //query result
        return $this->query($strSql);
    }
    
    public function find_active() {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry.=" WHERE is_default=1";
//        print_r($qry);exit;
        return $this->query($qry);
    }
    
    public function find_by_category($id = 0) {
        //select query
        $strSql = "SELECT * FROM " . static::$table_name . " WHERE hf_cat_id={$id} ";
        //query result
        return $this->query($strSql);
    }

    public function find_by_location_id($id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE locid =" . $id;
        return $this->query($qry);
    }

    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if ($this->$field != '') {
                    $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.
        return isset($this->pk_id) ? $this->update() : $this->create();
    }

    public function deactivate($id, $status) {
        $qry = "UPDATE " . static::$table_name . " SET is_default=$status where pk_id=$id";
//        print_r($qry);exit;
        $this->query($qry);
    }
    
    public function deactivate_supplier($id, $status) {
        $qry = "UPDATE " . static::$table_name . " SET is_default=$status where pk_id=$id";
//        print_r($qry);exit;
        $this->query($qry);
    }
    
    public function deactivate_center($id, $status) {
        $qry = "UPDATE " . static::$table_name . " SET is_default=$status where pk_id=$id";
//        print_r($qry);exit;
        $this->query($qry);
    }

    public function deactivate_warehouse($id, $status) {
        $qry = "UPDATE " . static::$table_name . " SET is_default=$status where pk_id=$id";
//        print_r($qry);exit;
        $this->query($qry);
    }
    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create() {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return true;
        } else {
            return false;
        }
    }
    
    public function updatesupplier($stakeholder_id) {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE stkid=" . $stakeholder_id;
        $this->query2($sql);
        return true;
    }
    /**
     * update
     * @global type $this
     * @return type
     */
    public function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        $this->query2($sql);
        return true;
    }

    public function get_count() {
        $sql = "SELECT
        count(tbl_hf_data.pk_id) as total
        FROM
        tbl_hf_data
        ";
        return $this->query($sql);
    }

    public function find_suppliers() {
        $qry = "SELECT
tbl_hf_data.*
FROM
tbl_hf_data
WHERE
tbl_hf_data.hf_cat_id = 3
               ";
        return $this->query($qry);
    }
    
    public function get_all_hf($dist_id) {
        $qry = "SELECT * FROM " . static::$table_name . " WHERE province_id = '3' AND district_id='".$dist_id."' AND facility_type_id NOT IN ('3')"; 
//        $qry.=" WHERE status=1 AND parent_id IS NOT NULL ORDER BY location_level ASC";
//        print_r($qry);exit;
        $result = $this->query($qry);
        if (!empty($result))
            return $result->result_array();
    }
    
}
