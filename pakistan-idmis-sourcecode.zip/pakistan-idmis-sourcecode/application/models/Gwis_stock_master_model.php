<?php

/**
 * clsStockMaster
 * @package includes/class
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
// If it's going to need the database, then it's
// probably smart to require it before we start.
class Gwis_stock_master_model extends Base_model
{

	// table name
	protected static $table_name = "gwis_master";
	//db fileds 
	protected static $db_fields = array('tran_date', 'tran_no', 'status_id', 'tran_ref', 'wh_id_from', 'wh_id_from_supplier', 'wh_id_to', 'created_by', 'created_on', 'received_remarks', 'temp', 'tr_no', 'linked_tr', 'issued_by', 'source_type', 'shipment_mode', 'attachment_name', 'requisition_type', 'method', 'event', 'po_detail', 'mcc_year', 'issuance_to', 'user_from', 'user_to', 'approve_from', 'approve_to', 'parent_id', 'process_status', 'active_process', 'final_status', 'electronic_approval', 'tran_type_id', 'stk_id', 'inspection_date', 'delivery_location', 'po_cmu_no', 'po_cmu_date', 'po_gf_no', 'po_gf_date', 'date_of_receiving', 'air_bill_no', 'shipment_no', 'origin_of_country', 'vehicle_type_and_plate', 'consignment_weight', 'file', 'issue_to_info', 'province_id');
	//pk stock id
	public $pk_id;
	//transaction date
	public $tran_date;
	//transaction num
	public $tran_no;
	//transaction type id
	public $status_id;
	//transaction ref
	public $tran_ref;
	//from warehouse id
	public $wh_id_from;
	//from warehouse supplier id
	public $wh_id_from_suppliuer;
	//to warehouse id
	public $wh_id_to;
	//created by
	public $created_by;
	//created on
	public $created_on;
	//Received Remarks
	public $received_remarks;
	//temp
	public $temp;
	//transaction num
	public $tr_no;
	//batch num
	public $batch_no;
	//item id
	public $item_id;
	//from date
	public $fromDate;
	//to date
	public $toDate;
	//linked transaction
	public $linked_tr;
	//stakeholder
	public $stakeholder;
	//province
	public $province;
	//issued by
	public $issued_by;
	//funding source
	public $funding_source;
	public $source_type;
	public $shipment_mode;
	public $po_detail;
	public $attachment_name;
	public $requisition_type;
	public $method;
	public $event;
	public $mcc_year;
	public $issuance_to;
	public $user_from;
	public $user_to;
	public $approve_from;
	public $approve_to;
	public $parent_id;
	public $process_status;
	public $active_process;
	public $final_status;
	public $electronic_approval;
	public $tran_type_id;
	public $stk_id;

	public $inspection_date;
	public $delivery_location;
	public $po_cmu_no;
	public $po_cmu_date;
	public $po_gf_no;
	public $po_gf_date;

	public $date_of_receiving;
	public $air_bill_no;
	public $shipment_no;
	public $origin_of_country;
	public $vehicle_type_and_plate;
	public $consignment_weight;
	public $file;
	public $issue_to_info;
	public $province_id;
	// Common Database Methods
	/**
	 * 
	 * find_all
	 * @return type
	 * 
	 * 
	 */
	public function find_all()
	{
		return static::find_by_sql("SELECT * FROM " . static::$table_name);
	}

	/**
	 * 
	 * find_by_id
	 * @param type $id
	 * @return type
	 * 
	 * 
	 */
	public function find_by_id($id = 0)
	{
		//select query
		$strSql = "SELECT * FROM " . static::$table_name . " WHERE pk_id={$id} LIMIT 1";
		//       echo $strSql;exit;
		//query result
		return $this->query($strSql);
	}


	public function updatemasterpkid($id)
	{
		//select query
		$strSql = "UPDATE " . static::$table_name . " SET active_process = 0 WHERE pk_id='" . $id . "' ";
		//query result
		return $this->query($strSql);
	}

	public function updatedetailpkid($id)
	{
		//select query
		$strSql = "UPDATE gwis_detail SET is_received = 1 WHERE pk_id='" . $id . "' ";
		//query result
		return $this->query($strSql);
	}

	public function updatedetailpkidtozero($id)
	{
		//select query
		$strSql = "UPDATE gwis_detail SET is_received = 0 WHERE pk_id='" . $id . "' ";
		//query result
		return $this->query($strSql);
	}
	/**
	 * 
	 * find_by_sql
	 * @param type $sql
	 * @return type
	 * 
	 * 
	 */
	public function find_by_sql($sql = "")
	{
		$result_set = mysql_query($sql);
		//query result
		$object_array = array();
		while ($row = mysql_fetch_array($result_set)) {
			$object_array[] = static::instantiate($row);
		}
		return $object_array;
	}

	/**
	 * 
	 * count_all
	 * @global type $this
	 * @return type
	 * 
	 * 
	 */
	public function count_all()
	{
		//select query
		$sql = "SELECT COUNT(*) FROM " . static::$table_name;
		//query result
		$result_set = $this->query($sql);
		$row = $this->fetch_array($result_set);
		return array_shift($row);
	}

	/**
	 * 
	 * instantiate
	 * @param type $record
	 * @return \self
	 * 
	 * 
	 */
	private function instantiate($record)
	{
		// Could check that $record exists and is an array
		$object = new self;
		// Simple, long - form approach:
		// More dynamic, short - form approach:
		foreach ($record as $attribute => $value) {
			if ($object->has_attribute($attribute)) {
				$object->$attribute = $value;
			}
		}
		return $object;
	}

	/**
	 * 
	 * has_attribute
	 * @param type $attribute
	 * @return type
	 * 
	 * 
	 */
	private function has_attribute($attribute)
	{
		// We don't care about the value, we just want to know if the key exists
		// Will return true or false
		return array_key_exists($attribute, $this->attributes());
	}

	/**
	 * 
	 * attributes
	 * @return type
	 * 
	 * 
	 */
	protected function attributes()
	{
		// return an array of attribute names and their values
		$attributes = array();
		foreach (static::$db_fields as $field) {
			if (property_exists($this, $field)) {
				if (!empty($this->$field) || $this->$field == 0) {
					$attributes[$field] = $this->$field;
				}
			}
		}
		return $attributes;
	}

	/**
	 * 
	 * sanitized_attributes
	 * @global type $database
	 * @return type
	 * 
	 * 
	 */
	protected function sanitized_attributes()
	{
		$clean_attributes = array();
		// sanitize the values before submitting
		// Note: does not alter the actual value of each attribute
		foreach ($this->attributes() as $key => $value) {
			$clean_attributes[$key] = $this->escape_value($value);
		}
		return $clean_attributes;
	}

	/**
	 * 
	 * save
	 * @return type
	 * 
	 * 
	 */
	public function save()
	{
		// A new record won't have an id yet.

		return isset($this->pk_id) ? $this->update() : $this->create();
	}

	/**
	 *
	 * create
	 * @global type $database
	 * @return boolean
	 * 
	 * 
	 */
	public function create()
	{
		// Don't forget your SQL syntax and good habits:
		// - INSERT INTO table (key, key) VALUES ('value', 'value')
		// - single - quotes around all values
		// - escape all values to prevent SQL injection
		$attributes = $this->sanitized_attributes();
		//insert query
		$sql = "INSERT INTO " . static::$table_name . " (";
		$sql .= join(", ", array_keys($attributes));
		$sql .= ") VALUES ('";
		$sql .= join("', '", array_values($attributes));
		$sql .= "')";
		//        print_r($sql);exit;
		//	echo 'Ins:::'.$sql;exit;
		if ($this->query2($sql)) {
			//            print_r($this->insert_id());exit;
			return $this->insert_id();
		} else {
			return false;
		}
	}

	/**
	 * 
	 * update
	 * @global type $database
	 * @return type
	 * 
	 * 
	 */
	public function update()
	{
		//update query
		$attributes = $this->sanitized_attributes();
		$attribute_pairs = array();
		foreach ($attributes as $key => $value) {
			$attribute_pairs[] = "{$key}='{$value}'";
		}
		//        print_r($attribute_pairs);exit;
		$sql = "UPDATE " . static::$table_name . " SET ";
		$sql .= join(", ", $attribute_pairs);
		$sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
		//echo 'upd:::'.$sql;exit;
		if ($this->query2($sql)) {
			//            print_r($this->insert_id());exit;
			return $this->insert_id();
		} else {
			return false;
		}
	}

	public function updatebatchmaster()
	{
		//update query
		$attributes = $this->sanitized_attributes();
		$attribute_pairs = array();
		foreach ($attributes as $key => $value) {
			$attribute_pairs[] = "{$key}='{$value}'";
		}
		//        print_r($attribute_pairs);exit;
		$sql = "UPDATE " . static::$table_name . " SET wh_id_from_supplier = '" . $this->escape_value($this->wh_id_from_supplier) . "',wh_id_from = '" . $this->escape_value($this->wh_id_from) . "',tran_ref = '" . $this->escape_value($this->tran_ref) . "'";
		$sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
		//echo 'upd:::'.$sql;exit;
		if ($this->query2($sql)) {
			//            print_r($this->insert_id());exit;
			return $this->insert_id();
		} else {
			return false;
		}
	}

	public function updateissuebatchmaster()
	{
		//update query
		$attributes = $this->sanitized_attributes();
		$attribute_pairs = array();
		foreach ($attributes as $key => $value) {
			$attribute_pairs[] = "{$key}='{$value}'";
		}
		//        print_r($attribute_pairs);exit;
		$sql = "UPDATE " . static::$table_name . " SET wh_id_from_supplier = '" . $this->escape_value($this->wh_id_from_supplier) . "',wh_id_from = '" . $this->escape_value($this->wh_id_from) . "',tran_ref = '" . $this->escape_value($this->tran_ref) . "'";
		$sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
		//echo 'upd:::'.$sql;exit;
		if ($this->query2($sql)) {
			//            print_r($this->insert_id());exit;
			return $this->insert_id();
		} else {
			return false;
		}
	}


	function update_master_using_id()
	{
		//         $attributes = $this->sanitized_attributes();
		//        $attribute_pairs = array();
		//        foreach ($attributes as $key => $value) {
		//            $attribute_pairs[] = "{$key}='{$value}'";
		//        }
		$sql = "UPDATE " . static::$table_name . " SET status_id= '" . $this->escape_value($this->status_id) . "',user_from = '" . $this->escape_value($this->user_from) . "',user_to = '" . $this->escape_value($this->user_to) . "',tran_date = '" . $this->escape_value($this->tran_date) . "',tran_ref = '" . $this->escape_value($this->tran_ref) . "',received_remarks = '" . $this->escape_value($this->received_remarks) . "',tran_no = '" . $this->escape_value($this->tran_no) . "',tr_no = '" . $this->escape_value($this->tr_no) . "' WHERE pk_id = '" . $this->escape_value($this->pk_id) . "'";
		//        print_r($sql);exit;
		if ($this->query2($sql)) {
			//            print_r($this->insert_id());exit;
			return $this->insert_id();
		} else {
			return false;
		}
	}


	public function link_trans()
	{
		//update query
		$sql = "UPDATE " . static::$table_name . " SET ";
		$sql .= " linked_transaction='" . $this->linked_transaction . "'";
		$sql .= " WHERE pk_id='" . $this->escape_value($this->pk_id) . "'";
		//echo 'upd:::'.$sql;exit;
		$this->query($sql);
		return true;
	}
	public function mark_received()
	{
		//update query
		$sql = "UPDATE " . static::$table_name . " SET ";
		$sql .= " is_received='1' ";
		$sql .= " WHERE pk_id= '" . $this->escape_value($this->pk_id) . "' ";
		//echo 'upd:::'.$sql;exit;
		$this->query($sql);
		return true;
	}

	/**
	 * 
	 * delete
	 * @global type $database
	 * @return type
	 * 
	 * 
	 */
	public function delete()
	{
		// Don't forget your SQL syntax and good habits:
		// - DELETE FROM table WHERE condition LIMIT 1
		// - escape all values to prevent SQL injection
		// - use LIMIT 1 
		//delete query
		$sql = "DELETE FROM " . static::$table_name;
		$sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
		$sql .= " LIMIT 1";
		$this->query($sql);
		return ($this->affected_rows() == 1) ? true : false;

		// NB: After deleting, the instance of User still
		// exists, even though the database entry does not.
		// This can be useful, as in:
		// but, for example, we can't call $user->update()
		// after calling $user->delete(). 
	}

	/**
	 * 
	 * stockExists
	 * @return boolean
	 * 
	 * 
	 */
	function stockExists()
	{
		//select query
		$strSql = "SELECT
            tbl_stock_detail.PkDetailID
            FROM
            tbl_stock_detail
            WHERE
            tbl_stock_detail.fkStockID = " . $this->pk_id;
		//query result
		$rsSql = mysql_query($strSql) or die("Error stockExists");
		if (mysql_num_rows($rsSql) > 0) {
			return true;
		} else {
			return false;
		}
	}

	function GetStockLedger()
	{
		$whId = $_SESSION['user_warehouse'];

		$fs = '';
		if (!empty($this->funding_source) && $this->funding_source != 'all') {
			$fs = " AND s3_.funding_source = $this->funding_source ";
		}

		//select query
		$strSql = "SELECT
	s0_.PkDetailID AS detail_id,
	s0_.Qty AS quantity,
	s0_.IsReceived AS is_received,
	s0_.adjustmentType AS adjustment_type,
	s0_.fkStockID AS stock_master_id,
	s0_.BatchID AS stock_batch_warehouse_id,
	s0_.fkUnitID AS item_unit_id,
	transaction_types.trans_nature,
	s1_.CreatedOn,
	sysuser_tab.usrlogin_id,
	s1_.TranDate,
	s1_.TranNo,
	s1_.TranTypeID,
	`from`.wh_name fromWh,
	`to`.wh_name toWh,
	s3_.batch_no,
	s3_.batch_id,
	s3_.batch_expiry,
        transaction_types.trans_type,
        s3_.funding_source,
        fs.wh_name as funding_source_name
        FROM
                tbl_stock_detail AS s0_
        INNER JOIN tbl_stock_master AS s1_ ON s0_.fkStockID = s1_.PkStockID
        INNER JOIN stock_batch AS s3_ ON s0_.BatchID = s3_.batch_id
        INNER JOIN transaction_types ON s1_.TranTypeID = transaction_types.trans_id
        INNER JOIN sysuser_tab ON s1_.CreatedBy = sysuser_tab.UserID
        INNER JOIN tbl_warehouse AS `from` ON s1_.WHIDFrom = `from`.wh_id
        INNER JOIN tbl_warehouse AS `to` ON s1_.WHIDTo = `to`.wh_id
        INNER JOIN tbl_warehouse  AS  fs ON s3_.funding_source = fs.wh_id
        WHERE
                s3_.item_id = $this->item_id
        AND s3_.wh_id = $whId
        AND (
                DATE_FORMAT(s1_.TranDate, '%Y-%m-%d') BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'
        )
        $fs
        ORDER BY
	DATE_FORMAT( s1_.TranDate, '%Y-%m-%d' ) ASC,
	adjustment_type ASC,
	quantity ASC";
		//echo '<pre>';print_r($this);
		//        echo $strSql;exit;
		//query result
		$rsSql = mysql_query($strSql) or die("Error GetStockLedger");
		$data = array();
		if (mysql_num_rows($rsSql) > 0) {
			while ($row = mysql_fetch_assoc($rsSql)) {
				$data[] = $row;
			}
			return $data;
		} else {
			return false;
		}
	}

	function GetStockLedgerProvLvl($district)
	{
		//        $whId = $_SESSION['user_warehouse'];
		//        $distId = $_SESSION['user_district'];
		$fs = '';
		if (!empty($this->funding_source) && $this->funding_source != 'all') {
			$fs = " AND s3_.funding_source = $this->funding_source ";
		}

		//select query
		$strSql = "SELECT
	s0_.PkDetailID AS detail_id,
	s0_.Qty AS quantity,
	s0_.IsReceived AS is_received,
	s0_.adjustmentType AS adjustment_type,
	s0_.fkStockID AS stock_master_id,
	s0_.BatchID AS stock_batch_warehouse_id,
	s0_.fkUnitID AS item_unit_id,
	transaction_types.trans_nature,
	s1_.CreatedOn,
	sysuser_tab.usrlogin_id,
	s1_.TranDate,
	s1_.TranNo,
	s1_.TranTypeID,
	`from`.wh_name fromWh,
	`to`.wh_name toWh,
	s3_.batch_no,
	s3_.batch_id,
	s3_.batch_expiry,
        transaction_types.trans_type,
        s3_.funding_source,
        fs.wh_name as funding_source_name
        FROM
                tbl_stock_detail AS s0_
        INNER JOIN tbl_stock_master AS s1_ ON s0_.fkStockID = s1_.PkStockID
        INNER JOIN stock_batch AS s3_ ON s0_.BatchID = s3_.batch_id
        INNER JOIN transaction_types ON s1_.TranTypeID = transaction_types.trans_id
        INNER JOIN sysuser_tab ON s1_.CreatedBy = sysuser_tab.UserID
        INNER JOIN tbl_warehouse AS `from` ON s1_.WHIDFrom = `from`.wh_id
        INNER JOIN tbl_warehouse AS `to` ON s1_.WHIDTo = `to`.wh_id
        INNER JOIN tbl_warehouse  AS  fs ON s3_.funding_source = fs.wh_id
        WHERE
                s3_.item_id = $this->item_id
        AND (
                DATE_FORMAT(s1_.TranDate, '%Y-%m-%d') BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'
        )
        $fs
        ORDER BY
	s1_.TranDate ASC,
	adjustment_type ASC,
	quantity ASC";
		//        echo '<pre>';print_r($this);
		//        echo $strSql;exit;
		//query result
		$rsSql = mysql_query($strSql) or die("Error GetStockLedger");
		$data = array();
		if (mysql_num_rows($rsSql) > 0) {
			while ($row = mysql_fetch_assoc($rsSql)) {
				$data[] = $row;
			}
			return $data;
		} else {
			return false;
		}
	}


	function getBatchOB($batchId, $trDate)
	{
		list($dd, $mm, $yy) = explode("/", $trDate);
		$trDate1 = $yy . "-" . $mm . "-" . $dd;
		//select query
		$strSql = "SELECT
	SUM(s0_.Qty) AS sclr0
        FROM
                tbl_stock_detail s0_
        INNER JOIN tbl_stock_master s1_ ON s0_.fkStockID = s1_.PkStockID
        INNER JOIN stock_batch s2_ ON s0_.BatchID = s2_.batch_id
        WHERE
                s2_.batch_id = $batchId
            AND DATE_FORMAT(
                s1_.TranDate,
                '%Y-%m-%d'
            ) < '" . $trDate1 . "'
        ORDER BY
                s1_.TranDate ASC";
		//query result
		$rsSql = mysql_query($strSql) or die("Error stockExists");
		$data = array();
		if (mysql_num_rows($rsSql) > 0) {
			$row = mysql_fetch_assoc($rsSql);
			return $row['sclr0'];
		} else {
			return 0;
		}
	}

	public function getBatchOBCB($type, $item, $trDate, $funding_source = '')
	{
		$wh_id = $_SESSION['user_warehouse'];

		$fs = '';
		if (!empty($funding_source) && $funding_source != '' && $funding_source != 'all') {
			$fs = " AND s1_.funding_source = $funding_source ";
		}

		$operator = '<';

		if ($type == 'CB') {
			$operator = '<=';
		}

		$strSql = "SELECT
                        SUM(s0_.Qty) AS Qty,
                        s1_.batch_no,
                        s1_.batch_id,
                        tbl_warehouse.wh_name as funding_source_name

                    FROM
                        tbl_stock_detail s0_
                    INNER JOIN tbl_stock_master s3_ ON s0_.fkStockID = s3_.PkStockID
                    INNER JOIN stock_batch s1_ ON s0_.BatchID = s1_.batch_id
                    INNER JOIN itminfo_tab i2_ ON s1_.item_id = i2_.itm_id
                    INNER JOIN tbl_warehouse ON s1_.funding_source = tbl_warehouse.wh_id
                    WHERE
                        i2_.itm_id = $item
                        AND s1_.wh_id = $wh_id
                        AND DATE_FORMAT(s3_.TranDate, '%Y-%m-%d') $operator '" . $trDate . "'
                        $fs
                    GROUP BY
                        s1_.batch_id
                    HAVING
                        Qty <> 0";
		//echo $strSql;exit;
		//query result
		$rsSql = mysql_query($strSql) or die("Error getBatchOBCB");
		$data = array();
		if (mysql_num_rows($rsSql) > 0) {
			while ($row = mysql_fetch_assoc($rsSql)) {
				$data[] = $row;
			}
			return $data;
		} else {
			return array();
		}
	}


	public function getBatchOBCBProvLvl($type, $district, $item, $trDate, $funding_source = '')
	{
		//        $wh_id = $_SESSION['user_warehouse'];
		$wh_id = $district;

		$fs = '';
		if (!empty($funding_source) && $funding_source != '' && $funding_source != 'all') {
			$fs = " AND s1_.funding_source = $funding_source ";
		}

		$operator = '<';

		if ($type == 'CB') {
			$operator = '<=';
		}

		$strSql = "SELECT
                        SUM(s0_.Qty) AS Qty,
                        s1_.batch_no,
                        s1_.batch_id,
                        tbl_warehouse.wh_name as funding_source_name

                    FROM
                        tbl_stock_detail s0_
                    INNER JOIN tbl_stock_master s3_ ON s0_.fkStockID = s3_.PkStockID
                    INNER JOIN stock_batch s1_ ON s0_.BatchID = s1_.batch_id
                    INNER JOIN itminfo_tab i2_ ON s1_.item_id = i2_.itm_id
                    INNER JOIN tbl_warehouse ON s1_.funding_source = tbl_warehouse.wh_id
                    WHERE
                        i2_.itm_id = $item
                        AND DATE_FORMAT(s3_.TranDate, '%Y-%m-%d') $operator '" . $trDate . "'
                        $fs
                    GROUP BY
                        s1_.batch_id
                    HAVING
                        Qty <> 0";
		//        echo $strSql;exit;
		//query result
		$rsSql = mysql_query($strSql) or die("Error getBatchOBCB");
		$data = array();
		if (mysql_num_rows($rsSql) > 0) {
			while ($row = mysql_fetch_assoc($rsSql)) {
				$data[] = $row;
			}
			return $data;
		} else {
			return array();
		}
	}
	/**
	 * 
	 * GetTempStockIssue
	 * @param type $user
	 * @param type $wh_id
	 * @param type $type
	 * @return boolean
	 * 
	 * 
	 */
	function GetTempStockIssue($user, $wh_id, $type)
	{
		//select query
		//gets
		//transaction num,
		//transaction ref,
		//transaction Date,
		//Pk Stock ID,
		//Received Remarks,
		//warehouse name,
		//To warehouse,
		//issued by,
		//funding source
		$strSql = "SELECT
					tbl_stock_master.TranNo,
					tbl_stock_master.TranRef,
					tbl_stock_master.TranDate,
					tbl_stock_master.PkStockID,
					tbl_stock_master.ReceivedRemarks,
					CONCAT(tbl_warehouse.wh_name, ' (', stakeholder.stkname, ')') AS wh_name,
					tbl_stock_master.WHIDTo,
					tbl_stock_master.issued_by,
					stock_batch.funding_source,
                                        tbl_stock_master.requisition_type,
                                        tbl_stock_master.method
				FROM
					tbl_stock_master
				INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
				INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
				INNER JOIN tbl_warehouse ON tbl_warehouse.wh_id = tbl_stock_master.WHIDTo
				INNER JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid
				WHERE
					tbl_stock_master.CreatedBy = $user
				AND tbl_stock_master.WHIDFrom = $wh_id
				AND tbl_stock_master.temp = 1
				AND tbl_stock_master.TranTypeID = $type";

		//query result
		$rsSql = mysql_query($strSql) or die("Error GetTempStockIssue");
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * GetStocksIssueList
	 * @param type $userid
	 * @param type $wh_id
	 * @param type $type
	 * @param type $stockid
	 * @return boolean
	 * 
	 * 
	 */

	/**
	 * 
	 * updateTemp
	 * @param type $id
	 * @return boolean
	 * 
	 * 
	 */
	function updateTemp($id)
	{
		//update query
		$strSql = "Update tbl_stock_master set temp=0 where PkStockID=$id";
		//query result
		$rsSql = mysql_query($strSql) or die("Error updateTemp");
		if (mysql_affected_rows() > 0) {
			return true;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * GetTempStocksIssueList
	 * @param type $userid
	 * @param type $wh_id
	 * @param type $type
	 * @return boolean
	 * 
	 * 
	 */
	function GetTempStocksIssueList($userid, $wh_id, $type)
	{
		//select query
		//gets
		//transaction date
		//qty
		//batch num
		//unit price
		//batch expiry
		//item name
		//carton qty
		//waerhouse name
		//unit type
		//pk stock id
		//transaction num
		//transaction ref
		//pk detail id
		$strSql = "SELECT
            tbl_stock_master.TranDate,
            tbl_stock_detail.Qty,
            stock_batch.batch_no,
                    stock_batch.unit_price,
            stock_batch.batch_expiry,
            itminfo_tab.itm_name,
            CONCAT(tbl_warehouse.wh_name, ' (', stakeholder.stkname, ')') AS wh_name,
            tbl_itemunits.UnitType,
            tbl_stock_master.PkStockID,
            tbl_stock_master.TranNo,
            tbl_stock_master.TranRef,
            tbl_stock_detail.PkDetailID,
            itminfo_tab.qty_carton as qty_carton_old,
            stakeholder_item.quantity_per_pack as qty_carton
        FROM
        tbl_stock_master
        INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
        INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
        INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
        INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDTo = tbl_warehouse.wh_id
        LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
        LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
		INNER JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid
        WHERE
        tbl_stock_detail.temp = 1 AND
        tbl_stock_master.temp = 1 AND
        tbl_stock_master.WHIDFrom = '" . $wh_id . "' AND
        tbl_stock_master.CreatedBy = " . $userid . " AND 
		tbl_stock_master.TranTypeID =" . $type . " 
		ORDER BY itminfo_tab.frmindex ASC";

		//echo $strSql;exit;
		$rsSql = mysql_query($strSql) or die("Error GetTempStocksIssueList");
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * GetTempStockReceive
	 * @param type $user
	 * @param type $wh_id
	 * @param type $type
	 * @return boolean
	 * 
	 * 
	 */
	function GetTempStockReceive($user, $wh_id, $type)
	{
		//select query
		//gets
		//pk stock id
		//transaction num
		//transaction ref
		//transaction date
		//pk stock id
		//warehouse name
		//from warehouse
		$strSql = "SELECT
			tbl_stock_master.PkStockID,
			tbl_stock_master.TranNo,
			tbl_stock_master.TranRef,
			tbl_stock_master.TranDate,
			tbl_stock_master.PkStockID,
			tbl_warehouse.wh_name,
			tbl_stock_master.WHIDFrom,
                        tbl_stock_master.source_type,
                        tbl_stock_master.shipment_mode,
                        tbl_stock_master.attachment_name,
                        tbl_stock_master.event
		FROM
			tbl_stock_master
		INNER JOIN tbl_warehouse ON tbl_warehouse.wh_id = tbl_stock_master.WHIDTo
		WHERE
			tbl_stock_master.CreatedBy = $user
		AND tbl_stock_master.WHIDTo = $wh_id
		AND tbl_stock_master.temp = 1
		AND tbl_stock_master.TranTypeID = $type";
		//query result
		//        echo $strSql;exit;
		$rsSql = mysql_query($strSql) or die("Error GetTempStockReceive");
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * GetTempStockRUpdate
	 * @param type $PkStockID
	 * @return boolean
	 * 
	 * 
	 */
	function GetTempStockRUpdate($PkStockID = 0)
	{
		//select query
		//gets
		//pk stock id
		//transaction num
		//transaction date
		//pk stock id
		//warehouse name
		//item id
		//from warehouse
		$strSql = "SELECT
			tbl_stock_master.PkStockID,
			tbl_stock_master.TranNo,
			tbl_stock_master.TranRef,
			tbl_stock_master.TranDate,
			tbl_stock_master.PkStockID,
			tbl_warehouse.wh_name,
			itminfo_tab.itm_id,
			tbl_stock_master.WHIDFrom,
                        tbl_stock_master.source_type,
                        tbl_stock_master.shipment_mode,
                        tbl_stock_master.attachment_name,
                        tbl_stock_master.event
		FROM
			tbl_stock_master
		INNER JOIN tbl_warehouse ON tbl_warehouse.wh_id = tbl_stock_master.WHIDFrom
		 INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
                INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
		INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
		WHERE tbl_stock_master.PkStockID = $PkStockID";
		//query result
		$rsSql = mysql_query($strSql) or die("Error GetTempStockRUpdate");
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * GetTempStocksReceiveList
	 * @param type $userid
	 * @param type $wh_id
	 * @param type $type
	 * @return boolean
	 * 
	 * 
	 */
	function GetTempStocksReceiveList($userid, $wh_id, $type)
	{
		$strSql = "
        SELECT
			tbl_stock_master.TranDate,
			tbl_stock_detail.Qty,
			stock_batch.manufacturer,
                        stock_batch.batch_id,
			stock_batch.batch_no,
			stock_batch.production_date,
			stock_batch.batch_expiry,
			itminfo_tab.itm_name,
			stakeholder_item.quantity_per_pack as qty_carton,
			tbl_warehouse.wh_name,
			tbl_stock_master.PkStockID,
			tbl_stock_master.TranNo,
			tbl_stock_master.TranRef,
			tbl_stock_detail.PkDetailID,
			tbl_itemunits.UnitType
		FROM
			tbl_stock_master
		INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
		INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
		LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
		INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
		INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDFrom = tbl_warehouse.wh_id
		LEFT JOIN tbl_itemunits ON  itminfo_tab.itm_type= tbl_itemunits.UnitType
		WHERE
			tbl_stock_detail.temp = 1 AND
			tbl_stock_master.temp = 1 AND
			tbl_stock_master.WHIDTo = '" . $wh_id . "' AND
			tbl_stock_master.CreatedBy = " . $userid . " AND 
			tbl_stock_master.TranTypeID =" . $type . "
		ORDER BY stock_batch.batch_no ASC ";

		//        echo $strSql;exit;
		$rsSql = mysql_query($strSql) or die("Error GetTempStocksReceiveList");
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * GetLastInseredTempStocksReceiveList
	 * @param type $userid
	 * @param type $wh_id
	 * @param type $type
	 * @return boolean
	 * 
	 * 
	 */
	function GetLastInseredTempStocksReceiveList($userid, $wh_id, $type)
	{
		$strSql = "SELECT
        tbl_stock_master.TranDate,
        tbl_stock_detail.Qty,
        tbl_stock_detail.manufacturer,
        stock_batch.batch_no,
        stock_batch.production_date,
		stock_batch.batch_expiry,
        itminfo_tab.itm_name,
        tbl_warehouse.wh_name,
        tbl_stock_master.PkStockID,
        tbl_stock_master.TranNo,
        tbl_stock_master.TranRef,
		tbl_stock_detail.PkDetailID,
		itminfo_tab.itm_id,
		stock_batch.unit_price
        FROM
        tbl_stock_master
        INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
        INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
        INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
        INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDFrom = tbl_warehouse.wh_id
        WHERE
        tbl_stock_detail.temp = 1 AND
        tbl_stock_master.temp = 1 AND
        tbl_stock_master.WHIDTo = '" . $wh_id . "' AND
        tbl_stock_master.CreatedBy = " . $userid . " AND 
		tbl_stock_master.TranTypeID =" . $type . "
		ORDER BY tbl_stock_detail.PkDetailID DESC LIMIT 1 ";
		$rsSql = mysql_query($strSql) or die("Error :" . $strSql);
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * GetStocksReceiveList
	 * @param type $userid
	 * @param type $wh_id
	 * @param type $type
	 * @param type $stockid
	 * @return boolean
	 * 
	 * 
	 */
	//    function GetStocksReceiveList($userid, $wh_id, $type, $stockid) {
	//        $strSql = "SELECT
	//        tbl_stock_master.TranDate,
	//        tbl_stock_detail.Qty,
	//        stock_batch.batch_no,
	//        stock_batch.production_date,
	//		stock_batch.batch_expiry,
	//        itminfo_tab.itm_name,
	//		IFNULL(stakeholder_item.quantity_per_pack, itminfo_tab.qty_carton) qty_carton,
	//        tbl_warehouse.wh_name,
	//        tbl_stock_master.PkStockID,
	//        stakeholder_item.quantity_per_pack,
	//        tbl_stock_master.TranNo,
	//        tbl_stock_master.TranRef,
	//        tbl_itemunits.UnitType,
	//		tbl_stock_detail.PkDetailID,
	//		stakeholder.stk_type_id
	//        FROM
	//        tbl_stock_master
	//        INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
	//        INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
	//        LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
	//        INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
	//        INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDFrom = tbl_warehouse.wh_id
	//		INNER JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid
	//        LEFT JOIN tbl_itemunits ON  itminfo_tab.itm_type= tbl_itemunits.UnitType
	//        WHERE
	//        tbl_stock_master.WHIDTo = '" . $wh_id . "' AND
	//        tbl_stock_master.CreatedBy = " . $userid . " AND 
	//		tbl_stock_master.TranTypeID =" . $type . " AND tbl_stock_master.PkStockID = $stockid
	//		ORDER BY itminfo_tab.frmindex ASC,
	//		stock_batch.batch_no ASC";
	//        $rsSql = mysql_query($strSql) or die("Error GetStocksReceiveList");
	//        if (mysql_num_rows($rsSql) > 0) {
	//            return $rsSql;
	//        } else {
	//            return FALSE;
	//        }
	//    }

	/**
	 * 
	 * StockAdjustmentSearch
	 * @return boolean
	 * 
	 * 
	 */
	function StockAdjustmentSearch()
	{
		$strSql = "SELECT
        tbl_stock_master.TranDate,
        tbl_stock_master.TranNo,
        tbl_stock_master.TranRef,
         tbl_stock_master.PkStockID,
        itminfo_tab.itm_name,
        itminfo_tab.generic_name,
        stock_batch.batch_no,
        tbl_stock_detail.Qty,
        tbl_stock_master.ReceivedRemarks,
        transaction_types.trans_type,
        itminfo_tab.itm_type,
        itminfo_tab.qty_carton,
        tbl_stock_detail.PkDetailID,
        tbl_stock_detail.BatchID
        FROM
        tbl_stock_master
        INNER JOIN tbl_stock_detail ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
        INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
        INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
        INNER JOIN transaction_types ON tbl_stock_master.TranTypeID = transaction_types.trans_id";
		if (!empty($this->TranNo)) {
			$where[] = "tbl_stock_master.TranNo LIKE '%" . $this->TranNo . "%'";
		}
		if (!empty($this->TranTypeID)) {
			$where[] = "tbl_stock_master.TranTypeID = '" . $this->TranTypeID . "'";
		}
		if (!empty($this->WHIDFrom)) {
			$where[] = "tbl_stock_master.WHIDFrom = '" . $this->WHIDFrom . "'";
		}
		if (!empty($this->WHIDTo)) {
			$where[] = "tbl_stock_master.WHIDTo = '" . $this->WHIDTo . "'";
		}
		if (!empty($this->item_id)) {
			$where[] = "stock_batch.item_id = '" . $this->item_id . "'";
		}
		if (!empty($this->batch_id)) {
			$where[] = "stock_batch.batch_id = '" . $this->batch_id . "'";
		}
		if (!empty($this->fromDate) && !empty($this->toDate)) {
			$where[] = "tbl_stock_master.TranDate BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'";
		}

		if (is_array($where)) {
			$strSql .= " WHERE " . implode(" AND ", $where);
		}

		$strSql .= " GROUP BY tbl_stock_master.TranNo ORDER BY tbl_stock_master.TranNo DESC";
		//echo $strSql;exit;
		$rsSql = mysql_query($strSql) or die("Error StockAdjustmentSearch");
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	function StockAdjustmentSearch_multi_wh()
	{
		$strSql = "SELECT
tbl_warehouse.wh_name,
                    tbl_stock_master.TranDate,
                    tbl_stock_master.TranNo,
                    tbl_stock_master.TranRef,
                     tbl_stock_master.PkStockID,
                    itminfo_tab.itm_name,
                    stock_batch.batch_no,
                    tbl_stock_detail.Qty,
                    tbl_stock_master.ReceivedRemarks,
                    transaction_types.trans_type,
                    itminfo_tab.itm_type,
                    itminfo_tab.qty_carton,
                    tbl_stock_detail.PkDetailID,
                    tbl_stock_detail.BatchID
                    FROM
                    tbl_stock_master
                    INNER JOIN tbl_stock_detail ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
                    INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
                    INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                    INNER JOIN transaction_types ON tbl_stock_master.TranTypeID = transaction_types.trans_id
                    INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDFrom = tbl_warehouse.wh_id ";
		if (!empty($this->TranNo)) {
			$where[] = "tbl_stock_master.TranNo LIKE '%" . $this->TranNo . "%'";
		}
		if (!empty($this->TranTypeID)) {
			$where[] = "tbl_stock_master.TranTypeID = '" . $this->TranTypeID . "'";
		}
		if (!empty($this->WHIDFrom)) {
			$where[] = "tbl_stock_master.WHIDFrom in (" . implode(',', $this->WHIDFrom) . ") ";
		}

		$where[] = "tbl_stock_master.WHIDTo = tbl_stock_master.WHIDFrom";

		if (!empty($this->item_id)) {
			$where[] = "stock_batch.item_id = '" . $this->item_id . "'";
		}
		if (!empty($this->batch_id)) {
			$where[] = "stock_batch.batch_id = '" . $this->batch_id . "'";
		}
		if (!empty($this->fromDate) && !empty($this->toDate)) {
			$where[] = "tbl_stock_master.TranDate BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'";
		}

		if (is_array($where)) {
			$strSql .= " WHERE " . implode(" AND ", $where);
		}

		$strSql .= " GROUP BY tbl_stock_master.WHIDFrom,tbl_stock_master.TranNo ORDER BY tbl_stock_master.TranNo DESC";
		//echo $strSql;exit;
		$rsSql = mysql_query($strSql) or die("Error StockAdjustmentSearch");
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * StockAdjustmentSearchList
	 * @param type $stockpkid
	 * @return boolean
	 * 
	 * 
	 */
	function StockAdjustmentSearchList($stockpkid)
	{
		$strSql = "SELECT
        tbl_stock_master.TranDate,
        tbl_stock_master.TranNo,
        tbl_stock_master.TranRef,
         tbl_stock_master.PkStockID,
        itminfo_tab.itm_name,
        itminfo_tab.qty_carton,
        stock_batch.batch_no,
		stock_batch.batch_expiry,
        tbl_stock_detail.Qty,
        tbl_stock_master.ReceivedRemarks,
        transaction_types.trans_type,
        itminfo_tab.itm_type,
		tbl_warehouse.wh_name
        FROM
        tbl_stock_master
        INNER JOIN tbl_stock_detail ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
        INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
        INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
        INNER JOIN transaction_types ON tbl_stock_master.TranTypeID = transaction_types.trans_id
		INNER JOIN tbl_warehouse ON stock_batch.wh_id = tbl_warehouse.wh_id";

		$strSql .= " WHERE tbl_stock_master.PkStockID = " . $stockpkid . " ORDER BY tbl_stock_master.TranNo DESC";
		$rsSql = mysql_query($strSql) or die("Error StockAdjustmentSearch");
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * StockSearch
	 * @param type $type
	 * @param type $wh_id
	 * @return boolean
	 * 
	 * 
	 */
	function StockSearch($type, $wh_id, $groupby = '', $page_type = '')
	{
		if ($page_type == 'summary') {
			$detail_column = "SUM(tbl_stock_detail.Qty) as Qty";
		} else {
			$detail_column = "tbl_stock_detail.Qty";
		}
		//select query
		$strSql = "SELECT
					tbl_stock_master.TranDate,
					tbl_stock_master.PkStockID,
					tbl_stock_master.TranNo,
					tbl_stock_master.TranRef,
					tbl_warehouse.wh_name,
					itminfo_tab.itm_name,
                                        itminfo_tab.generic_name,
					stock_batch.batch_no,
					$detail_column,
                                        stakeholder_item.unit_price*tbl_stock_detail.Qty as price_of_qty,
					tbl_itemunits.UnitType,
					tbl_stock_detail.PkDetailID,
					stock_batch.batch_id AS BatchID,
					stock_batch.batch_expiry,
					stakeholder.stkname,
                                        stakeholder_item.unit_price,
                                         IFNULL(stakeholder_item.quantity_per_pack, itminfo_tab.qty_carton) qty_carton,
                                         itminfo_tab.field_color,
                                        tbl_stock_master.CreatedBy,
                                        tbl_stock_master.CreatedOn,
                                        tbl_stock_master.source_type,
                                        tbl_stock_master.shipment_mode,
                                        tbl_stock_master.attachment_name,
                                        tbl_stock_master.event,
                                        tbl_stock_detail.PkDetailID
				FROM
					tbl_stock_master
					INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
					INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDFrom = tbl_warehouse.wh_id
					INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
					INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
					LEFT JOIN tbl_itemunits ON itminfo_tab.item_unit_id = tbl_itemunits.pkUnitID
					LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
                    LEFT JOIN stakeholder ON stakeholder_item.stkid = stakeholder.stkid";

		if (!empty($this->TranNo)) {
			$where[] = "tbl_stock_master.TranNo LIKE '%" . $this->TranNo . "%'";
		}
		if (!empty($this->batch_no)) {
			$where[] = "stock_batch.batch_no LIKE '%" . $this->batch_no . "%'";
		}
		if (!empty($this->TranRef)) {
			$where[] = "tbl_stock_master.TranRef LIKE '%" . $this->TranRef . "%'";
		}
		if (!empty($this->WHIDFrom)) {
			$where[] = "tbl_stock_master.WHIDFrom = '" . $this->WHIDFrom . "'";
		}
		if (!empty($this->item_id)) {
			$where[] = "stock_batch.item_id = '" . $this->item_id . "'";
		}
		if (!empty($this->manufacturer)) {
			$where[] = "stock_batch.manufacturer = '" . $this->manufacturer . "'";
		}
		if (!empty($this->WHIDTo)) {
			$where[] = "stock_batch.funding_source = '" . $this->WHIDTo . "'";
		}
		if (!empty($this->fromDate) && !empty($this->toDate)) {
			$where[] = "DATE_FORMAT(tbl_stock_master.TranDate, '%Y-%m-%d') BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'";
		}

		$where[] = "tbl_stock_master.TranTypeID = $type";
		$where[] = "stock_batch.wh_id = $wh_id";
		$where[] = "tbl_stock_detail.temp = 0";

		if (is_array($where)) {
			$strSql .= " WHERE " . implode(" AND ", $where);
		}
		$groupby = !empty($groupby) ? $groupby : ' ORDER BY tbl_stock_master.TranNo DESC';
		$strSql = $strSql . $groupby;

		//$strSql = $strSql . ' GROUP BY tbl_stock_master.TranNo ORDER BY tbl_stock_master.TranNo DESC';
		//$strSql = $strSql . ' ORDER BY tbl_stock_master.TranNo DESC';
		//        print_r($strSql);exit;
		$rsSql = mysql_query($strSql) or trigger_error(mysql_error() . $strSql);
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	function inward_cargo_search($type, $wh_id)
	{

		$detail_column = "tbl_stock_detail.Qty";

		//select query
		$strSql = "SELECT
					tbl_stock_master.TranDate,
					tbl_stock_master.PkStockID,
					tbl_stock_master.TranNo,
					tbl_stock_master.TranRef,
					tbl_warehouse.wh_name,
					itminfo_tab.itm_name,
					stock_batch.batch_no,
					$detail_column,
                                        stakeholder_item.unit_price*tbl_stock_detail.Qty as price_of_qty,
					tbl_itemunits.UnitType,
					tbl_stock_detail.PkDetailID,
					stock_batch.batch_id AS BatchID,
					stock_batch.batch_expiry,
					stakeholder.stkname,
                                        stakeholder_item.unit_price,
                                         IFNULL(stakeholder_item.quantity_per_pack, itminfo_tab.qty_carton) qty_carton,
                                         itminfo_tab.field_color,
                                        tbl_stock_master.CreatedBy
				FROM
					tbl_stock_master
					INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
					INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDFrom = tbl_warehouse.wh_id
					INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
					INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
					LEFT JOIN tbl_itemunits ON itminfo_tab.item_unit_id = tbl_itemunits.pkUnitID
					LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
                    LEFT JOIN stakeholder ON stakeholder_item.stkid = stakeholder.stkid";

		if (!empty($this->TranNo)) {
			$where[] = "tbl_stock_master.TranNo LIKE '%" . $this->TranNo . "%'";
		}
		if (!empty($this->batch_no)) {
			$where[] = "stock_batch.batch_no LIKE '%" . $this->batch_no . "%'";
		}
		if (!empty($this->TranRef)) {
			$where[] = "tbl_stock_master.TranRef LIKE '%" . $this->TranRef . "%'";
		}
		if (!empty($this->WHIDFrom)) {
			$where[] = "tbl_stock_master.WHIDFrom = '" . $this->WHIDFrom . "'";
		}
		if (!empty($this->item_id)) {
			$where[] = "stock_batch.item_id = '" . $this->item_id . "'";
		}
		if (!empty($this->manufacturer)) {
			$where[] = "stock_batch.manufacturer = '" . $this->manufacturer . "'";
		}
		if (!empty($this->WHIDTo)) {
			$where[] = "stock_batch.funding_source = '" . $this->WHIDTo . "'";
		}
		if (!empty($this->fromDate) && !empty($this->toDate)) {
			$where[] = "DATE_FORMAT(tbl_stock_master.TranDate, '%Y-%m-%d') BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'";
		}

		$where[] = "tbl_stock_master.TranTypeID = $type";
		$where[] = "stock_batch.wh_id = $wh_id";
		$where[] = "tbl_stock_detail.temp = 0";

		if (is_array($where)) {
			$strSql .= " WHERE " . implode(" AND ", $where);
		}
		$groupby = '';
		$groupby .= ' ORDER BY tbl_stock_master.TranNo DESC';
		$strSql = $strSql . $groupby;

		//$strSql = $strSql . ' GROUP BY tbl_stock_master.TranNo ORDER BY tbl_stock_master.TranNo DESC';
		//$strSql = $strSql . ' ORDER BY tbl_stock_master.TranNo DESC';
		//echo $strSql;
		$rsSql = mysql_query($strSql) or trigger_error(mysql_error() . $strSql);
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	function StockSearch_multi_wh($type, $wh_arr, $groupby = '', $page_type = '')
	{
		if ($page_type == 'summary') {
			$detail_column = "SUM(tbl_stock_detail.Qty) as Qty";
		} else {
			$detail_column = "tbl_stock_detail.Qty";
		}
		//select query
		$strSql = "SELECT
rcvd_at.wh_name as rcvd_at_wh,
					tbl_stock_master.TranDate,
					tbl_stock_master.PkStockID,
					tbl_stock_master.TranNo,
					tbl_stock_master.TranRef,
					tbl_warehouse.wh_name,
					itminfo_tab.itm_name,
					stock_batch.batch_no,
					$detail_column,
                                        stakeholder_item.unit_price*tbl_stock_detail.Qty as price_of_qty,
					tbl_itemunits.UnitType,
					tbl_stock_detail.PkDetailID,
					stock_batch.batch_id AS BatchID,
					stock_batch.batch_expiry,
					stakeholder.stkname,
                                        stakeholder_item.unit_price,
                                         IFNULL(stakeholder_item.quantity_per_pack, itminfo_tab.qty_carton) qty_carton,
                                         itminfo_tab.field_color
				FROM
					tbl_stock_master
					INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
					INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDFrom = tbl_warehouse.wh_id
					INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
                                        INNER JOIN tbl_warehouse rcvd_at ON stock_batch.wh_id = rcvd_at.wh_id
					INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
					LEFT JOIN tbl_itemunits ON itminfo_tab.item_unit_id = tbl_itemunits.pkUnitID
					LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
                    LEFT JOIN stakeholder ON stakeholder_item.stkid = stakeholder.stkid";

		if (!empty($this->TranNo)) {
			$where[] = "tbl_stock_master.TranNo LIKE '%" . $this->TranNo . "%'";
		}
		if (!empty($this->batch_no)) {
			$where[] = "stock_batch.batch_no LIKE '%" . $this->batch_no . "%'";
		}
		if (!empty($this->TranRef)) {
			$where[] = "tbl_stock_master.TranRef LIKE '%" . $this->TranRef . "%'";
		}
		if (!empty($this->WHIDFrom)) {
			$where[] = "tbl_stock_master.WHIDFrom = '" . $this->WHIDFrom . "'";
		}
		if (!empty($this->item_id)) {
			$where[] = "stock_batch.item_id = '" . $this->item_id . "'";
		}
		if (!empty($this->manufacturer)) {
			$where[] = "stock_batch.manufacturer = '" . $this->manufacturer . "'";
		}
		if (!empty($this->WHIDTo)) {
			$where[] = "stock_batch.funding_source = '" . $this->WHIDTo . "'";
		}
		if (!empty($this->fromDate) && !empty($this->toDate)) {
			$where[] = "DATE_FORMAT(tbl_stock_master.TranDate, '%Y-%m-%d') BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'";
		}

		$where[] = "tbl_stock_master.TranTypeID = $type";
		$where[] = "stock_batch.wh_id in (" . implode(',', $wh_arr) . ") ";
		$where[] = "tbl_stock_detail.temp = 0";

		if (is_array($where)) {
			$strSql .= " WHERE " . implode(" AND ", $where);
		}
		$groupby = !empty($groupby) ? $groupby : ' ORDER BY tbl_stock_master.TranNo DESC';
		$strSql = $strSql . $groupby;

		//$strSql = $strSql . ' GROUP BY tbl_stock_master.TranNo ORDER BY tbl_stock_master.TranNo DESC';
		//$strSql = $strSql . ' ORDER BY tbl_stock_master.TranNo DESC';
		//echo $strSql;exit;
		$rsSql = mysql_query($strSql) or trigger_error(mysql_error() . $strSql);
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * StockSearchList
	 * @param type $type
	 * @param type $wh_id
	 * @return boolean
	 * 
	 * 
	 */
	function StockSearchList($type, $wh_id)
	{
		//select query
		//gets
		//transaction date
		//pk stock id
		//transaction num
		//warehouse name
		//batch num
		//batch expiry
		//qty
		//item type
		//pk detail id
		//batch id
		//item id
		//item name
		//carton qty
		$strSql = "SELECT
	tbl_stock_master.TranDate,
	tbl_stock_master.PkStockID,
	tbl_stock_master.TranNo,
	tbl_stock_master.TranRef,
	tbl_warehouse.wh_name,
	stock_batch.batch_no,
	stock_batch.batch_expiry,
	tbl_stock_detail.Qty,
	itminfo_tab.itm_type,
	tbl_stock_detail.PkDetailID,
	tbl_stock_detail.BatchID,
	itminfo_tab.itm_id,
	itminfo_tab.itm_name,
	itminfo_tab.qty_carton,
	(
		SELECT
			sum(placements.quantity) AS remValue
		FROM
			placements
		WHERE
			placements.stock_detail_id = tbl_stock_detail.PkDetailID
	) AS sumQty
	FROM
        tbl_stock_master
        INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
        INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDFrom = tbl_warehouse.wh_id
        INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
        INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id";

		if (!empty($this->TranNo)) {
			$where[] = "tbl_stock_master.TranNo LIKE '%" . $this->TranNo . "%'";
		}
		if (!empty($this->batch_no)) {
			$where[] = "stock_batch.batch_no LIKE '%" . $this->batch_no . "%'";
		}
		if (!empty($this->TranRef)) {
			$where[] = "tbl_stock_master.TranRef LIKE '%" . $this->TranRef . "%'";
		}
		if (!empty($this->WHIDFrom)) {
			$where[] = "tbl_stock_master.WHIDFrom = '" . $this->WHIDFrom . "'";
		}
		if (!empty($this->item_id)) {
			$where[] = "stock_batch.item_id = '" . $this->item_id . "'";
		}
		if (!empty($this->manufacturer)) {
			$where[] = "tbl_stock_detail.manufacturer = '" . $this->manufacturer . "'";
		}
		if (!empty($this->fromDate) && !empty($this->toDate)) {
			$where[] = "DATE_FORMAT(tbl_stock_master.TranDate, '%Y-%m-%d') BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'";
		}

		$where[] = "tbl_stock_master.TranTypeID = $type";
		$where[] = "stock_batch.wh_id = $wh_id";
		$where[] = "tbl_stock_detail.temp = 0";

		if (is_array($where)) {
			$strSql .= " WHERE " . implode(" AND ", $where);
		}

		$rsSql = mysql_query($strSql) or trigger_error(mysql_error() . $strSql);
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * addStockSearch
	 * @param type $type
	 * @param type $wh_id
	 * @return boolean
	 * 
	 * 
	 */
	function addStockSearch($type, $wh_id)
	{
		//select query
		//gets
		//pk stock id
		//pk detail id
		//batch id
		//transaction date
		//item name
		//transaction num
		//batch num
		//batch expiry
		$strSql = "SELECT
	tbl_stock_master.PkStockID,
	tbl_stock_detail.PkDetailID,
	tbl_stock_detail.BatchID,
	tbl_stock_master.TranDate,
	itminfo_tab.itm_name,
	tbl_stock_master.TranNo,
	stock_batch.batch_no,
	stock_batch.batch_expiry,
	(
		tbl_stock_detail.Qty / itminfo_tab.qty_carton
	) AS receivedQty,
	sum(placements.quantity) AS allocated,
	ROUND(
		tbl_stock_detail.Qty / itminfo_tab.qty_carton
	) - sum(placements.quantity) AS unallocated
FROM
	tbl_stock_master
INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
INNER JOIN placements ON stock_batch.batch_id = placements.stock_batch_id
WHERE
	tbl_stock_master.TranTypeID = $type
AND tbl_stock_master.WHIDTo = $wh_id
AND placements.quantity > 0
GROUP BY
	tbl_stock_detail.BatchID";

		if (!empty($this->TranNo)) {
			$where[] = "tbl_stock_master.TranNo = '" . $this->TranNo . "'";
		}
		if (!empty($this->batch_no)) {
			$where[] = "stock_batch.batch_no = '" . $this->batch_no . "'";
		}
		if (!empty($this->TranRef)) {
			$where[] = "tbl_stock_master.TranRef = '" . $this->TranRef . "'";
		}
		if (!empty($this->WHIDFrom)) {
			$where[] = "tbl_stock_master.WHIDFrom = '" . $this->WHIDFrom . "'";
		}
		if (!empty($this->item_id)) {
			$where[] = "stock_batch.item_id = '" . $this->item_id . "'";
		}
		if (!empty($this->manufacturer)) {
			$where[] = "tbl_stock_detail.manufacturer = '" . $this->manufacturer . "'";
		}
		if (!empty($this->fromDate) && !empty($this->toDate)) {
			$where[] = "tbl_stock_master.TranDate BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'";
		}

		$where[] = "tbl_stock_master.TranTypeID = $type";
		$where[] = "stock_batch.wh_id = $wh_id";
		$where[] = "tbl_stock_detail.temp = 0";

		if (is_array($where)) {
			$strSql .= " WHERE " . implode(" AND ", $where);
		}

		$strSql = $strSql . ' ORDER BY tbl_stock_master.TranNo DESC';

		$rsSql = mysql_query($strSql) or trigger_error(mysql_error() . $strSql);
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * DelStockSearch
	 * @param type $type
	 * @param type $wh_id
	 * @return boolean
	 * 
	 * 
	 */
	function DelStockSearch($type, $wh_id)
	{
		//select query
		//gets
		//transaction date
		//transaction number
		//transaction ref
		//warehouse name
		//batch num
		//batch expiry
		//qty
		//unit type
		//pk detail id
		//batch id
		//doses per unit
		//item id
		//sysuser name
		$strSql = "SELECT
        log_tbl_stock_master.TranDate,
		log_tbl_stock_master.PkStockID,
        log_tbl_stock_master.TranNo,
        log_tbl_stock_master.TranRef,
        tbl_warehouse.wh_name,
        log_stock_batch.batch_no,
        log_stock_batch.batch_expiry,
        log_tbl_stock_detail.Qty,
        tbl_itemunits.UnitType,
		log_tbl_stock_detail.PkDetailID,
		log_tbl_stock_detail.BatchID,
		itminfo_tab.doses_per_unit,
		itminfo_tab.itm_id,
		CONCAT(DATE_FORMAT(log_tbl_stock_master.deleted_on, '%d/%m/%Y %h:%i:%s %p')) AS DeletedOn,
		sysuser_tab.sysusr_name,
        itminfo_tab.itm_name,(select  sum(placement.qty) as remValue from placement where placement.StockIDetaild=log_tbl_stock_detail.PkDetailID and is_placed=1) as sumQty
        FROM
        log_tbl_stock_master
        INNER JOIN log_tbl_stock_detail ON log_tbl_stock_master.PkStockID = log_tbl_stock_detail.fkStockID
        INNER JOIN tbl_warehouse ON log_tbl_stock_master.WHIDFrom = tbl_warehouse.wh_id
        INNER JOIN log_stock_batch ON log_tbl_stock_detail.BatchID = log_stock_batch.batch_id
        INNER JOIN itminfo_tab ON log_stock_batch.item_id = itminfo_tab.itm_id
        INNER JOIN tbl_itemunits ON itminfo_tab.fkUnitID = tbl_itemunits.pkUnitID
		INNER JOIN sysuser_tab ON log_tbl_stock_master.deleted_by = sysuser_tab.UserID";

		if (!empty($this->TranNo)) {
			$where[] = "log_tbl_stock_master.TranNo = '" . $this->TranNo . "'";
		}
		if (!empty($this->batch_no)) {
			$where[] = "log_stock_batch.batch_no = '" . $this->batch_no . "'";
		}
		if (!empty($this->TranRef)) {
			$where[] = "log_tbl_stock_master.TranRef = '" . $this->TranRef . "'";
		}
		if (!empty($this->WHIDFrom)) {
			$where[] = "log_tbl_stock_master.WHIDFrom = '" . $this->WHIDFrom . "'";
		}
		if (!empty($this->item_id)) {
			$where[] = "log_stock_batch.item_id = '" . $this->item_id . "'";
		}
		if (!empty($this->fromDate) && !empty($this->toDate)) {
			$where[] = "log_tbl_stock_master.TranDate BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'";
		}

		$where[] = "log_tbl_stock_master.TranTypeID = $type";
		$where[] = "log_tbl_stock_detail.temp = 0";

		if (is_array($where)) {
			$strSql .= " WHERE " . implode(" AND ", $where);
		}

		$strSql = $strSql . ' ORDER BY log_tbl_stock_master.TranNo DESC';

		$rsSql = mysql_query($strSql) or trigger_error(mysql_error() . $strSql);
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * StockIssueSearch
	 * @param type $type
	 * @param type $wh_id
	 * @param type $groupby
	 * @return boolean
	 * 
	 * 
	 */
	function StockIssueSearch($type, $wh_id, $groupby = '', $page_type = '')
	{

		if ($page_type == 'summary') {
			$detail_column = "SUM(tbl_stock_detail.Qty) as Qty";
		} else {
			$detail_column = "tbl_stock_detail.Qty";
		}
		//select query
		//gets
		//transaction date
		//pk stock id
		//transaction num
		//pk detail id
		//warehouse name
		//funding source
		//batch
		//batch expiry
		//qty
		//unit type
		//item name
		//carton qty
		$strSql = "SELECT
                        tbl_stock_master.TranDate,
                        tbl_stock_master.PkStockID,
                        tbl_stock_master.TranNo,
                        tbl_stock_master.TranRef,
                        tbl_stock_detail.PkDetailID,
                        tbl_warehouse.wh_name AS wh_name,

                        fundingSource.wh_name AS funding_source,
                        stock_batch.batch_no,
                        stock_batch.batch_expiry,
                        stock_batch.manufacturer,
                        tbl_stock_detail.BatchID,
                        $detail_column,
                        tbl_itemunits.UnitType,
                        itminfo_tab.itm_name,
                        itminfo_tab.generic_name,
                        IFNULL(stakeholder_item.quantity_per_pack, itminfo_tab.qty_carton) qty_carton,
                        itminfo_tab.field_color,
                        stakeholder.stkname,
                        stk_ofc.stkname as stk_office_name,
                                (
                                        SELECT
                                                sum(placements.quantity) AS remValue
                                        FROM
                                                placements
                                        WHERE
                                                placements.stock_detail_id = tbl_stock_detail.PkDetailID
                                        AND is_placed = 0
                                ) AS sumIssueQty,
                                tbl_stock_detail.IsReceived,
                        stk.stkname AS stakeholder_name,
                        stakeholder_item.unit_price,
                        (stakeholder_item.unit_price * abs(tbl_stock_detail.Qty)) AS price_of_qty,
                        tbl_locations.LocName as province,
                        tbl_stock_master.CreatedBy,
                        tbl_stock_master.CreatedOn,
                        stk_ofc.lvl,
                        tbl_warehouse.is_allowed_im,
                        tbl_warehouse.im_start_month,
                        tbl_stock_master.requisition_type,
                        tbl_stock_master.method,
                        tbl_stock_master.attachment_name
        FROM
        tbl_stock_master
        INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
        INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDTo = tbl_warehouse.wh_id
        INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
	LEFT JOIN tbl_warehouse AS fundingSource ON stock_batch.funding_source = fundingSource.wh_id
        INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
       	LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
        LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
        LEFT JOIN stakeholder ON stakeholder_item.stkid = stakeholder.stkid
        left JOIN stakeholder AS stk_ofc ON tbl_warehouse.stkofficeid = stk_ofc.stkid 
        LEFT JOIN stakeholder AS stk ON tbl_warehouse.stkid = stk.stkid
        LEFT JOIN tbl_locations ON tbl_warehouse.prov_id = tbl_locations.PkLocID  ";


		if (!empty($this->TranNo)) {
			$where[] = "tbl_stock_master.TranNo like '%" . $this->TranNo . "%'";
		}
		if (!empty($this->batch_no)) {
			$where[] = "stock_batch.batch_no like '%" . $this->batch_no . "%'";
		}
		if (!empty($this->TranRef)) {
			$where[] = "tbl_stock_master.TranRef like '%" . $this->TranRef . "%'";
		}
		if (!empty($this->WHIDTo)) {
			$where[] = "tbl_stock_master.WHIDTo = '" . $this->WHIDTo . "'";
		}
		if (!empty($this->province)) {
			$where[] = "tbl_warehouse.prov_id = '" . $this->province . "'";
		}
		if (!empty($this->stakeholder)) {
			$where[] = "tbl_warehouse.stkid = '" . $this->stakeholder . "'";
		}
		if (!empty($this->item_id)) {
			$where[] = "stock_batch.item_id = '" . $this->item_id . "'";
		}
		if (!empty($this->fromDate) && !empty($this->toDate)) {
			$where[] = "tbl_stock_master.TranDate BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'";
		}

		if (!empty($this->funding_source)) {
			$where[] = " stock_batch.funding_source = " . $this->funding_source . " ";
		}

		$where[] = "tbl_stock_master.TranTypeID = $type";
		$where[] = "stock_batch.wh_id = $wh_id";
		$where[] = "tbl_stock_detail.temp = 0";

		if (is_array($where)) {
			$strSql .= " WHERE " . implode(" AND ", $where);
		}
		$groupby = !empty($groupby) ? $groupby : ' ORDER BY tbl_stock_master.TranDate DESC, tbl_stock_master.TranNo DESC';
		$strSql = $strSql . $groupby;

		//        echo $strSql;

		$rsSql = mysql_query($strSql) or trigger_error(mysql_error() . $strSql);
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	function StockStatus($type, $wh_id, $groupby = '', $page_type = '')
	{

		if ($page_type == 'summary') {
			$detail_column = "SUM(tbl_stock_detail.Qty) as Qty";
		} else {
			$detail_column = "tbl_stock_detail.Qty";
		}
		//select query
		//gets
		//transaction date
		//pk stock id
		//transaction num
		//pk detail id
		//warehouse name
		//funding source
		//batch
		//batch expiry
		//qty
		//unit type
		//item name
		//carton qty
		$strSql = "SELECT
                        tbl_stock_master.TranDate,
                        tbl_stock_master.PkStockID,
                        tbl_stock_master.TranNo,
                        tbl_stock_master.TranRef,
                        tbl_stock_detail.PkDetailID,
                        tbl_warehouse.wh_name AS wh_name,

                        fundingSource.wh_name AS funding_source,
                        stock_batch.batch_no,
                        stock_batch.batch_expiry,
                        stock_batch.manufacturer,
                        tbl_stock_detail.BatchID,
                        $detail_column,
                        tbl_itemunits.UnitType,
                        itminfo_tab.itm_name,
                        itminfo_tab.generic_name,
                        IFNULL(stakeholder_item.quantity_per_pack, itminfo_tab.qty_carton) qty_carton,
                        itminfo_tab.field_color,
                        stakeholder.stkname,
                        stk_ofc.stkname as stk_office_name,
                                (
                                        SELECT
                                                sum(placements.quantity) AS remValue
                                        FROM
                                                placements
                                        WHERE
                                                placements.stock_detail_id = tbl_stock_detail.PkDetailID
                                        AND is_placed = 0
                                ) AS sumIssueQty,
                                tbl_stock_detail.IsReceived,
                        stk.stkname AS stakeholder_name,
                        stakeholder_item.unit_price,
                        (stakeholder_item.unit_price * abs(tbl_stock_detail.Qty)) AS price_of_qty,
                        tbl_locations.LocName as province,
                        tbl_stock_master.CreatedBy,
                        tbl_stock_master.CreatedOn,
                        stk_ofc.lvl,
                        tbl_warehouse.is_allowed_im,
                        tbl_warehouse.im_start_month
        FROM
        tbl_stock_master
        INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
        INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDTo = tbl_warehouse.wh_id
        INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
	LEFT JOIN tbl_warehouse AS fundingSource ON stock_batch.funding_source = fundingSource.wh_id
        INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
       	LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
        LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
        LEFT JOIN stakeholder ON stakeholder_item.stkid = stakeholder.stkid
        left JOIN stakeholder AS stk_ofc ON tbl_warehouse.stkofficeid = stk_ofc.stkid 
        LEFT JOIN stakeholder AS stk ON tbl_warehouse.stkid = stk.stkid
        LEFT JOIN tbl_locations ON tbl_warehouse.prov_id = tbl_locations.PkLocID  ";


		if (!empty($this->TranNo)) {
			$where[] = "tbl_stock_master.TranNo like '%" . $this->TranNo . "%'";
		}
		if (!empty($this->batch_no)) {
			$where[] = "stock_batch.batch_no like '%" . $this->batch_no . "%'";
		}
		if (!empty($this->TranRef)) {
			$where[] = "tbl_stock_master.TranRef like '%" . $this->TranRef . "%'";
		}
		if (!empty($this->WHIDTo)) {
			$where[] = "tbl_stock_master.WHIDTo = '" . $this->WHIDTo . "'";
		}
		if (!empty($this->province)) {
			$where[] = "tbl_warehouse.prov_id = '" . $this->province . "'";
		}
		if (!empty($this->stakeholder)) {
			$where[] = "tbl_warehouse.stkid = '" . $this->stakeholder . "'";
		}
		if (!empty($this->item_id)) {
			$where[] = "stock_batch.item_id = '" . $this->item_id . "'";
		}
		if (!empty($this->fromDate) && !empty($this->toDate)) {
			$where[] = "tbl_stock_master.TranDate BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'";
		}

		if (!empty($this->funding_source)) {
			$where[] = " stock_batch.funding_source = " . $this->funding_source . " ";
		}

		$where[] = "tbl_stock_master.TranTypeID = $type";
		$where[] = "stock_batch.wh_id = $wh_id";
		$where[] = "tbl_stock_detail.temp = 0";

		if (is_array($where)) {
			$strSql .= " WHERE " . implode(" AND ", $where);
		}
		$groupby = " GROUP BY itminfo_tab.itm_id,tbl_warehouse.wh_id";
		$strSql = $strSql . $groupby;

		$orderby = " ORDER BY province ASC, funding_source ASC, itminfo_tab.itm_name ASC";
		$strSql = $strSql . $orderby;

		$rsSql = mysql_query($strSql) or trigger_error(mysql_error() . $strSql);
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	function distribution_report_search($type, $wh_id)
	{


		$detail_column = "tbl_stock_detail.Qty";

		//select query
		//gets
		//transaction date
		//pk stock id
		//transaction num
		//pk detail id
		//warehouse name
		//funding source
		//batch
		//batch expiry
		//qty
		//unit type
		//item name
		//carton qty
		$strSql = "SELECT
                        tbl_stock_master.TranDate,
                        tbl_stock_master.PkStockID,
                        tbl_stock_master.TranNo,
                        tbl_stock_master.TranRef,
                        tbl_stock_detail.PkDetailID,
                        tbl_warehouse.wh_name AS wh_name,

                        fundingSource.wh_name AS funding_source,
                        stock_batch.batch_no,
                        stock_batch.batch_expiry,
                        stock_batch.manufacturer,
                        tbl_stock_detail.BatchID,
                        $detail_column,
                        tbl_itemunits.UnitType,
                        itminfo_tab.itm_name,
                        IFNULL(stakeholder_item.quantity_per_pack, itminfo_tab.qty_carton) qty_carton,
                        itminfo_tab.field_color,
                        stakeholder.stkname,
                        stk_ofc.stkname as stk_office_name,
                                (
                                        SELECT
                                                sum(placements.quantity) AS remValue
                                        FROM
                                                placements
                                        WHERE
                                                placements.stock_detail_id = tbl_stock_detail.PkDetailID
                                        AND is_placed = 0
                                ) AS sumIssueQty,
                                tbl_stock_detail.IsReceived,
                        stk.stkname AS stakeholder_name,
                        stakeholder_item.unit_price,
                        (stakeholder_item.unit_price * abs(tbl_stock_detail.Qty)) AS price_of_qty,
                        tbl_locations.LocName as province,
                        tbl_stock_master.CreatedBy,
                        tbl_stock_master.CreatedOn,
                        stk_ofc.lvl,
                        tbl_warehouse.is_allowed_im,
                        tbl_warehouse.im_start_month,
                        GROUP_CONCAT(distinct gatepass_master.number) as gate_passes,
                        GROUP_CONCAT(distinct gatepass_master.pk_id) AS gate_pass_id,
GROUP_CONCAT(
		DISTINCT gatepass_vehicles.number ) as vehicles
        FROM
        tbl_stock_master
        INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
        INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDTo = tbl_warehouse.wh_id
        INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
	LEFT JOIN tbl_warehouse AS fundingSource ON stock_batch.funding_source = fundingSource.wh_id
        INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
       	LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
        LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
        LEFT JOIN stakeholder ON stakeholder_item.stkid = stakeholder.stkid
        left JOIN stakeholder AS stk_ofc ON tbl_warehouse.stkofficeid = stk_ofc.stkid 
        LEFT JOIN stakeholder AS stk ON tbl_warehouse.stkid = stk.stkid
        LEFT JOIN tbl_locations ON tbl_warehouse.prov_id = tbl_locations.PkLocID
        LEFT JOIN gatepass_detail ON tbl_stock_detail.PkDetailID = gatepass_detail.stock_detail_id
        LEFT JOIN gatepass_master ON gatepass_detail.gatepass_master_id = gatepass_master.pk_id
LEFT JOIN gatepass_vehicles ON gatepass_master.gatepass_vehicle_id = gatepass_vehicles.pk_id
        ";


		if (!empty($this->TranNo)) {
			$where[] = "tbl_stock_master.TranNo like '%" . $this->TranNo . "%'";
		}
		if (!empty($this->batch_no)) {
			$where[] = "stock_batch.batch_no like '%" . $this->batch_no . "%'";
		}
		if (!empty($this->TranRef)) {
			$where[] = "tbl_stock_master.TranRef like '%" . $this->TranRef . "%'";
		}
		if (!empty($this->WHIDTo)) {
			$where[] = "tbl_stock_master.WHIDTo = '" . $this->WHIDTo . "'";
		}
		if (!empty($this->province)) {
			$where[] = "tbl_warehouse.prov_id = '" . $this->province . "'";
		}
		if (!empty($this->stakeholder)) {
			$where[] = "tbl_warehouse.stkid = '" . $this->stakeholder . "'";
		}
		if (!empty($this->item_id)) {
			$where[] = "stock_batch.item_id = '" . $this->item_id . "'";
		}
		if (!empty($this->fromDate) && !empty($this->toDate)) {
			$where[] = "tbl_stock_master.TranDate BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'";
		}

		if (!empty($this->funding_source)) {
			$where[] = " stock_batch.funding_source = " . $this->funding_source . " ";
		}

		$where[] = "tbl_stock_master.TranTypeID = $type";
		$where[] = "stock_batch.wh_id = $wh_id";
		$where[] = "tbl_stock_detail.temp = 0";

		if (is_array($where)) {
			$strSql .= " WHERE " . implode(" AND ", $where);
		}
		$groupby = ' group by tbl_stock_detail.PkDetailID ';
		$groupby .= ' ORDER BY tbl_stock_master.TranDate DESC, tbl_stock_master.TranNo DESC ';
		$strSql = $strSql . $groupby;

		//echo $strSql;

		$rsSql = mysql_query($strSql) or trigger_error(mysql_error() . $strSql);
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	function StockIssueSearch2($type, $wh_id, $groupby = '', $page_type = '')
	{

		if ($page_type == 'summary') {
			$detail_column = "SUM(tbl_stock_detail.Qty) as Qty";
		} else {
			$detail_column = "tbl_stock_detail.Qty";
		}
		//select query
		//gets
		//transaction date
		//pk stock id
		//transaction num
		//pk detail id
		//warehouse name
		//funding source
		//batch
		//batch expiry
		//qty
		//unit type
		//item name
		//carton qty
		$strSql = "SELECT
                        tbl_stock_master.TranDate,
                        tbl_stock_master.PkStockID,
                        tbl_stock_master.TranNo,
                        tbl_stock_master.TranRef,
                        tbl_stock_detail.PkDetailID,
                        tbl_warehouse.wh_name AS wh_name,

                        fundingSource.wh_name AS funding_source,
                        stock_batch.batch_no,
                        stock_batch.batch_expiry,
                        stock_batch.manufacturer,
                        tbl_stock_detail.BatchID,
                        $detail_column,
                        tbl_itemunits.UnitType,
                        itminfo_tab.itm_name,
                        IFNULL(stakeholder_item.quantity_per_pack, itminfo_tab.qty_carton) qty_carton,
                        itminfo_tab.field_color,
                        stakeholder.stkname,
                        stk_ofc.stkname as stk_office_name,
                                (
                                        SELECT
                                                sum(placements.quantity) AS remValue
                                        FROM
                                                placements
                                        WHERE
                                                placements.stock_detail_id = tbl_stock_detail.PkDetailID
                                        AND is_placed = 0
                                ) AS sumIssueQty,
                                tbl_stock_detail.IsReceived,
                        stk.stkname AS stakeholder_name,
                        stakeholder_item.unit_price,
                        sum(stakeholder_item.unit_price * abs(tbl_stock_detail.Qty)) AS price_of_qty,
                        tbl_locations.LocName as province,
                        tbl_stock_master.CreatedBy,
                        tbl_stock_master.CreatedOn,
                        stk_ofc.lvl
        FROM
        tbl_stock_master
        INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
        INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDTo = tbl_warehouse.wh_id
        INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
	LEFT JOIN tbl_warehouse AS fundingSource ON stock_batch.funding_source = fundingSource.wh_id
        INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
       	LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
        LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
        LEFT JOIN stakeholder ON stakeholder_item.stkid = stakeholder.stkid
        left JOIN stakeholder AS stk_ofc ON tbl_warehouse.stkofficeid = stk_ofc.stkid 
        LEFT JOIN stakeholder AS stk ON tbl_warehouse.stkid = stk.stkid
        LEFT JOIN tbl_locations ON tbl_warehouse.prov_id = tbl_locations.PkLocID  ";


		if (!empty($this->TranNo)) {
			$where[] = "tbl_stock_master.TranNo like '%" . $this->TranNo . "%'";
		}
		if (!empty($this->batch_no)) {
			$where[] = "stock_batch.batch_no like '%" . $this->batch_no . "%'";
		}
		if (!empty($this->TranRef)) {
			$where[] = "tbl_stock_master.TranRef like '%" . $this->TranRef . "%'";
		}
		if (!empty($this->WHIDTo)) {
			$where[] = "tbl_stock_master.WHIDTo = '" . $this->WHIDTo . "'";
		}
		if (!empty($this->province)) {
			$where[] = "tbl_warehouse.prov_id = '" . $this->province . "'";
		}
		if (!empty($this->stakeholder)) {
			$where[] = "tbl_warehouse.stkid = '" . $this->stakeholder . "'";
		}
		if (!empty($this->item_id)) {
			$where[] = "stock_batch.item_id = '" . $this->item_id . "'";
		}
		if (!empty($this->fromDate) && !empty($this->toDate)) {
			$where[] = "tbl_stock_master.TranDate BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'";
		}

		if (!empty($this->funding_source)) {
			$where[] = " stock_batch.funding_source = " . $this->funding_source . " ";
		}

		$where[] = "tbl_stock_master.TranTypeID = $type";
		$where[] = "stock_batch.wh_id = $wh_id";
		$where[] = "tbl_stock_detail.temp = 0";

		if (is_array($where)) {
			$strSql .= " WHERE " . implode(" AND ", $where);
		}
		$groupby = !empty($groupby) ? $groupby : ' ORDER BY tbl_stock_master.TranDate DESC, tbl_stock_master.TranNo DESC';
		$strSql = $strSql . $groupby;

		//echo $strSql;

		$rsSql = mysql_query($strSql) or trigger_error(mysql_error() . $strSql);
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	function StockIssueSearch_multi_wh($type, $wh_arr, $groupby = '', $page_type = '')
	{

		if ($page_type == 'summary') {
			$detail_column = "SUM(tbl_stock_detail.Qty) as Qty";
		} else {
			$detail_column = "tbl_stock_detail.Qty";
		}
		//select query
		//gets
		//transaction date
		//pk stock id
		//transaction num
		//pk detail id
		//warehouse name
		//funding source
		//batch
		//batch expiry
		//qty
		//unit type
		//item name
		//carton qty
		$strSql = "SELECT
            
                        issued_from.wh_name as issued_by_wh,
                        tbl_stock_master.TranDate,
                        tbl_stock_master.PkStockID,
                        tbl_stock_master.TranNo,
                        tbl_stock_master.TranRef,
                        tbl_stock_detail.PkDetailID,
                        tbl_warehouse.wh_name AS wh_name,

                        fundingSource.wh_name AS funding_source,
                        stock_batch.batch_no,
                        stock_batch.batch_expiry,
                        stock_batch.manufacturer,
                        tbl_stock_detail.BatchID,
                        $detail_column,
                        tbl_itemunits.UnitType,
                        itminfo_tab.itm_name,
                        IFNULL(stakeholder_item.quantity_per_pack, itminfo_tab.qty_carton) qty_carton,
                        itminfo_tab.field_color,
                        stakeholder.stkname,
                        stk_ofc.stkname as stk_office_name,
                                (
                                        SELECT
                                                sum(placements.quantity) AS remValue
                                        FROM
                                                placements
                                        WHERE
                                                placements.stock_detail_id = tbl_stock_detail.PkDetailID
                                        AND is_placed = 0
                                ) AS sumIssueQty,
                                tbl_stock_detail.IsReceived,
                        stk.stkname AS stakeholder_name,
                        stakeholder_item.unit_price,
                        (stakeholder_item.unit_price * abs(tbl_stock_detail.Qty)) AS price_of_qty,
                        tbl_locations.LocName as province,
                        tbl_stock_master.CreatedBy,
                        tbl_stock_master.CreatedOn,
                        stk_ofc.lvl
        FROM
        tbl_stock_master
        INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
        INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDTo = tbl_warehouse.wh_id
        INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
	LEFT JOIN tbl_warehouse AS fundingSource ON stock_batch.funding_source = fundingSource.wh_id
        LEFT JOIN tbl_warehouse AS issued_from ON stock_batch.wh_id = issued_from.wh_id
        INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
       	LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
        LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
        LEFT JOIN stakeholder ON stakeholder_item.stkid = stakeholder.stkid
        left JOIN stakeholder AS stk_ofc ON tbl_warehouse.stkofficeid = stk_ofc.stkid 
        LEFT JOIN stakeholder AS stk ON tbl_warehouse.stkid = stk.stkid
        LEFT JOIN tbl_locations ON tbl_warehouse.prov_id = tbl_locations.PkLocID  ";


		if (!empty($this->TranNo)) {
			$where[] = "tbl_stock_master.TranNo like '%" . $this->TranNo . "%'";
		}
		if (!empty($this->batch_no)) {
			$where[] = "stock_batch.batch_no like '%" . $this->batch_no . "%'";
		}
		if (!empty($this->TranRef)) {
			$where[] = "tbl_stock_master.TranRef like '%" . $this->TranRef . "%'";
		}
		if (!empty($this->WHIDTo)) {
			$where[] = "tbl_stock_master.WHIDTo = '" . $this->WHIDTo . "'";
		}
		if (!empty($this->province)) {
			$where[] = "tbl_warehouse.prov_id = '" . $this->province . "'";
		}
		if (!empty($this->stakeholder)) {
			$where[] = "tbl_warehouse.stkid = '" . $this->stakeholder . "'";
		}
		if (!empty($this->item_id)) {
			$where[] = "stock_batch.item_id = '" . $this->item_id . "'";
		}
		if (!empty($this->fromDate) && !empty($this->toDate)) {
			$where[] = "tbl_stock_master.TranDate BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'";
		}

		if (!empty($this->funding_source)) {
			$where[] = " stock_batch.funding_source = " . $this->funding_source . " ";
		}

		$where[] = "tbl_stock_master.TranTypeID = $type";
		$where[] = "stock_batch.wh_id in (" . implode(',', $wh_arr) . ")";
		$where[] = "tbl_stock_detail.temp = 0";

		if (is_array($where)) {
			$strSql .= " WHERE " . implode(" AND ", $where);
		}
		$groupby = !empty($groupby) ? $groupby : ' ORDER BY tbl_stock_master.TranDate DESC, tbl_stock_master.TranNo DESC';
		$strSql = $strSql . $groupby;

		//echo $strSql;

		$rsSql = mysql_query($strSql) or trigger_error(mysql_error() . $strSql);
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * DelStockIssueSearch
	 * @param type $type
	 * @param type $wh_id
	 * @return boolean
	 * 
	 * 
	 */
	function DelStockIssueSearch($type, $wh_id)
	{
		//select query
		//gets
		//transaction date
		//pk stock id
		//transaction num
		//transaction ref
		//pk detail id
		//warehouse name
		//batch number
		//batch expiry
		//batch id
		//qty
		//item name
		//unit type
		$strSql = "SELECT
        log_tbl_stock_master.TranDate,
		log_tbl_stock_master.PkStockID,
        log_tbl_stock_master.TranNo,
        log_tbl_stock_master.TranRef,
		log_tbl_stock_detail.PkDetailID,
        tbl_warehouse.wh_name,
        log_stock_batch.batch_no,
        log_stock_batch.batch_expiry,
		log_tbl_stock_detail.BatchID,
        log_tbl_stock_detail.Qty,
        tbl_itemunits.UnitType,
        itminfo_tab.itm_name,
		itminfo_tab.doses_per_unit,
		CONCAT(DATE_FORMAT(log_tbl_stock_master.deleted_on, '%d/%m/%Y %h:%i:%s %p')) AS DeletedOn,
		sysuser_tab.sysusr_name,
		(select sum(placement.qty) as remValue from placement where placement.StockIDetaild=log_tbl_stock_detail.PkDetailID and is_placed=0) as sumIssueQty
        FROM
        log_tbl_stock_master
        INNER JOIN log_tbl_stock_detail ON log_tbl_stock_master.PkStockID = log_tbl_stock_detail.fkStockID
        INNER JOIN tbl_warehouse ON log_tbl_stock_master.WHIDTo = tbl_warehouse.wh_id
        INNER JOIN log_stock_batch ON log_tbl_stock_detail.BatchID = log_stock_batch.batch_id
        INNER JOIN itminfo_tab ON log_stock_batch.item_id = itminfo_tab.itm_id
        INNER JOIN tbl_itemunits ON itminfo_tab.fkUnitID = tbl_itemunits.pkUnitID
		INNER JOIN sysuser_tab ON log_tbl_stock_master.deleted_by = sysuser_tab.UserID";

		if (!empty($this->TranNo)) {
			$where[] = "log_tbl_stock_master.TranNo like '" . $this->TranNo . "%'";
		}
		if (!empty($this->batch_no)) {
			$where[] = "log_stock_batch.batch_no like '" . $this->batch_no . "%'";
		}
		if (!empty($this->TranRef)) {
			$where[] = "log_tbl_stock_master.TranRef like '" . $this->TranRef . "%'";
		}
		if (!empty($this->WHIDTo)) {
			$where[] = "log_tbl_stock_master.WHIDTo = '" . $this->WHIDTo . "'";
		}
		if (!empty($this->item_id)) {
			$where[] = "log_stock_batch.item_id = '" . $this->item_id . "'";
		}
		if (!empty($this->fromDate) && !empty($this->toDate)) {
			$where[] = "log_tbl_stock_master.TranDate BETWEEN '" . $this->fromDate . "' AND '" . $this->toDate . "'";
		}

		$where[] = "log_tbl_stock_master.TranTypeID = $type";
		$where[] = "log_tbl_stock_detail.temp = 0";

		if (is_array($where)) {
			$strSql .= " WHERE " . implode(" AND ", $where);
		}
		$strSql = $strSql . ' GROUP BY log_stock_batch.batch_id, log_tbl_stock_master.WHIDTo ORDER BY log_tbl_stock_master.TranNo DESC';
		$rsSql = mysql_query($strSql) or trigger_error(mysql_error() . $strSql);
		if (mysql_num_rows($rsSql) > 0) {
			return $rsSql;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * getLastID
	 * @param type $from
	 * @param type $to
	 * @param type $tr_type
	 * @return boolean
	 * 
	 * 
	 */
	function getProcessLastID($from, $to, $status_id)
	{
		//        if ($tr_type == 1) {
		//            $str = "AND wh_id_to='" . $_SESSION['warehouse_id'] . "'";
		//        } else {
		//            $str = "AND wh_id_from='" . $_SESSION['warehouse_id'] . "'";
		//        }
		//        if ($status_id == 0) {
		//            $str = "where status_id='" . $status_id . "'";
		//        } 
		//        else if ($status_id == 1) {
		//            $str = "where status_id='" . $status_id . "'";
		//        } else{
		//            $str = "where status_id='" . $status_id . "'";
		//            $str .= "OR status_id = '3'";
		//        }
		$str = "where process_status='" . $status_id . "' AND approve_from != ''";
		//        if ($status_id == 1) {
		//            $str = "where process_status='" . $status_id . "'";
		//        } 
		//        else if ($status_id == 2) {
		//            $str = "where process_status='" . $status_id . "'";
		//        } else if ($status_id == 3) {
		//            $str = "where process_status='" . $status_id . "' AND active_process = 1";
		//        } else if ($status_id == 4) {
		//            $str = "where process_status='" . $status_id . "' AND active_process = 1";
		//        } else{
		//            $str = "where process_status='" . $status_id . "' AND active_process = 1";
		//            $str .= "OR process_status = '3'";
		//        }
		//        $strSql = "SELECT MAX(tr_no) as Maxtr from " . static::$table_name . " where tran_date between '" . $from . "' and '" . $to . "' $str";
		$strSql = "SELECT MAX(tr_no) as Maxtr from " . static::$table_name . " $str";

		//        echo $strSql;exit;
		return $this->query($strSql);
	}


	function getLastID($from, $to, $status_id)
	{
		//        if ($tr_type == 1) {
		//            $str = "AND wh_id_to='" . $_SESSION['warehouse_id'] . "'";
		//        } else {
		//            $str = "AND wh_id_from='" . $_SESSION['warehouse_id'] . "'";
		//        }
		//        if ($status_id == 0) {
		//            $str = "where status_id='" . $status_id . "'";
		//        } 
		//        else if ($status_id == 1) {
		//            $str = "where status_id='" . $status_id . "'";
		//        } else{
		//            $str = "where status_id='" . $status_id . "'";
		//            $str .= "OR status_id = '3'";
		//        }
		//          $str = "where process_status='" . $status_id . "'";
		if ($status_id == 0) {
			$str = "where tran_type_id NOT IN (3,4) AND parent_id = '0' AND wh_id_to =" . $_SESSION['warehouse_id'];
		} else if ($status_id == 1) {
			$str = "where status_id='" . $status_id . "' AND parent_id = '0' OR null";
		} else if ($status_id == 2) {
			$str = "where status_id='" . $status_id . "' AND parent_id = '0' OR null";
		} else if ($status_id == 3) {
			$str = "where status_id='" . $status_id . "' AND parent_id = '0' OR null";
		} else if ($status_id == 4) {
			$str = "where status_id='" . $status_id . "' AND parent_id = '0' OR null";
		} else if ($status_id == 5) {
			$str = "where status_id='" . $status_id . "'";
		} else {
			$str = "where status_id='" . $status_id . "' AND parent_id = '0' OR null";
			//            $str .= "OR status_id = '3'";
		}
		//        $strSql = "SELECT MAX(tr_no) as Maxtr from " . static::$table_name . " where tran_date between '" . $from . "' and '" . $to . "' $str";
		$strSql = "SELECT MAX(tr_no) as Maxtr from " . static::$table_name . " $str";

		//        echo $strSql;exit;
		return $this->query($strSql);
	}

	/**
	 * 
	 * getAdjLastID
	 * @param type $from
	 * @param type $to
	 * @return boolean
	 * 
	 * 
	 */
	function getAdjLastID($from, $to)
	{
		if (!empty($tr_type) && $tr_type == 1) {
			$str = "AND wh_id_to='" . $_SESSION['warehouse_id'] . "'";
		} else {
			$str = "AND wh_id_from='" . $_SESSION['warehouse_id'] . "'";
		}
		$strSql = "SELECT MAX(tr_no) as Maxtr from " . static::$table_name . " where tran_date between '" . $from . "' and '" . $to . "' AND status_id != 1 AND status_id != 2 $str";
		//echo $strSql;exit;
		return $this->query($strSql);
	}

	/**
	 * 
	 * GetWHStockByIssueNo
	 * @return boolean
	 * 
	 * 
	 */
	function GetWHStockByIssueNo()
	{

		$createdby = '';
		$gwisadj = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		$strSql = "SELECT
                        IF
                        (
                            gwis_detail.field1 IS NULL,
                            gwis_detail.pk_id,
                            MAX( gwis_detail.pk_id )) AS pk_id,
                        gwis_detail.quantity,
                        gwis_detail.dc_quantity,
                        gwis_detail.pi_quantity,
                        gwis_detail.ti_quantity,
                        gwis_detail.actual_rec_qty,
                        gwis_detail.field1,
                        gwis_detail.field2,
                        gwis_detail.field3,
                        gwis_detail.field4,
                        gwis_detail.field5,
                        gwis_detail.field6,
                        gwis_detail.field7,
                        gwis_detail.field8,
                        gwis_detail.field9,
                        gwis_detail.field10,
                        gwis_detail.delivery_challan_type,
                        gwis_detail.challan_type_detail,
                        gwis_detail.driver_name,
                        gwis_detail.driver_contract,
                        gwis_detail.vehicle_reg,
                        gwis_detail.dc_no,
                        gwis_detail.dc_date,
                        gwis_detail.invoice,
                        stock_batch.batch_no,
                        stock_batch.batch_id,
                        itminfo_tab.itm_name,
                        itminfo_tab.itm_id,
                        itminfo_tab.product_type,
                        gwis_detail.fk_stock_id,
                        gwis_master.tran_date,
                        gwis_detail.batch_id,
                        gwis_master.tran_no,
                        gwis_master.tran_ref,
                        ww.wh_name AS wh_from,
                        ws.wh_name AS wh_from_supplier,
                        stakeholder.ntn,
                        stakeholder.gstn,
                        stakeholder.contact_person,
                        stakeholder.contact_numbers,
                        stakeholder.contact_emails,
                        stakeholder.contact_address,
                        stock_batch.production_date,
                        stock_batch.batch_expiry,
                        gwis_detail.siv_no_of_cartons,
                        gwis_detail.invoice,
                        gwis_detail.dc_date,
                        gwis_detail.dc_no,
                        gwis_detail.vehicle_reg,
                        gwis_detail.driver_contract,
                        gwis_detail.driver_name,
                        gwis_detail.challan_type_detail,
                        gwis_detail.ti_comment,
                        gwis_detail.grn_quantity,
                        gwis_detail.giv_quantity,
                        challan_type.challan_type,
                        stock_batch.dtl,
                        stock_batch.unit_price,
                        stock_batch.dtl_result,
                        stock_batch.currency,
                        stock_batch.conversion_rate,
                        gwis_master.pk_id AS masterpkid,
                        gwis_detail.pi_comment,
                        gwis_detail.po_quantity,
                        gwis_detail.comments,
                        gwis_master.wh_id_from,
                        gwis_master.wh_id_to,
                        gwis_master.wh_id_from_supplier,
                        gwis_master.stk_id,
                        gwis_master.inspection_date,
                        gwis_master.delivery_location,
                        gwis_master.po_cmu_no AS po_cmu_no_id,
                        gwis_master.po_cmu_date,
                        gwis_master.po_gf_no AS po_gf_no_id,
                        gwis_master.po_gf_date,
                        gwis_master.date_of_receiving,
                        gwis_master.air_bill_no,
                        gwis_master.shipment_no,
                        gwis_master.origin_of_country,
                        gwis_master.vehicle_type_and_plate,
                        gwis_master.consignment_weight,
                        gwis_master.file,
                        gwis_master.source_type,
                        gwis_master.province_id,
                        gwis_detail.electronic_approval,
                        gwis_detail.pi_type,
                        gwis_detail.sbtr_dc_rec,
                        gwis_detail.siv_driver_name,
                        gwis_detail.siv_contatc_number,
                        gwis_detail.siv_vehicle_plate_no,
                        gwis_detail.siv_cnic,
                        gwis_detail.siv_weight,
                        gwis_detail.siv_no_of_cartons,
                        gwis_detail.siv_transportation_po,
                        gwis_detail.siv_tracking_no,
                        gwis_detail.siv_mode_of_transport,
                        gwis_detail.siv_name_of_transporter,
                        gwis_detail.siv_vehicle_type,
                        gwis_detail.storage,
                        gwis_detail.shipment_temprature,
                        stock_batch.batch_totalprice,
                        stock_batch.manufacturer,
                        po_gf.number AS po_gf_no,
                        po_cmu.number AS po_cmu_no,
                        manf.stkname AS manufacturer_name
                FROM
                        gwis_master
                        INNER JOIN gwis_detail ON gwis_detail.fk_stock_id = gwis_master.pk_id
                        INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                        INNER JOIN itminfo_tab ON itminfo_tab.itm_id = stock_batch.item_id
                        LEFT JOIN tbl_warehouse ON gwis_master.wh_id_from_supplier = tbl_warehouse.wh_id
                        LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                        LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                        LEFT JOIN stakeholder ON tbl_warehouse.stkid = stakeholder.stkid
                        LEFT JOIN challan_type ON gwis_detail.delivery_challan_type = challan_type.pk_id
                        LEFT JOIN po_info AS po_cmu ON gwis_master.po_cmu_no = po_cmu.pk_id
                        LEFT JOIN po_info AS po_gf ON gwis_master.po_gf_no = po_gf.pk_id
                        LEFT JOIN stakeholder AS manf ON itminfo_tab.manufacturer_id = manf.stkid 
                WHERE
                gwis_master.tran_no = '" . $this->tran_no . "' AND
                gwis_master.temp = 0 
                $createdby
                AND (gwis_detail.is_received is NULL or gwis_detail.is_received = 0) AND gwis_master.status_id IN (" . $this->status_id . ") AND gwis_master.active_process = 1
                GROUP BY
                if(gwis_detail.field1 ='',  gwis_detail.pk_id, gwis_detail.pk_id) ";

		//changing Group by gwis_detail.field1 to gwis_detail.pk_id due to errors


		return $this->query($strSql);
	}

	function GetTransportReqByIssueNo()
	{
		//select query
		//gets
		//qty
		//batch num
		//item name
		//fk stock id
		//pk detail id
		$createdby = '';
		$gwisadj = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		//        if($this->pk_id)
		//        {
		//            $gwisadj = "gwis_master.pk_id = '" . $this->pk_id . "' AND";
		//        }
		//        else{
		//           $gwisadj = "";
		//        }

		$strSql = "SELECT
                IF
                        (
		gwis_detail.field1 IS NULL,
		gwis_detail.pk_id,
                MAX( gwis_detail.pk_id )) AS pk_id,
                gwis_detail.quantity,
                gwis_detail.dc_quantity,
                gwis_detail.pi_quantity,
                gwis_detail.ti_quantity,
                gwis_detail.actual_rec_qty,
                gwis_detail.field1,
                gwis_detail.field2,
                gwis_detail.field3,
                gwis_detail.field4,
                gwis_detail.field5,
                gwis_detail.field6,
                gwis_detail.field7,
                gwis_detail.field8,
                gwis_detail.field9,
                gwis_detail.field10,
                gwis_detail.delivery_challan_type,
                gwis_detail.challan_type_detail,
                gwis_detail.driver_name,
                gwis_detail.driver_contract,
                gwis_detail.vehicle_reg,
                gwis_detail.dc_no,
                gwis_detail.dc_date,
                gwis_detail.invoice,
                stock_batch.batch_no,
                stock_batch.batch_id,
                itminfo_tab.itm_name,
                itminfo_tab.itm_id,
                itminfo_tab.cold_chain_temp,
                itminfo_tab.product_type AS product_type_id,
                gwis_detail.fk_stock_id,
                gwis_master.tran_date,
                gwis_detail.batch_id,
                gwis_master.tran_no,
                gwis_master.tran_ref,
                ww.wh_name AS wh_from,
                wt.wh_name AS wh_to,
                ws.wh_name AS wh_from_supplier,
                stakeholder.ntn,
                stakeholder.gstn,
                stakeholder.contact_person,
                stakeholder.contact_numbers,
                stakeholder.contact_emails,
                stakeholder.contact_address,
                stock_batch.production_date,
                stock_batch.batch_expiry,
                gwis_detail.invoice,
                gwis_detail.dc_date,
                gwis_detail.dc_no,
                gwis_detail.vehicle_reg,
                gwis_detail.driver_contract,
                gwis_detail.driver_name,
                gwis_detail.challan_type_detail,
                gwis_detail.ti_comment,
                gwis_detail.grn_quantity,
                gwis_detail.giv_quantity,
                challan_type.challan_type,
                stock_batch.dtl,
                stock_batch.unit_price,
                stock_batch.dtl_result,
                stock_batch.currency,
                stock_batch.conversion_rate,
                gwis_master.pk_id AS masterpkid,
                gwis_detail.pi_comment,
                gwis_detail.po_quantity,
                gwis_detail.comments,
                gwis_master.wh_id_from,
                gwis_master.wh_id_to,
                gwis_master.wh_id_from_supplier,
                gwis_detail.electronic_approval,
                gwis_detail.siv_no_of_cartons,
                stock_batch.batch_totalprice,
                stock_batch.manufacturer,
                stock_batch.manufacturer_name,
                list_detail.`name` AS product_type 
            FROM
                gwis_master
                INNER JOIN gwis_detail ON gwis_detail.fk_stock_id = gwis_master.pk_id
                INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                INNER JOIN itminfo_tab ON itminfo_tab.itm_id = stock_batch.item_id
                LEFT JOIN tbl_warehouse ON gwis_master.wh_id_from_supplier = tbl_warehouse.wh_id
                LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                LEFT JOIN tbl_warehouse AS wt ON gwis_master.wh_id_to = wt.wh_id
                LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                LEFT JOIN stakeholder ON tbl_warehouse.stkid = stakeholder.stkid
                LEFT JOIN challan_type ON gwis_detail.delivery_challan_type = challan_type.pk_id 
                LEFT JOIN list_detail ON itminfo_tab.product_type = list_detail.pk_id 
                WHERE
                gwis_master.tran_no = '" . $this->tran_no . "' AND
                gwis_master.temp = 0 
                $createdby
                AND (gwis_detail.is_received is NULL or gwis_detail.is_received = 0) AND gwis_master.status_id IN (" . $this->status_id . ") AND gwis_master.active_process = 1
                GROUP BY
                if(gwis_detail.field1 ='',  gwis_detail.pk_id, gwis_detail.pk_id)  ";
		//        echo $strSql;exit;
		//query result
		//        $rsSql = mysql_query($strSql) or die("Error GetWHStockByIssueNo");
		//        if (mysql_num_rows($rsSql) > 0) {
		//            return $rsSql;
		//        } else {
		//            return FALSE;
		//        }
		return $this->query($strSql);
	}

	function GetTacWHStockByIssueNo($dtlchk)
	{
		//select query
		//gets
		//qty
		//batch num
		//item name
		//fk stock id
		//pk detail id
		$createdby = '';
		$gwisadj = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		//        if($this->pk_id)
		//        {
		//            $gwisadj = "gwis_master.pk_id = '" . $this->pk_id . "' AND";
		//        }
		//        else{
		//           $gwisadj = "";
		//        }

		$strSql = "SELECT
                    if(gwis_detail.field1 IS NULL,  gwis_detail.pk_id,MAX( gwis_detail.pk_id )) AS pk_id,
                    gwis_detail.quantity,
                    gwis_detail.dc_quantity,
                    gwis_detail.pi_quantity,
                    gwis_detail.ti_quantity,
                    gwis_detail.actual_rec_qty,
                    gwis_detail.field1,
                    gwis_detail.field2,
                    gwis_detail.field3,
                    gwis_detail.field4,
                    gwis_detail.field5,
                    gwis_detail.field6,
                    gwis_detail.field7,
                    gwis_detail.field8,
                    gwis_detail.field9,
                    gwis_detail.field10,
                    gwis_detail.delivery_challan_type,
                    gwis_detail.challan_type_detail,
                    gwis_detail.driver_name,
                    gwis_detail.driver_contract,
                    gwis_detail.vehicle_reg,
                    gwis_detail.dc_no,
                    gwis_detail.dc_date,
                    gwis_detail.invoice,
                    stock_batch.batch_no,
                    stock_batch.batch_id,
                    itminfo_tab.itm_name,
                    itminfo_tab.itm_id,
                    itminfo_tab.product_type,
                    gwis_detail.fk_stock_id,
                    gwis_master.tran_date,
                    gwis_detail.batch_id,
                    gwis_master.tran_no,
                    gwis_master.tran_ref,
                    gwis_master.file,
                    ww.wh_name AS wh_from,
                    ws.wh_name AS wh_from_supplier,
                    stakeholder.ntn,
                    stakeholder.gstn,
                    stakeholder.contact_person,
                    stakeholder.contact_numbers,
                    stakeholder.contact_emails,
                    stakeholder.contact_address,
                    stock_batch.production_date,
                    stock_batch.batch_expiry,
                    gwis_detail.siv_no_of_cartons,
                    gwis_detail.invoice,
                    gwis_detail.dc_date,
                    gwis_detail.dc_no,
                    gwis_detail.vehicle_reg,
                    gwis_detail.driver_contract,
                    gwis_detail.driver_name,
                    gwis_detail.challan_type_detail,
                    gwis_detail.ti_comment,
                    gwis_detail.grn_quantity,
                    gwis_detail.giv_quantity,
                    challan_type.challan_type,
                    stock_batch.dtl,
                    stock_batch.unit_price,
                    stock_batch.dtl_result,
                    stock_batch.currency,
                    stock_batch.conversion_rate,
                    gwis_master.pk_id AS masterpkid,
                    gwis_detail.pi_comment,
                    gwis_detail.po_quantity,
                    gwis_detail.comments,
                    gwis_master.wh_id_from,
                    gwis_master.wh_id_to,
                    gwis_master.wh_id_from_supplier,
                    gwis_master.stk_id,
                    gwis_master.inspection_date,
                    gwis_master.delivery_location,
                    gwis_master.po_cmu_no AS po_cmu_no_id,
                    gwis_master.po_cmu_date,
                    gwis_master.po_gf_no AS po_gf_no_id,
                    gwis_master.po_gf_date,
                    gwis_master.date_of_receiving,
                    gwis_master.air_bill_no,
                    gwis_master.shipment_no,
                    gwis_master.origin_of_country,
                    gwis_master.vehicle_type_and_plate,
                    gwis_master.consignment_weight,
                    gwis_detail.electronic_approval,
                    gwis_detail.pi_type,
                    gwis_detail.sbtr_dc_rec,
                    gwis_detail.shipment_temprature,
                    stock_batch.batch_totalprice,
                    stock_batch.manufacturer,
                    stock_batch.manufacturer_name,
                    po_gf.number AS po_gf_no,
                    po_cmu.number AS po_cmu_no 
                FROM
                        gwis_master
                INNER JOIN gwis_detail ON gwis_detail.fk_stock_id = gwis_master.pk_id
                INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                INNER JOIN itminfo_tab ON itminfo_tab.itm_id = stock_batch.item_id
                LEFT JOIN tbl_warehouse ON gwis_master.wh_id_from_supplier = tbl_warehouse.wh_id
                LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                LEFT JOIN stakeholder ON tbl_warehouse.stkid = stakeholder.stkid
                LEFT JOIN challan_type ON gwis_detail.delivery_challan_type = challan_type.pk_id
                LEFT JOIN po_info AS po_cmu ON gwis_master.po_cmu_no = po_cmu.pk_id
                LEFT JOIN po_info AS po_gf ON gwis_master.po_gf_no = po_gf.pk_id 
                WHERE
                gwis_master.tran_no = '" . $this->tran_no . "' AND
                gwis_master.temp = 0 
                $dtlchk
                $createdby
                AND (gwis_detail.is_received is NULL or gwis_detail.is_received = 0) AND gwis_master.status_id IN (" . $this->status_id . ") AND gwis_master.active_process = 1
                GROUP BY
                if(gwis_detail.field1 ='',  gwis_detail.pk_id, gwis_detail.pk_id) ";
		//        echo $strSql;exit;
		//query result
		//        $rsSql = mysql_query($strSql) or die("Error GetWHStockByIssueNo");
		//        if (mysql_num_rows($rsSql) > 0) {
		//            return $rsSql;
		//        } else {
		//            return FALSE;
		//        }
		return $this->query($strSql);
	}

	function GetAllStockReceiveByIssueNo($dtlchk)
	{
		//select query
		//gets
		//qty
		//batch num
		//item name
		//fk stock id
		//pk detail id
		$createdby = '';
		$gwisadj = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		//        if($this->pk_id)
		//        {
		//            $gwisadj = "gwis_master.pk_id = '" . $this->pk_id . "' AND";
		//        }
		//        else{
		//           $gwisadj = "";
		//        }

		$strSql = "SELECT
                    if(gwis_detail.field1 IS NULL,  gwis_detail.pk_id,MAX( gwis_detail.pk_id )) AS pk_id,
                    gwis_detail.quantity,
                    gwis_detail.dc_quantity,
                    gwis_detail.pi_quantity,
                    gwis_detail.ti_quantity,
                    gwis_detail.actual_rec_qty,
                    gwis_detail.field1,
                    gwis_detail.field2,
                    gwis_detail.field3,
                    gwis_detail.field4,
                    gwis_detail.field5,
                    gwis_detail.field6,
                    gwis_detail.field7,
                    gwis_detail.field8,
                    gwis_detail.field9,
                    gwis_detail.field10,
                    gwis_detail.delivery_challan_type,
                    gwis_detail.challan_type_detail,
                    gwis_detail.driver_name,
                    gwis_detail.driver_contract,
                    gwis_detail.vehicle_reg,
                    gwis_detail.dc_no,
                    gwis_detail.dc_date,
                    gwis_detail.invoice,
                    gwis_detail.shipment_temprature,
                    stock_batch.batch_no,
                    stock_batch.batch_id,
                    itminfo_tab.itm_name,
                    itminfo_tab.itm_id,
                    itminfo_tab.product_type,
                    gwis_detail.fk_stock_id,
                    gwis_master.tran_date,
                    gwis_detail.batch_id,
                    gwis_master.tran_no,
                    gwis_master.tran_ref,
                    ww.wh_name AS wh_from,
                    ws.wh_name AS wh_from_supplier,
                    stakeholder.ntn,
                    stakeholder.gstn,
                    stakeholder.contact_person,
                    stakeholder.contact_numbers,
                    stakeholder.contact_emails,
                    stakeholder.contact_address,
                    stock_batch.production_date,
                    stock_batch.batch_expiry,
                    gwis_detail.siv_no_of_cartons,
                    gwis_detail.invoice,
                    gwis_detail.dc_date,
                    gwis_detail.dc_no,
                    gwis_detail.vehicle_reg,
                    gwis_detail.driver_contract,
                    gwis_detail.driver_name,
                    gwis_detail.challan_type_detail,
                    gwis_detail.ti_comment,
                    gwis_detail.grn_quantity,
                    gwis_detail.giv_quantity,
                    challan_type.challan_type,
                    stock_batch.dtl,
                    stock_batch.unit_price,
                    stock_batch.dtl_result,
                    stock_batch.currency,
                    stock_batch.conversion_rate,
                    gwis_master.pk_id AS masterpkid,
                    gwis_detail.pi_comment,
                    gwis_detail.po_quantity,
                    gwis_detail.comments,
                    gwis_master.wh_id_from,
                    gwis_master.wh_id_to,
                    gwis_master.wh_id_from_supplier,
                    gwis_master.stk_id,
                    gwis_master.inspection_date,
                    gwis_master.delivery_location,
                    gwis_master.po_cmu_no AS po_cmu_no_id,
                    gwis_master.po_cmu_date,
                    gwis_master.po_gf_no AS po_gf_no_id,
                    gwis_master.po_gf_date,
                    gwis_master.date_of_receiving,
                    gwis_master.air_bill_no,
                    gwis_master.shipment_no,
                    gwis_master.origin_of_country,
                    gwis_master.vehicle_type_and_plate,
                    gwis_master.consignment_weight,
                    gwis_master.file,
                    gwis_detail.electronic_approval,
                    gwis_detail.pi_type,
                    gwis_detail.sbtr_dc_rec,
                    gwis_detail.wh_location,
                    stock_batch.batch_totalprice,
                    stock_batch.manufacturer,
                    stock_batch.manufacturer_name,
                    po_gf.number AS po_gf_no,
                    po_cmu.number AS po_cmu_no 
                FROM
                        gwis_master
                INNER JOIN gwis_detail ON gwis_detail.fk_stock_id = gwis_master.pk_id
                INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                INNER JOIN itminfo_tab ON itminfo_tab.itm_id = stock_batch.item_id
                LEFT JOIN tbl_warehouse ON gwis_master.wh_id_from_supplier = tbl_warehouse.wh_id
                LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                LEFT JOIN stakeholder ON tbl_warehouse.stkid = stakeholder.stkid
                LEFT JOIN challan_type ON gwis_detail.delivery_challan_type = challan_type.pk_id
                LEFT JOIN po_info AS po_cmu ON gwis_master.po_cmu_no = po_cmu.pk_id
                LEFT JOIN po_info AS po_gf ON gwis_master.po_gf_no = po_gf.pk_id
                WHERE
                gwis_master.tran_no = '" . $this->tran_no . "' AND
                gwis_master.temp = 0 
                $dtlchk
                $createdby
                AND (gwis_detail.is_received is NULL or gwis_detail.is_received = 0) AND gwis_master.status_id IN (" . $this->status_id . ") AND gwis_master.active_process = 1
                GROUP BY
                if(gwis_detail.field1 ='',  gwis_detail.pk_id, gwis_detail.pk_id) ";
		//        echo $strSql;exit;
		//query result
		//        $rsSql = mysql_query($strSql) or die("Error GetWHStockByIssueNo");
		//        if (mysql_num_rows($rsSql) > 0) {
		//            return $rsSql;
		//        } else {
		//            return FALSE;
		//        }
		return $this->query($strSql);
	}

	function GetDTLWHStockByIssueNo()
	{
		//select query
		//gets
		//qty
		//batch num
		//item name
		//fk stock id
		//pk detail id
		$createdby = '';
		$gwisadj = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		//        if($this->pk_id)
		//        {
		//            $gwisadj = "gwis_master.pk_id = '" . $this->pk_id . "' AND";
		//        }
		//        else{
		//           $gwisadj = "";
		//        }

		$strSql = "SELECT
                    gwis_detail.quantity, 
                    gwis_detail.dc_quantity, 
                    gwis_detail.pi_quantity, 
                    gwis_detail.ti_quantity, 
                    gwis_detail.actual_rec_qty, 
                    gwis_detail.field1, 
                    gwis_detail.field2, 
                    gwis_detail.field3, 
                    gwis_detail.field4, 
                    gwis_detail.field5, 
                    gwis_detail.field6, 
                    gwis_detail.field7, 
                    gwis_detail.field8, 
                    gwis_detail.field9, 
                    gwis_detail.field10, 
                    gwis_detail.delivery_challan_type, 
                    gwis_detail.challan_type_detail, 
                    gwis_detail.driver_name, 
                    gwis_detail.driver_contract, 
                    gwis_detail.vehicle_reg, 
                    gwis_detail.dc_no, 
                    gwis_detail.dc_date, 
                    gwis_detail.invoice, 
                    stock_batch.batch_no, 
                    stock_batch.batch_id, 
                    itminfo_tab.itm_name, 
                    itminfo_tab.itm_id, 
                    itminfo_tab.product_type, 
                    gwis_detail.fk_stock_id, 
                    gwis_detail.pk_id, 
                    gwis_master.tran_date, 
                    gwis_detail.batch_id, 
                    gwis_master.tran_no, 
                    gwis_master.tran_ref, 
                    ww.wh_name AS wh_from, 
                    ws.wh_name AS wh_from_supplier, 
                    stakeholder.ntn, 
                    stakeholder.gstn, 
                    stakeholder.contact_person, 
                    stakeholder.contact_numbers, 
                    stakeholder.contact_emails, 
                    stakeholder.contact_address, 
                    stock_batch.production_date, 
                    stock_batch.batch_expiry, 
                    gwis_detail.invoice, 
                    gwis_detail.dc_date, 
                    gwis_detail.dc_no, 
                    gwis_detail.vehicle_reg, 
                    gwis_detail.driver_contract, 
                    gwis_detail.driver_name, 
                    gwis_detail.challan_type_detail, 
                    gwis_detail.ti_comment, 
                    gwis_detail.grn_quantity, 
                    gwis_detail.giv_quantity, 
                    challan_type.challan_type, 
                    stock_batch.dtl, 
                    stock_batch.unit_price, 
                    stock_batch.dtl_result, 
                    stock_batch.currency, 
                    stock_batch.conversion_rate, 
                    gwis_master.pk_id AS masterpkid, 
                    gwis_detail.pi_comment, 
                    gwis_detail.po_quantity, 
                    gwis_detail.comments,
                    gwis_master.wh_id_from, 
                    gwis_master.wh_id_from_supplier,
                    stock_batch.batch_totalprice,
                    stock_batch.manufacturer,
                    stock_batch.manufacturer_name
                FROM
                        gwis_master
                INNER JOIN gwis_detail ON gwis_detail.fk_stock_id = gwis_master.pk_id
                INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                INNER JOIN itminfo_tab ON itminfo_tab.itm_id = stock_batch.item_id
                LEFT JOIN tbl_warehouse ON gwis_master.wh_id_from_supplier = tbl_warehouse.wh_id
                LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                LEFT JOIN stakeholder ON tbl_warehouse.stkid = stakeholder.stkid
                LEFT JOIN challan_type ON gwis_detail.delivery_challan_type = challan_type.pk_id
                WHERE
                gwis_master.tran_no = '" . $this->tran_no . "' AND
                gwis_master.temp = 0 
                AND stock_batch.dtl = 2 
                AND stock_batch.dtl_status = 'inprocess'
                $createdby
                AND (gwis_detail.is_received is NULL or gwis_detail.is_received = 0) AND gwis_master.status_id = '" . $this->status_id . "' AND gwis_master.active_process = 1
                 ";
		//        echo $strSql;exit;
		//query result
		//        $rsSql = mysql_query($strSql) or die("Error GetWHStockByIssueNo");
		//        if (mysql_num_rows($rsSql) > 0) {
		//            return $rsSql;
		//        } else {
		//            return FALSE;
		//        }
		return $this->query($strSql);
	}

	function GetWHStockByRejIssueNo()
	{
		//select query
		//gets
		//qty
		//batch num
		//item name
		//fk stock id
		//pk detail id
		$createdby = '';
		$gwisadj = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		//        if($this->pk_id)
		//        {
		//            $gwisadj = "gwis_master.pk_id = '" . $this->pk_id . "' AND";
		//        }
		//        else{
		//           $gwisadj = "";
		//        }

		$strSql = "SELECT
                    IF
                            (
                                    gwis_detail.field1 IS NULL,
                                    gwis_detail.pk_id,
                            MAX( gwis_detail.pk_id )) AS pk_id,
                            gwis_detail.quantity,
                            gwis_detail.dc_quantity,
                            gwis_detail.pi_quantity,
                            gwis_detail.ti_quantity,
                            gwis_detail.actual_rec_qty,
                            gwis_detail.field1,
                            gwis_detail.field2,
                            gwis_detail.field3,
                            gwis_detail.field4,
                            gwis_detail.field5,
                            gwis_detail.field6,
                            gwis_detail.field7,
                            gwis_detail.field8,
                            gwis_detail.field9,
                            gwis_detail.field10,
                            gwis_detail.delivery_challan_type,
                            gwis_detail.challan_type_detail,
                            gwis_detail.driver_name,
                            gwis_detail.driver_contract,
                            gwis_detail.vehicle_reg,
                            gwis_detail.dc_no,
                            gwis_detail.dc_date,
                            gwis_detail.invoice,
                            stock_batch.batch_no,
                            stock_batch.batch_id,
                            itminfo_tab.itm_name,
                            itminfo_tab.itm_id,
                            itminfo_tab.product_type,
                            gwis_detail.fk_stock_id,
                            gwis_master.tran_date,
                            gwis_detail.batch_id,
                            gwis_master.tran_no,
                            gwis_master.tran_ref,
                            gwis_master.province_id,
                            ww.wh_name AS wh_from,
                            ws.wh_name AS wh_from_supplier,
                            stakeholder.ntn,
                            stakeholder.gstn,
                            stakeholder.contact_person,
                            stakeholder.contact_numbers,
                            stakeholder.contact_emails,
                            stakeholder.contact_address,
                            stock_batch.production_date,
                            stock_batch.batch_expiry,
                            gwis_detail.siv_no_of_cartons,
                            gwis_detail.invoice,
                            gwis_detail.dc_date,
                            gwis_detail.dc_no,
                            gwis_detail.vehicle_reg,
                            gwis_detail.driver_contract,
                            gwis_detail.driver_name,
                            gwis_detail.challan_type_detail,
                            gwis_detail.ti_comment,
                            gwis_detail.grn_quantity,
                            gwis_detail.giv_quantity,
                            challan_type.challan_type,
                            stock_batch.dtl,
                            stock_batch.unit_price,
                            stock_batch.dtl_result,
                            stock_batch.currency,
                            stock_batch.conversion_rate,
                            gwis_master.pk_id AS masterpkid,
                            gwis_detail.pi_comment,
                            gwis_detail.po_quantity,
                            gwis_detail.comments,
                            gwis_detail.shipment_temprature,
                            gwis_master.wh_id_from,
                            gwis_master.wh_id_to,
                            gwis_master.wh_id_from_supplier,
                            gwis_master.stk_id,
                            gwis_master.inspection_date,
                            gwis_master.delivery_location,
                            gwis_master.po_cmu_no AS po_cmu_no_id,
                            gwis_master.po_cmu_date,
                            gwis_master.po_gf_no AS po_gf_no_id,
                            gwis_master.po_gf_date,
                            gwis_master.date_of_receiving,
                            gwis_master.air_bill_no,
                            gwis_master.shipment_no,
                            gwis_master.origin_of_country,
                            gwis_master.vehicle_type_and_plate,
                            gwis_master.consignment_weight,
                            gwis_master.file,
                            gwis_master.source_type,
                            gwis_detail.electronic_approval,
                            gwis_detail.pi_type,
                            gwis_detail.sbtr_dc_rec,
                            gwis_detail.wh_location,
                            gwis_detail.storage,
                            stock_batch.batch_totalprice,
                            stock_batch.manufacturer,
                            po_gf.number AS po_gf_no,
                            po_cmu.number AS po_cmu_no,
                            manf.stkname AS manufacturer_name
                    FROM
                            gwis_master
                            INNER JOIN gwis_detail ON gwis_detail.fk_stock_id = gwis_master.pk_id
                            INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                            INNER JOIN itminfo_tab ON itminfo_tab.itm_id = stock_batch.item_id
                            LEFT JOIN tbl_warehouse ON gwis_master.wh_id_from_supplier = tbl_warehouse.wh_id
                            LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                            LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                            LEFT JOIN stakeholder ON tbl_warehouse.stkid = stakeholder.stkid
                            LEFT JOIN challan_type ON gwis_detail.delivery_challan_type = challan_type.pk_id
                            LEFT JOIN po_info AS po_cmu ON gwis_master.po_cmu_no = po_cmu.pk_id
                            LEFT JOIN po_info AS po_gf ON gwis_master.po_gf_no = po_gf.pk_id
                            LEFT JOIN stakeholder AS manf ON itminfo_tab.manufacturer_id = manf.stkid 
                WHERE
                gwis_master.tran_no = '" . $this->tran_no . "' AND
                gwis_master.temp = 0 
                AND gwis_detail.electronic_approval = 2
                $createdby
                AND (gwis_detail.is_received is NULL or gwis_detail.is_received = 0) AND gwis_master.status_id = '" . $this->status_id . "' 
                GROUP BY
                if(gwis_detail.field1 ='',  gwis_detail.pk_id, gwis_detail.pk_id) ";
		//        echo $strSql;exit;
		//query result
		//        $rsSql = mysql_query($strSql) or die("Error GetWHStockByIssueNo");
		//        if (mysql_num_rows($rsSql) > 0) {
		//            return $rsSql;
		//        } else {
		//            return FALSE;
		//        }
		return $this->query($strSql);
	}

	function GetWHStockByDtlIssueNo()
	{
		//select query
		//gets
		//qty
		//batch num
		//item name
		//fk stock id
		//pk detail id
		$createdby = '';
		$gwisadj = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		//        if($this->pk_id)
		//        {
		//            $gwisadj = "gwis_master.pk_id = '" . $this->pk_id . "' AND";
		//        }
		//        else{
		//           $gwisadj = "";
		//        }

		$strSql = "SELECT
                    gwis_detail.quantity, 
                    gwis_detail.dc_quantity, 
                    gwis_detail.pi_quantity, 
                    gwis_detail.ti_quantity, 
                    gwis_detail.actual_rec_qty, 
                    gwis_detail.field1, 
                    gwis_detail.field2, 
                    gwis_detail.field3, 
                    gwis_detail.field4, 
                    gwis_detail.field5, 
                    gwis_detail.field6, 
                    gwis_detail.field7, 
                    gwis_detail.field8, 
                    gwis_detail.field9, 
                    gwis_detail.field10, 
                    gwis_detail.delivery_challan_type, 
                    gwis_detail.challan_type_detail, 
                    gwis_detail.driver_name, 
                    gwis_detail.driver_contract, 
                    gwis_detail.vehicle_reg, 
                    gwis_detail.dc_no, 
                    gwis_detail.dc_date, 
                    gwis_detail.invoice, 
                    stock_batch.batch_no, 
                    stock_batch.batch_id, 
                    itminfo_tab.itm_name, 
                    itminfo_tab.itm_id, 
                    itminfo_tab.product_type, 
                    gwis_detail.fk_stock_id, 
                    gwis_detail.pk_id, 
                    gwis_master.tran_date, 
                    gwis_detail.batch_id, 
                    gwis_master.tran_no, 
                    gwis_master.file,
                    gwis_master.tran_ref, 
                    ww.wh_name AS wh_from, 
                    ws.wh_name AS wh_from_supplier, 
                    stakeholder.ntn, 
                    stakeholder.gstn, 
                    stakeholder.contact_person, 
                    stakeholder.contact_numbers, 
                    stakeholder.contact_emails, 
                    stakeholder.contact_address, 
                    stock_batch.production_date, 
                    stock_batch.batch_expiry, 
                    gwis_detail.invoice, 
                    gwis_detail.dc_date, 
                    gwis_detail.dc_no, 
                    gwis_detail.vehicle_reg, 
                    gwis_detail.driver_contract, 
                    gwis_detail.driver_name, 
                    gwis_detail.challan_type_detail, 
                    gwis_detail.ti_comment, 
                    gwis_detail.grn_quantity, 
                    gwis_detail.giv_quantity, 
                    challan_type.challan_type, 
                    stock_batch.dtl, 
                    stock_batch.unit_price, 
                    stock_batch.dtl_result, 
                    stock_batch.currency, 
                    stock_batch.conversion_rate, 
                    gwis_master.pk_id AS masterpkid, 
                    gwis_detail.pi_comment, 
                    gwis_detail.po_quantity, 
                    gwis_detail.comments,
                    gwis_detail.shipment_temprature,
                    gwis_master.wh_id_from, 
                    gwis_master.wh_id_from_supplier,
                    stock_batch.batch_totalprice,
                    stock_batch.manufacturer,
                    stock_batch.manufacturer_name,
                    gwis_master.inspection_date,
                    gwis_master.delivery_location,
                    gwis_master.po_cmu_date,
                    gwis_master.date_of_receiving,
                    gwis_master.air_bill_no,
                    gwis_master.shipment_no,
                    gwis_master.origin_of_country,
                    gwis_master.vehicle_type_and_plate,
                    gwis_master.consignment_weight,
                    po_gf.number AS po_gf_no,
                    po_cmu.number AS po_cmu_no,
                    gwis_master.po_gf_date,
                    gwis_master.stk_id,
                    gwis_master.po_cmu_no AS po_cmu_no_id,
                    gwis_master.po_gf_no AS po_gf_no_id,
                    gwis_detail.pi_type,
                    gwis_detail.sbtr_dc_rec
                FROM
                        gwis_master
                INNER JOIN gwis_detail ON gwis_detail.fk_stock_id = gwis_master.pk_id
                INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                INNER JOIN itminfo_tab ON itminfo_tab.itm_id = stock_batch.item_id
                LEFT JOIN tbl_warehouse ON gwis_master.wh_id_from_supplier = tbl_warehouse.wh_id
                LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                LEFT JOIN stakeholder ON tbl_warehouse.stkid = stakeholder.stkid
                LEFT JOIN challan_type ON gwis_detail.delivery_challan_type = challan_type.pk_id
                LEFT JOIN po_info AS po_cmu ON gwis_master.po_cmu_no = po_cmu.pk_id
                LEFT JOIN po_info AS po_gf ON gwis_master.po_gf_no = po_gf.pk_id 
                WHERE
                gwis_master.tran_no = '" . $this->tran_no . "' AND
                gwis_master.temp = 0 
                AND dtl_result IN (3,4)
                $createdby
                AND (gwis_detail.is_received is NULL or gwis_detail.is_received = 0) AND gwis_master.status_id = '" . $this->status_id . "' 
                 ";
		//        echo $strSql;exit;
		//query result
		//        $rsSql = mysql_query($strSql) or die("Error GetWHStockByIssueNo");
		//        if (mysql_num_rows($rsSql) > 0) {
		//            return $rsSql;
		//        } else {
		//            return FALSE;
		//        }
		return $this->query($strSql);
	}

	function GetBatchWHStockByIssueNo($pkdetailid)
	{
		//select query
		//gets
		//qty
		//batch num
		//item name
		//fk stock id
		//pk detail id
		$createdby = '';

		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		$strSql = "SELECT
                A.*,
                B.* 
        FROM
                (
                SELECT
                        gwis_detail.quantity,
                        gwis_detail.dc_quantity,
                        gwis_detail.pi_quantity,
                        gwis_detail.ti_quantity,
                        gwis_detail.actual_rec_qty,
                        stock_batch.batch_no,
                        itminfo_tab.itm_name,
                        itminfo_tab.itm_id,
                        gwis_detail.fk_stock_id,
                        gwis_detail.pk_id,
                        gwis_master.tran_date,
                        gwis_master.province_id,
                        gwis_master.source_type,
                        gwis_detail.batch_id,
                        gwis_master.tran_no,
                        gwis_master.tran_ref,
                        gwis_master.file,
                        ww.wh_name AS wh_from,
                        ws.wh_name AS wh_from_supplier,
                        stakeholder.ntn,
                        stakeholder.gstn,
                        stakeholder.contact_person,
                        stakeholder.contact_numbers,
                        stakeholder.contact_emails,
                        stakeholder.contact_address,
                        stock_batch.production_date,
                        stock_batch.batch_expiry,
                        gwis_detail.invoice,
                        gwis_detail.dc_date,
                        gwis_detail.dc_no,
                        gwis_detail.vehicle_reg,
                        gwis_detail.driver_contract,
                        gwis_detail.driver_name,
                        gwis_detail.challan_type_detail,
                        gwis_detail.ti_comment,
                        gwis_detail.storage,
                        gwis_detail.shipment_temprature,
                        challan_type.challan_type,
                        stock_batch.unit_price,
                        stock_batch.currency,
                        stock_batch.conversion_rate,
                        stock_batch.manufacturer,
                        stock_batch.manufacturer_name
                FROM
                        gwis_master
                        INNER JOIN gwis_detail ON gwis_detail.fk_stock_id = gwis_master.pk_id
                        INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                        INNER JOIN itminfo_tab ON itminfo_tab.itm_id = stock_batch.item_id
                        LEFT JOIN tbl_warehouse ON gwis_master.wh_id_from_supplier = tbl_warehouse.wh_id
                        LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                        LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                        LEFT JOIN stakeholder ON tbl_warehouse.stkid = stakeholder.stkid
                        LEFT JOIN challan_type ON gwis_detail.delivery_challan_type = challan_type.pk_id 
                WHERE
                        gwis_master.tran_no = '" . $this->tran_no . "' AND
                        
                        gwis_master.temp = 0 
                        $createdby
                        AND gwis_master.wh_id_to = " . $this->wh_id_to . " AND
                        (gwis_detail.is_received is NULL or gwis_detail.is_received = 0) AND gwis_master.status_id = '" . $this->status_id . "' 
                ) A
                LEFT JOIN (
                SELECT
                        tbl_stock_detail.PkDetailID,
                        tbl_stock_detail.BatchID,
                        tbl_stock_detail.fkStockID,
                        tbl_stock_detail.Qty,
                        tbl_stock_detail.comments,
                        tbl_stock_master.TranRef,
                        tbl_stock_master.source_type,
                        stock_batch.dtl,
                        stock_batch.dtl_result,
                        tbl_stock_master.ReceivedRemarks
                FROM
                        tbl_stock_detail
                        INNER JOIN tbl_stock_master ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
                        INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id 
                WHERE
                tbl_stock_detail.PkDetailID = '$pkdetailid'
                ) B ON A.tran_no = B.TranRef
        ";
		//        echo $strSql;exit;
		//query result
		//        $rsSql = mysql_query($strSql) or die("Error GetWHStockByIssueNo");
		//        if (mysql_num_rows($rsSql) > 0) {
		//            return $rsSql;
		//        } else {
		//            return FALSE;
		//        }
		return $this->query($strSql);
	}
	/**
	 * 
	 * getWhLevelByStockID
	 * @param type $stock_id
	 * @return boolean
	 * 
	 * 
	 */
	function getWhLevelByStockID($stock_id)
	{
		//select query
		//gets
		//to warehose id
		//level
		//
		$strSql = "SELECT
                            tbl_stock_master.WHIDTo,
                            stakeholder.lvl,
                            tbl_warehouse.is_allowed_im,
                            tbl_warehouse.im_start_month
			FROM
                            tbl_stock_master
			INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDTo = tbl_warehouse.wh_id
			INNER JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid
			WHERE
                            tbl_stock_master.PkStockID = $stock_id";
		//query result
		$rsSql = mysql_query($strSql) or die("Error getWhLevelByStockID");
		if (mysql_num_rows($rsSql) > 0) {
			$row = mysql_fetch_object($rsSql);
			return array(
				'uc_wh_id' => $row->WHIDTo,
				'level' => $row->lvl,
				'im_enabled' => $row->is_allowed_im
			);
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * getDateAndItemfromStock
	 * @param type $stock_id
	 * @return boolean
	 * 
	 * 
	 */
	function getDateAndItemfromStock($stock_id)
	{
		//select query
		//gets
		//transaction date
		//qty
		//item rec id
		//item id
		//
		$strSql = "SELECT
				tbl_stock_master.TranDate,
				tbl_stock_detail.Qty AS Qty,
				itminfo_tab.itmrec_id as itemrec_id,
				itminfo_tab.itm_id as item_id
				FROM
				tbl_stock_master
				INNER JOIN tbl_stock_detail ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
				INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
				INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
				WHERE
				tbl_stock_master.PkStockID = $stock_id AND tbl_stock_detail.IsReceived = 1
         ";
		//query result
		$rsSql = mysql_query($strSql) or die("Error getDateAndItemfromStock");
		if (mysql_num_rows($rsSql) > 0) {
			while ($row = mysql_fetch_object($rsSql)) {
				$array[] = array(
					'date' => $row->TranDate,
					'item_id' => $row->item_id,
					'itemrec_id' => $row->itemrec_id,
					'qty' => $row->Qty
				);
			}
			return $array;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * getItemDetailfromStock
	 * @param type $stock_id
	 * @return boolean
	 * 
	 * 
	 */
	function getItemDetailfromStock($stock_id)
	{
		//select query
		//gets
		//transaction date
		//qty
		//item rec id
		//item id
		$strSql = "SELECT
					tbl_stock_master.TranDate,
					tbl_stock_detail.Qty AS Qty,
					itminfo_tab.itmrec_id as itemrec_id,
					itminfo_tab.itm_id as item_id
					FROM
					tbl_stock_master
					INNER JOIN tbl_stock_detail ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
					INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
					INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
					WHERE	tbl_stock_master.PkStockID =  $stock_id";
		//query deatil
		$rsSql = mysql_query($strSql) or die("Error getItemDetailfromStock");
		if (mysql_num_rows($rsSql) > 0) {
			while ($row = mysql_fetch_object($rsSql)) {
				$array[] = array(
					'date' => $row->TranDate,
					'item_id' => $row->item_id,
					'itemrec_id' => $row->itemrec_id,
					'qty' => $row->Qty
				);
			}
			return $array;
		} else {
			return FALSE;
		}
	}

	/**
	 * 
	 * updateMasterIssueDate
	 * @param type $stock_id
	 * @return boolean
	 * 
	 * 
	 */
	function updateMasterIssueDate($stock_id)
	{
		//update query
		$strSql = "UPDATE
						tbl_stock_master 
					SET
						tbl_stock_master.TranDate = '" . $this->TranDate . "',
						tbl_stock_master.issued_by = '" . $this->issued_by . "',
						tbl_stock_master.TranRef = '" . $this->TranRef . "',
						tbl_stock_master.ReceivedRemarks = '" . $this->ReceivedRemarks . "'
					WHERE
						tbl_stock_master.PkStockID = '" . $stock_id . "' ";
		mysql_query($strSql);
		return true;
	}

	public function getPendingVouchers($dist_id)
	{
		//update query
		$strSql = "SELECT DISTINCT
	tbl_stock_master.TranNo,
	tbl_stock_master.PkStockID
FROM
	tbl_stock_master
INNER JOIN tbl_stock_detail ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
WHERE
tbl_stock_master.WHIDTo = $dist_id AND
tbl_stock_master.TranTypeID = 2 AND
tbl_stock_detail.IsReceived = 0";
		$rsSql = mysql_query($strSql) or die("Error getPendingVouchers");
		if (mysql_num_rows($rsSql) > 0) {
			$data = "";
			while ($row = mysql_fetch_assoc($rsSql)) {
				if ($_SERVER['REMOTE_ADDR'] == '::1' || $_SERVER['REMOTE_ADDR'] == '127.0.0.1' || $_SERVER['REMOTE_ADDR'] == 'localhost')
					$data .= "<a style='color:red' href='/clmis/application/im/new_receive_wh.php?issue_no=" . $row['TranNo'] . "&search=true'>" . $row['TranNo'] . "</a>, ";
				else
					$data .= "<a style='color:red' href='/clmisapp/application/im/new_receive_wh.php?issue_no=" . $row['TranNo'] . "&search=true'>" . $row['TranNo'] . "</a>, ";
			}
			return $data;
		} else {
			return '';
		}
	}

	public function auto_rcv_is_pending($stock_id)
	{
		$strSql = " SELECT
                            distinct tbl_stock_master.PkStockID,
                            tbl_stock_master.TranNo,
                            tbl_stock_master.TranRef, 
                            tbl_stock_master.WHIDFrom,
                            tbl_stock_master.WHIDTo,
                            tbl_stock_master.TranTypeID,
                            tbl_warehouse.wh_name as wh_from,
                            t.wh_name as wh_to,
                            tbl_stock_master.TranDate,
                            (SELECT
                                group_concat(sd.PkDetailID)
                                FROM
                                tbl_stock_master AS sm
                                INNER JOIN tbl_stock_detail AS sd ON sm.PkStockID = sd.fkStockID
                                INNER JOIN stock_batch AS sb ON sd.BatchID = sb.batch_id
                                WHERE
                                sm.TranTypeID = 1 AND
                                sm.WHIDFrom = tbl_stock_master.WHIDFrom AND
                                sm.WHIDTo = tbl_stock_master.WHIDTo AND
                                sb.item_id = stock_batch.item_id
                                and sm.TranRef = tbl_stock_master.TranNo AND
                                sb.batch_no = stock_batch.batch_no AND
                                IFNULL(sb.manufacturer, 0) =  IFNULL(stock_batch.manufacturer, 0)) AS rcv_detail_id
                    FROM
                            tbl_stock_master
                            INNER JOIN tbl_stock_detail ON tbl_stock_master.PkStockID = tbl_stock_detail.fkStockID
                            INNER JOIN stock_batch ON tbl_stock_detail.BatchID = stock_batch.batch_id
                            INNER JOIN tbl_warehouse ON tbl_stock_master.WHIDFrom = tbl_warehouse.wh_id
                            INNER JOIN tbl_warehouse t ON tbl_stock_master.WHIDTo = t.wh_id
                            INNER JOIN stakeholder ON t.stkofficeid = stakeholder.stkid
                    WHERE

                    tbl_stock_master.PkStockID = $stock_id
                    having 
                                rcv_detail_id is null
                    ORDER BY 
                                tbl_warehouse.wh_name
                ";
		$pending_rcv = false;
		$rsSql = mysql_query($strSql) or die("Error auto_rcv_is_pending at stkid:" . $stock_id);
		if (mysql_num_rows($rsSql) > 0) {
			while ($row = mysql_fetch_assoc($rsSql)) {
				if ($row['rcv_detail_id'] == '' || $row['rcv_detail_id'] == NULL) {
					$pending_rcv = true;
				}
			}
		}
		return $pending_rcv;
	}

	public function autoReceiveVoucher($stockid)
	{
		mysql_query("INSERT INTO tbl_stock_master
SELECT
	'',
	tbl_stock_master.TranDate,
	CONCAT('R',SUBSTRING(tbl_stock_master.TranNo,2)),
	1,
	tbl_stock_master.TranRef,
	tbl_stock_master.WHIDFrom,
	tbl_stock_master.WHIDTo,
	tbl_stock_master.CreatedBy,
	tbl_stock_master.CreatedOn,
	tbl_stock_master.ReceivedRemarks,
	tbl_stock_master.temp,
	tbl_stock_master.trNo,
	tbl_stock_master.LinkedTr,
	tbl_stock_master.issued_by,
	tbl_stock_master.is_copied,
	tbl_stock_master.shipment_id
FROM
	tbl_stock_master
WHERE
	tbl_stock_master.PkStockID = $stockid");
	}

	/**
	 * Auto Receive Data
	 *
	 * @param type $stock_master_id
	 * @return boolean
	 */
	public function autoReceiveData($stock_id)
	{
		$objTransType = new clsTransTypes();
		$objStockDetail = new clsStockDetail();
		$objFiscalYear = new clsFiscalYear();
		$objStockBatch = new clsStockBatch();
		$objWhData = new clsWarehouseData();

		if (isset($stock_id) && !empty($stock_id)) {
			$arr_types = $objTransType->get_all();
			$array_types = array();
			foreach ($arr_types as $arrtype) {
				$array_types[$arrtype->trans_id] = $arrtype->trans_nature;
			}

			$type_id = 1;
			//find by stock id
			$stockDetail = $objStockDetail->find_by_stock_id($stock_id);

			if (mysql_num_rows($stockDetail) > 0) {
				$count = 1;
				while ($data = mysql_fetch_object($stockDetail)) {

					$user_warehouse = $data->WHIDTo;

					if ($count == 1) {
						$issued_by = $data->issued_by;
						if (empty($issued_by)) {
							$issued_by = 119;
						}
						//transaction type id
						$this->TranTypeID = $type_id;
						//transaction date
						$this->TranDate = $data->TranDate;
						//transaction reference
						$this->TranRef = $data->TranNo;
						//from warehouse
						$this->WHIDFrom = $data->WHIDFrom;
						//issued by
						$this->issued_by = $issued_by;
						//to warehouse
						$this->WHIDTo = $data->WHIDTo;
						//created by
						$this->CreatedBy = $data->CreatedBy;
						//created on
						$this->CreatedOn = date("Y-m-d");
						//Received Remarks 
						$this->ReceivedRemarks = $data->ReceivedRemarks;
						//temp
						$this->temp = 0;
						//LinkedTr 
						$this->LinkedTr = 0;
						//get get Fiscal Year
						$fy_dates = $objFiscalYear->getFiscalYear();

						//changing the from and to date , from fiscal year to only month
						//$date_breakdown = explode('/', $data->TranDate);
						//                        $year1 = $date_breakdown[2];
						//                        $mon1 = $date_breakdown[1];
						//                        $date1 = $date_breakdown[0];
						//                        $issue_date_formatted = $year1 . '-' . $mon1 . '-' . $date1;
						$issue_date_formatted = date('Y-m-d', strtotime($data->TranDate));
						//echo '<pre>';print_r($fy_dates);exit;
						//get Last ID
						$last_id = $this->getLastID(date('Y-m-01', strtotime($issue_date_formatted)), date('Y-m-t', strtotime($issue_date_formatted)), $type_id);

						if ($last_id == NULL) {
							$last_id = 0;
						}
						//transaction number
						$trans_no = "R" . date('ym') . str_pad(($last_id + 1), 4, "0", STR_PAD_LEFT);
						//set transaction number
						//echo $trans_no;exit;
						$this->TranNo = $trans_no;
						$this->trNo = ($last_id + 1);
						$fkStockID = $this->save();
					}

					$detail_id = $data->PkDetailID;

					$objStockDetail->StockReceived($detail_id);
					//Get Batch Detail
					$stockBatch = $objStockDetail->GetBatchDetail($detail_id);

					//quantity
					$quantity = str_replace("-", "", $stockBatch->Qty);
					//product id
					$product_id = $stockBatch->item_id;
					//batch number
					$objStockBatch->batch_no = $stockBatch->batch_no;
					//batch expiry
					$objStockBatch->batch_expiry = $stockBatch->batch_expiry;
					$objStockBatch->funding_source = $stockBatch->funding_source;
					$objStockBatch->manufacturer = $stockBatch->manufacturer;
					//quantity
					$objStockBatch->Qty = $quantity;
					//item id
					$objStockBatch->item_id = $product_id;
					//status
					$objStockBatch->status = 'Stacked';
					//unit price
					$objStockBatch->unit_price = $stockBatch->unit_price;
					//production date
					$objStockBatch->production_date = $stockBatch->production_date;
					//warehouse id
					$objStockBatch->wh_id = $user_warehouse;
					//            save stock batch
					//            echo '<pre>';
					//            print_r($stockBatch);
					//            print_r($objStockBatch);
					//            exit;
					$objStockBatch->check_in_wh_id = $user_warehouse;
					$batch_id1 = $objStockBatch->save();

					//fk stock id
					$objStockDetail->fkStockID = $fkStockID;
					//batch id
					$objStockDetail->BatchID = $batch_id1;
					//fk unit id
					$objStockDetail->fkUnitID = $data->fkUnitID;
					//quantity
					$objStockDetail->Qty = $array_types[$type_id] . $quantity;
					//temp
					$objStockDetail->temp = 0;
					//is received
					$objStockDetail->IsReceived = 1;
					//adjustment type
					$objStockDetail->adjustmentType = $type_id;
					//save stock detail
					$objStockDetail->save();

					// Adjust Batch Quantity
					$objStockBatch->adjustQtyByWh($batch_id1, $user_warehouse);
					//auto Running LEFO Batch
					$objStockBatch->autoRunningLEFOBatch($product_id, $user_warehouse);
					$count++;
				}
				//Save Data in WH data table (Need modification)
				$objWhData->addReport($fkStockID, 1, 'wh');
			}
			return true;
		}
		return false;
	}

	function fetch_suppliers()
	{
		$qry = "SELECT
tbl_warehouse.*
FROM
tbl_warehouse
WHERE
tbl_warehouse.hf_cat_id = 3
               ";
		return $this->query($qry);
	}

	function updategwisstatus($statusid, $id)
	{
		$qry = "UPDATE gwis_master SET status_id = '" . $statusid . "' WHERE pk_id = '" . $id . "'";
		//        echo $qry;exit;
		return $this->query($qry);
	}


	function stock_search($date_from, $date_to, $supplier_id, $type_id)
	{
		$statusid = '';
		$filter = '';
		$supplierinfo = '';
		$createdby = '';



		$stklimit = '';
		$join = '';
		//        $stkidarray = array();
		//        for ($i = 0; $i < $_SESSION['count']; $i++) {
		//            array_push($stkidarray, "'" . $_SESSION['stakeholder_id_'.$i]. "'");
		//        }
		//        $stkid = implode(', ', $stkidarray);
		$stkid = $this->get_user_stakeholders();

		if ($_SESSION['id'] == '1') {
			$stklimit = '';
			$join = '';
		} else {
			//New 
			$stklimit = " AND gwis_master.stk_id IN (" . $stkid . ")";
			//Old
			//            $stklimit = "AND stakeholder_item.stk_id IN (".$stkid.")";
			//            $join = " LEFT JOIN stakeholder ON gwis_master.stk_id = stakeholder.stkid
			//                    INNER JOIN stakeholder_item ON stakeholder_item.stk_id = stakeholder.stkid";
		}







		//        if($_SESSION['id'] == '1')
		//        {
		//            $createdby = '';
		//        }
		//        else{
		//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		//        }

		$wh_id = $this->session->userdata('warehouse_id');
		if ($type_id == 1) {
			$filter = " AND gwis_master.wh_id_to = $wh_id";
		} else if ($type_id == 2) {
			$filter = " AND gwis_master.wh_id_from = $wh_id";
		}

		if (isset($type_id) && $type_id == '0') {
			$statusid = "AND gwis_master.status_id IN (1,2)";
		}
		if (isset($type_id) && $type_id == 'gwis') {
			$statusid = "AND gwis_master.status_id IN (1)";
		}
		if (isset($type_id) && $type_id == 'tac') {
			$statusid = "AND gwis_master.status_id IN (2)";
		} else if (isset($type_id) && $type_id == '3') {
			$statusid = "AND gwis_master.status_id IN (3)";
		} else if (isset($type_id) && $type_id == '4') {
			$statusid = "AND gwis_master.status_id IN (4)";
		}

		if (isset($supplier_id) && !empty($supplier_id)) {
			$supplierinfo = "AND gwis_master.wh_id_from_supplier = '$supplier_id'";
		}

		$wh_id = $_SESSION['warehouse_id'];

		$qry = "SELECT
                        gwis_master.tran_date,
                        gwis_master.tran_ref,
                        gwis_master.tran_no,
                        gwis_master.wh_id_to,
                        gwis_master.status_id,
                        stock_batch.batch_no,
                        stock_batch.batch_expiry,
                        stock_batch.production_date,
                        ABS( gwis_detail.quantity ) AS quantity,
                        gwis_master.issuance_to,
                        tbl_warehouse.wh_name AS warehouse_name,
                        patients.full_name,
                        patients.nic_no,
                        gwis_detail.fk_stock_id,
                        gwis_detail.pk_id,
                        gwis_detail.batch_id,
                        fs.stkname AS funding_source_name,
                        itminfo_tab.itm_name AS product_name,
                        ww.wh_name AS wh_from,
                        ws.wh_name AS wh_from_supplier,
                        gwis_master.active_process,
                        gwis_master.process_status,
                        gwis_master.approve_from,
                        gwis_master.approve_to,
                        users.username,
                        gwis_detail.field1,
                        gwis_detail.field2,
                        gwis_detail.field3,
                        gwis_detail.field4,
                        gwis_detail.field5,
                        gwis_detail.field6,
                        gwis_detail.field7,
                        gwis_detail.field8,
                        gwis_detail.field9,
                        gwis_detail.field10,
                        manf.stkname AS manufacturer 
                FROM
                        gwis_master
                        LEFT JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                        LEFT JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                        LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                        LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
                        LEFT JOIN patients ON gwis_master.wh_id_to = patients.pk_id
                        LEFT JOIN stakeholder AS fs ON stock_batch.funding_source = fs.stkid
                        LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                        LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                        LEFT JOIN users ON gwis_master.created_by = users.pk_id
                        LEFT JOIN stakeholder AS manf ON itminfo_tab.manufacturer_id = manf.stkid 
                WHERE
                    Date(gwis_master.tran_date) BETWEEN '$date_from' AND '$date_to'
					AND stock_batch.wh_id = $wh_id
					AND gwis_master.active_process = '1'
                    $statusid
                    $filter
                    $supplierinfo
                    $createdby
                    $stklimit
                    GROUP BY
					gwis_master.pk_id 
                    ORDER BY 
                        gwis_master.pk_id DESC
                    ";
		//print_r($qry);exit;
		return $this->query($qry);
	}

	function generate_grn_number($processtatus)
	{

		if ($processtatus == 7) {
			$current_year = date("Y");
			//current month
			$current_month = date("m");
			if ($current_month < 7) {
				//from date
				$from_date = ($current_year - 1) . "-06-30";
				//to date
				$to_date = $current_year . "-07-30";
			} else {
				//from date
				$from_date = $current_year . "-06-30";
				//to date
				$to_date = ($current_year + 1) . "-07-30";
			}

			//get last id
			$last_id = $this->getProcessLastID($from_date, $to_date, $processtatus);

			if (!empty($last_id)) {
				if ($last_id)
					$last_idd = $last_id->result_array();
				foreach ($last_idd as $row) {
					$lastid = $row['Maxtr'];
				}
			}

			if ($lastid == NULL) {
				$lastid = 0;
			}
			$prefix = '';
			// $itmname = '';
			// if (isset($_REQUEST['tran_no']) && !empty($_REQUEST['tran_no'])) {
			// 	$itmname = $_REQUEST['tran_no'];
			// }
			// if (isset($itmname) && !empty($itmname)) {
			// 	$charc = substr($itmname, 0, 1);
			// 	if ($charc == 'A') {
			// 		$prefix = $charc;
			// 	} else if ($charc == 'M') {
			// 		$prefix = $charc;
			// 	} else if ($charc == 'TB') {
			// 		$prefix = $charc;
			// 	} else {
			// 		$prefix = '';
			// 	}
			// }

			return array('tr_no' => $prefix . "GRN" . $processtatus . date('ym') . str_pad(($lastid + 1), 4, "0", STR_PAD_LEFT),
			'last_id' => $lastid+1);
		} else {
			return '';
		}
	}

	function clone_record_grn($stk_id, $approvefrom, $approveto, $processtatus, $finalstatus, $fileto, $user_id, $status_id, $tran_id, $trn_no)
	{

		if(!empty($trn_no)){
			$tr_no = "'".$trn_no['tr_no']."'";
			$last_id = $trn_no['last_id'];
		} else {
			$tr_no = 'gwis_master.tran_no';
			$last_id = 'gwis_master.tr_no';
		}

		$this->query("UPDATE gwis_master SET active_process = 0, tran_type_id=0 WHERE pk_id = $stk_id");

		$qry = "INSERT INTO gwis_master (
		gwis_master.tran_date, 
		gwis_master.tran_no, 
		gwis_master.status_id, 
		gwis_master.tran_ref, 
		gwis_master.wh_id_from, 
		gwis_master.wh_id_to, 
		gwis_master.created_by, 
		gwis_master.created_on, 
		gwis_master.received_remarks, 
		gwis_master.temp, 
		gwis_master.tr_no, 
		gwis_master.linked_tr, 
		gwis_master.issued_by, 
		gwis_master.is_copied, 
		gwis_master.shipment_id, 
		gwis_master.wh_id_from_supplier, 
		gwis_master.shipment_mode, 
		gwis_master.attachment_name, 
		gwis_master.method, 
		gwis_master.requisition_type, 
		gwis_master.source_type, 
		gwis_master.`event`, 
		gwis_master.po_detail, 
		gwis_master.issuance_to, 
		gwis_master.mcc_year, 
		gwis_master.user_from, 
		gwis_master.user_to, 
		gwis_master.approve_from, 
		gwis_master.approve_to, 
		gwis_master.parent_id, 
		gwis_master.process_status, 
		gwis_master.active_process, 
		gwis_master.final_status, 
		gwis_master.electronic_approval, 
		gwis_master.tran_type_id, 
		gwis_master.stk_id, 
		gwis_master.inspection_date, 
		gwis_master.delivery_location, 
		gwis_master.po_cmu_no, 
		gwis_master.po_cmu_date, 
		gwis_master.po_gf_no, 
		gwis_master.po_gf_date, 
		gwis_master.date_of_receiving, 
		gwis_master.air_bill_no, 
		gwis_master.shipment_no, 
		gwis_master.origin_of_country, 
		gwis_master.vehicle_type_and_plate, 
		gwis_master.consignment_weight, 
		gwis_master.file, 
		gwis_master.issue_to_info, 
		gwis_master.province_id, 
		gwis_master.script_master_id) 
		SELECT  
	gwis_master.tran_date, 
	$tr_no, 
	$status_id, 
	gwis_master.tran_ref, 
	gwis_master.wh_id_from_supplier, 
	gwis_master.wh_id_to, 
	$user_id, 
	NOW(), 
	gwis_master.received_remarks, 
	gwis_master.temp, 
	$last_id,
	gwis_master.linked_tr, 
	gwis_master.issued_by, 
	gwis_master.is_copied, 
	gwis_master.shipment_id, 
	gwis_master.wh_id_from_supplier, 
	gwis_master.shipment_mode, 
	gwis_master.attachment_name, 
	gwis_master.method, 
	gwis_master.requisition_type, 
	gwis_master.source_type, 
	gwis_master.`event`, 
	gwis_master.po_detail, 
	'centers', 
	gwis_master.mcc_year, 
	gwis_master.user_from, 
	gwis_master.user_to, 
	'$approvefrom', 
	'$approveto', 
	$stk_id, 
	$processtatus, 
	1, 
	$finalstatus, 
	gwis_master.electronic_approval, 
	$tran_id, 
	gwis_master.stk_id, 
	gwis_master.inspection_date, 
	gwis_master.delivery_location, 
	gwis_master.po_cmu_no, 
	gwis_master.po_cmu_date, 
	gwis_master.po_gf_no, 
	gwis_master.po_gf_date, 
	gwis_master.date_of_receiving, 
	gwis_master.air_bill_no, 
	gwis_master.shipment_no, 
	gwis_master.origin_of_country, 
	gwis_master.vehicle_type_and_plate, 
	gwis_master.consignment_weight, 
	'$fileto', 
	gwis_master.issue_to_info, 
	gwis_master.province_id, 
	gwis_master.script_master_id FROM gwis_master WHERE gwis_master.pk_id = $stk_id";
		// echo $qry;
		// exit;
		$this->query($qry);
		return $this->insert_id();
	}

	function clone_record($stk_id, $approvefrom, $approveto, $processtatus, $finalstatus, $fileto, $user_id, $status_id, $tran_id)
	{

		$this->query("UPDATE gwis_master SET active_process = 0, tran_type_id=0 WHERE pk_id = $stk_id");

		$qry = "INSERT INTO gwis_master (
		gwis_master.tran_date, 
		gwis_master.tran_no, 
		gwis_master.status_id, 
		gwis_master.tran_ref, 
		gwis_master.wh_id_from, 
		gwis_master.wh_id_to, 
		gwis_master.created_by, 
		gwis_master.created_on, 
		gwis_master.received_remarks, 
		gwis_master.temp, 
		gwis_master.tr_no, 
		gwis_master.linked_tr, 
		gwis_master.issued_by, 
		gwis_master.is_copied, 
		gwis_master.shipment_id, 
		gwis_master.wh_id_from_supplier, 
		gwis_master.shipment_mode, 
		gwis_master.attachment_name, 
		gwis_master.method, 
		gwis_master.requisition_type, 
		gwis_master.source_type, 
		gwis_master.`event`, 
		gwis_master.po_detail, 
		gwis_master.issuance_to, 
		gwis_master.mcc_year, 
		gwis_master.user_from, 
		gwis_master.user_to, 
		gwis_master.approve_from, 
		gwis_master.approve_to, 
		gwis_master.parent_id, 
		gwis_master.process_status, 
		gwis_master.active_process, 
		gwis_master.final_status, 
		gwis_master.electronic_approval, 
		gwis_master.tran_type_id, 
		gwis_master.stk_id, 
		gwis_master.inspection_date, 
		gwis_master.delivery_location, 
		gwis_master.po_cmu_no, 
		gwis_master.po_cmu_date, 
		gwis_master.po_gf_no, 
		gwis_master.po_gf_date, 
		gwis_master.date_of_receiving, 
		gwis_master.air_bill_no, 
		gwis_master.shipment_no, 
		gwis_master.origin_of_country, 
		gwis_master.vehicle_type_and_plate, 
		gwis_master.consignment_weight, 
		gwis_master.file, 
		gwis_master.issue_to_info, 
		gwis_master.province_id, 
		gwis_master.script_master_id) 
		SELECT  
	gwis_master.tran_date, 
	gwis_master.tran_no, 
	$status_id, 
	gwis_master.tran_ref, 
	gwis_master.wh_id_from, 
	gwis_master.wh_id_to, 
	$user_id, 
	NOW(), 
	gwis_master.received_remarks, 
	gwis_master.temp, 
	gwis_master.tr_no, 
	gwis_master.linked_tr, 
	gwis_master.issued_by, 
	gwis_master.is_copied, 
	gwis_master.shipment_id, 
	gwis_master.wh_id_from_supplier, 
	gwis_master.shipment_mode, 
	gwis_master.attachment_name, 
	gwis_master.method, 
	gwis_master.requisition_type, 
	gwis_master.source_type, 
	gwis_master.`event`, 
	gwis_master.po_detail, 
	'centers', 
	gwis_master.mcc_year, 
	gwis_master.user_from, 
	gwis_master.user_to, 
	'$approvefrom', 
	'$approveto', 
	$stk_id, 
	$processtatus, 
	1, 
	$finalstatus, 
	gwis_master.electronic_approval, 
	$tran_id, 
	gwis_master.stk_id, 
	gwis_master.inspection_date, 
	gwis_master.delivery_location, 
	gwis_master.po_cmu_no, 
	gwis_master.po_cmu_date, 
	gwis_master.po_gf_no, 
	gwis_master.po_gf_date, 
	gwis_master.date_of_receiving, 
	gwis_master.air_bill_no, 
	gwis_master.shipment_no, 
	gwis_master.origin_of_country, 
	gwis_master.vehicle_type_and_plate, 
	gwis_master.consignment_weight, 
	'$fileto', 
	gwis_master.issue_to_info, 
	gwis_master.province_id, 
	gwis_master.script_master_id FROM gwis_master WHERE gwis_master.pk_id = $stk_id";
		// echo $qry;
		// exit;
		$this->query($qry);
		return $this->insert_id();
	}

	function stock_search_by_stk_wh($date_from, $date_to, $supplier_id, $type_id, $stakeholder, $warehouse)
	{
		$statusid = '';
		$filter = '';
		$supplierinfo = '';
		$createdby = '';
		$stakeholderinfo = '';
		$warehouseinfo = '';


		$stklimit = '';
		//        $join = '';
		//        $stkid = $this->get_user_stakeholders();
		//        
		//        if($_SESSION['id'] == '1')
		//        {
		//            $stklimit = '';
		//            $join = '';
		//        }
		//        else{ 
		//            //New 
		//            $stklimit = " AND gwis_master.stk_id IN (".$stkid.")";
		//            //Old
		////            $stklimit = "AND stakeholder_item.stk_id IN (".$stkid.")";
		////            $join = " LEFT JOIN stakeholder ON gwis_master.stk_id = stakeholder.stkid
		////                    INNER JOIN stakeholder_item ON stakeholder_item.stk_id = stakeholder.stkid";
		//        }
		//        






		//        if($_SESSION['id'] == '1')
		//        {
		//            $createdby = '';
		//        }
		//        else{
		//            $createdby = " AND gwis_master.created_by = '".$_SESSION['id']."'";
		//        }

		//        $wh_id = $this->session->userdata('warehouse_id');
		//        if($type_id==1){
		//            $filter=" AND gwis_master.wh_id_to = $wh_id";
		//        }
		//        else if($type_id==2){
		//            $filter=" AND gwis_master.wh_id_from = $wh_id";
		//        }

		if (isset($type_id) && $type_id == '0') {
			$statusid = "AND gwis_master.status_id IN (1,2)";
		}
		if (isset($type_id) && $type_id == 'gwis') {
			$statusid = "AND gwis_master.status_id IN (1)";
		}
		if (isset($type_id) && $type_id == 'tac') {
			$statusid = "AND gwis_master.status_id IN (2)";
		} else if (isset($type_id) && $type_id == '3') {
			$statusid = "AND gwis_master.status_id IN (3)";
		} else if (isset($type_id) && $type_id == '4') {
			$statusid = "AND gwis_master.status_id IN (4)";
		}

		if (isset($supplier_id) && !empty($supplier_id)) {
			$supplierinfo = "AND gwis_master.wh_id_from_supplier = '$supplier_id'";
		}

		if (isset($warehouse) && !empty($warehouse)) {
			$warehouseinfo = " AND gwis_master.wh_id_to = $warehouse";
		}
		if (isset($stakeholder) && !empty($stakeholder)) {
			$stakeholderinfo = "AND gwis_master.stk_id = '$stakeholder'";
		}

		$wh_id = $this->session->userdata('warehouse_id');
		$stkids = $this->get_user_stakeholders();

		$qry = "SELECT
                        gwis_master.tran_date,
                        gwis_master.tran_ref,
                        gwis_master.tran_no,
                        gwis_master.wh_id_to,
                        gwis_master.status_id,
                        stock_batch.batch_no,
                        stock_batch.batch_expiry,
                        stock_batch.production_date,
                        ABS( gwis_detail.quantity ) AS quantity,
                        gwis_master.issuance_to,
                        tbl_warehouse.wh_name AS warehouse_name,
                        patients.full_name,
                        patients.nic_no,
                        gwis_detail.fk_stock_id,
                        gwis_detail.pk_id,
                        gwis_detail.batch_id,
                        fs.stkname AS funding_source_name,
                        itminfo_tab.itm_name AS product_name,
                        ww.wh_name AS wh_from,
                        ws.wh_name AS wh_from_supplier,
                        gwis_master.active_process,
                        gwis_master.process_status,
                        gwis_master.approve_from,
                        gwis_master.approve_to,
                        users.username,
                        gwis_detail.field1,
                        gwis_detail.field2,
                        gwis_detail.field3,
                        gwis_detail.field4,
                        gwis_detail.field5,
                        gwis_detail.field6,
                        gwis_detail.field7,
                        gwis_detail.field8,
                        gwis_detail.field9,
                        gwis_detail.field10,
                        manf.stkname AS manufacturer,
                        stock_batch.Qty,
                        stock_batch.unit_price,
                        stock_batch.conversion_rate
                FROM
                        gwis_master
                        LEFT JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                        LEFT JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                        LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
						LEFT JOIN stakeholder_item ON stakeholder_item.product_id = itminfo_tab.itm_id
                        LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
                        LEFT JOIN patients ON gwis_master.wh_id_to = patients.pk_id
                        LEFT JOIN stakeholder AS fs ON stock_batch.funding_source = fs.stkid
                        LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                        LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                        LEFT JOIN users ON gwis_master.created_by = users.pk_id
                        LEFT JOIN stakeholder AS manf ON itminfo_tab.manufacturer_id = manf.stkid 
                WHERE
                    Date(gwis_master.tran_date) BETWEEN '$date_from' AND '$date_to'
					AND gwis_master.active_process=1
					AND stakeholder_item.stk_id IN($stkids)
					AND stock_batch.wh_id = $wh_id
                    $warehouseinfo
                    $stakeholderinfo
                    $statusid
                    $filter
                    $supplierinfo
                    $createdby
                    $stklimit
                    GROUP BY
                        gwis_detail.fk_stock_id 
                    ORDER BY 
                        gwis_master.pk_id DESC
                    ";
		//                    print_r($qry);exit;
		return $this->query($qry);
	}

	function transport_req_form_search($date_from, $date_to, $supplier_id, $type_id)
	{
		$statusid = '';
		$filter = '';
		$supplierinfo = '';
		$createdby = '';

		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		$wh_id = $this->session->userdata('warehouse_id');

		if (isset($type_id) && $type_id == '5') {
			$statusid = "AND gwis_master.status_id IN (5)";
		}

		if (isset($supplier_id) && !empty($supplier_id)) {
			$supplierinfo = "AND gwis_master.wh_id_from_supplier = '$supplier_id'";
		}

		$qry = "SELECT
                        gwis_master.tran_date,
                        gwis_master.tran_ref,
                        gwis_master.tran_no,
                        gwis_master.wh_id_to,
                        gwis_master.status_id,
                        stock_batch.batch_no,
                        stock_batch.batch_expiry,
                        ABS( gwis_detail.quantity ) AS quantity,
                        gwis_master.issuance_to,
                        tbl_warehouse.wh_name AS warehouse_name,
                        patients.full_name,
                        patients.nic_no,
                        gwis_detail.fk_stock_id,
                        gwis_detail.pk_id,
                        gwis_detail.batch_id,
                        funding_sources.funding_source_name,
                        itminfo_tab.itm_name AS product_name,
                        ww.wh_name AS wh_from,
                        ws.wh_name AS wh_from_supplier,
                        gwis_master.active_process,
                        gwis_master.process_status,
                        gwis_master.approve_from,
                        gwis_master.approve_to,
                        users.username,
                        gwis_detail.field1,
                        gwis_detail.field2,
                        gwis_detail.field3,
                        gwis_detail.field4,
                        gwis_detail.field5,
                        gwis_detail.field6,
                        gwis_detail.field7,
                        gwis_detail.field8,
                        gwis_detail.field9,
                        gwis_detail.field10,
                        stakeholder.stkname AS manufacturer
                FROM
                        gwis_master
                        LEFT JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                        LEFT JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                        LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                        LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
                        LEFT JOIN patients ON gwis_master.wh_id_to = patients.pk_id
                        LEFT JOIN funding_sources ON stock_batch.funding_source = funding_sources.pk_id
                        LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                        LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                        LEFT JOIN users ON gwis_master.created_by = users.pk_id
                        LEFT JOIN stakeholder ON itminfo_tab.manufacturer_id = stakeholder.stkid 
                WHERE
                    Date(gwis_master.tran_date) BETWEEN '$date_from' AND '$date_to'
                    $statusid
                    $filter
                    $supplierinfo
                    $createdby
                    GROUP BY
                        gwis_detail.fk_stock_id 
                    ORDER BY 
                        gwis_master.pk_id DESC
                    ";
		//                    print_r($qry);exit;
		return $this->query($qry);
	}

	function save_master_temp($stock_master_id)
	{
		$qry = "UPDATE gwis_master set temp=0 where pk_id=$stock_master_id";
		$this->query($qry);
		return true;
	}

	function get_temp_master_records_adj($transaction_type, $issuance_type = '')
	{
		$wh_id = $this->session->userdata('warehouse_id');
		$filter = '';
		if ($issuance_type != '') {
			//            $filter = "AND gwis_master.issuance_to='$issuance_type'";
		}
		$qry = "SELECT
        stock_batch.batch_no,
        stock_batch.batch_expiry,
        gwis_master.pk_id as stock_master_id,
        ABS(gwis_detail.quantity) as quantity,
        itminfo_tab.itm_name AS product_name,
        itminfo_tab.pack_size,
        itminfo_tab.unit,
        product_manufacturer.manufacturer,
        gwis_detail.pk_id,
        gwis_detail.fk_stock_id,
        gwis_detail.batch_id,
        funding_sources.funding_source_name,
        tbl_warehouse.wh_name AS warehouse_name,
        patients.full_name,
        patients.nic_no,
        gwis_master.issuance_to,
        gwis_master.tran_ref,
        transaction_types.trans_type,
        transaction_types.trans_id,
        gwis_master.wh_id_to,
        wfrom.wh_name AS wh_from,
	stakeholder.stkname,
	stakeholder.stkid 
        FROM
        gwis_detail
        INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
        LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
        LEFT JOIN product_manufacturer ON product_manufacturer.pk_id = itminfo_tab.manufacturer_id
        LEFT JOIN funding_sources ON stock_batch.funding_source = funding_sources.pk_id
        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
        INNER JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
        LEFT JOIN patients ON gwis_master.wh_id_to = patients.pk_id
        LEFT JOIN transaction_types ON gwis_master.tran_type_id = transaction_types.trans_id
INNER JOIN tbl_warehouse AS wfrom ON gwis_master.wh_id_from = wfrom.wh_id
INNER JOIN stakeholder ON gwis_master.stk_id = stakeholder.stkid 
        WHERE 
        gwis_master.wh_id_to = $wh_id
            AND gwis_detail.temp=1";
		//        if($transaction_type > 2){
		//            $qry .= " AND gwis_master.status_id > 2";
		//        }
		//        else{
		$qry .= " AND gwis_master.status_id=$transaction_type";
		//        }
		$qry .= "
                $filter
        ";
		//        print_r($qry);exit;
		return $this->query($qry);
	}

	//    function get_temp_master_records($transaction_type, $issuance_type = '') {
	function get_temp_master_records($transaction_type)
	{
		$wh_id = $this->session->userdata('warehouse_id');
		$filter = '';
		//        if ($issuance_type != '') {
		//            $filter = "AND gwis_master.issuance_to='$issuance_type'";
		//        }

		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			$createdby = "AND gwis_master.created_by = '" . $_SESSION['id'] . "'";
		}

		$qry = "SELECT
	stock_batch.batch_no,
	stock_batch.batch_expiry,
	ABS( gwis_detail.quantity ) AS quantity,
	itminfo_tab.itm_name AS product_name,
	product_manufacturer.manufacturer,
	gwis_detail.pk_id,
	gwis_detail.fk_stock_id,
	funding_sources.funding_source_name,
	tbl_warehouse.wh_name AS warehouse_name,
	patients.full_name,
	patients.nic_no,
	gwis_master.issuance_to,
	gwis_master.tran_ref,
        gwis_master.tran_no,
	gwis_master.wh_id_to,
        gwis_master.pk_id AS stock_master_id,
	wfrom.wh_name AS wh_from,
        stock_batch.batch_no,
	stock_batch.Qty,
	stock_batch.batch_expiry,
	ABS( gwis_detail.quantity ) AS quantity,
	itminfo_tab.itm_name AS product_name,
	itminfo_tab.product_type,
        itminfo_tab.pack_size,
        itminfo_tab.unit,
	product_manufacturer.manufacturer,
	gwis_detail.pk_id,
	gwis_detail.fk_stock_id,
	tbl_warehouse.wh_name AS warehouse_name,
	patients.full_name,
	patients.nic_no,
	gwis_master.issuance_to,
	transaction_types.trans_type,
        ww.wh_id AS wh_from_id,
	ww.wh_name AS wh_from,
	gwis_master.wh_id_to,
	ws.wh_name AS wh_from_supplier,
	stock_batch.production_date,
	gwis_master.tran_date,
	gwis_detail.dc_quantity,
	gwis_detail.pi_quantity,
	gwis_detail.pi_comment,
	gwis_master.received_remarks,
	gwis_detail.field1,
	gwis_detail.field2,
	gwis_detail.field3,
	gwis_detail.field4,
	gwis_detail.field5,
	gwis_detail.field6,
	gwis_detail.field7,
	gwis_detail.field8,
	gwis_detail.field9,
	gwis_detail.field10,
        gwis_detail.batch_id,
	stakeholder.stkname 
FROM
	gwis_detail
	INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
	LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
	LEFT JOIN product_manufacturer ON product_manufacturer.pk_id = itminfo_tab.manufacturer_id
	LEFT JOIN funding_sources ON stock_batch.funding_source = funding_sources.pk_id
	INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
	LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
	LEFT JOIN patients ON gwis_master.wh_id_to = patients.pk_id
	LEFT JOIN tbl_warehouse AS wfrom ON gwis_master.wh_id_from = wfrom.wh_id
        LEFT JOIN transaction_types ON gwis_master.status_id = transaction_types.trans_id
	LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
	LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
	LEFT JOIN stakeholder ON stock_batch.funding_source = stakeholder.stkid
        LEFT JOIN users ON gwis_master.created_by = users.pk_id
WHERE
	 gwis_detail.temp = 1 
            AND gwis_detail.temp=1
            AND gwis_master.status_id = '$transaction_type'
            $createdby ";
		//        if($transaction_type > 4){
		//            $qry .= " gwis_master.status_id > 4";
		//        }
		//        else{
		//            $qry .= " AND gwis_master.status_id = $transaction_type";
		//        }
		$qry .= "
                $filter
        ";
		//        print_r($qry);exit;
		return $this->query($qry);
	}

	function get_issue_vouchers()
	{

		$createdby = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			$createdby = '';
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		$qry_vouchers = "SELECT DISTINCT gwis_master.tran_no,
                                gwis_detail.is_received
                        FROM
                                gwis_master

                        INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                        WHERE
                                gwis_master.status_id IN (" . $this->status_id . ") AND
                                gwis_detail.is_received = 0 
                                $createdby
                                AND gwis_master.active_process = '1' 
                                AND gwis_master.process_status IN (" . $this->process_status . ")";

		//                        if($_SESSION['is_allowed_im'] == 1 && !empty($_SESSION['im_start_month']) && $_SESSION['im_start_month'] > '2017-01-01')
		//                        $qry_vouchers.= "  AND gwis_master.tran_date > '".$_SESSION['im_start_month']."' ";

		$qry_vouchers .= "               ORDER BY
                                                                gwis_master.pk_id ASC";
		//                        echo $qry_vouchers;exit;
		return $this->query($qry_vouchers);
	}

	function getgwis_issue_vouchers($approvefrom)
	{

		$createdby = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			$createdby = '';
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		if (isset($this->parent_id) && $this->parent_id == '0') {
			$pcreated_by = " AND gwis_master.created_by = '" . $_SESSION['id'] . "'";
		} else {
			$pcreated_by = '';
		}

		if ($approvefrom == '=') {
			$wr = "(gwis_master.approve_from = '' OR gwis_master.approve_from IS NULL)";
		} else {
			$wr = "gwis_master.approve_from != ''";
		}

		$qry_vouchers = "SELECT DISTINCT gwis_master.tran_no,
                                gwis_detail.is_received
                        FROM
                                gwis_master

                        INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                        WHERE
                                gwis_master.status_id IN (" . $this->status_id . ") AND
                                gwis_detail.is_received = 0 
                                $createdby
                                $pcreated_by
                                AND gwis_master.active_process = '1'
                                AND $wr
                                AND gwis_master.process_status IN (" . $this->process_status . ")";

		//                        if($_SESSION['is_allowed_im'] == 1 && !empty($_SESSION['im_start_month']) && $_SESSION['im_start_month'] > '2017-01-01')
		//                        $qry_vouchers.= "  AND gwis_master.tran_date > '".$_SESSION['im_start_month']."' ";

		$qry_vouchers .= "               ORDER BY
                                                                gwis_master.pk_id ASC";
		//                        echo $qry_vouchers;exit;
		return $this->query($qry_vouchers);
	}

	function get_rejected_vouchers()
	{

		$createdby = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		if (isset($this->parent_id) && $this->parent_id == '0') {
			$pcreated_by = " AND gwis_master.created_by = '" . $_SESSION['id'] . "'";
		} else {
			$pcreated_by = '';
		}

		$qry_vouchers = "SELECT DISTINCT gwis_master.tran_no,
                                gwis_detail.is_received
                        FROM
                                gwis_master

                        INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                        WHERE
                                gwis_master.status_id IN (" . $this->status_id . ") AND
                                gwis_detail.is_received = 0 
                                $createdby
                                AND gwis_detail.electronic_approval = 2
                                AND gwis_detail.electronic_approval_status = 1
                                AND gwis_master.process_status IN (" . $this->process_status . ")";

		//                        if($_SESSION['is_allowed_im'] == 1 && !empty($_SESSION['im_start_month']) && $_SESSION['im_start_month'] > '2017-01-01')
		//                        $qry_vouchers.= "  AND gwis_master.tran_date > '".$_SESSION['im_start_month']."' ";

		$qry_vouchers .= "               ORDER BY
                                                                gwis_master.pk_id ASC";
		//                        echo $qry_vouchers;exit;
		return $this->query($qry_vouchers);
	}

	function rejected_real_masterid($tranref)
	{

		$createdby = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		$qry_vouchers = "SELECT MAX(pk_id) AS stkmasterid FROM gwis_master WHERE tran_ref= '$tranref' ";
		//                        echo $qry_vouchers;exit;
		return $this->query($qry_vouchers);
	}

	function get_dtlafter_vouchers($process_status_dtlnmbr)
	{

		$createdby = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		$qry_vouchers = "SELECT DISTINCT 
                                MAX(gwis_detail.pk_id), 
                                gwis_master.tran_no,
                                gwis_detail.is_received
                        FROM
                                gwis_master

                        INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                        INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
                        WHERE
                                gwis_master.status_id IN (2) AND
                                gwis_detail.is_received = 0 
                                $createdby
                                AND stock_batch.dtl IN (2)
                                AND stock_batch.dtl_status = 'inprocess' 
                                AND stock_batch.dtl_result IN ( 3, 4 ) 
                                AND gwis_master.process_status IN (" . $process_status_dtlnmbr . ")";

		//                        if($_SESSION['is_allowed_im'] == 1 && !empty($_SESSION['im_start_month']) && $_SESSION['im_start_month'] > '2017-01-01')
		//                        $qry_vouchers.= "  AND gwis_master.tran_date > '".$_SESSION['im_start_month']."' ";

		$qry_vouchers .= "               ORDER BY
                                                                gwis_master.pk_id ASC";
		//                        echo $qry_vouchers;exit;
		return $this->query($qry_vouchers);
	}

	function get_grn_issue_vouchers($dtlchk)
	{

		$createdby = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		$qry_vouchers = "SELECT DISTINCT gwis_master.tran_no,
                                gwis_detail.is_received
                        FROM
                                gwis_master

                        INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                        INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id 
                        WHERE
                                gwis_master.status_id IN (" . $this->status_id . ") AND
                                gwis_detail.is_received = 0 
                                $dtlchk
                                $createdby
                                AND gwis_master.active_process = '1' 
                                AND gwis_master.process_status IN (" . $this->process_status . ")";

		//                        if($_SESSION['is_allowed_im'] == 1 && !empty($_SESSION['im_start_month']) && $_SESSION['im_start_month'] > '2017-01-01')
		//                        $qry_vouchers.= "  AND gwis_master.tran_date > '".$_SESSION['im_start_month']."' ";

		$qry_vouchers .= "               ORDER BY
                                                                gwis_master.pk_id ASC";
		//                        echo $qry_vouchers;exit;
		return $this->query($qry_vouchers);
	}


	function get_transport_req_from_vouchers()
	{

		$createdby = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		$qry_vouchers = "SELECT DISTINCT gwis_master.tran_no,
                                gwis_detail.is_received
                        FROM
                                gwis_master

                        INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                        INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id 
                        WHERE
                                gwis_master.status_id IN (" . $this->status_id . ") AND
                                gwis_detail.is_received = 0 
                                $createdby
                                AND gwis_master.active_process = '1' 
                                AND gwis_master.process_status IN (" . $this->process_status . ")";

		//                        if($_SESSION['is_allowed_im'] == 1 && !empty($_SESSION['im_start_month']) && $_SESSION['im_start_month'] > '2017-01-01')
		//                        $qry_vouchers.= "  AND gwis_master.tran_date > '".$_SESSION['im_start_month']."' ";

		$qry_vouchers .= "               ORDER BY
                                                                gwis_master.pk_id ASC";
		//                        echo $qry_vouchers;exit;
		return $this->query($qry_vouchers);
	}

	function get_giv_issue_vouchers()
	{

		$createdby = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		if (isset($this->parent_id) && $this->parent_id == '0') {
			$pcreated_by = " AND gwis_master.created_by = '" . $_SESSION['id'] . "'";
		} else {
			$pcreated_by = '';
		}

		$qry_vouchers = "SELECT DISTINCT gwis_master.tran_no,
                                gwis_detail.is_received
                        FROM
                                gwis_master

                        INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                        INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id 
                        WHERE
                                gwis_master.status_id IN (" . $this->status_id . ") AND
                                gwis_detail.is_received = 0 
                                $createdby
                                $pcreated_by    
                                AND gwis_master.active_process = '1' 
                                AND gwis_master.process_status IN (" . $this->process_status . ")";

		//                        if($_SESSION['is_allowed_im'] == 1 && !empty($_SESSION['im_start_month']) && $_SESSION['im_start_month'] > '2017-01-01')
		//                        $qry_vouchers.= "  AND gwis_master.tran_date > '".$_SESSION['im_start_month']."' ";

		$qry_vouchers .= "               ORDER BY
                                                                gwis_master.pk_id ASC";
		//                        echo $qry_vouchers;exit;
		return $this->query($qry_vouchers);
	}

	function get_tac_issue_vouchers($dtlchk)
	{

		$createdby = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		$qry_vouchers = "SELECT DISTINCT gwis_master.tran_no,
                                gwis_master.pk_id,
                                gwis_master.status_id,
                                gwis_detail.is_received
                        FROM
                                gwis_master

                        INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                        INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id 
                        WHERE
                                gwis_master.status_id IN (" . $this->status_id . ") AND
                                gwis_detail.is_received = 0 
                                $createdby
                                AND gwis_master.active_process = '1' 
                                $dtlchk
                                AND gwis_master.process_status IN (" . $this->process_status . ")";

		//                        if($_SESSION['is_allowed_im'] == 1 && !empty($_SESSION['im_start_month']) && $_SESSION['im_start_month'] > '2017-01-01')
		//                        $qry_vouchers.= "  AND gwis_master.tran_date > '".$_SESSION['im_start_month']."' ";

		$qry_vouchers .= "               ORDER BY
                                                                gwis_master.pk_id ASC";
		//                        echo $qry_vouchers;exit;
		return $this->query($qry_vouchers);
	}

	function get_dtl_vouchers()
	{

		$createdby = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		$qry_vouchers = "SELECT DISTINCT gwis_master.tran_no,
                                gwis_detail.is_received
                        FROM
                                gwis_master

                        INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                        INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id 
                        WHERE
                                gwis_master.status_id IN (" . $this->status_id . ") AND
                                gwis_detail.is_received = 0 
                                $createdby
                                AND gwis_master.active_process = '1' 
                                AND gwis_master.process_status IN (" . $this->process_status . ")
                                AND stock_batch.dtl_status = 'inprocess'
                                AND (stock_batch.dtl_result IS NULL OR stock_batch.dtl_result = 0)
                                AND stock_batch.dtl = 2 ";

		//                        if($_SESSION['is_allowed_im'] == 1 && !empty($_SESSION['im_start_month']) && $_SESSION['im_start_month'] > '2017-01-01')
		//                        $qry_vouchers.= "  AND gwis_master.tran_date > '".$_SESSION['im_start_month']."' ";

		$qry_vouchers .= "               ORDER BY
                                                                gwis_master.pk_id ASC";
		//                        echo $qry_vouchers;exit;
		return $this->query($qry_vouchers);
	}

	function getprocess_status($process_status)
	{

		$createdby = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		$qry_vouchers = "SELECT
                                GROUP_CONCAT( approval_code.pk_id ) AS pk_id,
                                GROUP_CONCAT( approval_code.processid ) AS processid,
                                GROUP_CONCAT( approval_code.process_status ) AS process_status 
                        FROM
                                approval_code 
                        WHERE
                                approval_code.processid = '" . $process_status . "'
                                AND process_status != (
                                SELECT
                                        MAX( process_status ) 
                                FROM
                                        approval_code 
                        WHERE
                                approval_code.processid = '" . $process_status . "')";

		//                        echo $qry_vouchers;exit;
		return $this->query($qry_vouchers);
	}

	function get_dtl_process_status($process_status)
	{

		$createdby = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		$qry_vouchers = "SELECT
                                GROUP_CONCAT( approval_code.pk_id ) AS pk_id,
                                GROUP_CONCAT( approval_code.processid ) AS processid,
                                GROUP_CONCAT( approval_code.process_status ) AS process_status 
                        FROM
                                approval_code 
                        WHERE
                                approval_code.processid = '" . $process_status . "'
                                ";

		//                        echo $qry_vouchers;exit;
		return $this->query($qry_vouchers);
	}

	function getprocess_statusmax($process_status)
	{

		$createdby = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		$qry_vouchers = "SELECT
                                approval_code.pk_id,
                                approval_code.processid AS processid,
                                MAX( approval_code.process_status ) AS process_status 
                        FROM
                                approval_code 
                        WHERE
                                approval_code.processid = '$process_status' ";

		//                        echo $qry_vouchers;exit;
		return $this->query($qry_vouchers);
	}

	function get_gwis_adjustment()
	{

		$createdby = '';
		if ($_SESSION['id'] == '1') {
			$createdby = '';
		} else {
			//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
		}

		$qry_vouchers = "SELECT DISTINCT gwis_master.tran_no,
                                gwis_master.pk_id,
                                gwis_master.status_id,
                                gwis_detail.is_received
                        FROM
                                gwis_master

                        INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                        WHERE
                                gwis_master.status_id IN ( 1, 2 )  AND
                                gwis_detail.is_received = 0 
                                $createdby
                                AND gwis_master.wh_id_to = '" . $_SESSION['warehouse_id'] . "' ";

		//                        if($_SESSION['is_allowed_im'] == 1 && !empty($_SESSION['im_start_month']) && $_SESSION['im_start_month'] > '2017-01-01')
		//                        $qry_vouchers.= "  AND gwis_master.tran_date > '".$_SESSION['im_start_month']."' ";

		$qry_vouchers .= "               ORDER BY
                                                                gwis_master.pk_id ASC";
		//                        echo $qry_vouchers;exit;
		return $this->query($qry_vouchers);
	}

	function Getwhanduid($stockid)
	{
		$qry = "SELECT
                                            gwis_master.wh_id_from,
                                            gwis_master.created_by
                                    FROM
                                            gwis_master
                                    WHERE
                                            gwis_master.pk_id = " . $stockid . "";

		return $this->query($qry);
	}

	function Getheaderinfofir()
	{
		$qry = "SELECT
	tbl_warehouse.wh_name,
	tbl_warehouse.stkid,
	tbl_warehouse.prov_id,
	stakeholder.lvl
FROM
	tbl_warehouse
LEFT JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid
WHERE
	wh_id = '" . $_SESSION['warehouse_id'] . "'";
		//        echo $qry;exit;
		return $this->query($qry);
	}

	function Getheaderinfosec($stkid)
	{
		$qry = "select report_logo,report_title3 from stakeholder where stkid='" . $stkid . "'";
		//        echo $qry;exit;
		return $this->query($qry);
	}

	function get_assign_approvalcode($id)
	{
		$qry = "SELECT
                        GROUP_CONCAT( assign_approval_to_user.approval_code_id ) AS approval_code_id,
                        GROUP_CONCAT( approval_code.approval_code ) AS approval_code,
                        GROUP_CONCAT( approval_code.process_status ) AS process_status,
                        GROUP_CONCAT( a.`name` ) AS document_name,
                        GROUP_CONCAT( b.`name` ) AS approver_designation,
                        GROUP_CONCAT( b.`pk_id` ) AS approver_desg_id,
                        GROUP_CONCAT( approver_configration.approve_from ) AS approve_from,
                        GROUP_CONCAT( approver_configration.approve_to ) AS approve_to,
                        GROUP_CONCAT( approval_code.final ) AS final_status
                FROM
                        assign_approval_to_user
                        INNER JOIN approval_code ON assign_approval_to_user.approval_code_id = approval_code.pk_id
                        INNER JOIN list_detail AS a ON approval_code.document_id = a.pk_id
                        INNER JOIN list_detail AS b ON approval_code.approver_designation = b.pk_id
                        INNER JOIN approver_configration ON approval_code.pk_id = approver_configration.pk_id 
                WHERE
                        assign_approval_to_user.user_id = '" . $_SESSION['id'] . "' 
                        AND approval_code.processid = '$id'";
		//        echo $qry;exit;
		return $this->query($qry);
	}


	function GetStocksGwisList($userid, $wh_id, $type, $stockid)
	{

		$strSql = "SELECT
                            gwis_master.tran_date,
                            gwis_detail.quantity,
                            stock_batch.batch_no,
                            stock_batch.production_date,
                            stock_batch.batch_expiry,
                            stock_batch.currency,
                            cu.`name` AS currency_name,
                            itminfo_tab.itm_name,
                            itminfo_tab.itmrec_id,
                            itminfo_tab.itm_des,
                            stakeholder_item.quantity_per_pack,
                            IFNULL( stakeholder_item.quantity_per_pack, itminfo_tab.qty_carton ) AS qty_carton,
                            tbl_warehouse.wh_id,
                            CONCAT( tbl_warehouse.wh_name, ' (', IFNULL( stakeholder.stkname, '' ), ')' ) AS wh_name,
                            tbl_itemunits.UnitType,
                            gwis_master.pk_id AS pkmasterid,
                            gwis_master.tran_no,
                            gwis_master.tran_ref,
                            gwis_master.received_remarks,
                            gwis_detail.pk_id AS pkdetailid,
                            ww.wh_name AS wh_from,
                            wt.wh_name AS wh_to,
                            ws.wh_name AS wh_from_supplier,
                            pt.`name` AS product_type,
                            gwis_detail.no_of_cartons,
                            gwis_detail.value_of_product,
                            gwis_detail.transport_req_remarks,
                            gwis_detail.temperature_requirement,
                            vt.`name` AS vehicle_type,
                            put.`name` AS unit_type,
                            gwis_detail.no_of_vehicle,
                            gwis_detail.date_vehicle_req,
                            product_method_type.method_type,
                            gwis_detail.field3,
                            gwis_detail.field2,
                            itminfo_tab.cold_chain_temp,
                            gwis_detail.pi_quantity,
                            gwis_detail.ti_quantity,
                            gwis_detail.dc_date,
                            gwis_detail.invoice,
                            gwis_master.stk_id,
                            gwis_master.inspection_date,
                            gwis_master.delivery_location,
                            gwis_master.po_cmu_date,
                            gwis_master.date_of_receiving,
                            gwis_master.air_bill_no,
                            gwis_master.shipment_no,
                            gwis_master.origin_of_country,
                            gwis_master.vehicle_type_and_plate,
                            gwis_master.consignment_weight,
                            gwis_master.po_gf_date,
                            gwis_master.parent_id,
                            gwis_master.process_status,
                            po_gf.number AS po_gf_no,
                            po_cmu.number AS po_cmu_no,
                            gwis_detail.pi_type,
                            gwis_detail.sbtr_dc_rec,
                            gwis_detail.dc_no,
                            gwis_detail.vehicle_reg,
                            gwis_detail.driver_contract,
                            gwis_detail.driver_name,
                            gwis_detail.dc_quantity,
                            gwis_detail.actual_rec_qty,
                            users.username,
                            users.designation,
                            product_strength.strength,
                            pitype.`name` AS pi_type,
                            manf.stkname AS manufacturer_name,
                            stk.stkname AS stakeholder_name,
                            gwis_detail.pi_comment,
                            stock_batch.unit_price,
                            stock_batch.conversion_rate,
                            gwis_master.file,
                            gwis_detail.shipment_temprature,
                            itminfo_tab.unit
                    FROM
                            gwis_master
                            LEFT JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                            LEFT JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                            LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
                            LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                            LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
                            LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                            LEFT JOIN tbl_warehouse AS wt ON gwis_master.wh_id_to = wt.wh_id
                            LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                            LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
                            LEFT JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid
                            LEFT JOIN list_detail AS pt ON gwis_detail.type_of_vehicle = pt.pk_id
                            LEFT JOIN list_detail AS vt ON gwis_detail.product_type_id = vt.pk_id
                            LEFT JOIN list_detail AS put ON gwis_detail.field7 = put.pk_id
                            LEFT JOIN list_detail AS pitype ON gwis_detail.pi_type = pitype.pk_id
                            LEFT JOIN list_detail AS cu ON stock_batch.currency = cu.pk_id
                            LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
                            LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                            LEFT JOIN po_info AS po_cmu ON gwis_master.po_cmu_no = po_cmu.pk_id
                            LEFT JOIN po_info AS po_gf ON gwis_master.po_gf_no = po_gf.pk_id 
                            LEFT JOIN users ON gwis_master.created_by = users.pk_id
                            LEFT JOIN stakeholder AS manf ON stock_batch.manufacturer = manf.stkid
                            LEFT JOIN stakeholder AS stk ON gwis_master.stk_id = stk.stkid 
                    WHERE
					gwis_detail.temp = 0 AND
					gwis_master.temp = 0 AND
					gwis_master.wh_id_from = '" . $wh_id . "' AND
					gwis_master.created_by = " . $userid . "  
					
                                        AND gwis_master.pk_id = $stockid
				ORDER BY
					itminfo_tab.frmindex ASC";
		//        echo $strSql;exit;
		return $this->query($strSql);
	}

	function GetStocksTacList($userid, $wh_id, $type, $stockid)
	{

		$strSql = "SELECT
                            gwis_master.tran_date,
                            gwis_detail.quantity,
                            stock_batch.batch_no,
                            stock_batch.production_date,
                            stock_batch.batch_expiry,
                            itminfo_tab.itm_name,
                            itminfo_tab.itmrec_id,
                            itminfo_tab.itm_des,
                            stakeholder_item.quantity_per_pack,
                            IFNULL( stakeholder_item.quantity_per_pack, itminfo_tab.qty_carton ) AS qty_carton,
                            tbl_warehouse.wh_id,
                            CONCAT( tbl_warehouse.wh_name, ' (', IFNULL( stakeholder.stkname, '' ), ')' ) AS wh_name,
                            tbl_itemunits.UnitType,
                            gwis_master.pk_id AS pkmasterid,
                            gwis_master.tran_no,
                            gwis_master.tran_ref,
                            gwis_master.received_remarks,
                            gwis_detail.pk_id AS pkdetailid,
                            ww.wh_name AS wh_from,
                            wt.wh_name AS wh_to,
                            ws.wh_name AS wh_from_supplier,
                            pt.`name` AS product_type,
                            gwis_detail.no_of_cartons,
                            gwis_detail.value_of_product,
                            gwis_detail.transport_req_remarks,
                            gwis_detail.temperature_requirement,
                            vt.`name` AS vehicle_type,
                            gwis_detail.no_of_vehicle,
                            gwis_detail.date_vehicle_req,
                            product_method_type.method_type,
                            gwis_detail.field3,
                            itminfo_tab.cold_chain_temp,
                            gwis_detail.pi_quantity,
                            gwis_detail.ti_quantity,
                            gwis_detail.dc_date,
                            gwis_detail.invoice,
                            gwis_master.stk_id,
                            gwis_master.inspection_date,
                            gwis_master.delivery_location,
                            gwis_master.po_cmu_date,
                            gwis_master.date_of_receiving,
                            gwis_master.air_bill_no,
                            gwis_master.shipment_no,
                            gwis_master.origin_of_country,
                            gwis_master.vehicle_type_and_plate,
                            gwis_master.consignment_weight,
                            gwis_master.po_gf_date,
                            po_gf.number AS po_gf_no,
                            po_cmu.number AS po_cmu_no,
                            gwis_detail.pi_type,
                            gwis_detail.sbtr_dc_rec,
                            gwis_detail.dc_no,
                            gwis_detail.vehicle_reg,
                            gwis_detail.driver_contract,
                            gwis_detail.driver_name,
                            gwis_detail.dc_quantity,
                            gwis_detail.actual_rec_qty,
                            users.username,
                            users.designation
                    FROM
                            gwis_master
                            LEFT JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                            LEFT JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                            LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
                            LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                            LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
                            LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                            LEFT JOIN tbl_warehouse AS wt ON gwis_master.wh_id_to = wt.wh_id
                            LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                            LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
                            LEFT JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid
                            LEFT JOIN list_detail AS pt ON gwis_detail.type_of_vehicle = pt.pk_id
                            LEFT JOIN list_detail AS vt ON gwis_detail.product_type_id = vt.pk_id
                            LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
                            LEFT JOIN po_info AS po_cmu ON gwis_master.po_cmu_no = po_cmu.pk_id
                            LEFT JOIN po_info AS po_gf ON gwis_master.po_gf_no = po_gf.pk_id
                            LEFT JOIN users ON gwis_master.created_by = users.pk_id
                    WHERE
					gwis_detail.temp = 0 AND
					gwis_master.temp = 0 AND
					gwis_master.wh_id_from = '" . $wh_id . "' AND
					gwis_master.created_by = " . $userid . "  
					
                                        AND gwis_master.pk_id = $stockid
				ORDER BY
					itminfo_tab.frmindex ASC";
		//        echo $strSql;exit;
		return $this->query($strSql);
	}

	function GetStocksReceiveList($userid, $wh_id, $type, $stockid)
	{

		/*#gwis_detail.temp = 0 AND
					#gwis_master.temp = 0 AND
					#gwis_master.wh_id_from = '" . $wh_id . "' AND
					#gwis_master.created_by = " . $userid . "  */

		$strSql = "SELECT DISTINCT
                            gwis_master.tran_date,
                            gwis_detail.quantity,
                            stock_batch.batch_no,
                            stock_batch.production_date,
                            stock_batch.batch_expiry,
                            itminfo_tab.itm_name,
                            itminfo_tab.itmrec_id,
                            itminfo_tab.itm_des,
                            stakeholder_item.quantity_per_pack,
                            IFNULL( stakeholder_item.quantity_per_pack, itminfo_tab.qty_carton ) AS qty_carton,
                            tbl_warehouse.wh_id,
                            CONCAT( tbl_warehouse.wh_name, ' (', IFNULL( stakeholder.stkname, '' ), ')' ) AS wh_name,
                            tbl_itemunits.UnitType,
                            gwis_master.pk_id AS pkmasterid,
                            gwis_master.tran_no,
                            gwis_master.tran_ref,
                            gwis_master.received_remarks,
                            gwis_detail.pk_id AS pkdetailid,
                            ww.wh_name AS wh_from,
                            wt.wh_name AS wh_to,
                            ws.wh_name AS wh_from_supplier,
                            pt.`name` AS product_type,
                            gwis_detail.no_of_cartons,
                            gwis_detail.value_of_product,
                            gwis_detail.transport_req_remarks,
                            gwis_detail.temperature_requirement,
                            vt.`name` AS vehicle_type,
                            gwis_detail.no_of_vehicle,
                            gwis_detail.date_vehicle_req,
                            product_method_type.method_type,
                            gwis_detail.field3,
                            itminfo_tab.cold_chain_temp,
                            gwis_detail.pi_quantity,
                            gwis_detail.ti_quantity,
                            gwis_detail.dc_date,
                            gwis_detail.invoice,
                            gwis_master.stk_id,
                            gwis_master.inspection_date,
                            gwis_master.delivery_location,
                            gwis_master.po_cmu_date,
                            gwis_master.date_of_receiving,
                            gwis_master.air_bill_no,
                            gwis_master.shipment_no,
                            gwis_master.origin_of_country,
                            gwis_master.vehicle_type_and_plate,
                            gwis_master.consignment_weight,
                            gwis_master.po_gf_date,
                            po_gf.number AS po_gf_no,
                            po_cmu.number AS po_cmu_no,
                            gwis_detail.pi_type,
                            gwis_detail.sbtr_dc_rec,
                            gwis_detail.dc_no,
                            gwis_detail.vehicle_reg,
                            gwis_detail.driver_contract,
                            gwis_detail.driver_name,
                            gwis_detail.dc_quantity,
                            gwis_detail.actual_rec_qty,
                            stock_batch.conversion_rate,
                            stock_batch.unit_price,
                            gwis_detail.grn_quantity,
                            gwis_detail.giv_quantity,
                            stock_batch.currency,
                            users.username,
                            users.designation
                    FROM
                            gwis_master
                            LEFT JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                            LEFT JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                            LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
                            LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                            LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
                            LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                            LEFT JOIN tbl_warehouse AS wt ON gwis_master.wh_id_to = wt.wh_id
                            LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                            LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
                            LEFT JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid
                            LEFT JOIN list_detail AS pt ON gwis_detail.type_of_vehicle = pt.pk_id
                            LEFT JOIN list_detail AS vt ON gwis_detail.product_type_id = vt.pk_id
                            LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
                            LEFT JOIN po_info AS po_cmu ON gwis_master.po_cmu_no = po_cmu.pk_id
                            LEFT JOIN po_info AS po_gf ON gwis_master.po_gf_no = po_gf.pk_id 
                            LEFT JOIN users ON gwis_master.created_by = users.pk_id
                    WHERE
					
					gwis_master.pk_id = $stockid
				ORDER BY
					itminfo_tab.frmindex ASC";
		//echo $strSql;exit;
		return $this->query($strSql);
	}

	function GetStocksAdjList($userid, $wh_id, $type, $stockid)
	{

		$strSql = "SELECT
                            gwis_master.tran_date,
                            gwis_detail.quantity,
                            stock_batch.batch_no,
                            stock_batch.production_date,
                            stock_batch.batch_expiry,
                            itminfo_tab.itm_name,
                            itminfo_tab.itmrec_id,
                            itminfo_tab.itm_des,
                            stakeholder_item.quantity_per_pack,
                            IFNULL( stakeholder_item.quantity_per_pack, itminfo_tab.qty_carton ) AS qty_carton,
                            tbl_warehouse.wh_id,
                            CONCAT( tbl_warehouse.wh_name, ' (', IFNULL( stakeholder.stkname, '' ), ')' ) AS wh_name,
                            tbl_itemunits.UnitType,
                            gwis_master.pk_id AS pkmasterid,
                            gwis_master.tran_no,
                            gwis_master.tran_ref,
                            gwis_master.received_remarks,
                            gwis_detail.pk_id AS pkdetailid,
                            ww.wh_name AS wh_from,
                            wt.wh_name AS wh_to,
                            ws.wh_name AS wh_from_supplier,
                            pt.`name` AS product_type,
                            gwis_detail.no_of_cartons,
                            gwis_detail.value_of_product,
                            gwis_detail.transport_req_remarks,
                            gwis_detail.temperature_requirement,
                            vt.`name` AS vehicle_type,
                            gwis_detail.no_of_vehicle,
                            gwis_detail.date_vehicle_req,
                            product_method_type.method_type,
                            gwis_detail.field3,
                            itminfo_tab.cold_chain_temp,
                            gwis_detail.pi_quantity,
                            gwis_detail.ti_quantity,
                            gwis_detail.dc_date,
                            gwis_detail.invoice,
                            gwis_master.stk_id,
                            gwis_master.inspection_date,
                            gwis_master.delivery_location,
                            gwis_master.po_cmu_date,
                            gwis_master.date_of_receiving,
                            gwis_master.air_bill_no,
                            gwis_master.shipment_no,
                            gwis_master.origin_of_country,
                            gwis_master.vehicle_type_and_plate,
                            gwis_master.consignment_weight,
                            gwis_master.po_gf_date,
                            po_gf.number AS po_gf_no,
                            po_cmu.number AS po_cmu_no,
                            gwis_detail.pi_type,
                            gwis_detail.sbtr_dc_rec,
                            gwis_detail.dc_no,
                            gwis_detail.vehicle_reg,
                            gwis_detail.driver_contract,
                            gwis_detail.driver_name,
                            gwis_detail.dc_quantity,
                            gwis_detail.actual_rec_qty 
                    FROM
                            gwis_master
                            LEFT JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                            LEFT JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                            LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
                            LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                            LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
                            LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                            LEFT JOIN tbl_warehouse AS wt ON gwis_master.wh_id_to = wt.wh_id
                            LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                            LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
                            LEFT JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid
                            LEFT JOIN list_detail AS pt ON gwis_detail.type_of_vehicle = pt.pk_id
                            LEFT JOIN list_detail AS vt ON gwis_detail.product_type_id = vt.pk_id
                            LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
                            LEFT JOIN po_info AS po_cmu ON gwis_master.po_cmu_no = po_cmu.pk_id
                            LEFT JOIN po_info AS po_gf ON gwis_master.po_gf_no = po_gf.pk_id 
                    WHERE
					gwis_detail.temp = 0 AND
					gwis_master.temp = 0 AND
					gwis_master.wh_id_from = '" . $wh_id . "' AND
					gwis_master.created_by = " . $userid . "  
					
                                        AND gwis_master.pk_id = $stockid
				ORDER BY
					itminfo_tab.frmindex ASC";
		//        echo $strSql;exit;
		return $this->query($strSql);
	}

	function GetStocksIssueList($userid, $wh_id, $type, $stockid)
	{
		//select query 
		//gets
		//transaction date
		//qty
		//batch num
		//production date
		//batch expiry
		//item name
		//carton qty
		//warehouse id
		//warehouse name
		//unit type
		//pk stock id
		//warehouse name
		//transaction num
		//transaction  ref
		//received remark
		//issued by
		//pk detail id
		$strSql = "SELECT DISTINCT
                            gwis_master.tran_date,
                            gwis_detail.quantity,
                            stock_batch.batch_no,
                            stock_batch.production_date,
                            stock_batch.batch_expiry AS stock_batch_expiry,
                            itminfo_tab.itm_name,
                            itminfo_tab.itmrec_id,
                            itminfo_tab.itm_des,
                            itminfo_tab.pack_size,
                            itminfo_tab.carton_size,
                            stakeholder_item.quantity_per_pack,
                            IFNULL( stakeholder_item.quantity_per_pack, itminfo_tab.qty_carton ) AS qty_carton,
                            tbl_warehouse.wh_id,
                            CONCAT( tbl_warehouse.wh_name, ' (', IFNULL( stakeholder.stkname, '' ), ')' ) AS wh_name,
                            tbl_itemunits.UnitType,
                            gwis_master.pk_id AS pkmasterid,
                            gwis_master.tran_no,
                            gwis_master.tran_ref,
                            gwis_master.received_remarks,
                            gwis_master.issue_to_info,
                            gwis_detail.pk_id AS pkdetailid,
                            ww.wh_name AS wh_from,
                            wt.wh_name AS wh_to,
                            ws.wh_name AS wh_from_supplier,
                            pt.`name` AS product_type,
                            gwis_detail.no_of_cartons,
                            gwis_detail.value_of_product,
                            gwis_detail.transport_req_remarks,
                            gwis_detail.temperature_requirement,
                            vt.`name` AS vehicle_type,
                            gwis_detail.no_of_vehicle,
                            gwis_detail.date_vehicle_req,
                            product_method_type.method_type,
                            gwis_detail.field3 AS batch_expiry,
                            itminfo_tab.cold_chain_temp,
                            gwis_detail.pi_quantity,
                            gwis_detail.ti_quantity,
                            gwis_detail.dc_date,
                            gwis_detail.invoice,
                            gwis_master.stk_id,
                            gwis_master.inspection_date,
                            gwis_master.delivery_location,
                            gwis_master.po_cmu_date,
                            gwis_master.date_of_receiving,
                            gwis_master.air_bill_no,
                            gwis_master.shipment_no,
                            gwis_master.origin_of_country,
                            gwis_master.vehicle_type_and_plate,
                            gwis_master.consignment_weight,
                            gwis_master.po_gf_date,
                            gwis_master.parent_id,
                            gwis_master.process_status,
                            po_gf.number AS po_gf_no,
                            po_cmu.number AS po_cmu_no,
                            gwis_detail.pi_type,
                            gwis_detail.sbtr_dc_rec,
                            gwis_detail.dc_no,
                            gwis_detail.vehicle_reg,
                            gwis_detail.driver_contract,
                            gwis_detail.driver_name,
                            gwis_detail.dc_quantity,
                            gwis_detail.actual_rec_qty,
                            stock_batch.conversion_rate,
                            stock_batch.unit_price,
                            gwis_detail.grn_quantity,
                            gwis_detail.giv_quantity,
                            stock_batch.currency,
                            gwis_detail.siv_tracking_no,
                            gwis_detail.siv_transportation_po,
                            gwis_detail.siv_no_of_cartons,
                            gwis_detail.siv_weight,
                            gwis_detail.siv_cnic,
                            gwis_detail.siv_contatc_number,
                            gwis_detail.siv_driver_name,
                            gwis_detail.field6,
                            gwis_detail.siv_mode_of_transport,
                            gwis_detail.siv_name_of_transporter,
                            gwis_detail.siv_vehicle_type,
                            gwis_detail.siv_vehicle_plate_no,
                            users.username,
                            users.designation,
                            gwis_detail.comments,
                            itminfo_tab.unit
                    FROM
                            gwis_master
                            LEFT JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                            LEFT JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                            LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
                            LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                            LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
                            LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                            LEFT JOIN tbl_warehouse AS wt ON gwis_master.wh_id_to = wt.wh_id
                            LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                            LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
                            LEFT JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid
                            LEFT JOIN list_detail AS pt ON gwis_detail.type_of_vehicle = pt.pk_id
                            LEFT JOIN list_detail AS vt ON gwis_detail.product_type_id = vt.pk_id
                            LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
                            LEFT JOIN po_info AS po_cmu ON gwis_master.po_cmu_no = po_cmu.pk_id
                            LEFT JOIN po_info AS po_gf ON gwis_master.po_gf_no = po_gf.pk_id 
                            LEFT JOIN users ON gwis_master.created_by = users.pk_id
                    WHERE
					gwis_detail.temp = 0 AND
					gwis_master.temp = 0 AND
					gwis_master.wh_id_from = '" . $wh_id . "' AND
					gwis_master.created_by = " . $userid . "  
					
                                        AND gwis_master.pk_id = $stockid
				ORDER BY
					itminfo_tab.frmindex ASC";
		//        echo $strSql;exit;
		return $this->query($strSql);
	}

	function GetUsercreatedID($process_id1, $parent_id1)
	{
		$strSql = "SELECT
                            users.username,
                            users.designation
                    FROM
                            gwis_master
                            LEFT JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
                            LEFT JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                            LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
                            LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                            LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
                            LEFT JOIN tbl_warehouse AS ww ON gwis_master.wh_id_from = ww.wh_id
                            LEFT JOIN tbl_warehouse AS wt ON gwis_master.wh_id_to = wt.wh_id
                            LEFT JOIN tbl_warehouse AS ws ON gwis_master.wh_id_from_supplier = ws.wh_id
                            LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
                            LEFT JOIN stakeholder ON tbl_warehouse.stkofficeid = stakeholder.stkid
                            LEFT JOIN list_detail AS pt ON gwis_detail.type_of_vehicle = pt.pk_id
                            LEFT JOIN list_detail AS vt ON gwis_detail.product_type_id = vt.pk_id
                            LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
                            LEFT JOIN po_info AS po_cmu ON gwis_master.po_cmu_no = po_cmu.pk_id
                            LEFT JOIN po_info AS po_gf ON gwis_master.po_gf_no = po_gf.pk_id 
                            LEFT JOIN users ON gwis_master.created_by = users.pk_id
                    WHERE
					gwis_master.pk_id = '" . $parent_id1 . "'
				ORDER BY
					itminfo_tab.frmindex ASC";
		//        echo $strSql;exit;
		return $this->query($strSql);
	}

	public function GetBatchDetailForEditIssue($masterid)
	{
		$strSql = "SELECT
                        stock_batch.batch_no,
                        stock_batch.batch_expiry,
                        stock_batch.item_id,
                        
                        stock_batch.unit_price,
                        stock_batch.production_date,
                        stock_batch.vvm_type,
                        gwis_detail.quantity,
                        gwis_detail.dc_quantity,
                        gwis_detail.pi_quantity,
                        gwis_detail.ti_quantity,
                        gwis_detail.pi_comment,
                        gwis_detail.ti_comment,
                        gwis_detail.comments,
                        stock_batch.funding_source,
                        stock_batch.manufacturer,
                        gwis_detail.delivery_challan_type,
                        gwis_detail.challan_type_detail,
                        gwis_detail.dc_no,
                        gwis_detail.dc_date,
                        gwis_detail.invoice,
                        gwis_detail.po_quantity,
                        gwis_detail.actual_rec_qty,
                        gwis_detail.vehicle_reg,
                        gwis_detail.driver_contract,
                        gwis_detail.driver_name,
                        gwis_detail.service_name,
                        gwis_detail.agency_name,
                        gwis_detail.consignment_no,
                        gwis_detail.builty,
                        gwis_master.wh_id_from_supplier,
                        stock_batch.currency,
                        stock_batch.conversion_rate,
                        gwis_master.wh_id_from,
                        gwis_master.tran_ref,
                        gwis_master.stk_id,
                        gwis_master.inspection_date,
                        gwis_master.delivery_location,
                        gwis_master.po_cmu_no,
                        gwis_master.po_cmu_date,
                        gwis_master.po_gf_no,
                        gwis_master.po_gf_date,
                        gwis_detail.sbtr_dc_rec,
                        gwis_master.date_of_receiving,
                        gwis_master.air_bill_no,
                        gwis_master.shipment_no,
                        gwis_master.origin_of_country,
                        gwis_master.vehicle_type_and_plate,
                        gwis_master.consignment_weight,
                        gwis_master.issue_to_info,
                        gwis_detail.pk_id,
                        gwis_detail.pi_type,
                        gwis_detail.fk_stock_id, 
                        gwis_detail.batch_id,
                        gwis_detail.siv_tracking_no,
                        gwis_detail.siv_transportation_po,
                        gwis_detail.siv_no_of_cartons,
                        gwis_detail.siv_weight,
                        gwis_detail.siv_cnic,
                        gwis_detail.siv_contatc_number,
                        gwis_detail.siv_driver_name,
                        gwis_detail.field6 AS pack_size,
                        gwis_detail.siv_mode_of_transport,
                        gwis_detail.siv_name_of_transporter,
                        gwis_detail.siv_vehicle_type,
                        gwis_detail.siv_vehicle_plate_no,
                        gwis_master.source_type,
                        gwis_master.tran_date,
                        gwis_master.received_remarks,
                        gwis_master.wh_id_to,
                        gwis_master.province_id,
                        itminfo_tab.pack_size,
                        itminfo_tab.unit
                FROM
                        gwis_detail
                        INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                        LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                WHERE
                            gwis_master.pk_id = '$masterid'";
		//query result
		//       echo $strSql;exit;

		return $this->query($strSql);
	}

	function Getdetail_distribution($userid, $wh_id, $type, $stockid, $process_status_nmbr_s3, $process_status_nmbr_s4, $stakeholder)
	{

		$createdby = '';
		//        if($_SESSION['id'] == '1')
		//        {
		//            $createdby = '';
		//        }
		//        else{
		//            $createdby = " AND gwis_master.created_by = '".$_SESSION['id']."'";
		//        }

		$stklimit = '';
		$join = '';
		//        $stkidarray = array();
		//        for ($i = 0; $i < $_SESSION['count']; $i++) {
		//            array_push($stkidarray, "'" . $_SESSION['stakeholder_id_'.$i]. "'");
		//        }
		//        $stkid = implode(', ', $stkidarray);
		$stkid = $this->get_user_stakeholders();

		if ($_SESSION['id'] == '1') {
			if (isset($stakeholder) && !empty($stakeholder)) {
				$stklimit = " AND gwis_master.stk_id IN (" . $stakeholder . ")";
			} else {
				$stklimit = '';
			}
			$join = '';
		} else {
			//New 
			if (isset($stakeholder) && !empty($stakeholder)) {
				$stklimit = " AND gwis_master.stk_id IN (" . $stakeholder . ")";
			} else {
				$stklimit = " AND gwis_master.stk_id IN (" . $stkid . ")";
			}
			//Old
			//            $stklimit = "AND stakeholder_item.stk_id IN (".$stkid.")";
			//            $join = " LEFT JOIN stakeholder ON gwis_master.stk_id = stakeholder.stkid
			//                    INNER JOIN stakeholder_item ON stakeholder_item.stk_id = stakeholder.stkid";
		}

		$wh_id = $_SESSION['warehouse_id'];

		$strSql = "SELECT
                            stock_batch.batch_id,
                            TIMESTAMPDIFF( MONTH, CURRENT_DATE (), stock_batch.batch_expiry ) AS expirymonths,
                            stock_batch.batch_expiry,
                            stock_batch.batch_no,
                            itminfo_tab.itm_name,
                            itminfo_tab.product_type,
                            stock_batch.Qty,
                            list_detail.`name` AS `storage`,
                            stakeholder.stkname AS stakeholder_name,
                            product_strength.strength,
                            stock_batch.unit_price,
                            stock_batch.conversion_rate
                    FROM
                            stock_batch
                            INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                            INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                            INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
                            LEFT JOIN list_detail ON gwis_detail.`storage` = list_detail.pk_id
                            LEFT JOIN stakeholder ON gwis_master.stk_id = stakeholder.stkid
                            LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                            LEFT JOIN users ON gwis_master.created_by = users.pk_id
                            $join
                    WHERE
                            gwis_master.status_id IN ( 3 ) 
							AND stock_batch.wh_id = $wh_id
                            AND gwis_master.process_status IN (9,12,99)
                            AND stock_batch.Qty > 0
                            $createdby
                            $stklimit
                    ORDER BY
                            expirymonths,product_type ASC";
		//in future check

		//        gwis_detail.temp = 0 AND
		//                gwis_master.temp = 0 AND
		//                gwis_master.wh_id_from = '" . $wh_id . "' AND
		//                gwis_master.created_by = " . $userid . "  
		//
		//                AND gwis_master.pk_id = $stockid
		//        ORDER BY
		//                itminfo_tab.frmindex ASC


		//        echo $strSql;exit;
		return $this->query($strSql);
	}

	//    SELECT
	//	stock_batch.batch_no, 
	//	stock_batch.Qty, 
	//	stock_batch.dtl, 
	//	stock_batch.dtl_result
	//FROM
	//	stock_batch
	//WHERE
	//	stock_batch.batch_id =

	function fetch_manufacturers()
	{
		/*$qry = "SELECT
		'Existing' group_id,
		product_manufacturer.pk_id AS `key`,
		product_manufacturer.manufacturer AS `value`
	FROM
		product_manufacturer
		INNER JOIN stock_batch ON stock_batch.manufacturer = product_manufacturer.manufacturer
	WHERE
		stock_batch.item_id = 9 UNION
	SELECT
		'New' group_id,
		pk_id AS `key`,
		manufacturer AS `value`
	FROM
		product_manufacturer";*/
		$qry = "SELECT
            pk_id as `key`, manufacturer as `value`
            FROM
            product_manufacturer";
		return $this->query($qry);
	}

	function stock_search_new($type_id)
	{
		$wh_id = $this->session->userdata('warehouse_id');

		$qry = "SELECT
        gwis_master.tran_date,
        gwis_master.tran_no,
        gwis_master.tran_ref,
        stock_batch.batch_no,
        stock_batch.batch_expiry,
        ABS(gwis_detail.quantity) as quantity,
        gwis_master.issuance_to,
        tbl_warehouse.wh_name,
        patients.full_name,
        patients.nic_no,
        gwis_detail.fk_stock_id,
        gwis_detail.pk_id,
        gwis_detail.batch_id,
        funding_sources.funding_source_name,
        CONCAT( itminfo_tab.itm_name, ' - ', product_generic_name.generic_name, ' - ', IFNULL(product_strength.strength,'') ) product_name 
        FROM
        gwis_master
        INNER JOIN gwis_detail ON gwis_master.pk_id = gwis_detail.fk_stock_id
        INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
        INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
	    INNER JOIN product_generic_name ON itminfo_tab.generic_name = product_generic_name.pk_id
	    LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
        LEFT JOIN tbl_warehouse ON gwis_master.wh_id_to = tbl_warehouse.wh_id
        LEFT JOIN patients ON gwis_master.wh_id_to = patients.pk_id
        LEFT JOIN funding_sources ON stock_batch.funding_source = funding_sources.pk_id
        WHERE
        gwis_master.tran_type_id = $type_id 
		AND gwis_master.temp = 0
		AND stock_batch.wh_id = $wh_id
        ORDER BY gwis_master.pk_id DESC";
		//	print_r($qry);exit;
		return $this->query($qry);
	}

	function auto_receive_voucher($master_id)
	{
		$qry = "INSERT INTO gwis_master (
            gwis_master.tran_date,
            gwis_master.tran_type_id,
            gwis_master.tran_ref,
            gwis_master.wh_id_from,
            gwis_master.wh_id_to,
            gwis_master.created_by,
            gwis_master.created_on,
            gwis_master.received_remarks,
            gwis_master.temp,
            gwis_master.linked_tr,
            gwis_master.issuance_to,
            gwis_master.mcc_year
        ) SELECT
        A.tran_date,
        1,
        A.tran_ref,
        A.wh_id_from,
        A.wh_id_to,
        A.created_by,
        A.created_on,
        A.received_remarks,
        0,
        $master_id,
        A.issuance_to,
        A.mcc_year
        FROM
            gwis_master A WHERE A.pk_id = $master_id AND A.tran_type_id = 2";

		$this->query($qry);
		$new_master_id = $this->insert_id();

		if (!empty($new_master_id)) {
			$qrydetail = "SELECT
            gwis_detail.fk_stock_id, 
            gwis_detail.batch_id, 
            gwis_detail.quantity, 
            gwis_detail.temp, 
            'TEMPBATCH' batch_number, 
            stock_batch.batch_expiry, 
            stock_batch.item_id,
            stock_batch.wh_id, 
            stock_batch.funding_source, 
            stock_batch.manufacturer, 
            stock_batch.production_date
        FROM
            gwis_detail
            INNER JOIN
            stock_batch
            ON 
                gwis_detail.batch_id = stock_batch.batch_id
        WHERE
            gwis_detail.fk_stock_id = $master_id";

			$res_detail = $this->query($qrydetail);

			if (!empty($res_detail)) {
				$data = $res_detail->result_array();

				foreach ($data as $row) {
					$this->obj_stock_batch->batch_no = $row['batch_no'];
					$this->obj_stock_batch->batch_expiry = $row['batch_expiry'];
					$this->obj_stock_batch->production_date = $row['production_date'];
					$this->obj_stock_batch->item_id = $row['item_id'];
					$this->obj_stock_batch->wh_id = $_SESSION['warehouse_id'];
					$this->obj_stock_batch->quantity = 0;
					$this->obj_stock_batch->funding_source = $row['funding_source'];
					$stock_batch_id = $this->obj_stock_batch->save();


					$this->obj_stock_detail->fk_stock_id = $new_master_id;
					$this->obj_stock_detail->batch_id = $stock_batch_id;
					$this->obj_stock_detail->quantity = ABS($row['quantity']);
					$this->obj_stock_detail->temp = 0;
					$this->obj_stock_detail->save();

					$this->obj_stock_batch->recalculate_batch_qty($stock_batch_id);
				}
			}
		}
	}
}
