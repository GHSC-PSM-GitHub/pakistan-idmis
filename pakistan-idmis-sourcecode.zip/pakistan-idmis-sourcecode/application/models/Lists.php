<?php
class Lists extends Base_model {

    protected static $table_name = "list_detail";
    private $conn;
    protected static $db_fields = array("master_id","name","description","order");
    public $pk_id;
    public $master_id;
    public $name;
    public $description;
    public $order;

    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all() {
        $qry = "SELECT
list_detail.pk_id,
list_detail.master_id,
list_detail.`name`,
list_detail.description,
list_detail.order,
list_master.`name` AS master_name  FROM " . static::$table_name; 
        $qry.="
 
INNER JOIN list_master ON list_detail.master_id = list_master.pk_id
ORDER BY
master_name ASC,
list_detail.`name` ASC
 ";
//        print_r($qry);exit;
        $result = $this->query($qry);
        return $result->result_array();
    }
    public function find_by_master($id) {
        $qry = "SELECT
list_detail.pk_id,
list_detail.master_id,
list_detail.`name`,
list_detail.description,
list_detail.order,
list_master.`name` AS master_name  FROM " . static::$table_name; 
        $qry.="
 
INNER JOIN list_master ON list_detail.master_id = list_master.pk_id
WHERE list_detail.master_id = '".$id."'
ORDER BY
master_name ASC,
list_detail.`name` ASC
 ";
//        print_r($qry);exit;
        $result = $this->query($qry);
        return $result->result_array();
    }

    public function find_by_id($id) {
        $qry = "SELECT * FROM " . static::$table_name; 
        $qry .= " WHERE pk_id=" . $id;
        return $this->query($qry);
    }

    public function get_list($id){
        $qry = "SELECT * FROM " . static::$table_name; 
        $qry .= " WHERE master_id=" . $id;
//        echo $qry;exit;
//        $result =  $this->query($qry);
//        if (!empty($result)) {
//            foreach ($result->result_object() as $row) {
//                $searched_list[]=$row;
//            }
//        }
//        return $searched_list;
        return $this->query($qry);
    }

    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if ($this->$field != '') {
                $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.
        return isset($this->pk_id) ? $this->update() : $this->create();
    }
    public function deactivate($id){
        $qry="UPDATE ". static::$table_name. " SET status=0 where pk_id=$id";
        $this->query($qry);
    }
    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create() {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    /**
     * update
     * @global type $this
     * @return type
     */
    public function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
//        print_r($sql);exit;
        $this->query2($sql);
        return true;
    }

}
