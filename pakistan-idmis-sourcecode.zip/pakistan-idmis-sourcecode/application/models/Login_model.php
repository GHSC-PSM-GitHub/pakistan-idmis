<?php
class Login_model extends CI_Model {

    public function edit_option_md5($action, $id, $table){
        $this->db->where('md5(id)',$id);
        $this->db->update($table,$action);
        return;
    }

    //-- check post email
    public function check_email($email){
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('email', $email); 
        $this->db->limit(1);
        $query = $this->db->get();
        if($query->num_rows() == 1) {
            return $query->result();
        } else {
            return false;
        }
    }

    //check valid user by id
    public function validate_id($id) {
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('md5(id)', $id); 
        $this->db->limit(1);
        $query = $this->db->get();
        if($query -> num_rows() == 1){                 
            return $query->result();
        }
        else{
            return false;
        }
    }

    //-- check valid user
    function validate_user($username, $password){
        $this->db->select('users.pk_id, users.stakeholder_id, users.username, users.designation, stakeholder.report_logo, stakeholder.landing_background, stakeholder.stkname, user_stk.stk_id AS ustkid, stakeholder_item.product_id, users.warehouse_id, users.province_id, users.role_id, users.email, users.district_id, assign_approval_to_user.approval_code_id');
        $this->db->from('users');
        $this->db->join('user_stk', 'users.pk_id = user_stk.user_id','left');
        $this->db->join('stakeholder_item', 'user_stk.stk_id = stakeholder_item.stk_id', 'left');
        $this->db->join('stakeholder', 'stakeholder.stkid = users.stakeholder_id', 'left');
        $this->db->join('assign_approval_to_user', 'users.pk_id = assign_approval_to_user.user_id', 'left');
        $this->db->where('login_id', $username); 
        $this->db->where('password', md5($this->input->post('password')));
        $this->db->where('is_active', '1');
        $result = $this->db->get()->result();   
        return $result;
    }
}
