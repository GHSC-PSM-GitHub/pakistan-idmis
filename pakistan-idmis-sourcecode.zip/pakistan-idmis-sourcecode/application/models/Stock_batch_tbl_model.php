<?php

/**
 * clsStockBatch
 * @package includes/class
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
class Stock_batch_tbl_model extends Base_model {

    //batch id
    public $batch_id;
    //batch num
    public $batch_no;
    //batch expiry
    public $batch_expiry;
    //item id
    public $item_id;
    //quantity
    public $Qty;
    //transaction ref
    public $TranRef;
    //batch qty
    public $BatchQty;
    //status
    public $status;
    //production date
    public $production_date;
    //vv type
    public $vvm_type;
    //unit price
    public $unit_price;
    //funding source
    public $funding_source;
    //warehouse id
    public $wh_id;
    //manufacturer
    public $manufacturer;
    public $manufacturer_name;
    public $dtl;
    
    public $phy_inspection;
    
    public $conversion_rate;
    
    public $currency;
    
    public $batch_totalprice;
    public $dtl_result;
    public $dtl_comment;
    public $dtl_remarks;
    public $dtl_received_date;
    public $dtl_status;  

    protected static $table_name = "stock_batch";
    protected static $db_fields = array('batch_no', 'batch_expiry', 'item_id', 'Qty', 'TranRef', 'BatchQty', 'status', 'production_date', 'vvm_type', 'unit_price', 'wh_id', 'funding_source', 'manufacturer','phy_inspection','dtl','dist_plan','currency','conversion_rate','batch_totalprice','dtl_result','dtl_comment','dtl_remarks','dtl_received_date','dtl_status','manufacturer_name');

    // Common Database Methods
    /**
     * find_all
     * @return type
     */
    public static
            function find_all() {
        return static::find_by_sql("SELECT * FROM " . static::$table_name);
    }

    /**
     * find_by_id
     * @param type $id
     * @return type
     */
    public static
            function find_by_id($id = 0) {
        $result_array = static::find_by_sql("SELECT * FROM " . static::$table_name . " WHERE batch_id={$id} LIMIT 1");
               return !empty($result_array) ? array_shift($result_array) : false;

    }
    public function find_by_batch_no($batch_no){
        $qry="SELECT
        stock_batch.batch_id,
        stock_batch.batch_no
        FROM
        stock_batch
        WHERE
        stock_batch.batch_no = '$batch_no'
        ";
//        print_r($qry);exit;
        $rsSql = mysql_query($qry) or die("Error: GetAllRunningBatches");
        if (mysql_num_rows($rsSql) > 0) {
            return $rsSql;
        } else {
            return FALSE;
        }
    }
    /**
     * search
     * @param type $item_id
     * @param type $batch_no
     * @param type $TranRef
     * @param type $status
     * @return boolean
     */
    public function search($item_id, $batch_no, $TranRef, $status) {
        switch ($status) {
            case 1:
                $status = 'Running';
                break;
            case 2:
                $status = 'Stacked';
                break;
            case 3:
                $status = 'Finished';
                break;
            default:
                break;
        }
        $sql = "SELECT
					stock_batch.batch_id,
					stock_batch.batch_no,
					stock_batch.batch_expiry,
					stock_batch.`status`,
					Sum(tbl_stock_detail.Qty) AS BatchQty,
					itminfo_tab.itm_name,
					itminfo_tab.generic_name,
					tbl_itemunits.UnitType,
					tbl_warehouse.wh_name AS funding_source,
                                        IFNULL(manu.stkname,'N/A') manufacturer,
                                        stakeholder_item.quantity_per_pack as qty_carton,
                                        stakeholder_item.carton_per_pallet,
                                        stock_batch.unit_price,
                                        stock_batch.dtl,
                                        stock_batch.phy_inspection
				FROM
					tbl_stock_detail
				INNER JOIN tbl_stock_master ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
				INNER JOIN stock_batch ON stock_batch.batch_id = tbl_stock_detail.BatchID
				INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
				LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
				INNER JOIN transaction_types ON tbl_stock_master.TranTypeID = transaction_types.trans_id
				LEFT JOIN tbl_warehouse ON stock_batch.funding_source = tbl_warehouse.wh_id
                                LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
                                LEFT JOIN stakeholder AS manu ON stakeholder_item.stkid = manu.stkid";

        if (!empty($item_id)) {
            $where[] = " stock_batch.item_id = " . $item_id;
        }
        if (!empty($batch_no)) {
            $where[] = " stock_batch.batch_no LIKE '%" . $batch_no . "%'";
        }
        if (!empty($TranRef)) {
            $where[] = " tbl_stock_master.TranRef LIKE '%" . $TranRef . "%'";
        }
        if ($status == 4) {
            $where[] = " stock_batch.`status` IN ('Running', 'Stacked')";
        } else {
            $where[] = " stock_batch.`status` = '" . $status . "'";
        }
        if (!empty($this->funding_source) && $this->funding_source != 'all') {
            $where[] = " stock_batch.funding_source = " . $this->funding_source . " ";
        }
        $where[] = " stock_batch.`wh_id` = " . $this->session->userdata('warehouse_id') . "";

        // Finished means 0 quantity, We don't need this check for Finished Qty
        if ($status != 'Finished') {
            $where[] = " stock_batch.Qty <> 0";
        }

        if (!empty($where)) {
            $sql .= " WHERE " . implode(" AND ", $where);
        }
        $sql .= " group by stock_batch.item_id, stock_batch.batch_id, stock_batch.batch_expiry, stock_batch.status ORDER BY
	itminfo_tab.itm_name ASC";
        //query result
        //echo $sql;exit
        $result = mysql_query($sql);
        if (mysql_num_rows($result) > 0) {
            return $result;
        } else {
            return false;
        }
    }

    /**
     * find_by_sql
     * @param type $sql
     * @return type
     */
    public static
            function find_by_sql($sql = "") {
        $result_set = mysql_query($sql);
        $object_array = array();
        while ($row = mysql_fetch_array($result_set)) {
            $object_array[] = static::instantiate($row);
        }
        return $object_array;
    }

    /**
     * find_by_item
     * @param type $item_id
     * @return type
     */
    public static
            function find_by_item($item_id) {
        //select query
        //gets
        //batch num
        //item name
        //item id
        //stacked qty
        //running qty
        //finished qty
        //stacked
        //finished
        $sql = "SELECT
			stock_batch.batch_no,
			itminfo_tab.itm_name,
			itminfo_tab.itm_id,
			itminfo_tab.itm_type,
			sum(CASE WHEN stock_batch.`status` = 'Stacked' THEN stock_batch.Qty ELSE 0 END) as StackedQty,
			sum(CASE WHEN stock_batch.`status` = 'Running' THEN stock_batch.Qty ELSE 0 END) as RunningQty,
			sum(CASE WHEN stock_batch.`status` = 'Finished' THEN stock_batch.Qty ELSE 0 END) as FinishedQty,
			sum(CASE WHEN stock_batch.`status` = 'Stacked' THEN	1 ELSE 0 END) stacked,
			sum(CASE WHEN stock_batch.`status` = 'Running' THEN 1 ELSE 0 END) running,
			sum(CASE WHEN stock_batch.`status` = 'Finished' THEN 1 ELSE 0 END) finished
		FROM
			stock_batch
		INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
		WHERE
			stock_batch.item_id = " . $item_id . " AND stock_batch.wh_id = " . $this->session->userdata('warehouse_id');
//query result
        $result_array = mysql_query($sql);

        $object_array = array();
        while ($row = mysql_fetch_object($result_array)) {
            $object_array[] = $row;
        }

        return !empty($object_array) ? array_shift($object_array) : false;
    }

    /**
     * count_all
     * @global type $database
     * @return type
     */
    public static
            function count_all() {
        global $database;
        $sql = "SELECT COUNT(*) FROM " . static::$table_name;
        //query result
        $result_set = $database->query($sql);
        $row = $database->fetch_array($result_set);
        return array_shift($row);
    }

    /**
     * instantiate
     * @param type $record
     * @return \self
     */
    private static
            function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * has_attribute
     * @param type $attribute
     * @return type
     */
    private
            function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * attributes
     * @return type
     */
    protected
            function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                if (isset($this->$field)&&($this->$field!='')) {
                    $attributes[$field] = $this->$field;
                }
            }
        }
        return $attributes;
    }

    /**
     * sanitized_attributes
     * @global type $database
     * @return type
     */
    function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }

        return $clean_attributes;
    }

    /**
     * save
     * @return type
     */
    public
            function save() {
        // A new record won't have an id yet.

        return isset($this->batch_id) ? $this->update() : $this->create();
    }

    /**
     * create
     * @global type $database
     * @return boolean
     */
    public
    function create() {


        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection

        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
//            echo $sql; 
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    /**
     * update
     * @global type $database
     * @return type
     */
    public function update() {

        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
//        print_r($attribute_pairs);exit;
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE batch_id='" . $this->escape_value($this->batch_id)."' ";
//        print_r($sql); exit;
        $this->query($sql);
//        print_r($this->affected_rows());exit;
        return  true ;
    }
    
     public function updatedtlstatus() {

        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
//        print_r($attribute_pairs);exit;
        $sql = "UPDATE " . static::$table_name . " SET dtl_status = '" . $this->escape_value($this->dtl_status)."' WHERE batch_id='" . $this->escape_value($this->batch_id)."' ";
//        print_r($sql); 
        $this->query($sql);
//        print_r($this->affected_rows());exit;
        return  true ;
    }

    /**
     * FindItemQtyByBatchId
     * @param type $wh_id
     * @param type $batch_id
     * @param type $item_id
     * @return boolean
     */
    public function FindItemQtyByBatchId($wh_id, $batch_id, $item_id) {
        //select query
        //gets
        //batch qty
        //warehouse name
        //item typ

        $strSql = "SELECT
			stock_batch.Qty,
			tbl_warehouse.wh_name,
			itminfo_tab.itm_type
			FROM
			stock_batch
			INNER JOIN tbl_warehouse ON stock_batch.wh_id = tbl_warehouse.wh_id
			INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
			WHERE
			stock_batch.wh_id = $wh_id AND
			stock_batch.batch_id = $batch_id AND
			stock_batch.item_id = $item_id";
        //query result
        $rsSql = mysql_query($strSql) or die("Error: FindItemQtyByBatchId");
        if (mysql_num_rows($rsSql) > 0) {
            return $rsSql;
        } else {
            return FALSE;
        }
    }

    /**
     * delete
     * @global type $database
     * @return type
     */
    public function delete() {
        global $database;
        // Don't forget your SQL syntax and good habits:
        // - DELETE FROM table WHERE condition LIMIT 1
        // - escape all values to prevent SQL injection
        // - use LIMIT 1
        $sql = "DELETE FROM " . static::$table_name;
        $sql .= " WHERE batch_id=" . $database->escape_value($this->batch_id);
        $sql .= " LIMIT 1";
        $database->query($sql);
        return ($database->affected_rows() == 1) ? true : false;

        // NB: After deleting, the instance of User still
        // exists, even though the database entry does not.
        // This can be useful, as in:
        // but, for example, we can't call $user->update()
        // after calling $user->delete().
    }

    /**
     * checkBatch
     * @return boolean
     */
    function checkBatch() {
        if ($this->session->userdata('warehouse_id') == 123) {
            $fundingSource = " AND stock_batch.funding_source = '" . $this->funding_source . "' ";
        } else {
            $fundingSource = '';
        }
        
        //if checking for another wh, else the whid from session
        $wh_id = $this->session->userdata('warehouse_id');
        if(!empty($this->check_in_wh_id)) $wh_id = $this->check_in_wh_id;
        
        //select query
        //gets
        //batch num
        //batch id
        $strSql = "SELECT
					stock_batch.batch_no,
					stock_batch.batch_id
				FROM
					stock_batch
				WHERE
					stock_batch.batch_no = '" . $this->batch_no . "'
					AND stock_batch.item_id = '" . $this->item_id . "'
					AND stock_batch.wh_id = '" . $wh_id . "'
					$fundingSource
				LIMIT 1";
//query result
        $result_obj = mysql_query($strSql);
        if (mysql_num_rows($result_obj) > 0) {
            $row = mysql_fetch_object($result_obj);
            $batchid = $row->batch_id;
            $this->updateQty($batchid);
            return $batchid;
        } else {
            return FALSE;
        }
    }

    /**
     * checkBatchQuantity
     * @param type $batch_id
     * @return type
     */
    function checkBatchQuantity($batch_id) {
        //select query
        //gets
        $strSql = "SELECT
		stock_batch.Qty
		FROM
		stock_batch
		WHERE
		stock_batch.batch_id = " . $batch_id . " LIMIT 1";

        $result_obj = mysql_query($strSql);
        if (mysql_num_rows($result_obj) > 0) {
            $row = mysql_fetch_object($result_obj);
            $qty = $row->Qty;
            return $qty;
        } else {
            return -1;
        }
    }

    /**
     * updateQty
     * @param type $id
     * @return boolean
     */
    function updateQty($id) {
        $strSql = "UPDATE " . static::$table_name . " SET Qty=Qty+" . $this->Qty;
        $strSql .= " WHERE batch_id='" . $id . "'";
        //query result
        $this->query($strSql);
//        print_r($this->affected_rows());exit;
        return  true ;
    }

    function update_getgiws_delete_Qty($id,$qty) {
        $strSql = " UPDATE stock_batch SET Qty = Qty-" . $qty . " WHERE batch_id='" . $id . "'";
        //query result
//        echo $strSql;exit;
        $this->query($strSql);
//        print_r($this->affected_rows());exit;
        return  true ;
    }
    
    /**
     * adjustQtyByWh
     * @param type $batch_id
     * @param type $wh_id
     * @return boolean
     */
    function adjustQtyByWh($batch_id, $wh_id) {
        $strSql = "SELECT AdjustQty($batch_id,$wh_id) from DUAL";
//        print_r($strSql);exit;
        $rsSql = mysql_query($strSql) or $this->insert_error_log($strSql, mysql_error(),$_SESSION['user_id'],__LINE__);
        //$this->insert_error_log($strSql, 'test');
        if (isset($rsSql) && mysql_num_rows($rsSql) > 0) {
            $row = mysql_fetch_array($rsSql);
            return $row[0];
        } else {
            return FALSE;
        }
    }

     function adjustQty_two($batch_id) {
        $strSql = "SELECT AdjustQty2($batch_id) from DUAL";
//        echo $strSql;
        $rsSql = mysql_query($strSql) or $this->insert_error_log($strSql, mysql_error(),$_SESSION['user_id'],__LINE__);
        //$this->insert_error_log($strSql, 'test2');
        if (isset($rsSql) && mysql_num_rows($rsSql) > 0) {
            $row = mysql_fetch_array($rsSql);
//            print_r($row);
            return $row[0];
        } else {
            return FALSE;
        }
    }
    /**
     * adjustQty
     * @param type $id
     * @param type $qty
     * @return boolean
     */
    function adjustQty($id, $qty) {
        $strSql = "UPDATE " . static::$table_name . " SET Qty=" . $qty;
        $strSql .= " WHERE batch_id='" . $id . "'";
        $rsSql = mysql_query($strSql) or die("Error adjustQty" . $rsSql);
        if (mysql_affected_rows()) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    /**
     * editBatchNo
     * @param type $detail_id
     * @param type $batch_no
     * @return boolean
     */
    function editBatchNo($detail_id, $batch_no) {
        $wh_id = $this->session->userdata('warehouse_id');
        $objStockDetail = new clsStockDetail();
        $QtyAndBatch = $objStockDetail->getQtyById($detail_id);
//        print_r($QtyAndBatch);exit;
        $this->funding_source=$QtyAndBatch['funding_source'];
        $this->manufacturer=$QtyAndBatch['manufacturer'];
        $this->unit_price=$QtyAndBatch['unit_price'];
        $this->phy_inspection=$QtyAndBatch['phy_inspection'];
        $this->batch_no = $batch_no;
        $this->item_id = $QtyAndBatch['item_id'];
        $this->Qty = $QtyAndBatch['Qty'];
        $batch_id = $this->checkBatch();

        if (!$batch_id) {
            if ($this->checkBatchQuantity($QtyAndBatch['BatchID']) <= 0) {
                return $this->updateName($QtyAndBatch['BatchID'], $batch_no);
            } else {
                $this->wh_id = $wh_id;
                $batchInfo = $this->GetBatchExpiry($QtyAndBatch['BatchID']);
                $this->batch_expiry = $batchInfo['date'];
                $new_batch_id = $this->create();
                $objStockDetail->updateDetail($QtyAndBatch['BatchID'], $new_batch_id, $detail_id);
                $this->adjustQtyByWh($QtyAndBatch['BatchID'], $wh_id);
            }
        } else {
            $objStockDetail->updateDetail($QtyAndBatch['BatchID'], $batch_id, $detail_id);
            $this->batch_id = $QtyAndBatch['BatchID'];
            $this->adjustQtyByWh($QtyAndBatch['BatchID'], $wh_id);

            // Check if Quantoty is Greater than 0 then delete it
            $batchInfo = $this->GetBatchExpiry($QtyAndBatch['BatchID']);
            if ($batchInfo['qty'] == 0) {
                return $this->delete();
            } else {
                return true;
            }
        }
    }

    /**
     * updateName
     * @param type $id
     * @param type $batch_no
     * @return boolean
     */
    function updateName($id, $batch_no) {
        $strSql = "UPDATE " . static::$table_name . " SET batch_no='" . $batch_no . "'";
        $strSql .= " WHERE batch_id='" . $id . "'";
        //query result
        $rsSql = mysql_query($strSql) or die("Error updateName");
        if (mysql_affected_rows()) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    /**
     * changeStatus
     * @param type $batch_id
     * @param type $status
     * @return boolean
     */
    function changeStatus($batch_id, $status) {
        $strSql = "UPDATE " . static::$table_name . " SET status='" . $status . "'";
        $strSql .= " WHERE batch_id=" . $batch_id;

        $rsSql = mysql_query($strSql) or die("Error changeStatus");
        if (mysql_affected_rows()) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    /**
     * changeWh
     * @param type $batch_id
     * @return boolean
     */
    function changeWh($batch_id) {
        $strSql = "UPDATE " . static::$table_name . " SET wh_id=0 ";
        $strSql .= " WHERE batch_id=" . $batch_id;

        $rsSql = mysql_query($strSql) or die("Error changeWh");
        if (mysql_affected_rows()) {
            return TRUE;
        } else {
            return FALSE;
        }
    }
    
    function update_gwis_stockadj($statusid) {
//         $attributes = $this->sanitized_attributes();
//        $attribute_pairs = array();
//        foreach ($attributes as $key => $value) {
//            $attribute_pairs[] = "{$key}='{$value}'";
//        }
        $sql = "UPDATE " . static::$table_name . " SET Qty = '" .$this->escape_value($this->Qty)."' WHERE batch_id = '" .$this->escape_value($this->batch_id)."'";
        
        $this->query2($sql);
        return true;
    }


    /**
     * GetAllRunningBatches
     * @param type $item
     * @return boolean
     */
    function GetAllRunningBatches($item) {
        $wh_id = $this->session->userdata('warehouse_id');
        if (!empty($this->funding_source)) {
            $fundingSource = " AND stock_batch.funding_source = '" . $this->funding_source . "' ";
        } else {
            $fundingSource = '';
        }
        //select query
        //gets
        $strSql = "SELECT
						stock_batch.batch_no,
						stock_batch.batch_id,
						stock_batch.batch_expiry,
						stock_batch.item_id,
						SUM(tbl_stock_detail.Qty) AS Qty
					FROM
						stock_batch
					INNER JOIN tbl_stock_detail ON stock_batch.batch_id = tbl_stock_detail.BatchID
					INNER JOIN tbl_stock_master ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
					WHERE
						stock_batch.Qty <> 0
					$fundingSource
					AND stock_batch.`status` = 'Running'
					AND stock_batch.item_id = $item
					AND stock_batch.wh_id = $wh_id
					AND tbl_stock_master.WHIDTo = $wh_id
					AND tbl_stock_detail.temp = 0
					GROUP BY
						stock_batch.batch_no";
//query result
        //echo $strSql;exit;
        $rsSql = mysql_query($strSql) or die("Error: GetAllRunningBatches");
        if (mysql_num_rows($rsSql) > 0) {
            return $rsSql;
        } else {
            return FALSE;
        }
    }

    /**
     * GetAllAdjustmentBatches
     * @param type $item
     * @return boolean
     */
    function GetAllAdjustmentBatches($item) {
        $wh_id = $this->session->userdata('warehouse_id');
        $strSql = "SELECT
						stock_batch.batch_no,
						stock_batch.batch_id,
						stock_batch.batch_expiry,
						stock_batch.item_id
					FROM
						stock_batch
					WHERE
						stock_batch.item_id = $item
					AND stock_batch.wh_id = $wh_id
					GROUP BY
						stock_batch.batch_no";

        $rsSql = mysql_query($strSql) or die("Error: GetAllRunningBatches");
        if (mysql_num_rows($rsSql) > 0) {
            return $rsSql;
        } else {
            return FALSE;
        }
    }

    /**
     * autoRunningLEFOBatch
     * @param type $product_id
     * @param type $wh_id
     * @return boolean
     */
    function autoRunningLEFOBatch($product_id, $wh_id) {
        $expiry_date = $this->IsBatchExists($product_id, $wh_id);
        if ($expiry_date != false) {

            // Make stacked all the batches excluding the batches that user set to running
            $strSql = "UPDATE stock_batch
						SET STATUS = 'Stacked'
						WHERE
							item_id = $product_id
						AND wh_id = $wh_id
						AND stock_batch.Qty > 0
						AND batch_id NOT IN (
							SELECT
								*
							FROM
								(
									SELECT
										stock_batch.batch_id
									FROM
										stock_batch
									WHERE
										stock_batch.`status` = 'Running'
									AND stock_batch.wh_id = $wh_id
									AND stock_batch.item_id = $product_id
									UNION
										SELECT
											tbl_stock_detail.BatchID
										FROM
											tbl_stock_detail
										WHERE
											tbl_stock_detail.temp = 1
								) A
						)";
            $rsSql = mysql_query($strSql) or die("Error: autoStackedAllBatches".$strSql);

            // Make Running near to expiry batch
            $strSql = "UPDATE stock_batch
					SET `status` = 'Running'
					WHERE
						item_id = $product_id
					AND wh_id = $wh_id
					AND batch_expiry = '$expiry_date'
					AND stock_batch.Qty > 0
					AND batch_id NOT IN (
						SELECT
							*
						FROM
							(
								SELECT
									stock_batch.batch_id
								FROM
									stock_batch
								WHERE
									stock_batch.`status` = 'Running'
								AND stock_batch.wh_id = $wh_id
								AND stock_batch.item_id = $product_id
								UNION
									SELECT
										tbl_stock_detail.BatchID
									FROM
										tbl_stock_detail
									WHERE
										tbl_stock_detail.temp = 1
							) A
					)
					LIMIT 1";
            $rsSql = mysql_query($strSql) or die("Error: autoRunningLEFOBatch");
            if ($rsSql) {
                return TRUE;
            } else {
                return FALSE;
            }
        } else {
            return FALSE;
        }
    }

    /**
     * IsBatchExists
     * @param type $product_id
     * @param type $wh_id
     * @return boolean
     */
    function IsBatchExists($product_id, $wh_id) {
        $strSql = "SELECT
		MIN(batch_expiry) AS MinDate
		FROM
		stock_batch
		WHERE
		item_id = $product_id
		AND wh_id = $wh_id
		AND Qty <> 0 AND batch_id Not IN(
                SELECT
                tbl_stock_detail.BatchID
                FROM
                tbl_stock_detail
                WHERE
                tbl_stock_detail.temp = 1) LIMIT 1";
        $rsSql = mysql_query($strSql) or die("Error: IsBatchExists");
        if (!empty($rsSql) && mysql_num_rows($rsSql) > 0) {
            $row = mysql_fetch_object($rsSql);
            return $row->MinDate;
        } else {
            return FALSE;
        }
    }

    /**
     * GetBatchExpiry
     * @param type $id
     * @return boolean
     */
    function GetBatchExpiry($id) {
        $strSql = "SELECT
						stock_batch.batch_expiry,
						itminfo_tab.itm_category,
						SUM(tbl_stock_detail.Qty) AS Qty
					FROM
						stock_batch
					INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
					INNER JOIN tbl_stock_detail ON stock_batch.batch_id = tbl_stock_detail.BatchID
					INNER JOIN tbl_stock_master ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
					WHERE
						stock_batch.batch_id = $id";

        $rsSql = mysql_query($strSql) or die("Error: GetBatchExpiry");
        if (mysql_num_rows($rsSql) > 0) {
            $row = mysql_fetch_object($rsSql);
            $data = array(
                'date' => $row->batch_expiry,
                'qty' => $row->Qty,
                'cat' => $row->itm_category
            );
            return $data;
        } else {
            return FALSE;
        }
    }

    /**
     * editBatchExpiry
     * @param type $id
     * @param type $date
     * @return boolean
     */
    function editBatchExpiry($id, $date) {
        $strSql = "UPDATE " . static::$table_name . " SET batch_expiry='" . $date . "'";
        $strSql .= " WHERE batch_id='" . $id . "'";
        $rsSql = mysql_query($strSql) or die("Error editBatchExpiry");
        if (mysql_affected_rows()) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    public function UpdateBatchManufacturer($nbatchId, $Manufacturer) {
        $strSql = "UPDATE " . static::$table_name . " SET manufacturer = $Manufacturer WHERE batch_id = $nbatchId";
        mysql_query($strSql) or die("Error: UpdateBatchManufacturer");
        return true;
    }
    
    
    public function insert_error_log($qry, $err_text,$user_id,$line) {
        $strSql = " INSERT INTO errors_log SET file='clsStockBatch' , qry ='".$qry."' , err_text = '".$err_text."' , user_id ='".$user_id."', line='".$line."' ; ";
        mysql_query($strSql) ;
        return true;
    }
    
    function get_product_batches($item,$wh_id=0,$product_category,$process_status_nmbr,$stk_id,$temp_id=0) {
		$stk_id = $this->get_user_stakeholders();
//        $strSql = "SELECT
//	stock_batch.batch_no,
//	stock_batch.batch_id,
//	stock_batch.batch_expiry,
//	stock_batch.item_id,
//	SUM(tbl_stock_detail.Qty) AS Qty
//        FROM
//                stock_batch
//        INNER JOIN tbl_stock_detail ON stock_batch.batch_id = tbl_stock_detail.BatchID
//        INNER JOIN tbl_stock_master ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
//        WHERE
//                stock_batch.Qty > 0 
//        AND stock_batch.item_id = $item
//        AND stock_batch.wh_id = $wh_id
//        AND tbl_stock_master.WHIDTo = $wh_id
//        AND tbl_stock_detail.temp = 0
//        GROUP BY
//	stock_batch.batch_no";
        $orderby = '';
        if($product_category == '36')
        {
//            $orderby = 'ORDER BY
//                            stock_batch.batch_expiry ASC
//                        LIMIT 1';
            $orderby = 'ORDER BY
                            stock_batch.batch_expiry ASC
                        ';
        }
        else{
//            $orderby = 'ORDER BY
//                            tbl_stock_detail.BatchID ASC
//                        LIMIT 1';
            $orderby = 'ORDER BY
                            gwis_detail.batch_id ASC
                        ';
        }
        $createdby = '';
        if($_SESSION['id'] == '1')
        {
            $createdby = '';
        }
        else{
//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
        }

		$wh_id = $_SESSION['warehouse_id'];

        
        $strSql = "SELECT
            stock_batch.batch_no, 
            stock_batch.batch_id, 
            stock_batch.batch_expiry, 
            stock_batch.item_id, 
            SUM(gwis_detail.quantity) AS Qty, 
            gwis_detail.actual_rec_qty, 
            gwis_master.wh_id_from_supplier,
            gwis_master.wh_id_from, 
            gwis_detail.field1, 
            gwis_detail.field2, 
            gwis_detail.field3, 
            gwis_detail.field4, 
            gwis_detail.field5, 
            gwis_detail.field6, 
            gwis_detail.field7, 
            gwis_detail.field8, 
            gwis_detail.field9, 
            gwis_detail.field10, 
            gwis_detail.po_quantity, 
            gwis_detail.grn_quantity,
            gwis_detail.giv_quantity,
            gwis_detail.driver_contract, 
            gwis_detail.driver_name, 
            gwis_detail.vehicle_reg, 
            gwis_detail.dc_no, 
            gwis_detail.dc_date, 
            gwis_detail.invoice, 
            gwis_detail.challan_type_detail, 
            gwis_detail.delivery_challan_type, 
            gwis_detail.ti_comment, 
            gwis_detail.ti_quantity, 
            gwis_detail.pi_comment, 
            gwis_detail.pi_quantity, 
            gwis_detail.dc_quantity,
            gwis_master.stk_id,
            gwis_master.inspection_date,
            gwis_master.delivery_location,
            gwis_master.po_cmu_no,
            gwis_master.po_cmu_date,
            gwis_master.po_gf_no,
            gwis_master.po_gf_date,
            gwis_master.date_of_receiving,
            gwis_master.air_bill_no,
            gwis_master.shipment_no,
            gwis_master.origin_of_country,
            gwis_master.vehicle_type_and_plate,
            gwis_master.consignment_weight
        FROM
                stock_batch
                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
        WHERE
                stock_batch.Qty > 0 
        AND stock_batch.item_id = '$item'
        AND gwis_master.stk_id IN ($stk_id)
        AND gwis_detail.temp = '$temp_id'
        AND gwis_master.process_status IN ($process_status_nmbr,99)
        AND gwis_master.status_id IN (3,13)
        AND gwis_detail.electronic_approval =1
        AND stock_batch.status = 'Running'
		AND stock_batch.wh_id = $wh_id
        $createdby
        GROUP BY
            stock_batch.batch_id 
        $orderby";
      // print_r($strSql);exit;
        return $this->query($strSql);
    }
    
    function get_product_batches_adj($item,$wh_id=0,$product_category,$process_status_nmbr,$stk_id) {
//        $strSql = "SELECT
//	stock_batch.batch_no,
//	stock_batch.batch_id,
//	stock_batch.batch_expiry,
//	stock_batch.item_id,
//	SUM(tbl_stock_detail.Qty) AS Qty
//        FROM
//                stock_batch
//        INNER JOIN tbl_stock_detail ON stock_batch.batch_id = tbl_stock_detail.BatchID
//        INNER JOIN tbl_stock_master ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
//        WHERE
//                stock_batch.Qty > 0 
//        AND stock_batch.item_id = $item
//        AND stock_batch.wh_id = $wh_id
//        AND tbl_stock_master.WHIDTo = $wh_id
//        AND tbl_stock_detail.temp = 0
//        GROUP BY
//	stock_batch.batch_no";
        $orderby = '';
        if($product_category == '36')
        {
            $orderby = 'ORDER BY
                            stock_batch.batch_expiry ASC
                        ';
        }
        else{
            $orderby = 'ORDER BY
                            gwis_detail.batch_id ASC
                        ';
        }
        $createdby = '';
        if($_SESSION['id'] == '1')
        {
            $createdby = '';
        }
        else{
//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
        }
        
        $strSql = "SELECT
            stock_batch.batch_no, 
            stock_batch.batch_id, 
            stock_batch.batch_expiry, 
            stock_batch.item_id, 
            SUM(gwis_detail.quantity) AS Qty, 
            gwis_detail.actual_rec_qty, 
            gwis_master.wh_id_from_supplier,
            gwis_master.wh_id_from, 
            gwis_detail.field1, 
            gwis_detail.field2, 
            gwis_detail.field3, 
            gwis_detail.field4, 
            gwis_detail.field5, 
            gwis_detail.field6, 
            gwis_detail.field7, 
            gwis_detail.field8, 
            gwis_detail.field9, 
            gwis_detail.field10, 
            gwis_detail.po_quantity, 
            gwis_detail.grn_quantity,
            gwis_detail.giv_quantity,
            gwis_detail.driver_contract, 
            gwis_detail.driver_name, 
            gwis_detail.vehicle_reg, 
            gwis_detail.dc_no, 
            gwis_detail.dc_date, 
            gwis_detail.invoice, 
            gwis_detail.challan_type_detail, 
            gwis_detail.delivery_challan_type, 
            gwis_detail.ti_comment, 
            gwis_detail.ti_quantity, 
            gwis_detail.pi_comment, 
            gwis_detail.pi_quantity, 
            gwis_detail.dc_quantity
        FROM
                stock_batch
                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
        WHERE
                stock_batch.Qty > 0 
        AND stock_batch.item_id = '$item'
        AND gwis_master.stk_id = '$stk_id'
        AND gwis_detail.temp = 0
        AND gwis_master.process_status IN ($process_status_nmbr,99)
        AND gwis_master.status_id NOT IN (1,2,4,5)
        AND gwis_detail.electronic_approval =1
		AND stock_batch.wh_id = ".$_SESSION['warehouse_id']."
        $createdby
        GROUP BY
            stock_batch.batch_no 
        $orderby";
//        print_r($strSql);exit;
        return $this->query($strSql);
    }
    
    function get_product_batches_chng_prod($item,$wh_id=0,$product_category,$process_status_nmbr,$stk_id) {
//        $strSql = "SELECT
//	stock_batch.batch_no,
//	stock_batch.batch_id,
//	stock_batch.batch_expiry,
//	stock_batch.item_id,
//	SUM(tbl_stock_detail.Qty) AS Qty
//        FROM
//                stock_batch
//        INNER JOIN tbl_stock_detail ON stock_batch.batch_id = tbl_stock_detail.BatchID
//        INNER JOIN tbl_stock_master ON tbl_stock_detail.fkStockID = tbl_stock_master.PkStockID
//        WHERE
//                stock_batch.Qty > 0 
//        AND stock_batch.item_id = $item
//        AND stock_batch.wh_id = $wh_id
//        AND tbl_stock_master.WHIDTo = $wh_id
//        AND tbl_stock_detail.temp = 0
//        GROUP BY
//	stock_batch.batch_no";
        $orderby = '';
        if($product_category == '36')
        {
            $orderby = 'ORDER BY
                            stock_batch.batch_expiry ASC
                        ';
        }
        else{
            $orderby = 'ORDER BY
                            tbl_stock_detail.BatchID ASC
                        ';
        }
        $createdby = '';
        if($_SESSION['id'] == '1')
        {
            $createdby = '';
        }
        else{
//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
        }
        
        $strSql = "SELECT
            stock_batch.batch_no, 
            stock_batch.batch_id, 
            stock_batch.batch_expiry, 
            stock_batch.item_id, 
            SUM(gwis_detail.quantity) AS Qty, 
            gwis_detail.actual_rec_qty, 
            gwis_master.wh_id_from_supplier,
            gwis_master.wh_id_from, 
            gwis_detail.field1, 
            gwis_detail.field2, 
            gwis_detail.field3, 
            gwis_detail.field4, 
            gwis_detail.field5, 
            gwis_detail.field6, 
            gwis_detail.field7, 
            gwis_detail.field8, 
            gwis_detail.field9, 
            gwis_detail.field10, 
            gwis_detail.po_quantity, 
            gwis_detail.grn_quantity,
            gwis_detail.giv_quantity,
            gwis_detail.driver_contract, 
            gwis_detail.driver_name, 
            gwis_detail.vehicle_reg, 
            gwis_detail.dc_no, 
            gwis_detail.dc_date, 
            gwis_detail.invoice, 
            gwis_detail.challan_type_detail, 
            gwis_detail.delivery_challan_type, 
            gwis_detail.ti_comment, 
            gwis_detail.ti_quantity, 
            gwis_detail.pi_comment, 
            gwis_detail.pi_quantity, 
            gwis_detail.dc_quantity,
            gwis_detail.pk_id
        FROM
                stock_batch
                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
        WHERE
                stock_batch.Qty > 0 
        AND stock_batch.item_id = '$item'
        AND gwis_master.stk_id = '$stk_id'
        AND gwis_detail.temp = 0
        AND gwis_master.process_status IN ($process_status_nmbr,99)
        AND gwis_master.status_id NOT IN (1,2,4,5)
        AND gwis_detail.electronic_approval =1
        $createdby
        GROUP BY
            stock_batch.batch_no 
        $orderby";
//        print_r($strSql);exit;
        return $this->query($strSql);
    }
    
    
    function recalculate_batch_qty($batch_id) {
        
        $qry                = "SELECT * from gwis_detail where batch_id=$batch_id";
        $res_arr            = $this->query($qry);
//        print_r($res_arr);exit;
        $data_arr           = $res_arr->result_array();
        
        $balance = 0;
        foreach($data_arr as $k=>$row){
            //echo ','.$row['quantity'];
            $balance += $row['quantity'];
        }
        //echo 'BALANCE:'.$balance;exit;
        $qry = "UPDATE stock_batch set Qty='".$balance."' where batch_id='".$batch_id."' ";
//        print_r($qry);exit;
        $this->query2($qry);
        return $balance;
    }
    
    function update_recalculate_batch_qty($batch_id,$balance) {
        
//        echo 'BALANCE:'.$balance;exit;
        $qry = "UPDATE stock_batch set Qty=Qty+'".$balance."' where batch_id='".$batch_id."' ";
//        print_r($qry);exit;
        $this->query2($qry);
        return $balance;
    }
    
    function stock_adjs_recalculate_batch_qty($batch_id,$detailid) {
        
        $qry1                = "SELECT * from gwis_detail
                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                                WHERE
                                stock_batch.batch_id = '".$batch_id."' 
                                AND gwis_detail.pk_id = '".$detailid."'";
        $res_arr            = $this->query($qry1);
//        print_r($qry1);exit;
        $data_arr           = $res_arr->result_array();
        
        $balance = 0;
        foreach($data_arr as $k=>$row){
            //echo ','.$row['quantity'];
            $balance = $row['quantity'];
        }
        
        $qry2                = "SELECT * from stock_batch 
                                WHERE
                                batch_id = '".$batch_id."'";
        $res_arr2            = $this->query($qry2);
//        print_r($qry);exit;
        $data_arr2           = $res_arr2->result_array();
        
        $actual_balance = 0;
        foreach($data_arr2 as $k=>$row2){
            //echo ','.$row['quantity'];
            $actual_balance = $row2['Qty'];
        }
        $fqty = $actual_balance + $balance;
//        echo 'BALANCE1: '.$fqty;exit;
//        echo 'BALANCE2: '.$actual_balance;exit;
        $qry = "UPDATE stock_batch set Qty='".$fqty."' where batch_id='".$batch_id."' ";
//        $qry = "UPDATE stock_batch
//                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
//                        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
//                SET Qty = '".$balance."' 
//                WHERE
//                        stock_batch.batch_id = '".$batch_id."' 
//                        AND gwis_master.process_status = 12";
//        print_r($qry);exit;
        $this->query2($qry);
        return $balance;
    }
    
    function final_process_recalculate_batch_qty($batch_id,$parentid,$detailid) {
        
        $qry1                = "SELECT * from gwis_detail
                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                                WHERE
                                stock_batch.batch_id = '".$batch_id."' 
                                AND gwis_master.process_status = 12
                                AND gwis_detail.pk_id = '".$detailid."'";
        $res_arr            = $this->query($qry1);
//        print_r($qry1);exit;
        $data_arr           = $res_arr->result_array();
        
        $balance = 0;
        foreach($data_arr as $k=>$row){
            //echo ','.$row['quantity'];
            $balance = $row['quantity'];
        }
        
        $qry2                = "SELECT * from stock_batch 
                                WHERE
                                batch_id = '".$batch_id."'";
        $res_arr2            = $this->query($qry2);
//        print_r($qry);exit;
        $data_arr2           = $res_arr2->result_array();
        
        $actual_balance = 0;
        foreach($data_arr2 as $k=>$row2){
            //echo ','.$row['quantity'];
            $actual_balance = $row2['Qty'];
        }
        $fqty = $actual_balance + $balance;
//        echo 'BALANCE1: '.$fqty;exit;
//        echo 'BALANCE2: '.$actual_balance;exit;
        $qry = "UPDATE stock_batch set Qty='".$fqty."' where batch_id='".$batch_id."' ";
//        $qry = "UPDATE stock_batch
//                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
//                        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
//                SET Qty = '".$balance."' 
//                WHERE
//                        stock_batch.batch_id = '".$batch_id."' 
//                        AND gwis_master.process_status = 12";
//        print_r($qry);exit;
        $this->query2($qry);
        return $balance;
    }
    
    function gwisfinal_process_recalculate_batch_qty($batch_id,$parentid,$detailid) {
        
        $qry1                = "SELECT * from gwis_detail
                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                                WHERE
                                stock_batch.batch_id = '".$batch_id."' 
                                AND gwis_master.process_status = 3
                                AND gwis_detail.pk_id = '".$detailid."'";
        $res_arr            = $this->query($qry1);
//        print_r($qry1);exit;
        $data_arr           = $res_arr->result_array();
        
        $balance = 0;
        foreach($data_arr as $k=>$row){
            //echo ','.$row['quantity'];
            $balance = $row['quantity'];
        }
        
        $qry2                = "SELECT * from stock_batch 
                                WHERE
                                batch_id = '".$batch_id."'";
        $res_arr2            = $this->query($qry2);
//        print_r($qry);exit;
        $data_arr2           = $res_arr2->result_array();
        
        $actual_balance = 0;
        foreach($data_arr2 as $k=>$row2){
            //echo ','.$row['quantity'];
            $actual_balance = $row2['Qty'];
        }
        
//        For Stock issue 
//        $fqty = $actual_balance + $balance;
//        
//        For Stock Gwis
          $fqty = abs($balance);
//        echo 'BALANCE1: '.$fqty;exit;
//        echo 'BALANCE2: '.$actual_balance;exit;
         $qry = "UPDATE stock_batch set Qty='".$fqty."' where batch_id='".$batch_id."' ";
//        $qry = "UPDATE stock_batch
//                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
//                        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
//                SET Qty = '".$balance."' 
//                WHERE
//                        stock_batch.batch_id = '".$batch_id."' 
//                        AND gwis_master.process_status = 12";
//        print_r($qry);exit;
        $this->query2($qry);
        return $balance;
    }
    
    
    function tacfinal_process_recalculate_batch_qty($batch_id,$parentid,$detailid) {
        
        $qry1                = "SELECT * from gwis_detail
                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                                WHERE
                                stock_batch.batch_id = '".$batch_id."' 
                                AND gwis_master.process_status = 6
                                AND gwis_detail.pk_id = '".$detailid."'";
        $res_arr            = $this->query($qry1);
//        print_r($qry1);exit;
        $data_arr           = $res_arr->result_array();
        
        $balance = 0;
        foreach($data_arr as $k=>$row){
            //echo ','.$row['quantity'];
            $balance = $row['quantity'];
        }
        
        $qry2                = "SELECT * from stock_batch 
                                WHERE
                                batch_id = '".$batch_id."'";
        $res_arr2            = $this->query($qry2);
//        print_r($qry);exit;
        $data_arr2           = $res_arr2->result_array();
        
        $actual_balance = 0;
        foreach($data_arr2 as $k=>$row2){
            //echo ','.$row['quantity'];
            $actual_balance = $row2['Qty'];
        }
        
//        For Stock issue 
//        $fqty = $actual_balance + $balance;
//        
//        For Stock TAC
          $fqty = abs($balance);
//        echo 'BALANCE1: '.$fqty;exit;
//        echo 'BALANCE2: '.$actual_balance;exit;
         $qry = "UPDATE stock_batch set Qty='".$fqty."' where batch_id='".$batch_id."' ";
//        $qry = "UPDATE stock_batch
//                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
//                        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
//                SET Qty = '".$balance."' 
//                WHERE
//                        stock_batch.batch_id = '".$batch_id."' 
//                        AND gwis_master.process_status = 12";
//        print_r($qry);exit;
        $this->query2($qry);
        return $balance;
    }
    
    function grnfinal_process_recalculate_batch_qty($batch_id,$parentid,$detailid) {
        
        $qry1                = "SELECT * from gwis_detail
                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                                WHERE
                                stock_batch.batch_id = '".$batch_id."' 
                                AND gwis_master.process_status = 9
                                AND gwis_detail.pk_id = '".$detailid."'";
        $res_arr            = $this->query($qry1);
//        print_r($qry1);exit;
        $data_arr           = $res_arr->result_array();
        
        $balance = 0;
        foreach($data_arr as $k=>$row){
            //echo ','.$row['quantity'];
            $balance = $row['quantity'];
        }
        
        $qry2                = "SELECT * from stock_batch 
                                WHERE
                                batch_id = '".$batch_id."'";
        $res_arr2            = $this->query($qry2);
//        print_r($qry);exit;
        $data_arr2           = $res_arr2->result_array();
        
        $actual_balance = 0;
        foreach($data_arr2 as $k=>$row2){
            //echo ','.$row['quantity'];
            $actual_balance = $row2['Qty'];
        }
        
//        For Stock issue 
//        $fqty = $actual_balance + $balance;
//        
//        For Stock TAC
          $fqty = abs($balance);
//        echo 'BALANCE1: '.$fqty;exit;
//        echo 'BALANCE2: '.$actual_balance;exit;
         $qry = "UPDATE stock_batch set Qty='".$fqty."' where batch_id='".$batch_id."' ";
//        $qry = "UPDATE stock_batch
//                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
//                        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
//                SET Qty = '".$balance."' 
//                WHERE
//                        stock_batch.batch_id = '".$batch_id."' 
//                        AND gwis_master.process_status = 12";
//        print_r($qry);exit;
        $this->query2($qry);
        return $balance;
    }
    
    function get_batch_info($batch_id) {
        $wh_id = $this->session->userdata('warehouse_id');
        $strSql = "SELECT
                stock_batch.batch_no,
                stock_batch.batch_id,
                stock_batch.batch_expiry,
                stock_batch.item_id,
                stock_batch.Qty AS Qty,
                stock_batch.batch_totalprice,
                stock_batch.unit_price,
                stock_batch.currency,
                stock_batch.conversion_rate,
                gwis_detail.actual_rec_qty,
                gwis_detail.field1,
                gwis_detail.field2,
                gwis_detail.field3,
                gwis_detail.field4,
                gwis_detail.field5,
                gwis_detail.field6,
                gwis_detail.field7,
                gwis_detail.field8,
                gwis_detail.field9,
                gwis_detail.field10,
                gwis_detail.wh_location,
                list_detail.`name` AS `storage`,
                list_detail.`pk_id` AS `storage_id` 
        FROM
                stock_batch
                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                LEFT JOIN list_detail ON gwis_detail.`storage` = list_detail.pk_id 
        WHERE
        stock_batch.batch_id = $batch_id 
        AND gwis_master.status_id = 3
        AND stock_batch.status = 'Running'
        GROUP BY
	stock_batch.batch_no";
//       echo $strSql;exit;
        return $this->query($strSql);
    }
    
    function get_batch_info_new($batch_id) {
        $wh_id = $this->session->userdata('warehouse_id');
        $strSql = "SELECT
                stock_batch.batch_no,
                stock_batch.batch_id,
                stock_batch.batch_expiry,
                stock_batch.item_id,
                stock_batch.Qty AS Qty,
                sum(gwis_detail.quantity) AS tempissue,
                stock_batch.batch_totalprice,
                stock_batch.unit_price,
                stock_batch.currency,
                stock_batch.conversion_rate,
                gwis_detail.actual_rec_qty,
                gwis_detail.field1,
                gwis_detail.field2,
                gwis_detail.field3,
                gwis_detail.field4,
                gwis_detail.field5,
                gwis_detail.field6,
                gwis_detail.field7,
                gwis_detail.field8,
                gwis_detail.field9,
                gwis_detail.field10,
                gwis_detail.wh_location,
                list_detail.`name` AS `storage`,
                list_detail.`pk_id` AS `storage_id` 
        FROM
                stock_batch
                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                LEFT JOIN list_detail ON gwis_detail.`storage` = list_detail.pk_id 
        WHERE
        stock_batch.batch_id = $batch_id 
        AND gwis_detail.temp = 1
        AND stock_batch.status = 'Running'
        GROUP BY
	stock_batch.batch_no";
//        echo $strSql;exit;
        return $this->query($strSql);
    }
    
    function get_batch_tempinfos($batch_id) {
        $wh_id = $this->session->userdata('warehouse_id');
        $strSql = "SELECT
                stock_batch.batch_no,
                stock_batch.batch_id,
                stock_batch.batch_expiry,
                stock_batch.item_id,
                stock_batch.Qty AS Qty,
                sum(gwis_detail.quantity) AS tempissue,
                stock_batch.batch_totalprice,
                stock_batch.unit_price,
                stock_batch.currency,
                stock_batch.conversion_rate,
                gwis_detail.actual_rec_qty,
                gwis_detail.field1,
                gwis_detail.field2,
                gwis_detail.field3,
                gwis_detail.field4,
                gwis_detail.field5,
                gwis_detail.field6,
                gwis_detail.field7,
                gwis_detail.field8,
                gwis_detail.field9,
                gwis_detail.field10,
                gwis_detail.wh_location,
                list_detail.`name` AS `storage`, 
                list_detail.`pk_id` AS `storage_id` 
        FROM
                stock_batch
                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                LEFT JOIN list_detail ON gwis_detail.`storage` = list_detail.pk_id 
        WHERE
        stock_batch.batch_id = $batch_id 
        AND gwis_detail.temp = 1
        AND stock_batch.status = 'Running'
        GROUP BY
	stock_batch.batch_no";
//echo $strSql;exit;
        return $this->query($strSql);
    }
    
    function getprodinfo($prod_id,$process_status_nmbr,$stk_id) {
        $wh_id = $this->session->userdata('warehouse_id');
        $strSql = "SELECT
	stock_batch.batch_no,
	stock_batch.batch_id,
	stock_batch.batch_expiry,
	stock_batch.item_id,
	stock_batch.Qty AS Qty,
	stock_batch.batch_totalprice,
	stock_batch.unit_price,
	stock_batch.currency,
	stock_batch.conversion_rate,
	gwis_detail.actual_rec_qty,
	gwis_detail.field1,
	gwis_detail.field2,
	gwis_detail.field3,
	gwis_detail.field4,
	gwis_detail.field5,
	gwis_detail.field6,
	gwis_detail.field7,
	gwis_detail.field8,
	gwis_detail.field9,
	gwis_detail.field10,
	gwis_detail.quantity,
	gwis_detail.manufacturer,
	gwis_detail.comments,
	gwis_detail.dc_quantity,
	gwis_detail.pi_quantity,
	gwis_detail.pi_comment,
	gwis_detail.ti_comment,
	gwis_detail.ti_quantity,
	gwis_detail.delivery_challan_type,
	gwis_detail.challan_type_detail,
	gwis_detail.driver_name,
	gwis_detail.driver_contract,
	gwis_detail.vehicle_reg,
	gwis_detail.dc_no,
	gwis_detail.dc_date,
	gwis_detail.invoice,
	gwis_detail.po_quantity,
	gwis_detail.gwis_adj_status,
	gwis_detail.siv_driver_name,
	gwis_detail.siv_contatc_number,
	gwis_detail.siv_cnic,
	gwis_detail.siv_weight,
	gwis_detail.siv_no_of_cartons,
	gwis_detail.siv_transportation_po,
	gwis_detail.siv_tracking_no,
	gwis_detail.grn_quantity,
	gwis_detail.giv_quantity,
	gwis_detail.electronic_approval,
	gwis_detail.electronic_approval_status,
	gwis_detail.detail_active_process,
	gwis_detail.date_vehicle_req,
	gwis_detail.no_of_vehicle,
	gwis_detail.type_of_vehicle,
	gwis_detail.no_of_cartons,
	gwis_detail.temperature_requirement,
	gwis_detail.product_type_id,
	gwis_detail.transport_req_remarks,
	gwis_detail.value_of_product,
        gwis_detail.wh_location,
        gwis_master.wh_id_from_supplier,
        gwis_master.wh_id_from,
        gwis_master.stk_id,
        gwis_master.inspection_date,
        gwis_master.delivery_location,
        gwis_master.po_cmu_no,
        gwis_master.po_cmu_date,
        gwis_master.po_gf_no,
        gwis_master.po_gf_date,
        gwis_master.date_of_receiving,
        gwis_master.air_bill_no,
        gwis_master.shipment_no,
        gwis_master.origin_of_country,
        gwis_master.vehicle_type_and_plate,
        gwis_master.consignment_weight,
        list_detail.`name` AS `storage`, 
        list_detail.`pk_id` AS `storage_id` 
        FROM
                stock_batch
        INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
        LEFT JOIN list_detail ON gwis_detail.`storage` = list_detail.pk_id 
        WHERE 
            stock_batch.Qty > 0 
            AND stock_batch.item_id = '$prod_id' 
            AND gwis_master.stk_id = '$stk_id'
            AND gwis_master.process_status IN ($process_status_nmbr,99)
            AND gwis_master.status_id NOT IN (1,2,4,5)
            AND stock_batch.status = 'Running'
        GROUP BY
            stock_batch.batch_no";
//        echo $strSql;exit;
        return $this->query($strSql);
    }
    
    function getprodinfo_adj($prod_id,$wh_id=0,$product_category,$process_status_nmbr,$stk_id) {
        $wh_id = $this->session->userdata('warehouse_id');
        $strSql = "SELECT
	stock_batch.batch_no,
	stock_batch.batch_id,
	stock_batch.batch_expiry,
	stock_batch.item_id,
	stock_batch.Qty AS Qty,
	stock_batch.batch_totalprice,
	stock_batch.unit_price,
	stock_batch.currency,
	stock_batch.conversion_rate,
	gwis_detail.actual_rec_qty,
	gwis_detail.field1,
	gwis_detail.field2,
	gwis_detail.field3,
	gwis_detail.field4,
	gwis_detail.field5,
	gwis_detail.field6,
	gwis_detail.field7,
	gwis_detail.field8,
	gwis_detail.field9,
	gwis_detail.field10,
	gwis_detail.quantity,
	gwis_detail.manufacturer,
	gwis_detail.comments,
	gwis_detail.dc_quantity,
	gwis_detail.pi_quantity,
	gwis_detail.pi_comment,
	gwis_detail.ti_comment,
	gwis_detail.ti_quantity,
	gwis_detail.delivery_challan_type,
	gwis_detail.challan_type_detail,
	gwis_detail.driver_name,
	gwis_detail.driver_contract,
	gwis_detail.vehicle_reg,
	gwis_detail.dc_no,
	gwis_detail.dc_date,
	gwis_detail.invoice,
	gwis_detail.po_quantity,
	gwis_detail.gwis_adj_status,
	gwis_detail.siv_driver_name,
	gwis_detail.siv_contatc_number,
	gwis_detail.siv_cnic,
	gwis_detail.siv_weight,
	gwis_detail.siv_no_of_cartons,
	gwis_detail.siv_transportation_po,
	gwis_detail.siv_tracking_no,
	gwis_detail.grn_quantity,
	gwis_detail.giv_quantity,
	gwis_detail.electronic_approval,
	gwis_detail.electronic_approval_status,
	gwis_detail.detail_active_process,
	gwis_detail.date_vehicle_req,
	gwis_detail.no_of_vehicle,
	gwis_detail.type_of_vehicle,
	gwis_detail.no_of_cartons,
	gwis_detail.temperature_requirement,
	gwis_detail.product_type_id,
	gwis_detail.transport_req_remarks,
	gwis_detail.value_of_product,
        gwis_master.wh_id_from_supplier,
        gwis_master.wh_id_from
        FROM
                stock_batch
        INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
        WHERE 
            stock_batch.Qty > 0 
            AND gwis_detail.temp = 0
            AND gwis_master.process_status IN ($process_status_nmbr,99)
            AND gwis_master.status_id NOT IN (1,2,4,5)
            AND gwis_detail.electronic_approval = 1
            AND stock_batch.item_id = $prod_id 
            AND gwis_master.stk_id = '$stk_id'
        GROUP BY
	stock_batch.batch_no";
//        echo $strSql;exit;
        return $this->query($strSql);
    }
    
    function getprodinfo_chng_prod($prod_id,$wh_id=0,$product_category,$process_status_nmbr,$stk_id) {
        $wh_id = $this->session->userdata('warehouse_id');
        $strSql = "SELECT
	stock_batch.batch_no,
	stock_batch.batch_id,
	stock_batch.batch_expiry,
	stock_batch.item_id,
	stock_batch.Qty AS Qty,
	stock_batch.batch_totalprice,
	stock_batch.unit_price,
	stock_batch.currency,
	stock_batch.conversion_rate,
	gwis_detail.actual_rec_qty,
	gwis_detail.field1,
	gwis_detail.field2,
	gwis_detail.field3,
	gwis_detail.field4,
	gwis_detail.field5,
	gwis_detail.field6,
	gwis_detail.field7,
	gwis_detail.field8,
	gwis_detail.field9,
	gwis_detail.field10,
	gwis_detail.quantity,
	gwis_detail.manufacturer,
	gwis_detail.comments,
	gwis_detail.dc_quantity,
	gwis_detail.pi_quantity,
	gwis_detail.pi_comment,
	gwis_detail.ti_comment,
	gwis_detail.ti_quantity,
	gwis_detail.delivery_challan_type,
	gwis_detail.challan_type_detail,
	gwis_detail.driver_name,
	gwis_detail.driver_contract,
	gwis_detail.vehicle_reg,
	gwis_detail.dc_no,
	gwis_detail.dc_date,
	gwis_detail.invoice,
	gwis_detail.po_quantity,
	gwis_detail.gwis_adj_status,
	gwis_detail.siv_driver_name,
	gwis_detail.siv_contatc_number,
	gwis_detail.siv_cnic,
	gwis_detail.siv_weight,
	gwis_detail.siv_no_of_cartons,
	gwis_detail.siv_transportation_po,
	gwis_detail.siv_tracking_no,
	gwis_detail.grn_quantity,
	gwis_detail.giv_quantity,
	gwis_detail.electronic_approval,
	gwis_detail.electronic_approval_status,
	gwis_detail.detail_active_process,
	gwis_detail.date_vehicle_req,
	gwis_detail.no_of_vehicle,
	gwis_detail.type_of_vehicle,
	gwis_detail.no_of_cartons,
	gwis_detail.temperature_requirement,
	gwis_detail.product_type_id,
	gwis_detail.transport_req_remarks,
	gwis_detail.value_of_product,
        gwis_detail.wh_location,
        gwis_detail.pk_id,
        list_detail.`name` AS `storage`,
        list_detail.`pk_id` AS `storage_id`,
        gwis_master.wh_id_from_supplier,
        gwis_master.wh_id_from
        FROM
                stock_batch
        INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
        LEFT JOIN list_detail ON gwis_detail.`storage` = list_detail.pk_id 
        WHERE 
            stock_batch.Qty > 0 
            AND gwis_detail.temp = 0
            AND gwis_master.process_status IN ($process_status_nmbr,99)
            AND gwis_master.status_id NOT IN (1,2,4,5)
            AND gwis_detail.electronic_approval = 1
            AND stock_batch.item_id = $prod_id
            AND gwis_master.stk_id = '$stk_id'
        GROUP BY
	stock_batch.batch_no";
//        echo $strSql;exit;
        return $this->query($strSql);
    }
    /**
     * GetBatchDetail
     * @param type $id
     * @return boolean
     */
    public function GetBatchDetail($id) {
        $strSql = "     SELECT
                            stock_batch.batch_no,
                            stock_batch.batch_expiry,
                            stock_batch.item_id,
                            stock_batch.unit_price,
                            stock_batch.production_date,
                            stock_batch.vvm_type,
                            gwis_detail.quantity,
                            gwis_detail.dc_quantity,
                            gwis_detail.pi_quantity,
                            gwis_detail.ti_quantity,
                            gwis_detail.pi_comment,
                            gwis_detail.ti_comment,
                            stock_batch.funding_source,
                            stock_batch.manufacturer
			FROM
                            gwis_detail
			INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
			WHERE
                            gwis_detail.pk_id = $id";
//        echo $strSql;exit;
        //query result
        return $this->query($strSql);
    }
    
    public function getproductfields($itemid,$product_type) {
        $strSql = "SELECT
                        GROUP_CONCAT(category_field_list.field_id) AS field_id,
                        category_field_list.pk_id,
                        category_field_list.`status`,
                        GROUP_CONCAT(field_list.field_name) AS field_name,
                        GROUP_CONCAT(field_list.field_id) AS fid,
                        GROUP_CONCAT(category_field_list.is_mandatory) AS is_mandatory
                FROM
                        category_field_list
                        INNER JOIN field_list ON category_field_list.field_id = field_list.pk_id 
                WHERE
                        category_field_list.category_id = '$product_type'";
        //query result
        return $this->query($strSql);
    }
    
    function get_tran_nature($tran_id) {
        $wh_id = $this->session->userdata('warehouse_id');
        $strSql = "SELECT
                transaction_types.trans_nature
                FROM
                transaction_types
                WHERE

                transaction_types.trans_id = '$tran_id' 
                ";
        return $this->query($strSql);
    }
    
    
    function getfledgerbatchinfo($batchid) {
        $strSql = "SELECT
                    stock_batch.batch_no,
                    stock_batch.batch_expiry,
                    stock_batch.item_id,
                    stock_batch.Qty,
                    sum(gwis_detail.quantity) as quantity,
                    stock_batch.`status`,
                    stock_batch.unit_price,
                    stock_batch.production_date,
                    stock_batch.vvm_type,
                    stock_batch.wh_id,
                    stock_batch.funding_source,
                    stock_batch.manufacturer,
                    stock_batch.phy_inspection,
                    stock_batch.dtl,
                    stock_batch.dist_plan,
                    itminfo_tab.itm_name,
                    tbl_warehouse.wh_name,
                    tbl_warehouse.stkid,
                    CONCAT( stakeholder.stkname ) AS funding_source_name,
                    gwis_master.source_type
            FROM
                    stock_batch
            LEFT JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
            LEFT JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
            LEFT JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
            LEFT JOIN tbl_warehouse ON stock_batch.funding_source = tbl_warehouse.wh_id
            
            LEFT JOIN stakeholder ON gwis_master.source_type = stakeholder.stkid 
            WHERE
                    stock_batch.batch_id = '$batchid' 
                   AND process_status IN ( 9, 12, 99) 
                ";
//        echo $strSql;exit;
        return $this->query($strSql);
    }
    
    function getfledgerbatchsec($batchid) {
        $strSql = "SELECT
                    gwis_master.wh_id_from,
                    gwis_master.wh_id_to,
                    stock_batch.batch_id,
                    stock_batch.batch_no,
                    gwis_master.created_on,
                    gwis_detail.quantity,
                    stock_batch.`status`,
                    tbl_warehouse.wh_name AS From_warehouse,
                    tt.wh_name AS to_warehouse,
                    stakeholder.stkname,
                    tbl_locations.LocName AS province_name,
                    gwis_master.tran_date,
                    gwis_master.tran_no,
                    gwis_master.tran_ref,
                    gwis_master.pk_id,
                    gwis_master.status_id,
                    gwis_detail.adjustment_type,
                    transaction_types.trans_type,
                    fs.stkname AS funding_source_name,
                    gwis_master.process_status
            FROM
                    stock_batch
            INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
            INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
            LEFT JOIN tbl_warehouse ON gwis_master.wh_id_from = tbl_warehouse.wh_id
            LEFT JOIN tbl_warehouse AS tt ON gwis_master.wh_id_to = tt.wh_id
            LEFT JOIN stakeholder ON gwis_master.stk_id = stakeholder.stkid
            LEFT JOIN tbl_locations ON tt.prov_id = tbl_locations.PkLocID
            LEFT JOIN transaction_types ON gwis_detail.adjustment_type = transaction_types.trans_id
            LEFT JOIN stakeholder AS fs ON gwis_master.source_type = fs.stkid 
            WHERE
                    stock_batch.batch_id = '$batchid' 
                        AND process_status IN (9,12,99)
            ORDER BY
                    DATE_FORMAT(
                            gwis_master.tran_date,
                            '%Y-%m-%d'
                    ) ASC,
                    gwis_detail.pk_id
                            ";
//        echo $strSql;exit;
        return $this->query($strSql);
    }
    
    function get_manufacturer_field($item_id){
        $strSql = "SELECT
                            stakeholder.stkname,
                            itminfo_tab.manufacturer_id,
                            product_method_type.method_type,
                            product_method_type.pk_id 
                    FROM
                            stakeholder
                            INNER JOIN itminfo_tab ON stakeholder.stkid = itminfo_tab.manufacturer_id
                            INNER JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id 
                    WHERE
                            itminfo_tab.itm_id = '$item_id'";
//        echo $strSql;exit;
        return $this->query($strSql);
    }
    
    function get_manufacturerld($item_id){
        $strSql = "SELECT
                            stakeholder.stkname,
                            stakeholder.stkid,
                            itminfo_tab.manufacturer_id
                    FROM
                            stakeholder
                            INNER JOIN itminfo_tab ON stakeholder.stkid = itminfo_tab.manufacturer_id
                    WHERE
                            itminfo_tab.itm_id = '$item_id'";
//        echo $strSql;exit;
        return $this->query($strSql);
    }
    
    
    function get_issue_batchno($batch_id){
        $strSql = "SELECT
                            *
                    FROM
                            stock_batch
                    WHERE
                            stock_batch.batch_id = '$batch_id'";
//        echo $strSql;exit;
        return $this->query($strSql);
    }
    
    function getprodname($itmid){
        $strSql = "SELECT
                            *
                    FROM
                            itminfo_tab
                    WHERE
                            itminfo_tab.itm_id = '$itmid'";
//        echo $strSql;exit;
        return $this->query($strSql);
    }
    
    public function tac_updateprocess_status($batch_id) {

        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
//        print_r($attribute_pairs);exit;
        $sql = "UPDATE " . static::$table_name . " SET dtl_status = '" . $this->escape_value($this->dtl_status)."',
            dtl_result = '" . $this->escape_value($this->dtl_result)."', dtl = '" . $this->escape_value($this->dtl)."' WHERE batch_id='".$batch_id."' ";
//        print_r($sql); 
        $this->query($sql);
//        print_r($this->affected_rows());exit;
        return  true ;
    }
    function getbatchmang_batchinfo($itmid)
    {
        $strSql = "SELECT
                            stock_batch.batch_id
                    FROM
                            stock_batch
                    WHERE
                            stock_batch.item_id = " . $itmid . "  and wh_id = '".$this->session->userdata('warehouse_id')."' ";
                            
                            //echo $strSql;exit;
                            //In Future
                            //    AND stock_batch.wh_id = " . $_SESSION['warehouse_id'];
        $res = $this->query($strSql);
        $data['res'] = $res->result_array();
//        echo '<pre>';
//        print_r($data['res']);
//        echo '</pre>';
//        exit;
        foreach($data['res'] as $k => $v){
            $strSql2 = " select AdjustQty2(".$v['batch_id']."); ";
            $res2 = $this->query($strSql2);
        }
        
        $strSql = "SELECT
                            stock_batch.batch_no,
                            itminfo_tab.itm_name,
                            itminfo_tab.itm_id,
                            itminfo_tab.itm_type,
                            sum( CASE WHEN stock_batch.`status` = 'Stacked' THEN stock_batch.Qty ELSE 0 END ) AS StackedQty,
                            sum( CASE WHEN stock_batch.`status` = 'Running' THEN stock_batch.Qty ELSE 0 END ) AS RunningQty,
                            sum( CASE WHEN stock_batch.`status` = 'Finished' THEN stock_batch.Qty ELSE 0 END ) AS FinishedQty,
                            sum( CASE WHEN stock_batch.`status` = 'Stacked' THEN 1 ELSE 0 END ) stacked,
                            sum( CASE WHEN stock_batch.`status` = 'Running' THEN 1 ELSE 0 END ) running,
                            sum( CASE WHEN stock_batch.`status` = 'Finished' THEN 1 ELSE 0 END ) finished 
                    FROM
                            stock_batch
                            INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id 
                            INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                            INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
                    WHERE
                            stock_batch.item_id = " . $itmid . " 
                            AND stock_batch.wh_id = '".$this->session->userdata('warehouse_id')."'
                            AND gwis_master.status_id IN (3,4)
                            AND gwis_master.process_status IN (9,99)";
                            
//                            echo $strSql;exit;
                            //In Future
                            //    AND stock_batch.wh_id = " . $_SESSION['warehouse_id'];
                            return $this->query($strSql);
    }
    
    function getbatchmang_batchsummary($id){
        
        $createdby = '';
//        if($_SESSION['id'] == '1')
//        {
//            $createdby = '';
//        }
//        else{
//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
//        }
        
        $stklimit = '';
        $join = ''; 
//        $stkidarray = array();
//        for ($i = 0; $i < $_SESSION['count']; $i++) {
//            array_push($stkidarray, "'" . $_SESSION['stakeholder_id_'.$i]. "'");
//        }
//        $stkid = implode(', ', $stkidarray);
		$stkid = $this->get_user_stakeholders();
        
        if($_SESSION['id'] == '1')
        {
            if(isset($stakeholder) && !empty($stakeholder))
            {
                $stklimit = " AND gwis_master.stk_id IN (".$stakeholder.")";
            }
            else 
            {
                $stklimit = '';
            }
            $join = '';
        }
        else{ 
            //New 
            if(isset($stakeholder) && !empty($stakeholder))
            {
                //$stklimit = " AND gwis_master.stk_id IN (".$stakeholder.")";
            }
            else 
            {
                //$stklimit = " AND gwis_master.stk_id IN (".$stkid.")";
            }
            //Old
//            $stklimit = "AND stakeholder_item.stk_id IN (".$stkid.")";
//            $join = " LEFT JOIN stakeholder ON gwis_master.stk_id = stakeholder.stkid
//                    INNER JOIN stakeholder_item ON stakeholder_item.stk_id = stakeholder.stkid";
        }
        
		$wh_id = $_SESSION['warehouse_id'];
        $qry = "SELECT
                        itminfo_tab.itm_name,
                        itminfo_tab.unit,
                        SUM(stock_batch.Qty) AS Vials,
                        itminfo_tab.qty_carton AS qty_carton_old,
                        stock_batch.unit_price,
                        product_strength.strength 
                FROM
                        stock_batch
                        INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                        LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id 
                        /*INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
                        LEFT JOIN users ON gwis_master.created_by = users.pk_id*/
                WHERE
                        stock_batch.Qty > 0 
						AND stock_batch.wh_id = $wh_id
                        $createdby
                        $stklimit
                GROUP BY
                        stock_batch.item_id 
                ORDER BY
                        itminfo_tab.itm_name";
        
        //IN Future
//        stock_batch.`wh_id` = '" . $_SESSION['warehouse_id'] . "'
//                            AND 
        
//        echo $qry;exit;
        return $this->query($qry);
        
    }
    
    
    public function batch_mangsearch($item_id, $batch_no, $TranRef, $status,$funding_source) {
        $session_wh_id = $_SESSION['warehouse_id'];
        switch ($status) {
            case 1:
                $status = 'Running';
                break;
            case 2:
                $status = 'Stacked';
                break;
            case 3:
                $status = 'Finished';
                break;
            default:
                break;
        }
            $sql = "SELECT
                                stock_batch.batch_id,
                                stock_batch.batch_no,
                                stock_batch.batch_expiry,
                                stock_batch.`status`,
                                Sum( gwis_detail.quantity ) AS BatchQty,
                                itminfo_tab.itm_id,
                                itminfo_tab.itm_name,
                                itminfo_tab.generic_name,
                                itminfo_tab.generic_name,
                                itminfo_tab.strength_id,
                                tbl_itemunits.UnitType,
                                tbl_warehouse.wh_name AS funding_source,
                                /*IFNULL( manu.stkname, 'N/A' ) manufacturer,*/
                               /* stakeholder_item.quantity_per_pack AS qty_carton,*/
                                stock_batch.unit_price,
                                stock_batch.dtl,
                                stock_batch.phy_inspection,
                                '' AS fs_name,
                                '' AS stakeholder_name,
                                '' as manufacturer,
                                '' as qty_carton
                                /*source_type.stkname AS fs_name*/
                                /*
                                stkname.stkname AS stakeholder_name*/
				FROM
					gwis_detail
				INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
				INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
				INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
				LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
				LEFT JOIN transaction_types ON gwis_master.tran_type_id = transaction_types.trans_id
				LEFT JOIN tbl_warehouse ON stock_batch.funding_source = tbl_warehouse.wh_id
                               /* LEFT JOIN stakeholder_item ON stock_batch.manufacturer = stakeholder_item.stk_id
                                LEFT JOIN stakeholder AS manu ON stakeholder_item.stk_id = manu.stkid
                                LEFT JOIN stakeholder AS source_type ON gwis_master.source_type = source_type.stkid
                                LEFT JOIN stakeholder AS stkname ON gwis_master.stk_id = stkname.stkid*/
                                LEFT JOIN users ON gwis_master.created_by = users.pk_id ";

        if (!empty($item_id)) {
            $where[] = " stock_batch.item_id = " . $item_id;
        }
        if (!empty($batch_no)) {
            $where[] = " stock_batch.batch_no LIKE '%" . $batch_no . "%'";
        }
        if (!empty($TranRef)) {
            $where[] = " gwis_master.tran_no LIKE '%" . $TranRef . "%'";
        }
        if ($status == 4) {
            $where[] = " stock_batch.`status` IN ('Running', 'Stacked')";
        } else {
            $where[] = " stock_batch.`status` = '" . $status . "'";
        }
        if (!empty($funding_source) && $funding_source != 'all') {
            $where[] = " gwis_master.source_type = " . $funding_source . " ";
        }
//        if($_SESSION['id'] == '1')
//        {
////            $createdby = '';
//        }
//        else{
////            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
//            $where[] = " gwis_master.created_by = '".$_SESSION['id']."'";
//        }
//        In Future
//        $where[] = " stock_batch.`wh_id` = " . $_SESSION['warehouse_id'] . "";

        // Finished means 0 quantity, We don't need this check for Finished Qty
        if ($status != 'Finished') {
//            $where[] = " stock_batch.Qty <> 0";
        }

        if (!empty($where)) {
            $sql .= " WHERE " . implode(" AND ", $where);
        }
        $sql .= "AND stock_batch.`wh_id` = '$session_wh_id'";
        $sql .= "AND  process_status IN ( 9, 12, 99 ) "; /// process status added, to match the logic for calculation of stock
        $sql .= " group by stock_batch.item_id, stock_batch.batch_id, stock_batch.batch_expiry, stock_batch.status ORDER BY
	itminfo_tab.itm_name ASC";
        //query result
//        echo $sql;exit;
        return $this->query($sql);
    }
    
    public function storage_search($startdate,$enddate,$product, $storage,$process_status_nmbr_s3,$process_status_nmbr_s4,$product_category)
    {
        $createdby = '';
//        if($_SESSION['id'] == '1')
//        {
//            $createdby = '';
//        }
//        else{
//            $createdby = "AND gwis_master.created_by = '".$_SESSION['id']."'";
//        }
        
        $stklimit = '';
        $join = '';
        $stkidarray = array();
        $wstorage = '';
        $wproduct = '';
        $wproductcat = '';
        $date = "Date(gwis_master.tran_date) BETWEEN '$startdate' AND '$enddate'";
        if(!empty($storage))
        {
            $wstorage = " AND gwis_detail.storage = '$storage'";
        }
        if(!empty($product))
        {
            $wproduct = " AND stock_batch.item_id = '$product'";
        }
        
        if(!empty($product_category))
        {
            $wproductcat = " AND itminfo_tab.product_type = '$product_category'";
        }
        
        $stkid = $this->get_user_stakeholders();
        
        if($_SESSION['id'] == '1')
        {
            $stklimit = '';
            $join = '';
        }
        else{ 
            //New 
            $stklimit = " AND gwis_master.stk_id IN (".$stkid.")";
            //Old
//            $stklimit = "AND stakeholder_item.stk_id IN (".$stkid.")";
//            $join = " LEFT JOIN stakeholder ON gwis_master.stk_id = stakeholder.stkid
//                    INNER JOIN stakeholder_item ON stakeholder_item.stk_id = stakeholder.stkid";
        }
        
        
        $qry = "SELECT
                        A.*,
                        B.* 
                FROM
                        (
                        SELECT
                                itminfo_tab.itm_name,
                                itminfo_tab.qty_carton,
                                Sum( gwis_detail.quantity ) AS stock_receive,
                                Sum( stock_batch.Qty ) AS Vials,
                                tbl_itemunits.UnitType,
                                product_category.category,
                                product_strength.strength,
                                product_method_type.method_type,
                                stock_batch.batch_expiry,
                                stock_batch.batch_no,
                                stock_batch.batch_id,
                                stakeholder.stkname AS funding_source,
                                SUM( gwis_detail.actual_rec_qty ) AS actual_rec_qty,
                                itminfo_tab.itm_id,
                                stkn.stkname AS stk_name,
                                list_detail.`name` AS `storage`
                        FROM
                                stock_batch
                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType
                                LEFT JOIN product_category ON itminfo_tab.itm_category = product_category.pk_id
                                LEFT JOIN product_method_type ON itminfo_tab.method_type = product_method_type.pk_id
                                LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                                LEFT JOIN stakeholder ON stock_batch.funding_source = stakeholder.stkid
                                INNER JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id 
                                LEFT JOIN stakeholder AS stkn ON gwis_master.stk_id = stkn.stkid
                                INNER JOIN list_detail ON gwis_detail.`storage` = list_detail.pk_id
                                LEFT JOIN users ON gwis_master.created_by = users.pk_id
                        WHERE
                                $date
                                AND gwis_master.status_id IN ( 3 )
                                AND gwis_master.process_status = '$process_status_nmbr_s3'
                                $createdby
                                $wproduct 
                                $wstorage
                                $stklimit
                                $wproductcat
                                     AND stock_batch.wh_id = '".$_SESSION['warehouse_id']."'
                        GROUP BY
                                itminfo_tab.itm_id 
                        ORDER BY
                                stkn.stkname ASC
                        ) A
                        LEFT JOIN (
                        SELECT
                                SUM(gwis_detail.quantity) AS issue_quantity,
                                itminfo_tab.itm_id 
                        FROM
                                gwis_detail
                                INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
                                INNER JOIN stock_batch ON stock_batch.batch_id = gwis_detail.batch_id
                                INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                                LEFT JOIN tbl_itemunits ON itminfo_tab.itm_type = tbl_itemunits.UnitType 
                        WHERE
                                gwis_master.status_id IN ( 4 ) 
                                AND gwis_master.process_status = '$process_status_nmbr_s4'
                                $wproduct 
                                $wstorage
                                $wproductcat
                                    AND stock_batch.wh_id = '".$_SESSION['warehouse_id']."'
                        GROUP BY
                        itminfo_tab.itm_id 
                        ) B ON A.itm_id = B.itm_id";
//        echo $qry;exit;
        return $this->query($qry);
    }
    
    function updatebatchstatus($batchid,$status) {
//         $attributes = $this->sanitized_attributes();
//        $attribute_pairs = array();
//        foreach ($attributes as $key => $value) {
//            $attribute_pairs[] = "{$key}='{$value}'";
//        }
        $sql = "UPDATE stock_batch SET status = '" .$status."' WHERE batch_id = '" .$batchid."'";
//        echo $sql;exit;
        $this->query2($sql);
        return true;
    }
    
    
    
    public function adjustmenttypesearch($startdate,$enddate,$product, $tran_type,$process_status_nmbr_s3,$process_status_nmbr_s4,$product_category)
    {
        $createdby = '';
        if($_SESSION['id'] == '1')
        {
            $createdby = '';
        }
        else{
            $createdby = " AND gwis_master.created_by = '".$_SESSION['id']."'";
        }
        
        $wproduct = '';
        $wtran_type = '';
        $wproductcat = '';
        $date = "Date(gwis_master.tran_date) BETWEEN '$startdate' AND '$enddate'";
        if(!empty($product))
        {
            $wproduct = " AND stock_batch.item_id = '$product'";
        }
        if(!empty($tran_type))
        {
            $wtran_type = " AND gwis_master.tran_type_id = '$tran_type'";
        }
        if(!empty($product_category))
        {
            $wproductcat = " AND itminfo_tab.product_type = '$product_category'";
        }
        
        $qry = "SELECT
                        stock_batch.batch_expiry,
                        itminfo_tab.itm_name,
                        transaction_types.trans_type,
                        transaction_types.trans_nature,
                        stock_batch.Qty,
                        gwis_detail.quantity AS issue_qty,
                        stock_batch.unit_price,
                        stock_batch.batch_no,
                        product_strength.strength
                FROM
                        gwis_detail
                        INNER JOIN gwis_master ON gwis_detail.fk_stock_id = gwis_master.pk_id
                        INNER JOIN stock_batch ON gwis_detail.batch_id = stock_batch.batch_id
                        INNER JOIN itminfo_tab ON stock_batch.item_id = itminfo_tab.itm_id
                        INNER JOIN transaction_types ON gwis_master.tran_type_id = transaction_types.trans_id
                        LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                        LEFT JOIN users ON gwis_master.created_by = users.pk_id
                        WHERE
                            $date
                            $wproduct
                            $createdby
                            $wproductcat
                            $wtran_type";
//        echo $qry;exit;
        return $this->query($qry);
    }
    
    
    public function consumption_report_search($whid,$year,$month,$province,$district,$stakeholder)
    {
        if($month < 10)
        {
            $fmonth = '0'.$month;
        }
        else if($month >= 10) {
            $fmonth = $month;
        }
        $qry = "SELECT
                        tbl_hf_data.pk_id,
                        tbl_hf_data.item_id,
                        tbl_warehouse.wh_name AS warehouse_name,
                        tbl_locations.LocName AS province_name,
                        tbl_hf_data.warehouse_id,
                        tbl_hf_data.opening_balance,
                        tbl_hf_data.received_balance,
                        tbl_hf_data.issue_balance,
                        tbl_hf_data.closing_balance,
                        tbl_hf_data.adjustment_positive,
                        tbl_hf_data.adjustment_negative,
                        tbl_hf_data.avg_consumption,
                        tbl_hf_data.new,
                        tbl_hf_data.old,
                        tbl_hf_data.reporting_date,
                        tbl_hf_data.created_date,
                        tbl_hf_data.last_update,
                        tbl_hf_data.ip_address,
                        tbl_hf_data.created_by,
                        tbl_hf_data.is_amc_calculated,
                        tbl_hf_data.temp,
                        tbl_hf_data.removals,
                        tbl_hf_data.dropouts,
                        tbl_hf_data.demand,
                        tbl_hf_data.change_pos,
                        tbl_hf_data.change_neg,
                        tbl_hf_data.retrieved,
                        itminfo_tab.itm_name,
                        product_strength.strength,
                        gwis_detail.field6 AS pack_size,
                        tbl_hf_data.arv_patients,
                        tbl_hf_data.total_stock_dcurperiod,
                        tbl_hf_data.quarterly_demand 
                FROM
                        tbl_hf_data
                        INNER JOIN tbl_warehouse ON tbl_hf_data.warehouse_id = tbl_warehouse.wh_id
                        INNER JOIN tbl_locations ON tbl_warehouse.prov_id = tbl_locations.PkLocID
                        INNER JOIN itminfo_tab ON tbl_hf_data.item_id = itminfo_tab.itm_id
                        LEFT JOIN product_strength ON itminfo_tab.strength_id = product_strength.pk_id
                        LEFT JOIN stock_batch ON tbl_hf_data.item_id = stock_batch.item_id
                        LEFT JOIN gwis_detail ON stock_batch.batch_id = gwis_detail.batch_id 
                WHERE
                        tbl_hf_data.warehouse_id = '".$whid."'
                        AND DATE_FORMAT( tbl_hf_data.reporting_date, '%Y-%m' ) = '$year-$fmonth'
                GROUP BY
                        tbl_hf_data.item_id";
//        echo $qry;exit;
        return $this->query($qry);
    }
    public function getgiws_delete_details($detail_id)
    {
        $qry = "SELECT
                       *
                FROM
                        gwis_detail
                WHERE
                        gwis_detail.pk_id = '".$detail_id."'
                        ";
//        echo $qry;exit;
        return $this->query($qry);
    }
}
?>
