<?php
class Manage_stakeholder_model extends CI_model{
	
	public function create($formArray){
		$this->db->insert('stakeholder', $formArray);
		$insert_id = $this->db->insert_id();
		return $insert_id;
	}// end create function

	public function create_user($formArray){
		$this->db->insert('users', $formArray);
		$insert_id = $this->db->insert_id();
		return $insert_id;
	}// end create_user function

	public function all(){
		$this->db->where('stakeholder.is_reporting', 1);
		$this->db->order_by('stakeholder.stkid', 'DESC');
		return $this->db->get('stakeholder')->result_array();
	}// end all function

	public function getDataById($id){
		$data = $this->db->get_where('stakeholder', array('stkid' => $id, 'is_reporting' => 1));
		return $data->result_array();
	}// end getDataById function

	public function update($id, $formArray){
		$this->db->where('stkid', $id);
		$this->db->update('stakeholder', $formArray);
	}// end update function

	public function check_abbreviation($abbreviation){
		$this->db->select('stkid');
		$this->db->from('stakeholder');
		$this->db->where('abbreviation', $abbreviation);
		$result = $this->db->get();
		return $result->result_array();
	}// end check_abbreviation function

	public function delete($id){
		$this->db->set('is_reporting', 0);
		$this->db->where('stkid', $id);
		return $this->db->update('stakeholder');
	}// end delete function
}// end stakeholder_model class
?>