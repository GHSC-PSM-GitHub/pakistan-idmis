<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

//-- check logged user
if (!function_exists('check_login_user')) {

    function check_login_user() {
//                echo '<pre>';print_r($_SESSION);exit;
        $ci = get_instance();
        if ($ci->session->userdata('is_login') != TRUE) {
            $ci->session->sess_destroy();
            redirect(base_url('/'));
        }
    }

}

if (!function_exists('shelf_life')) {

    function shelf_life($start_date, $end_date) {
		$startDate = new DateTime($start_date);
		$endDate = new DateTime($end_date);
		$difference = $endDate->diff($startDate);
		return $difference->y . " years and " . $difference->m." months and ".$difference->d." days ";
    }

}

if (!function_exists('check_power')) {

    function check_power($type) {
        $ci = get_instance();

        $ci->load->model('common_model');
        $option = $ci->common_model->check_power($type);

        return $option;
    }

}

//-- current date time function
if (!function_exists('current_datetime')) {

    function current_datetime() {
        $dt = new DateTime('now', new DateTimezone('Asia/Dhaka'));
        $date_time = $dt->format('Y-m-d H:i:s');
        return $date_time;
    }

}

//-- show current date & time with custom format
if (!function_exists('my_date_show_time')) {

    function my_date_show_time($date) {
        if ($date != '') {
            $date2 = date_create($date);
            $date_new = date_format($date2, "d M Y h A");
            return $date_new;
        } else {
            return '';
        }
    }

}

//-- show current date with custom format
if (!function_exists('my_date_show')) {

    function my_date_show($date) {

        if ($date != '') {
            $date2 = date_create($date);
            $date_new = date_format($date2, "d M Y");
            return $date_new;
        } else {
            return '';
        }
    }

}

if (!function_exists('add_page_js_file')) {

    function add_page_js_file() {
        $ci = & get_instance();
        $class = $ci->router->fetch_class();
        $method = $ci->router->fetch_method();
        $url = "assets/js/$class/$method.js";

        if (is_file($url)) {
            $html = '<script src="' . base_url($url) . '"></script>';
        } else {
            $html = '';
        }

        return $html;
    }

}

if (!function_exists('add_page_custom_js_file')) {

    function add_page_custom_js_file($path = array()) {
        $html = '';
        if (is_array($path)) {
            if (count($path) > 0) {
                foreach ($path as $js) {
                    $url = "assets/js/$js.js";
                    if (is_file($url)) {
                        $html .= '<script src="' . base_url($url) . '"></script>';
                    }
                }
            }
        }

        return $html;
    }

}

if (!function_exists('add_page_css_file')) {

    function add_page_css_file() {
        $ci = & get_instance();
        $class = $ci->router->fetch_class();
        $method = $ci->router->fetch_method();
        $url = "assets/css/$class/$method.css";

        if (is_file($url)) {
            $html = '<link href="' . base_url($url) . '" rel="stylesheet" type="text/css">';
        } else {
            $html = '';
        }
        return $html;
    }

}

if (!function_exists('add_page_custom_css_file')) {

    function add_page_custom_css_file($path = array()) {
        $html = '';
        if (is_array($path)) {
            if (count($path) > 0) {
                foreach ($path as $css) {
                    $url = "assets/css/$css.css";
                    if (is_file($url)) {
                        $html .= '<link href="' . base_url($url) . '" rel="stylesheet" type="text/css">';
                    }
                }
            }
        }

        return $html;
    }

}

if (!function_exists('start_form')) {

    function start_form($name = 'dataentry', $method = 'post', $action = '') {
        $html = '<form method="' . $method . '" id="' . $name . '" name="' . $name . '" action="' . $action . '">';
        return $html;
    }

}

if (!function_exists('end_form')) {

    function end_form() {
        $html = '</form>';
        return $html;
    }

}

if (!function_exists('start_table')) {

    function start_table($id, $columns) {
        $html = '<table id="' . $id . '" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">';
        $html .= "<thead><tr>";
        foreach ($columns as $column) {
            $html .= "<th>" . $column . "</th>";
        }
        $html .= "</tr>
                </thead><tbody>";
        return $html;
    }

}

if (!function_exists('end_table')) {

    function end_table() {
        $html = '</tbody></table>';
        return $html;
    }

}

if (!function_exists('create_display_message')) {

    function create_display_message($msg, $type) {
        $ci = get_instance();

        $html = '';
        $html .= '<h4>' . $msg . '</h4>';
        $html .= '<br>';
        $html .= '<br>';
        if ($type == 'success') {
            $html .= '<i class="ti-check-box text-success" style="color:green;font-size:150px !important;" font-size:150px=""></i>';
        }
        return $html;
    }

}

if (!function_exists('unified_date')) {

    function unified_date($date, $format = 'd/M/Y') {
        $formatted_date = '';
        if (!empty($date) && $date != '0000-00-00')
            $formatted_date = date($format, strtotime($date));
        return $formatted_date;
    }

}

if (!function_exists('create_multi_combo')) {

    function create_multi_combo($name, $data, $sel_val = '') {
        $html = '<select multiple class="form-control" id="' . $name . '" name="' . $name . '" required>';
        if (isset($data)) {
            if (is_object($data)) {
                foreach ($data->result_object() as $row) {
                    $sel = '';
                    if ($sel_val == $row->key) {
                        $sel = "selected=selected";
                    }
                    $html .= "<option value=" . $row->key . " $sel>" . $row->value . "</option>";
                }
            } else {
                foreach ($data as $key => $value) {
                    $sel = '';
                    if ($sel_val == $key) {
                        $sel = "selected=selected";
                    }
                    $html .= "<option value=" . $key . " $sel>" . $value . "</option>";
                }
            }
        }
        $html .= "</select>";
        return $html;
    }

}


if (!function_exists('create_list_combo')) {
    function create_list_combo($name, $id, $sel_val = '', $is_required='required')
    {
        $html = '<select class="form-control searchable" id="' . $name . '" name="' . $name . '" "'.$is_required.'">';
        $html .= '<option value=>Select</option>';

        require_once "application/models/Lists.php";

        $list = new Lists();
        $data = $list->get_list($id);

//        echo '<pre>';
//        print_r($data->result_object());
//        echo '</pre>';
//        exit;
        if (isset($data)) {
            if (is_object($data)) {
                foreach ($data->result_object() as $row) {
                    $sel = '';
                    if ($sel_val == $row->pk_id) {
                        $sel = "selected=selected";
                    }
                    $html .= "<option value=" . $row->pk_id . " $sel>" . $row->name . "</option>";
                }
            }
        }
        $html .= "</select>";
        return $html;
    }
}

if (!function_exists('create_combo')) {

    function create_combo($name, $data, $sel_val = '') {
        $html = '<select class="form-control" id="' . $name . '" name="' . $name . '" required>';
        $html .= '<option value=>Select</option>';
        if (isset($data)) {
            if (is_object($data)) {
                foreach ($data->result_object() as $row) {
                    $sel = '';
                    if ($sel_val == $row->key) {
                        $sel = "selected=selected";
                    }
                    $html .= "<option value=" . $row->key . " $sel>" . $row->value . "</option>";
                }
            } else {
                foreach ($data as $key => $value) {
                    $sel = '';
                    if ($sel_val == $key) {
                        $sel = "selected=selected";
                    }
                    $html .= "<option value=" . $key . " $sel>" . $value . "</option>";
                }
            }
        }
        $html .= "</select>";
        return $html;
    }

}

if (!function_exists('convert_date')) {

    function convert_date($origDate, $format = 'todb') {
        switch ($format) {
            case 'todb':
                $date = str_replace('/', '-', $origDate);
                return date("Y-m-d H:i:s", strtotime($date));
                break;
            case 'toview':
                //$date = str_replace('-', '/', $origDate );
                return date("d/m/Y", strtotime($origDate));
                break;
            default:
                return '';
                break;
        }
    }

}
if (!function_exists('get_reporting_months')) {

    function get_reporting_months($wh_id) {
        $ci = get_instance();

        $ci->load->model('Dataentry2_model');
        $bm = new Dataentry2_model();

        $month = $bm->getReportingStartMonth($wh_id);

        return '<a class="btn btn-danger btn-xs" href="add_cons_hf?wh_id=' . $wh_id . '&date=' . $month . '"><i class="fa fa-pen">&nbsp;</i> ' . $month . ' </a>';
    }

}
if (!function_exists('getlast3months')) {

    function getlast3months($wh_id) {
        $ci = get_instance();
        $ci->load->model('Dataentry2_model');
        $bm = new Dataentry2_model();

        $LastReportDate = $bm->GetLastReportDate($wh_id);
//echo "Hello";
        $data = array();
        if ($LastReportDate != "") {
            $LRD_dt = new DateTime($LastReportDate);
            //Get Pending Report Month
            $NewReportDate = $bm->GetPendingReportMonth($wh_id);
//echo "Hello1";
            if ($NewReportDate != "") {
                $NRD_dt = new DateTime($NewReportDate);
                $data['last_update'] = '<span class="help-block">Last Update: ' . $bm->get_last_update() . '</span>';
                //$do = urlencode("Z" . ($_SESSION['warehouse_id'] + 77000) . '|' . $NRD_dt->format('Y-m-') . '01|1');
                $do = "wh_id=" . $wh_id . "&date=" . $NRD_dt->format('Y-m-') . '01';

                // Show last three months for which date is entered
                $allMonths = '';
                //Get Last 3 Months
                $last3Months = $bm->getlast3months_helper($wh_id);
               // echo "Hello2";
                for ($i = 0; $i < sizeof($last3Months); $i++) {
                    
                    $L3M_dt = new DateTime($last3Months[$i]['MaxDate']);
                    $draftYear = $L3M_dt->format('Y');
                    $draftMonth = $L3M_dt->format('m');
                   
                    
                    //check draft
//                    $draft = $bm->checkDraft($draftMonth, $draftYear, $wh_id);
//                    $do3Months = urlencode("Z" . ($wh_id + 77000) . '|' . $L3M_dt->format('Y-m-') . '01|0');
//
//                    $date_temp = $L3M_dt->format('Y-m-') . '01';
//                    if ((!isset($_REQUEST['request_from']) || $_REQUEST['request_from'] != 'admin') && !empty($_SESSION['is_allowed_im']) && $_SESSION['is_allowed_im'] == '1' && $date_temp >= $_SESSION['im_start_month']) {
//                        //dont show months after enabling of IM module
//                        $allMonths[] = '<span class="help-block">IM is enabled at this warehouse , from ' . date('M-Y', strtotime($_SESSION['im_start_month'])) . '. Therefore data entry screen will be locked from ' . date('M-Y', strtotime($_SESSION['im_start_month'])) . ' and onwards. </span>';
//                    } else {
//                        $url = base_url() . "add_cons?Do=" . $do3Months;
////                                                echo $url;exit;
//                        $data['do3months'] = $do3Months;
//                        $allMonths = "<a href=\"$url;\" onclick=\"openPopUp('$url')\" class=\"btn btn-xs red\">" . $L3M_dt->format('M-Y') . "$draft" . " <i class=\"fa fa-edit\"></i></a>";
//                        $data['all_months'] = $allMonths;
//                    }
                }
                //draft year
                $draftYear = $NRD_dt->format('Y');
                //draft month
                $draftMonth = $NRD_dt->format('m');
                //check draft
                //$draft = $bm->checkDraft($draftMonth, $draftYear, $wh_id);
                //url
                $url = base_url() . "dataentry2/add_cons_hf?" . $do;
                $data['do'] = $do;
//				print_r($do);exit();

                $date_temp2 = $NRD_dt->format('Y-m-') . '01';

                //$new_report_month = " <a href=\"$url\" onclick=\"openPopUp('$url')\" class=\"btn btn-xs green\"> Add " . $NRD_dt->format('M-y') . " Report$draft <i class=\"fa fa-plus\"></i></a> ";
               // $data['new_report_month'] = $new_report_month;

                $allMonths;
                //flag
                $flag1 = TRUE;
            }
        }
        
        return $data;
    }
    
    if (!function_exists('checkmonth')) {
    function checkmonth($wh_id, $rdate) {
        
        $ci = get_instance();
        $ci->load->model('Dataentry2_model');
        $bm = new Dataentry2_model();
        return $bm->check_month($wh_id, $rdate);
		
	}
    }

}

if (!function_exists('pr')) {
    function pr($array)
    {
        echo "<pre>";
        print_r($array);
        echo "</pre>";
        exit;
    }
}
if (!function_exists('create_multi_combo')) {
    function create_multi_combo($name, $data, $sel_val = array())
    {
        $html = '<select multiple class="form-control" id="' . $name . '" name="' . $name . '[]" required>';
        if (isset($data)) {
            if (is_object($data)) {
                foreach ($data->result_object() as $row) {
                    $sel = '';
                    if (in_array($row->key, $sel_val)) {
                        $sel = "selected=selected";
                    }
                    $html .= "<option value=" . $row->key . " $sel>" . $row->value . "</option>";
                }
            } else {
                foreach ($data as $key => $value) {
                    $sel = '';
                    if (in_array($key, $sel_val)) {
                        $sel = "selected=selected";
                    }
                    $html .= "<option value=" . $key . " $sel>" . $value . "</option>";
                }
            }
        }
        $html .= "</select>";
        return $html;
    }
}

if (!function_exists('get_lab_code')) {
    function get_lab_code()
    {
        $ci = get_instance();
        $ci->load->model('patient_lab_master_model');
        $plm = new Patient_lab_master_model();
        return $plm->get_lab_code();
    }
}
if (!function_exists('get_total_lab_patients')) {
    function get_total_lab_patients()
    {
        $ci = get_instance();
        $ci->load->model('patient_lab_master_model');
        $plm = new Patient_lab_master_model();
        return $plm->get_total_patients();
    }
}
if (!function_exists('get_assigned_tests')) {
    function get_assigned_tests()
    {
        $plm = new Patient_lab_master_model();
        return $plm->get_assigned_tests();
    }
}
if (!function_exists('get_pending_tests')) {
    function get_pending_tests()
    {
        $plm = new Patient_lab_master_model();
        return $plm->get_pending_tests();
    }
}
if (!function_exists('get_declared_tests')) {
    function get_declared_tests()
    {
        $plm = new Patient_lab_master_model();
        return $plm->get_completed_tests();
    }
}
if (!function_exists('get_ready_to_verify_tests')) {
    function get_ready_to_verify_tests()
    {
        $plm = new Patient_lab_master_model();
        return $plm->get_ready_to_verify_tests();
    }
}
if (!function_exists('get_mr_no_count')) {
    function get_mr_no_count()
    {
        $pm = new Patients_model();
        $mrcount = $pm->getMrCount();
        $count = 1;
        return str_pad($mrcount+$count, 5, '0', STR_PAD_LEFT);
    }
}

if (!function_exists('convert_date2')) {
    function convert_date2($origDate, $format = 'todb')
    {
        switch ($format) {
            case 'todb':
                $date = explode('/',$origDate);
                return $date[2]."-".$date[0]."-".$date[1];
                break;
            case 'toview':
                //$date = str_replace('-', '/', $origDate );
                return date("d/m/Y", strtotime($origDate));
                break;
            default:
                return '';
                break;
        }
    }
}
