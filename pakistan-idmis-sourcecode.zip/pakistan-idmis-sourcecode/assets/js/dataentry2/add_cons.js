function cal_balance(itemId)
        {

            var y = document.getElementsByClassName('FLDSrcs' + itemId);
            var i;
            var total = 0;
            var totalvar = false;
            for (i = 0; i < y.length; i++) {
                total += parseInt(y[i].value) || 0;
                totalvar = true;
            }
            if (totalvar) {
                document.getElementById('FLDRecv' + itemId).value = (total);
            }

            if (document.getElementById('WHOBLC' + itemId))
                var wholbc = (document.getElementById('WHOBLC' + itemId).value == "") ? 0 : parseInt(document.getElementById('WHOBLC' + itemId).value);
            else
                var wholbc = 0;
            if (document.getElementById('WHOBLA' + itemId))
                var wholba = (document.getElementById('WHOBLA' + itemId).value == "") ? 0 : parseInt(document.getElementById('WHOBLA' + itemId).value);
            else
                var wholba = 0;
            if (document.getElementById('WHRecv' + itemId))
                var WHRecv = (document.getElementById('WHRecv' + itemId).value == "") ? 0 : parseInt(document.getElementById('WHRecv' + itemId).value);
            else
                var WHRecv = 0;
            if (document.getElementById('IsuueUP' + itemId))
                var IsuueUP = (document.getElementById('IsuueUP' + itemId).value == "") ? 0 : parseInt(document.getElementById('IsuueUP' + itemId).value);
            else
                var IsuueUP = 0;
            //WH adj+
            if (document.getElementById('ReturnTo' + itemId))
                var ReturnTo = (document.getElementById('ReturnTo' + itemId).value == "") ? 0 : parseInt(document.getElementById('ReturnTo' + itemId).value);
            else
                var ReturnTo = 0;
            //WH adj-
            if (document.getElementById('Unusable' + itemId))
                var Unusable = (document.getElementById('Unusable' + itemId).value == "") ? 0 : parseInt(document.getElementById('Unusable' + itemId).value);
            else
                var Unusable = 0;
            if (document.getElementById('FLDOBLC' + itemId))
                var fldolbc = (document.getElementById('FLDOBLC' + itemId).value == "") ? 0 : parseInt(document.getElementById('FLDOBLC' + itemId).value);
            else
                var fldolbc = 0;
            if (document.getElementById('FLDOBLA' + itemId))
                var fldolba = (document.getElementById('FLDOBLA' + itemId).value == "") ? 0 : parseInt(document.getElementById('FLDOBLA' + itemId).value);
            else
                var fldolba = 0;
            if (document.getElementById('FLDRecv' + itemId))
                var FLDRecv = (document.getElementById('FLDRecv' + itemId).value == "") ? 0 : parseInt(document.getElementById('FLDRecv' + itemId).value);
            else
                var FLDRecv = 0;
            if (document.getElementById('FLDIsuueUP' + itemId))
                var FLDIsuueUP = (document.getElementById('FLDIsuueUP' + itemId).value == "") ? 0 : parseInt(document.getElementById('FLDIsuueUP' + itemId).value);
            else
                var FLDIsuueUP = 0;
            /*if(document.getElementById('FLDmyavg'+itemId))	
             var FLDmyavg = (document.getElementById('FLDmyavg'+itemId).value=="")? 0 : parseInt(document.getElementById('FLDmyavg'+itemId).value);
             else
             var FLDmyavg = 0;*/
            //Fld adj+
            if (document.getElementById('FLDReturnTo' + itemId))
                var FLDReturnTo = (document.getElementById('FLDReturnTo' + itemId).value == "") ? 0 : parseInt(document.getElementById('FLDReturnTo' + itemId).value);
            else
                var FLDReturnTo = 0;
            //Fld adj-
            if (document.getElementById('FLDUnusable' + itemId))
                var FLDUnusable = (document.getElementById('FLDUnusable' + itemId).value == "") ? 0 : parseInt(document.getElementById('FLDUnusable' + itemId).value);
            else
                var FLDUnusable = 0;
            /*if(document.getElementById('FLDmyavg'+itemId))
             {
             var myavg = document.getElementById('FLDmyavg'+itemId).value;
             }
             else {
             var myavg = document.getElementById('myavg'+itemId).value;
             }
             var mycalavg = myavg.split('-');
             if(document.getElementById('FLDIsuueUP'+itemId))
             var divisible = parseInt(mycalavg[1]+FLDIsuueUP);
             else
             var divisible = parseInt(mycalavg[1]+IsuueUP);
             var divider = parseInt(mycalavg[0]+1);
             if(parseInt(divider)>0)
             {
             var myactualavg = parseInt(divisible)/parseInt(divider);
             }
             else {
             var myactualavg = parseInt(divisible)/1;
             }*/
            if (document.getElementById('WHCBLC' + itemId))
                document.getElementById('WHCBLC' + itemId).value = (wholbc + WHRecv + ReturnTo) - (IsuueUP + Unusable);
            if (document.getElementById('WHCBLA' + itemId))
                document.getElementById('WHCBLA' + itemId).value = (wholba + WHRecv + ReturnTo) - (IsuueUP + Unusable);
            if (document.getElementById('MOS' + itemId) && document.getElementById('WHCBLA' + itemId))
            {
                if (parseInt(myactualavg) > 0)
                {
                    document.getElementById('MOS' + itemId).value = roundNumber(parseInt(document.getElementById('WHCBLA' + itemId).value) / parseInt(myactualavg), 1);
                } else {
                    document.getElementById('MOS' + itemId).value = roundNumber(parseInt(document.getElementById('WHCBLA' + itemId).value) / 1, 1);
                }
            }
            if (document.getElementById('FLDCBLC' + itemId))
                document.getElementById('FLDCBLC' + itemId).value = (fldolbc + FLDRecv + FLDReturnTo) - (FLDIsuueUP + FLDUnusable);
            if (document.getElementById('FLDCBLA' + itemId))
                document.getElementById('FLDCBLA' + itemId).value = (fldolba + FLDRecv + FLDReturnTo) - (FLDIsuueUP + FLDUnusable);
            if (document.getElementById('FLDMOS' + itemId) && document.getElementById('FLDCBLA' + itemId))
            {
                if (parseInt(myactualavg) > 0)
                {
                    document.getElementById('FLDMOS' + itemId).value = roundNumber(parseInt(document.getElementById('FLDCBLA' + itemId).value) / parseInt(myactualavg), 1);
                } else {
                    document.getElementById('FLDMOS' + itemId).value = roundNumber(parseInt(document.getElementById('FLDCBLA' + itemId).value) / 1, 1);
                }
            }
        }

        function formvalidate()
        {
            var arrlength = document.frmaddF7.itmrec_id.length;
            var firstrec = document.frmaddF7.itmrec_id[0].value;
            var firstval = firstrec.split('-');
            var atLeastOneEntry = false;
            var fldAtLeastOneEntry = false;
            var fldExists = false;
            for (var i = 0; i < arrlength; i++)
            {
                var fieldval = document.frmaddF7.itmrec_id[i].value;
                fieldconcat = fieldval.split('-');
                var whobla = 'WHOBLA' + fieldconcat[1];
                var whrecv = 'WHRecv' + fieldconcat[1];
                var whissue = 'IsuueUP' + fieldconcat[1];
                var fldobla = 'FLDOBLA' + fieldconcat[1];
                var fldrecv = 'FLDRecv' + fieldconcat[1];
                var fldissue = 'FLDIsuueUP' + fieldconcat[1];
                if ((document.getElementById(whobla).value != 0 || document.getElementById(whobla).value != ''))
                {
                    if (document.getElementById(whrecv).value == 0 || document.getElementById(whrecv).value == '')
                    {
                        alert('Please Enter Recieved');
                        document.getElementById(whrecv).focus();
                        return false;
                    }
                    if (document.getElementById(whissue).value == 0 || document.getElementById(whissue).value == '')
                    {
                        alert('Please Enter Recieved');
                        document.getElementById(whissue).focus();
                        return false;
                    }
                }
                if ((document.getElementById(whobla).value != 0 || document.getElementById(whobla).value != ''))
                {
                    atLeastOneEntry = true;
                    break;
                }
            }
            if (atLeastOneEntry == false)
            {
                alert('Please Enter Atleast one Entry');
                document.getElementById('WHOBLA' + firstval[1]).focus();
                return false;
            }
        }