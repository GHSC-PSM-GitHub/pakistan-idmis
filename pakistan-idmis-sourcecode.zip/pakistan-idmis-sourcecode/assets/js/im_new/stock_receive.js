$(function () {
    deleterv();
    function deleterv() {
        $("button[id$='-deleterv']").click(function () {
            if (confirm("Are you sure you want to remove?")) {
                var value = $(this).attr("id");
                var params = value.replace("-deleterv", "");
                var arr = params.split("_");

                $.ajax({
                    type: "GET",
                    url: "ajax_delgsi",
                    data: {
                        'pk_id': arr[0], 'fk_stock_id': arr[1], 'batch_id': arr[2], 'quantity': arr[3]
                    },
                    dataType: "html",
                    success: function (data) {
                        
                        window.location.href = "stock_receive";
                        $(btn).closest('tr').fadeOut("slow");
                    }
                });
            }
        });
    }

    $("#stock_receive").validate({
        rules: {
            refernce_number: "required",
            receiving_time: "required",
            received_from: "required",
            product: "required",
            manufacturer: "required",
            batch_number: "required",
            expiry_date: "required",
            quantity: "required",
        },
    });
    $("#receiving_time").datepicker({
        minDate: 0,
        maxDate: "+10Y",
        dateFormat: "dd/mm/yy",
        changeMonth: true,
        changeYear: true,
    });
    $("#expiry_date").change(function () {
        var exp = $("#expiry_date").val();
        var man = $("#manufacturing_date").val();
        var mdy = exp.split("/");
        var exp2 = new Date(mdy[2], mdy[0] - 1, mdy[1]);
        var mdy2 = man.split("/");
        var man2 = new Date(mdy2[2], mdy2[0] - 1, mdy2[1]);
        var today = new Date();

        var diff = Math.round((exp2 - man2) / (1000 * 60 * 60 * 24));
        var diff2 = Math.round((exp2 - today) / (1000 * 60 * 60 * 24));
        var shelf_life = 0;
        if (diff != "undefined" && diff != "NaN" && diff > 0) {
            if (diff2 != "undefined" && diff2 != "NaN" && diff2 > 0) {
                shelf_life = Math.round((diff2 * 100) / diff);
                var msgg =
                        "This batch will expire in :" +
                        diff2 +
                        " days. Shelf life is:" +
                        shelf_life +
                        "%";
                if (shelf_life != "undefined" && shelf_life >= 85) {
                    alertify.success(msgg);
                    $("#msg_shelf_text").html("").html(msgg);
                    $("#msg_shelf").slideUp();
                } else {
                    alertify.error(msgg);
                    $("#msg_shelf_text").html("").html(msgg);
                    $("#msg_shelf").slideDown();
                }
            }
        }
        //alertify.success("Exp "+exp+",exp2:"+exp2+",man:"+man+",diff:"+diff+", diff frm today"+diff2+" , shelf life:"+(diff2*100/diff));
        //
    });
    $("#manufacturing_date").change(function () {
        //alertify.success("manufacturing_date changed.");
        //          $('#msg_shelf').show();
    });

    $("#expiry_date").datepicker({
        minDate: "0",
        maxDate: "+10Y",
        defaultDate: new Date(),
        dateFormat: "dd/mm/yyyy",
        changeMonth: true,
        changeYear: true,
    });

    $("#manufacturing_date").datepicker({
        minDate: "-10Y",
        maxDate: "0",
        defaultDate: new Date(),
        dateFormat: "dd/mm/yyyy",
        changeMonth: true,
        changeYear: true,
    });
    $("#save_temp_receive").click(function () {
        $.ajax({
            type: "POST",
            url: "save_temporary_records",
            data: {
                stock_master_id: $("#stock_master_id").val(),
            },
            dataType: "html",
            success: function (data) {
                window.location.href = "stock_receive_search";
            },
        });
    });
});

$("#receiving_time, #manufacturing_date, #expiry_date").datepicker({
    dateFormat: "dd/mm/yy",
});

function calc() {
    var qty = $("#quantity").val();
    var unitprice = $("#unit_price").val();
    $("#amount").val(qty * unitprice);
}

$("#product").change(function () {
    var product = $("#product").val();
    $.ajax({
        type: "POST",
        url: "get_product_unit",
        data: {
            item_id: product,
        },
        dataType: "html",
        success: function (data) {
            $("#prod_unit").html(data);
        },
    });
});
