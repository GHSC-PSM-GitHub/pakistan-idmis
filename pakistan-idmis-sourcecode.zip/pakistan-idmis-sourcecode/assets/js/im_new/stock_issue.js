$(function () {
  $("#batch").change(function () {
    var batch_id = $("#batch").val();
    $.ajax({
      type: "POST",
      url: "get_batch_info",
      data: {
        batch_id: batch_id,
      },
      dataType: "json",
      success: function (data) {
        $("#available_quantity").val(data.available_qty);
        $("#quantity").attr("max", data.available_qty);
        $("#batch_expiry").val(data.expiry_date);
      },
    });
  });


	$("#receiving_time").datepicker();

   $("button[id$='-deletegsi']").click(function(e){
       //    e.preventDefault(); 
           let available_qty = $('#available_quantity').val(); 
           var value = $(this).attr("id");
           var params = value.replace("-deletegsi", "");
           var arr = params.split('_');
           var btn = this;

           $.ajax({
             type: "POST",
             url: base_url_site+"/im_new/ajax_delgsi",
             cache: false,
             data: {'pk_id': arr[0],'fk_stock_id': arr[1],'batch_id': arr[2],'quantity': arr[3]}, // since, you need to delete post of particular id
             success: function(reaksi) {
                if (reaksi){
                   alert("Record Deleted Successfully.");
                   let new_quantity = parseInt(available_qty.toString())+parseInt(arr[3].toString());
                   $('#available_quantity').val(new_quantity.toString());
                   $(btn).closest('tr').fadeOut("slow");
//                   $("#dc_result").html(reaksi);
                } else {
                    alert("ERROR");
                }
              }
          });
       });

  $("#office_change").change(function () {
    var office_id = $("#office_change").val();
      $("#center_patient").empty();
      $("#center_patient").html('<option value="">Select</option>');
      $("#center_patient").select2().select2('val','').change();
      
     if(office_id == ""){
      $('#province_div').hide();
      $("#province_change_office").select2().select2('val','').change();
      $('#district_change_office').empty();
      $('#district_change_office').html('<option value="">Select</option>');
      $("#center_patient").empty();
      $("#center_patient").html('<option value="">Select</option>');
 
     }else{
      $('#province_div').show();
     }
     $('#district_div').hide();
      
      $("#province_change_office").select2().select2('val','');
      $('#district_change_office').empty();
      $('#district_change_office').html('<option value="">Select</option>');
    
  });

   

   $("#receiving_times").datepicker({
       format: 'dd/mm/yyyy',
       autoclose: true,
   }).on('changeDate', function (selected) {
       var minDate = new Date(selected.date.valueOf());
       $('#receiving_times').datepicker('setStartDate', minDate);
   });
  $("#province_change_office").change(function () {
    let province_id = $("#province_change_office").val();
     $("#center_patient").select2().select2('val','').change();
    let office_id = $("#office_change").val();
        if(office_id == 3){
          $.ajax({
            type: "POST",
            url: "get_office_centers",
            data: {
              prov_id: province_id,
              office_id: office_id
            },
            dataType: "html",
            success: function (data) {
              console.log(data);
              $("#center_patient").empty();
              $("#center_patient").html(data);
            },
          });
      }else{
      
  			$.ajax({
  				type: "POST",
  				url: base_url_site+'/ajax/combo_village',
  				data: {
  					id: province_id,
  					lvl: 4
  				},
  				dataType: 'html',
  				success: function(data) {
  					$('#district_change_office').html(data);
            $('#district_div').show();
  				}
  			});
      
      }
    });


   $(".issue_batch_stock").change(function () {
               var batch_id = $("#issue_batch_stock").val();
               if(batch_id == '')
               {
                   batch_id = $("#editbatchid").val();
               }

            $.ajax({
                type: "POST",
                url: base_url_site+'/im_new/get_batch_info',
                data: {
                    batch_id: batch_id
                },
                dataType: 'json',
                success: function (data) {
                    $('#show_expiry_date').fadeIn();
                    $("#show_expiry_date").prop('required',true);
                    if(data.reorder_date)
                    {
                        $('#show_expiry_date').fadeOut();
                        $("#show_expiry_date").prop('required',false);
                        $('#show_reorder_date').fadeIn();
                        $("#show_reorder_date").prop('required',true);
                    }
                    else
                    {
                        $('#show_reorder_date').fadeOut();
                        $("#show_reorder_date").prop('required',false);
                    }
//                    alert(data.available_qty);
                    $("#available_quantity").val(Number(data.available_qty).toString());
                    $("#batch_expiry").val(data.expiry_date);
                    $("#reorder_date").val(data.reorder_date);
                    $("#unit_price").val(data.unit_price);
                    $("#conversion_rate").val(data.conversion_rate);
                    $("#currency").val(data.currency).change();
                    $("#actual_rec_qty").val(data.actual_rec_qty);
//                    $("#wh_location").val(data.wh_location);
//                    $("#storage_info").val(data.storage);
                    $("#storage_id").val(data.storage_id);
                    $("#storage_info").select2().select2('val',data.storage_id);
                }
            });
//            
        }).change();

  $("#driver_date").datepicker({
       format: 'dd/mm/yyyy',
       autoclose: true,
   }).on('changeDate', function (selected) {
       var minDate = new Date(selected.date.valueOf());
       $('#driver_date').datepicker('setStartDate', minDate);
   });
  $("#siv_mode_of_transport").change(function () {
        let mode_of_transport = $("#siv_mode_of_transport").val();
        $('.transport_mode_div').empty();
        if(mode_of_transport == 'Official Vehicle'){
           $('.transport_mode_div').append('<div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_name" required>Driver Name </label><div class="controls"> <input type="text" name="driver_names" id="driver_names" class="form-control" value="" ></div></div></div><div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_name" required>  CNIC </label><div class="controls"> <input type="text" name="driver_cnic" id="driver_cnic" maxlength="13" class="form-control" value="" ></div></div></div><div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_name" required> Contact</label><div class="controls"> <input type="text" name="driver_contact" id="driver_contact" class="form-control" value="" ></div></div></div><div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_name" required> Vehicle # </label><div class="controls"> <input type="text" name="driver_vehicle" id="driver_vehicle" class="form-control" value="" ></div></div></div> ');
        }else if(mode_of_transport == 'Self'){
          $('.transport_mode_div').append('<div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_name" required> Name </label><div class="controls"> <input type="text" name="driver_names" id="driver_names" class="form-control" value="" ></div></div></div><div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_name" required>  Designation </label><div class="controls"> <input type="text" name="driver_designation" id="driver_designation" class="form-control" value="" ></div></div></div><div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_name" required> CNIC</label><div class="controls"> <input type="text" name="driver_cnic" maxlength="13" id="driver_cnic" class="form-control" value="" ></div></div></div><div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_contact" required> Mobile </label><div class="controls"> <input type="text" name="driver_contact" id="driver_contact" class="form-control" value="" ></div></div></div> ');
        }else if(mode_of_transport == 'Courier service'){
          $('.transport_mode_div').append('<div class="col-md-3"><div class="control-group"><label class="example-text-input" for="service_name" required> Service Name </label><div class="controls"> <input type="text" name="service_name" id="service_name" class="form-control" value="" ></div></div></div><div class="col-md-3"><div class="control-group"><label class="example-text-input" for="consignment_no" required> Consignment No</label><div class="controls"> <input type="text" name="consignment_no" id="consignment_no" class="form-control" value="" ></div></div></div> ');
        }else if(mode_of_transport == 'Goods Forwarding Agency'){
          $('.transport_mode_div').append('<div class="col-md-3"><div class="control-group"><label class="example-text-input" for="agency_name" required> Agency Name </label><div class="controls"> <input type="text" name="agency_name" id="agency_name" class="form-control" value="" ></div></div></div><div class="col-md-3"><div class="control-group"><label class="example-text-input" for="driver_reference" required> Reference</label><div class="controls"> <input type="text" name="driver_reference" id="driver_reference" class="form-control" value="" ></div></div></div> ');
        }
       $("#driver_date").datepicker({
       format: 'dd/mm/yyyy',
       autoclose: true,
       }).on('changeDate', function (selected) {
           var minDate = new Date(selected.date.valueOf());
           $('#driver_date').datepicker('setStartDate', minDate);
       });

  });



  $("#district_change_office").change(function () {
    let district_id = $("#district_change_office").val();
    let province_id = $("#province_change_office").val();
    let office_id = $("#office_change").val();
      $("#center_patient").select2().select2('val','');
        $.ajax({
          type: "POST",
          url: "get_office_centers",
          data: {
            prov_id: province_id,
            office_id: office_id,
            district_id: district_id
          },
          dataType: "html",
          success: function (data) {
            console.log(data);
            $("#center_patient").empty();
            $("#center_patient").html(data);
          },
        });
      });

  $("#stock_issue").validate({
    rules: {
      refernce_number: "required",
      issuance_time: "required",
      product: "required",
      batch: "required",
      expiry_date: "required",
      quantity: {
        required: true,
        number: true,
        max: function(element) {
            return $("#available_quantity").val();
          },
          min:1,
        step: 1,
      },
       driver_contact: {
          number: true,
          minlength: 11,
          maxlength: 11
      },
      driver_cnic: {
          number: true,
          minlength: 13,
          maxlength: 13

      },
    },
  });

  $("#product").change(function () {
    $("#batch").attr("disabled", true);
    var product = $("#product").val();
    var wh_id = $("#center_from").val();
    $.ajax({
      type: "POST",
      url: "get_batches_of_wh",
      data: {
        item_id: product,
        wh_id: wh_id,
      },
      dataType: "html",
      success: function (data) {
        alertify.success("Please select the Batch now.");
        $("#batch").attr("disabled", false);
        $("#batch").html(data);
        $("#batch").trigger("change");
      },
    });
  });

  $("#center_from").change(function () {
    $("#product").attr("disabled", true);
    var id = $(this).val();
    $.ajax({
      type: "POST",
      url: "get_available_prods_of_wh",
      data: {
        wh_id: id,
      },
      dataType: "html",
      success: function (data) {
        if (!data) {
          alertify.error("No Stock available at this center");
        } else {
          //alertify.success("Please select the product now.");
          $("#product").attr("disabled", false);
          $("#product").html(data);
        }
      },
    });
  });
  
  $("#issue_to").change(function () {
    $.ajax({
      type: "POST",
      url: "get_center_patients",
      data: {
        issue_type: $(this).val(),
      },
      dataType: "html",
      success: function (data) {
        $("#center_patient").html(data);
      },
    });
  });
  $("#save_temp_issue").click(function () {
    $.ajax({
      type: "POST",
      url: "save_temporary_records",
      data: {
        stock_master_id: $("#stock_master_id").val(),
      },
      dataType: "html",
      success: function (data) {
        window.location.href = "stock_issue_search";
      },
    });
  });
});

deletepp();
function deletepp() {
  $("button[id$='-deletepp']").click(function () {
    if (confirm("Are you sure you want to remove?")) {
      var value = $(this).attr("id");
      var params = value.replace("-deletepp", "");
      var arr = params.split("_");

      $.ajax({
        type: "POST",
        url: "ajax_del_stock_detail",
        data: {
          b_id: arr[0],
          d_id: arr[1]
        },
        dataType: "html",
        success: function (data) {
          window.location = baseurl + "inventory_management/stock_issue";
        },
      });

    }
  });
}
