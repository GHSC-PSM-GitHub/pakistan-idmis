$(function () {
  $("#product").change(function () {
    $("#batch").attr("disabled", true);
    var product = $("#product").val();
    var wh_id = $("#center_from").val();
    var issuance_limit = $("#product [value=" + product + "]").attr(
      "issuance_limit"
    );
    //console.log(product+'-'+wh_id+'-'+$(this).val()+'-'+issuance_limit);

    $.ajax({
      type: "POST",
      url: "get_batches_of_wh",
      data: {
        item_id: product,
        wh_id: wh_id,
      },
      dataType: "html",
      success: function (data) {
        alertify.success("Please select the Batch now.");
        $("#batch").attr("disabled", false);
        $("#batch").html(data);
      },
    });
  });

  $("#center_from").change(function () {
    $("#product").attr("disabled", true);
    var id = $(this).val();
    $.ajax({
      type: "POST",
      url: "get_available_prods_of_wh",
      data: {
        wh_id: id,
      },
      dataType: "html",
      success: function (data) {
        if (!data) {
          alertify.error("No Stock available at this center");
        } else {
          //alertify.success("Please select the product now.");
          $("#product").attr("disabled", false);
          $("#product").html(data);
        }
      },
    });
  });
  $("#batch").change(function () {
    var batch_id = $("#batch").val();
    $.ajax({
      type: "POST",
      url: "get_batch_info",
      data: {
        batch_id: batch_id,
      },
      dataType: "json",
      success: function (data) {
        $("#available_quantity").val(data.available_qty);
        $("#batch_expiry").val(data.expiry_date);
      },
    });
  });
  $("#issue_to").change(function () {
    $.ajax({
      type: "POST",
      url: "get_center_patients",
      data: {
        issue_type: $(this).val(),
      },
      dataType: "html",
      success: function (data) {
        $("#center_patient").html(data);
      },
    });
  });
  $("#save_temp_issue").click(function () {
    $.ajax({
      type: "POST",
      url: "save_temporary_records",
      data: {
        stock_master_id: $("#stock_master_id").val(),
      },
      dataType: "html",
      success: function (data) {
        window.location.href = "stock_issue_search";
      },
    });
  });
});
