/*
 Navicat Premium Data Transfer

 Source Server         : MySQL
 Source Server Type    : MySQL
 Source Server Version : 100422
 Source Host           : localhost:3306
 Source Schema         : cmu

 Target Server Type    : MySQL
 Target Server Version : 100422
 File Encoding         : 65001

 Date: 30/05/2024 09:30:54
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for age_tetanus
-- ----------------------------
DROP TABLE IF EXISTS `age_tetanus`;
CREATE TABLE `age_tetanus`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `age_tetanus` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `message` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for announcements
-- ----------------------------
DROP TABLE IF EXISTS `announcements`;
CREATE TABLE `announcements`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `sent_by` int NULL DEFAULT NULL,
  `text` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `created_at` datetime NULL DEFAULT current_timestamp,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for announcements_seen
-- ----------------------------
DROP TABLE IF EXISTS `announcements_seen`;
CREATE TABLE `announcements_seen`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `seen_by` int NULL DEFAULT NULL,
  `seen_at` datetime NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for api_requests_log
-- ----------------------------
DROP TABLE IF EXISTS `api_requests_log`;
CREATE TABLE `api_requests_log`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `api_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `data` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `created_at` datetime NULL DEFAULT NULL,
  `user_id` int NULL DEFAULT NULL,
  `response` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `responded_at` datetime NULL DEFAULT NULL,
  `query_run` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `apk_version` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `api_name_index`(`api_name`) USING BTREE,
  INDEX `api_user`(`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for approval_code
-- ----------------------------
DROP TABLE IF EXISTS `approval_code`;
CREATE TABLE `approval_code`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `approval_code` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  `document_id` int NULL DEFAULT NULL,
  `approver_designation` int NULL DEFAULT NULL,
  `level` int NULL DEFAULT NULL,
  `final` int NULL DEFAULT NULL,
  `processid` int NULL DEFAULT NULL,
  `process_status` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for approver_configration
-- ----------------------------
DROP TABLE IF EXISTS `approver_configration`;
CREATE TABLE `approver_configration`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `approve_from` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `approve_to` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for approver_info
-- ----------------------------
DROP TABLE IF EXISTS `approver_info`;
CREATE TABLE `approver_info`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `doc_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `approver` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `approver_code` int NULL DEFAULT NULL,
  `next_code` int NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for assign_approval_to_user
-- ----------------------------
DROP TABLE IF EXISTS `assign_approval_to_user`;
CREATE TABLE `assign_approval_to_user`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NULL DEFAULT NULL,
  `document_id` int NULL DEFAULT NULL,
  `approval_code_id` int NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 250 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for bitool_data
-- ----------------------------
DROP TABLE IF EXISTS `bitool_data`;
CREATE TABLE `bitool_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `Province` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `District` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Facility` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Disease` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `LabTest` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ResultType` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Gender` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `TestCount` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Age` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Week` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Month` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3828 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for categories
-- ----------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for category_field_list
-- ----------------------------
DROP TABLE IF EXISTS `category_field_list`;
CREATE TABLE `category_field_list`  (
  `pk_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` int NULL DEFAULT NULL,
  `field_id` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  `is_mandatory` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 140 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for center_status
-- ----------------------------
DROP TABLE IF EXISTS `center_status`;
CREATE TABLE `center_status`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `status_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for challan_type
-- ----------------------------
DROP TABLE IF EXISTS `challan_type`;
CREATE TABLE `challan_type`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `challan_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for cities
-- ----------------------------
DROP TABLE IF EXISTS `cities`;
CREATE TABLE `cities`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `city_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 100 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for clr_details
-- ----------------------------
DROP TABLE IF EXISTS `clr_details`;
CREATE TABLE `clr_details`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `pk_master_id` int NOT NULL,
  `itm_id` int UNSIGNED NULL DEFAULT NULL,
  `avg_consumption` double NULL DEFAULT NULL,
  `soh_dist` double NULL DEFAULT NULL,
  `soh_field` double NULL DEFAULT NULL,
  `total_stock` double NULL DEFAULT NULL,
  `desired_stock` double NULL DEFAULT NULL,
  `replenishment` double NULL DEFAULT NULL,
  `available_qty` int NULL DEFAULT NULL,
  `approve_qty` int NULL DEFAULT NULL,
  `approval_status` enum('Pending','Denied','Issued','Prov_Approved','Prov_Saved','Dist_Approved','RS_Approved','RS_Saved','Approved') CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT 'Pending',
  `approve_date` datetime NULL DEFAULT NULL,
  `approved_by` int NULL DEFAULT NULL,
  `stock_master_id` int NULL DEFAULT NULL,
  `qty_req_dist_lvl1` double(11, 0) NULL DEFAULT NULL,
  `qty_req_dist_lvl2` double(11, 0) NULL DEFAULT NULL,
  `qty_req_prov` double(11, 0) NULL DEFAULT NULL,
  `qty_req_central` double(11, 0) NULL DEFAULT NULL,
  `remarks_dist_lvl1` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `remarks_dist_lvl2` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `remarks_prov` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `remarks_central` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `received_by_consignee` double(11, 0) NULL DEFAULT NULL,
  `var_req_n_disp` double(11, 0) NULL DEFAULT NULL,
  `var_disp_n_rec` double(11, 0) NULL DEFAULT NULL,
  `remarks_clr7` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `sale_of_last_3_months` double(11, 0) NULL DEFAULT NULL,
  `sale_of_last_month` double(11, 0) NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `pk_master_id`(`pk_master_id`) USING BTREE,
  INDEX `itm_id`(`itm_id`) USING BTREE,
  CONSTRAINT `clr_details_ibfk_1` FOREIGN KEY (`pk_master_id`) REFERENCES `clr_master` (`pk_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 79729 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for clr_details_approval
-- ----------------------------
DROP TABLE IF EXISTS `clr_details_approval`;
CREATE TABLE `clr_details_approval`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `clr_details_id` int NULL DEFAULT NULL,
  `manufacturer` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `carton_size` int NULL DEFAULT NULL,
  `qty_approved` int NULL DEFAULT NULL,
  `is_issued` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for clr_distribution_plans
-- ----------------------------
DROP TABLE IF EXISTS `clr_distribution_plans`;
CREATE TABLE `clr_distribution_plans`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `plan_number` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `prov_id` int NULL DEFAULT NULL,
  `plan_status` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `month` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `year` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `submitted_to` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 573 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for clr_distribution_plans_stk
-- ----------------------------
DROP TABLE IF EXISTS `clr_distribution_plans_stk`;
CREATE TABLE `clr_distribution_plans_stk`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `plan_id` int NULL DEFAULT NULL,
  `stk_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 679 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for clr_master
-- ----------------------------
DROP TABLE IF EXISTS `clr_master`;
CREATE TABLE `clr_master`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `requisition_num` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `requisition_to` int NOT NULL,
  `wh_id` int NOT NULL,
  `stk_id` int NOT NULL,
  `fk_stock_id` int NULL DEFAULT NULL,
  `date_from` date NOT NULL,
  `date_to` date NOT NULL,
  `requested_by` int NOT NULL,
  `requested_on` datetime NOT NULL,
  `approval_status` enum('Pending','Denied','Issued','Issue in Process','RS_Approved','RS_Saved','Prov_Approved','Prov_Saved','Dist_Approved','Approved','Hard_Copy','Hard_Copy_Issued') CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT 'Pending',
  `distribution_plan_id` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `attachment_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `receiving_date` date NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `requisition_num`(`requisition_num`) USING BTREE,
  INDEX `requisition_to`(`requisition_to`) USING BTREE,
  INDEX `wh_id`(`wh_id`) USING BTREE,
  INDEX `stk_id`(`stk_id`) USING BTREE,
  INDEX `date_from`(`date_from`) USING BTREE,
  INDEX `date_to`(`date_to`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8735 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for clr_master_log
-- ----------------------------
DROP TABLE IF EXISTS `clr_master_log`;
CREATE TABLE `clr_master_log`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `master_id` int NULL DEFAULT NULL,
  `requisition_to` int NULL DEFAULT NULL,
  `wh_id` int NULL DEFAULT NULL,
  `requested_by` int NULL DEFAULT NULL,
  `log_timestamp` datetime NULL DEFAULT NULL,
  `approval_status` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `user_id` int NULL DEFAULT NULL,
  `approval_level` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 93 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for clr_patients_tb_seven
-- ----------------------------
DROP TABLE IF EXISTS `clr_patients_tb_seven`;
CREATE TABLE `clr_patients_tb_seven`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `start_date` date NULL DEFAULT NULL,
  `end_date` date NULL DEFAULT NULL,
  `district` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `warehouse_id` int NULL DEFAULT NULL,
  `new_bcptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `replase_bcptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `nr_bcptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `taf_bcptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ltaf_bcptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `others_bcptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `wuth_bcptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_bcptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `new_cdptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `replase_cdptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `nr_cdptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `taf_cdptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ltaf_cdptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `others_cdptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `wuth_cdptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_cdptb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `new_bc_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `replase_bc_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `nr_bc_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `taf_bc_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ltaf_bc_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `others_bc_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `wuth_bc_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_bc_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `new_cd_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `replase_cd_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `nr_cd_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `taf_cd_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ltaf_cd_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `others_cd_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `wuth_cd_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_cd_ep_tb` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_new` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_replase` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_nr` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_taf` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_ltaf` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_others` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_wuth` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_tb_seven` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `male_zero_to_four` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `male_five_to_fourteen` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `female_zero_to_four` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `female_five_to_fourteen` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_regimen_one_ncd` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_regimen_two_bchrone` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_regimen_three_bchrtwo` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_pediatric_all` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 30 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for configuration_info
-- ----------------------------
DROP TABLE IF EXISTS `configuration_info`;
CREATE TABLE `configuration_info`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `conf_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `message` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for containment_info
-- ----------------------------
DROP TABLE IF EXISTS `containment_info`;
CREATE TABLE `containment_info`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `containment_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `message` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for countries
-- ----------------------------
DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries`  (
  `country_id` int NOT NULL,
  `country_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `country_code` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `sorting_order` int NULL DEFAULT NULL,
  PRIMARY KEY (`country_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for daily_weekly_reporting
-- ----------------------------
DROP TABLE IF EXISTS `daily_weekly_reporting`;
CREATE TABLE `daily_weekly_reporting`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `week_start_date` datetime NULL DEFAULT NULL,
  `week_end_date` datetime NULL DEFAULT NULL,
  `district` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `facility_id` int NULL DEFAULT NULL,
  `reporting_date` datetime NULL DEFAULT NULL,
  `reported_non_reported` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `suspected_cases` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `screened_cases` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `confirmed_cases` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `admitted_cases` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `discharged` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `deaths` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `hh_inspected` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `hh_positive` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `containers_inspected` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `containers_positive` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `outside_inspected` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `outside_positive` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `larval_hi` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `larval_ci` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `larval_bi` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `larval_oi` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `male_session` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `male_participants` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `female_session` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `female_participants` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `walks` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `iec_distributed` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `hh_sprayed` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Insecticides_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dosage_and_formulation` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `insecticide_used` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `foging_name_of_insecticides` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `foging_dosage_and_formulation` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `foging_area_covered` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `foging_insecticidal_used` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `training_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `training_male` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `training_female` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `training_total` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `conducted_non_conducted` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `chaired_by_dc_adc` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `meeting_minutes` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `daily_weekly` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `week` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1391 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for data_detail
-- ----------------------------
DROP TABLE IF EXISTS `data_detail`;
CREATE TABLE `data_detail`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `data_master_id` int NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  `years1217` int NULL DEFAULT NULL,
  `years18` int NULL DEFAULT NULL,
  `total` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for data_master
-- ----------------------------
DROP TABLE IF EXISTS `data_master`;
CREATE TABLE `data_master`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `wh_id` int NULL DEFAULT NULL,
  `auto_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `submission_date` datetime NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp,
  `updated_at` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for del_product
-- ----------------------------
DROP TABLE IF EXISTS `del_product`;
CREATE TABLE `del_product`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `generic_name_id` int NULL DEFAULT NULL,
  `generic_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength_id` int NULL DEFAULT NULL,
  `method_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `method_type_id` int NULL DEFAULT NULL,
  `manufacturer` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `manufacturer_id` int NULL DEFAULT NULL,
  `category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  `sub_category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sub_category_id` int NULL DEFAULT NULL,
  `registration_number` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `barcode` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `gtin` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `products_in_packet` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `packet_in_cartons` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  `daily_units_in_single_item` int NULL DEFAULT NULL,
  `issuance_limit` int NULL DEFAULT 0,
  `disease_id` int NULL DEFAULT NULL,
  `from_weight` int NULL DEFAULT NULL,
  `to_weight` int NULL DEFAULT NULL,
  `from_year` int NULL DEFAULT NULL,
  `to_year` int NULL DEFAULT NULL,
  `comments` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `species_id` int NULL DEFAULT NULL,
  `treatment_id` int NULL DEFAULT NULL,
  `pregnant_id` int NULL DEFAULT NULL,
  `pregnant_stage` int NULL DEFAULT NULL,
  `method_type_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `dose_id` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `tablet_id` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `times_a_day` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `dose_a_day` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `no_of_days` int NULL DEFAULT NULL,
  `formula_or_hardcode` int NULL DEFAULT NULL,
  `quantity` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 98 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for del_stock_detail
-- ----------------------------
DROP TABLE IF EXISTS `del_stock_detail`;
CREATE TABLE `del_stock_detail`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `stock_master_id` int NULL DEFAULT NULL,
  `batch_id` int NULL DEFAULT NULL,
  `quantity` bigint NULL DEFAULT NULL,
  `temp` tinyint(1) NULL DEFAULT NULL,
  `next_issuance_date` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `PkDetailID`(`pk_id`) USING BTREE,
  INDEX `fkStockID`(`stock_master_id`) USING BTREE,
  INDEX `BatchID`(`batch_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 114 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for del_stock_master
-- ----------------------------
DROP TABLE IF EXISTS `del_stock_master`;
CREATE TABLE `del_stock_master`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `transaction_date` date NULL DEFAULT NULL,
  `transaction_type_id` int NULL DEFAULT NULL,
  `transaction_reference` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `warehouse_from` int NULL DEFAULT NULL,
  `warehouse_to` int NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `created_on` date NULL DEFAULT NULL,
  `remarks` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `temp` tinyint(1) NULL DEFAULT NULL,
  `linked_transaction` int NULL DEFAULT NULL,
  `issuance_to` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `vials_returned` int NULL DEFAULT NULL,
  `mcc_year` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `is_received` int NULL DEFAULT 0,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `PkStockID`(`pk_id`) USING BTREE,
  INDEX `WHIDFrom`(`warehouse_from`) USING BTREE,
  INDEX `WHIDTo`(`warehouse_to`) USING BTREE,
  INDEX `temp`(`temp`) USING BTREE,
  INDEX `TranTypeID`(`transaction_type_id`) USING BTREE,
  INDEX `TranTypeID_3`(`transaction_type_id`, `warehouse_from`) USING BTREE,
  INDEX `TranTypeID_2`(`transaction_type_id`, `warehouse_from`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 204 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for del_tbl_trans_type
-- ----------------------------
DROP TABLE IF EXISTS `del_tbl_trans_type`;
CREATE TABLE `del_tbl_trans_type`  (
  `trans_id` int NOT NULL AUTO_INCREMENT,
  `trans_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `trans_nature` varchar(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_adjustment` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`trans_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for demographic_disease_analysis
-- ----------------------------
DROP TABLE IF EXISTS `demographic_disease_analysis`;
CREATE TABLE `demographic_disease_analysis`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `location_id` int NULL DEFAULT NULL,
  `location_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `parent_id` int NULL DEFAULT NULL,
  `population` int NULL DEFAULT NULL,
  `disease_burden` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 164 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Table structure for departments
-- ----------------------------
DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'Hospitals Departments' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for depth_info
-- ----------------------------
DROP TABLE IF EXISTS `depth_info`;
CREATE TABLE `depth_info`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `depth_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `message` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for devitalized_info
-- ----------------------------
DROP TABLE IF EXISTS `devitalized_info`;
CREATE TABLE `devitalized_info`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `devitalized_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `message` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for dhis2_punjab_data
-- ----------------------------
DROP TABLE IF EXISTS `dhis2_punjab_data`;
CREATE TABLE `dhis2_punjab_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT COMMENT ' ',
  `field_uid` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `facility_uid` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `period` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `period_type` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `opening_balance` decimal(11, 2) NULL DEFAULT NULL,
  `received_balance` decimal(11, 2) NULL DEFAULT NULL,
  `closing_balance` decimal(11, 2) NULL DEFAULT NULL,
  `issue_balance` decimal(11, 2) NULL DEFAULT NULL,
  `created_on` datetime NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `ind_field`(`field_uid`) USING BTREE,
  INDEX `ind_fac`(`facility_uid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 53235 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for dhis2_tb_data
-- ----------------------------
DROP TABLE IF EXISTS `dhis2_tb_data`;
CREATE TABLE `dhis2_tb_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT COMMENT ' ',
  `field_uid` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `facility_uid` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `datavalue` decimal(11, 2) NULL DEFAULT NULL,
  `period` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `period_type` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_on` datetime NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `ind_field`(`field_uid`) USING BTREE,
  INDEX `ind_fac`(`facility_uid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 53235 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for dhis2_tb_metadata
-- ----------------------------
DROP TABLE IF EXISTS `dhis2_tb_metadata`;
CREATE TABLE `dhis2_tb_metadata`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `system` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `uid` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `code` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `item_type` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `value_type` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `display_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `ind_meta`(`uid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 31 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for disease_detail_info
-- ----------------------------
DROP TABLE IF EXISTS `disease_detail_info`;
CREATE TABLE `disease_detail_info`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `disease_id` int NULL DEFAULT NULL,
  `disease_detail_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `disease_detail_info` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `disease_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 148 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for disease_regimens
-- ----------------------------
DROP TABLE IF EXISTS `disease_regimens`;
CREATE TABLE `disease_regimens`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `disease_id` int NULL DEFAULT NULL,
  `types_of_patient` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `criteria` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `regimen` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 40 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'Field Type\r\n1. Regimens for formula\r\n2. Table Columns' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for diseases
-- ----------------------------
DROP TABLE IF EXISTS `diseases`;
CREATE TABLE `diseases`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `date` date NULL DEFAULT NULL,
  `disease` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `total_cases` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `positive_cases` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `facility_id` int NULL DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `field1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field4` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field5` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field6` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field7` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field8` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field9` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field10` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field11` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field12` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field13` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field14` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `field15` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `test_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `province_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `district_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `tehsil_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `uc_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 79 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for district_action_data_dhis
-- ----------------------------
DROP TABLE IF EXISTS `district_action_data_dhis`;
CREATE TABLE `district_action_data_dhis`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `distcode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `dist_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `fyear` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `fmonth` date NULL DEFAULT NULL,
  `opd` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `fp_clients` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `anc1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `malnurished_anc1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `anc4` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `pnc1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `malnurished_pnc1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `assisted_deliveries` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `c_section` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `normal_deliveries` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `mal_children_low_weight` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `mal_children_short_height` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `mal_children_muac` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `children_rcv_measles_vacc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `children_rcv_3penta_vacc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `women_rcv_tt2_vacc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created_date` date NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3969 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for emr_tabs
-- ----------------------------
DROP TABLE IF EXISTS `emr_tabs`;
CREATE TABLE `emr_tabs`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `tab_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for emr_view_control
-- ----------------------------
DROP TABLE IF EXISTS `emr_view_control`;
CREATE TABLE `emr_view_control`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `stk_id` int NULL DEFAULT NULL,
  `prov_id` int NULL DEFAULT NULL,
  `role_id` int NULL DEFAULT NULL,
  `tab_id` int NULL DEFAULT NULL,
  `emr_view_id` int NULL DEFAULT NULL,
  `control` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 86 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'Tab List\r\n1. Rapid Test\r\n2. Lab Test\r\n3. Pre-examination\r\n4. Clinical Notes\r\n5. Prescription\r\n6. Shift To Ward\r\n7. Patient Discharge\r\n8. Patient Document\r\n\r\nEMR Views\r\n1. Master View\r\n2. BSL View' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for external_systems
-- ----------------------------
DROP TABLE IF EXISTS `external_systems`;
CREATE TABLE `external_systems`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `external_system_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for facility_types
-- ----------------------------
DROP TABLE IF EXISTS `facility_types`;
CREATE TABLE `facility_types`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `facility_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `full_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 32 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for field_list
-- ----------------------------
DROP TABLE IF EXISTS `field_list`;
CREATE TABLE `field_list`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `field_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  `field_id` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `type` int NULL DEFAULT NULL,
  `rank` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_affected_diseases
-- ----------------------------
DROP TABLE IF EXISTS `flood_affected_diseases`;
CREATE TABLE `flood_affected_diseases`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `disease_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `idmis_id` int NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_affected_districts
-- ----------------------------
DROP TABLE IF EXISTS `flood_affected_districts`;
CREATE TABLE `flood_affected_districts`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `dist_id` int NULL DEFAULT NULL,
  `prov_id` int NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_affected_locations
-- ----------------------------
DROP TABLE IF EXISTS `flood_affected_locations`;
CREATE TABLE `flood_affected_locations`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `idmis_location_id` int NULL DEFAULT NULL,
  `parent_id` int NULL DEFAULT NULL,
  `level` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 178 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_affected_population_data
-- ----------------------------
DROP TABLE IF EXISTS `flood_affected_population_data`;
CREATE TABLE `flood_affected_population_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `province_id` int NULL DEFAULT NULL,
  `district_count` int NULL DEFAULT NULL,
  `population_count` int NULL DEFAULT NULL,
  `date` date NULL DEFAULT NULL,
  `created_at` date NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_affected_summary
-- ----------------------------
DROP TABLE IF EXISTS `flood_affected_summary`;
CREATE TABLE `flood_affected_summary`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `province_id` int NULL DEFAULT NULL,
  `districts_count` int NULL DEFAULT NULL,
  `tehsil_count` int NULL DEFAULT NULL,
  `uc_count` int NULL DEFAULT NULL,
  `bmu_count` int NULL DEFAULT NULL,
  `ppm_count` int NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  `tehsil_id` int NULL DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `date` date NULL DEFAULT NULL,
  `created_at` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 164 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_affected_summary_copy
-- ----------------------------
DROP TABLE IF EXISTS `flood_affected_summary_copy`;
CREATE TABLE `flood_affected_summary_copy`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `province_id` int NULL DEFAULT NULL,
  `districts_count` int NULL DEFAULT NULL,
  `tehsil_count` int NULL DEFAULT NULL,
  `uc_count` int NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  `tehsil_id` int NULL DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `date` date NULL DEFAULT NULL,
  `created_at` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 158 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_alert_table
-- ----------------------------
DROP TABLE IF EXISTS `flood_alert_table`;
CREATE TABLE `flood_alert_table`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `river_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `station_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `inflow` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `outflow` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `quantitive_value_forecast` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `quantitive_level_forecast` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `date` date NULL DEFAULT NULL,
  `created_at` date NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_dams_reservoirs_level
-- ----------------------------
DROP TABLE IF EXISTS `flood_dams_reservoirs_level`;
CREATE TABLE `flood_dams_reservoirs_level`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `reservoir_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `max_conservation_level_feet` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `max_conservation_level_maf` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `current_conservation_level_feet` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `current_conservation_level_maf` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `remaining_conservation_level_feet` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `remaining_conservation_level_maf` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `date` date NULL DEFAULT NULL,
  `created_at` date NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_death_injured_data
-- ----------------------------
DROP TABLE IF EXISTS `flood_death_injured_data`;
CREATE TABLE `flood_death_injured_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `province_id` int NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  `death_male_count` int NULL DEFAULT NULL,
  `death_female_count` int NULL DEFAULT NULL,
  `death_child` int NULL DEFAULT NULL,
  `injured_male_count` int NULL DEFAULT NULL,
  `injured_female_count` int NULL DEFAULT NULL,
  `injured_child_count` int NULL DEFAULT NULL,
  `key_level` int NULL DEFAULT NULL,
  `date` date NULL DEFAULT NULL,
  `created_at` date NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_disease_wise_cases_weekly_data
-- ----------------------------
DROP TABLE IF EXISTS `flood_disease_wise_cases_weekly_data`;
CREATE TABLE `flood_disease_wise_cases_weekly_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `disease` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  `cases_count` int NULL DEFAULT NULL,
  `week` int NULL DEFAULT NULL,
  `year` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 256245 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_disease_wise_issued_stock
-- ----------------------------
DROP TABLE IF EXISTS `flood_disease_wise_issued_stock`;
CREATE TABLE `flood_disease_wise_issued_stock`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `rep_date` date NULL DEFAULT NULL,
  `disease_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `itm_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_issued` int NULL DEFAULT NULL,
  `facility_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `LocName` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `PkLocID` int NULL DEFAULT NULL,
  `vlmis_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8192 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_disease_wise_issued_stock_old
-- ----------------------------
DROP TABLE IF EXISTS `flood_disease_wise_issued_stock_old`;
CREATE TABLE `flood_disease_wise_issued_stock_old`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `rep_date` date NULL DEFAULT NULL,
  `disease_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `itm_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_issued` int NULL DEFAULT NULL,
  `facility_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `LocName` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `PkLocID` int NULL DEFAULT NULL,
  `vlmis_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3929 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_flow_data
-- ----------------------------
DROP TABLE IF EXISTS `flood_flow_data`;
CREATE TABLE `flood_flow_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `dam_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `reservoir_level` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `storage_capacity` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `live_storage_maf` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `current_level` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `inflow` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `outflow` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `date` date NULL DEFAULT NULL,
  `created_at` date NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_infrastructure_damages_data
-- ----------------------------
DROP TABLE IF EXISTS `flood_infrastructure_damages_data`;
CREATE TABLE `flood_infrastructure_damages_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `province_id` int NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  `road_count` int NULL DEFAULT NULL,
  `bridge_count` int NULL DEFAULT NULL,
  `death_child` int NULL DEFAULT NULL,
  `live_stock_count` int NULL DEFAULT NULL,
  `key_level` int NULL DEFAULT NULL,
  `date` date NULL DEFAULT NULL,
  `created_at` date NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_infrastructure_damages_house_data
-- ----------------------------
DROP TABLE IF EXISTS `flood_infrastructure_damages_house_data`;
CREATE TABLE `flood_infrastructure_damages_house_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `province_id` int NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  `pd_count` int NULL DEFAULT NULL,
  `fd_count` int NULL DEFAULT NULL,
  `key_level` int NULL DEFAULT NULL,
  `date` date NULL DEFAULT NULL,
  `created_at` date NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_map_legend
-- ----------------------------
DROP TABLE IF EXISTS `flood_map_legend`;
CREATE TABLE `flood_map_legend`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `legend_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `map_color_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `legend_color_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  `legend_map_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 5 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_map_legend_districts
-- ----------------------------
DROP TABLE IF EXISTS `flood_map_legend_districts`;
CREATE TABLE `flood_map_legend_districts`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `legend_id` int NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 88 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Fixed;

-- ----------------------------
-- Table structure for flood_relief_assistance_data
-- ----------------------------
DROP TABLE IF EXISTS `flood_relief_assistance_data`;
CREATE TABLE `flood_relief_assistance_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `province_id` int NULL DEFAULT NULL,
  `benefit_count` int NULL DEFAULT NULL,
  `disbursement_planned_cash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `disbursement_completed_benefits` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `disbursement_completed_cash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `disbursement_balance_cash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `disbursement_balance_percentage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `date` date NULL DEFAULT NULL,
  `created_at` date NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for flood_river_data
-- ----------------------------
DROP TABLE IF EXISTS `flood_river_data`;
CREATE TABLE `flood_river_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `river_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `date` date NULL DEFAULT NULL,
  `created_at` date NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for follow_up
-- ----------------------------
DROP TABLE IF EXISTS `follow_up`;
CREATE TABLE `follow_up`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `follow_up_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for funding_sources
-- ----------------------------
DROP TABLE IF EXISTS `funding_sources`;
CREATE TABLE `funding_sources`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `funding_source_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` tinyint NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for funding_sources_old
-- ----------------------------
DROP TABLE IF EXISTS `funding_sources_old`;
CREATE TABLE `funding_sources_old`  (
  `pk_id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `funding_source_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL COMMENT 'province of warehouse',
  `stakeholder_id` int NULL DEFAULT NULL COMMENT 'stakeholder',
  `tehsil_id` int NULL DEFAULT NULL,
  `uc_id` int NULL DEFAULT NULL,
  `city_id` int NULL DEFAULT NULL,
  `province_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `district_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `uc_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tehsil_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `city_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  `category_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `facility_type_id` int NULL DEFAULT NULL,
  `facility_type_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stakeholder_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `facility_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact_person` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact_designation` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact_number` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `status` tinyint(1) NULL DEFAULT 1,
  `created_by` int NOT NULL DEFAULT 1,
  `created_date` datetime NULL DEFAULT current_timestamp,
  `modified_by` int NOT NULL DEFAULT 1,
  `modified_date` datetime NOT NULL DEFAULT current_timestamp,
  `longitude` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `latitude` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `parent_hospital_id` int NULL DEFAULT NULL,
  `parent_hospital_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'contain information about warehouse' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for gender_info
-- ----------------------------
DROP TABLE IF EXISTS `gender_info`;
CREATE TABLE `gender_info`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for gwis_detail
-- ----------------------------
DROP TABLE IF EXISTS `gwis_detail`;
CREATE TABLE `gwis_detail`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `fk_stock_id` int NULL DEFAULT NULL,
  `batch_id` int NULL DEFAULT NULL,
  `fk_unit_id` int NULL DEFAULT NULL,
  `quantity` double(11, 2) NULL DEFAULT NULL,
  `temp` tinyint(1) NULL DEFAULT NULL,
  `vvm_stage` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `is_received` int NULL DEFAULT NULL,
  `adjustment_type` tinyint(1) NULL DEFAULT NULL,
  `comments` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `manufacturer` int NULL DEFAULT NULL,
  `dc_quantity` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pi_quantity` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pi_comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ti_quantity` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ti_comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `delivery_challan_type` int NULL DEFAULT NULL,
  `challan_type_detail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',
  `driver_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `driver_contract` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `vehicle_reg` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dc_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dc_date` datetime NULL DEFAULT NULL,
  `invoice` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `po_quantity` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `actual_rec_qty` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field1` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field2` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field3` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field4` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field5` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field6` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field7` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field8` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field9` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field10` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field11` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field12` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field13` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field14` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field15` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field16` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field17` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field18` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field19` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field20` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `gwis_adj_status` int NULL DEFAULT NULL,
  `siv_driver_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_contatc_number` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_cnic` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_weight` double NULL DEFAULT NULL,
  `siv_no_of_cartons` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_transportation_po` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_tracking_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `grn_quantity` double(11, 2) NULL DEFAULT NULL,
  `giv_quantity` double(11, 2) NULL DEFAULT NULL,
  `electronic_approval` int NULL DEFAULT NULL,
  `electronic_approval_status` int NULL DEFAULT NULL,
  `detail_active_process` int NULL DEFAULT NULL,
  `date_vehicle_req` datetime NULL DEFAULT NULL,
  `no_of_vehicle` int NULL DEFAULT NULL,
  `type_of_vehicle` int NULL DEFAULT NULL,
  `no_of_cartons` int NULL DEFAULT NULL,
  `value_of_product` int NULL DEFAULT NULL,
  `transport_req_remarks` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `product_type_id` int NULL DEFAULT NULL,
  `temperature_requirement` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pi_type` int NULL DEFAULT NULL,
  `sbtr_dc_rec` int NULL DEFAULT NULL,
  `siv_mode_of_transport` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_name_of_transporter` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_vehicle_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_vehicle_plate_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `wh_location` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `shipment_temprature` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `storage` int NULL DEFAULT NULL,
  `consignment_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `agency_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `builty` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `service_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `origin_of_country` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 47394 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for gwis_detail_bkp
-- ----------------------------
DROP TABLE IF EXISTS `gwis_detail_bkp`;
CREATE TABLE `gwis_detail_bkp`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `fk_stock_id` int NULL DEFAULT NULL,
  `batch_id` int NULL DEFAULT NULL,
  `fk_unit_id` int NULL DEFAULT NULL,
  `quantity` bigint NULL DEFAULT NULL,
  `temp` tinyint(1) NULL DEFAULT NULL,
  `vvm_stage` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `is_received` tinyint NULL DEFAULT NULL,
  `adjustment_type` tinyint(1) NULL DEFAULT NULL,
  `comments` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `manufacturer` int NULL DEFAULT NULL,
  `dc_quantity` int NULL DEFAULT NULL,
  `pi_quantity` int NULL DEFAULT NULL,
  `pi_comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ti_quantity` int NULL DEFAULT NULL,
  `ti_comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `delivery_challan_type` int NULL DEFAULT NULL,
  `challan_type_detail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',
  `driver_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `driver_contract` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `vehicle_reg` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dc_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dc_date` datetime NULL DEFAULT NULL,
  `invoice` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `po_quantity` int NULL DEFAULT NULL,
  `actual_rec_qty` int NULL DEFAULT NULL,
  `field1` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field2` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field3` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field4` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field5` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field6` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field7` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field8` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field9` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field10` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field11` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field12` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field13` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field14` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field15` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field16` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field17` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field18` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field19` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field20` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `gwis_adj_status` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 67 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for gwis_detail_history
-- ----------------------------
DROP TABLE IF EXISTS `gwis_detail_history`;
CREATE TABLE `gwis_detail_history`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `detail_pk_id` int NULL DEFAULT NULL,
  `fk_stock_id` int NULL DEFAULT NULL,
  `batch_id` int NULL DEFAULT NULL,
  `fk_unit_id` int NULL DEFAULT NULL,
  `quantity` double(11, 2) NULL DEFAULT NULL,
  `temp` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `vvm_stage` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `is_received` tinyint NULL DEFAULT NULL,
  `adjustment_type` tinyint(1) NULL DEFAULT NULL,
  `comments` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `manufacturer` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dc_quantity` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pi_quantity` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pi_comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ti_quantity` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ti_comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `delivery_challan_type` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `challan_type_detail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',
  `driver_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `driver_contract` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `vehicle_reg` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dc_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dc_date` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `invoice` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `po_quantity` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `actual_rec_qty` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field1` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field2` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field3` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field4` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field5` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field6` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field7` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field8` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field9` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field10` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field11` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field12` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field13` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field14` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field15` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field16` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field17` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field18` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field19` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `field20` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `gwis_adj_status` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_driver_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_contatc_number` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_cnic` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_weight` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_no_of_cartons` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_transportation_po` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_tracking_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `grn_quantity` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `giv_quantity` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `electronic_approval` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `electronic_approval_status` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `detail_active_process` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `date_vehicle_req` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `no_of_vehicle` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `type_of_vehicle` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `no_of_cartons` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `value_of_product` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `transport_req_remarks` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `product_type_id` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `temperature_requirement` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pi_type` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sbtr_dc_rec` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_mode_of_transport` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_name_of_transporter` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_vehicle_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_vehicle_plate_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `wh_location` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `shipment_temprature` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `storage` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `consignment_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `agency_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `builty` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `service_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `origin_of_country` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 34300 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for gwis_master
-- ----------------------------
DROP TABLE IF EXISTS `gwis_master`;
CREATE TABLE `gwis_master`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `tran_date` datetime NULL DEFAULT NULL,
  `tran_no` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `status_id` int NULL DEFAULT NULL,
  `tran_ref` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `wh_id_from` int NULL DEFAULT NULL,
  `wh_id_to` int NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `approved_by` int NULL DEFAULT NULL,
  `created_on` date NULL DEFAULT NULL,
  `received_remarks` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `temp` tinyint(1) NULL DEFAULT NULL,
  `tr_no` int NULL DEFAULT NULL,
  `linked_tr` int NULL DEFAULT NULL,
  `issued_by` int NULL DEFAULT NULL,
  `is_copied` tinyint NULL DEFAULT 0,
  `shipment_id` int NULL DEFAULT NULL,
  `wh_id_from_supplier` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `shipment_mode` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `attachment_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `method` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `requisition_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `source_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `event` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `po_detail` int NULL DEFAULT NULL,
  `issuance_to` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `mcc_year` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `user_from` int NULL DEFAULT NULL,
  `user_to` int NULL DEFAULT NULL,
  `approve_from` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `approve_to` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `parent_id` int NULL DEFAULT NULL,
  `process_status` int NULL DEFAULT NULL,
  `active_process` int NULL DEFAULT NULL,
  `final_status` int NULL DEFAULT NULL,
  `electronic_approval` int NULL DEFAULT NULL,
  `tran_type_id` int NULL DEFAULT NULL,
  `stk_id` int NULL DEFAULT NULL,
  `inspection_date` date NULL DEFAULT NULL,
  `delivery_location` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `po_cmu_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `po_cmu_date` date NULL DEFAULT NULL,
  `po_gf_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `po_gf_date` date NULL DEFAULT NULL,
  `date_of_receiving` date NULL DEFAULT NULL,
  `air_bill_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `shipment_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `origin_of_country` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `vehicle_type_and_plate` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `consignment_weight` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `file` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `issue_to_info` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL,
  `script_master_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11530 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for header_info
-- ----------------------------
DROP TABLE IF EXISTS `header_info`;
CREATE TABLE `header_info`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `prov_id` int NULL DEFAULT NULL,
  `stk_id` int NULL DEFAULT NULL,
  `logo_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `header_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `report_header` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `report_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `left_logo_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `right_logo_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 36 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hep_cons_data
-- ----------------------------
DROP TABLE IF EXISTS `hep_cons_data`;
CREATE TABLE `hep_cons_data`  (
  `id` int NOT NULL,
  `warehouse_id` int NULL DEFAULT NULL,
  `reporting_date` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Table structure for hiv_formula
-- ----------------------------
DROP TABLE IF EXISTS `hiv_formula`;
CREATE TABLE `hiv_formula`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `item_id` int NULL DEFAULT NULL,
  `pead` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `adult` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `category` enum('first_line_adult','fdc_adult_arv','first_line_peadiatric','second_line_adult') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hr_list
-- ----------------------------
DROP TABLE IF EXISTS `hr_list`;
CREATE TABLE `hr_list`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `f_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `husband_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `cnic` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `facility_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `tehsil_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `dist_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `dist_id` int NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `cell_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `uc` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `centre` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_lhw` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  `deployment` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `working_under` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `bps` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `place_of_posting` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `name_of_post` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL COMMENT 'cmw/lhw/lhs/sba/lhv/facility_incharge',
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1453 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hr_profile
-- ----------------------------
DROP TABLE IF EXISTS `hr_profile`;
CREATE TABLE `hr_profile`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `designation` int NULL DEFAULT NULL,
  `pmdc_number` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `cnic_number` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` tinyint NULL DEFAULT NULL,
  `warehouse_id` int NULL DEFAULT NULL,
  `hr_type_id` int NULL DEFAULT NULL,
  `hr_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `link_user` int NULL DEFAULT NULL,
  `hr_status_id` int NULL DEFAULT NULL,
  `department` int NULL DEFAULT NULL,
  `reg_number` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `pmc_expiry` date NULL DEFAULT NULL,
  `pmc_category` int NULL DEFAULT NULL,
  `blood_group` int NULL DEFAULT NULL,
  `doj` date NULL DEFAULT NULL,
  `job_band` int NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `pcn` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `em_contact` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `em_contact_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `experience` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `education` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `dob` date NULL DEFAULT NULL,
  `gender` int NULL DEFAULT NULL,
  `stakeholder_id` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hr_types
-- ----------------------------
DROP TABLE IF EXISTS `hr_types`;
CREATE TABLE `hr_types`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'Hospitals Departments' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for idmis_explorer
-- ----------------------------
DROP TABLE IF EXISTS `idmis_explorer`;
CREATE TABLE `idmis_explorer`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `list_master_id` int NULL DEFAULT NULL,
  `list_master_parent_id` int NULL DEFAULT NULL,
  `list_detail_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for initial_checkup
-- ----------------------------
DROP TABLE IF EXISTS `initial_checkup`;
CREATE TABLE `initial_checkup`  (
  `pk_id` int NOT NULL,
  `patient_id` int NULL DEFAULT NULL,
  `temprature` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `bp` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `heart_pulse` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `other` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `checkup_date` datetime NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for integrated_lab_data
-- ----------------------------
DROP TABLE IF EXISTS `integrated_lab_data`;
CREATE TABLE `integrated_lab_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `report_date` date NULL DEFAULT NULL,
  `system_id` int NULL DEFAULT NULL,
  `system_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `disease` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `test_result` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `test_json` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `patient_json` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `address_json` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `facility_json` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8781 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for item_dose
-- ----------------------------
DROP TABLE IF EXISTS `item_dose`;
CREATE TABLE `item_dose`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `dose_form` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for item_strength
-- ----------------------------
DROP TABLE IF EXISTS `item_strength`;
CREATE TABLE `item_strength`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `strength` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for itminfo_tab
-- ----------------------------
DROP TABLE IF EXISTS `itminfo_tab`;
CREATE TABLE `itminfo_tab`  (
  `itmrec_id` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `itm_id` int NOT NULL AUTO_INCREMENT,
  `itm_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `generic_name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `method_type` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `method_rank` int NULL DEFAULT NULL,
  `itm_type` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `qty_carton` int NOT NULL DEFAULT 0 COMMENT 'quantity in one carton',
  `field_color` varchar(7) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `itm_des` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `itm_status` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `frmindex` int NOT NULL DEFAULT 0 COMMENT 'not implemented in v1',
  `user_factor` decimal(10, 5) NULL DEFAULT NULL,
  `extra` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `itm_category` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `item_unit_id` int NULL DEFAULT NULL,
  `volume` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `mnch_id` int NULL DEFAULT NULL,
  `lhw_kp_id` int NULL DEFAULT NULL,
  `lhw_punjab_id` int NULL DEFAULT NULL,
  `mnch_kp_id` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `dhis_stock_field` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `drug_reg_num` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `merf_product_id` int NULL DEFAULT NULL,
  `ihs_product_id` int NULL DEFAULT NULL,
  `pphi_product_id` int NULL DEFAULT NULL,
  `hands_product_id` int NULL DEFAULT NULL,
  `manufacturer_id` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `supplier_id` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength_id` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `product_code` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `min_quantity` int NULL DEFAULT NULL,
  `max_quantity` int NULL DEFAULT NULL,
  `reorder_quantity` int NULL DEFAULT NULL,
  `cold_chain_temp` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `product_type` int NULL DEFAULT NULL,
  `barcode` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `pack_size` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `unit` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `carton_size` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `daily_units_in_single_item` int NULL DEFAULT NULL,
  `issuance_limit` int NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  UNIQUE INDEX `itm_id`(`itm_id`) USING BTREE,
  UNIQUE INDEX `itmrec_id`(`itmrec_id`) USING BTREE,
  UNIQUE INDEX `itm_name`(`itm_name`, `strength_id`) USING BTREE,
  INDEX `frmindex`(`frmindex`) USING BTREE,
  INDEX `itm_type`(`itm_type`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1148 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'contain information about product attributes' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lab_test_detail
-- ----------------------------
DROP TABLE IF EXISTS `lab_test_detail`;
CREATE TABLE `lab_test_detail`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `lab_test_master_id` int NULL DEFAULT NULL,
  `lab_test_master_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `test_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `unit` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ref_range_min_male` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_max_male` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_min_female` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_max_female` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_min_general` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_max_general` decimal(11, 2) NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  `sample_type_id` int NULL DEFAULT NULL,
  `sample_type_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT 1,
  `remarks` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 281 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'lab_test_detail' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lab_test_detail_copy1
-- ----------------------------
DROP TABLE IF EXISTS `lab_test_detail_copy1`;
CREATE TABLE `lab_test_detail_copy1`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `lab_test_master_id` int NULL DEFAULT NULL,
  `lab_test_master_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `test_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `unit` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ref_range_min_male` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_max_male` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_min_female` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_max_female` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_min_general` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_max_general` decimal(11, 2) NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  `sample_type_id` int NULL DEFAULT NULL,
  `sample_type_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 141 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'lab_test_detail' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for lab_test_detail_mapping
-- ----------------------------
DROP TABLE IF EXISTS `lab_test_detail_mapping`;
CREATE TABLE `lab_test_detail_mapping`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `system_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `system_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `idmis_lab_detail_id` int NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 69 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lab_test_master
-- ----------------------------
DROP TABLE IF EXISTS `lab_test_master`;
CREATE TABLE `lab_test_master`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `department_id` int NULL DEFAULT NULL,
  `test_name_id` int NULL DEFAULT NULL,
  `sample_collection_type_id` int NULL DEFAULT NULL,
  `sample_collection_type_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `final_result` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `comments` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT current_timestamp,
  `updated_by` int NULL DEFAULT NULL,
  `master_test_short_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 194 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'lab_test_master' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lab_test_master_
-- ----------------------------
DROP TABLE IF EXISTS `lab_test_master_`;
CREATE TABLE `lab_test_master_`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `department_id` int NULL DEFAULT NULL,
  `test_name_id` int NULL DEFAULT NULL,
  `sample_collection_type_id` int NULL DEFAULT NULL,
  `sample_collection_type_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `final_result` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `comments` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT current_timestamp,
  `updated_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 77 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'lab_test_master' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lab_test_name
-- ----------------------------
DROP TABLE IF EXISTS `lab_test_name`;
CREATE TABLE `lab_test_name`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `lab_test_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lab_tests_ranges
-- ----------------------------
DROP TABLE IF EXISTS `lab_tests_ranges`;
CREATE TABLE `lab_tests_ranges`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `wh_id` int NULL DEFAULT NULL,
  `lab_detail_id` int NULL DEFAULT NULL,
  `unit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ref_range_min_male` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ref_range_max_male` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ref_range_min_female` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ref_range_max_female` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ref_range_min_general` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ref_range_max_general` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `ref_range_custom` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 56 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lab_types
-- ----------------------------
DROP TABLE IF EXISTS `lab_types`;
CREATE TABLE `lab_types`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'Hospitals Departments' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for lhw_commodities
-- ----------------------------
DROP TABLE IF EXISTS `lhw_commodities`;
CREATE TABLE `lhw_commodities`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `item_id` int NULL DEFAULT NULL,
  `lhw_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `wh_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `qty` int NULL DEFAULT NULL,
  `district` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `province` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created_at` datetime NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4982 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for list_detail
-- ----------------------------
DROP TABLE IF EXISTS `list_detail`;
CREATE TABLE `list_detail`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `master_id` int NULL DEFAULT NULL,
  `name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `child_id` int NULL DEFAULT NULL,
  `description` varchar(0) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `order` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `list_detail_list_master_id_list_master_fk1`(`master_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 196 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for list_detail_copy1
-- ----------------------------
DROP TABLE IF EXISTS `list_detail_copy1`;
CREATE TABLE `list_detail_copy1`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `master_id` int NULL DEFAULT NULL,
  `name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `child_id` int NULL DEFAULT NULL,
  `description` varchar(0) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `order` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `list_detail_list_master_id_list_master_fk1`(`master_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 179 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for list_master
-- ----------------------------
DROP TABLE IF EXISTS `list_master`;
CREATE TABLE `list_master`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for locations
-- ----------------------------
DROP TABLE IF EXISTS `locations`;
CREATE TABLE `locations`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `location_name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `geo_level_id` int NULL DEFAULT NULL,
  `parent_id` int NULL DEFAULT NULL,
  `location_type_id` int NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  `ccm_location_id` int NULL DEFAULT NULL,
  `sdms_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `dhis_code` int NULL DEFAULT NULL,
  `surveillance_dist_code` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_by` int NOT NULL DEFAULT 1,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `modified_by` int NOT NULL DEFAULT 1,
  `modified_date` timestamp NOT NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT '1',
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `geo_level_id`(`geo_level_id`) USING BTREE,
  INDEX `location_type_id`(`location_type_id`) USING BTREE,
  INDEX `province_id`(`province_id`) USING BTREE,
  INDEX `parent_id`(`parent_id`) USING BTREE,
  INDEX `created_by`(`created_by`) USING BTREE,
  INDEX `modified_by`(`modified_by`) USING BTREE,
  INDEX `district_id`(`district_id`) USING BTREE,
  CONSTRAINT `locations_ibfk_1` FOREIGN KEY (`geo_level_id`) REFERENCES `geo_levels` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `locations_ibfk_2` FOREIGN KEY (`location_type_id`) REFERENCES `location_types` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `locations_ibfk_3` FOREIGN KEY (`province_id`) REFERENCES `locations` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `locations_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `users` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `locations_ibfk_5` FOREIGN KEY (`modified_by`) REFERENCES `users` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `locations_ibfk_6` FOREIGN KEY (`parent_id`) REFERENCES `locations` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `locations_ibfk_7` FOREIGN KEY (`district_id`) REFERENCES `locations` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 10133 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for malaria_formula
-- ----------------------------
DROP TABLE IF EXISTS `malaria_formula`;
CREATE TABLE `malaria_formula`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `item_id` int NULL DEFAULT NULL,
  `children` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `adult` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `above_30` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 125 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for malaria_formula_copy1
-- ----------------------------
DROP TABLE IF EXISTS `malaria_formula_copy1`;
CREATE TABLE `malaria_formula_copy1`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `item_id` int NULL DEFAULT NULL,
  `children` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `adult` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `above_30` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 125 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for marital_status
-- ----------------------------
DROP TABLE IF EXISTS `marital_status`;
CREATE TABLE `marital_status`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `marital_status_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for master_data
-- ----------------------------
DROP TABLE IF EXISTS `master_data`;
CREATE TABLE `master_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `entity_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `entity_pk` int NULL DEFAULT NULL,
  `external_system_id` int NULL DEFAULT NULL,
  `external_pk` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for medicine_lab
-- ----------------------------
DROP TABLE IF EXISTS `medicine_lab`;
CREATE TABLE `medicine_lab`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `lab_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for medicines
-- ----------------------------
DROP TABLE IF EXISTS `medicines`;
CREATE TABLE `medicines`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `generic_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `disease_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for mosscale_tab
-- ----------------------------
DROP TABLE IF EXISTS `mosscale_tab`;
CREATE TABLE `mosscale_tab`  (
  `row_id` int NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `itmrec_id` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `shortterm` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `longterm` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sclstart` float NOT NULL DEFAULT 0 COMMENT 'Scale start at',
  `sclsend` float NOT NULL DEFAULT 0 COMMENT 'scale ends at',
  `extra` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `colorcode` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stkid` int NULL DEFAULT NULL COMMENT 'Foreign Key: Stakeholder',
  `lvl_id` int NULL DEFAULT NULL COMMENT 'Foreign Key: distribution level',
  PRIMARY KEY (`row_id`) USING BTREE,
  INDEX `itmrec_id`(`itmrec_id`) USING BTREE,
  INDEX `shortterm`(`shortterm`) USING BTREE,
  INDEX `fk_Stk`(`stkid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 77 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'contain inforamtion about min/max values of product code etc' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for notified_diseases
-- ----------------------------
DROP TABLE IF EXISTS `notified_diseases`;
CREATE TABLE `notified_diseases`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `disease_short_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `disease_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `stakeholder_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `rank` int NULL DEFAULT NULL,
  `loinc_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 44 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for oxygen_ecosystem
-- ----------------------------
DROP TABLE IF EXISTS `oxygen_ecosystem`;
CREATE TABLE `oxygen_ecosystem`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `date` date NULL DEFAULT NULL,
  `province` int NULL DEFAULT NULL,
  `no_of_hf` int NULL DEFAULT NULL,
  `dispatched_from_wh` int NULL DEFAULT NULL,
  `on_route` int NULL DEFAULT NULL,
  `delivered` int NULL DEFAULT NULL,
  `pending_at_wh` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `updated_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_allocation
-- ----------------------------
DROP TABLE IF EXISTS `patient_allocation`;
CREATE TABLE `patient_allocation`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `date` datetime NULL DEFAULT NULL,
  `wh_id` int NULL DEFAULT NULL,
  `wh_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `consultant_id` int NULL DEFAULT NULL,
  `consultant_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `notes` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `patient_condition` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  `nurse_id` int NULL DEFAULT NULL,
  `nurse_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `bed_no_allocated` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_clinical_notes
-- ----------------------------
DROP TABLE IF EXISTS `patient_clinical_notes`;
CREATE TABLE `patient_clinical_notes`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `checkup_date` datetime NULL DEFAULT NULL,
  `hr_type_id` int NULL DEFAULT NULL,
  `hr_id` int NULL DEFAULT NULL,
  `notes` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  `diagnosis` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `doctor_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_discharge
-- ----------------------------
DROP TABLE IF EXISTS `patient_discharge`;
CREATE TABLE `patient_discharge`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `discharge_id` int NULL DEFAULT NULL,
  `financial_clearance` enum('clear','not_clear') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `discharge_date` datetime NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_documents
-- ----------------------------
DROP TABLE IF EXISTS `patient_documents`;
CREATE TABLE `patient_documents`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `document_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `old_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `created_by` int NULL DEFAULT NULL,
  `created_at` datetime NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 63 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_ipd
-- ----------------------------
DROP TABLE IF EXISTS `patient_ipd`;
CREATE TABLE `patient_ipd`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `admission_date` datetime NULL DEFAULT NULL,
  `ward_id` int NULL DEFAULT NULL,
  `ward_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `notes` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `patient_condition` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_lab_detail
-- ----------------------------
DROP TABLE IF EXISTS `patient_lab_detail`;
CREATE TABLE `patient_lab_detail`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_lab_master_id` int NULL DEFAULT NULL,
  `lab_test_detail_id` int NULL DEFAULT NULL,
  `lab_test_detail_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `lab_test_master_id` int NULL DEFAULT NULL,
  `lab_test_master_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `test_result` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `patient_id` int NULL DEFAULT NULL,
  `patient_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  `verified_date` datetime NULL DEFAULT NULL,
  `verified_by` int NULL DEFAULT NULL,
  `comments` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `unit` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ref_range_min_male` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_max_male` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_min_female` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_max_female` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_min_general` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_max_general` decimal(11, 2) NULL DEFAULT NULL,
  `result` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `app_local_patient_id` int NULL DEFAULT NULL,
  `from_api` tinyint(1) NULL DEFAULT NULL,
  `app_local_test_detail_id` int NULL DEFAULT NULL,
  `app_local_test_master_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 183145 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'patient_lab_detail' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_lab_detail_copy1
-- ----------------------------
DROP TABLE IF EXISTS `patient_lab_detail_copy1`;
CREATE TABLE `patient_lab_detail_copy1`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_lab_master_id` int NULL DEFAULT NULL,
  `lab_test_detail_id` int NULL DEFAULT NULL,
  `lab_test_detail_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `lab_test_master_id` int NULL DEFAULT NULL,
  `lab_test_master_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `test_result` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `patient_id` int NULL DEFAULT NULL,
  `patient_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  `verified_date` datetime NULL DEFAULT NULL,
  `verified_by` int NULL DEFAULT NULL,
  `comments` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `unit` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ref_range_min_male` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_max_male` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_min_female` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_max_female` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_min_general` decimal(11, 2) NULL DEFAULT NULL,
  `ref_range_max_general` decimal(11, 2) NULL DEFAULT NULL,
  `result` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1258 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'patient_lab_detail' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_lab_master
-- ----------------------------
DROP TABLE IF EXISTS `patient_lab_master`;
CREATE TABLE `patient_lab_master`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `patient_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL,
  `province_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  `district_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `tehsil_id` int NULL DEFAULT NULL,
  `tehsil_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `uc_id` int NULL DEFAULT NULL,
  `uc_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `hf_id` int NULL DEFAULT NULL,
  `hf_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `department_id` int NULL DEFAULT NULL,
  `department_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `lab_test_master_id` int NULL DEFAULT NULL,
  `lab_test_master_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `lab_test_master_description` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sample_datetime` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sample_collection_type_id` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sample_collection_type_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  `ordered_date` datetime NULL DEFAULT NULL,
  `ordered_by` int NULL DEFAULT NULL,
  `status_id` int NULL DEFAULT NULL,
  `lab_number` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `file` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `result` enum('Positive','Negative','Pending') CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT 'Pending',
  `value` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `remarks` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `lab_test_code` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `ref_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `app_local_test_master_id` int NULL DEFAULT NULL,
  `app_local_patient_id` int NULL DEFAULT NULL,
  `from_api` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 128722 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'Patients Test Main Table' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_lab_master_copy1
-- ----------------------------
DROP TABLE IF EXISTS `patient_lab_master_copy1`;
CREATE TABLE `patient_lab_master_copy1`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `patient_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL,
  `province_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  `district_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `tehsil_id` int NULL DEFAULT NULL,
  `tehsil_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `uc_id` int NULL DEFAULT NULL,
  `uc_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `hf_id` int NULL DEFAULT NULL,
  `hf_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `department_id` int NULL DEFAULT NULL,
  `department_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `lab_test_master_id` int NULL DEFAULT NULL,
  `lab_test_master_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `lab_test_master_description` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sample_datetime` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sample_collection_type_id` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sample_collection_type_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  `ordered_date` datetime NULL DEFAULT NULL,
  `ordered_by` int NULL DEFAULT NULL,
  `status_id` int NULL DEFAULT NULL,
  `lab_number` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `file` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `result` enum('Positive','Negative','Pending') CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT 'Pending',
  `value` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `remarks` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2125 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'Patients Test Main Table' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_preliminary_exam
-- ----------------------------
DROP TABLE IF EXISTS `patient_preliminary_exam`;
CREATE TABLE `patient_preliminary_exam`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `examination_date` datetime NULL DEFAULT NULL,
  `indicator_id` int NULL DEFAULT NULL,
  `indicator_value` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 204 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_preliminary_exam_bkp
-- ----------------------------
DROP TABLE IF EXISTS `patient_preliminary_exam_bkp`;
CREATE TABLE `patient_preliminary_exam_bkp`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `examination_date` datetime NULL DEFAULT NULL,
  `indicator_id` int NULL DEFAULT NULL,
  `indicator_value` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_prescriptions
-- ----------------------------
DROP TABLE IF EXISTS `patient_prescriptions`;
CREATE TABLE `patient_prescriptions`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `patient_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `medicine_id` int NULL DEFAULT NULL,
  `medicine_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `medicine_type` int NULL DEFAULT NULL,
  `prescribed_quantity` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `issued_quantity` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `batch_id` int NULL DEFAULT NULL,
  `dose` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `method` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `days` int NULL DEFAULT NULL,
  `schedule` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `schedule_start_date` datetime NULL DEFAULT NULL,
  `schedule_end_date` datetime NULL DEFAULT NULL,
  `status` enum('Continue','Discontinued') CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `remarks` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `gwis_detail_id` int NULL DEFAULT NULL,
  `opd_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `disease_id` int NULL DEFAULT NULL,
  `stk_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_rdt
-- ----------------------------
DROP TABLE IF EXISTS `patient_rdt`;
CREATE TABLE `patient_rdt`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `rdt_id` int NULL DEFAULT NULL,
  `result` enum('Pending','Negative','Positive') CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `test_date` timestamp NULL DEFAULT current_timestamp,
  `result_date` datetime NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  UNIQUE INDEX `patient_id`(`patient_id`, `rdt_id`, `result`, `test_date`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 47 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patient_status
-- ----------------------------
DROP TABLE IF EXISTS `patient_status`;
CREATE TABLE `patient_status`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NULL DEFAULT NULL,
  `visit_date` datetime NULL DEFAULT NULL,
  `wh_id` int NULL DEFAULT NULL,
  `wh_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `consultant_id` int NULL DEFAULT NULL,
  `consultant_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `notes` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `diagnosis` int NULL DEFAULT NULL,
  `visit_fees` int NULL DEFAULT NULL,
  `payment_method` int NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patients
-- ----------------------------
DROP TABLE IF EXISTS `patients`;
CREATE TABLE `patients`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `prefix` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `full_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `mr_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `mr_count` int NULL DEFAULT NULL,
  `old_mr_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `date_of_birth` date NULL DEFAULT NULL,
  `marital_status` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `gender` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `nic_no` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `city` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `province` int NULL DEFAULT NULL,
  `district` int NULL DEFAULT NULL,
  `tehsil` int NULL DEFAULT NULL,
  `uc` int NULL DEFAULT NULL,
  `father_guardian_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `mobile_no` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `payment` int NULL DEFAULT NULL,
  `payment_method` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT 1,
  `is_nadra_verified` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int NULL DEFAULT NULL,
  `vaccination_status` int NULL DEFAULT NULL,
  `last_dose_date` date NULL DEFAULT NULL,
  `vaccine_name` int NULL DEFAULT NULL,
  `covid_status` int NULL DEFAULT NULL,
  `oxygen_status` int NULL DEFAULT NULL,
  `date_of_discharge` datetime NULL DEFAULT NULL,
  `discharge_reason` int NULL DEFAULT NULL,
  `discharge_notes` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `stakeholder_id` int NULL DEFAULT 1,
  `landline` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `passport_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `remarks` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `opd_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `cnicg` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `country` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `country_id` int NULL DEFAULT NULL,
  `registration_date` datetime NULL DEFAULT NULL,
  `wh_id` int NULL DEFAULT NULL,
  `wh_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `app_local_patient_id` int NULL DEFAULT NULL,
  `from_api` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 111246 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for patients_copy1
-- ----------------------------
DROP TABLE IF EXISTS `patients_copy1`;
CREATE TABLE `patients_copy1`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `prefix` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `full_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `mr_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `mr_count` int NULL DEFAULT NULL,
  `old_mr_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `date_of_birth` date NULL DEFAULT NULL,
  `marital_status` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `gender` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `nic_no` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `city` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `province` int NULL DEFAULT NULL,
  `district` int NULL DEFAULT NULL,
  `tehsil` int NULL DEFAULT NULL,
  `uc` int NULL DEFAULT NULL,
  `father_guardian_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `mobile_no` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `payment` int NULL DEFAULT NULL,
  `payment_method` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT 1,
  `is_nadra_verified` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int NULL DEFAULT NULL,
  `vaccination_status` int NULL DEFAULT NULL,
  `last_dose_date` date NULL DEFAULT NULL,
  `vaccine_name` int NULL DEFAULT NULL,
  `covid_status` int NULL DEFAULT NULL,
  `oxygen_status` int NULL DEFAULT NULL,
  `date_of_discharge` datetime NULL DEFAULT NULL,
  `discharge_reason` int NULL DEFAULT NULL,
  `discharge_notes` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `stakeholder_id` int NULL DEFAULT 1,
  `landline` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `passport_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `remarks` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `opd_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `cnicg` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 36197 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for person_relation
-- ----------------------------
DROP TABLE IF EXISTS `person_relation`;
CREATE TABLE `person_relation`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `relation_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pims_lab_data
-- ----------------------------
DROP TABLE IF EXISTS `pims_lab_data`;
CREATE TABLE `pims_lab_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `date_created` datetime NULL DEFAULT NULL,
  `test_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `test_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `element_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `test_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `primary_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `district` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `idmis_lab_detail_id` int NULL DEFAULT NULL,
  `wh_id` int NULL DEFAULT NULL,
  `test_count` int NULL DEFAULT NULL,
  `created_at` datetime NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9452 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pims_lab_data_copy1
-- ----------------------------
DROP TABLE IF EXISTS `pims_lab_data_copy1`;
CREATE TABLE `pims_lab_data_copy1`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `date_created` datetime NULL DEFAULT NULL,
  `test_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `test_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `element_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `test_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `primary_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `district` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `idmis_lab_detail_id` int NULL DEFAULT NULL,
  `wh_id` int NULL DEFAULT NULL,
  `test_count` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 945 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for places
-- ----------------------------
DROP TABLE IF EXISTS `places`;
CREATE TABLE `places`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `loc_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `loc_level` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `parent_id` int NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 96 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for po_info
-- ----------------------------
DROP TABLE IF EXISTS `po_info`;
CREATE TABLE `po_info`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `number` int NULL DEFAULT NULL,
  `date` date NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 56 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for pregnant_stage
-- ----------------------------
DROP TABLE IF EXISTS `pregnant_stage`;
CREATE TABLE `pregnant_stage`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `pregnant_stage` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `generic_name_id` int NULL DEFAULT NULL,
  `generic_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength_id` int NULL DEFAULT NULL,
  `method_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `method_type_id` int NULL DEFAULT NULL,
  `manufacturer` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `manufacturer_id` int NULL DEFAULT NULL,
  `category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  `sub_category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sub_category_id` int NULL DEFAULT NULL,
  `registration_number` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `barcode` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `gtin` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `products_in_packet` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `packet_in_cartons` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  `daily_units_in_single_item` int NULL DEFAULT NULL,
  `issuance_limit` int NULL DEFAULT 0,
  `disease_id` int NULL DEFAULT NULL,
  `from_weight` int NULL DEFAULT NULL,
  `to_weight` int NULL DEFAULT NULL,
  `from_year` int NULL DEFAULT NULL,
  `to_year` int NULL DEFAULT NULL,
  `comments` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `species_id` int NULL DEFAULT NULL,
  `treatment_id` int NULL DEFAULT NULL,
  `pregnant_id` int NULL DEFAULT NULL,
  `pregnant_stage` int NULL DEFAULT NULL,
  `method_type_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `dose_id` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `tablet_id` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `times_a_day` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `dose_a_day` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `no_of_days` int NULL DEFAULT NULL,
  `formula_or_hardcode` int NULL DEFAULT NULL,
  `quantity` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 98 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_category
-- ----------------------------
DROP TABLE IF EXISTS `product_category`;
CREATE TABLE `product_category`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_contradicts
-- ----------------------------
DROP TABLE IF EXISTS `product_contradicts`;
CREATE TABLE `product_contradicts`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `generic_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `generic_name_id` int NULL DEFAULT NULL,
  `contrast_product_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_generic_name
-- ----------------------------
DROP TABLE IF EXISTS `product_generic_name`;
CREATE TABLE `product_generic_name`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `generic_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 415 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_manufacturer
-- ----------------------------
DROP TABLE IF EXISTS `product_manufacturer`;
CREATE TABLE `product_manufacturer`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `manufacturer` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_method_type
-- ----------------------------
DROP TABLE IF EXISTS `product_method_type`;
CREATE TABLE `product_method_type`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `method_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 47 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_oldd
-- ----------------------------
DROP TABLE IF EXISTS `product_oldd`;
CREATE TABLE `product_oldd`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `generic_name_id` int NULL DEFAULT NULL,
  `generic_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength_id` int NULL DEFAULT NULL,
  `method_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `method_type_id` int NULL DEFAULT NULL,
  `manufacturer` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `manufacturer_id` int NULL DEFAULT NULL,
  `category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  `sub_category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sub_category_id` int NULL DEFAULT NULL,
  `registration_number` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `barcode` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `gtin` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `products_in_packet` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `packet_in_cartons` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_strength
-- ----------------------------
DROP TABLE IF EXISTS `product_strength`;
CREATE TABLE `product_strength`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `strength` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 121 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for product_sub_category
-- ----------------------------
DROP TABLE IF EXISTS `product_sub_category`;
CREATE TABLE `product_sub_category`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `sub_category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for public_private
-- ----------------------------
DROP TABLE IF EXISTS `public_private`;
CREATE TABLE `public_private`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for quality_desk
-- ----------------------------
DROP TABLE IF EXISTS `quality_desk`;
CREATE TABLE `quality_desk`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `hf_name` int NULL DEFAULT NULL,
  `total_screened` int NULL DEFAULT NULL,
  `total_positive` int NULL DEFAULT NULL,
  `total_negative` int NULL DEFAULT NULL,
  `malaria_pf` int NULL DEFAULT NULL,
  `malaria_pv` int NULL DEFAULT NULL,
  `malaria_mix` int NULL DEFAULT NULL,
  `nagative_slides_sent` int NULL DEFAULT NULL,
  `positive_slides_sent` int NULL DEFAULT NULL,
  `negative_slides_receive` int NULL DEFAULT NULL,
  `positive_slides_receive` int NULL DEFAULT NULL,
  `facility_submitted_slides` int NULL DEFAULT NULL,
  `negative_slides_variance` int NULL DEFAULT NULL,
  `positive_slides_variance` int NULL DEFAULT NULL,
  `remarks` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  `active_id` int NULL DEFAULT 1,
  `district_id` int NULL DEFAULT NULL,
  `year` int NULL DEFAULT NULL,
  `month` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for raw_data_report
-- ----------------------------
DROP TABLE IF EXISTS `raw_data_report`;
CREATE TABLE `raw_data_report`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `batch_number` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `batch_expiry` date NULL DEFAULT NULL,
  `product_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `generic_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `strength` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `method_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `manufacturer` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `prescribed_quantity` bigint NULL DEFAULT NULL,
  `quantity` bigint NULL DEFAULT NULL,
  `transaction_date` date NULL DEFAULT NULL,
  `transaction_reference` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `trans_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `trans_nature` varchar(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `from_wh` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `to_wh` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cnic` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `mr_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `remarks` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `username` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `designation` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `hospital` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5462 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for rdt_list
-- ----------------------------
DROP TABLE IF EXISTS `rdt_list`;
CREATE TABLE `rdt_list`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `rdt_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT 1,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `approved_by` int NULL DEFAULT 1,
  `approved_date` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for req_regimens
-- ----------------------------
DROP TABLE IF EXISTS `req_regimens`;
CREATE TABLE `req_regimens`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `clr_master_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `disease_regimen_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `regimen_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `created_at` datetime NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 43 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for requisition_detail
-- ----------------------------
DROP TABLE IF EXISTS `requisition_detail`;
CREATE TABLE `requisition_detail`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `pk_master_id` int NOT NULL,
  `itm_id` int UNSIGNED NULL DEFAULT NULL,
  `available_qty` int NULL DEFAULT NULL,
  `approval_status` enum('Pending','Denied','Issued','Prov_Approved','Prov_Saved','Dist_Approved','RS_Approved','RS_Saved','Approved') CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT 'Pending',
  `approve_date` datetime NULL DEFAULT NULL,
  `approved_by` int NULL DEFAULT NULL,
  `qty_req_hf` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `qty_req_dist` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `qty_req_prov` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `qty_req_central` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `approve_qty_dist` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `approve_qty_prov` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `remarks_hf` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `remarks_dist` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `remarks_prov` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `remarks_central` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `opening_balance` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `received` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `received_2` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `issued_stock` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `expired` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `closing_balance` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `net_demand` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `buffer_stock` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_demand` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `pk_master_id`(`pk_master_id`) USING BTREE,
  INDEX `itm_id`(`itm_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for requisition_master
-- ----------------------------
DROP TABLE IF EXISTS `requisition_master`;
CREATE TABLE `requisition_master`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `requisition_num` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `requisition_to` int NOT NULL,
  `wh_id` int NOT NULL,
  `stk_id` int NOT NULL,
  `date_from` date NOT NULL,
  `date_to` date NOT NULL,
  `requested_by` int NOT NULL,
  `requested_on` datetime NOT NULL,
  `approval_status` enum('Pending','Denied','Issued','Issue in Process','Approved','hf_updated','Dist_Approved','Prov_Approved') CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT 'Pending',
  `level` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for requisition_module_flow
-- ----------------------------
DROP TABLE IF EXISTS `requisition_module_flow`;
CREATE TABLE `requisition_module_flow`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `action_id` int NULL DEFAULT NULL,
  `can_submit_to` int NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  `prov_id` int NULL DEFAULT NULL,
  `stk_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 55 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Table structure for resource_types
-- ----------------------------
DROP TABLE IF EXISTS `resource_types`;
CREATE TABLE `resource_types`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `resource_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int NOT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `created_by`(`created_by`) USING BTREE,
  INDEX `modified_by`(`modified_by`) USING BTREE,
  CONSTRAINT `resource_types_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `resource_types_ibfk_2` FOREIGN KEY (`modified_by`) REFERENCES `users` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for resource_types_copy
-- ----------------------------
DROP TABLE IF EXISTS `resource_types_copy`;
CREATE TABLE `resource_types_copy`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `resource_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int NOT NULL,
  `modified_date` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `created_by`(`created_by`) USING BTREE,
  INDEX `modified_by`(`modified_by`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for resources
-- ----------------------------
DROP TABLE IF EXISTS `resources`;
CREATE TABLE `resources`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `resource_name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `page_title` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `meta_title` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `meta_description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `rank` int NULL DEFAULT NULL,
  `level` int NULL DEFAULT NULL,
  `parent_id` int NULL DEFAULT NULL,
  `resource_type_id` int NOT NULL,
  `icon_class` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT 1,
  `created_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int NOT NULL DEFAULT 1,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `resource_type_id`(`resource_type_id`) USING BTREE,
  INDEX `resources_created_by_users_pk`(`created_by`) USING BTREE,
  INDEX `resources_created_by_users_pk2`(`modified_by`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 177 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for resources_
-- ----------------------------
DROP TABLE IF EXISTS `resources_`;
CREATE TABLE `resources_`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `resource_name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `page_title` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `meta_title` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `meta_description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `rank` int NULL DEFAULT NULL,
  `level` int NULL DEFAULT NULL,
  `parent_id` int NULL DEFAULT NULL,
  `resource_type_id` int NOT NULL,
  `icon_class` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT 1,
  `created_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int NOT NULL DEFAULT 1,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `resource_type_id`(`resource_type_id`) USING BTREE,
  INDEX `resources_created_by_users_pk`(`created_by`) USING BTREE,
  INDEX `resources_created_by_users_pk2`(`modified_by`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 63 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for resources_old
-- ----------------------------
DROP TABLE IF EXISTS `resources_old`;
CREATE TABLE `resources_old`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `resource_name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `page_title` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `meta_title` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `meta_description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `rank` int NULL DEFAULT NULL,
  `level` int NULL DEFAULT NULL,
  `parent_id` int NULL DEFAULT NULL,
  `resource_type_id` int NOT NULL,
  `icon_class` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `modified_by` int NOT NULL,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Table structure for resources_old_copy1
-- ----------------------------
DROP TABLE IF EXISTS `resources_old_copy1`;
CREATE TABLE `resources_old_copy1`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `resource_name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `page_title` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `meta_title` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `meta_description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `rank` int NULL DEFAULT NULL,
  `level` int NULL DEFAULT NULL,
  `parent_id` int NULL DEFAULT NULL,
  `resource_type_id` int NOT NULL,
  `icon_class` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `modified_by` int NOT NULL,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for role_resources
-- ----------------------------
DROP TABLE IF EXISTS `role_resources`;
CREATE TABLE `role_resources`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `permission` enum('DENY','ALLOW') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'ALLOW',
  `role_id` int NOT NULL,
  `resource_id` int NOT NULL,
  `is_default` int NULL DEFAULT 1,
  `rank` int NULL DEFAULT NULL,
  `view` int NULL DEFAULT NULL,
  `add` int NULL DEFAULT NULL,
  `edit` int NULL DEFAULT NULL,
  `delete` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `role_resources_roles_fk1`(`role_id`) USING BTREE,
  INDEX `role_resources_resources_fk2`(`resource_id`) USING BTREE,
  CONSTRAINT `role_resources_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `role_resources_ibfk_2` FOREIGN KEY (`resource_id`) REFERENCES `resources` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1885 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for role_resources_
-- ----------------------------
DROP TABLE IF EXISTS `role_resources_`;
CREATE TABLE `role_resources_`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `permission` enum('DENY','ALLOW') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'ALLOW',
  `role_id` int NOT NULL,
  `resource_id` int NOT NULL,
  `is_default` int NULL DEFAULT 1,
  `rank` int NULL DEFAULT NULL,
  `view` int NULL DEFAULT NULL,
  `add` int NULL DEFAULT NULL,
  `edit` int NULL DEFAULT NULL,
  `delete` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `role_resources_roles_fk1`(`role_id`) USING BTREE,
  INDEX `role_resources_resources_fk2`(`resource_id`) USING BTREE,
  CONSTRAINT `role_resources__ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles_` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `role_resources__ibfk_2` FOREIGN KEY (`resource_id`) REFERENCES `resources_` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 808 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `role_level` int NULL DEFAULT NULL,
  `role_category_id` int NULL DEFAULT 1 COMMENT 'list master id 29',
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `status` tinyint(1) NULL DEFAULT NULL,
  `landing_resource_id` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `roles_users_fk2`(`created_by`) USING BTREE,
  INDEX `roles_users_fk3`(`modified_by`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 75 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'contain user type information' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for roles_
-- ----------------------------
DROP TABLE IF EXISTS `roles_`;
CREATE TABLE `roles_`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `role_level` int NULL DEFAULT NULL,
  `role_category_id` int NULL DEFAULT 1 COMMENT 'list master id 29',
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `status` tinyint(1) NULL DEFAULT NULL,
  `landing_resource_id` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `modified_by` int NOT NULL,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `roles_users_fk2`(`created_by`) USING BTREE,
  INDEX `roles_users_fk3`(`modified_by`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 29 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'contain user type information' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sample_collection_types
-- ----------------------------
DROP TABLE IF EXISTS `sample_collection_types`;
CREATE TABLE `sample_collection_types`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `type_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci COMMENT = 'sample_collection_types' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sms_log
-- ----------------------------
DROP TABLE IF EXISTS `sms_log`;
CREATE TABLE `sms_log`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `userid` int NULL DEFAULT NULL,
  `sms_time` datetime NULL DEFAULT NULL,
  `message` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `message_to` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 90 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for stakeholder
-- ----------------------------
DROP TABLE IF EXISTS `stakeholder`;
CREATE TABLE `stakeholder`  (
  `stkid` int NOT NULL AUTO_INCREMENT COMMENT 'stakeholder id',
  `stkname` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `merged_stk` int NULL DEFAULT NULL,
  `report_title1` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `report_title2` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `report_title3` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `report_logo` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stkcode` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stkorder` int UNSIGNED NULL DEFAULT NULL COMMENT 'the order in which stakeholder will appear in report or data entry form',
  `ParentID` int NULL DEFAULT NULL,
  `stk_type_id` int NULL DEFAULT 0,
  `lvl` int NULL DEFAULT NULL,
  `MainStakeholder` int NULL DEFAULT NULL,
  `is_reporting` tinyint NULL DEFAULT 1,
  `contact_person` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact_numbers` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact_emails` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact_address` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `company_status` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ntn` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `gstn` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `disease_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `login_background` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `landing_background` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `default_landing_path` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `default_login_path` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `abbreviation` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `landing_text` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `details` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `short_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`stkid`) USING BTREE,
  INDEX `stkid`(`stkid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1929 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'contain information about stakeholders' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for stakeholder_dist
-- ----------------------------
DROP TABLE IF EXISTS `stakeholder_dist`;
CREATE TABLE `stakeholder_dist`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `stk_id` int NULL DEFAULT NULL,
  `location_id` int NULL DEFAULT NULL,
  `screened_patients` int NULL DEFAULT NULL,
  `spr` decimal(11, 2) NULL DEFAULT NULL,
  `no_of_pf` int NULL DEFAULT NULL,
  `no_of_pv` int NULL DEFAULT NULL,
  `no_of_mix` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Table structure for stakeholder_item
-- ----------------------------
DROP TABLE IF EXISTS `stakeholder_item`;
CREATE TABLE `stakeholder_item`  (
  `pk_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `stk_id` int NULL DEFAULT NULL,
  `product_id` int NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  `quantity_per_pack` int NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 17981 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for stakeholder_item_
-- ----------------------------
DROP TABLE IF EXISTS `stakeholder_item_`;
CREATE TABLE `stakeholder_item_`  (
  `pk_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `stk_id` int NULL DEFAULT NULL,
  `product_id` int NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  `quantity_per_pack` int NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8117 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for stakeholder_products
-- ----------------------------
DROP TABLE IF EXISTS `stakeholder_products`;
CREATE TABLE `stakeholder_products`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NULL DEFAULT NULL,
  `stakeholder_id` int NULL DEFAULT NULL,
  `created_date` date NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  UNIQUE INDEX `product_id`(`product_id`, `stakeholder_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 7584 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Fixed;

-- ----------------------------
-- Table structure for stakeholder_type
-- ----------------------------
DROP TABLE IF EXISTS `stakeholder_type`;
CREATE TABLE `stakeholder_type`  (
  `stk_type_id` int NOT NULL DEFAULT 0,
  `stk_type_descr` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`stk_type_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for stock_batch
-- ----------------------------
DROP TABLE IF EXISTS `stock_batch`;
CREATE TABLE `stock_batch`  (
  `batch_id` int NOT NULL AUTO_INCREMENT,
  `batch_no` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `batch_expiry` date NULL DEFAULT NULL,
  `item_id` int NULL DEFAULT NULL,
  `Qty` double(11, 2) NULL DEFAULT NULL,
  `status` enum('Finished','Stacked','Running','Expired') CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'Running',
  `unit_price` float NULL DEFAULT NULL,
  `dollar_rate` float NULL DEFAULT NULL,
  `production_date` date NULL DEFAULT NULL,
  `vvm_type` int NULL DEFAULT NULL,
  `wh_id` int NULL DEFAULT NULL,
  `funding_source` int NULL DEFAULT NULL,
  `manufacturer` int NULL DEFAULT NULL,
  `phy_inspection` varchar(3) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dtl` varchar(3) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dist_plan` varchar(3) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `currency` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `conversion_rate` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dtl_result` int NULL DEFAULT NULL,
  `batch_totalprice` int NULL DEFAULT NULL,
  `dtl_comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dtl_remarks` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dtl_received_date` datetime NULL DEFAULT NULL,
  `dtl_status` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `manufacturer_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pack_size` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `bar_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dosage_form` int NULL DEFAULT NULL,
  PRIMARY KEY (`batch_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4591 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for stock_detail
-- ----------------------------
DROP TABLE IF EXISTS `stock_detail`;
CREATE TABLE `stock_detail`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `stock_master_id` int NULL DEFAULT NULL,
  `batch_id` int NULL DEFAULT NULL,
  `quantity` bigint NULL DEFAULT NULL,
  `temp` tinyint(1) NULL DEFAULT NULL,
  `next_issuance_date` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `PkDetailID`(`pk_id`) USING BTREE,
  INDEX `fkStockID`(`stock_master_id`) USING BTREE,
  INDEX `BatchID`(`batch_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 114 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for stock_document_type
-- ----------------------------
DROP TABLE IF EXISTS `stock_document_type`;
CREATE TABLE `stock_document_type`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `document_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for stock_master
-- ----------------------------
DROP TABLE IF EXISTS `stock_master`;
CREATE TABLE `stock_master`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `transaction_date` date NULL DEFAULT NULL,
  `transaction_type_id` int NULL DEFAULT NULL,
  `transaction_reference` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `warehouse_from` int NULL DEFAULT NULL,
  `warehouse_to` int NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `created_on` date NULL DEFAULT NULL,
  `remarks` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `temp` tinyint(1) NULL DEFAULT NULL,
  `linked_transaction` int NULL DEFAULT NULL,
  `issuance_to` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `vials_returned` int NULL DEFAULT NULL,
  `mcc_year` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `is_received` int NULL DEFAULT 0,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `PkStockID`(`pk_id`) USING BTREE,
  INDEX `WHIDFrom`(`warehouse_from`) USING BTREE,
  INDEX `WHIDTo`(`warehouse_to`) USING BTREE,
  INDEX `temp`(`temp`) USING BTREE,
  INDEX `TranTypeID`(`transaction_type_id`) USING BTREE,
  INDEX `TranTypeID_3`(`transaction_type_id`, `warehouse_from`) USING BTREE,
  INDEX `TranTypeID_2`(`transaction_type_id`, `warehouse_from`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 204 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for summary_district
-- ----------------------------
DROP TABLE IF EXISTS `summary_district`;
CREATE TABLE `summary_district`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `item_id` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `stakeholder_id` int NULL DEFAULT NULL,
  `reporting_date` date NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL,
  `district_id` int NOT NULL,
  `consumption` double NULL DEFAULT NULL,
  `avg_consumption` double NULL DEFAULT NULL,
  `soh_district_store` double NULL DEFAULT NULL,
  `soh_district_lvl` double NULL DEFAULT NULL,
  `dist_reporting_rate` decimal(6, 2) NULL DEFAULT NULL,
  `field_reporting_rate` decimal(6, 2) NULL DEFAULT NULL,
  `reporting_rate` decimal(6, 2) NULL DEFAULT NULL,
  `total_health_facilities` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `pk_id`(`pk_id`) USING BTREE,
  INDEX `item_id`(`item_id`) USING BTREE,
  INDEX `stakeholder_id`(`stakeholder_id`) USING BTREE,
  INDEX `reporting_date`(`reporting_date`) USING BTREE,
  INDEX `province_id`(`province_id`) USING BTREE,
  INDEX `district_id`(`district_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 919514 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_dist_levels
-- ----------------------------
DROP TABLE IF EXISTS `tbl_dist_levels`;
CREATE TABLE `tbl_dist_levels`  (
  `lvl_id` int NOT NULL AUTO_INCREMENT COMMENT 'distribution level id',
  `lvl_name` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `lvl_desc` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`lvl_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'distribution level like district, province, national' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_hf_data
-- ----------------------------
DROP TABLE IF EXISTS `tbl_hf_data`;
CREATE TABLE `tbl_hf_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `warehouse_id` int NOT NULL,
  `item_id` int UNSIGNED NOT NULL,
  `opening_balance` double NULL DEFAULT NULL,
  `received_balance` double NULL DEFAULT NULL,
  `issue_balance` double NULL DEFAULT NULL,
  `closing_balance` double NULL DEFAULT NULL,
  `adjustment_positive` double NULL DEFAULT NULL,
  `adjustment_negative` double NULL DEFAULT NULL,
  `avg_consumption` double NULL DEFAULT NULL,
  `new` int NULL DEFAULT NULL,
  `old` int NULL DEFAULT NULL,
  `reporting_date` date NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp,
  `last_update` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `ip_address` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `created_by` int NOT NULL,
  `is_amc_calculated` tinyint NOT NULL DEFAULT 0,
  `temp` tinyint NULL DEFAULT 1,
  `removals` double NULL DEFAULT NULL,
  `dropouts` double NULL DEFAULT NULL,
  `demand` double NULL DEFAULT NULL,
  `change_pos` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `change_neg` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `retrieved` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `arv_patients` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_stock_dcurperiod` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `quarterly_demand` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `pk_id`(`pk_id`) USING BTREE,
  INDEX `warehouse_id`(`warehouse_id`) USING BTREE,
  INDEX `item_id`(`item_id`) USING BTREE,
  INDEX `reporting_date`(`reporting_date`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 27278 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_hf_type
-- ----------------------------
DROP TABLE IF EXISTS `tbl_hf_type`;
CREATE TABLE `tbl_hf_type`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `hf_type` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `stakeholder_id` int NOT NULL COMMENT 'Use ZERO stk for HF types used everywhere.',
  `hf_rank` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `pk_id`(`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 86 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_hf_type_rank
-- ----------------------------
DROP TABLE IF EXISTS `tbl_hf_type_rank`;
CREATE TABLE `tbl_hf_type_rank`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `stakeholder_id` int NOT NULL,
  `hf_type_id` int NOT NULL,
  `province_id` int NOT NULL,
  `hf_type_rank` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `pk_id`(`pk_id`) USING BTREE,
  INDEX `stakeholder_id`(`stakeholder_id`) USING BTREE,
  INDEX `hf_type_id`(`hf_type_id`) USING BTREE,
  INDEX `province_id`(`province_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 157 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_itemunits
-- ----------------------------
DROP TABLE IF EXISTS `tbl_itemunits`;
CREATE TABLE `tbl_itemunits`  (
  `pkUnitID` int NOT NULL AUTO_INCREMENT,
  `UnitType` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pkUnitID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_locations
-- ----------------------------
DROP TABLE IF EXISTS `tbl_locations`;
CREATE TABLE `tbl_locations`  (
  `PkLocID` int NOT NULL AUTO_INCREMENT,
  `LocName` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `LocLvl` int NULL DEFAULT NULL,
  `ParentID` int NULL DEFAULT NULL,
  `LocType` int NULL DEFAULT NULL,
  `temp_id` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `dhis_code` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `trees_id` int NULL DEFAULT NULL,
  `pop_male_rural` int NULL DEFAULT NULL,
  `pop_female_rural` int NULL DEFAULT NULL,
  `growth_rate_rural` decimal(15, 4) NULL DEFAULT NULL,
  `pop_male_urban` int NULL DEFAULT NULL,
  `pop_female_urban` int NULL DEFAULT NULL,
  `growth_rate_urban` decimal(15, 4) NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`PkLocID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8317 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_stock_detail
-- ----------------------------
DROP TABLE IF EXISTS `tbl_stock_detail`;
CREATE TABLE `tbl_stock_detail`  (
  `PkDetailID` int NOT NULL AUTO_INCREMENT,
  `fkStockID` int NULL DEFAULT NULL,
  `BatchID` int NULL DEFAULT NULL,
  `fkUnitID` int NULL DEFAULT NULL,
  `Qty` bigint NULL DEFAULT NULL,
  `temp` tinyint(1) NULL DEFAULT NULL,
  `vvm_stage` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `IsReceived` tinyint NULL DEFAULT NULL,
  `adjustmentType` tinyint(1) NULL DEFAULT NULL,
  `comments` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `manufacturer` int NULL DEFAULT NULL,
  `receiving_price` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `driver_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `driver_cnic` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `driver_contact` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name_of_service` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `consignment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name_of_agency` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `builty` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`PkDetailID`) USING BTREE,
  INDEX `PkDetailID`(`PkDetailID`) USING BTREE,
  INDEX `fkStockID`(`fkStockID`) USING BTREE,
  INDEX `BatchID`(`BatchID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1956322090 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_stock_detail_bkp
-- ----------------------------
DROP TABLE IF EXISTS `tbl_stock_detail_bkp`;
CREATE TABLE `tbl_stock_detail_bkp`  (
  `PkDetailID` int NOT NULL AUTO_INCREMENT,
  `fkStockID` int NULL DEFAULT NULL,
  `BatchID` int NULL DEFAULT NULL,
  `fkUnitID` int NULL DEFAULT NULL,
  `Qty` bigint NULL DEFAULT NULL,
  `temp` tinyint(1) NULL DEFAULT NULL,
  `vvm_stage` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `IsReceived` tinyint NULL DEFAULT NULL,
  `adjustmentType` tinyint(1) NULL DEFAULT NULL,
  `comments` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `manufacturer` int NULL DEFAULT NULL,
  `delivery_challan_type` int NULL DEFAULT NULL,
  `challan_type_detail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_driver_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_contatc_number` int NULL DEFAULT NULL,
  `siv_cnic` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_weight` double NULL DEFAULT NULL,
  `siv_no_of_cartons` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_transportation_po` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `siv_tracking_no` int NULL DEFAULT NULL,
  `actual_rec_qty` int NULL DEFAULT NULL,
  PRIMARY KEY (`PkDetailID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 69 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_stock_master
-- ----------------------------
DROP TABLE IF EXISTS `tbl_stock_master`;
CREATE TABLE `tbl_stock_master`  (
  `PkStockID` int NOT NULL AUTO_INCREMENT,
  `TranDate` datetime NULL DEFAULT NULL,
  `TranNo` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `TranTypeID` int NULL DEFAULT NULL,
  `TranRef` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `WHIDFrom` int NULL DEFAULT NULL,
  `WHIDTo` int NULL DEFAULT NULL,
  `CreatedBy` int NULL DEFAULT NULL,
  `CreatedOn` date NULL DEFAULT NULL,
  `ReceivedRemarks` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `temp` tinyint(1) NULL DEFAULT NULL,
  `trNo` int NULL DEFAULT NULL,
  `LinkedTr` int NULL DEFAULT NULL,
  `issued_by` int NULL DEFAULT NULL,
  `is_copied` tinyint NULL DEFAULT 0,
  `shipment_id` int NULL DEFAULT NULL,
  `WHIDFromSupplier` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `shipment_mode` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `attachment_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `method` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `requisition_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `source_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `event` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `po_detail` int NULL DEFAULT NULL,
  PRIMARY KEY (`PkStockID`) USING BTREE,
  INDEX `PkStockID`(`PkStockID`) USING BTREE,
  INDEX `WHIDFrom`(`WHIDFrom`) USING BTREE,
  INDEX `WHIDTo`(`WHIDTo`) USING BTREE,
  INDEX `TranNo`(`TranNo`) USING BTREE,
  INDEX `TranTypeID`(`TranTypeID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 544246 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_trans_type
-- ----------------------------
DROP TABLE IF EXISTS `tbl_trans_type`;
CREATE TABLE `tbl_trans_type`  (
  `trans_id` int NOT NULL AUTO_INCREMENT,
  `trans_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `trans_nature` varchar(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_adjustment` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`trans_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_warehouse
-- ----------------------------
DROP TABLE IF EXISTS `tbl_warehouse`;
CREATE TABLE `tbl_warehouse`  (
  `wh_id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `wh_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `dist_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `prov_id` int NULL DEFAULT NULL COMMENT 'province of warehouse',
  `stkid` int NULL DEFAULT NULL COMMENT 'stakeholder',
  `public_private` int NULL DEFAULT NULL,
  `wh_type_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `locid` int NULL DEFAULT NULL,
  `stkofficeid` int NULL DEFAULT NULL,
  `is_allowed_im` tinyint(1) NOT NULL DEFAULT 0,
  `hf_type_id` int NULL DEFAULT NULL,
  `hf_cat_id` int NULL DEFAULT NULL COMMENT '1=Primary, 2=Secondary, 3=Tertiary',
  `system_id` int NULL DEFAULT NULL,
  `system_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `wh_rank` decimal(10, 0) NULL DEFAULT NULL,
  `dhis_code` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'only 6 digit dhis facility code',
  `is_active` tinyint NOT NULL DEFAULT 1,
  `reporting_start_month` date NULL DEFAULT NULL,
  `editable_data_entry_months` tinyint NOT NULL DEFAULT 2,
  `is_lock_data_entry` tinyint NOT NULL DEFAULT 0,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT 1,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int NULL DEFAULT 1,
  `im_start_month` date NULL DEFAULT NULL,
  `parent_id` int NULL DEFAULT NULL,
  `merf_code` int NULL DEFAULT NULL,
  `ihs_code` int NULL DEFAULT NULL,
  `pphi_code` int NULL DEFAULT NULL,
  `total_bed_space` int NULL DEFAULT NULL,
  `issue_to_address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tehsil_id` int NULL DEFAULT NULL,
  `uc_id` int NULL DEFAULT NULL,
  `city_id` int NULL DEFAULT NULL,
  `province_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `district_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `uc_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tehsil_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `city_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `category_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `facility_type_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stakeholder_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact_person` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact_designation` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact_number` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `longitude` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `latitude` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `parent_hospital_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tb_dhis2_uid` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`wh_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 101505 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'contain information about warehouse' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_wh_data
-- ----------------------------
DROP TABLE IF EXISTS `tbl_wh_data`;
CREATE TABLE `tbl_wh_data`  (
  `w_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `report_month` int NULL DEFAULT NULL,
  `report_year` int NULL DEFAULT NULL,
  `item_id` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `wh_id` int NULL DEFAULT NULL,
  `wh_obl_a` int NULL DEFAULT NULL,
  `wh_obl_c` int NULL DEFAULT NULL,
  `wh_received` int NULL DEFAULT NULL,
  `wh_issue_up` int NULL DEFAULT NULL,
  `wh_cbl_c` int NULL DEFAULT NULL,
  `wh_cbl_a` int NULL DEFAULT NULL,
  `wh_adja` int NULL DEFAULT NULL,
  `wh_adjb` int NULL DEFAULT NULL,
  `lvl` smallint NULL DEFAULT NULL,
  `RptDate` date NULL DEFAULT NULL,
  `add_date` datetime NULL DEFAULT NULL,
  `last_update` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `ip_address` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `is_calculated` tinyint NULL DEFAULT 0,
  `comments` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`w_id`) USING BTREE,
  INDEX `item_id`(`item_id`) USING BTREE,
  INDEX `wh_id`(`wh_id`) USING BTREE,
  INDEX `RptDate`(`RptDate`) USING BTREE,
  INDEX `report_month`(`report_month`) USING BTREE,
  INDEX `report_year`(`report_year`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'InnoDB free: 61440 kB; (`item_id`) REFER `paklmis/itminfo_ta' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_wh_data_draft
-- ----------------------------
DROP TABLE IF EXISTS `tbl_wh_data_draft`;
CREATE TABLE `tbl_wh_data_draft`  (
  `w_id` int NOT NULL AUTO_INCREMENT,
  `report_month` int NULL DEFAULT NULL,
  `report_year` int NULL DEFAULT NULL,
  `item_id` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `wh_id` int NULL DEFAULT NULL,
  `wh_obl_a` int NULL DEFAULT NULL,
  `wh_obl_c` int NULL DEFAULT NULL,
  `wh_received` int NULL DEFAULT NULL,
  `wh_issue_up` int NULL DEFAULT NULL,
  `wh_cbl_c` int NULL DEFAULT NULL,
  `wh_cbl_a` int NULL DEFAULT NULL,
  `wh_adja` int NULL DEFAULT NULL,
  `wh_adjb` int NULL DEFAULT NULL,
  `lvl` smallint NULL DEFAULT NULL,
  `RptDate` date NULL DEFAULT NULL,
  `add_date` datetime NULL DEFAULT NULL,
  `last_update` datetime NULL DEFAULT NULL,
  `ip_address` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`w_id`) USING BTREE,
  INDEX `item_id`(`item_id`) USING BTREE,
  INDEX `wh_id`(`wh_id`) USING BTREE,
  INDEX `RptDate`(`RptDate`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'InnoDB free: 61440 kB; (`item_id`) REFER `paklmis/itminfo_ta' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_wh_data_history
-- ----------------------------
DROP TABLE IF EXISTS `tbl_wh_data_history`;
CREATE TABLE `tbl_wh_data_history`  (
  `w_id` int NOT NULL AUTO_INCREMENT,
  `report_month` int NULL DEFAULT NULL,
  `report_year` int NULL DEFAULT NULL,
  `item_id` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `wh_id` int NULL DEFAULT NULL,
  `wh_obl_a` int NULL DEFAULT NULL,
  `wh_received` int NULL DEFAULT NULL,
  `wh_issue_up` int NULL DEFAULT NULL,
  `wh_cbl_a` int NULL DEFAULT NULL,
  `wh_adja` int NULL DEFAULT NULL,
  `wh_adjb` int NULL DEFAULT NULL,
  `RptDate` date NULL DEFAULT NULL,
  `add_date` datetime NULL DEFAULT NULL,
  `ip_address` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`w_id`) USING BTREE,
  INDEX `item_id`(`item_id`) USING BTREE,
  INDEX `wh_id`(`wh_id`) USING BTREE,
  INDEX `RptDate`(`RptDate`) USING BTREE,
  INDEX `wh_id_2`(`wh_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'InnoDB free: 61440 kB; (`item_id`) REFER `paklmis/itminfo_ta' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_wh_update_history
-- ----------------------------
DROP TABLE IF EXISTS `tbl_wh_update_history`;
CREATE TABLE `tbl_wh_update_history`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `wh_id` int NOT NULL,
  `reporting_date` date NOT NULL,
  `update_on` datetime NULL DEFAULT NULL,
  `updated_by` int NULL DEFAULT NULL,
  `ip_address` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for test_result
-- ----------------------------
DROP TABLE IF EXISTS `test_result`;
CREATE TABLE `test_result`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `result_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT 1,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for transaction_log
-- ----------------------------
DROP TABLE IF EXISTS `transaction_log`;
CREATE TABLE `transaction_log`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT current_timestamp,
  `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'Add, Update, Delete',
  `module` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'GWIS, SIV, etc',
  `reference_id` int NULL DEFAULT NULL,
  `tran_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `raw_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 358 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for transaction_types
-- ----------------------------
DROP TABLE IF EXISTS `transaction_types`;
CREATE TABLE `transaction_types`  (
  `trans_id` int NOT NULL AUTO_INCREMENT,
  `trans_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `trans_nature` varchar(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_adjustment` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`trans_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for transaction_types_old
-- ----------------------------
DROP TABLE IF EXISTS `transaction_types_old`;
CREATE TABLE `transaction_types_old`  (
  `trans_id` int NOT NULL AUTO_INCREMENT,
  `trans_type` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `nature` varchar(1) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_adjustment` tinyint(1) NULL DEFAULT NULL,
  `status` tinyint(1) NULL DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `modified_by` int NOT NULL,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`trans_id`) USING BTREE,
  INDEX `transaction_types_users_fk1`(`created_by`) USING BTREE,
  INDEX `transaction_types_users_fk2`(`modified_by`) USING BTREE,
  CONSTRAINT `transaction_types_old_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `transaction_types_old_ibfk_2` FOREIGN KEY (`modified_by`) REFERENCES `users` (`pk_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for transport_product_info
-- ----------------------------
DROP TABLE IF EXISTS `transport_product_info`;
CREATE TABLE `transport_product_info`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `tr_master_id` int NULL DEFAULT NULL,
  `product` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `quantity` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `cartons` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `manufacturer` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `unit_cost` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `temp` int NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for transport_req_detail
-- ----------------------------
DROP TABLE IF EXISTS `transport_req_detail`;
CREATE TABLE `transport_req_detail`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `tr_master_id` int NULL DEFAULT NULL,
  `vehicle_type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `no_of_vehicle` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `vehicle_rent` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `amount` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `temp` int NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  `vehicle_req_date` date NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for transport_req_master
-- ----------------------------
DROP TABLE IF EXISTS `transport_req_master`;
CREATE TABLE `transport_req_master`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `tran_no` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `tr_no` int NULL DEFAULT NULL,
  `temp` int NULL DEFAULT NULL,
  `date_vehicle_req` date NULL DEFAULT NULL,
  `location_from` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `location_to` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_vehicle_cost` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `total_cartons` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `status` int NULL DEFAULT NULL,
  `approver_status` int NULL DEFAULT NULL,
  `file` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `demand_req_date` datetime NULL DEFAULT NULL,
  `demand_requisition` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for trees_disease_mapping
-- ----------------------------
DROP TABLE IF EXISTS `trees_disease_mapping`;
CREATE TABLE `trees_disease_mapping`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `trees_disease_id` int NULL DEFAULT NULL,
  `idmis_disease_id` int NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for unmapped_lab_data
-- ----------------------------
DROP TABLE IF EXISTS `unmapped_lab_data`;
CREATE TABLE `unmapped_lab_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `wh_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `lab_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `raw_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `report_date` date NULL DEFAULT NULL,
  `created_at` datetime NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10662 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for user_access_logs
-- ----------------------------
DROP TABLE IF EXISTS `user_access_logs`;
CREATE TABLE `user_access_logs`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `login_time` datetime NOT NULL DEFAULT current_timestamp,
  `logout_time` datetime NULL DEFAULT NULL,
  `username` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `login_success` int NULL DEFAULT NULL,
  `remarks` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `user_id` bigint NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1542 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for user_prov
-- ----------------------------
DROP TABLE IF EXISTS `user_prov`;
CREATE TABLE `user_prov`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `prov_id` int NULL DEFAULT NULL,
  `user_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 178 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for user_stk
-- ----------------------------
DROP TABLE IF EXISTS `user_stk`;
CREATE TABLE `user_stk`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `stk_id` int NULL DEFAULT NULL,
  `user_id` int NULL DEFAULT NULL,
  `is_default` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1891 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `designation` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `login_id` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `landing_page` int NULL DEFAULT NULL,
  `role_id` int NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `modified_by` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `modified_date` timestamp NULL DEFAULT current_timestamp ON UPDATE CURRENT_TIMESTAMP,
  `district_id` int NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL,
  `warehouse_id` int NULL DEFAULT NULL,
  `stakeholder_id` bigint NULL DEFAULT NULL,
  `file` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `user_level` int NULL DEFAULT NULL,
  `drilldown_access` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 671 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for vaccine_data
-- ----------------------------
DROP TABLE IF EXISTS `vaccine_data`;
CREATE TABLE `vaccine_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `date` date NULL DEFAULT NULL,
  `first_dose` int NULL DEFAULT NULL,
  `full_vaccinated` int NULL DEFAULT NULL,
  `booster_1` int NULL DEFAULT NULL,
  `booster_2` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for vitals
-- ----------------------------
DROP TABLE IF EXISTS `vitals`;
CREATE TABLE `vitals`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` int NULL DEFAULT NULL,
  `rank` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 30 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for warehouse_categories
-- ----------------------------
DROP TABLE IF EXISTS `warehouse_categories`;
CREATE TABLE `warehouse_categories`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for warehouse_population
-- ----------------------------
DROP TABLE IF EXISTS `warehouse_population`;
CREATE TABLE `warehouse_population`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `facility_total_pouplation` int NULL DEFAULT NULL,
  `estimation_year` year NULL DEFAULT NULL,
  `warehouse_id` int NULL DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_date` datetime NULL DEFAULT NULL,
  `modified_by` int NOT NULL,
  `modified_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE,
  INDEX `warehouses_population_warehouses_fk1`(`warehouse_id`) USING BTREE,
  INDEX `warehouses_population_users_fk2`(`created_by`) USING BTREE,
  INDEX `warehouses_population_users_fk3`(`modified_by`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for warehouse_status_history
-- ----------------------------
DROP TABLE IF EXISTS `warehouse_status_history`;
CREATE TABLE `warehouse_status_history`  (
  `pk_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `warehouse_id` int NOT NULL,
  `status` tinyint NOT NULL,
  `reporting_month` date NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 28 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for warehouse_types
-- ----------------------------
DROP TABLE IF EXISTS `warehouse_types`;
CREATE TABLE `warehouse_types`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `type_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  `category_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `is_active` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for warehouses
-- ----------------------------
DROP TABLE IF EXISTS `warehouses`;
CREATE TABLE `warehouses`  (
  `pk_id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `warehouse_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `district_id` int NULL DEFAULT NULL,
  `province_id` int NULL DEFAULT NULL COMMENT 'province of warehouse',
  `stakeholder_id` int NULL DEFAULT NULL COMMENT 'stakeholder',
  `tehsil_id` int NULL DEFAULT NULL,
  `uc_id` int NULL DEFAULT NULL,
  `city_id` int NULL DEFAULT NULL,
  `province_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `district_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `uc_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tehsil_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `city_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  `category_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `facility_type_id` int NULL DEFAULT NULL,
  `facility_type_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stakeholder_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `facility_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact_person` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact_designation` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `contact_number` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `status` tinyint(1) NULL DEFAULT 1,
  `total_bed_space` int NULL DEFAULT NULL,
  `created_by` int NOT NULL DEFAULT 1,
  `created_date` datetime NULL DEFAULT current_timestamp,
  `modified_by` int NOT NULL DEFAULT 1,
  `modified_date` datetime NOT NULL DEFAULT current_timestamp,
  `longitude` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `latitude` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `parent_hospital_id` int NULL DEFAULT NULL,
  `parent_hospital_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 42 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'contain information about warehouse' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for warehouses_by_month
-- ----------------------------
DROP TABLE IF EXISTS `warehouses_by_month`;
CREATE TABLE `warehouses_by_month`  (
  `pk_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `total_stores` int UNSIGNED NOT NULL,
  `level` tinyint NOT NULL,
  `stakeholder_id` int NOT NULL,
  `district_id` int UNSIGNED NOT NULL,
  `reporting_date` date NOT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for web_tokens
-- ----------------------------
DROP TABLE IF EXISTS `web_tokens`;
CREATE TABLE `web_tokens`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `valid_till` timestamp NULL DEFAULT NULL,
  `created_date` datetime NULL DEFAULT current_timestamp,
  `updated_date` datetime NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for wh_active_tests
-- ----------------------------
DROP TABLE IF EXISTS `wh_active_tests`;
CREATE TABLE `wh_active_tests`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `wh_id` int NULL DEFAULT NULL,
  `lab_master_id` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  `created_by` int NULL DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int NULL DEFAULT NULL,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 46 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for wh_data
-- ----------------------------
DROP TABLE IF EXISTS `wh_data`;
CREATE TABLE `wh_data`  (
  `pk_id` int NOT NULL AUTO_INCREMENT,
  `report_date` date NULL DEFAULT NULL,
  `item_id` int NULL DEFAULT NULL,
  `wh_id` int NULL DEFAULT NULL,
  `opening` decimal(10, 0) NULL DEFAULT NULL,
  `received` decimal(10, 0) NULL DEFAULT NULL,
  `issued` decimal(10, 0) NULL DEFAULT NULL,
  `closing` decimal(10, 0) NULL DEFAULT NULL,
  `pos_adjustment` decimal(10, 0) NULL DEFAULT NULL,
  `neg_adjustment` decimal(10, 0) NULL DEFAULT NULL,
  `created_by` int NULL DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT current_timestamp,
  PRIMARY KEY (`pk_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 208951 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = FIXED;

-- ----------------------------
-- Table structure for wh_user
-- ----------------------------
DROP TABLE IF EXISTS `wh_user`;
CREATE TABLE `wh_user`  (
  `wh_user_id` int NOT NULL AUTO_INCREMENT,
  `sysusrrec_id` int NOT NULL,
  `wh_id` int NOT NULL,
  `is_default` int NULL DEFAULT 1,
  PRIMARY KEY (`wh_user_id`) USING BTREE,
  INDEX `sysusrrec_id`(`sysusrrec_id`) USING BTREE,
  INDEX `wh_id`(`wh_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 895 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Triggers structure for table gwis_detail
-- ----------------------------
DROP TRIGGER IF EXISTS `AddQty`;
delimiter ;;
CREATE TRIGGER `AddQty` AFTER INSERT ON `gwis_detail` FOR EACH ROW BEGIN
 CALL REPAdjQty(NEW.batch_id);
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table gwis_detail
-- ----------------------------
DROP TRIGGER IF EXISTS `AddDetailHistory`;
delimiter ;;
CREATE TRIGGER `AddDetailHistory` BEFORE UPDATE ON `gwis_detail` FOR EACH ROW BEGIN
INSERT INTO gwis_detail_history SELECT NULL,gwis_detail.*,NOW() FROM gwis_detail WHERE pk_id = OLD.pk_id;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table gwis_detail
-- ----------------------------
DROP TRIGGER IF EXISTS `UpdateQty`;
delimiter ;;
CREATE TRIGGER `UpdateQty` AFTER UPDATE ON `gwis_detail` FOR EACH ROW BEGIN
 CALL REPAdjQty(NEW.batch_id);
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table gwis_detail
-- ----------------------------
DROP TRIGGER IF EXISTS `AddDetailDeleteHistory`;
delimiter ;;
CREATE TRIGGER `AddDetailDeleteHistory` BEFORE DELETE ON `gwis_detail` FOR EACH ROW BEGIN
INSERT INTO gwis_detail_history SELECT NULL,gwis_detail.*,NOW() FROM gwis_detail WHERE pk_id = OLD.pk_id;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table gwis_detail
-- ----------------------------
DROP TRIGGER IF EXISTS `DeleteQty`;
delimiter ;;
CREATE TRIGGER `DeleteQty` AFTER DELETE ON `gwis_detail` FOR EACH ROW BEGIN
 CALL REPAdjQty(OLD.batch_id);
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table gwis_detail_history
-- ----------------------------
DROP TRIGGER IF EXISTS `UpdateQty_copy1`;
delimiter ;;
CREATE TRIGGER `UpdateQty_copy1` AFTER INSERT ON `gwis_detail_history` FOR EACH ROW BEGIN
 CALL REPAdjQty(NEW.batch_id);
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table gwis_detail_history
-- ----------------------------
DROP TRIGGER IF EXISTS `DeleteQty_copy1`;
delimiter ;;
CREATE TRIGGER `DeleteQty_copy1` AFTER DELETE ON `gwis_detail_history` FOR EACH ROW BEGIN
 CALL REPAdjQty(OLD.batch_id);
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table summary_district
-- ----------------------------
DROP TRIGGER IF EXISTS `Update Province Summary Table Insert`;
delimiter ;;
CREATE TRIGGER `Update Province Summary Table Insert` AFTER INSERT ON `summary_district` FOR EACH ROW BEGIN
    CALL REPUpdateSummaryProvince(NEW.item_id, NEW.reporting_date, NEW.stakeholder_id, NEW.province_id);
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table summary_district
-- ----------------------------
DROP TRIGGER IF EXISTS `Update Province Summary Table Update`;
delimiter ;;
CREATE TRIGGER `Update Province Summary Table Update` AFTER UPDATE ON `summary_district` FOR EACH ROW BEGIN
    CALL REPUpdateSummaryProvince(NEW.item_id, NEW.reporting_date, NEW.stakeholder_id, NEW.province_id);
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
